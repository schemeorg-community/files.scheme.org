/* Generated from srfi-13.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2009-03-24 10:47
   Version 4.0.0 - SVN rev. 13887
   windows-mingw32-x86 [ manyargs dload ptables applyhook ]
   compiled 2009-03-24 on LENOVO-1 (MINGW32_NT-6.0)
   command line: srfi-13.scm -no-trace -optimize-level 2 -include-path . -include-path ./ -feature debugbuild -explicit-use -unsafe -no-lambda-info -output-file usrfi-13.c
   unit: srfi_13
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_srfi_14_toplevel)
C_externimport void C_ccall C_srfi_14_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[156];
static double C_possibly_force_alignment;


C_noret_decl(C_srfi_13_toplevel)
C_externexport void C_ccall C_srfi_13_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3503)
static void C_ccall f_3503(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3506)
static void C_ccall f_3506(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9324)
static void C_ccall f_9324(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_9324)
static void C_ccall f_9324r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_9433)
static void C_ccall f_9433(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9403)
static void C_ccall f_9403(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9386)
static void C_ccall f_9386(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9341)
static void C_fcall f_9341(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9347)
static void C_fcall f_9347(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9369)
static void C_ccall f_9369(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9251)
static void C_fcall f_9251(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7) C_noret;
C_noret_decl(f_9322)
static void C_ccall f_9322(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9282)
static C_word C_fcall f_9282(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_9111)
static void C_ccall f_9111(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,...) C_noret;
C_noret_decl(f_9111)
static void C_ccall f_9111r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t7) C_noret;
C_noret_decl(f_9164)
static void C_ccall f_9164(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9177)
static void C_ccall f_9177(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9230)
static void C_ccall f_9230(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9226)
static void C_ccall f_9226(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9120)
static void C_ccall f_9120(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9142)
static void C_ccall f_9142(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9132)
static void C_ccall f_9132(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8973)
static void C_ccall f_8973(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_8973)
static void C_ccall f_8973r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_9026)
static void C_ccall f_9026(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9089)
static void C_ccall f_9089(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9092)
static void C_ccall f_9092(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9086)
static void C_ccall f_9086(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9082)
static void C_ccall f_9082(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8982)
static void C_ccall f_8982(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9004)
static void C_ccall f_9004(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8994)
static void C_ccall f_8994(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8891)
static void C_ccall f_8891(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_8891)
static void C_ccall f_8891r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_8909)
static void C_ccall f_8909(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8915)
static void C_fcall f_8915(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8919)
static void C_ccall f_8919(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8928)
static void C_ccall f_8928(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8953)
static void C_ccall f_8953(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8942)
static void C_ccall f_8942(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8903)
static void C_ccall f_8903(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8840)
static void C_ccall f_8840(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,...) C_noret;
C_noret_decl(f_8840)
static void C_ccall f_8840r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t7) C_noret;
C_noret_decl(f_8844)
static void C_ccall f_8844(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8855)
static void C_ccall f_8855(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8868)
static void C_ccall f_8868(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8849)
static void C_ccall f_8849(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8797)
static void C_fcall f_8797(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8801)
static void C_ccall f_8801(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8809)
static C_word C_fcall f_8809(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_8671)
static void C_ccall f_8671(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_8671)
static void C_ccall f_8671r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_8695)
static void C_fcall f_8695(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8745)
static void C_fcall f_8745(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8586)
static void C_ccall f_8586(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_8586)
static void C_ccall f_8586r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_8613)
static C_word C_fcall f_8613(C_word t0,C_word t1);
C_noret_decl(f_8513)
static void C_ccall f_8513(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8520)
static void C_ccall f_8520(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8525)
static C_word C_fcall f_8525(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_8554)
static C_word C_fcall f_8554(C_word t0,C_word t1);
C_noret_decl(f_8411)
static void C_ccall f_8411(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8417)
static void C_fcall f_8417(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8471)
static void C_ccall f_8471(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8476)
static C_word C_fcall f_8476(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_8405)
static void C_ccall f_8405(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_8405)
static void C_ccall f_8405r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_8359)
static void C_ccall f_8359(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_8359)
static void C_ccall f_8359r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_8371)
static void C_ccall f_8371(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8381)
static void C_fcall f_8381(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8365)
static void C_ccall f_8365(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8304)
static void C_ccall f_8304(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_8304)
static void C_ccall f_8304r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_8316)
static void C_ccall f_8316(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8326)
static C_word C_fcall f_8326(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_8310)
static void C_ccall f_8310(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8249)
static void C_ccall f_8249(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_8249)
static void C_ccall f_8249r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_8261)
static void C_ccall f_8261(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8268)
static void C_ccall f_8268(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8277)
static C_word C_fcall f_8277(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_8255)
static void C_ccall f_8255(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8246)
static void C_ccall f_8246(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8125)
static void C_ccall f_8125(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,...) C_noret;
C_noret_decl(f_8125)
static void C_ccall f_8125r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t7) C_noret;
C_noret_decl(f_8149)
static void C_ccall f_8149(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8158)
static void C_fcall f_8158(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8190)
static void C_fcall f_8190(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8197)
static void C_ccall f_8197(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8188)
static void C_ccall f_8188(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8143)
static void C_ccall f_8143(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8087)
static void C_ccall f_8087(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7) C_noret;
C_noret_decl(f_8093)
static void C_fcall f_8093(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8100)
static void C_ccall f_8100(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7952)
static void C_ccall f_7952(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_7952)
static void C_ccall f_7952r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_7970)
static void C_ccall f_7970(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7977)
static void C_ccall f_7977(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7994)
static void C_fcall f_7994(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8009)
static void C_fcall f_8009(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8042)
static void C_ccall f_8042(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8036)
static void C_ccall f_8036(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7980)
static void C_ccall f_7980(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7964)
static void C_ccall f_7964(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7890)
static void C_ccall f_7890(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_7890)
static void C_ccall f_7890r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_7902)
static void C_ccall f_7902(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7914)
static void C_ccall f_7914(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7926)
static void C_fcall f_7926(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7939)
static void C_ccall f_7939(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7908)
static void C_ccall f_7908(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7896)
static void C_ccall f_7896(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7828)
static void C_ccall f_7828(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_7828)
static void C_ccall f_7828r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_7840)
static void C_ccall f_7840(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7852)
static void C_ccall f_7852(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7864)
static void C_fcall f_7864(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7877)
static void C_ccall f_7877(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7846)
static void C_ccall f_7846(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7834)
static void C_ccall f_7834(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7825)
static C_word C_fcall f_7825(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4);
C_noret_decl(f_7793)
static void C_ccall f_7793(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_7793)
static void C_ccall f_7793r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_7805)
static void C_ccall f_7805(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7812)
static void C_ccall f_7812(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7799)
static void C_ccall f_7799(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7752)
static void C_ccall f_7752(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_7752)
static void C_ccall f_7752r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_7764)
static void C_ccall f_7764(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7774)
static C_word C_fcall f_7774(C_word t0,C_word t1);
C_noret_decl(f_7758)
static void C_ccall f_7758(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7617)
static void C_ccall f_7617(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_7617)
static void C_ccall f_7617r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_7629)
static void C_ccall f_7629(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7675)
static void C_ccall f_7675(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7719)
static void C_fcall f_7719(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7740)
static void C_ccall f_7740(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7680)
static void C_fcall f_7680(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7701)
static void C_ccall f_7701(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7641)
static C_word C_fcall f_7641(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_7623)
static void C_ccall f_7623(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7482)
static void C_ccall f_7482(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_7482)
static void C_ccall f_7482r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_7494)
static void C_ccall f_7494(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7540)
static void C_ccall f_7540(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7588)
static void C_fcall f_7588(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7601)
static void C_ccall f_7601(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7549)
static void C_fcall f_7549(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7562)
static void C_ccall f_7562(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7510)
static C_word C_fcall f_7510(C_word t0,C_word t1);
C_noret_decl(f_7488)
static void C_ccall f_7488(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7359)
static void C_ccall f_7359(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_7359)
static void C_ccall f_7359r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_7371)
static void C_ccall f_7371(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7413)
static void C_ccall f_7413(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7453)
static void C_fcall f_7453(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7466)
static void C_ccall f_7466(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7418)
static void C_fcall f_7418(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7431)
static void C_ccall f_7431(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7383)
static C_word C_fcall f_7383(C_word t0,C_word t1);
C_noret_decl(f_7365)
static void C_ccall f_7365(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7224)
static void C_ccall f_7224(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_7224)
static void C_ccall f_7224r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_7236)
static void C_ccall f_7236(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7282)
static void C_ccall f_7282(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7330)
static void C_fcall f_7330(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7343)
static void C_ccall f_7343(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7291)
static void C_fcall f_7291(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7304)
static void C_ccall f_7304(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7252)
static C_word C_fcall f_7252(C_word t0,C_word t1);
C_noret_decl(f_7230)
static void C_ccall f_7230(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7101)
static void C_ccall f_7101(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_7101)
static void C_ccall f_7101r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_7113)
static void C_ccall f_7113(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7155)
static void C_ccall f_7155(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7195)
static void C_fcall f_7195(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7208)
static void C_ccall f_7208(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7160)
static void C_fcall f_7160(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7173)
static void C_ccall f_7173(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7125)
static C_word C_fcall f_7125(C_word t0,C_word t1);
C_noret_decl(f_7107)
static void C_ccall f_7107(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6993)
static void C_ccall f_6993(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_6993)
static void C_ccall f_6993r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_7005)
static void C_ccall f_7005(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7087)
static void C_ccall f_7087(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7048)
static void C_ccall f_7048(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7074)
static void C_ccall f_7074(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7081)
static void C_ccall f_7081(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7051)
static void C_ccall f_7051(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7054)
static void C_ccall f_7054(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7059)
static void C_ccall f_7059(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7066)
static void C_ccall f_7066(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7057)
static void C_ccall f_7057(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7018)
static void C_ccall f_7018(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7032)
static void C_ccall f_7032(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7039)
static void C_ccall f_7039(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7021)
static void C_ccall f_7021(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6999)
static void C_ccall f_6999(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6885)
static void C_ccall f_6885(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_6885)
static void C_ccall f_6885r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_6897)
static void C_ccall f_6897(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6979)
static void C_ccall f_6979(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6940)
static void C_ccall f_6940(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6966)
static void C_ccall f_6966(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6973)
static void C_ccall f_6973(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6943)
static void C_ccall f_6943(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6946)
static void C_ccall f_6946(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6951)
static void C_ccall f_6951(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6958)
static void C_ccall f_6958(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6949)
static void C_ccall f_6949(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6910)
static void C_ccall f_6910(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6924)
static void C_ccall f_6924(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6931)
static void C_ccall f_6931(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6913)
static void C_ccall f_6913(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6891)
static void C_ccall f_6891(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6823)
static void C_ccall f_6823(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_6823)
static void C_ccall f_6823r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_6844)
static void C_ccall f_6844(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6864)
static void C_ccall f_6864(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6838)
static void C_ccall f_6838(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6765)
static void C_ccall f_6765(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_6765)
static void C_ccall f_6765r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_6786)
static void C_ccall f_6786(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6806)
static void C_ccall f_6806(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6780)
static void C_ccall f_6780(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6715)
static void C_ccall f_6715(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6715)
static void C_ccall f_6715r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6733)
static void C_ccall f_6733(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6737)
static void C_ccall f_6737(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6751)
static void C_ccall f_6751(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6727)
static void C_ccall f_6727(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6669)
static void C_ccall f_6669(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6669)
static void C_ccall f_6669r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6687)
static void C_ccall f_6687(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6691)
static void C_ccall f_6691(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6681)
static void C_ccall f_6681(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6627)
static void C_ccall f_6627(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6627)
static void C_ccall f_6627r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6645)
static void C_ccall f_6645(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6649)
static void C_ccall f_6649(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6639)
static void C_ccall f_6639(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6600)
static void C_ccall f_6600(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6607)
static void C_ccall f_6607(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6577)
static void C_ccall f_6577(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6584)
static void C_ccall f_6584(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6550)
static void C_ccall f_6550(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6557)
static void C_ccall f_6557(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6530)
static void C_ccall f_6530(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6537)
static void C_ccall f_6537(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6505)
static void C_ccall f_6505(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6505)
static void C_ccall f_6505r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6517)
static void C_ccall f_6517(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6521)
static void C_ccall f_6521(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6524)
static void C_ccall f_6524(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6511)
static void C_ccall f_6511(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6487)
static void C_ccall f_6487(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6487)
static void C_ccall f_6487r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6499)
static void C_ccall f_6499(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6493)
static void C_ccall f_6493(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6428)
static void C_fcall f_6428(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6434)
static void C_fcall f_6434(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6481)
static void C_ccall f_6481(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6438)
static void C_ccall f_6438(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6468)
static void C_ccall f_6468(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6450)
static void C_ccall f_6450(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6456)
static void C_ccall f_6456(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6410)
static void C_ccall f_6410(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6410)
static void C_ccall f_6410r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6422)
static void C_ccall f_6422(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6416)
static void C_ccall f_6416(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6392)
static void C_ccall f_6392(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6392)
static void C_ccall f_6392r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6404)
static void C_ccall f_6404(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6398)
static void C_ccall f_6398(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6374)
static void C_ccall f_6374(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6374)
static void C_ccall f_6374r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6386)
static void C_ccall f_6386(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6380)
static void C_ccall f_6380(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6356)
static void C_ccall f_6356(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6356)
static void C_ccall f_6356r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6368)
static void C_ccall f_6368(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6362)
static void C_ccall f_6362(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6300)
static void C_ccall f_6300(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6300)
static void C_ccall f_6300r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6310)
static void C_fcall f_6310(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6324)
static void C_ccall f_6324(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6330)
static void C_ccall f_6330(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6318)
static void C_ccall f_6318(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6254)
static void C_ccall f_6254(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6254)
static void C_ccall f_6254r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6264)
static void C_fcall f_6264(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6278)
static void C_ccall f_6278(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6272)
static void C_ccall f_6272(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6182)
static void C_fcall f_6182(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_6200)
static void C_fcall f_6200(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6233)
static void C_ccall f_6233(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6235)
static C_word C_fcall f_6235(C_word t0,C_word t1);
C_noret_decl(f_6184)
static void C_fcall f_6184(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6134)
static void C_ccall f_6134(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_6134)
static void C_ccall f_6134r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_6146)
static void C_ccall f_6146(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6158)
static void C_ccall f_6158(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6165)
static void C_fcall f_6165(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6173)
static void C_ccall f_6173(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6152)
static void C_ccall f_6152(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6140)
static void C_ccall f_6140(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6086)
static void C_ccall f_6086(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_6086)
static void C_ccall f_6086r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_6098)
static void C_ccall f_6098(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6110)
static void C_ccall f_6110(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6117)
static void C_fcall f_6117(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6125)
static void C_ccall f_6125(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6104)
static void C_ccall f_6104(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6092)
static void C_ccall f_6092(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6035)
static void C_ccall f_6035(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_6035)
static void C_ccall f_6035r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_6047)
static void C_ccall f_6047(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6059)
static void C_ccall f_6059(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6066)
static void C_fcall f_6066(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6077)
static void C_ccall f_6077(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6074)
static void C_ccall f_6074(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6053)
static void C_ccall f_6053(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6041)
static void C_ccall f_6041(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5984)
static void C_ccall f_5984(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5984)
static void C_ccall f_5984r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5996)
static void C_ccall f_5996(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6008)
static void C_ccall f_6008(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6015)
static void C_fcall f_6015(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6026)
static void C_ccall f_6026(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6023)
static void C_ccall f_6023(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6002)
static void C_ccall f_6002(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5990)
static void C_ccall f_5990(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5917)
static void C_ccall f_5917(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5917)
static void C_ccall f_5917r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5929)
static void C_ccall f_5929(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5941)
static void C_ccall f_5941(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5964)
static void C_fcall f_5964(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5959)
static void C_ccall f_5959(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5935)
static void C_ccall f_5935(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5923)
static void C_ccall f_5923(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5855)
static void C_ccall f_5855(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5855)
static void C_ccall f_5855r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5867)
static void C_ccall f_5867(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5879)
static void C_ccall f_5879(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5889)
static void C_fcall f_5889(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5900)
static void C_ccall f_5900(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5897)
static void C_ccall f_5897(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5873)
static void C_ccall f_5873(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5861)
static void C_ccall f_5861(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5807)
static void C_ccall f_5807(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5807)
static void C_ccall f_5807r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5819)
static void C_ccall f_5819(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5831)
static void C_ccall f_5831(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5838)
static void C_fcall f_5838(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5846)
static void C_ccall f_5846(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5825)
static void C_ccall f_5825(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5813)
static void C_ccall f_5813(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5759)
static void C_ccall f_5759(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5759)
static void C_ccall f_5759r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5771)
static void C_ccall f_5771(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5783)
static void C_ccall f_5783(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5790)
static void C_fcall f_5790(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5798)
static void C_ccall f_5798(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5777)
static void C_ccall f_5777(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5765)
static void C_ccall f_5765(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5708)
static void C_ccall f_5708(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5708)
static void C_ccall f_5708r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5720)
static void C_ccall f_5720(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5732)
static void C_ccall f_5732(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5739)
static void C_fcall f_5739(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5750)
static void C_ccall f_5750(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5747)
static void C_ccall f_5747(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5726)
static void C_ccall f_5726(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5714)
static void C_ccall f_5714(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5657)
static void C_ccall f_5657(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5657)
static void C_ccall f_5657r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5669)
static void C_ccall f_5669(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5681)
static void C_ccall f_5681(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5688)
static void C_fcall f_5688(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5699)
static void C_ccall f_5699(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5696)
static void C_ccall f_5696(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5675)
static void C_ccall f_5675(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5663)
static void C_ccall f_5663(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5590)
static void C_ccall f_5590(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5590)
static void C_ccall f_5590r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5602)
static void C_ccall f_5602(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5614)
static void C_ccall f_5614(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5637)
static void C_fcall f_5637(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5632)
static void C_ccall f_5632(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5608)
static void C_ccall f_5608(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5596)
static void C_ccall f_5596(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5528)
static void C_ccall f_5528(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5528)
static void C_ccall f_5528r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5540)
static void C_ccall f_5540(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5552)
static void C_ccall f_5552(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5562)
static void C_fcall f_5562(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5573)
static void C_ccall f_5573(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5570)
static void C_ccall f_5570(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5546)
static void C_ccall f_5546(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5534)
static void C_ccall f_5534(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5498)
static void C_ccall f_5498(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,...) C_noret;
C_noret_decl(f_5498)
static void C_ccall f_5498r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t8) C_noret;
C_noret_decl(f_5510)
static void C_ccall f_5510(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5522)
static void C_ccall f_5522(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5516)
static void C_ccall f_5516(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5504)
static void C_ccall f_5504(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5468)
static void C_ccall f_5468(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,...) C_noret;
C_noret_decl(f_5468)
static void C_ccall f_5468r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t8) C_noret;
C_noret_decl(f_5480)
static void C_ccall f_5480(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5492)
static void C_ccall f_5492(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5486)
static void C_ccall f_5486(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5474)
static void C_ccall f_5474(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5406)
static void C_fcall f_5406(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9) C_noret;
C_noret_decl(f_5416)
static void C_ccall f_5416(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5450)
static void C_ccall f_5450(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5441)
static void C_fcall f_5441(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5344)
static void C_fcall f_5344(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9) C_noret;
C_noret_decl(f_5354)
static void C_ccall f_5354(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5379)
static void C_fcall f_5379(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5222)
static void C_ccall f_5222(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5222)
static void C_ccall f_5222r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5234)
static void C_ccall f_5234(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5246)
static void C_ccall f_5246(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5338)
static void C_ccall f_5338(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5240)
static void C_ccall f_5240(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5228)
static void C_ccall f_5228(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5192)
static void C_ccall f_5192(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5192)
static void C_ccall f_5192r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5204)
static void C_ccall f_5204(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5216)
static void C_ccall f_5216(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5315)
static void C_ccall f_5315(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5210)
static void C_ccall f_5210(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5198)
static void C_ccall f_5198(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5162)
static void C_ccall f_5162(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5162)
static void C_ccall f_5162r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5174)
static void C_ccall f_5174(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5186)
static void C_ccall f_5186(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5292)
static void C_ccall f_5292(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5180)
static void C_ccall f_5180(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5168)
static void C_ccall f_5168(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5132)
static void C_ccall f_5132(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5132)
static void C_ccall f_5132r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5144)
static void C_ccall f_5144(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5156)
static void C_ccall f_5156(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5269)
static void C_ccall f_5269(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5150)
static void C_ccall f_5150(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5138)
static void C_ccall f_5138(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5102)
static void C_ccall f_5102(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5102)
static void C_ccall f_5102r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5114)
static void C_ccall f_5114(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5126)
static void C_ccall f_5126(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5120)
static void C_ccall f_5120(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5108)
static void C_ccall f_5108(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5072)
static void C_ccall f_5072(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5072)
static void C_ccall f_5072r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5084)
static void C_ccall f_5084(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5096)
static void C_ccall f_5096(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5090)
static void C_ccall f_5090(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5078)
static void C_ccall f_5078(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5042)
static void C_ccall f_5042(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5042)
static void C_ccall f_5042r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5054)
static void C_ccall f_5054(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5066)
static void C_ccall f_5066(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5060)
static void C_ccall f_5060(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5048)
static void C_ccall f_5048(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5012)
static void C_ccall f_5012(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5012)
static void C_ccall f_5012r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5024)
static void C_ccall f_5024(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5036)
static void C_ccall f_5036(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5030)
static void C_ccall f_5030(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5018)
static void C_ccall f_5018(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4927)
static void C_fcall f_4927(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_4931)
static void C_ccall f_4931(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4940)
static void C_fcall f_4940(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4953)
static void C_fcall f_4953(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4988)
static void C_ccall f_4988(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4963)
static void C_fcall f_4963(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4854)
static void C_fcall f_4854(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_4858)
static void C_ccall f_4858(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4867)
static void C_fcall f_4867(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4872)
static void C_fcall f_4872(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4903)
static void C_ccall f_4903(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4882)
static void C_fcall f_4882(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4769)
static void C_fcall f_4769(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_4773)
static void C_ccall f_4773(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4782)
static void C_fcall f_4782(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4795)
static void C_fcall f_4795(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4805)
static void C_fcall f_4805(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4696)
static void C_fcall f_4696(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_4700)
static void C_ccall f_4700(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4709)
static void C_fcall f_4709(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4714)
static void C_fcall f_4714(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4724)
static void C_fcall f_4724(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4657)
static void C_ccall f_4657(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4664)
static void C_ccall f_4664(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4673)
static void C_fcall f_4673(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4694)
static void C_ccall f_4694(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4667)
static void C_ccall f_4667(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4527)
static void C_ccall f_4527(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4527)
static void C_ccall f_4527r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4539)
static void C_ccall f_4539(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4581)
static void C_ccall f_4581(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4627)
static void C_fcall f_4627(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4646)
static void C_ccall f_4646(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4586)
static void C_fcall f_4586(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4596)
static void C_ccall f_4596(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4551)
static C_word C_fcall f_4551(C_word t0,C_word t1);
C_noret_decl(f_4533)
static void C_ccall f_4533(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4397)
static void C_ccall f_4397(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4397)
static void C_ccall f_4397r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4409)
static void C_ccall f_4409(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4451)
static void C_ccall f_4451(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4497)
static void C_fcall f_4497(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4519)
static void C_ccall f_4519(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4456)
static void C_fcall f_4456(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4469)
static void C_ccall f_4469(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4421)
static C_word C_fcall f_4421(C_word t0,C_word t1);
C_noret_decl(f_4403)
static void C_ccall f_4403(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4360)
static void C_ccall f_4360(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4360)
static void C_ccall f_4360r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4372)
static void C_ccall f_4372(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4378)
static void C_fcall f_4378(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4388)
static void C_ccall f_4388(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4366)
static void C_ccall f_4366(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4319)
static void C_ccall f_4319(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4319)
static void C_ccall f_4319r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4331)
static void C_ccall f_4331(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4337)
static void C_fcall f_4337(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4347)
static void C_ccall f_4347(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4325)
static void C_ccall f_4325(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4133)
static void C_ccall f_4133(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,...) C_noret;
C_noret_decl(f_4133)
static void C_ccall f_4133r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t7) C_noret;
C_noret_decl(f_4156)
static void C_ccall f_4156(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4158)
static void C_fcall f_4158(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7) C_noret;
C_noret_decl(f_4164)
static void C_fcall f_4164(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4288)
static void C_ccall f_4288(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4174)
static void C_ccall f_4174(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4177)
static void C_ccall f_4177(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4198)
static void C_ccall f_4198(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4201)
static void C_ccall f_4201(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4221)
static void C_ccall f_4221(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4236)
static void C_ccall f_4236(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4251)
static C_word C_fcall f_4251(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_4301)
static void C_ccall f_4301(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3954)
static void C_ccall f_3954(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,...) C_noret;
C_noret_decl(f_3954)
static void C_ccall f_3954r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t7) C_noret;
C_noret_decl(f_3977)
static void C_ccall f_3977(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3979)
static void C_fcall f_3979(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7) C_noret;
C_noret_decl(f_3985)
static void C_fcall f_3985(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4102)
static void C_ccall f_4102(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3995)
static void C_ccall f_3995(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3998)
static void C_ccall f_3998(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4020)
static void C_ccall f_4020(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4023)
static void C_ccall f_4023(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4040)
static void C_ccall f_4040(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4052)
static void C_ccall f_4052(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4069)
static C_word C_fcall f_4069(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_4115)
static void C_ccall f_4115(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3908)
static void C_ccall f_3908(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_3908)
static void C_ccall f_3908r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_3920)
static void C_ccall f_3920(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3930)
static void C_fcall f_3930(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3944)
static void C_ccall f_3944(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3914)
static void C_ccall f_3914(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3866)
static void C_ccall f_3866(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_3866)
static void C_ccall f_3866r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_3878)
static void C_ccall f_3878(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3884)
static void C_fcall f_3884(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3898)
static void C_ccall f_3898(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3872)
static void C_ccall f_3872(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3833)
static void C_fcall f_3833(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3839)
static void C_fcall f_3839(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3860)
static void C_ccall f_3860(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3815)
static void C_ccall f_3815(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3815)
static void C_ccall f_3815r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3827)
static void C_ccall f_3827(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3821)
static void C_ccall f_3821(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3772)
static void C_fcall f_3772(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3779)
static void C_ccall f_3779(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3784)
static void C_fcall f_3784(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3809)
static void C_ccall f_3809(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3782)
static void C_ccall f_3782(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3754)
static void C_ccall f_3754(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3754)
static void C_ccall f_3754r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3766)
static void C_ccall f_3766(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3760)
static void C_ccall f_3760(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3736)
static void C_ccall f_3736(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3736)
static void C_ccall f_3736r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3748)
static void C_ccall f_3748(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3742)
static void C_ccall f_3742(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3714)
static void C_fcall f_3714(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3721)
static void C_fcall f_3721(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3684)
static void C_ccall f_3684(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3684)
static void C_ccall f_3684r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3697)
static void C_ccall f_3697(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3668)
static void C_ccall f_3668(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_3682)
static void C_ccall f_3682(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3628)
static void C_ccall f_3628(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3601)
static void C_ccall f_3601(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3613)
static void C_ccall f_3613(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3607)
static void C_ccall f_3607(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3508)
static void C_ccall f_3508(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3574)
static void C_ccall f_3574(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3538)
static void C_ccall f_3538(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_9341)
static void C_fcall trf_9341(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9341(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_9341(t0,t1,t2,t3);}

C_noret_decl(trf_9347)
static void C_fcall trf_9347(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9347(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9347(t0,t1,t2);}

C_noret_decl(trf_9251)
static void C_fcall trf_9251(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9251(void *dummy){
C_word t7=C_pick(0);
C_word t6=C_pick(1);
C_word t5=C_pick(2);
C_word t4=C_pick(3);
C_word t3=C_pick(4);
C_word t2=C_pick(5);
C_word t1=C_pick(6);
C_word t0=C_pick(7);
C_adjust_stack(-8);
f_9251(t0,t1,t2,t3,t4,t5,t6,t7);}

C_noret_decl(trf_8915)
static void C_fcall trf_8915(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8915(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8915(t0,t1,t2,t3);}

C_noret_decl(trf_8797)
static void C_fcall trf_8797(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8797(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_8797(t0,t1,t2,t3,t4);}

C_noret_decl(trf_8695)
static void C_fcall trf_8695(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8695(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_8695(t0,t1,t2,t3,t4);}

C_noret_decl(trf_8745)
static void C_fcall trf_8745(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8745(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8745(t0,t1);}

C_noret_decl(trf_8417)
static void C_fcall trf_8417(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8417(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_8417(t0,t1,t2,t3,t4);}

C_noret_decl(trf_8381)
static void C_fcall trf_8381(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8381(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8381(t0,t1,t2,t3);}

C_noret_decl(trf_8158)
static void C_fcall trf_8158(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8158(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8158(t0,t1,t2,t3);}

C_noret_decl(trf_8190)
static void C_fcall trf_8190(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8190(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8190(t0,t1,t2);}

C_noret_decl(trf_8093)
static void C_fcall trf_8093(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8093(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8093(t0,t1,t2);}

C_noret_decl(trf_7994)
static void C_fcall trf_7994(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7994(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_7994(t0,t1,t2,t3,t4);}

C_noret_decl(trf_8009)
static void C_fcall trf_8009(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8009(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8009(t0,t1,t2);}

C_noret_decl(trf_7926)
static void C_fcall trf_7926(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7926(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7926(t0,t1,t2);}

C_noret_decl(trf_7864)
static void C_fcall trf_7864(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7864(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7864(t0,t1,t2);}

C_noret_decl(trf_7719)
static void C_fcall trf_7719(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7719(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7719(t0,t1,t2,t3);}

C_noret_decl(trf_7680)
static void C_fcall trf_7680(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7680(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7680(t0,t1,t2,t3);}

C_noret_decl(trf_7588)
static void C_fcall trf_7588(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7588(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7588(t0,t1,t2);}

C_noret_decl(trf_7549)
static void C_fcall trf_7549(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7549(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7549(t0,t1,t2);}

C_noret_decl(trf_7453)
static void C_fcall trf_7453(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7453(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7453(t0,t1,t2);}

C_noret_decl(trf_7418)
static void C_fcall trf_7418(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7418(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7418(t0,t1,t2);}

C_noret_decl(trf_7330)
static void C_fcall trf_7330(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7330(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7330(t0,t1,t2);}

C_noret_decl(trf_7291)
static void C_fcall trf_7291(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7291(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7291(t0,t1,t2);}

C_noret_decl(trf_7195)
static void C_fcall trf_7195(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7195(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7195(t0,t1,t2);}

C_noret_decl(trf_7160)
static void C_fcall trf_7160(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7160(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7160(t0,t1,t2);}

C_noret_decl(trf_6428)
static void C_fcall trf_6428(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6428(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6428(t0,t1,t2,t3);}

C_noret_decl(trf_6434)
static void C_fcall trf_6434(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6434(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6434(t0,t1,t2);}

C_noret_decl(trf_6310)
static void C_fcall trf_6310(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6310(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6310(t0,t1);}

C_noret_decl(trf_6264)
static void C_fcall trf_6264(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6264(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6264(t0,t1);}

C_noret_decl(trf_6182)
static void C_fcall trf_6182(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6182(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_6182(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_6200)
static void C_fcall trf_6200(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6200(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6200(t0,t1,t2,t3);}

C_noret_decl(trf_6184)
static void C_fcall trf_6184(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6184(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6184(t0,t1,t2,t3);}

C_noret_decl(trf_6165)
static void C_fcall trf_6165(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6165(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6165(t0,t1);}

C_noret_decl(trf_6117)
static void C_fcall trf_6117(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6117(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6117(t0,t1);}

C_noret_decl(trf_6066)
static void C_fcall trf_6066(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6066(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6066(t0,t1);}

C_noret_decl(trf_6015)
static void C_fcall trf_6015(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6015(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6015(t0,t1);}

C_noret_decl(trf_5964)
static void C_fcall trf_5964(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5964(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5964(t0,t1);}

C_noret_decl(trf_5889)
static void C_fcall trf_5889(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5889(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5889(t0,t1);}

C_noret_decl(trf_5838)
static void C_fcall trf_5838(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5838(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5838(t0,t1);}

C_noret_decl(trf_5790)
static void C_fcall trf_5790(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5790(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5790(t0,t1);}

C_noret_decl(trf_5739)
static void C_fcall trf_5739(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5739(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5739(t0,t1);}

C_noret_decl(trf_5688)
static void C_fcall trf_5688(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5688(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5688(t0,t1);}

C_noret_decl(trf_5637)
static void C_fcall trf_5637(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5637(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5637(t0,t1);}

C_noret_decl(trf_5562)
static void C_fcall trf_5562(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5562(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5562(t0,t1);}

C_noret_decl(trf_5406)
static void C_fcall trf_5406(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5406(void *dummy){
C_word t9=C_pick(0);
C_word t8=C_pick(1);
C_word t7=C_pick(2);
C_word t6=C_pick(3);
C_word t5=C_pick(4);
C_word t4=C_pick(5);
C_word t3=C_pick(6);
C_word t2=C_pick(7);
C_word t1=C_pick(8);
C_word t0=C_pick(9);
C_adjust_stack(-10);
f_5406(t0,t1,t2,t3,t4,t5,t6,t7,t8,t9);}

C_noret_decl(trf_5441)
static void C_fcall trf_5441(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5441(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5441(t0,t1);}

C_noret_decl(trf_5344)
static void C_fcall trf_5344(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5344(void *dummy){
C_word t9=C_pick(0);
C_word t8=C_pick(1);
C_word t7=C_pick(2);
C_word t6=C_pick(3);
C_word t5=C_pick(4);
C_word t4=C_pick(5);
C_word t3=C_pick(6);
C_word t2=C_pick(7);
C_word t1=C_pick(8);
C_word t0=C_pick(9);
C_adjust_stack(-10);
f_5344(t0,t1,t2,t3,t4,t5,t6,t7,t8,t9);}

C_noret_decl(trf_5379)
static void C_fcall trf_5379(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5379(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5379(t0,t1);}

C_noret_decl(trf_4927)
static void C_fcall trf_4927(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4927(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_4927(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_4940)
static void C_fcall trf_4940(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4940(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4940(t0,t1);}

C_noret_decl(trf_4953)
static void C_fcall trf_4953(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4953(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4953(t0,t1,t2,t3);}

C_noret_decl(trf_4963)
static void C_fcall trf_4963(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4963(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4963(t0,t1);}

C_noret_decl(trf_4854)
static void C_fcall trf_4854(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4854(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_4854(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_4867)
static void C_fcall trf_4867(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4867(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4867(t0,t1);}

C_noret_decl(trf_4872)
static void C_fcall trf_4872(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4872(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4872(t0,t1,t2,t3);}

C_noret_decl(trf_4882)
static void C_fcall trf_4882(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4882(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4882(t0,t1);}

C_noret_decl(trf_4769)
static void C_fcall trf_4769(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4769(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_4769(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_4782)
static void C_fcall trf_4782(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4782(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4782(t0,t1);}

C_noret_decl(trf_4795)
static void C_fcall trf_4795(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4795(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4795(t0,t1,t2,t3);}

C_noret_decl(trf_4805)
static void C_fcall trf_4805(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4805(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4805(t0,t1);}

C_noret_decl(trf_4696)
static void C_fcall trf_4696(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4696(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_4696(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_4709)
static void C_fcall trf_4709(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4709(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4709(t0,t1);}

C_noret_decl(trf_4714)
static void C_fcall trf_4714(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4714(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4714(t0,t1,t2,t3);}

C_noret_decl(trf_4724)
static void C_fcall trf_4724(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4724(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4724(t0,t1);}

C_noret_decl(trf_4673)
static void C_fcall trf_4673(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4673(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4673(t0,t1,t2);}

C_noret_decl(trf_4627)
static void C_fcall trf_4627(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4627(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4627(t0,t1,t2);}

C_noret_decl(trf_4586)
static void C_fcall trf_4586(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4586(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4586(t0,t1,t2);}

C_noret_decl(trf_4497)
static void C_fcall trf_4497(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4497(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4497(t0,t1,t2);}

C_noret_decl(trf_4456)
static void C_fcall trf_4456(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4456(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4456(t0,t1,t2);}

C_noret_decl(trf_4378)
static void C_fcall trf_4378(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4378(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4378(t0,t1,t2);}

C_noret_decl(trf_4337)
static void C_fcall trf_4337(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4337(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4337(t0,t1,t2);}

C_noret_decl(trf_4158)
static void C_fcall trf_4158(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4158(void *dummy){
C_word t7=C_pick(0);
C_word t6=C_pick(1);
C_word t5=C_pick(2);
C_word t4=C_pick(3);
C_word t3=C_pick(4);
C_word t2=C_pick(5);
C_word t1=C_pick(6);
C_word t0=C_pick(7);
C_adjust_stack(-8);
f_4158(t0,t1,t2,t3,t4,t5,t6,t7);}

C_noret_decl(trf_4164)
static void C_fcall trf_4164(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4164(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4164(t0,t1,t2,t3);}

C_noret_decl(trf_3979)
static void C_fcall trf_3979(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3979(void *dummy){
C_word t7=C_pick(0);
C_word t6=C_pick(1);
C_word t5=C_pick(2);
C_word t4=C_pick(3);
C_word t3=C_pick(4);
C_word t2=C_pick(5);
C_word t1=C_pick(6);
C_word t0=C_pick(7);
C_adjust_stack(-8);
f_3979(t0,t1,t2,t3,t4,t5,t6,t7);}

C_noret_decl(trf_3985)
static void C_fcall trf_3985(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3985(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3985(t0,t1,t2,t3);}

C_noret_decl(trf_3930)
static void C_fcall trf_3930(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3930(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3930(t0,t1,t2,t3);}

C_noret_decl(trf_3884)
static void C_fcall trf_3884(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3884(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3884(t0,t1,t2,t3);}

C_noret_decl(trf_3833)
static void C_fcall trf_3833(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3833(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_3833(t0,t1,t2,t3,t4);}

C_noret_decl(trf_3839)
static void C_fcall trf_3839(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3839(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3839(t0,t1,t2);}

C_noret_decl(trf_3772)
static void C_fcall trf_3772(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3772(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_3772(t0,t1,t2,t3,t4);}

C_noret_decl(trf_3784)
static void C_fcall trf_3784(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3784(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3784(t0,t1,t2,t3);}

C_noret_decl(trf_3714)
static void C_fcall trf_3714(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3714(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3714(t0,t1,t2,t3);}

C_noret_decl(trf_3721)
static void C_fcall trf_3721(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3721(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3721(t0,t1);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr8)
static void C_fcall tr8(C_proc8 k) C_regparm C_noret;
C_regparm static void C_fcall tr8(C_proc8 k){
C_word t7=C_pick(0);
C_word t6=C_pick(1);
C_word t5=C_pick(2);
C_word t4=C_pick(3);
C_word t3=C_pick(4);
C_word t2=C_pick(5);
C_word t1=C_pick(6);
C_word t0=C_pick(7);
C_adjust_stack(-8);
(k)(8,t0,t1,t2,t3,t4,t5,t6,t7);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr7r)
static void C_fcall tr7r(C_proc7 k) C_regparm C_noret;
C_regparm static void C_fcall tr7r(C_proc7 k){
int n;
C_word *a,t7;
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
n=C_rest_count(0);
a=C_alloc(n*3);
t7=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5,t6,t7);}

C_noret_decl(tr5r)
static void C_fcall tr5r(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5r(C_proc5 k){
int n;
C_word *a,t5;
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
n=C_rest_count(0);
a=C_alloc(n*3);
t5=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr6r)
static void C_fcall tr6r(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6r(C_proc6 k){
int n;
C_word *a,t6;
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
n=C_rest_count(0);
a=C_alloc(n*3);
t6=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_srfi_13_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_srfi_13_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("srfi_13_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(1090)){
C_save(t1);
C_rereclaim2(1090*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,156);
lf[0]=C_h_intern(&lf[0],22,"string-parse-start+end");
lf[1]=C_h_intern(&lf[1],9,"\003syserror");
lf[2]=C_decode_literal(C_heaptop,"\376B\000\000\032Illegal substring END spec");
lf[3]=C_decode_literal(C_heaptop,"\376B\000\000 Illegal substring START/END spec");
lf[4]=C_decode_literal(C_heaptop,"\376B\000\000\034Illegal substring START spec");
lf[5]=C_h_intern(&lf[5],28,"string-parse-final-start+end");
lf[6]=C_decode_literal(C_heaptop,"\376B\000\000\034Extra arguments to procedure");
lf[7]=C_h_intern(&lf[7],18,"substring-spec-ok\077");
lf[8]=C_h_intern(&lf[8],20,"check-substring-spec");
lf[9]=C_decode_literal(C_heaptop,"\376B\000\000\027Illegal substring spec.");
lf[10]=C_h_intern(&lf[10],16,"substring/shared");
lf[12]=C_h_intern(&lf[12],13,"\003syssubstring");
lf[13]=C_h_intern(&lf[13],11,"string-copy");
lf[14]=C_h_intern(&lf[14],10,"string-map");
lf[16]=C_h_intern(&lf[16],11,"make-string");
lf[17]=C_h_intern(&lf[17],11,"string-map!");
lf[19]=C_h_intern(&lf[19],11,"string-fold");
lf[20]=C_h_intern(&lf[20],17,"string-fold-right");
lf[21]=C_h_intern(&lf[21],13,"string-unfold");
lf[22]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[23]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[25]=C_h_intern(&lf[25],3,"min");
lf[26]=C_h_intern(&lf[26],19,"string-unfold-right");
lf[27]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[28]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[29]=C_h_intern(&lf[29],15,"string-for-each");
lf[30]=C_h_intern(&lf[30],21,"string-for-each-index");
lf[31]=C_h_intern(&lf[31],12,"string-every");
lf[32]=C_h_intern(&lf[32],18,"char-set-contains\077");
lf[33]=C_decode_literal(C_heaptop,"\376B\000\000\077Second param is neither char-set, char, or predicate procedure.");
lf[34]=C_h_intern(&lf[34],9,"char-set\077");
lf[35]=C_h_intern(&lf[35],10,"string-any");
lf[36]=C_decode_literal(C_heaptop,"\376B\000\000\077Second param is neither char-set, char, or predicate procedure.");
lf[37]=C_h_intern(&lf[37],15,"string-tabulate");
lf[41]=C_h_intern(&lf[41],9,"char-ci=\077");
lf[43]=C_h_intern(&lf[43],20,"string-prefix-length");
lf[44]=C_h_intern(&lf[44],20,"string-suffix-length");
lf[45]=C_h_intern(&lf[45],23,"string-prefix-length-ci");
lf[46]=C_h_intern(&lf[46],23,"string-suffix-length-ci");
lf[47]=C_h_intern(&lf[47],14,"string-prefix\077");
lf[48]=C_h_intern(&lf[48],14,"string-suffix\077");
lf[49]=C_h_intern(&lf[49],17,"string-prefix-ci\077");
lf[50]=C_h_intern(&lf[50],17,"string-suffix-ci\077");
lf[53]=C_h_intern(&lf[53],9,"char-ci<\077");
lf[54]=C_h_intern(&lf[54],14,"string-compare");
lf[55]=C_h_intern(&lf[55],17,"string-compare-ci");
lf[56]=C_h_intern(&lf[56],7,"string=");
lf[57]=C_h_intern(&lf[57],6,"values");
lf[58]=C_h_intern(&lf[58],8,"string<>");
lf[59]=C_h_intern(&lf[59],7,"string<");
lf[60]=C_h_intern(&lf[60],7,"string>");
lf[61]=C_h_intern(&lf[61],8,"string<=");
lf[62]=C_h_intern(&lf[62],8,"string>=");
lf[63]=C_h_intern(&lf[63],10,"string-ci=");
lf[64]=C_h_intern(&lf[64],11,"string-ci<>");
lf[65]=C_h_intern(&lf[65],10,"string-ci<");
lf[66]=C_h_intern(&lf[66],10,"string-ci>");
lf[67]=C_h_intern(&lf[67],11,"string-ci<=");
lf[68]=C_h_intern(&lf[68],11,"string-ci>=");
lf[70]=C_h_intern(&lf[70],6,"modulo");
lf[71]=C_h_intern(&lf[71],11,"string-hash");
lf[72]=C_h_intern(&lf[72],13,"char->integer");
lf[73]=C_h_intern(&lf[73],14,"string-hash-ci");
lf[74]=C_h_intern(&lf[74],13,"string-upcase");
lf[75]=C_h_intern(&lf[75],11,"char-upcase");
lf[76]=C_h_intern(&lf[76],14,"string-upcase!");
lf[77]=C_h_intern(&lf[77],15,"string-downcase");
lf[78]=C_h_intern(&lf[78],13,"char-downcase");
lf[79]=C_h_intern(&lf[79],16,"string-downcase!");
lf[81]=C_h_intern(&lf[81],11,"string-skip");
lf[82]=C_h_intern(&lf[82],12,"string-index");
lf[83]=C_h_intern(&lf[83],17,"string-titlecase!");
lf[84]=C_h_intern(&lf[84],16,"string-titlecase");
lf[85]=C_h_intern(&lf[85],11,"string-take");
lf[86]=C_h_intern(&lf[86],15,"\003syscheck-range");
lf[87]=C_h_intern(&lf[87],17,"string-take-right");
lf[88]=C_h_intern(&lf[88],11,"string-drop");
lf[89]=C_h_intern(&lf[89],17,"string-drop-right");
lf[90]=C_h_intern(&lf[90],11,"string-trim");
lf[91]=C_h_intern(&lf[91],19,"char-set:whitespace");
lf[92]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[93]=C_h_intern(&lf[93],17,"string-trim-right");
lf[94]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[95]=C_h_intern(&lf[95],17,"string-skip-right");
lf[96]=C_h_intern(&lf[96],16,"string-trim-both");
lf[97]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[98]=C_h_intern(&lf[98],16,"string-pad-right");
lf[99]=C_h_intern(&lf[99],10,"string-pad");
lf[100]=C_h_intern(&lf[100],13,"string-delete");
lf[101]=C_h_intern(&lf[101],8,"char-set");
lf[102]=C_decode_literal(C_heaptop,"\376B\000\0006string-delete criteria not predicate, char or char-set");
lf[103]=C_h_intern(&lf[103],13,"string-filter");
lf[104]=C_decode_literal(C_heaptop,"\376B\000\0006string-delete criteria not predicate, char or char-set");
lf[105]=C_decode_literal(C_heaptop,"\376B\000\000\077Second param is neither char-set, char, or predicate procedure.");
lf[106]=C_h_intern(&lf[106],18,"string-index-right");
lf[107]=C_decode_literal(C_heaptop,"\376B\000\000\077Second param is neither char-set, char, or predicate procedure.");
lf[108]=C_decode_literal(C_heaptop,"\376B\000\000\077Second param is neither char-set, char, or predicate procedure.");
lf[109]=C_decode_literal(C_heaptop,"\376B\000\000+CRITERIA param is neither char-set or char.");
lf[110]=C_h_intern(&lf[110],12,"string-count");
lf[111]=C_decode_literal(C_heaptop,"\376B\000\000+CRITERIA param is neither char-set or char.");
lf[112]=C_h_intern(&lf[112],12,"string-fill!");
lf[113]=C_h_intern(&lf[113],12,"string-copy!");
lf[114]=C_h_intern(&lf[114],15,"string-contains");
lf[115]=C_h_intern(&lf[115],18,"string-contains-ci");
lf[116]=C_h_intern(&lf[116],23,"make-kmp-restart-vector");
lf[117]=C_h_intern(&lf[117],6,"char=\077");
lf[118]=C_h_intern(&lf[118],11,"make-vector");
lf[119]=C_h_intern(&lf[119],8,"kmp-step");
lf[120]=C_h_intern(&lf[120],25,"string-kmp-partial-search");
lf[121]=C_h_intern(&lf[121],12,"string-null\077");
lf[122]=C_h_intern(&lf[122],14,"string-reverse");
lf[123]=C_h_intern(&lf[123],15,"string-reverse!");
lf[124]=C_h_intern(&lf[124],12,"string->list");
lf[125]=C_h_intern(&lf[125],20,"string-append/shared");
lf[126]=C_h_intern(&lf[126],25,"string-concatenate/shared");
lf[127]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[128]=C_h_intern(&lf[128],18,"string-concatenate");
lf[129]=C_h_intern(&lf[129],26,"string-concatenate-reverse");
lf[130]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[132]=C_h_intern(&lf[132],33,"string-concatenate-reverse/shared");
lf[133]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[134]=C_h_intern(&lf[134],14,"string-replace");
lf[135]=C_h_intern(&lf[135],15,"string-tokenize");
lf[136]=C_h_intern(&lf[136],16,"char-set:graphic");
lf[137]=C_h_intern(&lf[137],10,"xsubstring");
lf[138]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[139]=C_decode_literal(C_heaptop,"\376B\000\000\042Cannot replicate empty (sub)string");
lf[142]=C_h_intern(&lf[142],13,"string-xcopy!");
lf[143]=C_decode_literal(C_heaptop,"\376B\000\000\042Cannot replicate empty (sub)string");
lf[144]=C_h_intern(&lf[144],11,"string-join");
lf[145]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[146]=C_h_intern(&lf[146],5,"infix");
lf[147]=C_h_intern(&lf[147],12,"strict-infix");
lf[148]=C_h_intern(&lf[148],6,"prefix");
lf[149]=C_h_intern(&lf[149],6,"suffix");
lf[150]=C_decode_literal(C_heaptop,"\376B\000\000\024Illegal join grammar");
lf[151]=C_decode_literal(C_heaptop,"\376B\000\0006Empty list cannot be joined with STRICT-INFIX grammar.");
lf[152]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[153]=C_decode_literal(C_heaptop,"\376B\000\000\033STRINGS parameter not list.");
lf[154]=C_h_intern(&lf[154],17,"register-feature!");
lf[155]=C_h_intern(&lf[155],7,"srfi-13");
C_register_lf2(lf,156,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3503,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_srfi_14_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k3501 */
static void C_ccall f_3503(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3503,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3506,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-13.scm: 49   register-feature! */
t3=*((C_word*)lf[154]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[155]);}

/* k3504 in k3501 */
static void C_ccall f_3506(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word t98;
C_word t99;
C_word t100;
C_word t101;
C_word ab[196],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3506,2,t0,t1);}
t2=C_mutate((C_word*)lf[0]+1 /* (set! string-parse-start+end ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3508,tmp=(C_word)a,a+=2,tmp));
t3=C_mutate((C_word*)lf[5]+1 /* (set! string-parse-final-start+end ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3601,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate((C_word*)lf[7]+1 /* (set! substring-spec-ok? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3628,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[8]+1 /* (set! check-substring-spec ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3668,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[10]+1 /* (set! substring/shared ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3684,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate(&lf[11] /* (set! %substring/shared ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3714,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate((C_word*)lf[13]+1 /* (set! string-copy ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3736,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate((C_word*)lf[14]+1 /* (set! string-map ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3754,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate(&lf[15] /* (set! %string-map ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3772,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate((C_word*)lf[17]+1 /* (set! string-map! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3815,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate(&lf[18] /* (set! %string-map! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3833,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate((C_word*)lf[19]+1 /* (set! string-fold ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3866,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate((C_word*)lf[20]+1 /* (set! string-fold-right ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3908,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate((C_word*)lf[21]+1 /* (set! string-unfold ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3954,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate((C_word*)lf[26]+1 /* (set! string-unfold-right ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4133,tmp=(C_word)a,a+=2,tmp));
t17=C_mutate((C_word*)lf[29]+1 /* (set! string-for-each ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4319,tmp=(C_word)a,a+=2,tmp));
t18=C_mutate((C_word*)lf[30]+1 /* (set! string-for-each-index ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4360,tmp=(C_word)a,a+=2,tmp));
t19=C_mutate((C_word*)lf[31]+1 /* (set! string-every ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4397,tmp=(C_word)a,a+=2,tmp));
t20=C_mutate((C_word*)lf[35]+1 /* (set! string-any ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4527,tmp=(C_word)a,a+=2,tmp));
t21=C_mutate((C_word*)lf[37]+1 /* (set! string-tabulate ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4657,tmp=(C_word)a,a+=2,tmp));
t22=C_mutate(&lf[38] /* (set! %string-prefix-length ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4696,tmp=(C_word)a,a+=2,tmp));
t23=C_mutate(&lf[39] /* (set! %string-suffix-length ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4769,tmp=(C_word)a,a+=2,tmp));
t24=C_mutate(&lf[40] /* (set! %string-prefix-length-ci ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4854,tmp=(C_word)a,a+=2,tmp));
t25=C_mutate(&lf[42] /* (set! %string-suffix-length-ci ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4927,tmp=(C_word)a,a+=2,tmp));
t26=C_mutate((C_word*)lf[43]+1 /* (set! string-prefix-length ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5012,tmp=(C_word)a,a+=2,tmp));
t27=C_mutate((C_word*)lf[44]+1 /* (set! string-suffix-length ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5042,tmp=(C_word)a,a+=2,tmp));
t28=C_mutate((C_word*)lf[45]+1 /* (set! string-prefix-length-ci ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5072,tmp=(C_word)a,a+=2,tmp));
t29=C_mutate((C_word*)lf[46]+1 /* (set! string-suffix-length-ci ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5102,tmp=(C_word)a,a+=2,tmp));
t30=C_mutate((C_word*)lf[47]+1 /* (set! string-prefix? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5132,tmp=(C_word)a,a+=2,tmp));
t31=C_mutate((C_word*)lf[48]+1 /* (set! string-suffix? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5162,tmp=(C_word)a,a+=2,tmp));
t32=C_mutate((C_word*)lf[49]+1 /* (set! string-prefix-ci? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5192,tmp=(C_word)a,a+=2,tmp));
t33=C_mutate((C_word*)lf[50]+1 /* (set! string-suffix-ci? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5222,tmp=(C_word)a,a+=2,tmp));
t34=C_mutate(&lf[51] /* (set! %string-compare ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5344,tmp=(C_word)a,a+=2,tmp));
t35=C_mutate(&lf[52] /* (set! %string-compare-ci ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5406,tmp=(C_word)a,a+=2,tmp));
t36=C_mutate((C_word*)lf[54]+1 /* (set! string-compare ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5468,tmp=(C_word)a,a+=2,tmp));
t37=C_mutate((C_word*)lf[55]+1 /* (set! string-compare-ci ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5498,tmp=(C_word)a,a+=2,tmp));
t38=C_mutate((C_word*)lf[56]+1 /* (set! string= ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5528,tmp=(C_word)a,a+=2,tmp));
t39=C_mutate((C_word*)lf[58]+1 /* (set! string<> ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5590,tmp=(C_word)a,a+=2,tmp));
t40=C_mutate((C_word*)lf[59]+1 /* (set! string< ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5657,tmp=(C_word)a,a+=2,tmp));
t41=C_mutate((C_word*)lf[60]+1 /* (set! string> ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5708,tmp=(C_word)a,a+=2,tmp));
t42=C_mutate((C_word*)lf[61]+1 /* (set! string<= ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5759,tmp=(C_word)a,a+=2,tmp));
t43=C_mutate((C_word*)lf[62]+1 /* (set! string>= ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5807,tmp=(C_word)a,a+=2,tmp));
t44=C_mutate((C_word*)lf[63]+1 /* (set! string-ci= ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5855,tmp=(C_word)a,a+=2,tmp));
t45=C_mutate((C_word*)lf[64]+1 /* (set! string-ci<> ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5917,tmp=(C_word)a,a+=2,tmp));
t46=C_mutate((C_word*)lf[65]+1 /* (set! string-ci< ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5984,tmp=(C_word)a,a+=2,tmp));
t47=C_mutate((C_word*)lf[66]+1 /* (set! string-ci> ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6035,tmp=(C_word)a,a+=2,tmp));
t48=C_mutate((C_word*)lf[67]+1 /* (set! string-ci<= ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6086,tmp=(C_word)a,a+=2,tmp));
t49=C_mutate((C_word*)lf[68]+1 /* (set! string-ci>= ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6134,tmp=(C_word)a,a+=2,tmp));
t50=C_mutate(&lf[69] /* (set! %string-hash ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6182,tmp=(C_word)a,a+=2,tmp));
t51=C_mutate((C_word*)lf[71]+1 /* (set! string-hash ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6254,tmp=(C_word)a,a+=2,tmp));
t52=C_mutate((C_word*)lf[73]+1 /* (set! string-hash-ci ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6300,tmp=(C_word)a,a+=2,tmp));
t53=C_mutate((C_word*)lf[74]+1 /* (set! string-upcase ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6356,tmp=(C_word)a,a+=2,tmp));
t54=C_mutate((C_word*)lf[76]+1 /* (set! string-upcase! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6374,tmp=(C_word)a,a+=2,tmp));
t55=C_mutate((C_word*)lf[77]+1 /* (set! string-downcase ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6392,tmp=(C_word)a,a+=2,tmp));
t56=C_mutate((C_word*)lf[79]+1 /* (set! string-downcase! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6410,tmp=(C_word)a,a+=2,tmp));
t57=C_mutate(&lf[80] /* (set! %string-titlecase! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6428,tmp=(C_word)a,a+=2,tmp));
t58=C_mutate((C_word*)lf[83]+1 /* (set! string-titlecase! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6487,tmp=(C_word)a,a+=2,tmp));
t59=C_mutate((C_word*)lf[84]+1 /* (set! string-titlecase ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6505,tmp=(C_word)a,a+=2,tmp));
t60=C_mutate((C_word*)lf[85]+1 /* (set! string-take ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6530,tmp=(C_word)a,a+=2,tmp));
t61=C_mutate((C_word*)lf[87]+1 /* (set! string-take-right ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6550,tmp=(C_word)a,a+=2,tmp));
t62=C_mutate((C_word*)lf[88]+1 /* (set! string-drop ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6577,tmp=(C_word)a,a+=2,tmp));
t63=C_mutate((C_word*)lf[89]+1 /* (set! string-drop-right ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6600,tmp=(C_word)a,a+=2,tmp));
t64=C_mutate((C_word*)lf[90]+1 /* (set! string-trim ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6627,tmp=(C_word)a,a+=2,tmp));
t65=C_mutate((C_word*)lf[93]+1 /* (set! string-trim-right ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6669,tmp=(C_word)a,a+=2,tmp));
t66=C_mutate((C_word*)lf[96]+1 /* (set! string-trim-both ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6715,tmp=(C_word)a,a+=2,tmp));
t67=C_mutate((C_word*)lf[98]+1 /* (set! string-pad-right ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6765,tmp=(C_word)a,a+=2,tmp));
t68=C_mutate((C_word*)lf[99]+1 /* (set! string-pad ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6823,tmp=(C_word)a,a+=2,tmp));
t69=C_mutate((C_word*)lf[100]+1 /* (set! string-delete ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6885,tmp=(C_word)a,a+=2,tmp));
t70=C_mutate((C_word*)lf[103]+1 /* (set! string-filter ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6993,tmp=(C_word)a,a+=2,tmp));
t71=C_mutate((C_word*)lf[82]+1 /* (set! string-index ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7101,tmp=(C_word)a,a+=2,tmp));
t72=C_mutate((C_word*)lf[106]+1 /* (set! string-index-right ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7224,tmp=(C_word)a,a+=2,tmp));
t73=C_mutate((C_word*)lf[81]+1 /* (set! string-skip ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7359,tmp=(C_word)a,a+=2,tmp));
t74=C_mutate((C_word*)lf[95]+1 /* (set! string-skip-right ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7482,tmp=(C_word)a,a+=2,tmp));
t75=C_mutate((C_word*)lf[110]+1 /* (set! string-count ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7617,tmp=(C_word)a,a+=2,tmp));
t76=C_mutate((C_word*)lf[112]+1 /* (set! string-fill! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7752,tmp=(C_word)a,a+=2,tmp));
t77=C_mutate((C_word*)lf[113]+1 /* (set! string-copy! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7793,tmp=(C_word)a,a+=2,tmp));
t78=C_mutate(&lf[24] /* (set! %string-copy! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7825,tmp=(C_word)a,a+=2,tmp));
t79=C_mutate((C_word*)lf[114]+1 /* (set! string-contains ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7828,tmp=(C_word)a,a+=2,tmp));
t80=C_mutate((C_word*)lf[115]+1 /* (set! string-contains-ci ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7890,tmp=(C_word)a,a+=2,tmp));
t81=C_mutate((C_word*)lf[116]+1 /* (set! make-kmp-restart-vector ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7952,tmp=(C_word)a,a+=2,tmp));
t82=C_mutate((C_word*)lf[119]+1 /* (set! kmp-step ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8087,tmp=(C_word)a,a+=2,tmp));
t83=C_mutate((C_word*)lf[120]+1 /* (set! string-kmp-partial-search ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8125,tmp=(C_word)a,a+=2,tmp));
t84=C_mutate((C_word*)lf[121]+1 /* (set! string-null? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8246,tmp=(C_word)a,a+=2,tmp));
t85=C_mutate((C_word*)lf[122]+1 /* (set! string-reverse ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8249,tmp=(C_word)a,a+=2,tmp));
t86=C_mutate((C_word*)lf[123]+1 /* (set! string-reverse! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8304,tmp=(C_word)a,a+=2,tmp));
t87=C_mutate((C_word*)lf[124]+1 /* (set! string->list ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8359,tmp=(C_word)a,a+=2,tmp));
t88=C_mutate((C_word*)lf[125]+1 /* (set! string-append/shared ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8405,tmp=(C_word)a,a+=2,tmp));
t89=C_mutate((C_word*)lf[126]+1 /* (set! string-concatenate/shared ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8411,tmp=(C_word)a,a+=2,tmp));
t90=C_mutate((C_word*)lf[128]+1 /* (set! string-concatenate ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8513,tmp=(C_word)a,a+=2,tmp));
t91=C_mutate((C_word*)lf[129]+1 /* (set! string-concatenate-reverse ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8586,tmp=(C_word)a,a+=2,tmp));
t92=C_mutate((C_word*)lf[132]+1 /* (set! string-concatenate-reverse/shared ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8671,tmp=(C_word)a,a+=2,tmp));
t93=C_mutate(&lf[131] /* (set! %finish-string-concatenate-reverse ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8797,tmp=(C_word)a,a+=2,tmp));
t94=C_mutate((C_word*)lf[134]+1 /* (set! string-replace ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8840,tmp=(C_word)a,a+=2,tmp));
t95=C_mutate((C_word*)lf[135]+1 /* (set! string-tokenize ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8891,tmp=(C_word)a,a+=2,tmp));
t96=C_mutate((C_word*)lf[137]+1 /* (set! xsubstring ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8973,tmp=(C_word)a,a+=2,tmp));
t97=C_mutate(&lf[141] /* (set! string-fill! ...) */,*((C_word*)lf[112]+1));
t98=C_mutate((C_word*)lf[142]+1 /* (set! string-xcopy! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9111,tmp=(C_word)a,a+=2,tmp));
t99=C_mutate(&lf[140] /* (set! %multispan-repcopy! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9251,tmp=(C_word)a,a+=2,tmp));
t100=C_mutate((C_word*)lf[144]+1 /* (set! string-join ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9324,tmp=(C_word)a,a+=2,tmp));
t101=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t101+1)))(2,t101,C_SCHEME_UNDEFINED);}

/* string-join in k3504 in k3501 */
static void C_ccall f_9324(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+13)){
C_save_and_reclaim((void*)tr3r,(void*)f_9324r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_9324r(t0,t1,t2,t3);}}

static void C_ccall f_9324r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word *a=C_alloc(13);
t4=(C_word)C_i_nullp(t3);
t5=(C_truep(t4)?lf[145]:(C_word)C_u_i_car(t3));
t6=(C_word)C_i_nullp(t3);
t7=(C_truep(t6)?C_SCHEME_END_OF_LIST:(C_word)C_slot(t3,C_fix(1)));
t8=(C_word)C_i_nullp(t7);
t9=(C_truep(t8)?lf[146]:(C_word)C_u_i_car(t7));
t10=(C_word)C_i_nullp(t7);
t11=(C_truep(t10)?C_SCHEME_END_OF_LIST:(C_word)C_slot(t7,C_fix(1)));
t12=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9341,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9386,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t14=(C_word)C_eqp(t9,lf[146]);
t15=(C_truep(t14)?t14:(C_word)C_eqp(t9,lf[147]));
if(C_truep(t15)){
t16=(C_word)C_u_i_car(t2);
t17=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9403,a[2]=t16,a[3]=t13,tmp=(C_word)a,a+=4,tmp);
t18=(C_word)C_slot(t2,C_fix(1));
/* srfi-13.scm: 1932 buildit */
t19=t12;
f_9341(t19,t17,t18,C_SCHEME_END_OF_LIST);}
else{
t16=(C_word)C_eqp(t9,lf[148]);
if(C_truep(t16)){
/* srfi-13.scm: 1934 buildit */
t17=t12;
f_9341(t17,t13,t2,C_SCHEME_END_OF_LIST);}
else{
t17=(C_word)C_eqp(t9,lf[149]);
if(C_truep(t17)){
t18=(C_word)C_u_i_car(t2);
t19=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9433,a[2]=t18,a[3]=t13,tmp=(C_word)a,a+=4,tmp);
t20=(C_word)C_slot(t2,C_fix(1));
t21=(C_word)C_a_i_list(&a,1,t5);
/* srfi-13.scm: 1937 buildit */
t22=t12;
f_9341(t22,t19,t20,t21);}
else{
/* srfi-13.scm: 1939 ##sys#error */
t18=*((C_word*)lf[1]+1);
((C_proc6)(void*)(*((C_word*)t18+1)))(6,t18,t13,lf[144],lf[150],t9,*((C_word*)lf[144]+1));}}}}
else{
if(C_truep((C_word)C_i_nullp(t2))){
t13=(C_word)C_eqp(t9,lf[147]);
if(C_truep(t13)){
/* srfi-13.scm: 1948 ##sys#error */
t14=*((C_word*)lf[1]+1);
((C_proc5)(void*)(*((C_word*)t14+1)))(5,t14,t1,lf[144],lf[151],*((C_word*)lf[144]+1));}
else{
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,lf[152]);}}
else{
/* srfi-13.scm: 1943 ##sys#error */
t13=*((C_word*)lf[1]+1);
((C_proc6)(void*)(*((C_word*)t13+1)))(6,t13,t1,lf[144],lf[153],t2,*((C_word*)lf[144]+1));}}}

/* k9431 in string-join in k3504 in k3501 */
static void C_ccall f_9433(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9433,2,t0,t1);}
t2=((C_word*)t0)[3];
f_9386(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k9401 in string-join in k3504 in k3501 */
static void C_ccall f_9403(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9403,2,t0,t1);}
t2=((C_word*)t0)[3];
f_9386(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k9384 in string-join in k3504 in k3501 */
static void C_ccall f_9386(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-13.scm: 1928 string-concatenate */
t2=*((C_word*)lf[128]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* buildit in string-join in k3504 in k3501 */
static void C_fcall f_9341(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9341,NULL,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9347,a[2]=t3,a[3]=t5,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_9347(t7,t1,t2);}

/* recur in buildit in string-join in k3504 in k3501 */
static void C_fcall f_9347(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
loop:
a=C_alloc(5);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_9347,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_u_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9369,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_slot(t2,C_fix(1));
/* srfi-13.scm: 1924 recur */
t7=t4;
t8=t5;
t1=t7;
t2=t8;
goto loop;}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[2]);}}

/* k9367 in recur in buildit in string-join in k3504 in k3501 */
static void C_ccall f_9369(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9369,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* %multispan-repcopy! in k3504 in k3501 */
static void C_fcall f_9251(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word t11;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9251,NULL,8,t1,t2,t3,t4,t5,t6,t7,t8);}
t9=(C_word)C_u_fixnum_difference(t8,t7);
t10=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_9322,a[2]=t1,a[3]=t9,a[4]=t8,a[5]=t4,a[6]=t3,a[7]=t2,a[8]=t5,a[9]=t6,a[10]=t7,tmp=(C_word)a,a+=11,tmp);
/* srfi-13.scm: 1883 modulo */
t11=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t10,t5,t9);}

/* k9320 in %multispan-repcopy! in k3504 in k3501 */
static void C_ccall f_9322(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9322,2,t0,t1);}
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[10],t1);
t3=(C_word)C_u_fixnum_difference(((C_word*)t0)[9],((C_word*)t0)[8]);
t4=f_7825(((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],t2,((C_word*)t0)[4]);
t5=(C_word)C_u_fixnum_difference(((C_word*)t0)[4],t2);
t6=(C_word)C_u_fixnum_difference(t3,t5);
t7=(C_word)C_fixnum_divide(t6,((C_word*)t0)[3]);
t8=(C_word)C_u_fixnum_plus(((C_word*)t0)[6],t5);
t9=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9282,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[10],a[7]=t3,a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
t10=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,f_9282(t9,t8,t7));}

/* doloop3324 in k9320 in %multispan-repcopy! in k3504 in k3501 */
static C_word C_fcall f_9282(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
loop:
t3=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t3)){
t4=(C_word)C_u_fixnum_difference(t1,((C_word*)t0)[8]);
t5=(C_word)C_u_fixnum_difference(((C_word*)t0)[7],t4);
t6=(C_word)C_u_fixnum_plus(((C_word*)t0)[6],t5);
return(f_7825(((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[6],t6));}
else{
t4=f_7825(((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[6],((C_word*)t0)[3]);
t5=(C_word)C_u_fixnum_plus(t1,((C_word*)t0)[2]);
t6=(C_word)C_u_fixnum_difference(t2,C_fix(1));
t11=t5;
t12=t6;
t1=t11;
t2=t12;
goto loop;}}

/* string-xcopy! in k3504 in k3501 */
static void C_ccall f_9111(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,...){
C_word tmp;
C_word t6;
va_list v;
C_word *a,c2=c;
C_save_rest(t5,c2,6);
if(!C_demand(c*C_SIZEOF_PAIR+11)){
C_save_and_reclaim((void*)tr6r,(void*)f_9111r,6,t0,t1,t2,t3,t4,t5);}
else{
a=C_alloc((c-6)*3);
t6=C_restore_rest(a,C_rest_count(0));
f_9111r(t0,t1,t2,t3,t4,t5,t6);}}

static void C_ccall f_9111r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(11);
t7=(C_word)C_i_check_exact_2(t5,lf[142]);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9120,a[2]=t5,a[3]=t4,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9164,a[2]=t4,a[3]=t2,a[4]=t3,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t8,t9);}

/* a9163 in string-xcopy! in k3504 in k3501 */
static void C_ccall f_9164(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9164,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_u_fixnum_difference(t2,((C_word*)t0)[5]);
t6=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],t5);
t7=(C_word)C_u_fixnum_difference(t4,t3);
t8=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_9177,a[2]=t6,a[3]=t4,a[4]=t3,a[5]=t2,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[2],a[8]=((C_word*)t0)[4],a[9]=((C_word*)t0)[3],a[10]=t7,a[11]=t1,a[12]=t5,tmp=(C_word)a,a+=13,tmp);
/* srfi-13.scm: 1861 check-substring-spec */
t9=*((C_word*)lf[8]+1);
((C_proc6)(void*)(*((C_word*)t9+1)))(6,t9,t8,*((C_word*)lf[142]+1),((C_word*)t0)[3],((C_word*)t0)[4],t6);}

/* k9175 in a9163 in string-xcopy! in k3504 in k3501 */
static void C_ccall f_9177(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9177,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[12],C_fix(0));
if(C_truep(t2)){
t3=((C_word*)t0)[11];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[10],C_fix(0));
if(C_truep(t3)){
/* srfi-13.scm: 1863 ##sys#error */
t4=*((C_word*)lf[1]+1);
((C_proc12)(void*)(*((C_word*)t4+1)))(12,t4,((C_word*)t0)[11],lf[142],lf[143],*((C_word*)lf[142]+1),((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t4=(C_word)C_eqp(C_fix(1),((C_word*)t0)[10]);
if(C_truep(t4)){
t5=(C_word)C_subchar(((C_word*)t0)[7],((C_word*)t0)[4]);
/* srfi-13.scm: 1868 ##srfi13#string-fill! */
t6=lf[141];
((C_proc6)(void*)(*((C_word*)t6+1)))(6,t6,((C_word*)t0)[11],((C_word*)t0)[9],t5,((C_word*)t0)[8],((C_word*)t0)[2]);}
else{
t5=(C_word)C_fixnum_divide(((C_word*)t0)[6],((C_word*)t0)[10]);
t6=(C_word)C_fixnum_divide(((C_word*)t0)[5],((C_word*)t0)[10]);
t7=(C_word)C_eqp(t5,t6);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9230,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[4],tmp=(C_word)a,a+=9,tmp);
/* srfi-13.scm: 1873 modulo */
t9=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t8,((C_word*)t0)[6],((C_word*)t0)[10]);}
else{
/* srfi-13.scm: 1877 %multispan-repcopy! */
f_9251(((C_word*)t0)[11],((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);}}}}}

/* k9228 in k9175 in a9163 in string-xcopy! in k3504 in k3501 */
static void C_ccall f_9230(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9230,2,t0,t1);}
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[8],t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9226,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* srfi-13.scm: 1874 modulo */
t4=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9224 in k9228 in k9175 in a9163 in string-xcopy! in k3504 in k3501 */
static void C_ccall f_9226(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[7],t1);
/* srfi-13.scm: 1872 %string-copy! */
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,f_7825(((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2));}

/* a9119 in string-xcopy! in k3504 in k3501 */
static void C_ccall f_9120(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9120,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9132,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9142,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t2,t3);}
else{
t2=(C_word)C_fix((C_word)C_header_size(((C_word*)t0)[3]));
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[2],t2);
/* srfi-13.scm: 1856 values */
C_values(5,0,t1,t3,C_fix(0),t2);}}

/* a9141 in a9119 in string-xcopy! in k3504 in k3501 */
static void C_ccall f_9142(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9142,4,t0,t1,t2,t3);}
t4=(C_word)C_u_i_car(((C_word*)t0)[2]);
t5=(C_word)C_i_check_exact_2(t4,lf[142]);
/* srfi-13.scm: 1854 values */
C_values(5,0,t1,t4,t2,t3);}

/* a9131 in a9119 in string-xcopy! in k3504 in k3501 */
static void C_ccall f_9132(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9132,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* string-parse-final-start+end */
t3=*((C_word*)lf[5]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t1,*((C_word*)lf[142]+1),((C_word*)t0)[2],t2);}

/* xsubstring in k3504 in k3501 */
static void C_ccall f_8973(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr4r,(void*)f_8973r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_8973r(t0,t1,t2,t3,t4);}}

static void C_ccall f_8973r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(9);
t5=(C_word)C_i_check_exact_2(t3,lf[137]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8982,a[2]=t3,a[3]=t2,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9026,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t6,t7);}

/* a9025 in xsubstring in k3504 in k3501 */
static void C_ccall f_9026(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9026,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_u_fixnum_difference(t4,t3);
t6=(C_word)C_u_fixnum_difference(t2,((C_word*)t0)[3]);
t7=(C_word)C_eqp(t6,C_fix(0));
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,lf[138]);}
else{
t8=(C_word)C_eqp(t5,C_fix(0));
if(C_truep(t8)){
/* srfi-13.scm: 1817 ##sys#error */
t9=*((C_word*)lf[1]+1);
((C_proc10)(void*)(*((C_word*)t9+1)))(10,t9,t1,lf[137],lf[139],*((C_word*)lf[137]+1),((C_word*)t0)[2],((C_word*)t0)[3],t2,t3,t4);}
else{
t9=(C_word)C_eqp(C_fix(1),t5);
if(C_truep(t9)){
t10=(C_word)C_subchar(((C_word*)t0)[2],t3);
/* srfi-13.scm: 1821 make-string */
t11=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t1,t6,t10);}
else{
t10=(C_word)C_fixnum_divide(((C_word*)t0)[3],t5);
t11=(C_word)C_fixnum_divide(t2,t5);
t12=(C_word)C_eqp(t10,t11);
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9086,a[2]=t5,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=t1,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* srfi-13.scm: 1825 modulo */
t14=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t14+1)))(4,t14,t13,((C_word*)t0)[3],t5);}
else{
t13=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9089,a[2]=t4,a[3]=t3,a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[2],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* srfi-13.scm: 1829 make-string */
t14=*((C_word*)lf[16]+1);
((C_proc3)(void*)(*((C_word*)t14+1)))(3,t14,t13,t6);}}}}}

/* k9087 in a9025 in xsubstring in k3504 in k3501 */
static void C_ccall f_9089(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9089,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9092,a[2]=t1,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* srfi-13.scm: 1830 %multispan-repcopy! */
f_9251(t2,t1,C_fix(0),((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9090 in k9087 in a9025 in xsubstring in k3504 in k3501 */
static void C_ccall f_9092(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k9084 in a9025 in xsubstring in k3504 in k3501 */
static void C_ccall f_9086(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9086,2,t0,t1);}
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[6],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9082,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* srfi-13.scm: 1826 modulo */
t4=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9080 in k9084 in a9025 in xsubstring in k3504 in k3501 */
static void C_ccall f_9082(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[5],t1);
/* srfi-13.scm: 1825 ##sys#substring */
t3=*((C_word*)lf[12]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* a8981 in xsubstring in k3504 in k3501 */
static void C_ccall f_8982(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8982,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8994,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9004,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t2,t3);}
else{
t2=(C_word)C_fix((C_word)C_header_size(((C_word*)t0)[3]));
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[2],t2);
/* srfi-13.scm: 1813 values */
C_values(5,0,t1,t3,C_fix(0),t2);}}

/* a9003 in a8981 in xsubstring in k3504 in k3501 */
static void C_ccall f_9004(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9004,4,t0,t1,t2,t3);}
t4=(C_word)C_u_i_car(((C_word*)t0)[2]);
t5=(C_word)C_i_check_exact_2(t4,lf[137]);
/* srfi-13.scm: 1810 values */
C_values(5,0,t1,t4,t2,t3);}

/* a8993 in a8981 in xsubstring in k3504 in k3501 */
static void C_ccall f_8994(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8994,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* string-parse-final-start+end */
t3=*((C_word*)lf[5]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t1,*((C_word*)lf[137]+1),((C_word*)t0)[2],t2);}

/* string-tokenize in k3504 in k3501 */
static void C_ccall f_8891(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3r,(void*)f_8891r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_8891r(t0,t1,t2,t3);}}

static void C_ccall f_8891r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(8);
t4=(C_word)C_i_nullp(t3);
t5=(C_truep(t4)?*((C_word*)lf[136]+1):(C_word)C_u_i_car(t3));
t6=(C_word)C_i_nullp(t3);
t7=(C_truep(t6)?C_SCHEME_END_OF_LIST:(C_word)C_slot(t3,C_fix(1)));
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8903,a[2]=t7,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8909,a[2]=t5,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t8,t9);}

/* a8908 in string-tokenize in k3504 in k3501 */
static void C_ccall f_8909(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8909,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8915,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t5,tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_8915(t7,t1,t3,C_SCHEME_END_OF_LIST);}

/* lp in a8908 in string-tokenize in k3504 in k3501 */
static void C_fcall f_8915(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8915,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8919,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=t3,tmp=(C_word)a,a+=8,tmp);
t5=((C_word*)t0)[3];
t6=t2;
if(C_truep((C_word)C_fixnum_lessp(t5,t6))){
/* srfi-13.scm: 1758 string-index-right */
t7=*((C_word*)lf[106]+1);
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t4,((C_word*)t0)[4],((C_word*)t0)[2],((C_word*)t0)[3],t2);}
else{
t7=t4;
f_8919(2,t7,C_SCHEME_FALSE);}}

/* k8917 in lp in a8908 in string-tokenize in k3504 in k3501 */
static void C_ccall f_8919(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8919,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_u_fixnum_plus(C_fix(1),t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8928,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* srfi-13.scm: 1761 string-skip-right */
t4=*((C_word*)lf[95]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t3,((C_word*)t0)[4],((C_word*)t0)[2],((C_word*)t0)[3],t1);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[7]);}}

/* k8926 in k8917 in lp in a8908 in string-tokenize in k3504 in k3501 */
static void C_ccall f_8928(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8928,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8942,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_u_fixnum_plus(C_fix(1),t1);
/* srfi-13.scm: 1764 ##sys#substring */
t4=*((C_word*)lf[12]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,((C_word*)t0)[4],t3,((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8953,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* srfi-13.scm: 1766 ##sys#substring */
t3=*((C_word*)lf[12]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[4],((C_word*)t0)[2],((C_word*)t0)[3]);}}

/* k8951 in k8926 in k8917 in lp in a8908 in string-tokenize in k3504 in k3501 */
static void C_ccall f_8953(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8953,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[2]));}

/* k8940 in k8926 in k8917 in lp in a8908 in string-tokenize in k3504 in k3501 */
static void C_ccall f_8942(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8942,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
/* srfi-13.scm: 1763 lp */
t3=((C_word*)((C_word*)t0)[4])[1];
f_8915(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* a8902 in string-tokenize in k3504 in k3501 */
static void C_ccall f_8903(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8903,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[5]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[135]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-replace in k3504 in k3501 */
static void C_ccall f_8840(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,...){
C_word tmp;
C_word t6;
va_list v;
C_word *a,c2=c;
C_save_rest(t5,c2,6);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr6r,(void*)f_8840r,6,t0,t1,t2,t3,t4,t5);}
else{
a=C_alloc((c-6)*3);
t6=C_restore_rest(a,C_rest_count(0));
f_8840r(t0,t1,t2,t3,t4,t5,t6);}}

static void C_ccall f_8840r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word *a=C_alloc(8);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8844,a[2]=t1,a[3]=t4,a[4]=t5,a[5]=t2,a[6]=t6,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
/* srfi-13.scm: 1735 check-substring-spec */
t8=*((C_word*)lf[8]+1);
((C_proc6)(void*)(*((C_word*)t8+1)))(6,t8,t7,*((C_word*)lf[134]+1),t2,t4,t5);}

/* k8842 in string-replace in k3504 in k3501 */
static void C_ccall f_8844(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8844,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8849,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8855,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a8854 in k8842 in string-replace in k3504 in k3501 */
static void C_ccall f_8855(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8855,4,t0,t1,t2,t3);}
t4=(C_word)C_fix((C_word)C_header_size(((C_word*)t0)[5]));
t5=(C_word)C_u_fixnum_difference(t3,t2);
t6=(C_word)C_u_fixnum_difference(((C_word*)t0)[4],((C_word*)t0)[3]);
t7=(C_word)C_u_fixnum_difference(t4,t6);
t8=(C_word)C_u_fixnum_plus(t7,t5);
t9=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8868,a[2]=t1,a[3]=t4,a[4]=((C_word*)t0)[4],a[5]=t5,a[6]=t3,a[7]=t2,a[8]=((C_word*)t0)[2],a[9]=((C_word*)t0)[3],a[10]=((C_word*)t0)[5],tmp=(C_word)a,a+=11,tmp);
/* srfi-13.scm: 1740 make-string */
t10=*((C_word*)lf[16]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,t8);}

/* k8866 in a8854 in k8842 in string-replace in k3504 in k3501 */
static void C_ccall f_8868(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=f_7825(t1,C_fix(0),((C_word*)t0)[10],C_fix(0),((C_word*)t0)[9]);
t3=f_7825(t1,((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6]);
t4=(C_word)C_u_fixnum_plus(((C_word*)t0)[9],((C_word*)t0)[5]);
t5=f_7825(t1,t4,((C_word*)t0)[10],((C_word*)t0)[4],((C_word*)t0)[3]);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t1);}

/* a8848 in k8842 in string-replace in k3504 in k3501 */
static void C_ccall f_8849(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8849,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[5]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[134]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* %finish-string-concatenate-reverse in k3504 in k3501 */
static void C_fcall f_8797(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8797,NULL,5,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8801,a[2]=t1,a[3]=t3,a[4]=t5,a[5]=t4,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t7=(C_word)C_u_fixnum_plus(t5,t2);
/* srfi-13.scm: 1715 make-string */
t8=*((C_word*)lf[16]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t6,t7);}

/* k8799 in %finish-string-concatenate-reverse in k3504 in k3501 */
static void C_ccall f_8801(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8801,2,t0,t1);}
t2=f_7825(t1,((C_word*)t0)[6],((C_word*)t0)[5],C_fix(0),((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8809,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=f_8809(t3,((C_word*)t0)[6],((C_word*)t0)[3]);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t1);}

/* lp in k8799 in %finish-string-concatenate-reverse in k3504 in k3501 */
static C_word C_fcall f_8809(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
loop:
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_fix((C_word)C_header_size(t3));
t6=(C_word)C_u_fixnum_difference(t1,t5);
t7=f_7825(((C_word*)t0)[2],t6,t3,C_fix(0),t5);
t9=t6;
t10=t4;
t1=t9;
t2=t10;
goto loop;}
else{
return(C_SCHEME_UNDEFINED);}}

/* string-concatenate-reverse/shared in k3504 in k3501 */
static void C_ccall f_8671(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3r,(void*)f_8671r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_8671r(t0,t1,t2,t3);}}

static void C_ccall f_8671r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a=C_alloc(7);
t4=(C_word)C_i_nullp(t3);
t5=(C_truep(t4)?lf[133]:(C_word)C_u_i_car(t3));
t6=(C_word)C_i_nullp(t3);
t7=(C_truep(t6)?C_SCHEME_END_OF_LIST:(C_word)C_slot(t3,C_fix(1)));
t8=(C_word)C_i_nullp(t7);
t9=(C_truep(t8)?(C_word)C_fix((C_word)C_header_size(t5)):(C_word)C_u_i_car(t7));
t10=(C_word)C_i_nullp(t7);
t11=(C_truep(t10)?C_SCHEME_END_OF_LIST:(C_word)C_slot(t7,C_fix(1)));
t12=(C_word)C_i_check_exact_2(t9,lf[132]);
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_set_block_item(t14,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8695,a[2]=t9,a[3]=t5,a[4]=t14,tmp=(C_word)a,a+=5,tmp));
t16=((C_word*)t14)[1];
f_8695(t16,t1,C_fix(0),C_SCHEME_FALSE,t2);}

/* lp in string-concatenate-reverse/shared in k3504 in k3501 */
static void C_fcall f_8695(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word *a;
loop:
a=C_alloc(7);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_8695,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_pairp(t4))){
t5=(C_word)C_u_i_car(t4);
t6=(C_word)C_fix((C_word)C_header_size(t5));
t7=(C_word)C_u_fixnum_plus(t2,t6);
t8=t3;
t9=(C_truep(t8)?t8:(C_word)C_eqp(t6,C_fix(0)));
t10=(C_truep(t9)?t3:t4);
t11=(C_word)C_slot(t4,C_fix(1));
/* srfi-13.scm: 1701 lp */
t19=t1;
t20=t7;
t21=t10;
t22=t11;
t1=t19;
t2=t20;
t3=t21;
t4=t22;
goto loop;}
else{
t5=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t5)){
/* srfi-13.scm: 1705 substring/shared */
t6=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t1,((C_word*)t0)[3],C_fix(0),((C_word*)t0)[2]);}
else{
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8745,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t3,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t7=(C_word)C_eqp(((C_word*)t0)[2],C_fix(0));
if(C_truep(t7)){
t8=(C_word)C_u_i_car(t3);
t9=(C_word)C_fix((C_word)C_header_size(t8));
t10=t2;
t11=t6;
f_8745(t11,(C_word)C_eqp(t10,t9));}
else{
t8=t6;
f_8745(t8,C_SCHEME_FALSE);}}}}

/* k8743 in lp in string-concatenate-reverse/shared in k3504 in k3501 */
static void C_fcall f_8745(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_u_i_car(((C_word*)t0)[5]));}
else{
/* srfi-13.scm: 1712 %finish-string-concatenate-reverse */
f_8797(((C_word*)t0)[6],((C_word*)t0)[4],((C_word*)t0)[5],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* string-concatenate-reverse in k3504 in k3501 */
static void C_ccall f_8586(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+2)){
C_save_and_reclaim((void*)tr3r,(void*)f_8586r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_8586r(t0,t1,t2,t3);}}

static void C_ccall f_8586r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(2);
t4=(C_word)C_i_nullp(t3);
t5=(C_truep(t4)?lf[130]:(C_word)C_u_i_car(t3));
t6=(C_word)C_i_nullp(t3);
t7=(C_truep(t6)?C_SCHEME_END_OF_LIST:(C_word)C_slot(t3,C_fix(1)));
t8=(C_word)C_i_nullp(t7);
t9=(C_truep(t8)?(C_word)C_fix((C_word)C_header_size(t5)):(C_word)C_u_i_car(t7));
t10=(C_word)C_i_nullp(t7);
t11=(C_truep(t10)?C_SCHEME_END_OF_LIST:(C_word)C_slot(t7,C_fix(1)));
t12=(C_word)C_i_check_exact_2(t9,lf[129]);
t13=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8613,tmp=(C_word)a,a+=2,tmp);
t14=f_8613(C_fix(0),t2);
/* srfi-13.scm: 1686 %finish-string-concatenate-reverse */
f_8797(t1,t14,t2,t5,t9);}

/* lp in string-concatenate-reverse in k3504 in k3501 */
static C_word C_fcall f_8613(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
loop:
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_fix((C_word)C_header_size(t3));
t5=(C_word)C_u_fixnum_plus(t1,t4);
t6=(C_word)C_slot(t2,C_fix(1));
t8=t5;
t9=t6;
t1=t8;
t2=t9;
goto loop;}
else{
return(t1);}}

/* string-concatenate in k3504 in k3501 */
static void C_ccall f_8513(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8513,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8554,tmp=(C_word)a,a+=2,tmp);
t4=f_8554(t2,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8520,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* srfi-13.scm: 1653 make-string */
t6=*((C_word*)lf[16]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t4);}

/* k8518 in string-concatenate in k3504 in k3501 */
static void C_ccall f_8520(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8520,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8525,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=f_8525(t2,C_fix(0),((C_word*)t0)[3]);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t1);}

/* lp in k8518 in string-concatenate in k3504 in k3501 */
static C_word C_fcall f_8525(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
loop:
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_fix((C_word)C_header_size(t3));
t5=f_7825(((C_word*)t0)[2],t1,t3,C_fix(0),t4);
t6=(C_word)C_u_fixnum_plus(t1,t4);
t7=(C_word)C_slot(t2,C_fix(1));
t9=t6;
t10=t7;
t1=t9;
t2=t10;
goto loop;}
else{
return(C_SCHEME_UNDEFINED);}}

/* doloop2972 in string-concatenate in k3504 in k3501 */
static C_word C_fcall f_8554(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
loop:
if(C_truep((C_word)C_i_pairp(t1))){
t3=(C_word)C_slot(t1,C_fix(1));
t4=(C_word)C_u_i_car(t1);
t5=(C_word)C_fix((C_word)C_header_size(t4));
t6=(C_word)C_u_fixnum_plus(t2,t5);
t8=t3;
t9=t6;
t1=t8;
t2=t9;
goto loop;}
else{
return(t2);}}

/* string-concatenate/shared in k3504 in k3501 */
static void C_ccall f_8411(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8411,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8417,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_8417(t6,t1,t2,C_fix(0),C_SCHEME_FALSE);}

/* lp in string-concatenate/shared in k3504 in k3501 */
static void C_fcall f_8417(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_8417,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_pairp(t2))){
t5=(C_word)C_u_i_car(t2);
t6=(C_word)C_slot(t2,C_fix(1));
t7=(C_word)C_fix((C_word)C_header_size(t5));
t8=(C_word)C_eqp(t7,C_fix(0));
if(C_truep(t8)){
/* srfi-13.scm: 1626 lp */
t19=t1;
t20=t6;
t21=t3;
t22=t4;
t1=t19;
t2=t20;
t3=t21;
t4=t22;
goto loop;}
else{
t9=(C_word)C_u_fixnum_plus(t3,t7);
t10=t4;
t11=(C_truep(t10)?t10:t2);
/* srfi-13.scm: 1627 lp */
t19=t1;
t20=t6;
t21=t9;
t22=t11;
t1=t19;
t2=t20;
t3=t21;
t4=t22;
goto loop;}}
else{
t5=(C_word)C_eqp(t3,C_fix(0));
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,lf[127]);}
else{
t6=(C_word)C_u_i_car(t4);
t7=(C_word)C_fix((C_word)C_header_size(t6));
t8=t3;
t9=(C_word)C_eqp(t8,t7);
if(C_truep(t9)){
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_u_i_car(t4));}
else{
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8471,a[2]=t1,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* srfi-13.scm: 1634 make-string */
t11=*((C_word*)lf[16]+1);
((C_proc3)(void*)(*((C_word*)t11+1)))(3,t11,t10,t3);}}}}

/* k8469 in lp in string-concatenate/shared in k3504 in k3501 */
static void C_ccall f_8471(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8471,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8476,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=f_8476(t2,((C_word*)t0)[3],C_fix(0));
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t1);}

/* lp in k8469 in lp in string-concatenate/shared in k3504 in k3501 */
static C_word C_fcall f_8476(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
loop:
if(C_truep((C_word)C_i_pairp(t1))){
t3=(C_word)C_u_i_car(t1);
t4=(C_word)C_fix((C_word)C_header_size(t3));
t5=f_7825(((C_word*)t0)[2],t2,t3,C_fix(0),t4);
t6=(C_word)C_slot(t1,C_fix(1));
t7=(C_word)C_u_fixnum_plus(t2,t4);
t9=t6;
t10=t7;
t1=t9;
t2=t10;
goto loop;}
else{
return(C_SCHEME_UNDEFINED);}}

/* string-append/shared in k3504 in k3501 */
static void C_ccall f_8405(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_8405r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_8405r(t0,t1,t2);}}

static void C_ccall f_8405r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
/* srfi-13.scm: 1617 string-concatenate/shared */
t3=*((C_word*)lf[126]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}

/* string->list in k3504 in k3501 */
static void C_ccall f_8359(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3r,(void*)f_8359r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_8359r(t0,t1,t2,t3);}}

static void C_ccall f_8359r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(7);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8365,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8371,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t4,t5);}

/* a8370 in string->list in k3504 in k3501 */
static void C_ccall f_8371(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8371,4,t0,t1,t2,t3);}
t4=(C_word)C_u_fixnum_difference(t3,C_fix(1));
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8381,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_8381(t8,t1,t4,C_SCHEME_END_OF_LIST);}

/* doloop2900 in a8370 in string->list in k3504 in k3501 */
static void C_fcall f_8381(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(3);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_8381,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=((C_word*)t0)[4];
if(C_truep((C_word)C_fixnum_lessp(t4,t5))){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t3);}
else{
t6=(C_word)C_u_fixnum_difference(t2,C_fix(1));
t7=(C_word)C_subchar(((C_word*)t0)[3],t2);
t8=(C_word)C_a_i_cons(&a,2,t7,t3);
t10=t1;
t11=t6;
t12=t8;
t1=t10;
t2=t11;
t3=t12;
goto loop;}}

/* a8364 in string->list in k3504 in k3501 */
static void C_ccall f_8365(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8365,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[5]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[124]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-reverse! in k3504 in k3501 */
static void C_ccall f_8304(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3r,(void*)f_8304r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_8304r(t0,t1,t2,t3);}}

static void C_ccall f_8304r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(7);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8310,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8316,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t4,t5);}

/* a8315 in string-reverse! in k3504 in k3501 */
static void C_ccall f_8316(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8316,4,t0,t1,t2,t3);}
t4=(C_word)C_u_fixnum_difference(t3,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8326,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,f_8326(t5,t4,t2));}

/* doloop2870 in a8315 in string-reverse! in k3504 in k3501 */
static C_word C_fcall f_8326(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
loop:
t3=t1;
t4=t2;
if(C_truep((C_word)C_fixnum_less_or_equal_p(t3,t4))){
return(C_SCHEME_UNDEFINED);}
else{
t5=(C_word)C_subchar(((C_word*)t0)[2],t1);
t6=(C_word)C_subchar(((C_word*)t0)[2],t2);
t7=(C_word)C_setsubchar(((C_word*)t0)[2],t1,t6);
t8=(C_word)C_setsubchar(((C_word*)t0)[2],t2,t5);
t9=(C_word)C_u_fixnum_difference(t1,C_fix(1));
t10=(C_word)C_u_fixnum_plus(t2,C_fix(1));
t12=t9;
t13=t10;
t1=t12;
t2=t13;
goto loop;}}

/* a8309 in string-reverse! in k3504 in k3501 */
static void C_ccall f_8310(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8310,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[5]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[123]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-reverse in k3504 in k3501 */
static void C_ccall f_8249(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3r,(void*)f_8249r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_8249r(t0,t1,t2,t3);}}

static void C_ccall f_8249r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(7);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8255,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8261,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t4,t5);}

/* a8260 in string-reverse in k3504 in k3501 */
static void C_ccall f_8261(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8261,4,t0,t1,t2,t3);}
t4=(C_word)C_u_fixnum_difference(t3,t2);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8268,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* srfi-13.scm: 1559 make-string */
t6=*((C_word*)lf[16]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t4);}

/* k8266 in a8260 in string-reverse in k3504 in k3501 */
static void C_ccall f_8268(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8268,2,t0,t1);}
t2=(C_word)C_u_fixnum_difference(((C_word*)t0)[5],C_fix(1));
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8277,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=f_8277(t3,((C_word*)t0)[3],t2);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t1);}

/* doloop2842 in k8266 in a8260 in string-reverse in k3504 in k3501 */
static C_word C_fcall f_8277(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
loop:
t3=t2;
if(C_truep((C_word)C_fixnum_lessp(t3,C_fix(0)))){
return(C_SCHEME_UNDEFINED);}
else{
t4=(C_word)C_subchar(((C_word*)t0)[3],t1);
t5=(C_word)C_setsubchar(((C_word*)t0)[2],t2,t4);
t6=(C_word)C_u_fixnum_plus(t1,C_fix(1));
t7=(C_word)C_u_fixnum_difference(t2,C_fix(1));
t9=t6;
t10=t7;
t1=t9;
t2=t10;
goto loop;}}

/* a8254 in string-reverse in k3504 in k3501 */
static void C_ccall f_8255(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8255,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[5]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[122]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-null? in k3504 in k3501 */
static void C_ccall f_8246(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8246,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_string_null_p(t2));}

/* string-kmp-partial-search in k3504 in k3501 */
static void C_ccall f_8125(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,...){
C_word tmp;
C_word t6;
va_list v;
C_word *a,c2=c;
C_save_rest(t5,c2,6);
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr6r,(void*)f_8125r,6,t0,t1,t2,t3,t4,t5);}
else{
a=C_alloc((c-6)*3);
t6=C_restore_rest(a,C_rest_count(0));
f_8125r(t0,t1,t2,t3,t4,t5,t6);}}

static void C_ccall f_8125r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a=C_alloc(12);
t7=(C_word)C_i_nullp(t6);
t8=(C_truep(t7)?*((C_word*)lf[117]+1):(C_word)C_u_i_car(t6));
t9=(C_word)C_i_nullp(t6);
t10=(C_truep(t9)?C_SCHEME_END_OF_LIST:(C_word)C_slot(t6,C_fix(1)));
t11=(C_word)C_i_nullp(t10);
t12=(C_truep(t11)?C_fix(0):(C_word)C_u_i_car(t10));
t13=(C_word)C_i_nullp(t10);
t14=(C_truep(t13)?C_SCHEME_END_OF_LIST:(C_word)C_slot(t10,C_fix(1)));
t15=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8143,a[2]=t14,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t16=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8149,a[2]=t5,a[3]=t8,a[4]=t2,a[5]=t12,a[6]=t4,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t15,t16);}

/* a8148 in string-kmp-partial-search in k3504 in k3501 */
static void C_ccall f_8149(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8149,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_fix((C_word)C_header_size(((C_word*)t0)[7]));
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8158,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[7],a[6]=t7,a[7]=((C_word*)t0)[6],a[8]=t4,a[9]=t5,tmp=(C_word)a,a+=10,tmp));
t9=((C_word*)t7)[1];
f_8158(t9,t1,t3,((C_word*)t0)[2]);}

/* lp in a8148 in string-kmp-partial-search in k3504 in k3501 */
static void C_fcall f_8158(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8158,NULL,4,t0,t1,t2,t3);}
t4=t3;
t5=(C_word)C_eqp(t4,((C_word*)t0)[9]);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_u_fixnum_negate(t2));}
else{
t6=t2;
t7=((C_word*)t0)[8];
t8=(C_word)C_eqp(t6,t7);
if(C_truep(t8)){
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t3);}
else{
t9=(C_word)C_subchar(((C_word*)t0)[7],t2);
t10=(C_word)C_u_fixnum_plus(t2,C_fix(1));
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8188,a[2]=t10,a[3]=t1,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t12=C_SCHEME_UNDEFINED;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_set_block_item(t13,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8190,a[2]=t9,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t13,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp));
t15=((C_word*)t13)[1];
f_8190(t15,t11,t3);}}}

/* lp2 in lp in a8148 in string-kmp-partial-search in k3504 in k3501 */
static void C_fcall f_8190(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8190,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8197,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_u_fixnum_plus(t2,((C_word*)t0)[5]);
t5=(C_word)C_subchar(((C_word*)t0)[4],t4);
/* srfi-13.scm: 1539 c= */
t6=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,((C_word*)t0)[2],t5);}

/* k8195 in lp2 in lp in a8148 in string-kmp-partial-search in k3504 in k3501 */
static void C_ccall f_8197(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1)));}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],((C_word*)t0)[4]);
t3=(C_word)C_eqp(t2,C_fix(-1));
if(C_truep(t3)){
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_fix(0));}
else{
/* srfi-13.scm: 1543 lp2 */
t4=((C_word*)((C_word*)t0)[2])[1];
f_8190(t4,((C_word*)t0)[5],t2);}}}

/* k8186 in lp in a8148 in string-kmp-partial-search in k3504 in k3501 */
static void C_ccall f_8188(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-13.scm: 1537 lp */
t2=((C_word*)((C_word*)t0)[4])[1];
f_8158(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a8142 in string-kmp-partial-search in k3504 in k3501 */
static void C_ccall f_8143(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8143,2,t0,t1);}
/* srfi-13.scm: 1528 string-parse-start+end */
t2=*((C_word*)lf[0]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[120]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* kmp-step in k3504 in k3501 */
static void C_ccall f_8087(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr8,(void*)f_8087,8,t0,t1,t2,t3,t4,t5,t6,t7);}
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8093,a[2]=t4,a[3]=t6,a[4]=t2,a[5]=t7,a[6]=t9,a[7]=t3,tmp=(C_word)a,a+=8,tmp));
t11=((C_word*)t9)[1];
f_8093(t11,t1,t5);}

/* lp in kmp-step in k3504 in k3501 */
static void C_fcall f_8093(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8093,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8100,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_u_fixnum_plus(t2,((C_word*)t0)[5]);
t5=(C_word)C_subchar(((C_word*)t0)[4],t4);
/* srfi-13.scm: 1506 c= */
t6=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,((C_word*)t0)[2],t5);}

/* k8098 in lp in kmp-step in k3504 in k3501 */
static void C_ccall f_8100(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1)));}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],((C_word*)t0)[4]);
t3=(C_word)C_eqp(t2,C_fix(-1));
if(C_truep(t3)){
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_fix(0));}
else{
/* srfi-13.scm: 1510 lp */
t4=((C_word*)((C_word*)t0)[2])[1];
f_8093(t4,((C_word*)t0)[5],t2);}}}

/* make-kmp-restart-vector in k3504 in k3501 */
static void C_ccall f_7952(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3r,(void*)f_7952r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_7952r(t0,t1,t2,t3);}}

static void C_ccall f_7952r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(8);
t4=(C_word)C_i_nullp(t3);
t5=(C_truep(t4)?*((C_word*)lf[117]+1):(C_word)C_u_i_car(t3));
t6=(C_word)C_i_nullp(t3);
t7=(C_truep(t6)?C_SCHEME_END_OF_LIST:(C_word)C_slot(t3,C_fix(1)));
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7964,a[2]=t7,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7970,a[2]=t5,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t8,t9);}

/* a7969 in make-kmp-restart-vector in k3504 in k3501 */
static void C_ccall f_7970(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7970,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_u_fixnum_difference(t4,t3);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7977,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=t5,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* srfi-13.scm: 1460 make-vector */
t7=*((C_word*)lf[118]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,t5,C_fix(-1));}

/* k7975 in a7969 in make-kmp-restart-vector in k3504 in k3501 */
static void C_ccall f_7977(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7977,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7980,a[2]=t1,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_greaterp(((C_word*)t0)[5],C_fix(0)))){
t3=(C_word)C_u_fixnum_difference(((C_word*)t0)[5],C_fix(1));
t4=(C_word)C_subchar(((C_word*)t0)[4],((C_word*)t0)[3]);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7994,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=t6,a[6]=t1,a[7]=((C_word*)t0)[4],a[8]=t3,tmp=(C_word)a,a+=9,tmp));
t8=((C_word*)t6)[1];
f_7994(t8,t2,C_fix(0),C_fix(-1),((C_word*)t0)[3]);}
else{
t3=t2;
f_7980(2,t3,C_SCHEME_UNDEFINED);}}

/* lp1 in k7975 in a7969 in make-kmp-restart-vector in k3504 in k3501 */
static void C_fcall f_7994(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7994,NULL,5,t0,t1,t2,t3,t4);}
t5=t2;
if(C_truep((C_word)C_fixnum_lessp(t5,((C_word*)t0)[8]))){
t6=(C_word)C_subchar(((C_word*)t0)[7],t4);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_8009,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[2],a[4]=t8,a[5]=((C_word*)t0)[3],a[6]=t6,a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=t4,a[10]=((C_word*)t0)[6],a[11]=t2,tmp=(C_word)a,a+=12,tmp));
t10=((C_word*)t8)[1];
f_8009(t10,t1,t3);}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}}

/* lp2 in lp1 in k7975 in a7969 in make-kmp-restart-vector in k3504 in k3501 */
static void C_fcall f_8009(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8009,NULL,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_eqp(t3,C_fix(-1));
if(C_truep(t4)){
t5=(C_word)C_u_fixnum_plus(((C_word*)t0)[11],C_fix(1));
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8036,a[2]=t1,a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=t5,a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
/* srfi-13.scm: 1478 c= */
t7=((C_word*)t0)[7];
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,((C_word*)t0)[6],((C_word*)t0)[5]);}
else{
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8042,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=t2,a[8]=((C_word*)t0)[11],tmp=(C_word)a,a+=9,tmp);
t6=(C_word)C_u_fixnum_plus(t2,((C_word*)t0)[3]);
t7=(C_word)C_subchar(((C_word*)t0)[2],t6);
/* srfi-13.scm: 1482 c= */
t8=((C_word*)t0)[7];
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t5,((C_word*)t0)[6],t7);}}

/* k8040 in lp2 in lp1 in k7975 in a7969 in make-kmp-restart-vector in k3504 in k3501 */
static void C_ccall f_8042(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_u_fixnum_plus(C_fix(1),((C_word*)t0)[8]);
t3=(C_word)C_u_fixnum_plus(C_fix(1),((C_word*)t0)[7]);
t4=(C_word)C_i_setslot(((C_word*)t0)[6],t2,t3);
t5=(C_word)C_u_fixnum_plus(((C_word*)t0)[5],C_fix(1));
/* srfi-13.scm: 1486 lp1 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_7994(t6,((C_word*)t0)[3],t2,t3,t5);}
else{
t2=(C_word)C_slot(((C_word*)t0)[6],((C_word*)t0)[7]);
/* srfi-13.scm: 1488 lp2 */
t3=((C_word*)((C_word*)t0)[2])[1];
f_8009(t3,((C_word*)t0)[3],t2);}}

/* k8034 in lp2 in lp1 in k7975 in a7969 in make-kmp-restart-vector in k3504 in k3501 */
static void C_ccall f_8036(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_truep(t1)?C_fix(-1):C_fix(0));
t3=(C_word)C_i_setslot(((C_word*)t0)[6],((C_word*)t0)[5],t2);
t4=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* srfi-13.scm: 1479 lp1 */
t5=((C_word*)((C_word*)t0)[3])[1];
f_7994(t5,((C_word*)t0)[2],((C_word*)t0)[5],C_fix(0),t4);}

/* k7978 in k7975 in a7969 in make-kmp-restart-vector in k3504 in k3501 */
static void C_ccall f_7980(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* a7963 in make-kmp-restart-vector in k3504 in k3501 */
static void C_ccall f_7964(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7964,2,t0,t1);}
/* srfi-13.scm: 1458 string-parse-start+end */
t2=*((C_word*)lf[0]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[116]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-contains-ci in k3504 in k3501 */
static void C_ccall f_7890(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr4r,(void*)f_7890r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_7890r(t0,t1,t2,t3,t4);}}

static void C_ccall f_7890r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(10);
t5=*((C_word*)lf[114]+1);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7896,a[2]=t4,a[3]=t2,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7902,a[2]=t2,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t6,t7);}

/* a7901 in string-contains-ci in k3504 in k3501 */
static void C_ccall f_7902(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7902,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7908,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7914,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[2],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t5,t6);}

/* a7913 in a7901 in string-contains-ci in k3504 in k3501 */
static void C_ccall f_7914(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7914,4,t0,t1,t2,t3);}
t4=(C_word)C_u_fixnum_difference(t3,t2);
t5=(C_word)C_u_fixnum_difference(((C_word*)t0)[5],t4);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7926,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t4,a[7]=t7,a[8]=t5,tmp=(C_word)a,a+=9,tmp));
t9=((C_word*)t7)[1];
f_7926(t9,t1,((C_word*)t0)[2]);}

/* lp in a7913 in a7901 in string-contains-ci in k3504 in k3501 */
static void C_fcall f_7926(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7926,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_less_or_equal_p(t2,((C_word*)t0)[8]))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7939,a[2]=((C_word*)t0)[7],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_u_fixnum_plus(t2,((C_word*)t0)[6]);
/* srfi-13.scm: 1401 string-ci= */
t5=*((C_word*)lf[63]+1);
((C_proc8)(void*)(*((C_word*)t5+1)))(8,t5,t3,((C_word*)t0)[5],((C_word*)t0)[4],t2,t4,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k7937 in lp in a7913 in a7901 in string-contains-ci in k3504 in k3501 */
static void C_ccall f_7939(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}
else{
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* srfi-13.scm: 1403 lp */
t3=((C_word*)((C_word*)t0)[2])[1];
f_7926(t3,((C_word*)t0)[4],t2);}}

/* a7907 in a7901 in string-contains-ci in k3504 in k3501 */
static void C_ccall f_7908(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7908,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[5]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a7895 in string-contains-ci in k3504 in k3501 */
static void C_ccall f_7896(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7896,2,t0,t1);}
/* string-parse-start+end */
t2=*((C_word*)lf[0]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-contains in k3504 in k3501 */
static void C_ccall f_7828(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr4r,(void*)f_7828r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_7828r(t0,t1,t2,t3,t4);}}

static void C_ccall f_7828r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(10);
t5=*((C_word*)lf[114]+1);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7834,a[2]=t4,a[3]=t2,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7840,a[2]=t2,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t6,t7);}

/* a7839 in string-contains in k3504 in k3501 */
static void C_ccall f_7840(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7840,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7846,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7852,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[2],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t5,t6);}

/* a7851 in a7839 in string-contains in k3504 in k3501 */
static void C_ccall f_7852(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7852,4,t0,t1,t2,t3);}
t4=(C_word)C_u_fixnum_difference(t3,t2);
t5=(C_word)C_u_fixnum_difference(((C_word*)t0)[5],t4);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7864,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t4,a[7]=t7,a[8]=t5,tmp=(C_word)a,a+=9,tmp));
t9=((C_word*)t7)[1];
f_7864(t9,t1,((C_word*)t0)[2]);}

/* lp in a7851 in a7839 in string-contains in k3504 in k3501 */
static void C_fcall f_7864(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7864,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_less_or_equal_p(t2,((C_word*)t0)[8]))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7877,a[2]=((C_word*)t0)[7],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_u_fixnum_plus(t2,((C_word*)t0)[6]);
/* srfi-13.scm: 1390 string= */
t5=*((C_word*)lf[56]+1);
((C_proc8)(void*)(*((C_word*)t5+1)))(8,t5,t3,((C_word*)t0)[5],((C_word*)t0)[4],t2,t4,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k7875 in lp in a7851 in a7839 in string-contains in k3504 in k3501 */
static void C_ccall f_7877(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}
else{
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* srfi-13.scm: 1392 lp */
t3=((C_word*)((C_word*)t0)[2])[1];
f_7864(t3,((C_word*)t0)[4],t2);}}

/* a7845 in a7839 in string-contains in k3504 in k3501 */
static void C_ccall f_7846(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7846,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[5]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a7833 in string-contains in k3504 in k3501 */
static void C_ccall f_7834(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7834,2,t0,t1);}
/* string-parse-start+end */
t2=*((C_word*)lf[0]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* %string-copy! in k3504 in k3501 */
static C_word C_fcall f_7825(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
return((C_word)C_substring_copy(t3,t1,t4,t5,t2));}

/* string-copy! in k3504 in k3501 */
static void C_ccall f_7793(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr5r,(void*)f_7793r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_7793r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_7793r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(9);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7799,a[2]=t5,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7805,a[2]=t4,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t6,t7);}

/* a7804 in string-copy! in k3504 in k3501 */
static void C_ccall f_7805(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7805,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact_2(((C_word*)t0)[4],lf[113]);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7812,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[3],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t6=(C_word)C_u_fixnum_difference(t3,t2);
t7=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],t6);
/* srfi-13.scm: 1370 check-substring-spec */
t8=*((C_word*)lf[8]+1);
((C_proc6)(void*)(*((C_word*)t8+1)))(6,t8,t5,*((C_word*)lf[113]+1),((C_word*)t0)[3],((C_word*)t0)[4],t7);}

/* k7810 in a7804 in string-copy! in k3504 in k3501 */
static void C_ccall f_7812(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-13.scm: 1371 %string-copy! */
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,f_7825(((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]));}

/* a7798 in string-copy! in k3504 in k3501 */
static void C_ccall f_7799(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7799,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[5]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[113]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-fill! in k3504 in k3501 */
static void C_ccall f_7752(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr4r,(void*)f_7752r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_7752r(t0,t1,t2,t3,t4);}}

static void C_ccall f_7752r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(8);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7758,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7764,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t5,t6);}

/* a7763 in string-fill! in k3504 in k3501 */
static void C_ccall f_7764(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7764,4,t0,t1,t2,t3);}
t4=(C_word)C_u_fixnum_difference(t3,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7774,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,f_7774(t5,t4));}

/* doloop2546 in a7763 in string-fill! in k3504 in k3501 */
static C_word C_fcall f_7774(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
loop:
t2=t1;
t3=((C_word*)t0)[4];
if(C_truep((C_word)C_fixnum_lessp(t2,t3))){
return(C_SCHEME_UNDEFINED);}
else{
t4=(C_word)C_setsubchar(((C_word*)t0)[3],t1,((C_word*)t0)[2]);
t5=(C_word)C_u_fixnum_difference(t1,C_fix(1));
t7=t5;
t1=t7;
goto loop;}}

/* a7757 in string-fill! in k3504 in k3501 */
static void C_ccall f_7758(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7758,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[5]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[112]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-count in k3504 in k3501 */
static void C_ccall f_7617(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr4r,(void*)f_7617r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_7617r(t0,t1,t2,t3,t4);}}

static void C_ccall f_7617r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(8);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7623,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7629,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t5,t6);}

/* a7628 in string-count in k3504 in k3501 */
static void C_ccall f_7629(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7629,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_charp(((C_word*)t0)[3]))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7641,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,f_7641(t4,t2,C_fix(0)));}
else{
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7675,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[2],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* srfi-13.scm: 1336 char-set? */
t5=*((C_word*)lf[34]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[3]);}}

/* k7673 in a7628 in string-count in k3504 in k3501 */
static void C_ccall f_7675(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7675,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7680,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_7680(t5,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0));}
else{
if(C_truep((C_word)C_i_closurep(((C_word*)t0)[4]))){
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7719,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_7719(t5,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0));}
else{
/* srfi-13.scm: 1348 ##sys#error */
t2=*((C_word*)lf[1]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[110],lf[111],*((C_word*)lf[110]+1),((C_word*)t0)[4]);}}}

/* doloop2521 in k7673 in a7628 in string-count in k3504 in k3501 */
static void C_fcall f_7719(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7719,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=((C_word*)t0)[5];
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t4,t5))){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t3);}
else{
t6=(C_word)C_u_fixnum_plus(t2,C_fix(1));
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7740,a[2]=t6,a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t8=(C_word)C_subchar(((C_word*)t0)[3],t2);
/* srfi-13.scm: 1345 criteria */
t9=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t7,t8);}}

/* k7738 in doloop2521 in k7673 in a7628 in string-count in k3504 in k3501 */
static void C_ccall f_7740(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?(C_word)C_u_fixnum_plus(((C_word*)t0)[5],C_fix(1)):((C_word*)t0)[5]);
t3=((C_word*)((C_word*)t0)[4])[1];
f_7719(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* doloop2510 in k7673 in a7628 in string-count in k3504 in k3501 */
static void C_fcall f_7680(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7680,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=((C_word*)t0)[5];
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t4,t5))){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t3);}
else{
t6=(C_word)C_u_fixnum_plus(t2,C_fix(1));
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7701,a[2]=t6,a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t8=(C_word)C_subchar(((C_word*)t0)[3],t2);
/* srfi-13.scm: 1338 char-set-contains? */
t9=*((C_word*)lf[32]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t7,((C_word*)t0)[2],t8);}}

/* k7699 in doloop2510 in k7673 in a7628 in string-count in k3504 in k3501 */
static void C_ccall f_7701(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?(C_word)C_u_fixnum_plus(((C_word*)t0)[5],C_fix(1)):((C_word*)t0)[5]);
t3=((C_word*)((C_word*)t0)[4])[1];
f_7680(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* doloop2499 in a7628 in string-count in k3504 in k3501 */
static C_word C_fcall f_7641(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
loop:
t3=t1;
t4=((C_word*)t0)[4];
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,t4))){
return(t2);}
else{
t5=(C_word)C_u_fixnum_plus(t1,C_fix(1));
t6=(C_word)C_subchar(((C_word*)t0)[3],t1);
t7=(C_word)C_eqp(((C_word*)t0)[2],t6);
t8=(C_truep(t7)?(C_word)C_u_fixnum_plus(t2,C_fix(1)):t2);
t10=t5;
t11=t8;
t1=t10;
t2=t11;
goto loop;}}

/* a7622 in string-count in k3504 in k3501 */
static void C_ccall f_7623(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7623,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[5]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[110]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-skip-right in k3504 in k3501 */
static void C_ccall f_7482(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr4r,(void*)f_7482r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_7482r(t0,t1,t2,t3,t4);}}

static void C_ccall f_7482r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(8);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7488,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7494,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t5,t6);}

/* a7493 in string-skip-right in k3504 in k3501 */
static void C_ccall f_7494(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7494,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_charp(((C_word*)t0)[3]))){
t4=(C_word)C_u_fixnum_difference(t3,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7510,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,f_7510(t5,t4));}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7540,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[2],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* srfi-13.scm: 1310 char-set? */
t5=*((C_word*)lf[34]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[3]);}}

/* k7538 in a7493 in string-skip-right in k3504 in k3501 */
static void C_ccall f_7540(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7540,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_u_fixnum_difference(((C_word*)t0)[5],C_fix(1));
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7549,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_7549(t6,((C_word*)t0)[2],t2);}
else{
if(C_truep((C_word)C_i_closurep(((C_word*)t0)[3]))){
t2=(C_word)C_u_fixnum_difference(((C_word*)t0)[5],C_fix(1));
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7588,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_7588(t6,((C_word*)t0)[2],t2);}
else{
/* srfi-13.scm: 1321 ##sys#error */
t2=*((C_word*)lf[1]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[2],lf[95],lf[109],*((C_word*)lf[95]+1),((C_word*)t0)[3]);}}}

/* lp in k7538 in a7493 in string-skip-right in k3504 in k3501 */
static void C_fcall f_7588(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7588,NULL,3,t0,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7601,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_subchar(((C_word*)t0)[3],t2);
/* srfi-13.scm: 1319 criteria */
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k7599 in lp in k7538 in a7493 in string-skip-right in k3504 in k3501 */
static void C_ccall f_7601(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_u_fixnum_difference(((C_word*)t0)[4],C_fix(1));
/* srfi-13.scm: 1319 lp */
t3=((C_word*)((C_word*)t0)[3])[1];
f_7588(t3,((C_word*)t0)[2],t2);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[4]);}}

/* lp in k7538 in a7493 in string-skip-right in k3504 in k3501 */
static void C_fcall f_7549(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7549,NULL,3,t0,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7562,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_subchar(((C_word*)t0)[3],t2);
/* srfi-13.scm: 1313 char-set-contains? */
t6=*((C_word*)lf[32]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,((C_word*)t0)[2],t5);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k7560 in lp in k7538 in a7493 in string-skip-right in k3504 in k3501 */
static void C_ccall f_7562(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_u_fixnum_difference(((C_word*)t0)[4],C_fix(1));
/* srfi-13.scm: 1314 lp */
t3=((C_word*)((C_word*)t0)[3])[1];
f_7549(t3,((C_word*)t0)[2],t2);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[4]);}}

/* lp in a7493 in string-skip-right in k3504 in k3501 */
static C_word C_fcall f_7510(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
loop:
t2=t1;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,C_fix(0)))){
t3=(C_word)C_subchar(((C_word*)t0)[3],t1);
t4=(C_word)C_eqp(((C_word*)t0)[2],t3);
if(C_truep(t4)){
t5=(C_word)C_u_fixnum_difference(t1,C_fix(1));
t7=t5;
t1=t7;
goto loop;}
else{
return(t1);}}
else{
return(C_SCHEME_FALSE);}}

/* a7487 in string-skip-right in k3504 in k3501 */
static void C_ccall f_7488(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7488,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[5]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[95]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-skip in k3504 in k3501 */
static void C_ccall f_7359(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr4r,(void*)f_7359r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_7359r(t0,t1,t2,t3,t4);}}

static void C_ccall f_7359r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(8);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7365,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7371,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t5,t6);}

/* a7370 in string-skip in k3504 in k3501 */
static void C_ccall f_7371(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7371,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_charp(((C_word*)t0)[3]))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7383,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,f_7383(t4,t2));}
else{
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7413,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[2],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* srfi-13.scm: 1288 char-set? */
t5=*((C_word*)lf[34]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[3]);}}

/* k7411 in a7370 in string-skip in k3504 in k3501 */
static void C_ccall f_7413(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7413,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7418,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_7418(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
if(C_truep((C_word)C_i_closurep(((C_word*)t0)[4]))){
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7453,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_7453(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* srfi-13.scm: 1299 ##sys#error */
t2=*((C_word*)lf[1]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[81],lf[108],*((C_word*)lf[81]+1),((C_word*)t0)[4]);}}}

/* lp in k7411 in a7370 in string-skip in k3504 in k3501 */
static void C_fcall f_7453(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7453,NULL,3,t0,t1,t2);}
t3=t2;
t4=((C_word*)t0)[5];
if(C_truep((C_word)C_fixnum_lessp(t3,t4))){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7466,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_subchar(((C_word*)t0)[3],t2);
/* srfi-13.scm: 1297 criteria */
t7=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t5,t6);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}

/* k7464 in lp in k7411 in a7370 in string-skip in k3504 in k3501 */
static void C_ccall f_7466(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* srfi-13.scm: 1297 lp */
t3=((C_word*)((C_word*)t0)[3])[1];
f_7453(t3,((C_word*)t0)[2],t2);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[4]);}}

/* lp in k7411 in a7370 in string-skip in k3504 in k3501 */
static void C_fcall f_7418(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7418,NULL,3,t0,t1,t2);}
t3=t2;
t4=((C_word*)t0)[5];
if(C_truep((C_word)C_fixnum_lessp(t3,t4))){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7431,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_subchar(((C_word*)t0)[3],t2);
/* srfi-13.scm: 1291 char-set-contains? */
t7=*((C_word*)lf[32]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,((C_word*)t0)[2],t6);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}

/* k7429 in lp in k7411 in a7370 in string-skip in k3504 in k3501 */
static void C_ccall f_7431(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* srfi-13.scm: 1292 lp */
t3=((C_word*)((C_word*)t0)[3])[1];
f_7418(t3,((C_word*)t0)[2],t2);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[4]);}}

/* lp in a7370 in string-skip in k3504 in k3501 */
static C_word C_fcall f_7383(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
loop:
t2=t1;
t3=((C_word*)t0)[4];
if(C_truep((C_word)C_fixnum_lessp(t2,t3))){
t4=(C_word)C_subchar(((C_word*)t0)[3],t1);
t5=(C_word)C_eqp(((C_word*)t0)[2],t4);
if(C_truep(t5)){
t6=(C_word)C_u_fixnum_plus(t1,C_fix(1));
t8=t6;
t1=t8;
goto loop;}
else{
return(t1);}}
else{
return(C_SCHEME_FALSE);}}

/* a7364 in string-skip in k3504 in k3501 */
static void C_ccall f_7365(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7365,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[5]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[81]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-index-right in k3504 in k3501 */
static void C_ccall f_7224(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr4r,(void*)f_7224r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_7224r(t0,t1,t2,t3,t4);}}

static void C_ccall f_7224r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(8);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7230,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7236,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t5,t6);}

/* a7235 in string-index-right in k3504 in k3501 */
static void C_ccall f_7236(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7236,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_charp(((C_word*)t0)[3]))){
t4=(C_word)C_u_fixnum_difference(t3,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7252,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,f_7252(t5,t4));}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7282,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[2],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* srfi-13.scm: 1267 char-set? */
t5=*((C_word*)lf[34]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[3]);}}

/* k7280 in a7235 in string-index-right in k3504 in k3501 */
static void C_ccall f_7282(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7282,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_u_fixnum_difference(((C_word*)t0)[5],C_fix(1));
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7291,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_7291(t6,((C_word*)t0)[2],t2);}
else{
if(C_truep((C_word)C_i_closurep(((C_word*)t0)[3]))){
t2=(C_word)C_u_fixnum_difference(((C_word*)t0)[5],C_fix(1));
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7330,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_7330(t6,((C_word*)t0)[2],t2);}
else{
/* srfi-13.scm: 1277 ##sys#error */
t2=*((C_word*)lf[1]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[2],lf[106],lf[107],*((C_word*)lf[106]+1),((C_word*)t0)[3]);}}}

/* lp in k7280 in a7235 in string-index-right in k3504 in k3501 */
static void C_fcall f_7330(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7330,NULL,3,t0,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7343,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_subchar(((C_word*)t0)[3],t2);
/* srfi-13.scm: 1275 criteria */
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k7341 in lp in k7280 in a7235 in string-index-right in k3504 in k3501 */
static void C_ccall f_7343(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}
else{
t2=(C_word)C_u_fixnum_difference(((C_word*)t0)[3],C_fix(1));
/* srfi-13.scm: 1276 lp */
t3=((C_word*)((C_word*)t0)[2])[1];
f_7330(t3,((C_word*)t0)[4],t2);}}

/* lp in k7280 in a7235 in string-index-right in k3504 in k3501 */
static void C_fcall f_7291(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7291,NULL,3,t0,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7304,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_subchar(((C_word*)t0)[3],t2);
/* srfi-13.scm: 1270 char-set-contains? */
t6=*((C_word*)lf[32]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,((C_word*)t0)[2],t5);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k7302 in lp in k7280 in a7235 in string-index-right in k3504 in k3501 */
static void C_ccall f_7304(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}
else{
t2=(C_word)C_u_fixnum_difference(((C_word*)t0)[3],C_fix(1));
/* srfi-13.scm: 1271 lp */
t3=((C_word*)((C_word*)t0)[2])[1];
f_7291(t3,((C_word*)t0)[4],t2);}}

/* lp in a7235 in string-index-right in k3504 in k3501 */
static C_word C_fcall f_7252(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
loop:
t2=t1;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,C_fix(0)))){
t3=(C_word)C_subchar(((C_word*)t0)[3],t1);
t4=(C_word)C_eqp(((C_word*)t0)[2],t3);
if(C_truep(t4)){
return(t1);}
else{
t5=(C_word)C_u_fixnum_difference(t1,C_fix(1));
t7=t5;
t1=t7;
goto loop;}}
else{
return(C_SCHEME_FALSE);}}

/* a7229 in string-index-right in k3504 in k3501 */
static void C_ccall f_7230(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7230,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[5]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[106]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-index in k3504 in k3501 */
static void C_ccall f_7101(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr4r,(void*)f_7101r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_7101r(t0,t1,t2,t3,t4);}}

static void C_ccall f_7101r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(8);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7107,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7113,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t5,t6);}

/* a7112 in string-index in k3504 in k3501 */
static void C_ccall f_7113(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7113,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_charp(((C_word*)t0)[3]))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7125,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,f_7125(t4,t2));}
else{
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7155,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[2],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* srfi-13.scm: 1247 char-set? */
t5=*((C_word*)lf[34]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[3]);}}

/* k7153 in a7112 in string-index in k3504 in k3501 */
static void C_ccall f_7155(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7155,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7160,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_7160(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
if(C_truep((C_word)C_i_closurep(((C_word*)t0)[4]))){
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7195,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_7195(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* srfi-13.scm: 1257 ##sys#error */
t2=*((C_word*)lf[1]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[82],lf[105],*((C_word*)lf[82]+1),((C_word*)t0)[4]);}}}

/* lp in k7153 in a7112 in string-index in k3504 in k3501 */
static void C_fcall f_7195(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7195,NULL,3,t0,t1,t2);}
t3=t2;
t4=((C_word*)t0)[5];
if(C_truep((C_word)C_fixnum_lessp(t3,t4))){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7208,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_subchar(((C_word*)t0)[3],t2);
/* srfi-13.scm: 1255 criteria */
t7=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t5,t6);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}

/* k7206 in lp in k7153 in a7112 in string-index in k3504 in k3501 */
static void C_ccall f_7208(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}
else{
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* srfi-13.scm: 1256 lp */
t3=((C_word*)((C_word*)t0)[2])[1];
f_7195(t3,((C_word*)t0)[4],t2);}}

/* lp in k7153 in a7112 in string-index in k3504 in k3501 */
static void C_fcall f_7160(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7160,NULL,3,t0,t1,t2);}
t3=t2;
t4=((C_word*)t0)[5];
if(C_truep((C_word)C_fixnum_lessp(t3,t4))){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7173,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_subchar(((C_word*)t0)[3],t2);
/* srfi-13.scm: 1250 char-set-contains? */
t7=*((C_word*)lf[32]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,((C_word*)t0)[2],t6);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}

/* k7171 in lp in k7153 in a7112 in string-index in k3504 in k3501 */
static void C_ccall f_7173(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}
else{
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* srfi-13.scm: 1251 lp */
t3=((C_word*)((C_word*)t0)[2])[1];
f_7160(t3,((C_word*)t0)[4],t2);}}

/* lp in a7112 in string-index in k3504 in k3501 */
static C_word C_fcall f_7125(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
loop:
t2=t1;
t3=((C_word*)t0)[4];
if(C_truep((C_word)C_fixnum_lessp(t2,t3))){
t4=(C_word)C_subchar(((C_word*)t0)[3],t1);
t5=(C_word)C_eqp(((C_word*)t0)[2],t4);
if(C_truep(t5)){
return(t1);}
else{
t6=(C_word)C_u_fixnum_plus(t1,C_fix(1));
t8=t6;
t1=t8;
goto loop;}}
else{
return(C_SCHEME_FALSE);}}

/* a7106 in string-index in k3504 in k3501 */
static void C_ccall f_7107(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7107,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[5]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[82]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-filter in k3504 in k3501 */
static void C_ccall f_6993(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr4r,(void*)f_6993r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_6993r(t0,t1,t2,t3,t4);}}

static void C_ccall f_6993r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(8);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6999,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7005,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t5,t6);}

/* a7004 in string-filter in k3504 in k3501 */
static void C_ccall f_7005(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7005,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_closurep(((C_word*)t0)[3]))){
t4=(C_word)C_u_fixnum_difference(t3,t2);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7018,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=t1,a[7]=t4,tmp=(C_word)a,a+=8,tmp);
/* srfi-13.scm: 1203 make-string */
t6=*((C_word*)lf[16]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t4);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7048,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7087,a[2]=((C_word*)t0)[3],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* srfi-13.scm: 1212 char-set? */
t6=*((C_word*)lf[34]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[3]);}}

/* k7085 in a7004 in string-filter in k3504 in k3501 */
static void C_ccall f_7087(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_7048(2,t2,((C_word*)t0)[2]);}
else{
if(C_truep((C_word)C_charp(((C_word*)t0)[2]))){
/* srfi-13.scm: 1213 char-set */
t2=*((C_word*)lf[101]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* srfi-13.scm: 1214 ##sys#error */
t2=*((C_word*)lf[1]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[103],lf[104],((C_word*)t0)[2]);}}}

/* k7046 in a7004 in string-filter in k3504 in k3501 */
static void C_ccall f_7048(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7048,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7051,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7074,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* srfi-13.scm: 1216 string-fold */
t4=*((C_word*)lf[19]+1);
((C_proc7)(void*)(*((C_word*)t4+1)))(7,t4,t2,t3,C_fix(0),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a7073 in k7046 in a7004 in string-filter in k3504 in k3501 */
static void C_ccall f_7074(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7074,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7081,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-13.scm: 1216 char-set-contains? */
t5=*((C_word*)lf[32]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[2],t2);}

/* k7079 in a7073 in k7046 in a7004 in string-filter in k3504 in k3501 */
static void C_ccall f_7081(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?(C_word)C_u_fixnum_plus(((C_word*)t0)[2],C_fix(1)):((C_word*)t0)[2]));}

/* k7049 in k7046 in a7004 in string-filter in k3504 in k3501 */
static void C_ccall f_7051(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7051,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7054,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* srfi-13.scm: 1220 make-string */
t3=*((C_word*)lf[16]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}

/* k7052 in k7049 in k7046 in a7004 in string-filter in k3504 in k3501 */
static void C_ccall f_7054(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7054,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7057,a[2]=t1,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7059,a[2]=((C_word*)t0)[5],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-13.scm: 1221 string-fold */
t4=*((C_word*)lf[19]+1);
((C_proc7)(void*)(*((C_word*)t4+1)))(7,t4,t2,t3,C_fix(0),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a7058 in k7052 in k7049 in k7046 in a7004 in string-filter in k3504 in k3501 */
static void C_ccall f_7059(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7059,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7066,a[2]=t1,a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* srfi-13.scm: 1221 char-set-contains? */
t5=*((C_word*)lf[32]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[2],t2);}

/* k7064 in a7058 in k7052 in k7049 in k7046 in a7004 in string-filter in k3504 in k3501 */
static void C_ccall f_7066(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_setsubchar(((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1)));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[4]);}}

/* k7055 in k7052 in k7049 in k7046 in a7004 in string-filter in k3504 in k3501 */
static void C_ccall f_7057(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k7016 in a7004 in string-filter in k3504 in k3501 */
static void C_ccall f_7018(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7018,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7021,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7032,a[2]=((C_word*)t0)[5],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-13.scm: 1204 string-fold */
t4=*((C_word*)lf[19]+1);
((C_proc7)(void*)(*((C_word*)t4+1)))(7,t4,t2,t3,C_fix(0),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a7031 in k7016 in a7004 in string-filter in k3504 in k3501 */
static void C_ccall f_7032(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7032,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7039,a[2]=t1,a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* srfi-13.scm: 1205 criteria */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k7037 in a7031 in k7016 in a7004 in string-filter in k3504 in k3501 */
static void C_ccall f_7039(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_setsubchar(((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1)));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[4]);}}

/* k7019 in k7016 in a7004 in string-filter in k3504 in k3501 */
static void C_ccall f_7021(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=t1;
t3=(C_word)C_eqp(t2,((C_word*)t0)[4]);
if(C_truep(t3)){
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[2]);}
else{
/* srfi-13.scm: 1210 ##sys#substring */
t4=*((C_word*)lf[12]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0),t1);}}

/* a6998 in string-filter in k3504 in k3501 */
static void C_ccall f_6999(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6999,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[5]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[103]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-delete in k3504 in k3501 */
static void C_ccall f_6885(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr4r,(void*)f_6885r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_6885r(t0,t1,t2,t3,t4);}}

static void C_ccall f_6885r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(8);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6891,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6897,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t5,t6);}

/* a6896 in string-delete in k3504 in k3501 */
static void C_ccall f_6897(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6897,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_closurep(((C_word*)t0)[3]))){
t4=(C_word)C_u_fixnum_difference(t3,t2);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6910,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=t1,a[7]=t4,tmp=(C_word)a,a+=8,tmp);
/* srfi-13.scm: 1176 make-string */
t6=*((C_word*)lf[16]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t4);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6940,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6979,a[2]=((C_word*)t0)[3],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* srfi-13.scm: 1184 char-set? */
t6=*((C_word*)lf[34]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[3]);}}

/* k6977 in a6896 in string-delete in k3504 in k3501 */
static void C_ccall f_6979(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_6940(2,t2,((C_word*)t0)[2]);}
else{
if(C_truep((C_word)C_charp(((C_word*)t0)[2]))){
/* srfi-13.scm: 1185 char-set */
t2=*((C_word*)lf[101]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* srfi-13.scm: 1186 ##sys#error */
t2=*((C_word*)lf[1]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[100],lf[102],((C_word*)t0)[2]);}}}

/* k6938 in a6896 in string-delete in k3504 in k3501 */
static void C_ccall f_6940(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6940,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6943,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6966,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* srfi-13.scm: 1187 string-fold */
t4=*((C_word*)lf[19]+1);
((C_proc7)(void*)(*((C_word*)t4+1)))(7,t4,t2,t3,C_fix(0),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a6965 in k6938 in a6896 in string-delete in k3504 in k3501 */
static void C_ccall f_6966(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6966,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6973,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-13.scm: 1187 char-set-contains? */
t5=*((C_word*)lf[32]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[2],t2);}

/* k6971 in a6965 in k6938 in a6896 in string-delete in k3504 in k3501 */
static void C_ccall f_6973(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?((C_word*)t0)[2]:(C_word)C_u_fixnum_plus(((C_word*)t0)[2],C_fix(1))));}

/* k6941 in k6938 in a6896 in string-delete in k3504 in k3501 */
static void C_ccall f_6943(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6943,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6946,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* srfi-13.scm: 1191 make-string */
t3=*((C_word*)lf[16]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}

/* k6944 in k6941 in k6938 in a6896 in string-delete in k3504 in k3501 */
static void C_ccall f_6946(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6946,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6949,a[2]=t1,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6951,a[2]=((C_word*)t0)[5],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-13.scm: 1192 string-fold */
t4=*((C_word*)lf[19]+1);
((C_proc7)(void*)(*((C_word*)t4+1)))(7,t4,t2,t3,C_fix(0),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a6950 in k6944 in k6941 in k6938 in a6896 in string-delete in k3504 in k3501 */
static void C_ccall f_6951(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6951,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6958,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* srfi-13.scm: 1192 char-set-contains? */
t5=*((C_word*)lf[32]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[2],t2);}

/* k6956 in a6950 in k6944 in k6941 in k6938 in a6896 in string-delete in k3504 in k3501 */
static void C_ccall f_6958(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[4]);}
else{
t2=(C_word)C_setsubchar(((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[2]);
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1)));}}

/* k6947 in k6944 in k6941 in k6938 in a6896 in string-delete in k3504 in k3501 */
static void C_ccall f_6949(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k6908 in a6896 in string-delete in k3504 in k3501 */
static void C_ccall f_6910(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6910,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6913,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6924,a[2]=((C_word*)t0)[5],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-13.scm: 1177 string-fold */
t4=*((C_word*)lf[19]+1);
((C_proc7)(void*)(*((C_word*)t4+1)))(7,t4,t2,t3,C_fix(0),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a6923 in k6908 in a6896 in string-delete in k3504 in k3501 */
static void C_ccall f_6924(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6924,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6931,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* srfi-13.scm: 1178 criteria */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k6929 in a6923 in k6908 in a6896 in string-delete in k3504 in k3501 */
static void C_ccall f_6931(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[4]);}
else{
t2=(C_word)C_setsubchar(((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[2]);
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1)));}}

/* k6911 in k6908 in a6896 in string-delete in k3504 in k3501 */
static void C_ccall f_6913(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=t1;
t3=(C_word)C_eqp(t2,((C_word*)t0)[4]);
if(C_truep(t3)){
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[2]);}
else{
/* srfi-13.scm: 1182 ##sys#substring */
t4=*((C_word*)lf[12]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0),t1);}}

/* a6890 in string-delete in k3504 in k3501 */
static void C_ccall f_6891(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6891,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[5]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[100]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-pad in k3504 in k3501 */
static void C_ccall f_6823(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr4r,(void*)f_6823r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_6823r(t0,t1,t2,t3,t4);}}

static void C_ccall f_6823r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(9);
t5=(C_word)C_i_check_exact_2(t3,lf[99]);
t6=(C_word)C_i_nullp(t4);
t7=(C_truep(t6)?C_make_character(32):(C_word)C_u_i_car(t4));
t8=(C_word)C_i_nullp(t4);
t9=(C_truep(t8)?C_SCHEME_END_OF_LIST:(C_word)C_slot(t4,C_fix(1)));
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6838,a[2]=t9,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6844,a[2]=t7,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t10,t11);}

/* a6843 in string-pad in k3504 in k3501 */
static void C_ccall f_6844(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6844,4,t0,t1,t2,t3);}
t4=(C_word)C_u_fixnum_difference(t3,t2);
t5=((C_word*)t0)[4];
if(C_truep((C_word)C_fixnum_less_or_equal_p(t5,t4))){
t6=(C_word)C_u_fixnum_difference(t3,((C_word*)t0)[4]);
/* srfi-13.scm: 1151 %substring/shared */
f_3714(t1,((C_word*)t0)[3],t6,t3);}
else{
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6864,a[2]=t1,a[3]=t3,a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=t4,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
/* srfi-13.scm: 1152 make-string */
t7=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* k6862 in a6843 in string-pad in k3504 in k3501 */
static void C_ccall f_6864(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_u_fixnum_difference(((C_word*)t0)[7],((C_word*)t0)[6]);
t3=f_7825(t1,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t1);}

/* a6837 in string-pad in k3504 in k3501 */
static void C_ccall f_6838(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6838,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[5]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[99]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-pad-right in k3504 in k3501 */
static void C_ccall f_6765(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr4r,(void*)f_6765r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_6765r(t0,t1,t2,t3,t4);}}

static void C_ccall f_6765r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(9);
t5=(C_word)C_i_check_exact_2(t3,lf[98]);
t6=(C_word)C_i_nullp(t4);
t7=(C_truep(t6)?C_make_character(32):(C_word)C_u_i_car(t4));
t8=(C_word)C_i_nullp(t4);
t9=(C_truep(t8)?C_SCHEME_END_OF_LIST:(C_word)C_slot(t4,C_fix(1)));
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6780,a[2]=t9,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6786,a[2]=t7,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t10,t11);}

/* a6785 in string-pad-right in k3504 in k3501 */
static void C_ccall f_6786(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6786,4,t0,t1,t2,t3);}
t4=(C_word)C_u_fixnum_difference(t3,t2);
t5=((C_word*)t0)[4];
if(C_truep((C_word)C_fixnum_less_or_equal_p(t5,t4))){
t6=(C_word)C_u_fixnum_plus(t2,((C_word*)t0)[4]);
/* srfi-13.scm: 1140 %substring/shared */
f_3714(t1,((C_word*)t0)[3],t2,t6);}
else{
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6806,a[2]=t1,a[3]=t3,a[4]=t2,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* srfi-13.scm: 1141 make-string */
t7=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* k6804 in a6785 in string-pad-right in k3504 in k3501 */
static void C_ccall f_6806(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=f_7825(t1,C_fix(0),((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* a6779 in string-pad-right in k3504 in k3501 */
static void C_ccall f_6780(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6780,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[5]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[98]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-trim-both in k3504 in k3501 */
static void C_ccall f_6715(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3r,(void*)f_6715r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6715r(t0,t1,t2,t3);}}

static void C_ccall f_6715r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(8);
t4=(C_word)C_i_nullp(t3);
t5=(C_truep(t4)?*((C_word*)lf[91]+1):(C_word)C_u_i_car(t3));
t6=(C_word)C_i_nullp(t3);
t7=(C_truep(t6)?C_SCHEME_END_OF_LIST:(C_word)C_slot(t3,C_fix(1)));
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6727,a[2]=t7,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6733,a[2]=t5,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t8,t9);}

/* a6732 in string-trim-both in k3504 in k3501 */
static void C_ccall f_6733(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6733,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6737,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* srfi-13.scm: 1128 string-skip */
t5=*((C_word*)lf[81]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t4,((C_word*)t0)[3],((C_word*)t0)[2],t2,t3);}

/* k6735 in a6732 in string-trim-both in k3504 in k3501 */
static void C_ccall f_6737(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6737,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6751,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* srfi-13.scm: 1130 string-skip-right */
t3=*((C_word*)lf[95]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[97]);}}

/* k6749 in k6735 in a6732 in string-trim-both in k3504 in k3501 */
static void C_ccall f_6751(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_plus(C_fix(1),t1);
/* srfi-13.scm: 1130 %substring/shared */
f_3714(((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* a6726 in string-trim-both in k3504 in k3501 */
static void C_ccall f_6727(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6727,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[5]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[96]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-trim-right in k3504 in k3501 */
static void C_ccall f_6669(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3r,(void*)f_6669r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6669r(t0,t1,t2,t3);}}

static void C_ccall f_6669r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(8);
t4=(C_word)C_i_nullp(t3);
t5=(C_truep(t4)?*((C_word*)lf[91]+1):(C_word)C_u_i_car(t3));
t6=(C_word)C_i_nullp(t3);
t7=(C_truep(t6)?C_SCHEME_END_OF_LIST:(C_word)C_slot(t3,C_fix(1)));
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6681,a[2]=t7,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6687,a[2]=t5,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t8,t9);}

/* a6686 in string-trim-right in k3504 in k3501 */
static void C_ccall f_6687(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6687,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6691,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-13.scm: 1121 string-skip-right */
t5=*((C_word*)lf[95]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t4,((C_word*)t0)[3],((C_word*)t0)[2],t2,t3);}

/* k6689 in a6686 in string-trim-right in k3504 in k3501 */
static void C_ccall f_6691(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_u_fixnum_plus(C_fix(1),t1);
/* srfi-13.scm: 1122 %substring/shared */
f_3714(((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0),t2);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[94]);}}

/* a6680 in string-trim-right in k3504 in k3501 */
static void C_ccall f_6681(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6681,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[5]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[93]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-trim in k3504 in k3501 */
static void C_ccall f_6627(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3r,(void*)f_6627r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6627r(t0,t1,t2,t3);}}

static void C_ccall f_6627r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(8);
t4=(C_word)C_i_nullp(t3);
t5=(C_truep(t4)?*((C_word*)lf[91]+1):(C_word)C_u_i_car(t3));
t6=(C_word)C_i_nullp(t3);
t7=(C_truep(t6)?C_SCHEME_END_OF_LIST:(C_word)C_slot(t3,C_fix(1)));
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6639,a[2]=t7,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6645,a[2]=t5,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t8,t9);}

/* a6644 in string-trim in k3504 in k3501 */
static void C_ccall f_6645(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6645,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6649,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* srfi-13.scm: 1114 string-skip */
t5=*((C_word*)lf[81]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t4,((C_word*)t0)[3],((C_word*)t0)[2],t2,t3);}

/* k6647 in a6644 in string-trim in k3504 in k3501 */
static void C_ccall f_6649(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* srfi-13.scm: 1115 %substring/shared */
f_3714(((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[92]);}}

/* a6638 in string-trim in k3504 in k3501 */
static void C_ccall f_6639(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6639,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[5]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[90]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-drop-right in k3504 in k3501 */
static void C_ccall f_6600(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6600,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[89]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6607,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_block_size(t2);
t7=(C_word)C_u_fixnum_plus(C_fix(1),t6);
/* srfi-13.scm: 1104 ##sys#check-range */
t8=*((C_word*)lf[86]+1);
((C_proc6)(void*)(*((C_word*)t8+1)))(6,t8,t5,t3,C_fix(0),t7,lf[89]);}

/* k6605 in string-drop-right in k3504 in k3501 */
static void C_ccall f_6607(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_block_size(((C_word*)t0)[4]);
t3=(C_word)C_u_fixnum_difference(t2,((C_word*)t0)[3]);
/* srfi-13.scm: 1108 %substring/shared */
f_3714(((C_word*)t0)[2],((C_word*)t0)[4],C_fix(0),t3);}

/* string-drop in k3504 in k3501 */
static void C_ccall f_6577(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6577,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[88]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6584,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_block_size(t2);
t7=(C_word)C_u_fixnum_plus(C_fix(1),t6);
/* srfi-13.scm: 1095 ##sys#check-range */
t8=*((C_word*)lf[86]+1);
((C_proc6)(void*)(*((C_word*)t8+1)))(6,t8,t5,t3,C_fix(0),t7,lf[88]);}

/* k6582 in string-drop in k3504 in k3501 */
static void C_ccall f_6584(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_block_size(((C_word*)t0)[4]);
/* srfi-13.scm: 1099 %substring/shared */
f_3714(((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[2],t2);}

/* string-take-right in k3504 in k3501 */
static void C_ccall f_6550(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6550,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[87]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6557,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_block_size(t2);
t7=(C_word)C_u_fixnum_plus(C_fix(1),t6);
/* srfi-13.scm: 1086 ##sys#check-range */
t8=*((C_word*)lf[86]+1);
((C_proc6)(void*)(*((C_word*)t8+1)))(6,t8,t5,t3,C_fix(0),t7,lf[87]);}

/* k6555 in string-take-right in k3504 in k3501 */
static void C_ccall f_6557(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_block_size(((C_word*)t0)[4]);
t3=(C_word)C_u_fixnum_difference(t2,((C_word*)t0)[3]);
/* srfi-13.scm: 1090 %substring/shared */
f_3714(((C_word*)t0)[2],((C_word*)t0)[4],t3,t2);}

/* string-take in k3504 in k3501 */
static void C_ccall f_6530(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6530,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[85]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6537,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_block_size(t2);
t7=(C_word)C_u_fixnum_plus(C_fix(1),t6);
/* srfi-13.scm: 1080 ##sys#check-range */
t8=*((C_word*)lf[86]+1);
((C_proc6)(void*)(*((C_word*)t8+1)))(6,t8,t5,t3,C_fix(0),t7,lf[85]);}

/* k6535 in string-take in k3504 in k3501 */
static void C_ccall f_6537(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-13.scm: 1081 %substring/shared */
f_3714(((C_word*)t0)[4],((C_word*)t0)[3],C_fix(0),((C_word*)t0)[2]);}

/* string-titlecase in k3504 in k3501 */
static void C_ccall f_6505(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3r,(void*)f_6505r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6505r(t0,t1,t2,t3);}}

static void C_ccall f_6505r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(7);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6511,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6517,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t4,t5);}

/* a6516 in string-titlecase in k3504 in k3501 */
static void C_ccall f_6517(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6517,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6521,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* srfi-13.scm: 1051 ##sys#substring */
t5=*((C_word*)lf[12]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,((C_word*)t0)[2],t2,t3);}

/* k6519 in a6516 in string-titlecase in k3504 in k3501 */
static void C_ccall f_6521(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6521,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6524,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_u_fixnum_difference(((C_word*)t0)[3],((C_word*)t0)[2]);
/* srfi-13.scm: 1052 %string-titlecase! */
f_6428(t2,t1,C_fix(0),t3);}

/* k6522 in k6519 in a6516 in string-titlecase in k3504 in k3501 */
static void C_ccall f_6524(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* a6510 in string-titlecase in k3504 in k3501 */
static void C_ccall f_6511(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6511,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[5]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[83]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-titlecase! in k3504 in k3501 */
static void C_ccall f_6487(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3r,(void*)f_6487r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6487r(t0,t1,t2,t3);}}

static void C_ccall f_6487r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(7);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6493,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6499,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t4,t5);}

/* a6498 in string-titlecase! in k3504 in k3501 */
static void C_ccall f_6499(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6499,4,t0,t1,t2,t3);}
/* srfi-13.scm: 1047 %string-titlecase! */
f_6428(t1,((C_word*)t0)[2],t2,t3);}

/* a6492 in string-titlecase! in k3504 in k3501 */
static void C_ccall f_6493(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6493,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[5]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[83]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* %string-titlecase! in k3504 in k3501 */
static void C_fcall f_6428(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6428,NULL,4,t1,t2,t3,t4);}
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6434,a[2]=t4,a[3]=t6,a[4]=t2,tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_6434(t8,t1,t3);}

/* lp in %string-titlecase! in k3504 in k3501 */
static void C_fcall f_6434(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6434,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6438,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6481,tmp=(C_word)a,a+=2,tmp);
/* srfi-13.scm: 1035 string-index */
t5=*((C_word*)lf[82]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t3,((C_word*)t0)[4],t4,t2,((C_word*)t0)[2]);}

/* a6480 in lp in %string-titlecase! in k3504 in k3501 */
static void C_ccall f_6481(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6481,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_u_i_char_alphabeticp(t2));}

/* k6436 in lp in %string-titlecase! in k3504 in k3501 */
static void C_ccall f_6438(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6438,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_subchar(((C_word*)t0)[5],t1);
t3=(C_word)C_u_i_char_upcase(t2);
t4=(C_word)C_setsubchar(((C_word*)t0)[5],t1,t3);
t5=(C_word)C_u_fixnum_plus(t1,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6450,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t7=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6468,tmp=(C_word)a,a+=2,tmp);
/* srfi-13.scm: 1039 string-skip */
t8=*((C_word*)lf[81]+1);
((C_proc6)(void*)(*((C_word*)t8+1)))(6,t8,t6,((C_word*)t0)[5],t7,t5,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* a6467 in k6436 in lp in %string-titlecase! in k3504 in k3501 */
static void C_ccall f_6468(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6468,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_u_i_char_alphabeticp(t2));}

/* k6448 in k6436 in lp in %string-titlecase! in k3504 in k3501 */
static void C_ccall f_6450(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6450,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6456,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* srfi-13.scm: 1041 string-downcase! */
t3=*((C_word*)lf[79]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[4],((C_word*)t0)[3],t1);}
else{
/* srfi-13.scm: 1043 string-downcase! */
t2=*((C_word*)lf[79]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k6454 in k6448 in k6436 in lp in %string-titlecase! in k3504 in k3501 */
static void C_ccall f_6456(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* srfi-13.scm: 1042 lp */
t3=((C_word*)((C_word*)t0)[3])[1];
f_6434(t3,((C_word*)t0)[2],t2);}

/* string-downcase! in k3504 in k3501 */
static void C_ccall f_6410(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3r,(void*)f_6410r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6410r(t0,t1,t2,t3);}}

static void C_ccall f_6410r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(7);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6416,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6422,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t4,t5);}

/* a6421 in string-downcase! in k3504 in k3501 */
static void C_ccall f_6422(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6422,4,t0,t1,t2,t3);}
/* srfi-13.scm: 1031 %string-map! */
f_3833(t1,*((C_word*)lf[78]+1),((C_word*)t0)[2],t2,t3);}

/* a6415 in string-downcase! in k3504 in k3501 */
static void C_ccall f_6416(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6416,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[5]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[79]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-downcase in k3504 in k3501 */
static void C_ccall f_6392(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3r,(void*)f_6392r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6392r(t0,t1,t2,t3);}}

static void C_ccall f_6392r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(7);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6398,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6404,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t4,t5);}

/* a6403 in string-downcase in k3504 in k3501 */
static void C_ccall f_6404(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6404,4,t0,t1,t2,t3);}
/* srfi-13.scm: 1027 %string-map */
f_3772(t1,*((C_word*)lf[78]+1),((C_word*)t0)[2],t2,t3);}

/* a6397 in string-downcase in k3504 in k3501 */
static void C_ccall f_6398(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6398,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[5]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[77]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-upcase! in k3504 in k3501 */
static void C_ccall f_6374(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3r,(void*)f_6374r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6374r(t0,t1,t2,t3);}}

static void C_ccall f_6374r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(7);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6380,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6386,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t4,t5);}

/* a6385 in string-upcase! in k3504 in k3501 */
static void C_ccall f_6386(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6386,4,t0,t1,t2,t3);}
/* srfi-13.scm: 1023 %string-map! */
f_3833(t1,*((C_word*)lf[75]+1),((C_word*)t0)[2],t2,t3);}

/* a6379 in string-upcase! in k3504 in k3501 */
static void C_ccall f_6380(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6380,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[5]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[76]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-upcase in k3504 in k3501 */
static void C_ccall f_6356(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3r,(void*)f_6356r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6356r(t0,t1,t2,t3);}}

static void C_ccall f_6356r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(7);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6362,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6368,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t4,t5);}

/* a6367 in string-upcase in k3504 in k3501 */
static void C_ccall f_6368(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6368,4,t0,t1,t2,t3);}
/* srfi-13.scm: 1019 %string-map */
f_3772(t1,*((C_word*)lf[75]+1),((C_word*)t0)[2],t2,t3);}

/* a6361 in string-upcase in k3504 in k3501 */
static void C_ccall f_6362(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6362,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[5]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[74]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-hash-ci in k3504 in k3501 */
static void C_ccall f_6300(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3r,(void*)f_6300r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6300r(t0,t1,t2,t3);}}

static void C_ccall f_6300r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a=C_alloc(8);
t4=(C_word)C_i_nullp(t3);
t5=(C_truep(t4)?C_fix(4194304):(C_word)C_u_i_car(t3));
t6=t5;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(C_word)C_i_nullp(t3);
t9=(C_truep(t8)?C_SCHEME_END_OF_LIST:(C_word)C_slot(t3,C_fix(1)));
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6310,a[2]=t1,a[3]=t9,a[4]=t2,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
t11=(C_word)C_eqp(((C_word*)t7)[1],C_fix(0));
if(C_truep(t11)){
t12=C_set_block_item(t7,0,C_fix(4194304));
t13=t10;
f_6310(t13,t12);}
else{
t12=t10;
f_6310(t12,C_SCHEME_UNDEFINED);}}

/* k6308 in string-hash-ci in k3504 in k3501 */
static void C_fcall f_6310(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6310,NULL,2,t0,t1);}
t2=(C_word)C_i_check_exact_2(((C_word*)((C_word*)t0)[5])[1],lf[73]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6318,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6324,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,((C_word*)t0)[2],t3,t4);}

/* a6323 in k6308 in string-hash-ci in k3504 in k3501 */
static void C_ccall f_6324(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6324,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6330,tmp=(C_word)a,a+=2,tmp);
/* srfi-13.scm: 1002 %string-hash */
f_6182(t1,((C_word*)t0)[3],t4,((C_word*)((C_word*)t0)[2])[1],t2,t3);}

/* a6329 in a6323 in k6308 in string-hash-ci in k3504 in k3501 */
static void C_ccall f_6330(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6330,3,t0,t1,t2);}
t3=(C_word)C_u_i_char_downcase(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_fix((C_word)C_character_code(t3)));}

/* a6317 in k6308 in string-hash-ci in k3504 in k3501 */
static void C_ccall f_6318(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6318,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[5]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[73]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-hash in k3504 in k3501 */
static void C_ccall f_6254(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3r,(void*)f_6254r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6254r(t0,t1,t2,t3);}}

static void C_ccall f_6254r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a=C_alloc(8);
t4=(C_word)C_i_nullp(t3);
t5=(C_truep(t4)?C_fix(4194304):(C_word)C_u_i_car(t3));
t6=t5;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(C_word)C_i_nullp(t3);
t9=(C_truep(t8)?C_SCHEME_END_OF_LIST:(C_word)C_slot(t3,C_fix(1)));
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6264,a[2]=t1,a[3]=t9,a[4]=t2,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
t11=(C_word)C_eqp(((C_word*)t7)[1],C_fix(0));
if(C_truep(t11)){
t12=C_set_block_item(t7,0,C_fix(4194304));
t13=t10;
f_6264(t13,t12);}
else{
t12=t10;
f_6264(t12,C_SCHEME_UNDEFINED);}}

/* k6262 in string-hash in k3504 in k3501 */
static void C_fcall f_6264(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6264,NULL,2,t0,t1);}
t2=(C_word)C_i_check_exact_2(((C_word*)((C_word*)t0)[5])[1],lf[71]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6272,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6278,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,((C_word*)t0)[2],t3,t4);}

/* a6277 in k6262 in string-hash in k3504 in k3501 */
static void C_ccall f_6278(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6278,4,t0,t1,t2,t3);}
/* srfi-13.scm: 992  %string-hash */
f_6182(t1,((C_word*)t0)[3],*((C_word*)lf[72]+1),((C_word*)((C_word*)t0)[2])[1],t2,t3);}

/* a6271 in k6262 in string-hash in k3504 in k3501 */
static void C_ccall f_6272(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6272,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[5]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[71]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* %string-hash in k3504 in k3501 */
static void C_fcall f_6182(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6182,NULL,6,t1,t2,t3,t4,t5,t6);}
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6184,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6235,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t9=f_6235(t8,C_fix(65536));
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6200,a[2]=t2,a[3]=t7,a[4]=t11,a[5]=t9,a[6]=t4,a[7]=t6,tmp=(C_word)a,a+=8,tmp));
t13=((C_word*)t11)[1];
f_6200(t13,t1,t5,C_fix(0));}

/* lp in %string-hash in k3504 in k3501 */
static void C_fcall f_6200(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6200,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=((C_word*)t0)[7];
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t4,t5))){
/* srfi-13.scm: 981  modulo */
t6=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t1,t3,((C_word*)t0)[6]);}
else{
t6=(C_word)C_u_fixnum_plus(t2,C_fix(1));
t7=(C_word)C_fixnum_times(C_fix(37),t3);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6233,a[2]=t6,a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t7,tmp=(C_word)a,a+=7,tmp);
/* srfi-13.scm: 982  iref */
t9=((C_word*)t0)[3];
f_6184(t9,t8,((C_word*)t0)[2],t2);}}

/* k6231 in lp in %string-hash in k3504 in k3501 */
static void C_ccall f_6233(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[6],t1);
t3=(C_word)C_u_fixnum_and(((C_word*)t0)[5],t2);
/* srfi-13.scm: 982  lp */
t4=((C_word*)((C_word*)t0)[4])[1];
f_6200(t4,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* lp in %string-hash in k3504 in k3501 */
static C_word C_fcall f_6235(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
loop:
t2=t1;
t3=((C_word*)t0)[2];
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,t3))){
return((C_word)C_u_fixnum_difference(t1,C_fix(1)));}
else{
t4=(C_word)C_u_fixnum_plus(t1,t1);
t6=t4;
t1=t6;
goto loop;}}

/* iref in %string-hash in k3504 in k3501 */
static void C_fcall f_6184(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6184,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_subchar(t2,t3);
/* srfi-13.scm: 976  char->int */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t1,t4);}

/* string-ci>= in k3504 in k3501 */
static void C_ccall f_6134(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr4r,(void*)f_6134r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_6134r(t0,t1,t2,t3,t4);}}

static void C_ccall f_6134r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(10);
t5=*((C_word*)lf[68]+1);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6140,a[2]=t4,a[3]=t2,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6146,a[2]=t2,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t6,t7);}

/* a6145 in string-ci>= in k3504 in k3501 */
static void C_ccall f_6146(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6146,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6152,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6158,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t5,t6);}

/* a6157 in a6145 in string-ci>= in k3504 in k3501 */
static void C_ccall f_6158(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6158,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6165,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,a[7]=t3,a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
t5=(C_word)C_eqp(((C_word*)t0)[4],((C_word*)t0)[2]);
if(C_truep(t5)){
t6=((C_word*)t0)[3];
t7=t2;
t8=t4;
f_6165(t8,(C_word)C_eqp(t6,t7));}
else{
t6=t4;
f_6165(t6,C_SCHEME_FALSE);}}

/* k6163 in a6157 in a6145 in string-ci>= in k3504 in k3501 */
static void C_fcall f_6165(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6165,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
t3=((C_word*)t0)[7];
t4=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_fixnum_greater_or_equal_p(t2,t3));}
else{
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6173,tmp=(C_word)a,a+=2,tmp);
/* srfi-13.scm: 956  %string-compare-ci */
f_5406(((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[8],((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[7],t2,*((C_word*)lf[57]+1),*((C_word*)lf[57]+1));}}

/* a6172 in k6163 in a6157 in a6145 in string-ci>= in k3504 in k3501 */
static void C_ccall f_6173(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6173,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}

/* a6151 in a6145 in string-ci>= in k3504 in k3501 */
static void C_ccall f_6152(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6152,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[5]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a6139 in string-ci>= in k3504 in k3501 */
static void C_ccall f_6140(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6140,2,t0,t1);}
/* string-parse-start+end */
t2=*((C_word*)lf[0]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-ci<= in k3504 in k3501 */
static void C_ccall f_6086(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr4r,(void*)f_6086r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_6086r(t0,t1,t2,t3,t4);}}

static void C_ccall f_6086r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(10);
t5=*((C_word*)lf[67]+1);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6092,a[2]=t4,a[3]=t2,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6098,a[2]=t2,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t6,t7);}

/* a6097 in string-ci<= in k3504 in k3501 */
static void C_ccall f_6098(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6098,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6104,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6110,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t5,t6);}

/* a6109 in a6097 in string-ci<= in k3504 in k3501 */
static void C_ccall f_6110(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6110,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6117,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,a[7]=t3,a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
t5=(C_word)C_eqp(((C_word*)t0)[4],((C_word*)t0)[2]);
if(C_truep(t5)){
t6=((C_word*)t0)[3];
t7=t2;
t8=t4;
f_6117(t8,(C_word)C_eqp(t6,t7));}
else{
t6=t4;
f_6117(t6,C_SCHEME_FALSE);}}

/* k6115 in a6109 in a6097 in string-ci<= in k3504 in k3501 */
static void C_fcall f_6117(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6117,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
t3=((C_word*)t0)[7];
t4=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_fixnum_less_or_equal_p(t2,t3));}
else{
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6125,tmp=(C_word)a,a+=2,tmp);
/* srfi-13.scm: 945  %string-compare-ci */
f_5406(((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[8],((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[7],*((C_word*)lf[57]+1),*((C_word*)lf[57]+1),t2);}}

/* a6124 in k6115 in a6109 in a6097 in string-ci<= in k3504 in k3501 */
static void C_ccall f_6125(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6125,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}

/* a6103 in a6097 in string-ci<= in k3504 in k3501 */
static void C_ccall f_6104(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6104,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[5]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a6091 in string-ci<= in k3504 in k3501 */
static void C_ccall f_6092(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6092,2,t0,t1);}
/* string-parse-start+end */
t2=*((C_word*)lf[0]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-ci> in k3504 in k3501 */
static void C_ccall f_6035(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr4r,(void*)f_6035r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_6035r(t0,t1,t2,t3,t4);}}

static void C_ccall f_6035r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(10);
t5=*((C_word*)lf[66]+1);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6041,a[2]=t4,a[3]=t2,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6047,a[2]=t2,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t6,t7);}

/* a6046 in string-ci> in k3504 in k3501 */
static void C_ccall f_6047(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6047,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6053,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6059,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t5,t6);}

/* a6058 in a6046 in string-ci> in k3504 in k3501 */
static void C_ccall f_6059(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6059,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6066,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,a[7]=t3,a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
t5=(C_word)C_eqp(((C_word*)t0)[4],((C_word*)t0)[2]);
if(C_truep(t5)){
t6=((C_word*)t0)[3];
t7=t2;
t8=t4;
f_6066(t8,(C_word)C_eqp(t6,t7));}
else{
t6=t4;
f_6066(t6,C_SCHEME_FALSE);}}

/* k6064 in a6058 in a6046 in string-ci> in k3504 in k3501 */
static void C_fcall f_6066(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6066,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
t3=((C_word*)t0)[7];
t4=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_fixnum_greaterp(t2,t3));}
else{
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6074,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6077,tmp=(C_word)a,a+=2,tmp);
/* srfi-13.scm: 934  %string-compare-ci */
f_5406(((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[8],((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[7],t2,t3,*((C_word*)lf[57]+1));}}

/* a6076 in k6064 in a6058 in a6046 in string-ci> in k3504 in k3501 */
static void C_ccall f_6077(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6077,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}

/* a6073 in k6064 in a6058 in a6046 in string-ci> in k3504 in k3501 */
static void C_ccall f_6074(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6074,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}

/* a6052 in a6046 in string-ci> in k3504 in k3501 */
static void C_ccall f_6053(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6053,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[5]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a6040 in string-ci> in k3504 in k3501 */
static void C_ccall f_6041(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6041,2,t0,t1);}
/* string-parse-start+end */
t2=*((C_word*)lf[0]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-ci< in k3504 in k3501 */
static void C_ccall f_5984(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr4r,(void*)f_5984r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5984r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5984r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(10);
t5=*((C_word*)lf[65]+1);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5990,a[2]=t4,a[3]=t2,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5996,a[2]=t2,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t6,t7);}

/* a5995 in string-ci< in k3504 in k3501 */
static void C_ccall f_5996(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5996,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6002,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6008,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t5,t6);}

/* a6007 in a5995 in string-ci< in k3504 in k3501 */
static void C_ccall f_6008(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6008,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6015,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,a[7]=t3,a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
t5=(C_word)C_eqp(((C_word*)t0)[4],((C_word*)t0)[2]);
if(C_truep(t5)){
t6=((C_word*)t0)[3];
t7=t2;
t8=t4;
f_6015(t8,(C_word)C_eqp(t6,t7));}
else{
t6=t4;
f_6015(t6,C_SCHEME_FALSE);}}

/* k6013 in a6007 in a5995 in string-ci< in k3504 in k3501 */
static void C_fcall f_6015(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6015,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
t3=((C_word*)t0)[7];
t4=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_fixnum_lessp(t2,t3));}
else{
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6023,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6026,tmp=(C_word)a,a+=2,tmp);
/* srfi-13.scm: 923  %string-compare-ci */
f_5406(((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[8],((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[7],*((C_word*)lf[57]+1),t2,t3);}}

/* a6025 in k6013 in a6007 in a5995 in string-ci< in k3504 in k3501 */
static void C_ccall f_6026(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6026,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}

/* a6022 in k6013 in a6007 in a5995 in string-ci< in k3504 in k3501 */
static void C_ccall f_6023(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6023,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}

/* a6001 in a5995 in string-ci< in k3504 in k3501 */
static void C_ccall f_6002(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6002,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[5]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5989 in string-ci< in k3504 in k3501 */
static void C_ccall f_5990(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5990,2,t0,t1);}
/* string-parse-start+end */
t2=*((C_word*)lf[0]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-ci<> in k3504 in k3501 */
static void C_ccall f_5917(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr4r,(void*)f_5917r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5917r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5917r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(10);
t5=*((C_word*)lf[64]+1);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5923,a[2]=t4,a[3]=t2,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5929,a[2]=t2,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t6,t7);}

/* a5928 in string-ci<> in k3504 in k3501 */
static void C_ccall f_5929(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5929,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5935,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5941,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t5,t6);}

/* a5940 in a5928 in string-ci<> in k3504 in k3501 */
static void C_ccall f_5941(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5941,4,t0,t1,t2,t3);}
t4=(C_word)C_u_fixnum_difference(((C_word*)t0)[5],((C_word*)t0)[4]);
t5=(C_word)C_u_fixnum_difference(t3,t2);
t6=(C_word)C_eqp(t4,t5);
t7=(C_word)C_i_not(t6);
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}
else{
t8=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5964,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[3],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t9=(C_word)C_eqp(((C_word*)t0)[3],((C_word*)t0)[2]);
if(C_truep(t9)){
t10=((C_word*)t0)[4];
t11=t2;
t12=t8;
f_5964(t12,(C_word)C_eqp(t10,t11));}
else{
t10=t8;
f_5964(t10,C_SCHEME_FALSE);}}}

/* k5962 in a5940 in a5928 in string-ci<> in k3504 in k3501 */
static void C_fcall f_5964(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5964,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5959,tmp=(C_word)a,a+=2,tmp);
/* srfi-13.scm: 912  %string-compare-ci */
f_5406(((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],*((C_word*)lf[57]+1),t2,*((C_word*)lf[57]+1));}}

/* a5958 in k5962 in a5940 in a5928 in string-ci<> in k3504 in k3501 */
static void C_ccall f_5959(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5959,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}

/* a5934 in a5928 in string-ci<> in k3504 in k3501 */
static void C_ccall f_5935(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5935,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[5]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5922 in string-ci<> in k3504 in k3501 */
static void C_ccall f_5923(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5923,2,t0,t1);}
/* string-parse-start+end */
t2=*((C_word*)lf[0]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-ci= in k3504 in k3501 */
static void C_ccall f_5855(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr4r,(void*)f_5855r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5855r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5855r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(10);
t5=*((C_word*)lf[63]+1);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5861,a[2]=t4,a[3]=t2,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5867,a[2]=t2,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t6,t7);}

/* a5866 in string-ci= in k3504 in k3501 */
static void C_ccall f_5867(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5867,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5873,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5879,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t5,t6);}

/* a5878 in a5866 in string-ci= in k3504 in k3501 */
static void C_ccall f_5879(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5879,4,t0,t1,t2,t3);}
t4=(C_word)C_u_fixnum_difference(((C_word*)t0)[5],((C_word*)t0)[4]);
t5=(C_word)C_u_fixnum_difference(t3,t2);
t6=(C_word)C_eqp(t4,t5);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5889,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[3],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t8=(C_word)C_eqp(((C_word*)t0)[3],((C_word*)t0)[2]);
if(C_truep(t8)){
t9=((C_word*)t0)[4];
t10=t2;
t11=t7;
f_5889(t11,(C_word)C_eqp(t9,t10));}
else{
t9=t7;
f_5889(t9,C_SCHEME_FALSE);}}
else{
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_SCHEME_FALSE);}}

/* k5887 in a5878 in a5866 in string-ci= in k3504 in k3501 */
static void C_fcall f_5889(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5889,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5897,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5900,tmp=(C_word)a,a+=2,tmp);
/* srfi-13.scm: 902  %string-compare-ci */
f_5406(((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2,*((C_word*)lf[57]+1),t3);}}

/* a5899 in k5887 in a5878 in a5866 in string-ci= in k3504 in k3501 */
static void C_ccall f_5900(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5900,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}

/* a5896 in k5887 in a5878 in a5866 in string-ci= in k3504 in k3501 */
static void C_ccall f_5897(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5897,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}

/* a5872 in a5866 in string-ci= in k3504 in k3501 */
static void C_ccall f_5873(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5873,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[5]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5860 in string-ci= in k3504 in k3501 */
static void C_ccall f_5861(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5861,2,t0,t1);}
/* string-parse-start+end */
t2=*((C_word*)lf[0]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string>= in k3504 in k3501 */
static void C_ccall f_5807(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr4r,(void*)f_5807r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5807r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5807r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(10);
t5=*((C_word*)lf[62]+1);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5813,a[2]=t4,a[3]=t2,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5819,a[2]=t2,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t6,t7);}

/* a5818 in string>= in k3504 in k3501 */
static void C_ccall f_5819(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5819,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5825,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5831,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t5,t6);}

/* a5830 in a5818 in string>= in k3504 in k3501 */
static void C_ccall f_5831(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5831,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5838,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,a[7]=t3,a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
t5=(C_word)C_eqp(((C_word*)t0)[4],((C_word*)t0)[2]);
if(C_truep(t5)){
t6=((C_word*)t0)[3];
t7=t2;
t8=t4;
f_5838(t8,(C_word)C_eqp(t6,t7));}
else{
t6=t4;
f_5838(t6,C_SCHEME_FALSE);}}

/* k5836 in a5830 in a5818 in string>= in k3504 in k3501 */
static void C_fcall f_5838(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5838,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
t3=((C_word*)t0)[7];
t4=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_fixnum_greater_or_equal_p(t2,t3));}
else{
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5846,tmp=(C_word)a,a+=2,tmp);
/* srfi-13.scm: 892  %string-compare */
f_5344(((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[8],((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[7],t2,*((C_word*)lf[57]+1),*((C_word*)lf[57]+1));}}

/* a5845 in k5836 in a5830 in a5818 in string>= in k3504 in k3501 */
static void C_ccall f_5846(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5846,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}

/* a5824 in a5818 in string>= in k3504 in k3501 */
static void C_ccall f_5825(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5825,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[5]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5812 in string>= in k3504 in k3501 */
static void C_ccall f_5813(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5813,2,t0,t1);}
/* string-parse-start+end */
t2=*((C_word*)lf[0]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string<= in k3504 in k3501 */
static void C_ccall f_5759(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr4r,(void*)f_5759r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5759r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5759r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(10);
t5=*((C_word*)lf[61]+1);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5765,a[2]=t4,a[3]=t2,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5771,a[2]=t2,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t6,t7);}

/* a5770 in string<= in k3504 in k3501 */
static void C_ccall f_5771(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5771,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5777,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5783,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t5,t6);}

/* a5782 in a5770 in string<= in k3504 in k3501 */
static void C_ccall f_5783(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5783,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5790,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,a[7]=t3,a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
t5=(C_word)C_eqp(((C_word*)t0)[4],((C_word*)t0)[2]);
if(C_truep(t5)){
t6=((C_word*)t0)[3];
t7=t2;
t8=t4;
f_5790(t8,(C_word)C_eqp(t6,t7));}
else{
t6=t4;
f_5790(t6,C_SCHEME_FALSE);}}

/* k5788 in a5782 in a5770 in string<= in k3504 in k3501 */
static void C_fcall f_5790(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5790,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
t3=((C_word*)t0)[7];
t4=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_fixnum_less_or_equal_p(t2,t3));}
else{
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5798,tmp=(C_word)a,a+=2,tmp);
/* srfi-13.scm: 881  %string-compare */
f_5344(((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[8],((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[7],*((C_word*)lf[57]+1),*((C_word*)lf[57]+1),t2);}}

/* a5797 in k5788 in a5782 in a5770 in string<= in k3504 in k3501 */
static void C_ccall f_5798(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5798,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}

/* a5776 in a5770 in string<= in k3504 in k3501 */
static void C_ccall f_5777(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5777,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[5]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5764 in string<= in k3504 in k3501 */
static void C_ccall f_5765(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5765,2,t0,t1);}
/* string-parse-start+end */
t2=*((C_word*)lf[0]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string> in k3504 in k3501 */
static void C_ccall f_5708(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr4r,(void*)f_5708r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5708r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5708r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(10);
t5=*((C_word*)lf[60]+1);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5714,a[2]=t4,a[3]=t2,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5720,a[2]=t2,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t6,t7);}

/* a5719 in string> in k3504 in k3501 */
static void C_ccall f_5720(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5720,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5726,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5732,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t5,t6);}

/* a5731 in a5719 in string> in k3504 in k3501 */
static void C_ccall f_5732(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5732,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5739,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,a[7]=t3,a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
t5=(C_word)C_eqp(((C_word*)t0)[4],((C_word*)t0)[2]);
if(C_truep(t5)){
t6=((C_word*)t0)[3];
t7=t2;
t8=t4;
f_5739(t8,(C_word)C_eqp(t6,t7));}
else{
t6=t4;
f_5739(t6,C_SCHEME_FALSE);}}

/* k5737 in a5731 in a5719 in string> in k3504 in k3501 */
static void C_fcall f_5739(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5739,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
t3=((C_word*)t0)[7];
t4=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_fixnum_greaterp(t2,t3));}
else{
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5747,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5750,tmp=(C_word)a,a+=2,tmp);
/* srfi-13.scm: 870  %string-compare */
f_5344(((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[8],((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[7],t2,t3,*((C_word*)lf[57]+1));}}

/* a5749 in k5737 in a5731 in a5719 in string> in k3504 in k3501 */
static void C_ccall f_5750(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5750,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}

/* a5746 in k5737 in a5731 in a5719 in string> in k3504 in k3501 */
static void C_ccall f_5747(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5747,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}

/* a5725 in a5719 in string> in k3504 in k3501 */
static void C_ccall f_5726(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5726,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[5]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5713 in string> in k3504 in k3501 */
static void C_ccall f_5714(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5714,2,t0,t1);}
/* string-parse-start+end */
t2=*((C_word*)lf[0]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string< in k3504 in k3501 */
static void C_ccall f_5657(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr4r,(void*)f_5657r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5657r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5657r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(10);
t5=*((C_word*)lf[59]+1);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5663,a[2]=t4,a[3]=t2,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5669,a[2]=t2,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t6,t7);}

/* a5668 in string< in k3504 in k3501 */
static void C_ccall f_5669(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5669,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5675,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5681,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t5,t6);}

/* a5680 in a5668 in string< in k3504 in k3501 */
static void C_ccall f_5681(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5681,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5688,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,a[7]=t3,a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
t5=(C_word)C_eqp(((C_word*)t0)[4],((C_word*)t0)[2]);
if(C_truep(t5)){
t6=((C_word*)t0)[3];
t7=t2;
t8=t4;
f_5688(t8,(C_word)C_eqp(t6,t7));}
else{
t6=t4;
f_5688(t6,C_SCHEME_FALSE);}}

/* k5686 in a5680 in a5668 in string< in k3504 in k3501 */
static void C_fcall f_5688(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5688,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
t3=((C_word*)t0)[7];
t4=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_fixnum_lessp(t2,t3));}
else{
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5696,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5699,tmp=(C_word)a,a+=2,tmp);
/* srfi-13.scm: 859  %string-compare */
f_5344(((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[8],((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[7],*((C_word*)lf[57]+1),t2,t3);}}

/* a5698 in k5686 in a5680 in a5668 in string< in k3504 in k3501 */
static void C_ccall f_5699(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5699,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}

/* a5695 in k5686 in a5680 in a5668 in string< in k3504 in k3501 */
static void C_ccall f_5696(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5696,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}

/* a5674 in a5668 in string< in k3504 in k3501 */
static void C_ccall f_5675(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5675,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[5]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5662 in string< in k3504 in k3501 */
static void C_ccall f_5663(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5663,2,t0,t1);}
/* string-parse-start+end */
t2=*((C_word*)lf[0]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string<> in k3504 in k3501 */
static void C_ccall f_5590(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr4r,(void*)f_5590r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5590r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5590r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(10);
t5=*((C_word*)lf[58]+1);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5596,a[2]=t4,a[3]=t2,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5602,a[2]=t2,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t6,t7);}

/* a5601 in string<> in k3504 in k3501 */
static void C_ccall f_5602(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5602,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5608,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5614,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t5,t6);}

/* a5613 in a5601 in string<> in k3504 in k3501 */
static void C_ccall f_5614(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5614,4,t0,t1,t2,t3);}
t4=(C_word)C_u_fixnum_difference(((C_word*)t0)[5],((C_word*)t0)[4]);
t5=(C_word)C_u_fixnum_difference(t3,t2);
t6=(C_word)C_eqp(t4,t5);
t7=(C_word)C_i_not(t6);
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}
else{
t8=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5637,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[3],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t9=(C_word)C_eqp(((C_word*)t0)[3],((C_word*)t0)[2]);
if(C_truep(t9)){
t10=((C_word*)t0)[4];
t11=t2;
t12=t8;
f_5637(t12,(C_word)C_eqp(t10,t11));}
else{
t10=t8;
f_5637(t10,C_SCHEME_FALSE);}}}

/* k5635 in a5613 in a5601 in string<> in k3504 in k3501 */
static void C_fcall f_5637(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5637,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5632,tmp=(C_word)a,a+=2,tmp);
/* srfi-13.scm: 848  %string-compare */
f_5344(((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],*((C_word*)lf[57]+1),t2,*((C_word*)lf[57]+1));}}

/* a5631 in k5635 in a5613 in a5601 in string<> in k3504 in k3501 */
static void C_ccall f_5632(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5632,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}

/* a5607 in a5601 in string<> in k3504 in k3501 */
static void C_ccall f_5608(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5608,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[5]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5595 in string<> in k3504 in k3501 */
static void C_ccall f_5596(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5596,2,t0,t1);}
/* string-parse-start+end */
t2=*((C_word*)lf[0]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string= in k3504 in k3501 */
static void C_ccall f_5528(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr4r,(void*)f_5528r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5528r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5528r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(10);
t5=*((C_word*)lf[56]+1);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5534,a[2]=t4,a[3]=t2,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5540,a[2]=t2,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t6,t7);}

/* a5539 in string= in k3504 in k3501 */
static void C_ccall f_5540(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5540,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5546,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5552,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t5,t6);}

/* a5551 in a5539 in string= in k3504 in k3501 */
static void C_ccall f_5552(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5552,4,t0,t1,t2,t3);}
t4=(C_word)C_u_fixnum_difference(((C_word*)t0)[5],((C_word*)t0)[4]);
t5=(C_word)C_u_fixnum_difference(t3,t2);
t6=(C_word)C_eqp(t4,t5);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5562,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[3],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t8=(C_word)C_eqp(((C_word*)t0)[3],((C_word*)t0)[2]);
if(C_truep(t8)){
t9=((C_word*)t0)[4];
t10=t2;
t11=t7;
f_5562(t11,(C_word)C_eqp(t9,t10));}
else{
t9=t7;
f_5562(t9,C_SCHEME_FALSE);}}
else{
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_SCHEME_FALSE);}}

/* k5560 in a5551 in a5539 in string= in k3504 in k3501 */
static void C_fcall f_5562(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5562,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5570,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5573,tmp=(C_word)a,a+=2,tmp);
/* srfi-13.scm: 838  %string-compare */
f_5344(((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2,*((C_word*)lf[57]+1),t3);}}

/* a5572 in k5560 in a5551 in a5539 in string= in k3504 in k3501 */
static void C_ccall f_5573(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5573,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}

/* a5569 in k5560 in a5551 in a5539 in string= in k3504 in k3501 */
static void C_ccall f_5570(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5570,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}

/* a5545 in a5539 in string= in k3504 in k3501 */
static void C_ccall f_5546(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5546,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[5]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5533 in string= in k3504 in k3501 */
static void C_ccall f_5534(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5534,2,t0,t1);}
/* string-parse-start+end */
t2=*((C_word*)lf[0]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-compare-ci in k3504 in k3501 */
static void C_ccall f_5498(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,...){
C_word tmp;
C_word t7;
va_list v;
C_word *a,c2=c;
C_save_rest(t6,c2,7);
if(!C_demand(c*C_SIZEOF_PAIR+13)){
C_save_and_reclaim((void*)tr7r,(void*)f_5498r,7,t0,t1,t2,t3,t4,t5,t6);}
else{
a=C_alloc((c-7)*3);
t7=C_restore_rest(a,C_rest_count(0));
f_5498r(t0,t1,t2,t3,t4,t5,t6,t7);}}

static void C_ccall f_5498r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(13);
t8=*((C_word*)lf[55]+1);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5504,a[2]=t7,a[3]=t2,a[4]=t8,tmp=(C_word)a,a+=5,tmp);
t10=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5510,a[2]=t6,a[3]=t5,a[4]=t4,a[5]=t2,a[6]=t3,a[7]=t8,tmp=(C_word)a,a+=8,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t9,t10);}

/* a5509 in string-compare-ci in k3504 in k3501 */
static void C_ccall f_5510(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5510,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5516,a[2]=t2,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5522,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=t4,a[7]=t3,a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t5,t6);}

/* a5521 in a5509 in string-compare-ci in k3504 in k3501 */
static void C_ccall f_5522(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5522,4,t0,t1,t2,t3);}
/* srfi-13.scm: 822  %string-compare-ci */
f_5406(t1,((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],t2,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5515 in a5509 in string-compare-ci in k3504 in k3501 */
static void C_ccall f_5516(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5516,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[5]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5503 in string-compare-ci in k3504 in k3501 */
static void C_ccall f_5504(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5504,2,t0,t1);}
/* string-parse-start+end */
t2=*((C_word*)lf[0]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-compare in k3504 in k3501 */
static void C_ccall f_5468(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,...){
C_word tmp;
C_word t7;
va_list v;
C_word *a,c2=c;
C_save_rest(t6,c2,7);
if(!C_demand(c*C_SIZEOF_PAIR+13)){
C_save_and_reclaim((void*)tr7r,(void*)f_5468r,7,t0,t1,t2,t3,t4,t5,t6);}
else{
a=C_alloc((c-7)*3);
t7=C_restore_rest(a,C_rest_count(0));
f_5468r(t0,t1,t2,t3,t4,t5,t6,t7);}}

static void C_ccall f_5468r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(13);
t8=*((C_word*)lf[54]+1);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5474,a[2]=t7,a[3]=t2,a[4]=t8,tmp=(C_word)a,a+=5,tmp);
t10=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5480,a[2]=t6,a[3]=t5,a[4]=t4,a[5]=t2,a[6]=t3,a[7]=t8,tmp=(C_word)a,a+=8,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t9,t10);}

/* a5479 in string-compare in k3504 in k3501 */
static void C_ccall f_5480(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5480,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5486,a[2]=t2,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5492,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=t4,a[7]=t3,a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t5,t6);}

/* a5491 in a5479 in string-compare in k3504 in k3501 */
static void C_ccall f_5492(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5492,4,t0,t1,t2,t3);}
/* srfi-13.scm: 814  %string-compare */
f_5344(t1,((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],t2,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5485 in a5479 in string-compare in k3504 in k3501 */
static void C_ccall f_5486(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5486,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[5]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5473 in string-compare in k3504 in k3501 */
static void C_ccall f_5474(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5474,2,t0,t1);}
/* string-parse-start+end */
t2=*((C_word*)lf[0]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* %string-compare-ci in k3504 in k3501 */
static void C_fcall f_5406(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9,C_word t10){
C_word tmp;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5406,NULL,10,t1,t2,t3,t4,t5,t6,t7,t8,t9,t10);}
t11=(C_word)C_u_fixnum_difference(t4,t3);
t12=(C_word)C_u_fixnum_difference(t7,t6);
t13=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_5416,a[2]=t5,a[3]=t6,a[4]=t2,a[5]=t10,a[6]=t3,a[7]=t4,a[8]=t1,a[9]=t8,a[10]=t9,a[11]=t12,a[12]=t11,tmp=(C_word)a,a+=13,tmp);
/* srfi-13.scm: 799  %string-prefix-length-ci */
f_4854(t13,t2,t3,t4,t5,t6,t7);}

/* k5414 in %string-compare-ci in k3504 in k3501 */
static void C_ccall f_5416(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5416,2,t0,t1);}
t2=t1;
t3=(C_word)C_eqp(t2,((C_word*)t0)[12]);
if(C_truep(t3)){
t4=t1;
t5=(C_word)C_eqp(t4,((C_word*)t0)[11]);
t6=(C_truep(t5)?((C_word*)t0)[10]:((C_word*)t0)[9]);
t7=t6;
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,((C_word*)t0)[8],((C_word*)t0)[7]);}
else{
t4=(C_word)C_u_fixnum_plus(((C_word*)t0)[6],t1);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5441,a[2]=t4,a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
t6=t1;
t7=(C_word)C_eqp(t6,((C_word*)t0)[11]);
if(C_truep(t7)){
t8=t5;
f_5441(t8,((C_word*)t0)[5]);}
else{
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5450,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[9],a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t9=(C_word)C_u_fixnum_plus(((C_word*)t0)[6],t1);
t10=(C_word)C_subchar(((C_word*)t0)[4],t9);
t11=(C_word)C_u_fixnum_plus(((C_word*)t0)[3],t1);
t12=(C_word)C_subchar(((C_word*)t0)[2],t11);
/* srfi-13.scm: 803  char-ci<? */
t13=*((C_word*)lf[53]+1);
((C_proc4)(void*)(*((C_word*)t13+1)))(4,t13,t8,t10,t12);}}}

/* k5448 in k5414 in %string-compare-ci in k3504 in k3501 */
static void C_ccall f_5450(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[4];
f_5441(t2,(C_truep(t1)?((C_word*)t0)[3]:((C_word*)t0)[2]));}

/* k5439 in k5414 in %string-compare-ci in k3504 in k3501 */
static void C_fcall f_5441(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* %string-compare in k3504 in k3501 */
static void C_fcall f_5344(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9,C_word t10){
C_word tmp;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5344,NULL,10,t1,t2,t3,t4,t5,t6,t7,t8,t9,t10);}
t11=(C_word)C_u_fixnum_difference(t4,t3);
t12=(C_word)C_u_fixnum_difference(t7,t6);
t13=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_5354,a[2]=t5,a[3]=t6,a[4]=t2,a[5]=t10,a[6]=t3,a[7]=t4,a[8]=t1,a[9]=t8,a[10]=t9,a[11]=t12,a[12]=t11,tmp=(C_word)a,a+=13,tmp);
/* srfi-13.scm: 785  %string-prefix-length */
f_4696(t13,t2,t3,t4,t5,t6,t7);}

/* k5352 in %string-compare in k3504 in k3501 */
static void C_ccall f_5354(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5354,2,t0,t1);}
t2=t1;
t3=(C_word)C_eqp(t2,((C_word*)t0)[12]);
if(C_truep(t3)){
t4=t1;
t5=(C_word)C_eqp(t4,((C_word*)t0)[11]);
t6=(C_truep(t5)?((C_word*)t0)[10]:((C_word*)t0)[9]);
t7=t6;
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,((C_word*)t0)[8],((C_word*)t0)[7]);}
else{
t4=(C_word)C_u_fixnum_plus(t1,((C_word*)t0)[6]);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5379,a[2]=t4,a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
t6=t1;
t7=(C_word)C_eqp(t6,((C_word*)t0)[11]);
if(C_truep(t7)){
t8=t5;
f_5379(t8,((C_word*)t0)[5]);}
else{
t8=(C_word)C_u_fixnum_plus(((C_word*)t0)[6],t1);
t9=(C_word)C_subchar(((C_word*)t0)[4],t8);
t10=(C_word)C_u_fixnum_plus(((C_word*)t0)[3],t1);
t11=(C_word)C_subchar(((C_word*)t0)[2],t10);
t12=(C_word)C_fixnum_lessp(t9,t11);
t13=t5;
f_5379(t13,(C_truep(t12)?((C_word*)t0)[9]:((C_word*)t0)[5]));}}}

/* k5377 in k5352 in %string-compare in k3504 in k3501 */
static void C_fcall f_5379(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-suffix-ci? in k3504 in k3501 */
static void C_ccall f_5222(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr4r,(void*)f_5222r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5222r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5222r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(10);
t5=*((C_word*)lf[50]+1);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5228,a[2]=t4,a[3]=t2,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5234,a[2]=t2,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t6,t7);}

/* a5233 in string-suffix-ci? in k3504 in k3501 */
static void C_ccall f_5234(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5234,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5240,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5246,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t3,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t5,t6);}

/* a5245 in a5233 in string-suffix-ci? in k3504 in k3501 */
static void C_ccall f_5246(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5246,4,t0,t1,t2,t3);}
t4=((C_word*)t0)[5];
t5=((C_word*)t0)[4];
t6=((C_word*)t0)[3];
t7=((C_word*)t0)[2];
t8=(C_word)C_u_fixnum_difference(t6,t5);
t9=(C_word)C_u_fixnum_difference(t3,t2);
if(C_truep((C_word)C_fixnum_less_or_equal_p(t8,t9))){
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5338,a[2]=t8,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-13.scm: 769  %string-suffix-length-ci */
f_4927(t10,t4,t5,t6,t7,t2,t3);}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}}

/* k5336 in a5245 in a5233 in string-suffix-ci? in k3504 in k3501 */
static void C_ccall f_5338(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_eqp(((C_word*)t0)[2],t1));}

/* a5239 in a5233 in string-suffix-ci? in k3504 in k3501 */
static void C_ccall f_5240(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5240,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[5]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5227 in string-suffix-ci? in k3504 in k3501 */
static void C_ccall f_5228(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5228,2,t0,t1);}
/* string-parse-start+end */
t2=*((C_word*)lf[0]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-prefix-ci? in k3504 in k3501 */
static void C_ccall f_5192(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr4r,(void*)f_5192r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5192r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5192r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(10);
t5=*((C_word*)lf[49]+1);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5198,a[2]=t4,a[3]=t2,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5204,a[2]=t2,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t6,t7);}

/* a5203 in string-prefix-ci? in k3504 in k3501 */
static void C_ccall f_5204(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5204,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5210,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5216,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t3,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t5,t6);}

/* a5215 in a5203 in string-prefix-ci? in k3504 in k3501 */
static void C_ccall f_5216(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5216,4,t0,t1,t2,t3);}
t4=((C_word*)t0)[5];
t5=((C_word*)t0)[4];
t6=((C_word*)t0)[3];
t7=((C_word*)t0)[2];
t8=(C_word)C_u_fixnum_difference(t6,t5);
t9=(C_word)C_u_fixnum_difference(t3,t2);
if(C_truep((C_word)C_fixnum_less_or_equal_p(t8,t9))){
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5315,a[2]=t8,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-13.scm: 763  %string-prefix-length-ci */
f_4854(t10,t4,t5,t6,t7,t2,t3);}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}}

/* k5313 in a5215 in a5203 in string-prefix-ci? in k3504 in k3501 */
static void C_ccall f_5315(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_eqp(((C_word*)t0)[2],t1));}

/* a5209 in a5203 in string-prefix-ci? in k3504 in k3501 */
static void C_ccall f_5210(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5210,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[5]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5197 in string-prefix-ci? in k3504 in k3501 */
static void C_ccall f_5198(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5198,2,t0,t1);}
/* string-parse-start+end */
t2=*((C_word*)lf[0]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-suffix? in k3504 in k3501 */
static void C_ccall f_5162(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr4r,(void*)f_5162r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5162r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5162r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(10);
t5=*((C_word*)lf[48]+1);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5168,a[2]=t4,a[3]=t2,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5174,a[2]=t2,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t6,t7);}

/* a5173 in string-suffix? in k3504 in k3501 */
static void C_ccall f_5174(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5174,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5180,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5186,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t3,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t5,t6);}

/* a5185 in a5173 in string-suffix? in k3504 in k3501 */
static void C_ccall f_5186(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5186,4,t0,t1,t2,t3);}
t4=((C_word*)t0)[5];
t5=((C_word*)t0)[4];
t6=((C_word*)t0)[3];
t7=((C_word*)t0)[2];
t8=(C_word)C_u_fixnum_difference(t6,t5);
t9=(C_word)C_u_fixnum_difference(t3,t2);
if(C_truep((C_word)C_fixnum_less_or_equal_p(t8,t9))){
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5292,a[2]=t8,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-13.scm: 757  %string-suffix-length */
f_4769(t10,t4,t5,t6,t7,t2,t3);}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}}

/* k5290 in a5185 in a5173 in string-suffix? in k3504 in k3501 */
static void C_ccall f_5292(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_eqp(((C_word*)t0)[2],t1));}

/* a5179 in a5173 in string-suffix? in k3504 in k3501 */
static void C_ccall f_5180(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5180,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[5]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5167 in string-suffix? in k3504 in k3501 */
static void C_ccall f_5168(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5168,2,t0,t1);}
/* string-parse-start+end */
t2=*((C_word*)lf[0]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-prefix? in k3504 in k3501 */
static void C_ccall f_5132(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr4r,(void*)f_5132r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5132r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5132r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(10);
t5=*((C_word*)lf[47]+1);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5138,a[2]=t4,a[3]=t2,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5144,a[2]=t2,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t6,t7);}

/* a5143 in string-prefix? in k3504 in k3501 */
static void C_ccall f_5144(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5144,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5150,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5156,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t3,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t5,t6);}

/* a5155 in a5143 in string-prefix? in k3504 in k3501 */
static void C_ccall f_5156(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5156,4,t0,t1,t2,t3);}
t4=((C_word*)t0)[5];
t5=((C_word*)t0)[4];
t6=((C_word*)t0)[3];
t7=((C_word*)t0)[2];
t8=(C_word)C_u_fixnum_difference(t6,t5);
t9=(C_word)C_u_fixnum_difference(t3,t2);
if(C_truep((C_word)C_fixnum_less_or_equal_p(t8,t9))){
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5269,a[2]=t8,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-13.scm: 750  %string-prefix-length */
f_4696(t10,t4,t5,t6,t7,t2,t3);}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}}

/* k5267 in a5155 in a5143 in string-prefix? in k3504 in k3501 */
static void C_ccall f_5269(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_eqp(t1,((C_word*)t0)[2]));}

/* a5149 in a5143 in string-prefix? in k3504 in k3501 */
static void C_ccall f_5150(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5150,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[5]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5137 in string-prefix? in k3504 in k3501 */
static void C_ccall f_5138(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5138,2,t0,t1);}
/* string-parse-start+end */
t2=*((C_word*)lf[0]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-suffix-length-ci in k3504 in k3501 */
static void C_ccall f_5102(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr4r,(void*)f_5102r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5102r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5102r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(10);
t5=*((C_word*)lf[46]+1);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5108,a[2]=t4,a[3]=t2,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5114,a[2]=t2,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t6,t7);}

/* a5113 in string-suffix-length-ci in k3504 in k3501 */
static void C_ccall f_5114(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5114,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5120,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5126,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t3,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t5,t6);}

/* a5125 in a5113 in string-suffix-length-ci in k3504 in k3501 */
static void C_ccall f_5126(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5126,4,t0,t1,t2,t3);}
/* srfi-13.scm: 714  %string-suffix-length-ci */
f_4927(t1,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2,t3);}

/* a5119 in a5113 in string-suffix-length-ci in k3504 in k3501 */
static void C_ccall f_5120(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5120,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[5]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5107 in string-suffix-length-ci in k3504 in k3501 */
static void C_ccall f_5108(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5108,2,t0,t1);}
/* string-parse-start+end */
t2=*((C_word*)lf[0]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-prefix-length-ci in k3504 in k3501 */
static void C_ccall f_5072(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr4r,(void*)f_5072r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5072r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5072r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(10);
t5=*((C_word*)lf[45]+1);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5078,a[2]=t4,a[3]=t2,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5084,a[2]=t2,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t6,t7);}

/* a5083 in string-prefix-length-ci in k3504 in k3501 */
static void C_ccall f_5084(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5084,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5090,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5096,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t3,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t5,t6);}

/* a5095 in a5083 in string-prefix-length-ci in k3504 in k3501 */
static void C_ccall f_5096(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5096,4,t0,t1,t2,t3);}
/* srfi-13.scm: 709  %string-prefix-length-ci */
f_4854(t1,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2,t3);}

/* a5089 in a5083 in string-prefix-length-ci in k3504 in k3501 */
static void C_ccall f_5090(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5090,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[5]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5077 in string-prefix-length-ci in k3504 in k3501 */
static void C_ccall f_5078(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5078,2,t0,t1);}
/* string-parse-start+end */
t2=*((C_word*)lf[0]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-suffix-length in k3504 in k3501 */
static void C_ccall f_5042(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr4r,(void*)f_5042r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5042r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5042r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(10);
t5=*((C_word*)lf[44]+1);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5048,a[2]=t4,a[3]=t2,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5054,a[2]=t2,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t6,t7);}

/* a5053 in string-suffix-length in k3504 in k3501 */
static void C_ccall f_5054(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5054,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5060,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5066,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t3,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t5,t6);}

/* a5065 in a5053 in string-suffix-length in k3504 in k3501 */
static void C_ccall f_5066(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5066,4,t0,t1,t2,t3);}
/* srfi-13.scm: 704  %string-suffix-length */
f_4769(t1,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2,t3);}

/* a5059 in a5053 in string-suffix-length in k3504 in k3501 */
static void C_ccall f_5060(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5060,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[5]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5047 in string-suffix-length in k3504 in k3501 */
static void C_ccall f_5048(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5048,2,t0,t1);}
/* string-parse-start+end */
t2=*((C_word*)lf[0]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-prefix-length in k3504 in k3501 */
static void C_ccall f_5012(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr4r,(void*)f_5012r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5012r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5012r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(10);
t5=*((C_word*)lf[43]+1);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5018,a[2]=t4,a[3]=t2,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5024,a[2]=t2,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t6,t7);}

/* a5023 in string-prefix-length in k3504 in k3501 */
static void C_ccall f_5024(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5024,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5030,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5036,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t3,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t5,t6);}

/* a5035 in a5023 in string-prefix-length in k3504 in k3501 */
static void C_ccall f_5036(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5036,4,t0,t1,t2,t3);}
/* srfi-13.scm: 699  %string-prefix-length */
f_4696(t1,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2,t3);}

/* a5029 in a5023 in string-prefix-length in k3504 in k3501 */
static void C_ccall f_5030(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5030,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[5]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5017 in string-prefix-length in k3504 in k3501 */
static void C_ccall f_5018(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5018,2,t0,t1);}
/* string-parse-start+end */
t2=*((C_word*)lf[0]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* %string-suffix-length-ci in k3504 in k3501 */
static void C_fcall f_4927(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4927,NULL,7,t1,t2,t3,t4,t5,t6,t7);}
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4931,a[2]=t5,a[3]=t2,a[4]=t7,a[5]=t1,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
t9=(C_word)C_u_fixnum_difference(t4,t3);
t10=(C_word)C_u_fixnum_difference(t7,t6);
/* srfi-13.scm: 682  min */
t11=*((C_word*)lf[25]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t8,t9,t10);}

/* k4929 in %string-suffix-length-ci in k3504 in k3501 */
static void C_ccall f_4931(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4931,2,t0,t1);}
t2=(C_word)C_u_fixnum_difference(((C_word*)t0)[6],t1);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4940,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
t4=(C_word)C_eqp(((C_word*)t0)[3],((C_word*)t0)[2]);
if(C_truep(t4)){
t5=((C_word*)t0)[6];
t6=((C_word*)t0)[4];
t7=t3;
f_4940(t7,(C_word)C_eqp(t5,t6));}
else{
t5=t3;
f_4940(t5,C_SCHEME_FALSE);}}

/* k4938 in k4929 in %string-suffix-length-ci in k3504 in k3501 */
static void C_fcall f_4940(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4940,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[7]);}
else{
t2=(C_word)C_u_fixnum_difference(((C_word*)t0)[6],C_fix(1));
t3=(C_word)C_u_fixnum_difference(((C_word*)t0)[5],C_fix(1));
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4953,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t5,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp));
t7=((C_word*)t5)[1];
f_4953(t7,((C_word*)t0)[8],t2,t3);}}

/* lp in k4938 in k4929 in %string-suffix-length-ci in k3504 in k3501 */
static void C_fcall f_4953(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4953,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_fixnum_lessp(t4,((C_word*)t0)[6]);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4963,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=t1,a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t5)){
t7=t6;
f_4963(t7,t5);}
else{
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4988,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_subchar(((C_word*)t0)[3],t2);
t9=(C_word)C_subchar(((C_word*)t0)[2],t3);
/* srfi-13.scm: 690  char-ci=? */
t10=*((C_word*)lf[41]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t7,t8,t9);}}

/* k4986 in lp in k4938 in k4929 in %string-suffix-length-ci in k3504 in k3501 */
static void C_ccall f_4988(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_4963(t2,(C_word)C_i_not(t1));}

/* k4961 in lp in k4938 in k4929 in %string-suffix-length-ci in k3504 in k3501 */
static void C_fcall f_4963(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_u_fixnum_difference(((C_word*)t0)[6],((C_word*)t0)[5]);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_u_fixnum_difference(t2,C_fix(1)));}
else{
t2=(C_word)C_u_fixnum_difference(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_u_fixnum_difference(((C_word*)t0)[3],C_fix(1));
/* srfi-13.scm: 693  lp */
t4=((C_word*)((C_word*)t0)[2])[1];
f_4953(t4,((C_word*)t0)[4],t2,t3);}}

/* %string-prefix-length-ci in k3504 in k3501 */
static void C_fcall f_4854(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4854,NULL,7,t1,t2,t3,t4,t5,t6,t7);}
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4858,a[2]=t6,a[3]=t5,a[4]=t2,a[5]=t1,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
t9=(C_word)C_u_fixnum_difference(t4,t3);
t10=(C_word)C_u_fixnum_difference(t7,t6);
/* srfi-13.scm: 668  min */
t11=*((C_word*)lf[25]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t8,t9,t10);}

/* k4856 in %string-prefix-length-ci in k3504 in k3501 */
static void C_ccall f_4858(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4858,2,t0,t1);}
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[6],t1);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4867,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=t1,a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
t4=(C_word)C_eqp(((C_word*)t0)[4],((C_word*)t0)[3]);
if(C_truep(t4)){
t5=((C_word*)t0)[6];
t6=((C_word*)t0)[2];
t7=t3;
f_4867(t7,(C_word)C_eqp(t5,t6));}
else{
t5=t3;
f_4867(t5,C_SCHEME_FALSE);}}

/* k4865 in k4856 in %string-prefix-length-ci in k3504 in k3501 */
static void C_fcall f_4867(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4867,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[7]);}
else{
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4872,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_4872(t5,((C_word*)t0)[8],((C_word*)t0)[5],((C_word*)t0)[2]);}}

/* lp in k4865 in k4856 in %string-prefix-length-ci in k3504 in k3501 */
static void C_fcall f_4872(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4872,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_fixnum_greater_or_equal_p(t4,((C_word*)t0)[6]);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4882,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t5)){
t7=t6;
f_4882(t7,t5);}
else{
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4903,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_subchar(((C_word*)t0)[3],t2);
t9=(C_word)C_subchar(((C_word*)t0)[2],t3);
/* srfi-13.scm: 676  char-ci=? */
t10=*((C_word*)lf[41]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t7,t8,t9);}}

/* k4901 in lp in k4865 in k4856 in %string-prefix-length-ci in k3504 in k3501 */
static void C_ccall f_4903(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_4882(t2,(C_word)C_i_not(t1));}

/* k4880 in lp in k4865 in k4856 in %string-prefix-length-ci in k3504 in k3501 */
static void C_fcall f_4882(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_u_fixnum_difference(((C_word*)t0)[5],((C_word*)t0)[4]));}
else{
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* srfi-13.scm: 679  lp */
t4=((C_word*)((C_word*)t0)[2])[1];
f_4872(t4,((C_word*)t0)[6],t2,t3);}}

/* %string-suffix-length in k3504 in k3501 */
static void C_fcall f_4769(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4769,NULL,7,t1,t2,t3,t4,t5,t6,t7);}
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4773,a[2]=t5,a[3]=t2,a[4]=t7,a[5]=t1,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
t9=(C_word)C_u_fixnum_difference(t4,t3);
t10=(C_word)C_u_fixnum_difference(t7,t6);
/* srfi-13.scm: 654  min */
t11=*((C_word*)lf[25]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t8,t9,t10);}

/* k4771 in %string-suffix-length in k3504 in k3501 */
static void C_ccall f_4773(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4773,2,t0,t1);}
t2=(C_word)C_u_fixnum_difference(((C_word*)t0)[6],t1);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4782,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
t4=(C_word)C_eqp(((C_word*)t0)[3],((C_word*)t0)[2]);
if(C_truep(t4)){
t5=((C_word*)t0)[6];
t6=((C_word*)t0)[4];
t7=t3;
f_4782(t7,(C_word)C_eqp(t5,t6));}
else{
t5=t3;
f_4782(t5,C_SCHEME_FALSE);}}

/* k4780 in k4771 in %string-suffix-length in k3504 in k3501 */
static void C_fcall f_4782(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4782,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[7]);}
else{
t2=(C_word)C_u_fixnum_difference(((C_word*)t0)[6],C_fix(1));
t3=(C_word)C_u_fixnum_difference(((C_word*)t0)[5],C_fix(1));
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4795,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t5,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp));
t7=((C_word*)t5)[1];
f_4795(t7,((C_word*)t0)[8],t2,t3);}}

/* lp in k4780 in k4771 in %string-suffix-length in k3504 in k3501 */
static void C_fcall f_4795(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4795,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_fixnum_lessp(t4,((C_word*)t0)[6]);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4805,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=t1,a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t5)){
t7=t6;
f_4805(t7,t5);}
else{
t7=(C_word)C_subchar(((C_word*)t0)[3],t2);
t8=(C_word)C_subchar(((C_word*)t0)[2],t3);
t9=(C_word)C_eqp(t7,t8);
t10=t6;
f_4805(t10,(C_word)C_i_not(t9));}}

/* k4803 in lp in k4780 in k4771 in %string-suffix-length in k3504 in k3501 */
static void C_fcall f_4805(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_u_fixnum_difference(((C_word*)t0)[6],((C_word*)t0)[5]);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_u_fixnum_difference(t2,C_fix(1)));}
else{
t2=(C_word)C_u_fixnum_difference(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_u_fixnum_difference(((C_word*)t0)[3],C_fix(1));
/* srfi-13.scm: 665  lp */
t4=((C_word*)((C_word*)t0)[2])[1];
f_4795(t4,((C_word*)t0)[4],t2,t3);}}

/* %string-prefix-length in k3504 in k3501 */
static void C_fcall f_4696(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4696,NULL,7,t1,t2,t3,t4,t5,t6,t7);}
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4700,a[2]=t6,a[3]=t5,a[4]=t2,a[5]=t1,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
t9=(C_word)C_u_fixnum_difference(t4,t3);
t10=(C_word)C_u_fixnum_difference(t7,t6);
/* srfi-13.scm: 640  min */
t11=*((C_word*)lf[25]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t8,t9,t10);}

/* k4698 in %string-prefix-length in k3504 in k3501 */
static void C_ccall f_4700(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4700,2,t0,t1);}
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[6],t1);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4709,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=t1,a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
t4=(C_word)C_eqp(((C_word*)t0)[4],((C_word*)t0)[3]);
if(C_truep(t4)){
t5=((C_word*)t0)[6];
t6=((C_word*)t0)[2];
t7=t3;
f_4709(t7,(C_word)C_eqp(t5,t6));}
else{
t5=t3;
f_4709(t5,C_SCHEME_FALSE);}}

/* k4707 in k4698 in %string-prefix-length in k3504 in k3501 */
static void C_fcall f_4709(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4709,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[7]);}
else{
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4714,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_4714(t5,((C_word*)t0)[8],((C_word*)t0)[5],((C_word*)t0)[2]);}}

/* lp in k4707 in k4698 in %string-prefix-length in k3504 in k3501 */
static void C_fcall f_4714(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4714,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_fixnum_greater_or_equal_p(t4,((C_word*)t0)[6]);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4724,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t5)){
t7=t6;
f_4724(t7,t5);}
else{
t7=(C_word)C_subchar(((C_word*)t0)[3],t2);
t8=(C_word)C_subchar(((C_word*)t0)[2],t3);
t9=(C_word)C_eqp(t7,t8);
t10=t6;
f_4724(t10,(C_word)C_i_not(t9));}}

/* k4722 in lp in k4707 in k4698 in %string-prefix-length in k3504 in k3501 */
static void C_fcall f_4724(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_u_fixnum_difference(((C_word*)t0)[5],((C_word*)t0)[4]));}
else{
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* srfi-13.scm: 651  lp */
t4=((C_word*)((C_word*)t0)[2])[1];
f_4714(t4,((C_word*)t0)[6],t2,t3);}}

/* string-tabulate in k3504 in k3501 */
static void C_ccall f_4657(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4657,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact_2(t3,lf[37]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4664,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* srfi-13.scm: 622  make-string */
t6=*((C_word*)lf[16]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t3);}

/* k4662 in string-tabulate in k3504 in k3501 */
static void C_ccall f_4664(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4664,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4667,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_u_fixnum_difference(((C_word*)t0)[3],C_fix(1));
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4673,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=t1,tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_4673(t7,t2,t3);}

/* doloop740 in k4662 in string-tabulate in k3504 in k3501 */
static void C_fcall f_4673(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4673,NULL,3,t0,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_lessp(t3,C_fix(0)))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4694,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* srfi-13.scm: 625  proc */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}}

/* k4692 in doloop740 in k4662 in string-tabulate in k3504 in k3501 */
static void C_ccall f_4694(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_setsubchar(((C_word*)t0)[5],((C_word*)t0)[4],t1);
t3=(C_word)C_u_fixnum_difference(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_4673(t4,((C_word*)t0)[2],t3);}

/* k4665 in k4662 in string-tabulate in k3504 in k3501 */
static void C_ccall f_4667(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* string-any in k3504 in k3501 */
static void C_ccall f_4527(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr4r,(void*)f_4527r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4527r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4527r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(8);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4533,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4539,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t5,t6);}

/* a4538 in string-any in k3504 in k3501 */
static void C_ccall f_4539(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4539,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_charp(((C_word*)t0)[3]))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4551,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,f_4551(t4,t2));}
else{
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4581,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[2],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* srfi-13.scm: 599  char-set? */
t5=*((C_word*)lf[34]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[3]);}}

/* k4579 in a4538 in string-any in k3504 in k3501 */
static void C_ccall f_4581(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4581,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4586,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_4586(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
if(C_truep((C_word)C_i_closurep(((C_word*)t0)[4]))){
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[6];
if(C_truep((C_word)C_fixnum_lessp(t2,t3))){
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4627,a[2]=t5,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_4627(t7,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
/* srfi-13.scm: 613  ##sys#error */
t2=*((C_word*)lf[1]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[35],lf[36],*((C_word*)lf[35]+1),((C_word*)t0)[4]);}}}

/* lp in k4579 in a4538 in string-any in k3504 in k3501 */
static void C_fcall f_4627(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4627,NULL,3,t0,t1,t2);}
t3=(C_word)C_subchar(((C_word*)t0)[5],t2);
t4=(C_word)C_u_fixnum_plus(t2,C_fix(1));
t5=((C_word*)t0)[4];
t6=(C_word)C_eqp(t4,t5);
if(C_truep(t6)){
/* srfi-13.scm: 610  criteria */
t7=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t1,t3);}
else{
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4646,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* srfi-13.scm: 611  criteria */
t8=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t3);}}

/* k4644 in lp in k4579 in a4538 in string-any in k3504 in k3501 */
static void C_ccall f_4646(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
/* srfi-13.scm: 611  lp */
t2=((C_word*)((C_word*)t0)[3])[1];
f_4627(t2,((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* lp in k4579 in a4538 in string-any in k3504 in k3501 */
static void C_fcall f_4586(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4586,NULL,3,t0,t1,t2);}
t3=t2;
t4=((C_word*)t0)[5];
if(C_truep((C_word)C_fixnum_lessp(t3,t4))){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4596,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_subchar(((C_word*)t0)[3],t2);
/* srfi-13.scm: 602  char-set-contains? */
t7=*((C_word*)lf[32]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,((C_word*)t0)[2],t6);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}

/* k4594 in lp in k4579 in a4538 in string-any in k3504 in k3501 */
static void C_ccall f_4596(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* srfi-13.scm: 603  lp */
t3=((C_word*)((C_word*)t0)[2])[1];
f_4586(t3,((C_word*)t0)[4],t2);}}

/* lp in a4538 in string-any in k3504 in k3501 */
static C_word C_fcall f_4551(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
loop:
t2=t1;
t3=((C_word*)t0)[4];
if(C_truep((C_word)C_fixnum_lessp(t2,t3))){
t4=(C_word)C_subchar(((C_word*)t0)[3],t1);
t5=(C_word)C_eqp(((C_word*)t0)[2],t4);
if(C_truep(t5)){
return(t5);}
else{
t6=(C_word)C_u_fixnum_plus(t1,C_fix(1));
t8=t6;
t1=t8;
goto loop;}}
else{
return(C_SCHEME_FALSE);}}

/* a4532 in string-any in k3504 in k3501 */
static void C_ccall f_4533(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4533,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[5]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[35]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-every in k3504 in k3501 */
static void C_ccall f_4397(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr4r,(void*)f_4397r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4397r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4397r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(8);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4403,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4409,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t5,t6);}

/* a4408 in string-every in k3504 in k3501 */
static void C_ccall f_4409(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4409,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_charp(((C_word*)t0)[3]))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4421,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,f_4421(t4,t2));}
else{
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4451,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[2],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* srfi-13.scm: 573  char-set? */
t5=*((C_word*)lf[34]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[3]);}}

/* k4449 in a4408 in string-every in k3504 in k3501 */
static void C_ccall f_4451(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4451,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4456,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_4456(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
if(C_truep((C_word)C_i_closurep(((C_word*)t0)[4]))){
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[6];
t4=(C_word)C_eqp(t2,t3);
if(C_truep(t4)){
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4497,a[2]=t6,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_4497(t8,((C_word*)t0)[3],((C_word*)t0)[2]);}}
else{
/* srfi-13.scm: 587  ##sys#error */
t2=*((C_word*)lf[1]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[31],lf[33],*((C_word*)lf[31]+1),((C_word*)t0)[4]);}}}

/* lp in k4449 in a4408 in string-every in k3504 in k3501 */
static void C_fcall f_4497(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4497,NULL,3,t0,t1,t2);}
t3=(C_word)C_subchar(((C_word*)t0)[5],t2);
t4=(C_word)C_u_fixnum_plus(t2,C_fix(1));
t5=((C_word*)t0)[4];
t6=(C_word)C_eqp(t4,t5);
if(C_truep(t6)){
/* srfi-13.scm: 584  criteria */
t7=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t1,t3);}
else{
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4519,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* srfi-13.scm: 585  criteria */
t8=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t3);}}

/* k4517 in lp in k4449 in a4408 in string-every in k3504 in k3501 */
static void C_ccall f_4519(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* srfi-13.scm: 585  lp */
t2=((C_word*)((C_word*)t0)[4])[1];
f_4497(t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* lp in k4449 in a4408 in string-every in k3504 in k3501 */
static void C_fcall f_4456(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4456,NULL,3,t0,t1,t2);}
t3=t2;
t4=((C_word*)t0)[5];
t5=(C_word)C_fixnum_greater_or_equal_p(t3,t4);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4469,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_subchar(((C_word*)t0)[3],t2);
/* srfi-13.scm: 576  char-set-contains? */
t8=*((C_word*)lf[32]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,((C_word*)t0)[2],t7);}}

/* k4467 in lp in k4449 in a4408 in string-every in k3504 in k3501 */
static void C_ccall f_4469(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* srfi-13.scm: 577  lp */
t3=((C_word*)((C_word*)t0)[3])[1];
f_4456(t3,((C_word*)t0)[2],t2);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* lp in a4408 in string-every in k3504 in k3501 */
static C_word C_fcall f_4421(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
loop:
t2=t1;
t3=((C_word*)t0)[4];
t4=(C_word)C_fixnum_greater_or_equal_p(t2,t3);
if(C_truep(t4)){
return(t4);}
else{
t5=(C_word)C_subchar(((C_word*)t0)[3],t1);
t6=(C_word)C_eqp(((C_word*)t0)[2],t5);
if(C_truep(t6)){
t7=(C_word)C_u_fixnum_plus(t1,C_fix(1));
t9=t7;
t1=t9;
goto loop;}
else{
return(C_SCHEME_FALSE);}}}

/* a4402 in string-every in k3504 in k3501 */
static void C_ccall f_4403(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4403,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[5]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[31]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-for-each-index in k3504 in k3501 */
static void C_ccall f_4360(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr4r,(void*)f_4360r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4360r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4360r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(7);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4366,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4372,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t5,t6);}

/* a4371 in string-for-each-index in k3504 in k3501 */
static void C_ccall f_4372(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4372,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4378,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_4378(t7,t1,t2);}

/* lp in a4371 in string-for-each-index in k3504 in k3501 */
static void C_fcall f_4378(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4378,NULL,3,t0,t1,t2);}
t3=t2;
t4=((C_word*)t0)[4];
if(C_truep((C_word)C_fixnum_lessp(t3,t4))){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4388,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* srfi-13.scm: 563  proc */
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}}

/* k4386 in lp in a4371 in string-for-each-index in k3504 in k3501 */
static void C_ccall f_4388(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* srfi-13.scm: 563  lp */
t3=((C_word*)((C_word*)t0)[3])[1];
f_4378(t3,((C_word*)t0)[2],t2);}

/* a4365 in string-for-each-index in k3504 in k3501 */
static void C_ccall f_4366(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4366,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[5]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[30]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-for-each in k3504 in k3501 */
static void C_ccall f_4319(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr4r,(void*)f_4319r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4319r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4319r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(8);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4325,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4331,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t5,t6);}

/* a4330 in string-for-each in k3504 in k3501 */
static void C_ccall f_4331(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4331,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4337,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t5,a[5]=t3,tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_4337(t7,t1,t2);}

/* lp in a4330 in string-for-each in k3504 in k3501 */
static void C_fcall f_4337(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4337,NULL,3,t0,t1,t2);}
t3=t2;
t4=((C_word*)t0)[5];
if(C_truep((C_word)C_fixnum_lessp(t3,t4))){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4347,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_subchar(((C_word*)t0)[3],t2);
/* srfi-13.scm: 556  proc */
t7=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t5,t6);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}}

/* k4345 in lp in a4330 in string-for-each in k3504 in k3501 */
static void C_ccall f_4347(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* srfi-13.scm: 557  lp */
t3=((C_word*)((C_word*)t0)[3])[1];
f_4337(t3,((C_word*)t0)[2],t2);}

/* a4324 in string-for-each in k3504 in k3501 */
static void C_ccall f_4325(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4325,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[5]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[29]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-unfold-right in k3504 in k3501 */
static void C_ccall f_4133(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,...){
C_word tmp;
C_word t6;
va_list v;
C_word *a,c2=c;
C_save_rest(t5,c2,6);
if(!C_demand(c*C_SIZEOF_PAIR+11)){
C_save_and_reclaim((void*)tr6r,(void*)f_4133r,6,t0,t1,t2,t3,t4,t5);}
else{
a=C_alloc((c-6)*3);
t6=C_restore_rest(a,C_rest_count(0));
f_4133r(t0,t1,t2,t3,t4,t5,t6);}}

static void C_ccall f_4133r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a=C_alloc(11);
t7=(C_word)C_i_nullp(t6);
t8=(C_truep(t7)?lf[27]:(C_word)C_u_i_car(t6));
t9=(C_word)C_i_nullp(t6);
t10=(C_truep(t9)?C_SCHEME_END_OF_LIST:(C_word)C_slot(t6,C_fix(1)));
t11=(C_word)C_i_nullp(t10);
t12=(C_truep(t11)?(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4301,tmp=(C_word)a,a+=2,tmp):(C_word)C_u_i_car(t10));
t13=(C_word)C_i_nullp(t10);
t14=(C_truep(t13)?C_SCHEME_END_OF_LIST:(C_word)C_slot(t10,C_fix(1)));
t15=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4156,a[2]=t5,a[3]=t1,a[4]=t2,a[5]=t3,a[6]=t4,a[7]=t12,a[8]=t8,tmp=(C_word)a,a+=9,tmp);
/* srfi-13.scm: 509  make-string */
t16=*((C_word*)lf[16]+1);
((C_proc3)(void*)(*((C_word*)t16+1)))(3,t16,t15,C_fix(40));}

/* k4154 in string-unfold-right in k3504 in k3501 */
static void C_ccall f_4156(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4156,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4158,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t3,a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp));
t5=((C_word*)t3)[1];
f_4158(t5,((C_word*)t0)[3],C_SCHEME_END_OF_LIST,C_fix(0),t1,C_fix(40),C_fix(40),((C_word*)t0)[2]);}

/* lp in k4154 in string-unfold-right in k3504 in k3501 */
static void C_fcall f_4158(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4158,NULL,8,t0,t1,t2,t3,t4,t5,t6,t7);}
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4164,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t9,a[7]=((C_word*)t0)[6],a[8]=t2,a[9]=t4,a[10]=t3,a[11]=t5,a[12]=((C_word*)t0)[7],tmp=(C_word)a,a+=13,tmp));
t11=((C_word*)t9)[1];
f_4164(t11,t1,t6,t7);}

/* lp2 in lp in k4154 in string-unfold-right in k3504 in k3501 */
static void C_fcall f_4164(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4164,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_4288,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t3,a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=t2,a[13]=((C_word*)t0)[11],a[14]=((C_word*)t0)[12],tmp=(C_word)a,a+=15,tmp);
/* srfi-13.scm: 514  p */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t3);}

/* k4286 in lp2 in lp in k4154 in string-unfold-right in k3504 in k3501 */
static void C_ccall f_4288(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4288,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4221,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[12],a[7]=((C_word*)t0)[13],a[8]=((C_word*)t0)[14],tmp=(C_word)a,a+=9,tmp);
/* srfi-13.scm: 531  make-final */
t3=((C_word*)t0)[7];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[6]);}
else{
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4174,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[13],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[5],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[12],tmp=(C_word)a,a+=12,tmp);
/* srfi-13.scm: 515  f */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[6]);}}

/* k4172 in k4286 in lp2 in lp in k4154 in string-unfold-right in k3504 in k3501 */
static void C_ccall f_4174(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4174,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4177,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=t1,a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
/* srfi-13.scm: 516  g */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k4175 in k4172 in k4286 in lp2 in lp in k4154 in string-unfold-right in k3504 in k3501 */
static void C_ccall f_4177(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4177,2,t0,t1);}
t2=((C_word*)t0)[10];
if(C_truep((C_word)C_fixnum_greaterp(t2,C_fix(0)))){
t3=(C_word)C_u_fixnum_difference(((C_word*)t0)[10],C_fix(1));
t4=(C_word)C_setsubchar(((C_word*)t0)[9],t3,((C_word*)t0)[8]);
/* srfi-13.scm: 520  lp2 */
t5=((C_word*)((C_word*)t0)[7])[1];
f_4164(t5,((C_word*)t0)[6],t3,t1);}
else{
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[5],((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4198,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* srfi-13.scm: 523  min */
t5=*((C_word*)lf[25]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_fix(4096),t3);}}

/* k4196 in k4175 in k4172 in k4286 in lp2 in lp in k4154 in string-unfold-right in k3504 in k3501 */
static void C_ccall f_4198(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4198,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4201,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t1,tmp=(C_word)a,a+=11,tmp);
/* srfi-13.scm: 524  make-string */
t3=*((C_word*)lf[16]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}

/* k4199 in k4196 in k4175 in k4172 in k4286 in lp2 in lp in k4154 in string-unfold-right in k3504 in k3501 */
static void C_ccall f_4201(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4201,2,t0,t1);}
t2=(C_word)C_u_fixnum_difference(((C_word*)t0)[10],C_fix(1));
t3=(C_word)C_setsubchar(t1,t2,((C_word*)t0)[9]);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],((C_word*)t0)[7]);
t5=(C_word)C_u_fixnum_plus(((C_word*)t0)[6],((C_word*)t0)[5]);
/* srfi-13.scm: 527  lp */
t6=((C_word*)((C_word*)t0)[4])[1];
f_4158(t6,((C_word*)t0)[3],t4,t5,t1,((C_word*)t0)[10],t2,((C_word*)t0)[2]);}

/* k4219 in k4286 in lp2 in lp in k4154 in string-unfold-right in k3504 in k3501 */
static void C_ccall f_4221(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4221,2,t0,t1);}
t2=(C_word)C_fix((C_word)C_header_size(t1));
t3=(C_word)C_fix((C_word)C_header_size(((C_word*)t0)[8]));
t4=(C_word)C_u_fixnum_difference(((C_word*)t0)[7],((C_word*)t0)[6]);
t5=(C_word)C_u_fixnum_plus((C_word)C_u_fixnum_plus(t3,((C_word*)t0)[5]),t4);
t6=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4236,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word*)t0)[8],a[6]=t4,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[4],a[10]=t2,a[11]=t1,tmp=(C_word)a,a+=12,tmp);
t7=(C_word)C_u_fixnum_plus(t5,t2);
/* srfi-13.scm: 536  make-string */
t8=*((C_word*)lf[16]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t6,t7);}

/* k4234 in k4219 in k4286 in lp2 in lp in k4154 in string-unfold-right in k3504 in k3501 */
static void C_ccall f_4236(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4236,2,t0,t1);}
t2=f_7825(t1,C_fix(0),((C_word*)t0)[11],C_fix(0),((C_word*)t0)[10]);
t3=f_7825(t1,((C_word*)t0)[10],((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7]);
t4=(C_word)C_u_fixnum_plus(((C_word*)t0)[10],((C_word*)t0)[6]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4251,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=f_4251(t5,t4,((C_word*)t0)[3]);
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t1);}

/* lp in k4234 in k4219 in k4286 in lp2 in lp in k4154 in string-unfold-right in k3504 in k3501 */
static C_word C_fcall f_4251(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
loop:
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_fix((C_word)C_header_size(t3));
t6=f_7825(((C_word*)t0)[4],t1,t3,C_fix(0),t5);
t7=(C_word)C_u_fixnum_plus(t1,t5);
t9=t7;
t10=t4;
t1=t9;
t2=t10;
goto loop;}
else{
return(f_7825(((C_word*)t0)[4],t1,((C_word*)t0)[3],C_fix(0),((C_word*)t0)[2]));}}

/* f_4301 in string-unfold-right in k3504 in k3501 */
static void C_ccall f_4301(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4301,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[28]);}

/* string-unfold in k3504 in k3501 */
static void C_ccall f_3954(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,...){
C_word tmp;
C_word t6;
va_list v;
C_word *a,c2=c;
C_save_rest(t5,c2,6);
if(!C_demand(c*C_SIZEOF_PAIR+11)){
C_save_and_reclaim((void*)tr6r,(void*)f_3954r,6,t0,t1,t2,t3,t4,t5);}
else{
a=C_alloc((c-6)*3);
t6=C_restore_rest(a,C_rest_count(0));
f_3954r(t0,t1,t2,t3,t4,t5,t6);}}

static void C_ccall f_3954r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a=C_alloc(11);
t7=(C_word)C_i_nullp(t6);
t8=(C_truep(t7)?lf[22]:(C_word)C_u_i_car(t6));
t9=(C_word)C_i_nullp(t6);
t10=(C_truep(t9)?C_SCHEME_END_OF_LIST:(C_word)C_slot(t6,C_fix(1)));
t11=(C_word)C_i_nullp(t10);
t12=(C_truep(t11)?(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4115,tmp=(C_word)a,a+=2,tmp):(C_word)C_u_i_car(t10));
t13=(C_word)C_i_nullp(t10);
t14=(C_truep(t13)?C_SCHEME_END_OF_LIST:(C_word)C_slot(t10,C_fix(1)));
t15=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3977,a[2]=t5,a[3]=t1,a[4]=t2,a[5]=t3,a[6]=t4,a[7]=t12,a[8]=t8,tmp=(C_word)a,a+=9,tmp);
/* srfi-13.scm: 464  make-string */
t16=*((C_word*)lf[16]+1);
((C_proc3)(void*)(*((C_word*)t16+1)))(3,t16,t15,C_fix(40));}

/* k3975 in string-unfold in k3504 in k3501 */
static void C_ccall f_3977(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3977,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3979,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t3,a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp));
t5=((C_word*)t3)[1];
f_3979(t5,((C_word*)t0)[3],C_SCHEME_END_OF_LIST,C_fix(0),t1,C_fix(40),C_fix(0),((C_word*)t0)[2]);}

/* lp in k3975 in string-unfold in k3504 in k3501 */
static void C_fcall f_3979(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3979,NULL,8,t0,t1,t2,t3,t4,t5,t6,t7);}
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3985,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t9,a[7]=t5,a[8]=((C_word*)t0)[6],a[9]=t2,a[10]=t4,a[11]=t3,a[12]=((C_word*)t0)[7],tmp=(C_word)a,a+=13,tmp));
t11=((C_word*)t9)[1];
f_3985(t11,t1,t6,t7);}

/* lp2 in lp in k3975 in string-unfold in k3504 in k3501 */
static void C_fcall f_3985(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3985,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_4102,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t3,a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=t2,a[13]=((C_word*)t0)[11],a[14]=((C_word*)t0)[12],tmp=(C_word)a,a+=15,tmp);
/* srfi-13.scm: 469  p */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t3);}

/* k4100 in lp2 in lp in k3975 in string-unfold in k3504 in k3501 */
static void C_ccall f_4102(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4102,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4040,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[13],a[7]=((C_word*)t0)[14],tmp=(C_word)a,a+=8,tmp);
/* srfi-13.scm: 484  make-final */
t3=((C_word*)t0)[8];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[7]);}
else{
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3995,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[13],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[6],a[11]=((C_word*)t0)[12],tmp=(C_word)a,a+=12,tmp);
/* srfi-13.scm: 470  f */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[7]);}}

/* k3993 in k4100 in lp2 in lp in k3975 in string-unfold in k3504 in k3501 */
static void C_ccall f_3995(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3995,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3998,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=t1,a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
/* srfi-13.scm: 471  g */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k3996 in k3993 in k4100 in lp2 in lp in k3975 in string-unfold in k3504 in k3501 */
static void C_ccall f_3998(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3998,2,t0,t1);}
t2=((C_word*)t0)[10];
t3=((C_word*)t0)[9];
if(C_truep((C_word)C_fixnum_lessp(t2,t3))){
t4=(C_word)C_setsubchar(((C_word*)t0)[8],((C_word*)t0)[10],((C_word*)t0)[7]);
t5=(C_word)C_u_fixnum_plus(((C_word*)t0)[10],C_fix(1));
/* srfi-13.scm: 474  lp2 */
t6=((C_word*)((C_word*)t0)[6])[1];
f_3985(t6,((C_word*)t0)[5],t5,t1);}
else{
t4=(C_word)C_u_fixnum_plus(((C_word*)t0)[9],((C_word*)t0)[4]);
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4020,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp);
/* srfi-13.scm: 477  min */
t6=*((C_word*)lf[25]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,C_fix(4096),t4);}}

/* k4018 in k3996 in k3993 in k4100 in lp2 in lp in k3975 in string-unfold in k3504 in k3501 */
static void C_ccall f_4020(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4020,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4023,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* srfi-13.scm: 478  make-string */
t3=*((C_word*)lf[16]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}

/* k4021 in k4018 in k3996 in k3993 in k4100 in lp2 in lp in k3975 in string-unfold in k3504 in k3501 */
static void C_ccall f_4023(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4023,2,t0,t1);}
t2=(C_word)C_setsubchar(t1,C_fix(0),((C_word*)t0)[10]);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],((C_word*)t0)[8]);
t4=(C_word)C_u_fixnum_plus(((C_word*)t0)[7],((C_word*)t0)[6]);
/* srfi-13.scm: 480  lp */
t5=((C_word*)((C_word*)t0)[5])[1];
f_3979(t5,((C_word*)t0)[4],t3,t4,t1,((C_word*)t0)[3],C_fix(1),((C_word*)t0)[2]);}

/* k4038 in k4100 in lp2 in lp in k3975 in string-unfold in k3504 in k3501 */
static void C_ccall f_4040(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4040,2,t0,t1);}
t2=(C_word)C_fix((C_word)C_header_size(t1));
t3=(C_word)C_fix((C_word)C_header_size(((C_word*)t0)[7]));
t4=(C_word)C_u_fixnum_plus((C_word)C_u_fixnum_plus(t3,((C_word*)t0)[6]),((C_word*)t0)[5]);
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4052,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=t2,a[9]=t1,a[10]=t4,tmp=(C_word)a,a+=11,tmp);
t6=(C_word)C_u_fixnum_plus(t4,t2);
/* srfi-13.scm: 488  make-string */
t7=*((C_word*)lf[16]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t5,t6);}

/* k4050 in k4038 in k4100 in lp2 in lp in k3975 in string-unfold in k3504 in k3501 */
static void C_ccall f_4052(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4052,2,t0,t1);}
t2=f_7825(t1,((C_word*)t0)[10],((C_word*)t0)[9],C_fix(0),((C_word*)t0)[8]);
t3=(C_word)C_u_fixnum_difference(((C_word*)t0)[10],((C_word*)t0)[7]);
t4=f_7825(t1,t3,((C_word*)t0)[6],C_fix(0),((C_word*)t0)[7]);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4069,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=f_4069(t5,t3,((C_word*)t0)[5]);
t7=f_7825(t1,C_fix(0),((C_word*)t0)[4],C_fix(0),((C_word*)t0)[3]);
t8=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t1);}

/* lp in k4050 in k4038 in k4100 in lp2 in lp in k3975 in string-unfold in k3504 in k3501 */
static C_word C_fcall f_4069(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
loop:
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_fix((C_word)C_header_size(t3));
t6=(C_word)C_u_fixnum_difference(t1,t5);
t7=f_7825(((C_word*)t0)[2],t6,t3,C_fix(0),t5);
t9=t6;
t10=t4;
t1=t9;
t2=t10;
goto loop;}
else{
return(C_SCHEME_UNDEFINED);}}

/* f_4115 in string-unfold in k3504 in k3501 */
static void C_ccall f_4115(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4115,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[23]);}

/* string-fold-right in k3504 in k3501 */
static void C_ccall f_3908(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr5r,(void*)f_3908r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_3908r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_3908r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(9);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3914,a[2]=t5,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3920,a[2]=t3,a[3]=t2,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t6,t7);}

/* a3919 in string-fold-right in k3504 in k3501 */
static void C_ccall f_3920(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3920,4,t0,t1,t2,t3);}
t4=(C_word)C_u_fixnum_difference(t3,C_fix(1));
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3930,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t6,a[5]=t2,tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_3930(t8,t1,((C_word*)t0)[2],t4);}

/* lp in a3919 in string-fold-right in k3504 in k3501 */
static void C_fcall f_3930(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3930,NULL,4,t0,t1,t2,t3);}
t4=t3;
t5=((C_word*)t0)[5];
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t4,t5))){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3944,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_subchar(((C_word*)t0)[3],t3);
/* srfi-13.scm: 389  kons */
t8=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,t7,t2);}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t2);}}

/* k3942 in lp in a3919 in string-fold-right in k3504 in k3501 */
static void C_ccall f_3944(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_difference(((C_word*)t0)[4],C_fix(1));
/* srfi-13.scm: 389  lp */
t3=((C_word*)((C_word*)t0)[3])[1];
f_3930(t3,((C_word*)t0)[2],t1,t2);}

/* a3913 in string-fold-right in k3504 in k3501 */
static void C_ccall f_3914(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3914,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[5]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[20]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-fold in k3504 in k3501 */
static void C_ccall f_3866(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr5r,(void*)f_3866r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_3866r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_3866r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(9);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3872,a[2]=t5,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3878,a[2]=t3,a[3]=t2,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t6,t7);}

/* a3877 in string-fold in k3504 in k3501 */
static void C_ccall f_3878(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3878,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3884,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t5,a[5]=t3,tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_3884(t7,t1,((C_word*)t0)[2],t2);}

/* lp in a3877 in string-fold in k3504 in k3501 */
static void C_fcall f_3884(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3884,NULL,4,t0,t1,t2,t3);}
t4=t3;
t5=((C_word*)t0)[5];
if(C_truep((C_word)C_fixnum_lessp(t4,t5))){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3898,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_subchar(((C_word*)t0)[3],t3);
/* srfi-13.scm: 382  kons */
t8=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,t7,t2);}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t2);}}

/* k3896 in lp in a3877 in string-fold in k3504 in k3501 */
static void C_ccall f_3898(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* srfi-13.scm: 382  lp */
t3=((C_word*)((C_word*)t0)[3])[1];
f_3884(t3,((C_word*)t0)[2],t1,t2);}

/* a3871 in string-fold in k3504 in k3501 */
static void C_ccall f_3872(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3872,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[5]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[19]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* %string-map! in k3504 in k3501 */
static void C_fcall f_3833(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3833,NULL,5,t1,t2,t3,t4,t5);}
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3839,a[2]=t2,a[3]=t7,a[4]=t3,a[5]=t5,tmp=(C_word)a,a+=6,tmp));
t9=((C_word*)t7)[1];
f_3839(t9,t1,t4);}

/* doloop310 in %string-map! in k3504 in k3501 */
static void C_fcall f_3839(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3839,NULL,3,t0,t1,t2);}
t3=t2;
t4=((C_word*)t0)[5];
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,t4))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,((C_word*)t0)[4]);}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3860,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_subchar(((C_word*)t0)[4],t2);
/* srfi-13.scm: 376  proc */
t7=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t5,t6);}}

/* k3858 in doloop310 in %string-map! in k3504 in k3501 */
static void C_ccall f_3860(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_setsubchar(((C_word*)t0)[5],((C_word*)t0)[4],t1);
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_3839(t4,((C_word*)t0)[2],t3);}

/* string-map! in k3504 in k3501 */
static void C_ccall f_3815(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr4r,(void*)f_3815r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3815r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3815r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(8);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3821,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3827,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t5,t6);}

/* a3826 in string-map! in k3504 in k3501 */
static void C_ccall f_3827(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3827,4,t0,t1,t2,t3);}
/* srfi-13.scm: 371  %string-map! */
f_3833(t1,((C_word*)t0)[3],((C_word*)t0)[2],t2,t3);}

/* a3820 in string-map! in k3504 in k3501 */
static void C_ccall f_3821(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3821,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[5]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[17]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* %string-map in k3504 in k3501 */
static void C_fcall f_3772(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3772,NULL,5,t1,t2,t3,t4,t5);}
t6=(C_word)C_u_fixnum_difference(t5,t4);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3779,a[2]=t4,a[3]=t2,a[4]=t3,a[5]=t6,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* srfi-13.scm: 361  make-string */
t8=*((C_word*)lf[16]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t6);}

/* k3777 in %string-map in k3504 in k3501 */
static void C_ccall f_3779(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3779,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3782,a[2]=t1,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3784,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp));
t6=((C_word*)t4)[1];
f_3784(t6,t2,C_fix(0),((C_word*)t0)[2]);}

/* doloop274 in k3777 in %string-map in k3504 in k3501 */
static void C_fcall f_3784(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3784,NULL,4,t0,t1,t2,t3);}
t4=t2;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t4,((C_word*)t0)[6]))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}
else{
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3809,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t6=(C_word)C_subchar(((C_word*)t0)[3],t3);
/* srfi-13.scm: 365  proc */
t7=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t5,t6);}}

/* k3807 in doloop274 in k3777 in %string-map in k3504 in k3501 */
static void C_ccall f_3809(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_setsubchar(((C_word*)t0)[6],((C_word*)t0)[5],t1);
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[5],C_fix(1));
t4=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t5=((C_word*)((C_word*)t0)[3])[1];
f_3784(t5,((C_word*)t0)[2],t3,t4);}

/* k3780 in k3777 in %string-map in k3504 in k3501 */
static void C_ccall f_3782(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* string-map in k3504 in k3501 */
static void C_ccall f_3754(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr4r,(void*)f_3754r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3754r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3754r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(8);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3760,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3766,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t5,t6);}

/* a3765 in string-map in k3504 in k3501 */
static void C_ccall f_3766(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3766,4,t0,t1,t2,t3);}
/* srfi-13.scm: 357  %string-map */
f_3772(t1,((C_word*)t0)[3],((C_word*)t0)[2],t2,t3);}

/* a3759 in string-map in k3504 in k3501 */
static void C_ccall f_3760(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3760,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[5]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[14]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-copy in k3504 in k3501 */
static void C_ccall f_3736(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3r,(void*)f_3736r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3736r(t0,t1,t2,t3);}}

static void C_ccall f_3736r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(7);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3742,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3748,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t4,t5);}

/* a3747 in string-copy in k3504 in k3501 */
static void C_ccall f_3748(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3748,4,t0,t1,t2,t3);}
/* srfi-13.scm: 322  ##sys#substring */
t4=*((C_word*)lf[12]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t1,((C_word*)t0)[2],t2,t3);}

/* a3741 in string-copy in k3504 in k3501 */
static void C_ccall f_3742(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3742,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[5]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[13]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* %substring/shared in k3504 in k3501 */
static void C_fcall f_3714(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3714,NULL,4,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3721,a[2]=t4,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_eqp(t3,C_fix(0));
if(C_truep(t6)){
t7=(C_word)C_fix((C_word)C_header_size(t2));
t8=t4;
t9=t5;
f_3721(t9,(C_word)C_eqp(t8,t7));}
else{
t7=t5;
f_3721(t7,C_SCHEME_FALSE);}}

/* k3719 in %substring/shared in k3504 in k3501 */
static void C_fcall f_3721(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[4]);}
else{
/* srfi-13.scm: 318  ##sys#substring */
t2=*((C_word*)lf[12]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* substring/shared in k3504 in k3501 */
static void C_ccall f_3684(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_3684r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3684r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3684r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(6);
t5=(C_word)C_fix((C_word)C_header_size(t2));
t6=(C_word)C_i_nullp(t4);
t7=(C_truep(t6)?t5:(C_word)C_u_i_car(t4));
t8=(C_word)C_i_check_exact_2(t7,lf[10]);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3697,a[2]=t7,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* srfi-13.scm: 303  check-substring-spec */
t10=*((C_word*)lf[8]+1);
((C_proc6)(void*)(*((C_word*)t10+1)))(6,t10,t9,lf[10],t2,t3,t7);}

/* k3695 in substring/shared in k3504 in k3501 */
static void C_ccall f_3697(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-13.scm: 304  %substring/shared */
f_3714(((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* check-substring-spec in k3504 in k3501 */
static void C_ccall f_3668(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_3668,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3682,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* srfi-13.scm: 271  substring-spec-ok? */
t7=*((C_word*)lf[7]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t6,t3,t4,t5);}

/* k3680 in check-substring-spec in k3504 in k3501 */
static void C_ccall f_3682(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
/* srfi-13.scm: 272  ##sys#error */
t2=*((C_word*)lf[1]+1);
((C_proc8)(void*)(*((C_word*)t2+1)))(8,t2,((C_word*)t0)[6],lf[8],lf[9],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* substring-spec-ok? in k3504 in k3501 */
static void C_ccall f_3628(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3628,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_stringp(t2))){
if(C_truep((C_word)C_fixnump(t3))){
if(C_truep((C_word)C_fixnump(t4))){
t5=t3;
if(C_truep((C_word)C_fixnum_less_or_equal_p(C_fix(0),t5))){
t6=t3;
t7=t4;
if(C_truep((C_word)C_fixnum_less_or_equal_p(t6,t7))){
t8=(C_word)C_fix((C_word)C_header_size(t2));
t9=t4;
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_fixnum_less_or_equal_p(t9,t8));}
else{
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_FALSE);}}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}

/* string-parse-final-start+end in k3504 in k3501 */
static void C_ccall f_3601(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3601,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3607,a[2]=t4,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3613,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t5,t6);}

/* a3612 in string-parse-final-start+end in k3504 in k3501 */
static void C_ccall f_3613(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3613,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_pairp(t2))){
/* srfi-13.scm: 255  ##sys#error */
t5=*((C_word*)lf[1]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t1,lf[5],lf[6],((C_word*)t0)[2],t2);}
else{
/* srfi-13.scm: 256  values */
C_values(4,0,t1,t3,t4);}}

/* a3606 in string-parse-final-start+end in k3504 in k3501 */
static void C_ccall f_3607(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3607,2,t0,t1);}
/* srfi-13.scm: 254  string-parse-start+end */
t2=*((C_word*)lf[0]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-parse-start+end in k3504 in k3501 */
static void C_ccall f_3508(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3508,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_check_string_2(t3,lf[0]);
t6=(C_word)C_fix((C_word)C_header_size(t3));
if(C_truep((C_word)C_i_pairp(t4))){
t7=(C_word)C_u_i_car(t4);
t8=(C_word)C_slot(t4,C_fix(1));
t9=(C_truep((C_word)C_fixnump(t7))?(C_word)C_fixnum_greater_or_equal_p(t7,C_fix(0)):C_SCHEME_FALSE);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3538,a[2]=t3,a[3]=t2,a[4]=t6,a[5]=t8,tmp=(C_word)a,a+=6,tmp);
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3574,a[2]=t3,a[3]=t2,a[4]=t7,tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t10,t11);}
else{
/* srfi-13.scm: 249  ##sys#error */
t10=*((C_word*)lf[1]+1);
((C_proc7)(void*)(*((C_word*)t10+1)))(7,t10,t1,lf[0],lf[4],t2,t7,t3);}}
else{
/* srfi-13.scm: 251  values */
C_values(5,0,t1,C_SCHEME_END_OF_LIST,C_fix(0),t6);}}

/* a3573 in string-parse-start+end in k3504 in k3501 */
static void C_ccall f_3574(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3574,4,t0,t1,t2,t3);}
t4=t2;
if(C_truep((C_word)C_fixnum_less_or_equal_p(((C_word*)t0)[4],t4))){
/* srfi-13.scm: 246  values */
C_values(5,0,t1,t3,((C_word*)t0)[4],t2);}
else{
/* srfi-13.scm: 247  ##sys#error */
t5=*((C_word*)lf[1]+1);
((C_proc8)(void*)(*((C_word*)t5+1)))(8,t5,t1,lf[0],lf[3],((C_word*)t0)[3],((C_word*)t0)[4],t2,((C_word*)t0)[2]);}}

/* a3537 in string-parse-start+end in k3504 in k3501 */
static void C_ccall f_3538(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3538,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[5]))){
t2=(C_word)C_u_i_car(((C_word*)t0)[5]);
t3=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t4=(C_truep((C_word)C_fixnump(t2))?(C_word)C_fixnum_less_or_equal_p(t2,((C_word*)t0)[4]):C_SCHEME_FALSE);
if(C_truep(t4)){
/* srfi-13.scm: 243  values */
C_values(4,0,t1,t2,t3);}
else{
/* srfi-13.scm: 244  ##sys#error */
t5=*((C_word*)lf[1]+1);
((C_proc7)(void*)(*((C_word*)t5+1)))(7,t5,t1,lf[0],lf[2],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}}
else{
/* srfi-13.scm: 245  values */
C_values(4,0,t1,((C_word*)t0)[4],((C_word*)t0)[5]);}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[536] = {
{"toplevel:srfi_13_scm",(void*)C_srfi_13_toplevel},
{"f_3503:srfi_13_scm",(void*)f_3503},
{"f_3506:srfi_13_scm",(void*)f_3506},
{"f_9324:srfi_13_scm",(void*)f_9324},
{"f_9433:srfi_13_scm",(void*)f_9433},
{"f_9403:srfi_13_scm",(void*)f_9403},
{"f_9386:srfi_13_scm",(void*)f_9386},
{"f_9341:srfi_13_scm",(void*)f_9341},
{"f_9347:srfi_13_scm",(void*)f_9347},
{"f_9369:srfi_13_scm",(void*)f_9369},
{"f_9251:srfi_13_scm",(void*)f_9251},
{"f_9322:srfi_13_scm",(void*)f_9322},
{"f_9282:srfi_13_scm",(void*)f_9282},
{"f_9111:srfi_13_scm",(void*)f_9111},
{"f_9164:srfi_13_scm",(void*)f_9164},
{"f_9177:srfi_13_scm",(void*)f_9177},
{"f_9230:srfi_13_scm",(void*)f_9230},
{"f_9226:srfi_13_scm",(void*)f_9226},
{"f_9120:srfi_13_scm",(void*)f_9120},
{"f_9142:srfi_13_scm",(void*)f_9142},
{"f_9132:srfi_13_scm",(void*)f_9132},
{"f_8973:srfi_13_scm",(void*)f_8973},
{"f_9026:srfi_13_scm",(void*)f_9026},
{"f_9089:srfi_13_scm",(void*)f_9089},
{"f_9092:srfi_13_scm",(void*)f_9092},
{"f_9086:srfi_13_scm",(void*)f_9086},
{"f_9082:srfi_13_scm",(void*)f_9082},
{"f_8982:srfi_13_scm",(void*)f_8982},
{"f_9004:srfi_13_scm",(void*)f_9004},
{"f_8994:srfi_13_scm",(void*)f_8994},
{"f_8891:srfi_13_scm",(void*)f_8891},
{"f_8909:srfi_13_scm",(void*)f_8909},
{"f_8915:srfi_13_scm",(void*)f_8915},
{"f_8919:srfi_13_scm",(void*)f_8919},
{"f_8928:srfi_13_scm",(void*)f_8928},
{"f_8953:srfi_13_scm",(void*)f_8953},
{"f_8942:srfi_13_scm",(void*)f_8942},
{"f_8903:srfi_13_scm",(void*)f_8903},
{"f_8840:srfi_13_scm",(void*)f_8840},
{"f_8844:srfi_13_scm",(void*)f_8844},
{"f_8855:srfi_13_scm",(void*)f_8855},
{"f_8868:srfi_13_scm",(void*)f_8868},
{"f_8849:srfi_13_scm",(void*)f_8849},
{"f_8797:srfi_13_scm",(void*)f_8797},
{"f_8801:srfi_13_scm",(void*)f_8801},
{"f_8809:srfi_13_scm",(void*)f_8809},
{"f_8671:srfi_13_scm",(void*)f_8671},
{"f_8695:srfi_13_scm",(void*)f_8695},
{"f_8745:srfi_13_scm",(void*)f_8745},
{"f_8586:srfi_13_scm",(void*)f_8586},
{"f_8613:srfi_13_scm",(void*)f_8613},
{"f_8513:srfi_13_scm",(void*)f_8513},
{"f_8520:srfi_13_scm",(void*)f_8520},
{"f_8525:srfi_13_scm",(void*)f_8525},
{"f_8554:srfi_13_scm",(void*)f_8554},
{"f_8411:srfi_13_scm",(void*)f_8411},
{"f_8417:srfi_13_scm",(void*)f_8417},
{"f_8471:srfi_13_scm",(void*)f_8471},
{"f_8476:srfi_13_scm",(void*)f_8476},
{"f_8405:srfi_13_scm",(void*)f_8405},
{"f_8359:srfi_13_scm",(void*)f_8359},
{"f_8371:srfi_13_scm",(void*)f_8371},
{"f_8381:srfi_13_scm",(void*)f_8381},
{"f_8365:srfi_13_scm",(void*)f_8365},
{"f_8304:srfi_13_scm",(void*)f_8304},
{"f_8316:srfi_13_scm",(void*)f_8316},
{"f_8326:srfi_13_scm",(void*)f_8326},
{"f_8310:srfi_13_scm",(void*)f_8310},
{"f_8249:srfi_13_scm",(void*)f_8249},
{"f_8261:srfi_13_scm",(void*)f_8261},
{"f_8268:srfi_13_scm",(void*)f_8268},
{"f_8277:srfi_13_scm",(void*)f_8277},
{"f_8255:srfi_13_scm",(void*)f_8255},
{"f_8246:srfi_13_scm",(void*)f_8246},
{"f_8125:srfi_13_scm",(void*)f_8125},
{"f_8149:srfi_13_scm",(void*)f_8149},
{"f_8158:srfi_13_scm",(void*)f_8158},
{"f_8190:srfi_13_scm",(void*)f_8190},
{"f_8197:srfi_13_scm",(void*)f_8197},
{"f_8188:srfi_13_scm",(void*)f_8188},
{"f_8143:srfi_13_scm",(void*)f_8143},
{"f_8087:srfi_13_scm",(void*)f_8087},
{"f_8093:srfi_13_scm",(void*)f_8093},
{"f_8100:srfi_13_scm",(void*)f_8100},
{"f_7952:srfi_13_scm",(void*)f_7952},
{"f_7970:srfi_13_scm",(void*)f_7970},
{"f_7977:srfi_13_scm",(void*)f_7977},
{"f_7994:srfi_13_scm",(void*)f_7994},
{"f_8009:srfi_13_scm",(void*)f_8009},
{"f_8042:srfi_13_scm",(void*)f_8042},
{"f_8036:srfi_13_scm",(void*)f_8036},
{"f_7980:srfi_13_scm",(void*)f_7980},
{"f_7964:srfi_13_scm",(void*)f_7964},
{"f_7890:srfi_13_scm",(void*)f_7890},
{"f_7902:srfi_13_scm",(void*)f_7902},
{"f_7914:srfi_13_scm",(void*)f_7914},
{"f_7926:srfi_13_scm",(void*)f_7926},
{"f_7939:srfi_13_scm",(void*)f_7939},
{"f_7908:srfi_13_scm",(void*)f_7908},
{"f_7896:srfi_13_scm",(void*)f_7896},
{"f_7828:srfi_13_scm",(void*)f_7828},
{"f_7840:srfi_13_scm",(void*)f_7840},
{"f_7852:srfi_13_scm",(void*)f_7852},
{"f_7864:srfi_13_scm",(void*)f_7864},
{"f_7877:srfi_13_scm",(void*)f_7877},
{"f_7846:srfi_13_scm",(void*)f_7846},
{"f_7834:srfi_13_scm",(void*)f_7834},
{"f_7825:srfi_13_scm",(void*)f_7825},
{"f_7793:srfi_13_scm",(void*)f_7793},
{"f_7805:srfi_13_scm",(void*)f_7805},
{"f_7812:srfi_13_scm",(void*)f_7812},
{"f_7799:srfi_13_scm",(void*)f_7799},
{"f_7752:srfi_13_scm",(void*)f_7752},
{"f_7764:srfi_13_scm",(void*)f_7764},
{"f_7774:srfi_13_scm",(void*)f_7774},
{"f_7758:srfi_13_scm",(void*)f_7758},
{"f_7617:srfi_13_scm",(void*)f_7617},
{"f_7629:srfi_13_scm",(void*)f_7629},
{"f_7675:srfi_13_scm",(void*)f_7675},
{"f_7719:srfi_13_scm",(void*)f_7719},
{"f_7740:srfi_13_scm",(void*)f_7740},
{"f_7680:srfi_13_scm",(void*)f_7680},
{"f_7701:srfi_13_scm",(void*)f_7701},
{"f_7641:srfi_13_scm",(void*)f_7641},
{"f_7623:srfi_13_scm",(void*)f_7623},
{"f_7482:srfi_13_scm",(void*)f_7482},
{"f_7494:srfi_13_scm",(void*)f_7494},
{"f_7540:srfi_13_scm",(void*)f_7540},
{"f_7588:srfi_13_scm",(void*)f_7588},
{"f_7601:srfi_13_scm",(void*)f_7601},
{"f_7549:srfi_13_scm",(void*)f_7549},
{"f_7562:srfi_13_scm",(void*)f_7562},
{"f_7510:srfi_13_scm",(void*)f_7510},
{"f_7488:srfi_13_scm",(void*)f_7488},
{"f_7359:srfi_13_scm",(void*)f_7359},
{"f_7371:srfi_13_scm",(void*)f_7371},
{"f_7413:srfi_13_scm",(void*)f_7413},
{"f_7453:srfi_13_scm",(void*)f_7453},
{"f_7466:srfi_13_scm",(void*)f_7466},
{"f_7418:srfi_13_scm",(void*)f_7418},
{"f_7431:srfi_13_scm",(void*)f_7431},
{"f_7383:srfi_13_scm",(void*)f_7383},
{"f_7365:srfi_13_scm",(void*)f_7365},
{"f_7224:srfi_13_scm",(void*)f_7224},
{"f_7236:srfi_13_scm",(void*)f_7236},
{"f_7282:srfi_13_scm",(void*)f_7282},
{"f_7330:srfi_13_scm",(void*)f_7330},
{"f_7343:srfi_13_scm",(void*)f_7343},
{"f_7291:srfi_13_scm",(void*)f_7291},
{"f_7304:srfi_13_scm",(void*)f_7304},
{"f_7252:srfi_13_scm",(void*)f_7252},
{"f_7230:srfi_13_scm",(void*)f_7230},
{"f_7101:srfi_13_scm",(void*)f_7101},
{"f_7113:srfi_13_scm",(void*)f_7113},
{"f_7155:srfi_13_scm",(void*)f_7155},
{"f_7195:srfi_13_scm",(void*)f_7195},
{"f_7208:srfi_13_scm",(void*)f_7208},
{"f_7160:srfi_13_scm",(void*)f_7160},
{"f_7173:srfi_13_scm",(void*)f_7173},
{"f_7125:srfi_13_scm",(void*)f_7125},
{"f_7107:srfi_13_scm",(void*)f_7107},
{"f_6993:srfi_13_scm",(void*)f_6993},
{"f_7005:srfi_13_scm",(void*)f_7005},
{"f_7087:srfi_13_scm",(void*)f_7087},
{"f_7048:srfi_13_scm",(void*)f_7048},
{"f_7074:srfi_13_scm",(void*)f_7074},
{"f_7081:srfi_13_scm",(void*)f_7081},
{"f_7051:srfi_13_scm",(void*)f_7051},
{"f_7054:srfi_13_scm",(void*)f_7054},
{"f_7059:srfi_13_scm",(void*)f_7059},
{"f_7066:srfi_13_scm",(void*)f_7066},
{"f_7057:srfi_13_scm",(void*)f_7057},
{"f_7018:srfi_13_scm",(void*)f_7018},
{"f_7032:srfi_13_scm",(void*)f_7032},
{"f_7039:srfi_13_scm",(void*)f_7039},
{"f_7021:srfi_13_scm",(void*)f_7021},
{"f_6999:srfi_13_scm",(void*)f_6999},
{"f_6885:srfi_13_scm",(void*)f_6885},
{"f_6897:srfi_13_scm",(void*)f_6897},
{"f_6979:srfi_13_scm",(void*)f_6979},
{"f_6940:srfi_13_scm",(void*)f_6940},
{"f_6966:srfi_13_scm",(void*)f_6966},
{"f_6973:srfi_13_scm",(void*)f_6973},
{"f_6943:srfi_13_scm",(void*)f_6943},
{"f_6946:srfi_13_scm",(void*)f_6946},
{"f_6951:srfi_13_scm",(void*)f_6951},
{"f_6958:srfi_13_scm",(void*)f_6958},
{"f_6949:srfi_13_scm",(void*)f_6949},
{"f_6910:srfi_13_scm",(void*)f_6910},
{"f_6924:srfi_13_scm",(void*)f_6924},
{"f_6931:srfi_13_scm",(void*)f_6931},
{"f_6913:srfi_13_scm",(void*)f_6913},
{"f_6891:srfi_13_scm",(void*)f_6891},
{"f_6823:srfi_13_scm",(void*)f_6823},
{"f_6844:srfi_13_scm",(void*)f_6844},
{"f_6864:srfi_13_scm",(void*)f_6864},
{"f_6838:srfi_13_scm",(void*)f_6838},
{"f_6765:srfi_13_scm",(void*)f_6765},
{"f_6786:srfi_13_scm",(void*)f_6786},
{"f_6806:srfi_13_scm",(void*)f_6806},
{"f_6780:srfi_13_scm",(void*)f_6780},
{"f_6715:srfi_13_scm",(void*)f_6715},
{"f_6733:srfi_13_scm",(void*)f_6733},
{"f_6737:srfi_13_scm",(void*)f_6737},
{"f_6751:srfi_13_scm",(void*)f_6751},
{"f_6727:srfi_13_scm",(void*)f_6727},
{"f_6669:srfi_13_scm",(void*)f_6669},
{"f_6687:srfi_13_scm",(void*)f_6687},
{"f_6691:srfi_13_scm",(void*)f_6691},
{"f_6681:srfi_13_scm",(void*)f_6681},
{"f_6627:srfi_13_scm",(void*)f_6627},
{"f_6645:srfi_13_scm",(void*)f_6645},
{"f_6649:srfi_13_scm",(void*)f_6649},
{"f_6639:srfi_13_scm",(void*)f_6639},
{"f_6600:srfi_13_scm",(void*)f_6600},
{"f_6607:srfi_13_scm",(void*)f_6607},
{"f_6577:srfi_13_scm",(void*)f_6577},
{"f_6584:srfi_13_scm",(void*)f_6584},
{"f_6550:srfi_13_scm",(void*)f_6550},
{"f_6557:srfi_13_scm",(void*)f_6557},
{"f_6530:srfi_13_scm",(void*)f_6530},
{"f_6537:srfi_13_scm",(void*)f_6537},
{"f_6505:srfi_13_scm",(void*)f_6505},
{"f_6517:srfi_13_scm",(void*)f_6517},
{"f_6521:srfi_13_scm",(void*)f_6521},
{"f_6524:srfi_13_scm",(void*)f_6524},
{"f_6511:srfi_13_scm",(void*)f_6511},
{"f_6487:srfi_13_scm",(void*)f_6487},
{"f_6499:srfi_13_scm",(void*)f_6499},
{"f_6493:srfi_13_scm",(void*)f_6493},
{"f_6428:srfi_13_scm",(void*)f_6428},
{"f_6434:srfi_13_scm",(void*)f_6434},
{"f_6481:srfi_13_scm",(void*)f_6481},
{"f_6438:srfi_13_scm",(void*)f_6438},
{"f_6468:srfi_13_scm",(void*)f_6468},
{"f_6450:srfi_13_scm",(void*)f_6450},
{"f_6456:srfi_13_scm",(void*)f_6456},
{"f_6410:srfi_13_scm",(void*)f_6410},
{"f_6422:srfi_13_scm",(void*)f_6422},
{"f_6416:srfi_13_scm",(void*)f_6416},
{"f_6392:srfi_13_scm",(void*)f_6392},
{"f_6404:srfi_13_scm",(void*)f_6404},
{"f_6398:srfi_13_scm",(void*)f_6398},
{"f_6374:srfi_13_scm",(void*)f_6374},
{"f_6386:srfi_13_scm",(void*)f_6386},
{"f_6380:srfi_13_scm",(void*)f_6380},
{"f_6356:srfi_13_scm",(void*)f_6356},
{"f_6368:srfi_13_scm",(void*)f_6368},
{"f_6362:srfi_13_scm",(void*)f_6362},
{"f_6300:srfi_13_scm",(void*)f_6300},
{"f_6310:srfi_13_scm",(void*)f_6310},
{"f_6324:srfi_13_scm",(void*)f_6324},
{"f_6330:srfi_13_scm",(void*)f_6330},
{"f_6318:srfi_13_scm",(void*)f_6318},
{"f_6254:srfi_13_scm",(void*)f_6254},
{"f_6264:srfi_13_scm",(void*)f_6264},
{"f_6278:srfi_13_scm",(void*)f_6278},
{"f_6272:srfi_13_scm",(void*)f_6272},
{"f_6182:srfi_13_scm",(void*)f_6182},
{"f_6200:srfi_13_scm",(void*)f_6200},
{"f_6233:srfi_13_scm",(void*)f_6233},
{"f_6235:srfi_13_scm",(void*)f_6235},
{"f_6184:srfi_13_scm",(void*)f_6184},
{"f_6134:srfi_13_scm",(void*)f_6134},
{"f_6146:srfi_13_scm",(void*)f_6146},
{"f_6158:srfi_13_scm",(void*)f_6158},
{"f_6165:srfi_13_scm",(void*)f_6165},
{"f_6173:srfi_13_scm",(void*)f_6173},
{"f_6152:srfi_13_scm",(void*)f_6152},
{"f_6140:srfi_13_scm",(void*)f_6140},
{"f_6086:srfi_13_scm",(void*)f_6086},
{"f_6098:srfi_13_scm",(void*)f_6098},
{"f_6110:srfi_13_scm",(void*)f_6110},
{"f_6117:srfi_13_scm",(void*)f_6117},
{"f_6125:srfi_13_scm",(void*)f_6125},
{"f_6104:srfi_13_scm",(void*)f_6104},
{"f_6092:srfi_13_scm",(void*)f_6092},
{"f_6035:srfi_13_scm",(void*)f_6035},
{"f_6047:srfi_13_scm",(void*)f_6047},
{"f_6059:srfi_13_scm",(void*)f_6059},
{"f_6066:srfi_13_scm",(void*)f_6066},
{"f_6077:srfi_13_scm",(void*)f_6077},
{"f_6074:srfi_13_scm",(void*)f_6074},
{"f_6053:srfi_13_scm",(void*)f_6053},
{"f_6041:srfi_13_scm",(void*)f_6041},
{"f_5984:srfi_13_scm",(void*)f_5984},
{"f_5996:srfi_13_scm",(void*)f_5996},
{"f_6008:srfi_13_scm",(void*)f_6008},
{"f_6015:srfi_13_scm",(void*)f_6015},
{"f_6026:srfi_13_scm",(void*)f_6026},
{"f_6023:srfi_13_scm",(void*)f_6023},
{"f_6002:srfi_13_scm",(void*)f_6002},
{"f_5990:srfi_13_scm",(void*)f_5990},
{"f_5917:srfi_13_scm",(void*)f_5917},
{"f_5929:srfi_13_scm",(void*)f_5929},
{"f_5941:srfi_13_scm",(void*)f_5941},
{"f_5964:srfi_13_scm",(void*)f_5964},
{"f_5959:srfi_13_scm",(void*)f_5959},
{"f_5935:srfi_13_scm",(void*)f_5935},
{"f_5923:srfi_13_scm",(void*)f_5923},
{"f_5855:srfi_13_scm",(void*)f_5855},
{"f_5867:srfi_13_scm",(void*)f_5867},
{"f_5879:srfi_13_scm",(void*)f_5879},
{"f_5889:srfi_13_scm",(void*)f_5889},
{"f_5900:srfi_13_scm",(void*)f_5900},
{"f_5897:srfi_13_scm",(void*)f_5897},
{"f_5873:srfi_13_scm",(void*)f_5873},
{"f_5861:srfi_13_scm",(void*)f_5861},
{"f_5807:srfi_13_scm",(void*)f_5807},
{"f_5819:srfi_13_scm",(void*)f_5819},
{"f_5831:srfi_13_scm",(void*)f_5831},
{"f_5838:srfi_13_scm",(void*)f_5838},
{"f_5846:srfi_13_scm",(void*)f_5846},
{"f_5825:srfi_13_scm",(void*)f_5825},
{"f_5813:srfi_13_scm",(void*)f_5813},
{"f_5759:srfi_13_scm",(void*)f_5759},
{"f_5771:srfi_13_scm",(void*)f_5771},
{"f_5783:srfi_13_scm",(void*)f_5783},
{"f_5790:srfi_13_scm",(void*)f_5790},
{"f_5798:srfi_13_scm",(void*)f_5798},
{"f_5777:srfi_13_scm",(void*)f_5777},
{"f_5765:srfi_13_scm",(void*)f_5765},
{"f_5708:srfi_13_scm",(void*)f_5708},
{"f_5720:srfi_13_scm",(void*)f_5720},
{"f_5732:srfi_13_scm",(void*)f_5732},
{"f_5739:srfi_13_scm",(void*)f_5739},
{"f_5750:srfi_13_scm",(void*)f_5750},
{"f_5747:srfi_13_scm",(void*)f_5747},
{"f_5726:srfi_13_scm",(void*)f_5726},
{"f_5714:srfi_13_scm",(void*)f_5714},
{"f_5657:srfi_13_scm",(void*)f_5657},
{"f_5669:srfi_13_scm",(void*)f_5669},
{"f_5681:srfi_13_scm",(void*)f_5681},
{"f_5688:srfi_13_scm",(void*)f_5688},
{"f_5699:srfi_13_scm",(void*)f_5699},
{"f_5696:srfi_13_scm",(void*)f_5696},
{"f_5675:srfi_13_scm",(void*)f_5675},
{"f_5663:srfi_13_scm",(void*)f_5663},
{"f_5590:srfi_13_scm",(void*)f_5590},
{"f_5602:srfi_13_scm",(void*)f_5602},
{"f_5614:srfi_13_scm",(void*)f_5614},
{"f_5637:srfi_13_scm",(void*)f_5637},
{"f_5632:srfi_13_scm",(void*)f_5632},
{"f_5608:srfi_13_scm",(void*)f_5608},
{"f_5596:srfi_13_scm",(void*)f_5596},
{"f_5528:srfi_13_scm",(void*)f_5528},
{"f_5540:srfi_13_scm",(void*)f_5540},
{"f_5552:srfi_13_scm",(void*)f_5552},
{"f_5562:srfi_13_scm",(void*)f_5562},
{"f_5573:srfi_13_scm",(void*)f_5573},
{"f_5570:srfi_13_scm",(void*)f_5570},
{"f_5546:srfi_13_scm",(void*)f_5546},
{"f_5534:srfi_13_scm",(void*)f_5534},
{"f_5498:srfi_13_scm",(void*)f_5498},
{"f_5510:srfi_13_scm",(void*)f_5510},
{"f_5522:srfi_13_scm",(void*)f_5522},
{"f_5516:srfi_13_scm",(void*)f_5516},
{"f_5504:srfi_13_scm",(void*)f_5504},
{"f_5468:srfi_13_scm",(void*)f_5468},
{"f_5480:srfi_13_scm",(void*)f_5480},
{"f_5492:srfi_13_scm",(void*)f_5492},
{"f_5486:srfi_13_scm",(void*)f_5486},
{"f_5474:srfi_13_scm",(void*)f_5474},
{"f_5406:srfi_13_scm",(void*)f_5406},
{"f_5416:srfi_13_scm",(void*)f_5416},
{"f_5450:srfi_13_scm",(void*)f_5450},
{"f_5441:srfi_13_scm",(void*)f_5441},
{"f_5344:srfi_13_scm",(void*)f_5344},
{"f_5354:srfi_13_scm",(void*)f_5354},
{"f_5379:srfi_13_scm",(void*)f_5379},
{"f_5222:srfi_13_scm",(void*)f_5222},
{"f_5234:srfi_13_scm",(void*)f_5234},
{"f_5246:srfi_13_scm",(void*)f_5246},
{"f_5338:srfi_13_scm",(void*)f_5338},
{"f_5240:srfi_13_scm",(void*)f_5240},
{"f_5228:srfi_13_scm",(void*)f_5228},
{"f_5192:srfi_13_scm",(void*)f_5192},
{"f_5204:srfi_13_scm",(void*)f_5204},
{"f_5216:srfi_13_scm",(void*)f_5216},
{"f_5315:srfi_13_scm",(void*)f_5315},
{"f_5210:srfi_13_scm",(void*)f_5210},
{"f_5198:srfi_13_scm",(void*)f_5198},
{"f_5162:srfi_13_scm",(void*)f_5162},
{"f_5174:srfi_13_scm",(void*)f_5174},
{"f_5186:srfi_13_scm",(void*)f_5186},
{"f_5292:srfi_13_scm",(void*)f_5292},
{"f_5180:srfi_13_scm",(void*)f_5180},
{"f_5168:srfi_13_scm",(void*)f_5168},
{"f_5132:srfi_13_scm",(void*)f_5132},
{"f_5144:srfi_13_scm",(void*)f_5144},
{"f_5156:srfi_13_scm",(void*)f_5156},
{"f_5269:srfi_13_scm",(void*)f_5269},
{"f_5150:srfi_13_scm",(void*)f_5150},
{"f_5138:srfi_13_scm",(void*)f_5138},
{"f_5102:srfi_13_scm",(void*)f_5102},
{"f_5114:srfi_13_scm",(void*)f_5114},
{"f_5126:srfi_13_scm",(void*)f_5126},
{"f_5120:srfi_13_scm",(void*)f_5120},
{"f_5108:srfi_13_scm",(void*)f_5108},
{"f_5072:srfi_13_scm",(void*)f_5072},
{"f_5084:srfi_13_scm",(void*)f_5084},
{"f_5096:srfi_13_scm",(void*)f_5096},
{"f_5090:srfi_13_scm",(void*)f_5090},
{"f_5078:srfi_13_scm",(void*)f_5078},
{"f_5042:srfi_13_scm",(void*)f_5042},
{"f_5054:srfi_13_scm",(void*)f_5054},
{"f_5066:srfi_13_scm",(void*)f_5066},
{"f_5060:srfi_13_scm",(void*)f_5060},
{"f_5048:srfi_13_scm",(void*)f_5048},
{"f_5012:srfi_13_scm",(void*)f_5012},
{"f_5024:srfi_13_scm",(void*)f_5024},
{"f_5036:srfi_13_scm",(void*)f_5036},
{"f_5030:srfi_13_scm",(void*)f_5030},
{"f_5018:srfi_13_scm",(void*)f_5018},
{"f_4927:srfi_13_scm",(void*)f_4927},
{"f_4931:srfi_13_scm",(void*)f_4931},
{"f_4940:srfi_13_scm",(void*)f_4940},
{"f_4953:srfi_13_scm",(void*)f_4953},
{"f_4988:srfi_13_scm",(void*)f_4988},
{"f_4963:srfi_13_scm",(void*)f_4963},
{"f_4854:srfi_13_scm",(void*)f_4854},
{"f_4858:srfi_13_scm",(void*)f_4858},
{"f_4867:srfi_13_scm",(void*)f_4867},
{"f_4872:srfi_13_scm",(void*)f_4872},
{"f_4903:srfi_13_scm",(void*)f_4903},
{"f_4882:srfi_13_scm",(void*)f_4882},
{"f_4769:srfi_13_scm",(void*)f_4769},
{"f_4773:srfi_13_scm",(void*)f_4773},
{"f_4782:srfi_13_scm",(void*)f_4782},
{"f_4795:srfi_13_scm",(void*)f_4795},
{"f_4805:srfi_13_scm",(void*)f_4805},
{"f_4696:srfi_13_scm",(void*)f_4696},
{"f_4700:srfi_13_scm",(void*)f_4700},
{"f_4709:srfi_13_scm",(void*)f_4709},
{"f_4714:srfi_13_scm",(void*)f_4714},
{"f_4724:srfi_13_scm",(void*)f_4724},
{"f_4657:srfi_13_scm",(void*)f_4657},
{"f_4664:srfi_13_scm",(void*)f_4664},
{"f_4673:srfi_13_scm",(void*)f_4673},
{"f_4694:srfi_13_scm",(void*)f_4694},
{"f_4667:srfi_13_scm",(void*)f_4667},
{"f_4527:srfi_13_scm",(void*)f_4527},
{"f_4539:srfi_13_scm",(void*)f_4539},
{"f_4581:srfi_13_scm",(void*)f_4581},
{"f_4627:srfi_13_scm",(void*)f_4627},
{"f_4646:srfi_13_scm",(void*)f_4646},
{"f_4586:srfi_13_scm",(void*)f_4586},
{"f_4596:srfi_13_scm",(void*)f_4596},
{"f_4551:srfi_13_scm",(void*)f_4551},
{"f_4533:srfi_13_scm",(void*)f_4533},
{"f_4397:srfi_13_scm",(void*)f_4397},
{"f_4409:srfi_13_scm",(void*)f_4409},
{"f_4451:srfi_13_scm",(void*)f_4451},
{"f_4497:srfi_13_scm",(void*)f_4497},
{"f_4519:srfi_13_scm",(void*)f_4519},
{"f_4456:srfi_13_scm",(void*)f_4456},
{"f_4469:srfi_13_scm",(void*)f_4469},
{"f_4421:srfi_13_scm",(void*)f_4421},
{"f_4403:srfi_13_scm",(void*)f_4403},
{"f_4360:srfi_13_scm",(void*)f_4360},
{"f_4372:srfi_13_scm",(void*)f_4372},
{"f_4378:srfi_13_scm",(void*)f_4378},
{"f_4388:srfi_13_scm",(void*)f_4388},
{"f_4366:srfi_13_scm",(void*)f_4366},
{"f_4319:srfi_13_scm",(void*)f_4319},
{"f_4331:srfi_13_scm",(void*)f_4331},
{"f_4337:srfi_13_scm",(void*)f_4337},
{"f_4347:srfi_13_scm",(void*)f_4347},
{"f_4325:srfi_13_scm",(void*)f_4325},
{"f_4133:srfi_13_scm",(void*)f_4133},
{"f_4156:srfi_13_scm",(void*)f_4156},
{"f_4158:srfi_13_scm",(void*)f_4158},
{"f_4164:srfi_13_scm",(void*)f_4164},
{"f_4288:srfi_13_scm",(void*)f_4288},
{"f_4174:srfi_13_scm",(void*)f_4174},
{"f_4177:srfi_13_scm",(void*)f_4177},
{"f_4198:srfi_13_scm",(void*)f_4198},
{"f_4201:srfi_13_scm",(void*)f_4201},
{"f_4221:srfi_13_scm",(void*)f_4221},
{"f_4236:srfi_13_scm",(void*)f_4236},
{"f_4251:srfi_13_scm",(void*)f_4251},
{"f_4301:srfi_13_scm",(void*)f_4301},
{"f_3954:srfi_13_scm",(void*)f_3954},
{"f_3977:srfi_13_scm",(void*)f_3977},
{"f_3979:srfi_13_scm",(void*)f_3979},
{"f_3985:srfi_13_scm",(void*)f_3985},
{"f_4102:srfi_13_scm",(void*)f_4102},
{"f_3995:srfi_13_scm",(void*)f_3995},
{"f_3998:srfi_13_scm",(void*)f_3998},
{"f_4020:srfi_13_scm",(void*)f_4020},
{"f_4023:srfi_13_scm",(void*)f_4023},
{"f_4040:srfi_13_scm",(void*)f_4040},
{"f_4052:srfi_13_scm",(void*)f_4052},
{"f_4069:srfi_13_scm",(void*)f_4069},
{"f_4115:srfi_13_scm",(void*)f_4115},
{"f_3908:srfi_13_scm",(void*)f_3908},
{"f_3920:srfi_13_scm",(void*)f_3920},
{"f_3930:srfi_13_scm",(void*)f_3930},
{"f_3944:srfi_13_scm",(void*)f_3944},
{"f_3914:srfi_13_scm",(void*)f_3914},
{"f_3866:srfi_13_scm",(void*)f_3866},
{"f_3878:srfi_13_scm",(void*)f_3878},
{"f_3884:srfi_13_scm",(void*)f_3884},
{"f_3898:srfi_13_scm",(void*)f_3898},
{"f_3872:srfi_13_scm",(void*)f_3872},
{"f_3833:srfi_13_scm",(void*)f_3833},
{"f_3839:srfi_13_scm",(void*)f_3839},
{"f_3860:srfi_13_scm",(void*)f_3860},
{"f_3815:srfi_13_scm",(void*)f_3815},
{"f_3827:srfi_13_scm",(void*)f_3827},
{"f_3821:srfi_13_scm",(void*)f_3821},
{"f_3772:srfi_13_scm",(void*)f_3772},
{"f_3779:srfi_13_scm",(void*)f_3779},
{"f_3784:srfi_13_scm",(void*)f_3784},
{"f_3809:srfi_13_scm",(void*)f_3809},
{"f_3782:srfi_13_scm",(void*)f_3782},
{"f_3754:srfi_13_scm",(void*)f_3754},
{"f_3766:srfi_13_scm",(void*)f_3766},
{"f_3760:srfi_13_scm",(void*)f_3760},
{"f_3736:srfi_13_scm",(void*)f_3736},
{"f_3748:srfi_13_scm",(void*)f_3748},
{"f_3742:srfi_13_scm",(void*)f_3742},
{"f_3714:srfi_13_scm",(void*)f_3714},
{"f_3721:srfi_13_scm",(void*)f_3721},
{"f_3684:srfi_13_scm",(void*)f_3684},
{"f_3697:srfi_13_scm",(void*)f_3697},
{"f_3668:srfi_13_scm",(void*)f_3668},
{"f_3682:srfi_13_scm",(void*)f_3682},
{"f_3628:srfi_13_scm",(void*)f_3628},
{"f_3601:srfi_13_scm",(void*)f_3601},
{"f_3613:srfi_13_scm",(void*)f_3613},
{"f_3607:srfi_13_scm",(void*)f_3607},
{"f_3508:srfi_13_scm",(void*)f_3508},
{"f_3574:srfi_13_scm",(void*)f_3574},
{"f_3538:srfi_13_scm",(void*)f_3538},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
