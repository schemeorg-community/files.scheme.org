/* Generated from setup-api.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2009-03-24 10:49
   Version 4.0.0 - SVN rev. 13887
   windows-mingw32-x86 [ manyargs dload ptables applyhook ]
   compiled 2009-03-24 on LENOVO-1 (MINGW32_NT-6.0)
   command line: setup-api.scm -no-trace -optimize-level 2 -include-path . -include-path ./ -feature debugbuild -feature chicken-compile-shared -dynamic -emit-import-library setup-api -ignore-repository -output-file setup-api.c
   used units: library eval data_structures ports extras srfi_69 srfi_1 regex utils posix srfi_13 extras ports data_structures files
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_69_toplevel)
C_externimport void C_ccall C_srfi_69_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_1_toplevel)
C_externimport void C_ccall C_srfi_1_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_regex_toplevel)
C_externimport void C_ccall C_regex_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_utils_toplevel)
C_externimport void C_ccall C_utils_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_posix_toplevel)
C_externimport void C_ccall C_posix_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_13_toplevel)
C_externimport void C_ccall C_srfi_13_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_files_toplevel)
C_externimport void C_ccall C_files_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[312];
static double C_possibly_force_alignment;
static C_char C_TLS li0[] C_aligned={C_lihdr(0,0,28),40,115,101,116,117,112,45,97,112,105,35,115,104,101,108,108,112,97,116,104,32,115,116,114,49,49,57,41,0,0,0,0};
static C_char C_TLS li1[] C_aligned={C_lihdr(0,0,25),40,115,101,116,117,112,45,97,112,105,35,99,114,111,115,115,45,99,104,105,99,107,101,110,41,0,0,0,0,0,0,0};
static C_char C_TLS li2[] C_aligned={C_lihdr(0,0,30),40,115,101,116,117,112,45,97,112,105,35,117,115,101,114,45,105,110,115,116,97,108,108,45,115,101,116,117,112,41,0,0};
static C_char C_TLS li3[] C_aligned={C_lihdr(0,0,34),40,115,101,116,117,112,45,97,112,105,35,115,117,100,111,45,105,110,115,116,97,108,108,32,46,32,97,114,103,115,49,53,49,41,0,0,0,0,0,0};
static C_char C_TLS li4[] C_aligned={C_lihdr(0,0,13),40,108,111,111,112,32,100,105,114,49,54,57,41,0,0,0};
static C_char C_TLS li5[] C_aligned={C_lihdr(0,0,27),40,99,114,101,97,116,101,45,100,105,114,101,99,116,111,114,121,45,48,32,100,105,114,49,54,53,41,0,0,0,0,0};
static C_char C_TLS li6[] C_aligned={C_lihdr(0,0,13),40,118,101,114,98,32,100,105,114,49,55,56,41,0,0,0};
static C_char C_TLS li7[] C_aligned={C_lihdr(0,0,15),40,102,95,52,55,54,57,32,100,105,114,49,56,50,41,0};
static C_char C_TLS li8[] C_aligned={C_lihdr(0,0,15),40,102,95,52,55,55,55,32,100,105,114,49,56,53,41,0};
static C_char C_TLS li9[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li10[] C_aligned={C_lihdr(0,0,7),40,97,49,57,56,48,41,0};
static C_char C_TLS li11[] C_aligned={C_lihdr(0,0,41),40,115,101,116,117,112,45,97,112,105,35,121,101,115,45,111,114,45,110,111,63,32,115,116,114,49,57,55,32,46,32,116,109,112,49,57,54,49,57,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li12[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li13[] C_aligned={C_lihdr(0,0,7),40,97,50,48,49,53,41,0};
static C_char C_TLS li14[] C_aligned={C_lihdr(0,0,7),40,97,50,48,48,53,41,0};
static C_char C_TLS li15[] C_aligned={C_lihdr(0,0,41),40,115,101,116,117,112,45,97,112,105,35,112,97,116,99,104,32,119,104,105,99,104,50,51,56,32,114,120,50,51,57,32,115,117,98,115,116,50,52,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li16[] C_aligned={C_lihdr(0,0,33),40,115,101,116,117,112,45,97,112,105,35,102,105,120,109,97,107,101,116,97,114,103,101,116,32,102,105,108,101,50,55,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li17[] C_aligned={C_lihdr(0,0,15),40,115,109,111,111,116,104,32,108,115,116,50,56,53,41,0};
static C_char C_TLS li18[] C_aligned={C_lihdr(0,0,14),40,97,50,49,57,49,32,99,109,100,50,56,57,41,0,0};
static C_char C_TLS li19[] C_aligned={C_lihdr(0,0,30),40,115,101,116,117,112,45,97,112,105,35,101,120,101,99,117,116,101,32,101,120,112,108,105,115,116,50,56,50,41,0,0};
static C_char C_TLS li20[] C_aligned={C_lihdr(0,0,37),40,115,101,116,117,112,45,97,112,105,35,109,97,107,101,58,102,111,114,109,45,101,114,114,111,114,32,115,51,57,53,32,112,51,57,54,41,0,0,0};
static C_char C_TLS li21[] C_aligned={C_lihdr(0,0,42),40,115,101,116,117,112,45,97,112,105,35,109,97,107,101,58,108,105,110,101,45,101,114,114,111,114,32,115,51,57,57,32,112,52,48,48,32,110,52,48,49,41,0,0,0,0,0,0};
static C_char C_TLS li22[] C_aligned={C_lihdr(0,0,7),40,97,50,53,53,50,41,0};
static C_char C_TLS li23[] C_aligned={C_lihdr(0,0,14),40,97,50,53,52,54,32,101,120,110,53,55,49,41,0,0};
static C_char C_TLS li24[] C_aligned={C_lihdr(0,0,7),40,97,50,53,56,49,41,0};
static C_char C_TLS li25[] C_aligned={C_lihdr(0,0,7),40,97,50,53,57,54,41,0};
static C_char C_TLS li26[] C_aligned={C_lihdr(0,0,20),40,97,50,53,57,48,32,46,32,97,114,103,115,53,54,53,53,55,55,41,0,0,0,0};
static C_char C_TLS li27[] C_aligned={C_lihdr(0,0,7),40,97,50,53,55,53,41,0};
static C_char C_TLS li28[] C_aligned={C_lihdr(0,0,15),40,97,50,53,52,48,32,107,53,54,52,53,54,57,41,0};
static C_char C_TLS li29[] C_aligned={C_lihdr(0,0,14),40,97,50,54,51,55,32,100,101,112,53,51,57,41,0,0};
static C_char C_TLS li30[] C_aligned={C_lihdr(0,0,12),40,97,50,54,54,54,32,100,53,51,48,41,0,0,0,0};
static C_char C_TLS li31[] C_aligned={C_lihdr(0,0,13),40,109,97,116,99,104,63,32,115,51,55,50,41,0,0,0};
static C_char C_TLS li32[] C_aligned={C_lihdr(0,0,15),40,108,111,111,112,32,108,105,110,101,115,51,55,55,41,0};
static C_char C_TLS li33[] C_aligned={C_lihdr(0,0,23),40,102,95,50,52,56,54,32,115,53,49,49,32,105,110,100,101,110,116,53,49,50,41,0};
static C_char C_TLS li34[] C_aligned={C_lihdr(0,0,15),40,97,50,55,48,57,32,105,116,101,109,53,57,56,41,0};
static C_char C_TLS li35[] C_aligned={C_lihdr(0,0,12),40,97,50,55,52,49,32,102,53,57,52,41,0,0,0,0};
static C_char C_TLS li36[] C_aligned={C_lihdr(0,0,14),40,97,50,51,55,57,32,100,101,112,52,54,52,41,0,0};
static C_char C_TLS li37[] C_aligned={C_lihdr(0,0,15),40,97,50,51,49,48,32,108,105,110,101,52,50,50,41,0};
static C_char C_TLS li38[] C_aligned={C_lihdr(0,0,49),40,115,101,116,117,112,45,97,112,105,35,109,97,107,101,58,109,97,107,101,47,112,114,111,99,47,104,101,108,112,101,114,32,115,112,101,99,53,48,49,32,97,114,103,118,53,48,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li39[] C_aligned={C_lihdr(0,0,45),40,115,101,116,117,112,45,97,112,105,35,109,97,107,101,47,112,114,111,99,32,103,54,48,56,54,48,57,54,50,48,32,46,32,114,118,97,114,54,49,48,54,50,49,41,0,0,0};
static C_char C_TLS li40[] C_aligned={C_lihdr(0,0,7),40,97,50,57,48,57,41,0};
static C_char C_TLS li41[] C_aligned={C_lihdr(0,0,7),40,97,50,57,49,56,41,0};
static C_char C_TLS li42[] C_aligned={C_lihdr(0,0,45),40,115,101,116,117,112,45,97,112,105,35,119,114,105,116,101,45,105,110,102,111,32,105,100,55,50,54,32,102,105,108,101,115,55,50,55,32,105,110,102,111,55,50,56,41,0,0,0};
static C_char C_TLS li43[] C_aligned={C_lihdr(0,0,26),40,98,111,100,121,56,48,48,32,101,114,114,56,49,48,32,112,114,101,102,105,120,56,49,49,41,0,0,0,0,0,0};
static C_char C_TLS li44[] C_aligned={C_lihdr(0,0,26),40,100,101,102,45,112,114,101,102,105,120,56,48,51,32,37,101,114,114,55,57,56,56,52,51,41,0,0,0,0,0,0};
static C_char C_TLS li45[] C_aligned={C_lihdr(0,0,12),40,100,101,102,45,101,114,114,56,48,50,41,0,0,0,0};
static C_char C_TLS li46[] C_aligned={C_lihdr(0,0,47),40,115,101,116,117,112,45,97,112,105,35,99,111,112,121,45,102,105,108,101,32,102,114,111,109,55,56,57,32,116,111,55,57,48,32,46,32,116,109,112,55,56,56,55,57,49,41,0};
static C_char C_TLS li47[] C_aligned={C_lihdr(0,0,35),40,115,101,116,117,112,45,97,112,105,35,109,111,118,101,45,102,105,108,101,32,102,114,111,109,56,53,55,32,116,111,56,53,56,41,0,0,0,0,0};
static C_char C_TLS li48[] C_aligned={C_lihdr(0,0,31),40,115,101,116,117,112,45,97,112,105,35,114,101,109,111,118,101,45,102,105,108,101,42,32,100,105,114,56,55,49,41,0};
static C_char C_TLS li49[] C_aligned={C_lihdr(0,0,46),40,115,101,116,117,112,45,97,112,105,35,109,97,107,101,45,100,101,115,116,45,112,97,116,104,110,97,109,101,32,112,97,116,104,56,56,48,32,102,105,108,101,56,56,49,41,0,0};
static C_char C_TLS li50[] C_aligned={C_lihdr(0,0,12),40,97,51,50,48,52,32,102,56,56,54,41,0,0,0,0};
static C_char C_TLS li51[] C_aligned={C_lihdr(0,0,35),40,115,101,116,117,112,45,97,112,105,35,99,104,101,99,107,45,102,105,108,101,108,105,115,116,32,102,108,105,115,116,56,56,52,41,0,0,0,0,0};
static C_char C_TLS li52[] C_aligned={C_lihdr(0,0,13),40,97,51,51,52,57,32,102,49,48,50,53,41,0,0,0};
static C_char C_TLS li53[] C_aligned={C_lihdr(0,0,13),40,97,51,51,57,51,32,102,49,48,49,54,41,0,0,0};
static C_char C_TLS li54[] C_aligned={C_lihdr(0,0,12),40,97,51,52,48,55,32,102,57,54,53,41,0,0,0,0};
static C_char C_TLS li55[] C_aligned={C_lihdr(0,0,56),40,115,101,116,117,112,45,97,112,105,35,105,110,115,116,97,108,108,45,101,120,116,101,110,115,105,111,110,32,105,100,57,52,49,32,102,105,108,101,115,57,52,50,32,46,32,116,109,112,57,52,48,57,52,51,41};
static C_char C_TLS li56[] C_aligned={C_lihdr(0,0,13),40,101,120,105,102,121,32,102,49,48,54,54,41,0,0,0};
static C_char C_TLS li57[] C_aligned={C_lihdr(0,0,13),40,97,51,54,49,51,32,102,49,48,56,49,41,0,0,0};
static C_char C_TLS li58[] C_aligned={C_lihdr(0,0,13),40,97,51,54,54,48,32,102,49,48,55,55,41,0,0,0};
static C_char C_TLS li59[] C_aligned={C_lihdr(0,0,58),40,115,101,116,117,112,45,97,112,105,35,105,110,115,116,97,108,108,45,112,114,111,103,114,97,109,32,105,100,49,48,52,57,32,102,105,108,101,115,49,48,53,48,32,46,32,116,109,112,49,48,52,56,49,48,53,49,41,0,0,0,0,0,0};
static C_char C_TLS li60[] C_aligned={C_lihdr(0,0,13),40,97,51,55,56,51,32,102,49,49,51,49,41,0,0,0};
static C_char C_TLS li61[] C_aligned={C_lihdr(0,0,57),40,115,101,116,117,112,45,97,112,105,35,105,110,115,116,97,108,108,45,115,99,114,105,112,116,32,105,100,49,49,48,54,32,102,105,108,101,115,49,49,48,55,32,46,32,116,109,112,49,49,48,53,49,49,48,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li62[] C_aligned={C_lihdr(0,0,33),40,115,101,116,117,112,45,97,112,105,35,114,101,112,111,45,112,97,116,104,32,116,109,112,49,49,54,51,49,49,54,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li63[] C_aligned={C_lihdr(0,0,37),40,115,101,116,117,112,45,97,112,105,35,101,110,115,117,114,101,45,100,105,114,101,99,116,111,114,121,32,112,97,116,104,49,49,56,50,41,0,0,0};
static C_char C_TLS li64[] C_aligned={C_lihdr(0,0,7),40,97,52,48,53,53,41,0};
static C_char C_TLS li65[] C_aligned={C_lihdr(0,0,7),40,97,52,48,54,49,41,0};
static C_char C_TLS li66[] C_aligned={C_lihdr(0,0,7),40,97,52,48,54,52,41,0};
static C_char C_TLS li67[] C_aligned={C_lihdr(0,0,7),40,97,52,48,55,48,41,0};
static C_char C_TLS li68[] C_aligned={C_lihdr(0,0,7),40,97,52,48,55,51,41,0};
static C_char C_TLS li69[] C_aligned={C_lihdr(0,0,7),40,97,52,48,55,54,41,0};
static C_char C_TLS li70[] C_aligned={C_lihdr(0,0,46),40,115,101,116,117,112,45,97,112,105,35,116,114,121,45,99,111,109,112,105,108,101,32,99,111,100,101,49,50,48,55,32,46,32,116,109,112,49,50,48,54,49,50,48,56,41,0,0};
static C_char C_TLS li71[] C_aligned={C_lihdr(0,0,42),40,115,101,116,117,112,45,97,112,105,35,114,101,113,117,105,114,101,100,45,99,104,105,99,107,101,110,45,118,101,114,115,105,111,110,32,118,49,50,53,52,41,0,0,0,0,0,0};
static C_char C_TLS li72[] C_aligned={C_lihdr(0,0,43),40,115,101,116,117,112,45,97,112,105,35,117,112,103,114,97,100,101,45,109,101,115,115,97,103,101,32,101,120,116,49,50,53,57,32,109,115,103,49,50,54,48,41,0,0,0,0,0};
static C_char C_TLS li73[] C_aligned={C_lihdr(0,0,15),40,108,111,111,112,32,97,114,103,115,49,50,54,55,41,0};
static C_char C_TLS li74[] C_aligned={C_lihdr(0,0,49),40,115,101,116,117,112,45,97,112,105,35,114,101,113,117,105,114,101,100,45,101,120,116,101,110,115,105,111,110,45,118,101,114,115,105,111,110,32,46,32,97,114,103,115,49,50,54,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li75[] C_aligned={C_lihdr(0,0,42),40,115,101,116,117,112,45,97,112,105,35,102,105,110,100,45,108,105,98,114,97,114,121,32,110,97,109,101,49,51,48,52,32,112,114,111,99,49,51,48,53,41,0,0,0,0,0,0};
static C_char C_TLS li76[] C_aligned={C_lihdr(0,0,32),40,115,101,116,117,112,45,97,112,105,35,102,105,110,100,45,104,101,97,100,101,114,32,110,97,109,101,49,51,48,56,41};
static C_char C_TLS li77[] C_aligned={C_lihdr(0,0,13),40,97,52,50,52,55,32,120,49,51,49,55,41,0,0,0};
static C_char C_TLS li78[] C_aligned={C_lihdr(0,0,21),40,118,101,114,115,105,111,110,45,62,108,105,115,116,32,118,49,51,49,53,41,0,0,0};
static C_char C_TLS li79[] C_aligned={C_lihdr(0,0,20),40,108,111,111,112,32,112,49,49,51,50,55,32,112,50,49,51,50,56,41,0,0,0,0};
static C_char C_TLS li80[] C_aligned={C_lihdr(0,0,36),40,115,101,116,117,112,45,97,112,105,35,118,101,114,115,105,111,110,62,61,63,32,118,49,49,51,49,49,32,118,50,49,51,49,50,41,0,0,0,0};
static C_char C_TLS li81[] C_aligned={C_lihdr(0,0,26),40,115,101,116,117,112,45,97,112,105,35,101,120,116,101,110,115,105,111,110,45,110,97,109,101,41,0,0,0,0,0,0};
static C_char C_TLS li82[] C_aligned={C_lihdr(0,0,43),40,115,101,116,117,112,45,97,112,105,35,101,120,116,101,110,115,105,111,110,45,118,101,114,115,105,111,110,32,46,32,116,109,112,49,51,56,56,49,51,56,57,41,0,0,0,0,0};
static C_char C_TLS li83[] C_aligned={C_lihdr(0,0,29),40,115,101,116,117,112,45,97,112,105,35,114,101,97,100,45,105,110,102,111,32,101,103,103,49,52,48,54,41,0,0,0};
static C_char C_TLS li84[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li85[] C_aligned={C_lihdr(0,0,38),40,115,101,116,117,112,45,97,112,105,35,99,114,101,97,116,101,45,116,101,109,112,111,114,97,114,121,45,100,105,114,101,99,116,111,114,121,41,0,0};
static C_char C_TLS li86[] C_aligned={C_lihdr(0,0,13),40,97,52,53,56,53,32,102,49,52,56,50,41,0,0,0};
static C_char C_TLS li87[] C_aligned={C_lihdr(0,0,14),40,119,97,108,107,32,100,105,114,49,52,55,56,41,0,0};
static C_char C_TLS li88[] C_aligned={C_lihdr(0,0,50),40,115,101,116,117,112,45,97,112,105,35,114,101,109,111,118,101,45,100,105,114,101,99,116,111,114,121,32,100,105,114,49,52,53,54,32,46,32,116,109,112,49,52,53,53,49,52,53,55,41,0,0,0,0,0,0};
static C_char C_TLS li89[] C_aligned={C_lihdr(0,0,36),40,115,101,116,117,112,45,97,112,105,35,114,101,109,111,118,101,45,101,120,116,101,110,115,105,111,110,32,101,103,103,49,52,57,56,41,0,0,0,0};
static C_char C_TLS li90[] C_aligned={C_lihdr(0,0,27),40,115,101,116,117,112,45,97,112,105,35,36,115,121,115,116,101,109,32,115,116,114,49,53,48,55,41,0,0,0,0,0};
static C_char C_TLS li91[] C_aligned={C_lihdr(0,0,21),40,101,110,115,117,114,101,45,115,116,114,105,110,103,32,120,49,51,55,48,41,0,0,0};
static C_char C_TLS li92[] C_aligned={C_lihdr(0,0,13),40,97,52,54,57,49,32,120,49,51,53,48,41,0,0,0};
static C_char C_TLS li93[] C_aligned={C_lihdr(0,0,10),40,116,111,112,108,101,118,101,108,41,0,0,0,0,0,0};


C_noret_decl(C_toplevel)
C_externexport void C_ccall C_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1619)
static void C_ccall f_1619(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1622)
static void C_ccall f_1622(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1625)
static void C_ccall f_1625(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1628)
static void C_ccall f_1628(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1631)
static void C_ccall f_1631(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1634)
static void C_ccall f_1634(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1637)
static void C_ccall f_1637(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1640)
static void C_ccall f_1640(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1643)
static void C_ccall f_1643(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1646)
static void C_ccall f_1646(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1649)
static void C_ccall f_1649(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1652)
static void C_ccall f_1652(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1655)
static void C_ccall f_1655(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1658)
static void C_ccall f_1658(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1661)
static void C_ccall f_1661(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4871)
static void C_ccall f_4871(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4867)
static void C_ccall f_4867(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4863)
static void C_ccall f_4863(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4859)
static void C_ccall f_4859(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1670)
static void C_ccall f_1670(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1674)
static void C_ccall f_1674(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1678)
static void C_ccall f_1678(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1682)
static void C_ccall f_1682(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1686)
static void C_ccall f_1686(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4827)
static void C_ccall f_4827(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1692)
static void C_ccall f_1692(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1695)
static void C_ccall f_1695(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1699)
static void C_ccall f_1699(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1703)
static void C_ccall f_1703(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1706)
static void C_ccall f_1706(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1709)
static void C_ccall f_1709(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1713)
static void C_ccall f_1713(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1716)
static void C_ccall f_1716(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4808)
static void C_ccall f_4808(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1719)
static void C_ccall f_1719(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1723)
static void C_ccall f_1723(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4795)
static void C_ccall f_4795(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1726)
static void C_fcall f_1726(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1747)
static void C_ccall f_1747(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1751)
static void C_ccall f_1751(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1755)
static void C_ccall f_1755(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1759)
static void C_ccall f_1759(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1763)
static void C_ccall f_1763(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1767)
static void C_ccall f_1767(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1853)
static void C_ccall f_1853(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1905)
static void C_ccall f_1905(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2077)
static void C_ccall f_2077(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4765)
static void C_ccall f_4765(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2831)
static void C_ccall f_2831(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4692)
static void C_ccall f_4692(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4708)
static void C_fcall f_4708(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4745)
static void C_ccall f_4745(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4738)
static void C_ccall f_4738(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4742)
static void C_ccall f_4742(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4715)
static void C_fcall f_4715(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4416)
static void C_ccall f_4416(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4670)
static void C_fcall f_4670(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4687)
static void C_ccall f_4687(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4674)
static void C_ccall f_4674(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4639)
static void C_ccall f_4639(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4668)
static void C_ccall f_4668(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4646)
static void C_ccall f_4646(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4657)
static void C_ccall f_4657(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4653)
static void C_ccall f_4653(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4539)
static void C_ccall f_4539(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4539)
static void C_ccall f_4539r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4543)
static void C_ccall f_4543(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4618)
static void C_ccall f_4618(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4574)
static void C_fcall f_4574(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4578)
static void C_ccall f_4578(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4586)
static void C_ccall f_4586(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4599)
static void C_ccall f_4599(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4605)
static void C_ccall f_4605(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4581)
static void C_ccall f_4581(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4569)
static void C_ccall f_4569(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4565)
static void C_ccall f_4565(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4486)
static void C_ccall f_4486(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4490)
static void C_ccall f_4490(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4528)
static void C_ccall f_4528(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4534)
static void C_ccall f_4534(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4493)
static void C_fcall f_4493(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4498)
static void C_fcall f_4498(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4525)
static void C_ccall f_4525(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4521)
static void C_ccall f_4521(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4505)
static void C_ccall f_4505(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4511)
static void C_ccall f_4511(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4517)
static void C_ccall f_4517(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4472)
static void C_ccall f_4472(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4484)
static void C_ccall f_4484(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4480)
static void C_ccall f_4480(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4428)
static void C_ccall f_4428(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4428)
static void C_ccall f_4428r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4432)
static void C_ccall f_4432(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4451)
static void C_ccall f_4451(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4441)
static void C_ccall f_4441(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4418)
static void C_ccall f_4418(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4426)
static void C_ccall f_4426(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4239)
static void C_ccall f_4239(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4266)
static void C_ccall f_4266(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4270)
static void C_ccall f_4270(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4272)
static void C_fcall f_4272(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4385)
static void C_ccall f_4385(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4375)
static void C_ccall f_4375(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4356)
static void C_ccall f_4356(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4332)
static void C_ccall f_4332(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4300)
static void C_ccall f_4300(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4242)
static void C_fcall f_4242(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4259)
static void C_ccall f_4259(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4248)
static void C_ccall f_4248(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4252)
static void C_ccall f_4252(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4229)
static void C_ccall f_4229(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4237)
static void C_ccall f_4237(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4215)
static void C_ccall f_4215(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4223)
static void C_ccall f_4223(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4227)
static void C_ccall f_4227(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4117)
static void C_ccall f_4117(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4117)
static void C_ccall f_4117r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4123)
static void C_fcall f_4123(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4136)
static void C_fcall f_4136(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4148)
static void C_ccall f_4148(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4151)
static void C_ccall f_4151(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4157)
static void C_fcall f_4157(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4186)
static void C_ccall f_4186(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4172)
static void C_ccall f_4172(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4179)
static void C_ccall f_4179(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4107)
static void C_fcall f_4107(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4115)
static void C_ccall f_4115(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4083)
static void C_ccall f_4083(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4101)
static void C_ccall f_4101(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4105)
static void C_ccall f_4105(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4090)
static void C_ccall f_4090(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4097)
static void C_ccall f_4097(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3971)
static void C_ccall f_3971(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3971)
static void C_ccall f_3971r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3975)
static void C_ccall f_3975(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4077)
static void C_ccall f_4077(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3978)
static void C_ccall f_3978(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4074)
static void C_ccall f_4074(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3981)
static void C_ccall f_3981(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4071)
static void C_ccall f_4071(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3984)
static void C_ccall f_3984(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4065)
static void C_ccall f_4065(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3987)
static void C_ccall f_3987(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4062)
static void C_ccall f_4062(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3990)
static void C_ccall f_3990(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3993)
static void C_ccall f_3993(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3996)
static void C_ccall f_3996(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4056)
static void C_ccall f_4056(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3999)
static void C_ccall f_3999(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4047)
static void C_ccall f_4047(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4033)
static void C_ccall f_4033(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4036)
static void C_ccall f_4036(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4002)
static void C_ccall f_4002(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4005)
static void C_ccall f_4005(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4019)
static void C_ccall f_4019(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4015)
static void C_ccall f_4015(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4008)
static void C_ccall f_4008(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3918)
static void C_fcall f_3918(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3922)
static void C_ccall f_3922(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3931)
static void C_ccall f_3931(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3943)
static void C_ccall f_3943(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3969)
static void C_ccall f_3969(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3937)
static void C_ccall f_3937(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3867)
static void C_fcall f_3867(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3871)
static void C_ccall f_3871(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3880)
static void C_ccall f_3880(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3887)
static void C_ccall f_3887(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3891)
static void C_ccall f_3891(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3874)
static void C_ccall f_3874(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3877)
static void C_ccall f_3877(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3731)
static void C_ccall f_3731(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3731)
static void C_ccall f_3731r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3735)
static void C_ccall f_3735(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3741)
static void C_ccall f_3741(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3744)
static void C_ccall f_3744(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3747)
static void C_ccall f_3747(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3833)
static void C_ccall f_3833(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3750)
static void C_ccall f_3750(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3784)
static void C_ccall f_3784(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3791)
static void C_ccall f_3791(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3794)
static void C_ccall f_3794(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3820)
static void C_ccall f_3820(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3797)
static void C_ccall f_3797(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3753)
static void C_ccall f_3753(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3782)
static void C_ccall f_3782(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3756)
static void C_ccall f_3756(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3574)
static void C_ccall f_3574(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3574)
static void C_ccall f_3574r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3578)
static void C_ccall f_3578(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3594)
static void C_ccall f_3594(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3597)
static void C_ccall f_3597(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3600)
static void C_ccall f_3600(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3697)
static void C_ccall f_3697(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3603)
static void C_ccall f_3603(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3661)
static void C_ccall f_3661(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3675)
static void C_ccall f_3675(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3679)
static void C_ccall f_3679(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3606)
static void C_ccall f_3606(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3614)
static void C_ccall f_3614(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3621)
static void C_ccall f_3621(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3624)
static void C_ccall f_3624(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3650)
static void C_ccall f_3650(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3627)
static void C_ccall f_3627(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3609)
static void C_ccall f_3609(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3580)
static void C_fcall f_3580(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3253)
static void C_ccall f_3253(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3260)
static void C_ccall f_3260(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3263)
static void C_fcall f_3263(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3302)
static void C_ccall f_3302(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3302)
static void C_ccall f_3302r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3306)
static void C_ccall f_3306(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3312)
static void C_ccall f_3312(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3315)
static void C_ccall f_3315(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3318)
static void C_ccall f_3318(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3321)
static void C_ccall f_3321(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3408)
static void C_ccall f_3408(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3415)
static void C_ccall f_3415(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3537)
static void C_ccall f_3537(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3508)
static void C_fcall f_3508(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3527)
static void C_ccall f_3527(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3418)
static void C_ccall f_3418(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3421)
static void C_ccall f_3421(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3505)
static void C_ccall f_3505(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3424)
static void C_ccall f_3424(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3482)
static void C_ccall f_3482(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3474)
static void C_ccall f_3474(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3439)
static void C_fcall f_3439(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3458)
static void C_ccall f_3458(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3430)
static void C_ccall f_3430(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3324)
static void C_ccall f_3324(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3386)
static void C_ccall f_3386(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3394)
static void C_ccall f_3394(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3402)
static void C_ccall f_3402(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3389)
static void C_ccall f_3389(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3330)
static void C_ccall f_3330(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3342)
static void C_ccall f_3342(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3350)
static void C_ccall f_3350(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3354)
static void C_ccall f_3354(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3357)
static void C_ccall f_3357(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3345)
static void C_ccall f_3345(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3336)
static void C_ccall f_3336(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3199)
static void C_fcall f_3199(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3205)
static void C_ccall f_3205(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3218)
static void C_ccall f_3218(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3221)
static void C_fcall f_3221(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3174)
static void C_fcall f_3174(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3194)
static void C_ccall f_3194(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3152)
static void C_ccall f_3152(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3172)
static void C_ccall f_3172(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3097)
static void C_ccall f_3097(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3104)
static void C_ccall f_3104(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3107)
static void C_ccall f_3107(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3126)
static void C_ccall f_3126(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3134)
static void C_ccall f_3134(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2947)
static void C_ccall f_2947(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2947)
static void C_ccall f_2947r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3049)
static void C_fcall f_3049(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3040)
static void C_fcall f_3040(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3048)
static void C_ccall f_3048(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2949)
static void C_fcall f_2949(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2956)
static void C_ccall f_2956(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3023)
static void C_ccall f_3023(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3013)
static void C_fcall f_3013(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2959)
static void C_ccall f_2959(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2962)
static void C_ccall f_2962(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2968)
static void C_ccall f_2968(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2971)
static void C_ccall f_2971(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2990)
static void C_ccall f_2990(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2998)
static void C_ccall f_2998(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2974)
static void C_ccall f_2974(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2833)
static void C_fcall f_2833(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2945)
static void C_ccall f_2945(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2941)
static void C_ccall f_2941(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2930)
static void C_ccall f_2930(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2840)
static void C_ccall f_2840(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2843)
static void C_ccall f_2843(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2927)
static void C_ccall f_2927(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2802)
static void C_ccall f_2802(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2846)
static void C_ccall f_2846(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2919)
static void C_ccall f_2919(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2878)
static void C_ccall f_2878(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2910)
static void C_ccall f_2910(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2881)
static void C_ccall f_2881(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2900)
static void C_ccall f_2900(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2908)
static void C_ccall f_2908(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2849)
static void C_ccall f_2849(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2875)
static void C_ccall f_2875(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2755)
static void C_ccall f_2755(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2755)
static void C_ccall f_2755r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2787)
static void C_ccall f_2787(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2465)
static void C_fcall f_2465(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2753)
static void C_ccall f_2753(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2469)
static void C_fcall f_2469(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2297)
static void C_ccall f_2297(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2306)
static void C_ccall f_2306(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2311)
static void C_ccall f_2311(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2318)
static void C_ccall f_2318(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2321)
static void C_ccall f_2321(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2330)
static void C_ccall f_2330(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2333)
static void C_ccall f_2333(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2372)
static void C_ccall f_2372(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2380)
static void C_ccall f_2380(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2342)
static void C_ccall f_2342(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2472)
static void C_ccall f_2472(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2457)
static void C_ccall f_2457(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2475)
static void C_ccall f_2475(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2480)
static void C_ccall f_2480(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2484)
static void C_ccall f_2484(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2742)
static void C_ccall f_2742(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2737)
static void C_ccall f_2737(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2699)
static void C_ccall f_2699(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2705)
static void C_ccall f_2705(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2718)
static void C_ccall f_2718(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2710)
static void C_ccall f_2710(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2486)
static void C_ccall f_2486(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2222)
static void C_fcall f_2222(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2235)
static void C_fcall f_2235(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2241)
static void C_ccall f_2241(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2213)
static void C_ccall f_2213(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2490)
static void C_ccall f_2490(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2493)
static void C_ccall f_2493(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2693)
static void C_ccall f_2693(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2496)
static void C_ccall f_2496(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2687)
static void C_ccall f_2687(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2499)
static void C_ccall f_2499(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2684)
static void C_ccall f_2684(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2669)
static void C_ccall f_2669(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2670)
static void C_ccall f_2670(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2508)
static void C_ccall f_2508(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2638)
static void C_ccall f_2638(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2642)
static void C_ccall f_2642(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2658)
static void C_ccall f_2658(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2665)
static void C_ccall f_2665(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2645)
static void C_ccall f_2645(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2655)
static void C_ccall f_2655(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2514)
static void C_ccall f_2514(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2604)
static void C_ccall f_2604(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2633)
static void C_ccall f_2633(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2611)
static void C_ccall f_2611(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2533)
static void C_ccall f_2533(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2541)
static void C_ccall f_2541(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2576)
static void C_ccall f_2576(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2591)
static void C_ccall f_2591(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2591)
static void C_ccall f_2591r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2597)
static void C_ccall f_2597(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2582)
static void C_ccall f_2582(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2547)
static void C_ccall f_2547(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2553)
static void C_ccall f_2553(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2571)
static void C_ccall f_2571(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2568)
static void C_ccall f_2568(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2557)
static void C_ccall f_2557(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2539)
static void C_ccall f_2539(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2277)
static void C_fcall f_2277(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2285)
static void C_ccall f_2285(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2267)
static void C_fcall f_2267(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2275)
static void C_ccall f_2275(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2161)
static void C_ccall f_2161(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2209)
static void C_ccall f_2209(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2192)
static void C_ccall f_2192(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2202)
static void C_ccall f_2202(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2196)
static void C_ccall f_2196(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2164)
static void C_ccall f_2164(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2168)
static void C_ccall f_2168(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2129)
static void C_ccall f_2129(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2108)
static void C_ccall f_2108(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2097)
static void C_ccall f_2097(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2104)
static void C_ccall f_2104(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2093)
static void C_ccall f_2093(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2179)
static void C_ccall f_2179(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2135)
static void C_fcall f_2135(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2159)
static void C_ccall f_2159(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2142)
static void C_fcall f_2142(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1987)
static void C_ccall f_1987(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2070)
static void C_ccall f_2070(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1991)
static void C_ccall f_1991(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2045)
static void C_ccall f_2045(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2048)
static void C_ccall f_2048(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2059)
static void C_ccall f_2059(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2063)
static void C_ccall f_2063(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2055)
static void C_ccall f_2055(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2006)
static void C_ccall f_2006(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2016)
static void C_ccall f_2016(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2022)
static void C_fcall f_2022(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2026)
static void C_ccall f_2026(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2042)
static void C_ccall f_2042(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2035)
static void C_ccall f_2035(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1907)
static void C_ccall f_1907(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1907)
static void C_ccall f_1907r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1911)
static void C_ccall f_1911(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1981)
static void C_ccall f_1981(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1914)
static void C_ccall f_1914(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1919)
static void C_fcall f_1919(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1923)
static void C_ccall f_1923(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1926)
static void C_ccall f_1926(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1929)
static void C_ccall f_1929(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1932)
static void C_ccall f_1932(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1935)
static void C_fcall f_1935(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1959)
static void C_ccall f_1959(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4777)
static void C_ccall f_4777(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4781)
static void C_ccall f_4781(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4792)
static void C_ccall f_4792(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4788)
static void C_ccall f_4788(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4769)
static void C_ccall f_4769(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4773)
static void C_ccall f_4773(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1888)
static void C_fcall f_1888(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1895)
static void C_ccall f_1895(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1856)
static void C_fcall f_1856(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1862)
static void C_fcall f_1862(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1886)
static void C_ccall f_1886(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1869)
static void C_fcall f_1869(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1879)
static void C_ccall f_1879(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1872)
static void C_ccall f_1872(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1831)
static void C_ccall f_1831(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1831)
static void C_ccall f_1831r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1805)
static void C_fcall f_1805(C_word t0) C_noret;
C_noret_decl(f_1738)
static void C_ccall f_1738(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1728)
static void C_ccall f_1728(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1736)
static void C_ccall f_1736(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_1726)
static void C_fcall trf_1726(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1726(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1726(t0,t1);}

C_noret_decl(trf_4708)
static void C_fcall trf_4708(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4708(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4708(t0,t1);}

C_noret_decl(trf_4715)
static void C_fcall trf_4715(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4715(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4715(t0,t1);}

C_noret_decl(trf_4670)
static void C_fcall trf_4670(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4670(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4670(t0,t1);}

C_noret_decl(trf_4574)
static void C_fcall trf_4574(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4574(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4574(t0,t1,t2);}

C_noret_decl(trf_4493)
static void C_fcall trf_4493(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4493(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4493(t0,t1);}

C_noret_decl(trf_4498)
static void C_fcall trf_4498(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4498(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4498(t0,t1);}

C_noret_decl(trf_4272)
static void C_fcall trf_4272(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4272(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4272(t0,t1,t2,t3);}

C_noret_decl(trf_4242)
static void C_fcall trf_4242(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4242(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4242(t0,t1);}

C_noret_decl(trf_4123)
static void C_fcall trf_4123(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4123(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4123(t0,t1,t2);}

C_noret_decl(trf_4136)
static void C_fcall trf_4136(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4136(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4136(t0,t1);}

C_noret_decl(trf_4157)
static void C_fcall trf_4157(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4157(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4157(t0,t1);}

C_noret_decl(trf_4107)
static void C_fcall trf_4107(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4107(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4107(t0,t1,t2);}

C_noret_decl(trf_3918)
static void C_fcall trf_3918(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3918(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3918(t0,t1);}

C_noret_decl(trf_3867)
static void C_fcall trf_3867(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3867(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3867(t0,t1);}

C_noret_decl(trf_3580)
static void C_fcall trf_3580(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3580(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3580(t0,t1);}

C_noret_decl(trf_3263)
static void C_fcall trf_3263(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3263(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3263(t0,t1);}

C_noret_decl(trf_3508)
static void C_fcall trf_3508(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3508(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3508(t0,t1);}

C_noret_decl(trf_3439)
static void C_fcall trf_3439(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3439(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3439(t0,t1);}

C_noret_decl(trf_3199)
static void C_fcall trf_3199(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3199(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3199(t0,t1);}

C_noret_decl(trf_3221)
static void C_fcall trf_3221(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3221(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3221(t0,t1);}

C_noret_decl(trf_3174)
static void C_fcall trf_3174(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3174(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3174(t0,t1,t2);}

C_noret_decl(trf_3049)
static void C_fcall trf_3049(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3049(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3049(t0,t1);}

C_noret_decl(trf_3040)
static void C_fcall trf_3040(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3040(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3040(t0,t1,t2);}

C_noret_decl(trf_2949)
static void C_fcall trf_2949(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2949(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2949(t0,t1,t2,t3);}

C_noret_decl(trf_3013)
static void C_fcall trf_3013(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3013(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3013(t0,t1);}

C_noret_decl(trf_2833)
static void C_fcall trf_2833(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2833(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2833(t0,t1,t2,t3);}

C_noret_decl(trf_2465)
static void C_fcall trf_2465(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2465(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2465(t0,t1,t2);}

C_noret_decl(trf_2469)
static void C_fcall trf_2469(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2469(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2469(t0,t1);}

C_noret_decl(trf_2222)
static void C_fcall trf_2222(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2222(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2222(t0,t1,t2);}

C_noret_decl(trf_2235)
static void C_fcall trf_2235(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2235(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2235(t0,t1);}

C_noret_decl(trf_2277)
static void C_fcall trf_2277(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2277(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2277(t0,t1,t2,t3);}

C_noret_decl(trf_2267)
static void C_fcall trf_2267(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2267(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2267(t0,t1,t2);}

C_noret_decl(trf_2135)
static void C_fcall trf_2135(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2135(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2135(t0,t1);}

C_noret_decl(trf_2142)
static void C_fcall trf_2142(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2142(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2142(t0,t1);}

C_noret_decl(trf_2022)
static void C_fcall trf_2022(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2022(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2022(t0,t1);}

C_noret_decl(trf_1919)
static void C_fcall trf_1919(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1919(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1919(t0,t1);}

C_noret_decl(trf_1935)
static void C_fcall trf_1935(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1935(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1935(t0,t1);}

C_noret_decl(trf_1888)
static void C_fcall trf_1888(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1888(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1888(t0,t1);}

C_noret_decl(trf_1856)
static void C_fcall trf_1856(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1856(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1856(t0,t1,t2);}

C_noret_decl(trf_1862)
static void C_fcall trf_1862(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1862(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1862(t0,t1,t2);}

C_noret_decl(trf_1869)
static void C_fcall trf_1869(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1869(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1869(t0,t1);}

C_noret_decl(trf_1805)
static void C_fcall trf_1805(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1805(void *dummy){
C_word t0=C_pick(0);
C_adjust_stack(-1);
f_1805(t0);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr2rv)
static void C_fcall tr2rv(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2rv(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n+1);
t2=C_restore_rest_vector(a,n);
(k)(t0,t1,t2);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_main_entry_point
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("toplevel"));
C_resize_stack(131072);
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(1392)){
C_save(t1);
C_rereclaim2(1392*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,312);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[2]=C_decode_literal(C_heaptop,"\376B\000\000\007chicken");
lf[3]=C_decode_literal(C_heaptop,"\376B\000\000\003csc");
lf[4]=C_decode_literal(C_heaptop,"\376B\000\000\003csi");
lf[5]=C_decode_literal(C_heaptop,"\376B\000\000\013chicken-bug");
lf[15]=C_h_intern(&lf[15],24,"setup-api#host-extension");
lf[18]=C_h_intern(&lf[18],24,"setup-api#chicken-prefix");
lf[19]=C_h_intern(&lf[19],19,"setup-api#shellpath");
lf[20]=C_h_intern(&lf[20],2,"qs");
lf[21]=C_h_intern(&lf[21],18,"normalize-pathname");
lf[22]=C_h_intern(&lf[22],23,"setup-api#cross-chicken");
lf[24]=C_h_intern(&lf[24],30,"setup-api#setup-root-directory");
lf[25]=C_h_intern(&lf[25],28,"setup-api#setup-verbose-flag");
lf[26]=C_h_intern(&lf[26],28,"setup-api#setup-install-flag");
lf[27]=C_h_intern(&lf[27],22,"setup-api#program-path");
lf[28]=C_h_intern(&lf[28],28,"setup-api#keep-intermediates");
lf[35]=C_h_intern(&lf[35],4,"copy");
lf[36]=C_decode_literal(C_heaptop,"\376B\000\000\011del /Q /S");
lf[37]=C_h_intern(&lf[37],4,"move");
lf[38]=C_decode_literal(C_heaptop,"\376B\000\000\005chmod");
lf[39]=C_decode_literal(C_heaptop,"\376B\000\000\006ranlib");
lf[40]=C_decode_literal(C_heaptop,"\376B\000\000\005cp -r");
lf[41]=C_decode_literal(C_heaptop,"\376B\000\000\006rm -fr");
lf[42]=C_h_intern(&lf[42],2,"mv");
lf[43]=C_decode_literal(C_heaptop,"\376B\000\000\005chmod");
lf[44]=C_decode_literal(C_heaptop,"\376B\000\000\006ranlib");
lf[45]=C_h_intern(&lf[45],22,"setup-api#sudo-install");
lf[46]=C_h_intern(&lf[46],5,"print");
lf[47]=C_decode_literal(C_heaptop,"\376B\000\0001Warning: cannot install as superuser with Windows");
lf[48]=C_decode_literal(C_heaptop,"\376B\000\000\012sudo cp -r");
lf[49]=C_decode_literal(C_heaptop,"\376B\000\000\013sudo rm -fr");
lf[50]=C_decode_literal(C_heaptop,"\376B\000\000\007sudo mv");
lf[51]=C_decode_literal(C_heaptop,"\376B\000\000\012sudo chmod");
lf[52]=C_decode_literal(C_heaptop,"\376B\000\000\013sudo ranlib");
lf[53]=C_h_intern(&lf[53],16,"create-directory");
lf[54]=C_h_intern(&lf[54],18,"pathname-directory");
lf[55]=C_h_intern(&lf[55],10,"directory\077");
lf[56]=C_h_intern(&lf[56],6,"printf");
lf[57]=C_decode_literal(C_heaptop,"\376B\000\000\035  creating directory `~a\047~%~!");
lf[59]=C_h_intern(&lf[59],7,"sprintf");
lf[60]=C_decode_literal(C_heaptop,"\376B\000\000\013mkdir -p ~a");
lf[61]=C_h_intern(&lf[61],34,"setup-api#create-directory/parents");
lf[62]=C_h_intern(&lf[62],21,"setup-api#abort-setup");
lf[63]=C_h_intern(&lf[63],20,"setup-api#yes-or-no\077");
lf[64]=C_decode_literal(C_heaptop,"\376B\000\000\003yes");
lf[65]=C_decode_literal(C_heaptop,"\376B\000\000\002no");
lf[66]=C_decode_literal(C_heaptop,"\376B\000\000\005abort");
lf[67]=C_decode_literal(C_heaptop,"\376B\000\000(~%Please enter \042yes\042, \042no\042 or \042abort\042.~%");
lf[68]=C_decode_literal(C_heaptop,"\376B\000\000\005abort");
lf[69]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[70]=C_h_intern(&lf[70],9,"read-line");
lf[71]=C_h_intern(&lf[71],12,"flush-output");
lf[72]=C_decode_literal(C_heaptop,"\376B\000\000\005[~A] ");
lf[73]=C_decode_literal(C_heaptop,"\376B\000\000\024~%~A (yes/no/abort) ");
lf[74]=C_h_intern(&lf[74],15,"\003sysget-keyword");
lf[75]=C_h_intern(&lf[75],6,"\000abort");
lf[76]=C_h_intern(&lf[76],8,"\000default");
lf[77]=C_h_intern(&lf[77],15,"setup-api#patch");
lf[78]=C_h_intern(&lf[78],10,"write-line");
lf[79]=C_h_intern(&lf[79],17,"string-substitute");
lf[80]=C_h_intern(&lf[80],20,"with-input-from-file");
lf[81]=C_h_intern(&lf[81],19,"with-output-to-file");
lf[82]=C_decode_literal(C_heaptop,"\376B\000\000\010~A ~A ~A");
lf[83]=C_h_intern(&lf[83],21,"create-temporary-file");
lf[84]=C_decode_literal(C_heaptop,"\376B\000\000\021patching ~A ...~%");
lf[85]=C_h_intern(&lf[85],21,"setup-api#run-verbose");
lf[87]=C_h_intern(&lf[87],26,"pathname-replace-extension");
lf[88]=C_h_intern(&lf[88],26,"\003sysload-dynamic-extension");
lf[89]=C_decode_literal(C_heaptop,"\376B\000\000\002so");
lf[90]=C_decode_literal(C_heaptop,"\376B\000\000\002so");
lf[91]=C_h_intern(&lf[91],18,"pathname-extension");
lf[92]=C_h_intern(&lf[92],17,"setup-api#execute");
lf[93]=C_h_intern(&lf[93],18,"string-intersperse");
lf[94]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[95]=C_decode_literal(C_heaptop,"\376B\000\000\003csc");
lf[96]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[97]=C_decode_literal(C_heaptop,"\376B\000\000\005-host");
lf[98]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[99]=C_h_intern(&lf[99],5,"cons*");
lf[100]=C_decode_literal(C_heaptop,"\376B\000\000\010-feature");
lf[101]=C_decode_literal(C_heaptop,"\376B\000\000\023compiling-extension");
lf[102]=C_h_intern(&lf[102],13,"make-pathname");
lf[103]=C_h_intern(&lf[103],7,"\003sysmap");
lf[104]=C_h_intern(&lf[104],8,"->string");
lf[105]=C_decode_literal(C_heaptop,"\376B\000\000\010  ~A~%~!");
lf[106]=C_h_intern(&lf[106],12,"\003sysfor-each");
lf[108]=C_h_intern(&lf[108],5,"error");
lf[109]=C_decode_literal(C_heaptop,"\376B\000\000\006~a: ~s");
lf[111]=C_decode_literal(C_heaptop,"\376B\000\000\023~a: ~s for line: ~a");
lf[113]=C_h_intern(&lf[113],6,"signal");
lf[114]=C_decode_literal(C_heaptop,"\376B\000\000\035make: Failed to make ~a: ~a~%");
lf[115]=C_h_intern(&lf[115],22,"with-exception-handler");
lf[116]=C_h_intern(&lf[116],30,"call-with-current-continuation");
lf[117]=C_decode_literal(C_heaptop,"\376B\000\000\025make: ~amaking ~a~a~%");
lf[118]=C_h_intern(&lf[118],13,"string-append");
lf[119]=C_decode_literal(C_heaptop,"\376B\000\000\011 because ");
lf[120]=C_decode_literal(C_heaptop,"\376B\000\000\010 changed");
lf[121]=C_decode_literal(C_heaptop,"\376B\000\000# just because (reason: ~a date: ~a)");
lf[122]=C_decode_literal(C_heaptop,"\376B\000\000\011 because ");
lf[123]=C_decode_literal(C_heaptop,"\376B\000\000\017 does not exist");
lf[124]=C_h_intern(&lf[124],22,"file-modification-time");
lf[125]=C_decode_literal(C_heaptop,"\376B\000\000\034dependancy ~a was not made~%");
lf[126]=C_h_intern(&lf[126],12,"file-exists\077");
lf[127]=C_h_intern(&lf[127],3,"any");
lf[128]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[129]=C_decode_literal(C_heaptop,"\376B\000\000\031don\047t know how to make ~a");
lf[130]=C_decode_literal(C_heaptop,"\376B\000\000\025make: ~achecking ~a~%");
lf[131]=C_decode_literal(C_heaptop,"\376B\000\000\017make: made ~a~%");
lf[132]=C_h_intern(&lf[132],7,"reverse");
lf[133]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[134]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[135]=C_h_intern(&lf[135],4,"caar");
lf[136]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[137]=C_h_intern(&lf[137],27,"condition-property-accessor");
lf[138]=C_h_intern(&lf[138],3,"exn");
lf[139]=C_h_intern(&lf[139],7,"message");
lf[140]=C_h_intern(&lf[140],19,"condition-predicate");
lf[141]=C_decode_literal(C_heaptop,"\376B\000\000\047argument is not a string or string list");
lf[142]=C_h_intern(&lf[142],5,"every");
lf[143]=C_h_intern(&lf[143],7,"string\077");
lf[144]=C_decode_literal(C_heaptop,"\376B\000\000#command part of line is not a thunk");
lf[145]=C_decode_literal(C_heaptop,"\376B\000\000\037dependency item is not a string");
lf[146]=C_decode_literal(C_heaptop,"\376B\000\000!second part of line is not a list");
lf[147]=C_decode_literal(C_heaptop,"\376B\000\0004line does not start with a string or list of strings");
lf[148]=C_decode_literal(C_heaptop,"\376B\000\000$list is not a list with 2 or 3 parts");
lf[149]=C_decode_literal(C_heaptop,"\376B\000\000\036specification is an empty list");
lf[150]=C_decode_literal(C_heaptop,"\376B\000\000\033specification is not a list");
lf[151]=C_h_intern(&lf[151],12,"vector->list");
lf[152]=C_h_intern(&lf[152],19,"setup-api#make/proc");
lf[153]=C_h_intern(&lf[153],9,"\003syserror");
lf[154]=C_decode_literal(C_heaptop,"\376B\000\0000no matching clause in call to \047case-lambda\047 form");
lf[155]=C_h_intern(&lf[155],29,"setup-api#installation-prefix");
lf[157]=C_h_intern(&lf[157],5,"files");
lf[158]=C_h_intern(&lf[158],3,"a+r");
lf[159]=C_h_intern(&lf[159],2,"pp");
lf[160]=C_decode_literal(C_heaptop,"\376B\000\000\012setup-info");
lf[161]=C_h_intern(&lf[161],15,"repository-path");
lf[163]=C_decode_literal(C_heaptop,"\376B\000\000\033writing info ~A -> ~S ...~%");
lf[164]=C_h_intern(&lf[164],10,"\003sysappend");
lf[165]=C_h_intern(&lf[165],19,"setup-api#copy-file");
lf[166]=C_decode_literal(C_heaptop,"\376B\000\000\023file does not exist");
lf[167]=C_h_intern(&lf[167],7,"warning");
lf[168]=C_decode_literal(C_heaptop,"\376B\000\000\023file does not exist");
lf[169]=C_h_intern(&lf[169],5,"glob\077");
lf[171]=C_h_intern(&lf[171],14,"string-prefix\077");
lf[172]=C_h_intern(&lf[172],19,"setup-api#move-file");
lf[173]=C_h_intern(&lf[173],22,"setup-api#remove-file*");
lf[175]=C_h_intern(&lf[175],18,"absolute-pathname\077");
lf[177]=C_decode_literal(C_heaptop,"\376B\000\000\032invalid file-specification");
lf[178]=C_h_intern(&lf[178],27,"setup-api#install-extension");
lf[179]=C_h_intern(&lf[179],13,"documentation");
lf[180]=C_h_intern(&lf[180],8,"examples");
lf[181]=C_h_intern(&lf[181],7,"newline");
lf[182]=C_h_intern(&lf[182],4,"a+rx");
lf[183]=C_h_intern(&lf[183],5,"chmod");
lf[184]=C_decode_literal(C_heaptop,"\376B\000\000\037\012* Installing example files in ");
lf[185]=C_decode_literal(C_heaptop,"\376B\000\000\001:");
lf[186]=C_decode_literal(C_heaptop,"\376B\000\000%\012* Installing documentation files in ");
lf[187]=C_decode_literal(C_heaptop,"\376B\000\000\001:");
lf[188]=C_h_intern(&lf[188],6,"static");
lf[189]=C_h_intern(&lf[189],6,"macosx");
lf[190]=C_decode_literal(C_heaptop,"\376B\000\000\001a");
lf[191]=C_h_intern(&lf[191],16,"software-version");
lf[192]=C_decode_literal(C_heaptop,"\376B\000\000\002so");
lf[193]=C_h_intern(&lf[193],25,"setup-api#install-program");
lf[194]=C_decode_literal(C_heaptop,"\376B\000\000\003exe");
lf[195]=C_decode_literal(C_heaptop,"\376B\000\000\002so");
lf[196]=C_decode_literal(C_heaptop,"\376B\000\000\001a");
lf[197]=C_decode_literal(C_heaptop,"\376B\000\000\003lib");
lf[198]=C_decode_literal(C_heaptop,"\376B\000\000\001a");
lf[199]=C_h_intern(&lf[199],24,"setup-api#install-script");
lf[200]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[201]=C_decode_literal(C_heaptop,"\376B\000\000Acannot create directory: a file with the same name already exists");
lf[202]=C_h_intern(&lf[202],3,"a+x");
lf[203]=C_h_intern(&lf[203],21,"setup-api#try-compile");
lf[204]=C_decode_literal(C_heaptop,"\376B\000\000\005~A ~A");
lf[205]=C_decode_literal(C_heaptop,"\376B\000\000\012succeeded.");
lf[206]=C_decode_literal(C_heaptop,"\376B\000\000\007failed.");
lf[207]=C_h_intern(&lf[207],6,"system");
lf[208]=C_decode_literal(C_heaptop,"\376B\000\000\004 ...");
lf[209]=C_decode_literal(C_heaptop,"\376B\000\000\002-c");
lf[210]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[211]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[212]=C_decode_literal(C_heaptop,"\376B\000\000\0042>&1");
lf[213]=C_h_intern(&lf[213],4,"conc");
lf[214]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[215]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[216]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[217]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[218]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[219]=C_decode_literal(C_heaptop,"\376B\000\000\014 >/dev/null ");
lf[220]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[221]=C_decode_literal(C_heaptop,"\376B\000\000\002-L");
lf[222]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[223]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[224]=C_h_intern(&lf[224],7,"display");
lf[225]=C_decode_literal(C_heaptop,"\376B\000\000\001o");
lf[226]=C_decode_literal(C_heaptop,"\376B\000\000\001c");
lf[227]=C_h_intern(&lf[227],13,"\000compile-only");
lf[228]=C_h_intern(&lf[228],5,"\000verb");
lf[229]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[230]=C_h_intern(&lf[230],8,"\000ldflags");
lf[231]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[232]=C_h_intern(&lf[232],7,"\000cflags");
lf[233]=C_h_intern(&lf[233],3,"\000cc");
lf[234]=C_h_intern(&lf[234],4,"\000c++");
lf[235]=C_h_intern(&lf[235],34,"setup-api#required-chicken-version");
lf[236]=C_decode_literal(C_heaptop,"\376B\000\000(CHICKEN version ~a or higher is required");
lf[237]=C_h_intern(&lf[237],11,"string-ci<\077");
lf[238]=C_h_intern(&lf[238],15,"chicken-version");
lf[240]=C_decode_literal(C_heaptop,"\376B\000\000uthe required extension `~s\047 ~a - please run~%~%  chicken-install ~a~%~%and "
"repeat the current installation operation.");
lf[241]=C_h_intern(&lf[241],36,"setup-api#required-extension-version");
lf[242]=C_decode_literal(C_heaptop,"\376B\000\0007is older than ~a, which is what this extension requires");
lf[243]=C_decode_literal(C_heaptop,"\376B\000\000%has no associated version information");
lf[244]=C_h_intern(&lf[244],7,"version");
lf[245]=C_decode_literal(C_heaptop,"\376B\000\000\020is not installed");
lf[246]=C_h_intern(&lf[246],21,"extension-information");
lf[247]=C_h_intern(&lf[247],30,"required-extension-information");
lf[248]=C_decode_literal(C_heaptop,"\376B\000\000\023bad argument format");
lf[249]=C_h_intern(&lf[249],22,"setup-api#test-compile");
lf[250]=C_h_intern(&lf[250],22,"setup-api#find-library");
lf[251]=C_decode_literal(C_heaptop,"\376B\000\000\002-l");
lf[252]=C_decode_literal(C_heaptop,"\376B\000\000T#ifdef __cplusplus~%extern \042C\042~%#endif~%char ~a();~%int main() { ~a(); retu"
"rn 0; }~%");
lf[253]=C_h_intern(&lf[253],21,"setup-api#find-header");
lf[254]=C_decode_literal(C_heaptop,"\376B\000\000\047#include <~a>\012int main() { return 0; }\012");
lf[255]=C_h_intern(&lf[255],20,"setup-api#version>=\077");
lf[256]=C_h_intern(&lf[256],19,"string-split-fields");
lf[257]=C_decode_literal(C_heaptop,"\376B\000\000\006[-\134._]");
lf[258]=C_h_intern(&lf[258],6,"\000infix");
lf[259]=C_h_intern(&lf[259],9,"string>=\077");
lf[260]=C_h_intern(&lf[260],36,"setup-api#extension-name-and-version");
lf[261]=C_h_intern(&lf[261],24,"setup-api#extension-name");
lf[262]=C_h_intern(&lf[262],27,"setup-api#extension-version");
lf[263]=C_h_intern(&lf[263],12,"string-null\077");
lf[264]=C_h_intern(&lf[264],19,"setup-api#read-info");
lf[265]=C_h_intern(&lf[265],4,"read");
lf[266]=C_decode_literal(C_heaptop,"\376B\000\000\013.setup-info");
lf[267]=C_h_intern(&lf[267],36,"setup-api#create-temporary-directory");
lf[268]=C_decode_literal(C_heaptop,"\376B\000\000\003tmp");
lf[269]=C_decode_literal(C_heaptop,"\376B\000\000\020chicken-install-");
lf[270]=C_decode_literal(C_heaptop,"\376B\000\000\004/tmp");
lf[271]=C_h_intern(&lf[271],6,"getenv");
lf[272]=C_decode_literal(C_heaptop,"\376B\000\000\003TMP");
lf[273]=C_decode_literal(C_heaptop,"\376B\000\000\004TEMP");
lf[274]=C_decode_literal(C_heaptop,"\376B\000\000\006TMPDIR");
lf[275]=C_h_intern(&lf[275],26,"setup-api#remove-directory");
lf[276]=C_decode_literal(C_heaptop,"\376B\000\000\016sudo rm -fr ~a");
lf[277]=C_h_intern(&lf[277],16,"delete-directory");
lf[278]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[279]=C_decode_literal(C_heaptop,"\376B\000\000\002..");
lf[280]=C_h_intern(&lf[280],11,"delete-file");
lf[281]=C_h_intern(&lf[281],9,"directory");
lf[282]=C_h_intern(&lf[282],16,"remove-directory");
lf[283]=C_decode_literal(C_heaptop,"\376B\000\000#cannot remove - directory not found");
lf[284]=C_h_intern(&lf[284],26,"setup-api#remove-extension");
lf[285]=C_decode_literal(C_heaptop,"\376B\000\000\012setup-info");
lf[286]=C_decode_literal(C_heaptop,"\376B\000\000-shell command failed with nonzero exit status");
lf[287]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[288]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[289]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\000\376\003\000\000\002\376B\000\000\000\376\377\016");
lf[290]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[291]=C_decode_literal(C_heaptop,"\376B\000\000\042invalid extension-name-and-version");
lf[292]=C_h_intern(&lf[292],14,"make-parameter");
lf[293]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\000\376\003\000\000\002\376B\000\000\000\376\377\016");
lf[294]=C_decode_literal(C_heaptop,"\376B\000\000\026CHICKEN_INSTALL_PREFIX");
lf[295]=C_h_intern(&lf[295],4,"exit");
lf[296]=C_h_intern(&lf[296],17,"current-directory");
lf[297]=C_decode_literal(C_heaptop,"\376B\000\000\012/usr/local");
lf[298]=C_h_intern(&lf[298],12,"string-match");
lf[299]=C_decode_literal(C_heaptop,"\376B\000\000\012(.*)/bin/\077");
lf[300]=C_decode_literal(C_heaptop,"\376B\000\000\016CHICKEN_PREFIX");
lf[301]=C_decode_literal(C_heaptop,"\376B\000\000\003doc");
lf[302]=C_h_intern(&lf[302],17,"\003syspeek-c-string");
lf[303]=C_decode_literal(C_heaptop,"\376B\000\000\021share/chicken/doc");
lf[304]=C_decode_literal(C_heaptop,"\376B\000\000\016CHICKEN_PREFIX");
lf[305]=C_decode_literal(C_heaptop,"\376B\000\000\003bin");
lf[306]=C_decode_literal(C_heaptop,"\376B\000\000\016CHICKEN_PREFIX");
lf[307]=C_h_intern(&lf[307],17,"register-feature!");
lf[308]=C_h_intern(&lf[308],13,"chicken-setup");
lf[309]=C_h_intern(&lf[309],7,"windows");
lf[310]=C_h_intern(&lf[310],14,"build-platform");
lf[311]=C_h_intern(&lf[311],13,"software-type");
C_register_lf2(lf,312,create_ptable());
t2=C_mutate(&lf[0] /* (set! c717 ...) */,lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1619,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t3);}

/* k1617 */
static void C_ccall f_1619(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1619,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1622,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1620 in k1617 */
static void C_ccall f_1622(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1622,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1625,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1623 in k1620 in k1617 */
static void C_ccall f_1625(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1625,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1628,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_1628(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1628,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1631,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_1631(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1631,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1634,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_1634(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1634,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1637,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_1_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_1637(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1637,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1640,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_regex_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_1640(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1640,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1643,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_utils_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_1643(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1643,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1646,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_posix_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_1646(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1646,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1649,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_13_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_1649(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1649,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1652,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_1652(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1652,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1655,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_1655(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1655,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1658,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_1658(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1658,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1661,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_files_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_1661(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1661,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4871,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t3=*((C_word*)lf[302]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_CHICKEN_PROGRAM),C_fix(0));}

/* k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_4871(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4871,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[2],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4867,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[302]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)C_CSC_PROGRAM),C_fix(0));}

/* k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_4867(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4867,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[3],t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4863,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[302]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)C_CSI_PROGRAM),C_fix(0));}

/* k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_4863(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4863,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[4],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4859,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[302]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)C_CHICKEN_BUG_PROGRAM),C_fix(0));}

/* k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_4859(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[21],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4859,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[5],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t5);
t7=C_mutate(&lf[6] /* (set! setup-api#*installed-executables* ...) */,t6);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1670,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t9=*((C_word*)lf[302]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t8,C_mpointer(&a,(void*)C_TARGET_CC),C_fix(0));}

/* k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_1670(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1670,2,t0,t1);}
t2=C_mutate(&lf[7] /* (set! setup-api#*cc* ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1674,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[302]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)C_TARGET_CXX),C_fix(0));}

/* k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_1674(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1674,2,t0,t1);}
t2=C_mutate(&lf[8] /* (set! setup-api#*cxx* ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1678,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[302]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)C_TARGET_CFLAGS),C_fix(0));}

/* k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_1678(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1678,2,t0,t1);}
t2=C_mutate(&lf[9] /* (set! setup-api#*target-cflags* ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1682,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[302]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)C_TARGET_MORE_LIBS),C_fix(0));}

/* k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_1682(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1682,2,t0,t1);}
t2=C_mutate(&lf[10] /* (set! setup-api#*target-libs* ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1686,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[302]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)C_TARGET_LIB_HOME),C_fix(0));}

/* k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_1686(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1686,2,t0,t1);}
t2=C_mutate(&lf[11] /* (set! setup-api#*target-lib-home* ...) */,t1);
t3=lf[12] /* setup-api#*sudo* */ =C_SCHEME_FALSE;;
t4=C_mutate(&lf[13] /* (set! setup-api#*windows-shell* ...) */,C_mk_bool(C_WINDOWS_SHELL));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1692,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4827,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 84   software-type */
((C_proc2)C_retrieve_symbol_proc(lf[311]))(2,*((C_word*)lf[311]+1),t6);}

/* k4825 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_4827(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(t1,lf[309]);
if(C_truep(t2)){
/* setup-api.scm: 85   build-platform */
((C_proc2)C_retrieve_symbol_proc(lf[310]))(2,*((C_word*)lf[310]+1),((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[2];
f_1692(2,t3,C_SCHEME_FALSE);}}

/* k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_1692(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1692,2,t0,t1);}
t2=C_mutate(&lf[14] /* (set! setup-api#*windows* ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1695,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 87   register-feature! */
((C_proc3)C_retrieve_symbol_proc(lf[307]))(3,*((C_word*)lf[307]+1),t3,lf[308]);}

/* k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_1695(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1695,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1699,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 89   make-parameter */
((C_proc3)C_retrieve_symbol_proc(lf[292]))(3,*((C_word*)lf[292]+1),t2,C_SCHEME_FALSE);}

/* k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_1699(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1699,2,t0,t1);}
t2=C_mutate((C_word*)lf[15]+1 /* (set! setup-api#host-extension ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1703,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 92   getenv */
((C_proc3)C_retrieve_symbol_proc(lf[271]))(3,*((C_word*)lf[271]+1),t3,lf[306]);}

/* k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_1703(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1703,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1706,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
/* setup-api.scm: 93   make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[102]))(4,*((C_word*)lf[102]+1),t2,t1,lf[305]);}
else{
t3=t2;
f_1706(2,t3,C_SCHEME_FALSE);}}

/* k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_1706(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1706,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1709,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
t3=t2;
f_1709(2,t3,t1);}
else{
/* ##sys#peek-c-string */
t3=*((C_word*)lf[302]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_INSTALL_BIN_HOME),C_fix(0));}}

/* k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_1709(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1709,2,t0,t1);}
t2=C_mutate(&lf[16] /* (set! setup-api#*chicken-bin-path* ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1713,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 97   getenv */
((C_proc3)C_retrieve_symbol_proc(lf[271]))(3,*((C_word*)lf[271]+1),t3,lf[304]);}

/* k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_1713(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1713,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1716,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
/* setup-api.scm: 98   make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[102]))(4,*((C_word*)lf[102]+1),t2,t1,lf[303]);}
else{
t3=t2;
f_1716(2,t3,C_SCHEME_FALSE);}}

/* k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_1716(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1716,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1719,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
t3=t2;
f_1719(2,t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4808,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[302]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)C_INSTALL_SHARE_HOME),C_fix(0));}}

/* k4806 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_4808(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 99   make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[102]))(4,*((C_word*)lf[102]+1),((C_word*)t0)[2],t1,lf[301]);}

/* k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_1719(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1719,2,t0,t1);}
t2=C_mutate(&lf[17] /* (set! setup-api#*doc-path* ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1723,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 104  getenv */
((C_proc3)C_retrieve_symbol_proc(lf[271]))(3,*((C_word*)lf[271]+1),t3,lf[300]);}

/* k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_1723(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1723,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1726,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
t3=t2;
f_1726(t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4795,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 105  string-match */
((C_proc4)C_retrieve_symbol_proc(lf[298]))(4,*((C_word*)lf[298]+1),t3,lf[299],C_retrieve2(lf[16],"setup-api#*chicken-bin-path*"));}}

/* k4793 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_4795(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_1726(t2,(C_truep(t1)?(C_word)C_i_cadr(t1):lf[297]));}

/* k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_fcall f_1726(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1726,NULL,2,t0,t1);}
t2=C_mutate((C_word*)lf[18]+1 /* (set! setup-api#chicken-prefix ...) */,t1);
t3=C_mutate((C_word*)lf[19]+1 /* (set! setup-api#shellpath ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1728,a[2]=((C_word)li0),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[22]+1 /* (set! setup-api#cross-chicken ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1738,a[2]=((C_word)li1),tmp=(C_word)a,a+=3,tmp));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1747,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 116  current-directory */
((C_proc2)C_retrieve_symbol_proc(lf[296]))(2,*((C_word*)lf[296]+1),t5);}

/* k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_1747(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1747,2,t0,t1);}
t2=C_mutate(&lf[23] /* (set! setup-api#*base-directory* ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1751,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 118  make-parameter */
((C_proc3)C_retrieve_symbol_proc(lf[292]))(3,*((C_word*)lf[292]+1),t3,C_retrieve2(lf[23],"setup-api#*base-directory*"));}

/* k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_1751(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1751,2,t0,t1);}
t2=C_mutate((C_word*)lf[24]+1 /* (set! setup-api#setup-root-directory ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1755,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 119  make-parameter */
((C_proc3)C_retrieve_symbol_proc(lf[292]))(3,*((C_word*)lf[292]+1),t3,C_SCHEME_FALSE);}

/* k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_1755(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1755,2,t0,t1);}
t2=C_mutate((C_word*)lf[25]+1 /* (set! setup-api#setup-verbose-flag ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1759,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 120  make-parameter */
((C_proc3)C_retrieve_symbol_proc(lf[292]))(3,*((C_word*)lf[292]+1),t3,C_SCHEME_TRUE);}

/* k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_1759(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1759,2,t0,t1);}
t2=C_mutate((C_word*)lf[26]+1 /* (set! setup-api#setup-install-flag ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1763,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 121  make-parameter */
((C_proc3)C_retrieve_symbol_proc(lf[292]))(3,*((C_word*)lf[292]+1),t3,C_retrieve2(lf[16],"setup-api#*chicken-bin-path*"));}

/* k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_1763(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1763,2,t0,t1);}
t2=C_mutate((C_word*)lf[27]+1 /* (set! setup-api#program-path ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1767,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 122  make-parameter */
((C_proc3)C_retrieve_symbol_proc(lf[292]))(3,*((C_word*)lf[292]+1),t3,C_SCHEME_FALSE);}

/* k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_1767(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1767,2,t0,t1);}
t2=C_mutate((C_word*)lf[28]+1 /* (set! setup-api#keep-intermediates ...) */,t1);
t3=lf[29] /* setup-api#*copy-command* */ =C_SCHEME_UNDEFINED;;
t4=lf[30] /* setup-api#*remove-command* */ =C_SCHEME_UNDEFINED;;
t5=lf[31] /* setup-api#*move-command* */ =C_SCHEME_UNDEFINED;;
t6=lf[32] /* setup-api#*chmod-command* */ =C_SCHEME_UNDEFINED;;
t7=lf[33] /* setup-api#*ranlib-command* */ =C_SCHEME_UNDEFINED;;
t8=C_mutate(&lf[34] /* (set! setup-api#user-install-setup ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1805,a[2]=((C_word)li2),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[45]+1 /* (set! setup-api#sudo-install ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1831,a[2]=((C_word)li3),tmp=(C_word)a,a+=3,tmp));
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1853,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 175  user-install-setup */
f_1805(t10);}

/* k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_1853(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1853,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_retrieve(lf[53]);
t7=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1856,a[2]=t6,a[3]=((C_word)li5),tmp=(C_word)a,a+=4,tmp));
t8=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1888,a[2]=((C_word)li6),tmp=(C_word)a,a+=3,tmp));
t9=(C_truep(C_retrieve2(lf[13],"setup-api#*windows-shell*"))?(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4769,a[2]=t5,a[3]=t3,a[4]=((C_word)li7),tmp=(C_word)a,a+=5,tmp):(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4777,a[2]=t5,a[3]=((C_word)li8),tmp=(C_word)a,a+=4,tmp));
t10=C_mutate((C_word*)lf[61]+1 /* (set! setup-api#create-directory/parents ...) */,t9);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1905,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 197  make-parameter */
((C_proc3)C_retrieve_symbol_proc(lf[292]))(3,*((C_word*)lf[292]+1),t11,C_retrieve(lf[295]));}

/* k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_1905(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1905,2,t0,t1);}
t2=C_mutate((C_word*)lf[62]+1 /* (set! setup-api#abort-setup ...) */,t1);
t3=C_mutate((C_word*)lf[63]+1 /* (set! setup-api#yes-or-no? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1907,a[2]=((C_word)li11),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[77]+1 /* (set! setup-api#patch ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1987,a[2]=((C_word)li15),tmp=(C_word)a,a+=3,tmp));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2077,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 232  make-parameter */
((C_proc3)C_retrieve_symbol_proc(lf[292]))(3,*((C_word*)lf[292]+1),t5,C_SCHEME_TRUE);}

/* k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_2077(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[24],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2077,2,t0,t1);}
t2=C_mutate((C_word*)lf[85]+1 /* (set! setup-api#run-verbose ...) */,t1);
t3=C_mutate(&lf[86] /* (set! setup-api#fixmaketarget ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2135,a[2]=((C_word)li16),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[92]+1 /* (set! setup-api#execute ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2161,a[2]=((C_word)li19),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate(&lf[107] /* (set! setup-api#make:form-error ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2267,a[2]=((C_word)li20),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate(&lf[110] /* (set! setup-api#make:line-error ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2277,a[2]=((C_word)li21),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate(&lf[112] /* (set! setup-api#make:make/proc/helper ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2465,a[2]=((C_word)li38),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[152]+1 /* (set! setup-api#make/proc ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2755,a[2]=((C_word)li39),tmp=(C_word)a,a+=3,tmp));
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2831,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4765,a[2]=t9,tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 434  getenv */
((C_proc3)C_retrieve_symbol_proc(lf[271]))(3,*((C_word*)lf[271]+1),t10,lf[294]);}

/* k4763 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_4765(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?t1:C_SCHEME_FALSE);
/* setup-api.scm: 434  make-parameter */
((C_proc3)C_retrieve_symbol_proc(lf[292]))(3,*((C_word*)lf[292]+1),((C_word*)t0)[2],t2);}

/* k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_2831(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word ab[60],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2831,2,t0,t1);}
t2=C_mutate((C_word*)lf[155]+1 /* (set! setup-api#installation-prefix ...) */,t1);
t3=C_mutate(&lf[156] /* (set! setup-api#write-info ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2833,a[2]=((C_word)li42),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[165]+1 /* (set! setup-api#copy-file ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2947,a[2]=((C_word)li46),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[172]+1 /* (set! setup-api#move-file ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3097,a[2]=((C_word)li47),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[173]+1 /* (set! setup-api#remove-file* ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3152,a[2]=((C_word)li48),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate(&lf[174] /* (set! setup-api#make-dest-pathname ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3174,a[2]=((C_word)li49),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate(&lf[176] /* (set! setup-api#check-filelist ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3199,a[2]=((C_word)li51),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[178]+1 /* (set! setup-api#install-extension ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3302,a[2]=((C_word)li55),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[193]+1 /* (set! setup-api#install-program ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3574,a[2]=((C_word)li59),tmp=(C_word)a,a+=3,tmp));
t11=C_mutate((C_word*)lf[199]+1 /* (set! setup-api#install-script ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3731,a[2]=((C_word)li61),tmp=(C_word)a,a+=3,tmp));
t12=C_mutate(&lf[162] /* (set! setup-api#repo-path ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3867,a[2]=((C_word)li62),tmp=(C_word)a,a+=3,tmp));
t13=C_mutate(&lf[170] /* (set! setup-api#ensure-directory ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3918,a[2]=((C_word)li63),tmp=(C_word)a,a+=3,tmp));
t14=C_mutate((C_word*)lf[203]+1 /* (set! setup-api#try-compile ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3971,a[2]=((C_word)li70),tmp=(C_word)a,a+=3,tmp));
t15=C_mutate((C_word*)lf[235]+1 /* (set! setup-api#required-chicken-version ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4083,a[2]=((C_word)li71),tmp=(C_word)a,a+=3,tmp));
t16=C_mutate(&lf[239] /* (set! setup-api#upgrade-message ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4107,a[2]=((C_word)li72),tmp=(C_word)a,a+=3,tmp));
t17=C_mutate((C_word*)lf[241]+1 /* (set! setup-api#required-extension-version ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4117,a[2]=((C_word)li74),tmp=(C_word)a,a+=3,tmp));
t18=C_mutate((C_word*)lf[249]+1 /* (set! setup-api#test-compile ...) */,C_retrieve(lf[203]));
t19=C_mutate((C_word*)lf[250]+1 /* (set! setup-api#find-library ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4215,a[2]=((C_word)li75),tmp=(C_word)a,a+=3,tmp));
t20=C_mutate((C_word*)lf[253]+1 /* (set! setup-api#find-header ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4229,a[2]=((C_word)li76),tmp=(C_word)a,a+=3,tmp));
t21=C_mutate((C_word*)lf[255]+1 /* (set! setup-api#version>=? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4239,a[2]=((C_word)li80),tmp=(C_word)a,a+=3,tmp));
t22=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4416,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t23=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4692,a[2]=((C_word)li92),tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 687  make-parameter */
((C_proc4)C_retrieve_symbol_proc(lf[292]))(4,*((C_word*)lf[292]+1),t22,lf[293],t23);}

/* a4691 in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_4692(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4692,3,t0,t1,t2);}
t3=(C_word)C_i_not(t2);
t4=(C_truep(t3)?t3:(C_word)C_i_nullp(t2));
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,lf[289]);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4708,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_listp(t2))){
t6=(C_word)C_i_length(t2);
t7=t5;
f_4708(t7,(C_word)C_i_nequalp(C_fix(2),t6));}
else{
t6=t5;
f_4708(t6,C_SCHEME_FALSE);}}}

/* k4706 in a4691 in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_fcall f_4708(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4708,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(C_word)C_i_cadr(((C_word*)t0)[3]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4715,a[2]=((C_word)li91),tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4738,a[2]=t3,a[3]=t4,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* setup-api.scm: 695  ensure-string */
f_4715(t5,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4745,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 697  warning */
((C_proc4)C_retrieve_symbol_proc(lf[167]))(4,*((C_word*)lf[167]+1),t2,lf[291],((C_word*)t0)[3]);}}

/* k4743 in k4706 in a4691 in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_4745(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 698  extension-name-and-version */
((C_proc2)C_retrieve_symbol_proc(lf[260]))(2,*((C_word*)lf[260]+1),((C_word*)t0)[2]);}

/* k4736 in k4706 in a4691 in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_4738(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4738,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4742,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 695  ensure-string */
f_4715(t2,((C_word*)t0)[2]);}

/* k4740 in k4736 in k4706 in a4691 in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_4742(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4742,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[2],t1));}

/* ensure-string in k4706 in a4691 in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_fcall f_4715(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4715,NULL,2,t1,t2);}
t3=(C_word)C_i_not(t2);
t4=(C_truep(t3)?t3:(C_word)C_i_nullp(t2));
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,lf[290]);}
else{
/* setup-api.scm: 694  ->string */
((C_proc3)C_retrieve_symbol_proc(lf[104]))(3,*((C_word*)lf[104]+1),t1,t2);}}

/* k4414 in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_4416(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[21],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4416,2,t0,t1);}
t2=C_mutate((C_word*)lf[260]+1 /* (set! setup-api#extension-name-and-version ...) */,t1);
t3=C_mutate((C_word*)lf[261]+1 /* (set! setup-api#extension-name ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4418,a[2]=((C_word)li81),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[262]+1 /* (set! setup-api#extension-version ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4428,a[2]=((C_word)li82),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[264]+1 /* (set! setup-api#read-info ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4472,a[2]=((C_word)li83),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[267]+1 /* (set! setup-api#create-temporary-directory ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4486,a[2]=((C_word)li85),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[275]+1 /* (set! setup-api#remove-directory ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4539,a[2]=((C_word)li88),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[284]+1 /* (set! setup-api#remove-extension ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4639,a[2]=((C_word)li89),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate(&lf[58] /* (set! setup-api#$system ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4670,a[2]=((C_word)li90),tmp=(C_word)a,a+=3,tmp));
t10=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_UNDEFINED);}

/* setup-api#$system in k4414 in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_fcall f_4670(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4670,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4674,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4687,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[13],"setup-api#*windows-shell*"))){
/* setup-api.scm: 750  string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[118]+1)))(5,*((C_word*)lf[118]+1),t4,lf[287],t2,lf[288]);}
else{
t5=t4;
f_4687(2,t5,t2);}}

/* k4685 in setup-api#$system in k4414 in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_4687(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 748  system */
((C_proc3)C_retrieve_symbol_proc(lf[207]))(3,*((C_word*)lf[207]+1),((C_word*)t0)[2],t1);}

/* k4672 in setup-api#$system in k4414 in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_4674(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_zerop(t1))){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
/* setup-api.scm: 753  error */
((C_proc5)C_retrieve_proc(*((C_word*)lf[108]+1)))(5,*((C_word*)lf[108]+1),((C_word*)t0)[3],lf[286],t1,((C_word*)t0)[2]);}}

/* setup-api#remove-extension in k4414 in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_4639(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4639,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4668,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 743  read-info */
((C_proc3)C_retrieve_symbol_proc(lf[264]))(3,*((C_word*)lf[264]+1),t3,t2);}

/* k4666 in setup-api#remove-extension in k4414 in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_4668(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4668,2,t0,t1);}
t2=(C_word)C_i_assq(lf[157],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4646,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t2)){
t4=(C_word)C_i_cdr(t2);
/* for-each */
t5=*((C_word*)lf[106]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,C_retrieve(lf[173]),t4);}
else{
t4=t3;
f_4646(2,t4,C_SCHEME_FALSE);}}

/* k4644 in k4666 in setup-api#remove-extension in k4414 in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_4646(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4646,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4653,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4657,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 745  repository-path */
((C_proc2)C_retrieve_symbol_proc(lf[161]))(2,*((C_word*)lf[161]+1),t3);}

/* k4655 in k4644 in k4666 in setup-api#remove-extension in k4414 in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_4657(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 745  make-pathname */
((C_proc5)C_retrieve_symbol_proc(lf[102]))(5,*((C_word*)lf[102]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2],lf[285]);}

/* k4651 in k4644 in k4666 in setup-api#remove-extension in k4414 in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_4653(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 745  remove-file* */
((C_proc3)C_retrieve_symbol_proc(lf[173]))(3,*((C_word*)lf[173]+1),((C_word*)t0)[2],t1);}

/* setup-api#remove-directory in k4414 in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_4539(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_4539r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4539r(t0,t1,t2,t3);}}

static void C_ccall f_4539r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4543,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_4543(2,t5,C_SCHEME_TRUE);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_4543(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[153]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k4541 in setup-api#remove-directory in k4414 in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_4543(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4543,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4618,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* setup-api.scm: 723  file-exists? */
((C_proc3)C_retrieve_symbol_proc(lf[126]))(3,*((C_word*)lf[126]+1),t2,((C_word*)t0)[2]);}

/* k4616 in k4541 in setup-api#remove-directory in k4414 in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_4618(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4618,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(C_retrieve2(lf[12],"setup-api#*sudo*"))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4565,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4569,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 728  shellpath */
((C_proc3)C_retrieve_symbol_proc(lf[19]))(3,*((C_word*)lf[19]+1),t3,((C_word*)t0)[3]);}
else{
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4574,a[2]=t3,a[3]=((C_word)li87),tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_4574(t5,((C_word*)t0)[4],((C_word*)t0)[3]);}}
else{
if(C_truep(((C_word*)t0)[2])){
/* setup-api.scm: 725  error */
((C_proc5)C_retrieve_proc(*((C_word*)lf[108]+1)))(5,*((C_word*)lf[108]+1),((C_word*)t0)[4],lf[282],lf[283],((C_word*)t0)[3]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}}

/* walk in k4616 in k4541 in setup-api#remove-directory in k4414 in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_fcall f_4574(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4574,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4578,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* setup-api.scm: 731  directory */
((C_proc4)C_retrieve_symbol_proc(lf[281]))(4,*((C_word*)lf[281]+1),t3,t2,C_SCHEME_TRUE);}

/* k4576 in walk in k4616 in k4541 in setup-api#remove-directory in k4414 in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_4578(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4578,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4581,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4586,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word)li86),tmp=(C_word)a,a+=5,tmp);
/* for-each */
t4=*((C_word*)lf[106]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,t1);}

/* a4585 in k4576 in walk in k4616 in k4541 in setup-api#remove-directory in k4414 in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_4586(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4586,3,t0,t1,t2);}
t3=(C_word)C_i_string_equal_p(lf[278],t2);
t4=(C_truep(t3)?t3:(C_word)C_i_string_equal_p(lf[279],t2));
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4599,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 735  make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[102]))(4,*((C_word*)lf[102]+1),t5,((C_word*)t0)[2],t2);}}

/* k4597 in a4585 in k4576 in walk in k4616 in k4541 in setup-api#remove-directory in k4414 in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_4599(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4599,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4605,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* setup-api.scm: 736  directory? */
((C_proc3)C_retrieve_symbol_proc(lf[55]))(3,*((C_word*)lf[55]+1),t2,t1);}

/* k4603 in k4597 in a4585 in k4576 in walk in k4616 in k4541 in setup-api#remove-directory in k4414 in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_4605(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* setup-api.scm: 737  walk */
t2=((C_word*)((C_word*)t0)[4])[1];
f_4574(t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* setup-api.scm: 738  delete-file */
((C_proc3)C_retrieve_symbol_proc(lf[280]))(3,*((C_word*)lf[280]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k4579 in k4576 in walk in k4616 in k4541 in setup-api#remove-directory in k4414 in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_4581(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 740  delete-directory */
((C_proc3)C_retrieve_symbol_proc(lf[277]))(3,*((C_word*)lf[277]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4567 in k4616 in k4541 in setup-api#remove-directory in k4414 in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_4569(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 728  sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[59]))(4,*((C_word*)lf[59]+1),((C_word*)t0)[2],lf[276],t1);}

/* k4563 in k4616 in k4541 in setup-api#remove-directory in k4414 in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_4565(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 728  $system */
f_4670(((C_word*)t0)[2],t1);}

/* setup-api#create-temporary-directory in k4414 in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_4486(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4486,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4490,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 715  getenv */
((C_proc3)C_retrieve_symbol_proc(lf[271]))(3,*((C_word*)lf[271]+1),t2,lf[274]);}

/* k4488 in setup-api#create-temporary-directory in k4414 in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_4490(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4490,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4493,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
t3=t2;
f_4493(t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4528,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 715  getenv */
((C_proc3)C_retrieve_symbol_proc(lf[271]))(3,*((C_word*)lf[271]+1),t3,lf[273]);}}

/* k4526 in k4488 in setup-api#create-temporary-directory in k4414 in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_4528(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4528,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
f_4493(t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4534,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 715  getenv */
((C_proc3)C_retrieve_symbol_proc(lf[271]))(3,*((C_word*)lf[271]+1),t2,lf[272]);}}

/* k4532 in k4526 in k4488 in setup-api#create-temporary-directory in k4414 in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_4534(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_4493(t2,(C_truep(t1)?t1:lf[270]));}

/* k4491 in k4488 in setup-api#create-temporary-directory in k4414 in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_fcall f_4493(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4493,NULL,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4498,a[2]=t1,a[3]=t3,a[4]=((C_word)li84),tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_4498(t5,((C_word*)t0)[2]);}

/* loop in k4491 in k4488 in setup-api#create-temporary-directory in k4414 in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_fcall f_4498(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4498,NULL,2,t0,t1);}
t2=(C_word)C_fudge(C_fix(16));
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4505,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4521,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4525,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 718  number->string */
C_number_to_string(4,0,t5,t2,C_fix(16));}

/* k4523 in loop in k4491 in k4488 in setup-api#create-temporary-directory in k4414 in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_4525(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 718  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[118]+1)))(4,*((C_word*)lf[118]+1),((C_word*)t0)[2],lf[269],t1);}

/* k4519 in loop in k4491 in k4488 in setup-api#create-temporary-directory in k4414 in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_4521(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 718  make-pathname */
((C_proc5)C_retrieve_symbol_proc(lf[102]))(5,*((C_word*)lf[102]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1,lf[268]);}

/* k4503 in loop in k4491 in k4488 in setup-api#create-temporary-directory in k4414 in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_4505(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4505,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4511,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* setup-api.scm: 719  file-exists? */
((C_proc3)C_retrieve_symbol_proc(lf[126]))(3,*((C_word*)lf[126]+1),t2,t1);}

/* k4509 in k4503 in loop in k4491 in k4488 in setup-api#create-temporary-directory in k4414 in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_4511(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4511,2,t0,t1);}
if(C_truep(t1)){
/* setup-api.scm: 719  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_4498(t2,((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4517,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 720  create-directory */
((C_proc3)C_retrieve_symbol_proc(lf[53]))(3,*((C_word*)lf[53]+1),t2,((C_word*)t0)[2]);}}

/* k4515 in k4509 in k4503 in loop in k4491 in k4488 in setup-api#create-temporary-directory in k4414 in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_4517(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* setup-api#read-info in k4414 in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_4472(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4472,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4480,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4484,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 711  repository-path */
((C_proc2)C_retrieve_symbol_proc(lf[161]))(2,*((C_word*)lf[161]+1),t4);}

/* k4482 in setup-api#read-info in k4414 in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_4484(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 711  make-pathname */
((C_proc5)C_retrieve_symbol_proc(lf[102]))(5,*((C_word*)lf[102]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2],lf[266]);}

/* k4478 in setup-api#read-info in k4414 in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_4480(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 710  with-input-from-file */
((C_proc4)C_retrieve_symbol_proc(lf[80]))(4,*((C_word*)lf[80]+1),((C_word*)t0)[2],t1,*((C_word*)lf[265]+1));}

/* setup-api#extension-version in k4414 in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_4428(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_4428r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4428r(t0,t1,t2);}}

static void C_ccall f_4428r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4432,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
t4=t3;
f_4432(2,t4,C_SCHEME_FALSE);}
else{
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t4))){
t5=t3;
f_4432(2,t5,(C_word)C_i_car(t2));}
else{
/* ##sys#error */
t5=*((C_word*)lf[153]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,lf[0],t2);}}}

/* k4430 in setup-api#extension-version in k4414 in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_4432(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4432,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4451,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 704  extension-name-and-version */
((C_proc2)C_retrieve_symbol_proc(lf[260]))(2,*((C_word*)lf[260]+1),t2);}

/* k4449 in k4430 in setup-api#extension-version in k4414 in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_4451(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4451,2,t0,t1);}
t2=(C_word)C_i_cadr(t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4441,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* setup-api.scm: 705  string-null? */
((C_proc3)C_retrieve_symbol_proc(lf[263]))(3,*((C_word*)lf[263]+1),t3,t2);}

/* k4439 in k4449 in k4430 in setup-api#extension-version in k4414 in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_4441(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
if(C_truep(((C_word*)t0)[4])){
/* setup-api.scm: 706  ->string */
((C_proc3)C_retrieve_symbol_proc(lf[104]))(3,*((C_word*)lf[104]+1),((C_word*)t0)[3],((C_word*)t0)[4]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* setup-api#extension-name in k4414 in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_4418(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4418,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4426,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 701  extension-name-and-version */
((C_proc2)C_retrieve_symbol_proc(lf[260]))(2,*((C_word*)lf[260]+1),t2);}

/* k4424 in setup-api#extension-name in k4414 in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_4426(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_car(t1));}

/* setup-api#version>=? in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_4239(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4239,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4242,a[2]=((C_word)li78),tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4266,a[2]=t3,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* setup-api.scm: 671  version->list */
f_4242(t5,t2);}

/* k4264 in setup-api#version>=? in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_4266(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4266,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4270,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 672  version->list */
f_4242(t2,((C_word*)t0)[2]);}

/* k4268 in k4264 in setup-api#version>=? in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_4270(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4270,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4272,a[2]=t3,a[3]=((C_word)li79),tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_4272(t5,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* loop in k4268 in k4264 in setup-api#version>=? in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_fcall f_4272(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4272,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_nullp(t3));}
else{
t4=(C_word)C_i_nullp(t3);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_numberp(t5))){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4300,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_i_car(t3);
if(C_truep((C_word)C_i_numberp(t7))){
t8=(C_word)C_i_car(t2);
t9=(C_word)C_i_car(t3);
t10=t6;
f_4300(2,t10,(C_word)C_i_greater_or_equalp(t8,t9));}
else{
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4332,a[2]=t6,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t9=(C_word)C_i_car(t2);
/* setup-api.scm: 678  number->string */
C_number_to_string(3,0,t8,t9);}}
else{
t6=(C_word)C_i_car(t3);
if(C_truep((C_word)C_i_numberp(t6))){
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4356,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t8=(C_word)C_i_car(t2);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4375,a[2]=t8,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
t10=(C_word)C_i_car(t3);
/* setup-api.scm: 681  number->string */
C_number_to_string(3,0,t9,t10);}
else{
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4385,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t8=(C_word)C_i_car(t2);
t9=(C_word)C_i_car(t3);
/* setup-api.scm: 683  string>=? */
((C_proc4)C_retrieve_proc(*((C_word*)lf[259]+1)))(4,*((C_word*)lf[259]+1),t7,t8,t9);}}}}}

/* k4383 in loop in k4268 in k4264 in setup-api#version>=? in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_4385(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* setup-api.scm: 683  loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_4272(t4,((C_word*)t0)[2],t2,t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k4373 in loop in k4268 in k4264 in setup-api#version>=? in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_4375(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 681  string>=? */
((C_proc4)C_retrieve_proc(*((C_word*)lf[259]+1)))(4,*((C_word*)lf[259]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4354 in loop in k4268 in k4264 in setup-api#version>=? in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_4356(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* setup-api.scm: 682  loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_4272(t4,((C_word*)t0)[2],t2,t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k4330 in loop in k4268 in k4264 in setup-api#version>=? in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_4332(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(((C_word*)t0)[3]);
/* setup-api.scm: 678  string>=? */
((C_proc4)C_retrieve_proc(*((C_word*)lf[259]+1)))(4,*((C_word*)lf[259]+1),((C_word*)t0)[2],t1,t2);}

/* k4298 in loop in k4268 in k4264 in setup-api#version>=? in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_4300(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* setup-api.scm: 679  loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_4272(t4,((C_word*)t0)[2],t2,t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* version->list in setup-api#version>=? in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_fcall f_4242(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4242,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4248,a[2]=((C_word)li77),tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4259,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 670  string-split-fields */
((C_proc5)C_retrieve_symbol_proc(lf[256]))(5,*((C_word*)lf[256]+1),t4,lf[257],t2,lf[258]);}

/* k4257 in version->list in setup-api#version>=? in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_4259(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[103]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a4247 in version->list in setup-api#version>=? in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_4248(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4248,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4252,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 669  string->number */
C_string_to_number(3,0,t3,t2);}

/* k4250 in a4247 in version->list in setup-api#version>=? in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_4252(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?t1:((C_word*)t0)[2]));}

/* setup-api#find-header in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_4229(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4229,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4237,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 664  sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[59]))(4,*((C_word*)lf[59]+1),t3,lf[254],t2);}

/* k4235 in setup-api#find-header in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_4237(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 663  test-compile */
((C_proc5)C_retrieve_symbol_proc(lf[249]))(5,*((C_word*)lf[249]+1),((C_word*)t0)[2],t1,lf[227],C_SCHEME_TRUE);}

/* setup-api#find-library in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_4215(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4215,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4223,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 659  sprintf */
((C_proc5)C_retrieve_symbol_proc(lf[59]))(5,*((C_word*)lf[59]+1),t4,lf[252],t3,t3);}

/* k4221 in setup-api#find-library in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_4223(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4223,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4227,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 660  conc */
((C_proc4)C_retrieve_symbol_proc(lf[213]))(4,*((C_word*)lf[213]+1),t2,lf[251],((C_word*)t0)[2]);}

/* k4225 in k4221 in setup-api#find-library in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_4227(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 658  test-compile */
((C_proc5)C_retrieve_symbol_proc(lf[249]))(5,*((C_word*)lf[249]+1),((C_word*)t0)[3],((C_word*)t0)[2],lf[230],t1);}

/* setup-api#required-extension-version in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_4117(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr2r,(void*)f_4117r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4117r(t0,t1,t2);}}

static void C_ccall f_4117r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4123,a[2]=t4,a[3]=((C_word)li73),tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_4123(t6,t1,t2);}

/* loop in setup-api#required-extension-version in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_fcall f_4123(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4123,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4136,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_listp(t2))){
t4=(C_word)C_i_length(t2);
t5=t3;
f_4136(t5,(C_word)C_i_greater_or_equalp(t4,C_fix(2)));}
else{
t4=t3;
f_4136(t4,C_SCHEME_FALSE);}}}

/* k4134 in loop in setup-api#required-extension-version in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_fcall f_4136(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4136,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
t4=(C_word)C_i_cddr(((C_word*)t0)[4]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4148,a[2]=t3,a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=t2,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* setup-api.scm: 640  extension-information */
((C_proc3)C_retrieve_symbol_proc(lf[246]))(3,*((C_word*)lf[246]+1),t5,t2);}
else{
/* setup-api.scm: 653  error */
((C_proc5)C_retrieve_proc(*((C_word*)lf[108]+1)))(5,*((C_word*)lf[108]+1),((C_word*)t0)[3],lf[247],lf[248],((C_word*)t0)[4]);}}

/* k4146 in k4134 in loop in setup-api#required-extension-version in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_4148(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4148,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4151,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* setup-api.scm: 641  ->string */
((C_proc3)C_retrieve_symbol_proc(lf[104]))(3,*((C_word*)lf[104]+1),t2,((C_word*)t0)[2]);}

/* k4149 in k4146 in k4134 in loop in setup-api#required-extension-version in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_4151(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4151,2,t0,t1);}
if(C_truep(((C_word*)t0)[6])){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4157,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_assq(lf[244],((C_word*)t0)[6]))){
t3=(C_word)C_i_assq(lf[244],((C_word*)t0)[6]);
t4=t2;
f_4157(t4,(C_word)C_i_cadr(t3));}
else{
t3=t2;
f_4157(t3,C_SCHEME_FALSE);}}
else{
/* setup-api.scm: 651  upgrade-message */
f_4107(((C_word*)t0)[5],((C_word*)t0)[4],lf[245]);}}

/* k4155 in k4149 in k4146 in k4134 in loop in setup-api#required-extension-version in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_fcall f_4157(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4157,NULL,2,t0,t1);}
t2=t1;
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4172,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4186,a[2]=((C_word*)t0)[4],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 645  ->string */
((C_proc3)C_retrieve_symbol_proc(lf[104]))(3,*((C_word*)lf[104]+1),t4,t1);}
else{
/* setup-api.scm: 644  upgrade-message */
f_4107(((C_word*)t0)[6],((C_word*)t0)[5],lf[243]);}}

/* k4184 in k4155 in k4149 in k4146 in k4134 in loop in setup-api#required-extension-version in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_4186(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 645  string-ci<? */
((C_proc4)C_retrieve_proc(*((C_word*)lf[237]+1)))(4,*((C_word*)lf[237]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4170 in k4155 in k4149 in k4146 in k4134 in loop in setup-api#required-extension-version in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_4172(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4172,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4179,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 648  sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[59]))(4,*((C_word*)lf[59]+1),t2,lf[242],((C_word*)t0)[4]);}
else{
/* setup-api.scm: 650  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_4123(t2,((C_word*)t0)[6],((C_word*)t0)[2]);}}

/* k4177 in k4170 in k4155 in k4149 in k4146 in k4134 in loop in setup-api#required-extension-version in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_4179(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 646  upgrade-message */
f_4107(((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* setup-api#upgrade-message in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_fcall f_4107(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4107,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4115,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 629  sprintf */
((C_proc6)C_retrieve_symbol_proc(lf[59]))(6,*((C_word*)lf[59]+1),t4,lf[240],t2,t3,t2);}

/* k4113 in setup-api#upgrade-message in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_4115(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 628  error */
((C_proc3)C_retrieve_proc(*((C_word*)lf[108]+1)))(3,*((C_word*)lf[108]+1),((C_word*)t0)[2],t1);}

/* setup-api#required-chicken-version in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_4083(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4083,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4090,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4101,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 624  chicken-version */
((C_proc2)C_retrieve_symbol_proc(lf[238]))(2,*((C_word*)lf[238]+1),t4);}

/* k4099 in setup-api#required-chicken-version in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_4101(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4101,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4105,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 624  ->string */
((C_proc3)C_retrieve_symbol_proc(lf[104]))(3,*((C_word*)lf[104]+1),t2,((C_word*)t0)[2]);}

/* k4103 in k4099 in setup-api#required-chicken-version in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_4105(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 624  string-ci<? */
((C_proc4)C_retrieve_proc(*((C_word*)lf[237]+1)))(4,*((C_word*)lf[237]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4088 in setup-api#required-chicken-version in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_4090(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4090,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4097,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 625  sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[59]))(4,*((C_word*)lf[59]+1),t2,lf[236],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k4095 in k4088 in setup-api#required-chicken-version in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_4097(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 625  error */
((C_proc3)C_retrieve_proc(*((C_word*)lf[108]+1)))(3,*((C_word*)lf[108]+1),((C_word*)t0)[2],t1);}

/* setup-api#try-compile in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_3971(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_3971r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3971r(t0,t1,t2,t3);}}

static void C_ccall f_3971r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3975,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* ##sys#get-keyword */
((C_proc4)C_retrieve_symbol_proc(lf[74]))(4,*((C_word*)lf[74]+1),t4,lf[234],t3);}

/* k3973 in setup-api#try-compile in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_3975(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3975,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3978,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4077,a[2]=t1,a[3]=((C_word)li69),tmp=(C_word)a,a+=4,tmp);
/* ##sys#get-keyword */
((C_proc5)C_retrieve_symbol_proc(lf[74]))(5,*((C_word*)lf[74]+1),t2,lf[233],((C_word*)t0)[2],t3);}

/* a4076 in k3973 in setup-api#try-compile in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_4077(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4077,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(((C_word*)t0)[2])?C_retrieve2(lf[8],"setup-api#*cxx*"):C_retrieve2(lf[7],"setup-api#*cc*")));}

/* k3976 in k3973 in setup-api#try-compile in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_3978(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3978,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3981,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4074,a[2]=((C_word)li68),tmp=(C_word)a,a+=3,tmp);
/* ##sys#get-keyword */
((C_proc5)C_retrieve_symbol_proc(lf[74]))(5,*((C_word*)lf[74]+1),t2,lf[232],((C_word*)t0)[2],t3);}

/* a4073 in k3976 in k3973 in setup-api#try-compile in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_4074(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4074,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[231]);}

/* k3979 in k3976 in k3973 in setup-api#try-compile in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_3981(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3981,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3984,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4071,a[2]=((C_word)li67),tmp=(C_word)a,a+=3,tmp);
/* ##sys#get-keyword */
((C_proc5)C_retrieve_symbol_proc(lf[74]))(5,*((C_word*)lf[74]+1),t2,lf[230],((C_word*)t0)[2],t3);}

/* a4070 in k3979 in k3976 in k3973 in setup-api#try-compile in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_4071(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4071,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[229]);}

/* k3982 in k3979 in k3976 in k3973 in setup-api#try-compile in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_3984(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3984,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3987,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4065,a[2]=((C_word)li66),tmp=(C_word)a,a+=3,tmp);
/* ##sys#get-keyword */
((C_proc5)C_retrieve_symbol_proc(lf[74]))(5,*((C_word*)lf[74]+1),t2,lf[228],((C_word*)t0)[2],t3);}

/* a4064 in k3982 in k3979 in k3976 in k3973 in setup-api#try-compile in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_4065(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4065,2,t0,t1);}
/* setup-api.scm: 601  setup-verbose-flag */
((C_proc2)C_retrieve_symbol_proc(lf[25]))(2,*((C_word*)lf[25]+1),t1);}

/* k3985 in k3982 in k3979 in k3976 in k3973 in setup-api#try-compile in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_3987(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3987,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3990,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4062,a[2]=((C_word)li65),tmp=(C_word)a,a+=3,tmp);
/* ##sys#get-keyword */
((C_proc5)C_retrieve_symbol_proc(lf[74]))(5,*((C_word*)lf[74]+1),t2,lf[227],((C_word*)t0)[2],t3);}

/* a4061 in k3985 in k3982 in k3979 in k3976 in k3973 in setup-api#try-compile in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_4062(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4062,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in setup-api#try-compile in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_3990(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3990,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3993,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* setup-api.scm: 602  create-temporary-file */
((C_proc3)C_retrieve_symbol_proc(lf[83]))(3,*((C_word*)lf[83]+1),t2,lf[226]);}

/* k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in setup-api#try-compile in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_3993(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3993,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3996,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* setup-api.scm: 603  pathname-replace-extension */
((C_proc4)C_retrieve_symbol_proc(lf[87]))(4,*((C_word*)lf[87]+1),t2,t1,lf[225]);}

/* k3994 in k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in setup-api#try-compile in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_3996(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3996,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3999,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4056,a[2]=((C_word*)t0)[2],a[3]=((C_word)li64),tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 605  with-output-to-file */
((C_proc4)C_retrieve_symbol_proc(lf[81]))(4,*((C_word*)lf[81]+1),t2,((C_word*)t0)[8],t3);}

/* a4055 in k3994 in k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in setup-api#try-compile in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_4056(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4056,2,t0,t1);}
/* display */
((C_proc3)C_retrieve_proc(*((C_word*)lf[224]+1)))(3,*((C_word*)lf[224]+1),t1,((C_word*)t0)[2]);}

/* k3997 in k3994 in k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in setup-api#try-compile in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_3999(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3999,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4002,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4033,a[2]=((C_word*)t0)[6],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_truep(((C_word*)t0)[5])?lf[209]:lf[210]);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4047,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=((C_word*)t0)[4],a[6]=t3,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[5])){
t6=t5;
f_4047(2,t6,lf[220]);}
else{
/* setup-api.scm: 614  conc */
((C_proc8)C_retrieve_symbol_proc(lf[213]))(8,*((C_word*)lf[213]+1),t5,lf[221],C_retrieve2(lf[11],"setup-api#*target-lib-home*"),lf[222],((C_word*)t0)[2],lf[223],C_retrieve2(lf[10],"setup-api#*target-libs*"));}}

/* k4045 in k3997 in k3994 in k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in setup-api#try-compile in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_4047(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(((C_word*)t0)[7])?lf[211]:lf[212]);
/* setup-api.scm: 607  conc */
((C_proc15)C_retrieve_symbol_proc(lf[213]))(15,*((C_word*)lf[213]+1),((C_word*)t0)[6],((C_word*)t0)[5],lf[214],((C_word*)t0)[4],lf[215],((C_word*)t0)[3],lf[216],C_retrieve2(lf[9],"setup-api#*target-cflags*"),lf[217],((C_word*)t0)[2],lf[218],t1,lf[219],t2);}

/* k4031 in k3997 in k3994 in k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in setup-api#try-compile in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_4033(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4033,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4036,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[2])){
/* setup-api.scm: 617  print */
((C_proc4)C_retrieve_proc(*((C_word*)lf[46]+1)))(4,*((C_word*)lf[46]+1),t2,t1,lf[208]);}
else{
t3=t2;
f_4036(2,t3,C_SCHEME_UNDEFINED);}}

/* k4034 in k4031 in k3997 in k3994 in k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in setup-api#try-compile in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_4036(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 606  system */
((C_proc3)C_retrieve_symbol_proc(lf[207]))(3,*((C_word*)lf[207]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4000 in k3997 in k3994 in k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in setup-api#try-compile in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_4002(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4002,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4005,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(C_word)C_i_zerop(t1);
t4=(C_truep(t3)?lf[205]:lf[206]);
/* setup-api.scm: 619  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[46]+1)))(3,*((C_word*)lf[46]+1),t2,t4);}
else{
t3=t2;
f_4005(2,t3,C_SCHEME_UNDEFINED);}}

/* k4003 in k4000 in k3997 in k3994 in k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in setup-api#try-compile in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_4005(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4005,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4008,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4015,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4019,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 620  shellpath */
((C_proc3)C_retrieve_symbol_proc(lf[19]))(3,*((C_word*)lf[19]+1),t4,((C_word*)t0)[2]);}

/* k4017 in k4003 in k4000 in k3997 in k3994 in k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in setup-api#try-compile in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_4019(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 620  sprintf */
((C_proc5)C_retrieve_symbol_proc(lf[59]))(5,*((C_word*)lf[59]+1),((C_word*)t0)[2],lf[204],C_retrieve2(lf[30],"setup-api#*remove-command*"),t1);}

/* k4013 in k4003 in k4000 in k3997 in k3994 in k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in setup-api#try-compile in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_4015(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 620  $system */
f_4670(((C_word*)t0)[2],t1);}

/* k4006 in k4003 in k4000 in k3997 in k3994 in k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in setup-api#try-compile in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_4008(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_zerop(((C_word*)t0)[2]));}

/* setup-api#ensure-directory in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_fcall f_3918(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3918,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3922,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 591  pathname-directory */
((C_proc3)C_retrieve_symbol_proc(lf[54]))(3,*((C_word*)lf[54]+1),t3,t2);}

/* k3920 in setup-api#ensure-directory in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_3922(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3922,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3931,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 592  file-exists? */
((C_proc3)C_retrieve_symbol_proc(lf[126]))(3,*((C_word*)lf[126]+1),t2,t1);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k3929 in k3920 in setup-api#ensure-directory in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_3931(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3931,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3937,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 593  directory? */
((C_proc3)C_retrieve_symbol_proc(lf[55]))(3,*((C_word*)lf[55]+1),t2,((C_word*)t0)[2]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3943,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 596  create-directory */
((C_proc3)C_retrieve_symbol_proc(lf[53]))(3,*((C_word*)lf[53]+1),t2,((C_word*)t0)[2]);}}

/* k3941 in k3929 in k3920 in setup-api#ensure-directory in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_3943(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3943,2,t0,t1);}
if(C_truep(C_retrieve2(lf[13],"setup-api#*windows-shell*"))){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3969,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 598  shellpath */
((C_proc3)C_retrieve_symbol_proc(lf[19]))(3,*((C_word*)lf[19]+1),t2,((C_word*)t0)[2]);}}

/* k3967 in k3941 in k3929 in k3920 in setup-api#ensure-directory in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_3969(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3969,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[202],t2);
t4=(C_word)C_a_i_cons(&a,2,C_retrieve2(lf[32],"setup-api#*chmod-command*"),t3);
t5=(C_word)C_a_i_list(&a,1,t4);
/* setup-api#execute */
((C_proc3)C_retrieve_symbol_proc(lf[92]))(3,*((C_word*)lf[92]+1),((C_word*)t0)[2],t5);}

/* k3935 in k3929 in k3920 in setup-api#ensure-directory in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_3937(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
/* setup-api.scm: 594  error */
((C_proc3)C_retrieve_proc(*((C_word*)lf[108]+1)))(3,*((C_word*)lf[108]+1),((C_word*)t0)[2],lf[201]);}}

/* setup-api#repo-path in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_fcall f_3867(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3867,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3871,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
t4=t3;
f_3871(2,t4,C_SCHEME_FALSE);}
else{
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t4))){
t5=t3;
f_3871(2,t5,(C_word)C_i_car(t2));}
else{
/* ##sys#error */
t5=*((C_word*)lf[153]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,lf[0],t2);}}}

/* k3869 in setup-api#repo-path in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_3871(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3871,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3874,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3880,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
/* setup-api.scm: 584  installation-prefix */
((C_proc2)C_retrieve_symbol_proc(lf[155]))(2,*((C_word*)lf[155]+1),t3);}
else{
t4=t3;
f_3880(2,t4,C_SCHEME_FALSE);}}

/* k3878 in k3869 in setup-api#repo-path in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_3880(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3880,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3887,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 585  installation-prefix */
((C_proc2)C_retrieve_symbol_proc(lf[155]))(2,*((C_word*)lf[155]+1),t2);}
else{
/* setup-api.scm: 586  repository-path */
((C_proc2)C_retrieve_symbol_proc(lf[161]))(2,*((C_word*)lf[161]+1),((C_word*)t0)[2]);}}

/* k3885 in k3878 in k3869 in setup-api#repo-path in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_3887(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3887,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3891,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 585  repository-path */
((C_proc2)C_retrieve_symbol_proc(lf[161]))(2,*((C_word*)lf[161]+1),t2);}

/* k3889 in k3885 in k3878 in k3869 in setup-api#repo-path in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_3891(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 585  make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[102]))(4,*((C_word*)lf[102]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3872 in k3869 in setup-api#repo-path in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_3874(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3874,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3877,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 587  ensure-directory */
f_3918(t2,t1);}

/* k3875 in k3872 in k3869 in setup-api#repo-path in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_3877(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* setup-api#install-script in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_3731(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_3731r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3731r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3731r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3735,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_3735(2,t6,C_SCHEME_END_OF_LIST);}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_3735(2,t7,(C_word)C_i_car(t4));}
else{
/* ##sys#error */
t7=*((C_word*)lf[153]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* k3733 in setup-api#install-script in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_3735(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3735,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3741,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* setup-api.scm: 564  setup-install-flag */
((C_proc2)C_retrieve_symbol_proc(lf[26]))(2,*((C_word*)lf[26]+1),t2);}

/* k3739 in k3733 in setup-api#install-script in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_3741(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3741,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3744,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_listp(((C_word*)t0)[2]);
t4=(C_truep(t3)?((C_word*)t0)[2]:(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]));
/* setup-api.scm: 565  check-filelist */
f_3199(t2,t4);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k3742 in k3739 in k3733 in setup-api#install-script in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_3744(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3744,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3747,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* setup-api.scm: 567  installation-prefix */
((C_proc2)C_retrieve_symbol_proc(lf[155]))(2,*((C_word*)lf[155]+1),t2);}

/* k3745 in k3742 in k3739 in k3733 in setup-api#install-script in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_3747(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3747,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3750,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3833,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 566  program-path */
((C_proc2)C_retrieve_symbol_proc(lf[27]))(2,*((C_word*)lf[27]+1),t3);}
else{
/* setup-api.scm: 566  program-path */
((C_proc2)C_retrieve_symbol_proc(lf[27]))(2,*((C_word*)lf[27]+1),t2);}}

/* k3831 in k3745 in k3742 in k3739 in k3733 in setup-api#install-script in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_3833(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 566  make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[102]))(4,*((C_word*)lf[102]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3748 in k3745 in k3742 in k3739 in k3733 in setup-api#install-script in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_3750(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3750,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3753,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3784,a[2]=t1,a[3]=((C_word)li60),tmp=(C_word)a,a+=4,tmp);
/* map */
t4=*((C_word*)lf[103]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a3783 in k3748 in k3745 in k3742 in k3739 in k3733 in setup-api#install-script in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_3784(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3784,3,t0,t1,t2);}
t3=(C_word)C_i_pairp(t2);
t4=(C_truep(t3)?(C_word)C_i_car(t2):t2);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3791,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 570  make-dest-pathname */
f_3174(t5,((C_word*)t0)[2],t2);}

/* k3789 in a3783 in k3748 in k3745 in k3742 in k3739 in k3733 in setup-api#install-script in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_3791(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3791,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3794,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 571  copy-file */
((C_proc4)C_retrieve_symbol_proc(lf[165]))(4,*((C_word*)lf[165]+1),t2,((C_word*)t0)[2],t1);}

/* k3792 in k3789 in a3783 in k3748 in k3745 in k3742 in k3739 in k3733 in setup-api#install-script in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_3794(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3794,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3797,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[13],"setup-api#*windows-shell*"))){
t3=t2;
f_3797(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3820,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 573  shellpath */
((C_proc3)C_retrieve_symbol_proc(lf[19]))(3,*((C_word*)lf[19]+1),t3,((C_word*)t0)[2]);}}

/* k3818 in k3792 in k3789 in a3783 in k3748 in k3745 in k3742 in k3739 in k3733 in setup-api#install-script in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_3820(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3820,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[158],t2);
t4=(C_word)C_a_i_cons(&a,2,C_retrieve2(lf[32],"setup-api#*chmod-command*"),t3);
t5=(C_word)C_a_i_list(&a,1,t4);
/* setup-api#execute */
((C_proc3)C_retrieve_symbol_proc(lf[92]))(3,*((C_word*)lf[92]+1),((C_word*)t0)[2],t5);}

/* k3795 in k3792 in k3789 in a3783 in k3748 in k3745 in k3742 in k3739 in k3733 in setup-api#install-script in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_3797(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k3751 in k3748 in k3745 in k3742 in k3739 in k3733 in setup-api#install-script in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_3753(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3753,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3756,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_retrieve2(lf[13],"setup-api#*windows-shell*"))){
t3=t2;
f_3756(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3782,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 577  string-intersperse */
((C_proc4)C_retrieve_symbol_proc(lf[93]))(4,*((C_word*)lf[93]+1),t3,t1,lf[200]);}}

/* k3780 in k3751 in k3748 in k3745 in k3742 in k3739 in k3733 in setup-api#install-script in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_3782(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3782,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[182],t2);
t4=(C_word)C_a_i_cons(&a,2,C_retrieve2(lf[32],"setup-api#*chmod-command*"),t3);
t5=(C_word)C_a_i_list(&a,1,t4);
/* setup-api#execute */
((C_proc3)C_retrieve_symbol_proc(lf[92]))(3,*((C_word*)lf[92]+1),((C_word*)t0)[2],t5);}

/* k3754 in k3751 in k3748 in k3745 in k3742 in k3739 in k3733 in setup-api#install-script in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_3756(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 578  write-info */
f_2833(((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* setup-api#install-program in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_3574(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_3574r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3574r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3574r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3578,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_3578(2,t6,C_SCHEME_END_OF_LIST);}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_3578(2,t7,(C_word)C_i_car(t4));}
else{
/* ##sys#error */
t7=*((C_word*)lf[153]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* k3576 in setup-api#install-program in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_3578(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3578,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3580,a[2]=((C_word)li56),tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3594,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* setup-api.scm: 542  setup-install-flag */
((C_proc2)C_retrieve_symbol_proc(lf[26]))(2,*((C_word*)lf[26]+1),t3);}

/* k3592 in k3576 in setup-api#install-program in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_3594(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3594,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3597,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_listp(((C_word*)t0)[2]);
t4=(C_truep(t3)?((C_word*)t0)[2]:(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]));
/* setup-api.scm: 543  check-filelist */
f_3199(t2,t4);}
else{
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k3595 in k3592 in k3576 in setup-api#install-program in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_3597(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3597,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3600,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* setup-api.scm: 545  installation-prefix */
((C_proc2)C_retrieve_symbol_proc(lf[155]))(2,*((C_word*)lf[155]+1),t2);}

/* k3598 in k3595 in k3592 in k3576 in setup-api#install-program in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_3600(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3600,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3603,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3697,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 544  program-path */
((C_proc2)C_retrieve_symbol_proc(lf[27]))(2,*((C_word*)lf[27]+1),t3);}
else{
/* setup-api.scm: 544  program-path */
((C_proc2)C_retrieve_symbol_proc(lf[27]))(2,*((C_word*)lf[27]+1),t2);}}

/* k3695 in k3598 in k3595 in k3592 in k3576 in setup-api#install-program in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_3697(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 544  make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[102]))(4,*((C_word*)lf[102]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3601 in k3598 in k3595 in k3592 in k3576 in setup-api#install-program in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_3603(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3603,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3606,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_retrieve2(lf[14],"setup-api#*windows*"))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3661,a[2]=((C_word*)t0)[3],a[3]=((C_word)li58),tmp=(C_word)a,a+=4,tmp);
/* map */
t4=*((C_word*)lf[103]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}
else{
t3=t2;
f_3606(2,t3,((C_word*)t0)[2]);}}

/* a3660 in k3601 in k3598 in k3595 in k3592 in k3576 in setup-api#install-program in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_3661(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3661,3,t0,t1,t2);}
if(C_truep((C_word)C_i_listp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3675,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_car(t2);
/* setup-api.scm: 549  exify */
f_3580(t3,t4);}
else{
/* setup-api.scm: 550  exify */
f_3580(t1,t2);}}

/* k3673 in a3660 in k3601 in k3598 in k3595 in k3592 in k3576 in setup-api#install-program in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_3675(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3675,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3679,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[3]);
/* setup-api.scm: 549  exify */
f_3580(t2,t3);}

/* k3677 in k3673 in a3660 in k3601 in k3598 in k3595 in k3592 in k3576 in setup-api#install-program in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_3679(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3679,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[2],t1));}

/* k3604 in k3601 in k3598 in k3595 in k3592 in k3576 in setup-api#install-program in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_3606(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3606,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3609,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3614,a[2]=((C_word*)t0)[2],a[3]=((C_word)li57),tmp=(C_word)a,a+=4,tmp);
/* map */
t4=*((C_word*)lf[103]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,t1);}

/* a3613 in k3604 in k3601 in k3598 in k3595 in k3592 in k3576 in setup-api#install-program in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_3614(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3614,3,t0,t1,t2);}
t3=(C_word)C_i_pairp(t2);
t4=(C_truep(t3)?(C_word)C_i_car(t2):t2);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3621,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 555  make-dest-pathname */
f_3174(t5,((C_word*)t0)[2],t2);}

/* k3619 in a3613 in k3604 in k3601 in k3598 in k3595 in k3592 in k3576 in setup-api#install-program in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_3621(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3621,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3624,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 556  copy-file */
((C_proc4)C_retrieve_symbol_proc(lf[165]))(4,*((C_word*)lf[165]+1),t2,((C_word*)t0)[2],t1);}

/* k3622 in k3619 in a3613 in k3604 in k3601 in k3598 in k3595 in k3592 in k3576 in setup-api#install-program in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_3624(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3624,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3627,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[13],"setup-api#*windows-shell*"))){
t3=t2;
f_3627(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3650,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 558  shellpath */
((C_proc3)C_retrieve_symbol_proc(lf[19]))(3,*((C_word*)lf[19]+1),t3,((C_word*)t0)[2]);}}

/* k3648 in k3622 in k3619 in a3613 in k3604 in k3601 in k3598 in k3595 in k3592 in k3576 in setup-api#install-program in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_3650(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3650,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[158],t2);
t4=(C_word)C_a_i_cons(&a,2,C_retrieve2(lf[32],"setup-api#*chmod-command*"),t3);
t5=(C_word)C_a_i_list(&a,1,t4);
/* setup-api#execute */
((C_proc3)C_retrieve_symbol_proc(lf[92]))(3,*((C_word*)lf[92]+1),((C_word*)t0)[2],t5);}

/* k3625 in k3622 in k3619 in a3613 in k3604 in k3601 in k3598 in k3595 in k3592 in k3576 in setup-api#install-program in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_3627(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k3607 in k3604 in k3601 in k3598 in k3595 in k3592 in k3576 in setup-api#install-program in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_3609(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 561  write-info */
f_2833(((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* exify in k3576 in setup-api#install-program in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_fcall f_3580(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3580,NULL,2,t1,t2);}
t3=(C_truep(C_retrieve2(lf[13],"setup-api#*windows-shell*"))?lf[194]:C_SCHEME_FALSE);
t4=(C_word)C_a_i_list(&a,1,t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3253,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_3253(2,t6,C_SCHEME_FALSE);}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_3253(2,t7,(C_word)C_i_car(t4));}
else{
/* ##sys#error */
t7=*((C_word*)lf[153]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* k3251 in exify in k3576 in setup-api#install-program in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_3253(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3253,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3260,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* setup-api.scm: 488  pathname-extension */
((C_proc3)C_retrieve_symbol_proc(lf[91]))(3,*((C_word*)lf[91]+1),t2,((C_word*)t0)[2]);}

/* k3258 in k3251 in exify in k3576 in setup-api#install-program in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_3260(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3260,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3263,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=t1;
if(C_truep(t3)){
if(C_truep((C_word)C_i_equalp(lf[195],t1))){
t4=t2;
f_3263(t4,C_retrieve(lf[88]));}
else{
t4=(C_word)C_i_equalp(lf[196],t1);
t5=t2;
f_3263(t5,(C_truep(t4)?(C_truep(C_retrieve2(lf[13],"setup-api#*windows-shell*"))?lf[197]:lf[198]):t1));}}
else{
t4=t2;
f_3263(t4,((C_word*)t0)[2]);}}

/* k3261 in k3258 in k3251 in exify in k3576 in setup-api#install-program in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_fcall f_3263(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 487  pathname-replace-extension */
((C_proc4)C_retrieve_symbol_proc(lf[87]))(4,*((C_word*)lf[87]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* setup-api#install-extension in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_3302(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_3302r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3302r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3302r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3306,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_3306(2,t6,C_SCHEME_END_OF_LIST);}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_3306(2,t7,(C_word)C_i_car(t4));}
else{
/* ##sys#error */
t7=*((C_word*)lf[153]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* k3304 in setup-api#install-extension in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_3306(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3306,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3312,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* setup-api.scm: 498  setup-install-flag */
((C_proc2)C_retrieve_symbol_proc(lf[26]))(2,*((C_word*)lf[26]+1),t2);}

/* k3310 in k3304 in setup-api#install-extension in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_3312(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3312,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3315,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_listp(((C_word*)t0)[2]);
t4=(C_truep(t3)?((C_word*)t0)[2]:(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]));
/* setup-api.scm: 499  check-filelist */
f_3199(t2,t4);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k3313 in k3310 in k3304 in setup-api#install-extension in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_3315(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3315,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3318,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* setup-api.scm: 500  repo-path */
f_3867(t2,C_SCHEME_END_OF_LIST);}

/* k3316 in k3313 in k3310 in k3304 in setup-api#install-extension in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_3318(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3318,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3321,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* setup-api.scm: 501  repo-path */
f_3867(t2,(C_word)C_a_i_list(&a,1,C_SCHEME_TRUE));}

/* k3319 in k3316 in k3313 in k3310 in k3304 in setup-api#install-extension in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_3321(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3321,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3324,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3408,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],a[5]=((C_word)li54),tmp=(C_word)a,a+=6,tmp);
/* map */
t4=*((C_word*)lf[103]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a3407 in k3319 in k3316 in k3313 in k3310 in k3304 in setup-api#install-extension in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_3408(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3408,3,t0,t1,t2);}
t3=(C_word)C_i_pairp(t2);
t4=(C_truep(t3)?(C_word)C_i_car(t2):t2);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3415,a[2]=t4,a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* setup-api.scm: 504  make-dest-pathname */
f_3174(t5,((C_word*)t0)[2],t2);}

/* k3413 in a3407 in k3319 in k3316 in k3313 in k3310 in k3304 in setup-api#install-extension in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_3415(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3415,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3418,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3508,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[14],"setup-api#*windows*"))){
t4=t3;
f_3508(t4,C_SCHEME_FALSE);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3537,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 506  pathname-extension */
((C_proc3)C_retrieve_symbol_proc(lf[91]))(3,*((C_word*)lf[91]+1),t4,t1);}}

/* k3535 in k3413 in a3407 in k3319 in k3316 in k3313 in k3310 in k3304 in setup-api#install-extension in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_3537(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_3508(t2,(C_word)C_i_equalp(lf[192],t1));}

/* k3506 in k3413 in a3407 in k3319 in k3316 in k3313 in k3310 in k3304 in setup-api#install-extension in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_fcall f_3508(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3508,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3527,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 507  shellpath */
((C_proc3)C_retrieve_symbol_proc(lf[19]))(3,*((C_word*)lf[19]+1),t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_3418(2,t2,C_SCHEME_UNDEFINED);}}

/* k3525 in k3506 in k3413 in a3407 in k3319 in k3316 in k3313 in k3310 in k3304 in setup-api#install-extension in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_3527(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3527,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,C_retrieve2(lf[30],"setup-api#*remove-command*"),t2);
t4=(C_word)C_a_i_list(&a,1,t3);
/* setup-api#execute */
((C_proc3)C_retrieve_symbol_proc(lf[92]))(3,*((C_word*)lf[92]+1),((C_word*)t0)[2],t4);}

/* k3416 in k3413 in a3407 in k3319 in k3316 in k3313 in k3310 in k3304 in setup-api#install-extension in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_3418(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3418,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3421,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* setup-api.scm: 508  copy-file */
((C_proc4)C_retrieve_symbol_proc(lf[165]))(4,*((C_word*)lf[165]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k3419 in k3416 in k3413 in a3407 in k3319 in k3316 in k3313 in k3310 in k3304 in setup-api#install-extension in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_3421(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3421,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3424,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(C_retrieve2(lf[13],"setup-api#*windows-shell*"))){
t3=t2;
f_3424(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3505,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 510  shellpath */
((C_proc3)C_retrieve_symbol_proc(lf[19]))(3,*((C_word*)lf[19]+1),t3,((C_word*)t0)[3]);}}

/* k3503 in k3419 in k3416 in k3413 in a3407 in k3319 in k3316 in k3313 in k3310 in k3304 in setup-api#install-extension in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_3505(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3505,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[158],t2);
t4=(C_word)C_a_i_cons(&a,2,C_retrieve2(lf[32],"setup-api#*chmod-command*"),t3);
t5=(C_word)C_a_i_list(&a,1,t4);
/* setup-api#execute */
((C_proc3)C_retrieve_symbol_proc(lf[92]))(3,*((C_word*)lf[92]+1),((C_word*)t0)[2],t5);}

/* k3422 in k3419 in k3416 in k3413 in a3407 in k3319 in k3316 in k3313 in k3310 in k3304 in setup-api#install-extension in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_3424(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3424,2,t0,t1);}
t2=(C_word)C_i_assq(lf[188],((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3430,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t2)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3439,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3482,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* setup-api.scm: 512  software-version */
((C_proc2)C_retrieve_symbol_proc(lf[191]))(2,*((C_word*)lf[191]+1),t5);}
else{
t4=t3;
f_3430(2,t4,C_SCHEME_FALSE);}}

/* k3480 in k3422 in k3419 in k3416 in k3413 in a3407 in k3319 in k3316 in k3313 in k3310 in k3304 in setup-api#install-extension in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_3482(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3482,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[189]);
if(C_truep(t2)){
t3=(C_word)C_i_cadr(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_equalp(t3,((C_word*)t0)[4]))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3474,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 514  pathname-extension */
((C_proc3)C_retrieve_symbol_proc(lf[91]))(3,*((C_word*)lf[91]+1),t4,((C_word*)t0)[2]);}
else{
t4=((C_word*)t0)[3];
f_3439(t4,C_SCHEME_FALSE);}}
else{
t3=((C_word*)t0)[3];
f_3439(t3,C_SCHEME_FALSE);}}

/* k3472 in k3480 in k3422 in k3419 in k3416 in k3413 in a3407 in k3319 in k3316 in k3313 in k3310 in k3304 in setup-api#install-extension in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_3474(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_3439(t2,(C_word)C_i_equalp(t1,lf[190]));}

/* k3437 in k3422 in k3419 in k3416 in k3413 in a3407 in k3319 in k3316 in k3313 in k3310 in k3304 in setup-api#install-extension in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_fcall f_3439(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3439,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3458,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 515  shellpath */
((C_proc3)C_retrieve_symbol_proc(lf[19]))(3,*((C_word*)lf[19]+1),t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_3430(2,t2,C_SCHEME_UNDEFINED);}}

/* k3456 in k3437 in k3422 in k3419 in k3416 in k3413 in a3407 in k3319 in k3316 in k3313 in k3310 in k3304 in setup-api#install-extension in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_3458(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3458,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,C_retrieve2(lf[33],"setup-api#*ranlib-command*"),t2);
t4=(C_word)C_a_i_list(&a,1,t3);
/* setup-api#execute */
((C_proc3)C_retrieve_symbol_proc(lf[92]))(3,*((C_word*)lf[92]+1),((C_word*)t0)[2],t4);}

/* k3428 in k3422 in k3419 in k3416 in k3413 in a3407 in k3319 in k3316 in k3313 in k3310 in k3304 in setup-api#install-extension in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_3430(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 516  make-dest-pathname */
f_3174(((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3322 in k3319 in k3316 in k3313 in k3310 in k3304 in setup-api#install-extension in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_3324(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3324,2,t0,t1);}
t2=(C_word)C_i_assq(lf[179],((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3330,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3386,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 519  print */
((C_proc5)C_retrieve_proc(*((C_word*)lf[46]+1)))(5,*((C_word*)lf[46]+1),t4,lf[186],C_retrieve2(lf[17],"setup-api#*doc-path*"),lf[187]);}
else{
t4=t3;
f_3330(2,t4,C_SCHEME_FALSE);}}

/* k3384 in k3322 in k3319 in k3316 in k3313 in k3310 in k3304 in setup-api#install-extension in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_3386(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3386,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3389,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3394,a[2]=((C_word)li53),tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* for-each */
t5=*((C_word*)lf[106]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,t3,t4);}

/* a3393 in k3384 in k3322 in k3319 in k3316 in k3313 in k3310 in k3304 in setup-api#install-extension in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_3394(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3394,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3402,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 522  make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[102]))(4,*((C_word*)lf[102]+1),t3,C_retrieve2(lf[17],"setup-api#*doc-path*"),t2);}

/* k3400 in a3393 in k3384 in k3322 in k3319 in k3316 in k3313 in k3310 in k3304 in setup-api#install-extension in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_3402(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 522  copy-file */
((C_proc5)C_retrieve_symbol_proc(lf[165]))(5,*((C_word*)lf[165]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1,C_SCHEME_FALSE);}

/* k3387 in k3384 in k3322 in k3319 in k3316 in k3313 in k3310 in k3304 in setup-api#install-extension in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_3389(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 524  newline */
((C_proc2)C_retrieve_proc(*((C_word*)lf[181]+1)))(2,*((C_word*)lf[181]+1),((C_word*)t0)[2]);}

/* k3328 in k3322 in k3319 in k3316 in k3313 in k3310 in k3304 in setup-api#install-extension in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_3330(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3330,2,t0,t1);}
t2=(C_word)C_i_assq(lf[180],((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3336,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3342,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 526  print */
((C_proc5)C_retrieve_proc(*((C_word*)lf[46]+1)))(5,*((C_word*)lf[46]+1),t4,lf[184],C_retrieve2(lf[17],"setup-api#*doc-path*"),lf[185]);}
else{
t4=t3;
f_3336(2,t4,C_SCHEME_FALSE);}}

/* k3340 in k3328 in k3322 in k3319 in k3316 in k3313 in k3310 in k3304 in setup-api#install-extension in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_3342(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3342,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3345,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3350,a[2]=((C_word)li52),tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* for-each */
t5=*((C_word*)lf[106]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,t3,t4);}

/* a3349 in k3340 in k3328 in k3322 in k3319 in k3316 in k3313 in k3310 in k3304 in setup-api#install-extension in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_3350(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3350,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3354,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 529  make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[102]))(4,*((C_word*)lf[102]+1),t3,C_retrieve2(lf[17],"setup-api#*doc-path*"),t2);}

/* k3352 in a3349 in k3340 in k3328 in k3322 in k3319 in k3316 in k3313 in k3310 in k3304 in setup-api#install-extension in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_3354(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3354,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3357,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 530  copy-file */
((C_proc5)C_retrieve_symbol_proc(lf[165]))(5,*((C_word*)lf[165]+1),t2,((C_word*)t0)[2],t1,C_SCHEME_FALSE);}

/* k3355 in k3352 in a3349 in k3340 in k3328 in k3322 in k3319 in k3316 in k3313 in k3310 in k3304 in setup-api#install-extension in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_3357(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3357,2,t0,t1);}
if(C_truep(C_retrieve2(lf[13],"setup-api#*windows-shell*"))){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[182],t2);
t4=(C_word)C_a_i_cons(&a,2,lf[183],t3);
t5=(C_word)C_a_i_list(&a,1,t4);
/* setup-api#execute */
((C_proc3)C_retrieve_symbol_proc(lf[92]))(3,*((C_word*)lf[92]+1),((C_word*)t0)[3],t5);}}

/* k3343 in k3340 in k3328 in k3322 in k3319 in k3316 in k3313 in k3310 in k3304 in setup-api#install-extension in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_3345(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 534  newline */
((C_proc2)C_retrieve_proc(*((C_word*)lf[181]+1)))(2,*((C_word*)lf[181]+1),((C_word*)t0)[2]);}

/* k3334 in k3328 in k3322 in k3319 in k3316 in k3313 in k3310 in k3304 in setup-api#install-extension in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_3336(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 535  write-info */
f_2833(((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* setup-api#check-filelist in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_fcall f_3199(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3199,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3205,a[2]=((C_word)li50),tmp=(C_word)a,a+=3,tmp);
/* map */
t4=*((C_word*)lf[103]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t3,t2);}

/* a3204 in setup-api#check-filelist in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_3205(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3205,3,t0,t1,t2);}
if(C_truep((C_word)C_i_stringp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3218,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_listp(t2))){
/* setup-api.scm: 481  every */
((C_proc4)C_retrieve_symbol_proc(lf[142]))(4,*((C_word*)lf[142]+1),t3,*((C_word*)lf[143]+1),t2);}
else{
t4=t3;
f_3218(2,t4,C_SCHEME_FALSE);}}}

/* k3216 in a3204 in setup-api#check-filelist in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_3218(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3218,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3221,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t3=(C_word)C_i_car(((C_word*)t0)[2]);
t4=(C_word)C_i_cdr(((C_word*)t0)[2]);
t5=t2;
f_3221(t5,(C_word)C_a_i_list(&a,2,t3,t4));}
else{
t3=t2;
f_3221(t3,C_SCHEME_FALSE);}}}

/* k3219 in k3216 in a3204 in setup-api#check-filelist in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_fcall f_3221(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
/* setup-api.scm: 483  error */
((C_proc4)C_retrieve_proc(*((C_word*)lf[108]+1)))(4,*((C_word*)lf[108]+1),((C_word*)t0)[3],lf[177],((C_word*)t0)[2]);}}

/* setup-api#make-dest-pathname in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_fcall f_3174(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
loop:
a=C_alloc(5);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3174,NULL,3,t1,t2,t3);}
if(C_truep((C_word)C_i_listp(t3))){
t4=(C_word)C_i_cadr(t3);
/* setup-api.scm: 473  make-dest-pathname */
t7=t1;
t8=t2;
t9=t4;
t1=t7;
t2=t8;
t3=t9;
goto loop;}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3194,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* setup-api.scm: 474  absolute-pathname? */
((C_proc3)C_retrieve_symbol_proc(lf[175]))(3,*((C_word*)lf[175]+1),t4,t3);}}

/* k3192 in setup-api#make-dest-pathname in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_3194(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}
else{
/* setup-api.scm: 476  make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[102]))(4,*((C_word*)lf[102]+1),((C_word*)t0)[4],((C_word*)t0)[2],((C_word*)t0)[3]);}}

/* setup-api#remove-file* in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_3152(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3152,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3172,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 469  shellpath */
((C_proc3)C_retrieve_symbol_proc(lf[19]))(3,*((C_word*)lf[19]+1),t3,t2);}

/* k3170 in setup-api#remove-file* in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_3172(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3172,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,C_retrieve2(lf[30],"setup-api#*remove-command*"),t2);
t4=(C_word)C_a_i_list(&a,1,t3);
/* setup-api#execute */
((C_proc3)C_retrieve_symbol_proc(lf[92]))(3,*((C_word*)lf[92]+1),((C_word*)t0)[2],t4);}

/* setup-api#move-file in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_3097(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3097,4,t0,t1,t2,t3);}
t4=(C_word)C_i_pairp(t2);
t5=(C_truep(t4)?(C_word)C_i_car(t2):t2);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3104,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t7=(C_word)C_i_cadr(t2);
/* setup-api.scm: 464  make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[102]))(4,*((C_word*)lf[102]+1),t6,t3,t7);}
else{
t7=t6;
f_3104(2,t7,t3);}}

/* k3102 in setup-api#move-file in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_3104(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3104,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3107,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* setup-api.scm: 465  ensure-directory */
f_3918(t2,t1);}

/* k3105 in k3102 in setup-api#move-file in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_3107(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3107,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3126,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 466  shellpath */
((C_proc3)C_retrieve_symbol_proc(lf[19]))(3,*((C_word*)lf[19]+1),t2,((C_word*)t0)[2]);}

/* k3124 in k3105 in k3102 in setup-api#move-file in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_3126(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3126,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3134,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 466  shellpath */
((C_proc3)C_retrieve_symbol_proc(lf[19]))(3,*((C_word*)lf[19]+1),t2,((C_word*)t0)[2]);}

/* k3132 in k3124 in k3105 in k3102 in setup-api#move-file in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_3134(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3134,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=(C_word)C_a_i_cons(&a,2,C_retrieve2(lf[31],"setup-api#*move-command*"),t3);
t5=(C_word)C_a_i_list(&a,1,t4);
/* setup-api#execute */
((C_proc3)C_retrieve_symbol_proc(lf[92]))(3,*((C_word*)lf[92]+1),((C_word*)t0)[2],t5);}

/* setup-api#copy-file in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_2947(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+13)){
C_save_and_reclaim((void*)tr4r,(void*)f_2947r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_2947r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2947r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(13);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2949,a[2]=t3,a[3]=t2,a[4]=((C_word)li43),tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3040,a[2]=t5,a[3]=((C_word)li44),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3049,a[2]=t6,a[3]=((C_word)li45),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-err802846 */
t8=t7;
f_3049(t8,t1);}
else{
t8=(C_word)C_i_car(t4);
t9=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t9))){
/* def-prefix803842 */
t10=t6;
f_3040(t10,t1,t8);}
else{
t10=(C_word)C_i_car(t9);
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
/* body800809 */
t12=t5;
f_2949(t12,t1,t8,t10);}
else{
/* ##sys#error */
t12=*((C_word*)lf[153]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t1,lf[0],t11);}}}}

/* def-err802 in setup-api#copy-file in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_fcall f_3049(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3049,NULL,2,t0,t1);}
/* def-prefix803842 */
t2=((C_word*)t0)[2];
f_3040(t2,t1,C_SCHEME_TRUE);}

/* def-prefix803 in setup-api#copy-file in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_fcall f_3040(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3040,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3048,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* setup-api.scm: 449  installation-prefix */
((C_proc2)C_retrieve_symbol_proc(lf[155]))(2,*((C_word*)lf[155]+1),t3);}

/* k3046 in def-prefix803 in setup-api#copy-file in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_3048(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* body800809 */
t2=((C_word*)t0)[4];
f_2949(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* body800 in setup-api#copy-file in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_fcall f_2949(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2949,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_pairp(((C_word*)t0)[3]);
t5=(C_truep(t4)?(C_word)C_i_car(((C_word*)t0)[3]):((C_word*)t0)[3]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2956,a[2]=t3,a[3]=t2,a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
t7=(C_word)C_i_cadr(((C_word*)t0)[3]);
/* setup-api.scm: 451  make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[102]))(4,*((C_word*)lf[102]+1),t6,((C_word*)t0)[2],t7);}
else{
t7=t6;
f_2956(2,t7,((C_word*)t0)[2]);}}

/* k2954 in body800 in setup-api#copy-file in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_2956(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2956,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2959,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3013,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3023,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 452  string-prefix? */
((C_proc4)C_retrieve_symbol_proc(lf[171]))(4,*((C_word*)lf[171]+1),t4,((C_word*)t0)[2],t1);}
else{
t4=t3;
f_3013(t4,C_SCHEME_FALSE);}}

/* k3021 in k2954 in body800 in setup-api#copy-file in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_3023(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_3013(t2,(C_word)C_i_not(t1));}

/* k3011 in k2954 in body800 in setup-api#copy-file in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_fcall f_3013(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* setup-api.scm: 453  make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[102]))(4,*((C_word*)lf[102]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
f_2959(2,t2,((C_word*)t0)[2]);}}

/* k2957 in k2954 in body800 in setup-api#copy-file in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_2959(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2959,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2962,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* setup-api.scm: 454  ensure-directory */
f_3918(t2,t1);}

/* k2960 in k2957 in k2954 in body800 in setup-api#copy-file in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_2962(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2962,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2968,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* setup-api.scm: 455  glob? */
((C_proc3)C_retrieve_symbol_proc(lf[169]))(3,*((C_word*)lf[169]+1),t2,((C_word*)t0)[3]);}

/* k2966 in k2960 in k2957 in k2954 in body800 in setup-api#copy-file in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_2968(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2968,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2971,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t1)){
t3=t2;
f_2971(2,t3,t1);}
else{
/* setup-api.scm: 455  file-exists? */
((C_proc3)C_retrieve_symbol_proc(lf[126]))(3,*((C_word*)lf[126]+1),t2,((C_word*)t0)[3]);}}

/* k2969 in k2966 in k2960 in k2957 in k2954 in body800 in setup-api#copy-file in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_2971(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2971,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2974,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2990,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 457  shellpath */
((C_proc3)C_retrieve_symbol_proc(lf[19]))(3,*((C_word*)lf[19]+1),t3,((C_word*)t0)[3]);}
else{
if(C_truep(((C_word*)t0)[2])){
/* setup-api.scm: 459  error */
((C_proc4)C_retrieve_proc(*((C_word*)lf[108]+1)))(4,*((C_word*)lf[108]+1),((C_word*)t0)[5],lf[166],((C_word*)t0)[3]);}
else{
/* setup-api.scm: 460  warning */
((C_proc4)C_retrieve_symbol_proc(lf[167]))(4,*((C_word*)lf[167]+1),((C_word*)t0)[5],lf[168],((C_word*)t0)[3]);}}}

/* k2988 in k2969 in k2966 in k2960 in k2957 in k2954 in body800 in setup-api#copy-file in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_2990(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2990,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2998,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 457  shellpath */
((C_proc3)C_retrieve_symbol_proc(lf[19]))(3,*((C_word*)lf[19]+1),t2,((C_word*)t0)[2]);}

/* k2996 in k2988 in k2969 in k2966 in k2960 in k2957 in k2954 in body800 in setup-api#copy-file in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_2998(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2998,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=(C_word)C_a_i_cons(&a,2,C_retrieve2(lf[29],"setup-api#*copy-command*"),t3);
t5=(C_word)C_a_i_list(&a,1,t4);
/* setup-api#execute */
((C_proc3)C_retrieve_symbol_proc(lf[92]))(3,*((C_word*)lf[92]+1),((C_word*)t0)[2],t5);}

/* k2972 in k2969 in k2966 in k2960 in k2957 in k2954 in body800 in setup-api#copy-file in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_2974(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* setup-api#write-info in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_fcall f_2833(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2833,NULL,4,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2945,a[2]=t4,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* ##sys#append */
t6=*((C_word*)lf[164]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t3,C_SCHEME_END_OF_LIST);}

/* k2943 in setup-api#write-info in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_2945(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2945,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[157],t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2941,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* ##sys#append */
t4=*((C_word*)lf[164]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k2939 in k2943 in setup-api#write-info in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_2941(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2941,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2840,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2930,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* setup-api.scm: 439  setup-verbose-flag */
((C_proc2)C_retrieve_symbol_proc(lf[25]))(2,*((C_word*)lf[25]+1),t4);}

/* k2928 in k2939 in k2943 in setup-api#write-info in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_2930(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* setup-api.scm: 439  printf */
((C_proc5)C_retrieve_symbol_proc(lf[56]))(5,*((C_word*)lf[56]+1),((C_word*)t0)[4],lf[163],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
f_2840(2,t2,C_SCHEME_UNDEFINED);}}

/* k2838 in k2939 in k2943 in setup-api#write-info in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_2840(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2840,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2843,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 440  ->string */
((C_proc3)C_retrieve_symbol_proc(lf[104]))(3,*((C_word*)lf[104]+1),t2,((C_word*)t0)[2]);}

/* k2841 in k2838 in k2939 in k2943 in setup-api#write-info in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_2843(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2843,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2846,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2927,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 441  repo-path */
f_3867(t3,(C_word)C_a_i_list(&a,1,C_SCHEME_TRUE));}

/* k2925 in k2841 in k2838 in k2939 in k2943 in setup-api#write-info in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_2927(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2927,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=(C_word)C_a_i_list(&a,1,t1);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2802,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* setup-api.scm: 430  repository-path */
((C_proc2)C_retrieve_symbol_proc(lf[161]))(2,*((C_word*)lf[161]+1),t4);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_2802(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[153]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k2800 in k2925 in k2841 in k2838 in k2939 in k2943 in setup-api#write-info in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_2802(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 431  make-pathname */
((C_proc5)C_retrieve_symbol_proc(lf[102]))(5,*((C_word*)lf[102]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2],lf[160]);}

/* k2844 in k2841 in k2838 in k2939 in k2943 in setup-api#write-info in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_2846(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2846,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2849,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[12],"setup-api#*sudo*"))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2878,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* setup-api.scm: 443  create-temporary-file */
((C_proc2)C_retrieve_symbol_proc(lf[83]))(2,*((C_word*)lf[83]+1),t3);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2919,a[2]=((C_word*)t0)[2],a[3]=((C_word)li41),tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 446  with-output-to-file */
((C_proc4)C_retrieve_symbol_proc(lf[81]))(4,*((C_word*)lf[81]+1),t2,t1,t3);}}

/* a2918 in k2844 in k2841 in k2838 in k2939 in k2943 in setup-api#write-info in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_2919(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2919,2,t0,t1);}
/* pp */
((C_proc3)C_retrieve_symbol_proc(lf[159]))(3,*((C_word*)lf[159]+1),t1,((C_word*)t0)[2]);}

/* k2876 in k2844 in k2841 in k2838 in k2939 in k2943 in setup-api#write-info in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_2878(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2878,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2881,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2910,a[2]=((C_word*)t0)[2],a[3]=((C_word)li40),tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 444  with-output-to-file */
((C_proc4)C_retrieve_symbol_proc(lf[81]))(4,*((C_word*)lf[81]+1),t2,t1,t3);}

/* a2909 in k2876 in k2844 in k2841 in k2838 in k2939 in k2943 in setup-api#write-info in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_2910(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2910,2,t0,t1);}
/* pp */
((C_proc3)C_retrieve_symbol_proc(lf[159]))(3,*((C_word*)lf[159]+1),t1,((C_word*)t0)[2]);}

/* k2879 in k2876 in k2844 in k2841 in k2838 in k2939 in k2943 in setup-api#write-info in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_2881(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2881,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2900,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 445  shellpath */
((C_proc3)C_retrieve_symbol_proc(lf[19]))(3,*((C_word*)lf[19]+1),t2,((C_word*)t0)[2]);}

/* k2898 in k2879 in k2876 in k2844 in k2841 in k2838 in k2939 in k2943 in setup-api#write-info in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_2900(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2900,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2908,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 445  shellpath */
((C_proc3)C_retrieve_symbol_proc(lf[19]))(3,*((C_word*)lf[19]+1),t2,((C_word*)t0)[2]);}

/* k2906 in k2898 in k2879 in k2876 in k2844 in k2841 in k2838 in k2939 in k2943 in setup-api#write-info in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_2908(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2908,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=(C_word)C_a_i_cons(&a,2,C_retrieve2(lf[31],"setup-api#*move-command*"),t3);
t5=(C_word)C_a_i_list(&a,1,t4);
/* setup-api#execute */
((C_proc3)C_retrieve_symbol_proc(lf[92]))(3,*((C_word*)lf[92]+1),((C_word*)t0)[2],t5);}

/* k2847 in k2844 in k2841 in k2838 in k2939 in k2943 in setup-api#write-info in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_2849(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2849,2,t0,t1);}
if(C_truep(C_retrieve2(lf[13],"setup-api#*windows-shell*"))){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2875,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 447  shellpath */
((C_proc3)C_retrieve_symbol_proc(lf[19]))(3,*((C_word*)lf[19]+1),t2,((C_word*)t0)[2]);}}

/* k2873 in k2847 in k2844 in k2841 in k2838 in k2939 in k2943 in setup-api#write-info in k2829 in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_2875(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2875,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[158],t2);
t4=(C_word)C_a_i_cons(&a,2,C_retrieve2(lf[32],"setup-api#*chmod-command*"),t3);
t5=(C_word)C_a_i_list(&a,1,t4);
/* setup-api#execute */
((C_proc3)C_retrieve_symbol_proc(lf[92]))(3,*((C_word*)lf[92]+1),((C_word*)t0)[2],t5);}

/* setup-api#make/proc in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_2755(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_2755r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2755r(t0,t1,t2,t3);}}

static void C_ccall f_2755r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(4);
t4=(C_word)C_i_length(t3);
switch(t4){
case C_fix(0):
t5=t2;
/* setup-api.scm: 389  make:make/proc/helper */
f_2465(t1,t5,C_SCHEME_END_OF_LIST);
case C_fix(1):
t5=t2;
t6=(C_word)C_i_car(t3);
t7=(C_word)C_i_cdr(t3);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2787,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_vectorp(t6))){
/* setup-api.scm: 394  vector->list */
((C_proc3)C_retrieve_proc(*((C_word*)lf[151]+1)))(3,*((C_word*)lf[151]+1),t8,t6);}
else{
t9=t8;
f_2787(2,t9,t6);}
default:
/* ##sys#error */
t5=*((C_word*)lf[153]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t1,lf[154]);}}

/* k2785 in setup-api#make/proc in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_2787(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 391  make:make/proc/helper */
f_2465(((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* setup-api#make:make/proc/helper in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_fcall f_2465(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2465,NULL,3,t1,t2,t3);}
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2469,a[2]=t4,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_vectorp(((C_word*)t4)[1]))){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2753,a[2]=t5,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 323  vector->list */
((C_proc3)C_retrieve_proc(*((C_word*)lf[151]+1)))(3,*((C_word*)lf[151]+1),t6,((C_word*)t4)[1]);}
else{
t6=t5;
f_2469(t6,C_SCHEME_UNDEFINED);}}

/* k2751 in setup-api#make:make/proc/helper in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_2753(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_2469(t3,t2);}

/* k2467 in setup-api#make:make/proc/helper in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_fcall f_2469(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2469,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2472,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[4];
t4=(C_word)C_i_listp(t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2297,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t4)){
t6=t5;
f_2297(2,t6,t4);}
else{
/* setup-api.scm: 295  make:form-error */
f_2267(t5,lf[150],t3);}}

/* k2295 in k2467 in setup-api#make:make/proc/helper in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_2297(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2297,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_pairp(((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2306,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t2)){
t4=t3;
f_2306(2,t4,t2);}
else{
/* setup-api.scm: 296  make:form-error */
f_2267(t3,lf[149],((C_word*)t0)[3]);}}
else{
t2=((C_word*)t0)[2];
f_2472(2,t2,C_SCHEME_FALSE);}}

/* k2304 in k2295 in k2467 in setup-api#make:make/proc/helper in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_2306(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2306,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2311,a[2]=((C_word)li37),tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 297  every */
((C_proc4)C_retrieve_symbol_proc(lf[142]))(4,*((C_word*)lf[142]+1),((C_word*)t0)[3],t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_2472(2,t2,C_SCHEME_FALSE);}}

/* a2310 in k2304 in k2295 in k2467 in setup-api#make:make/proc/helper in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_2311(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2311,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2318,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_listp(t2))){
t4=(C_word)C_i_length(t2);
/* setup-api.scm: 299  <= */
C_less_or_equal_p(5,0,t3,C_fix(2),t4,C_fix(3));}
else{
t4=t3;
f_2318(2,t4,C_SCHEME_FALSE);}}

/* k2316 in a2310 in k2304 in k2295 in k2467 in setup-api#make:make/proc/helper in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_2318(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2318,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2321,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=t2;
f_2321(2,t3,t1);}
else{
/* setup-api.scm: 300  make:form-error */
f_2267(t2,lf[148],((C_word*)t0)[3]);}}

/* k2319 in k2316 in a2310 in k2304 in k2295 in k2467 in setup-api#make:make/proc/helper in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_2321(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2321,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(C_word)C_i_stringp(t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2330,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t3)){
t5=t4;
f_2330(2,t5,t3);}
else{
t5=(C_word)C_i_car(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_listp(t5))){
t6=(C_word)C_i_car(((C_word*)t0)[3]);
/* setup-api.scm: 303  every */
((C_proc4)C_retrieve_symbol_proc(lf[142]))(4,*((C_word*)lf[142]+1),t4,*((C_word*)lf[143]+1),t6);}
else{
t6=t4;
f_2330(2,t6,C_SCHEME_FALSE);}}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k2328 in k2319 in k2316 in a2310 in k2304 in k2295 in k2467 in setup-api#make:make/proc/helper in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_2330(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2330,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2333,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=t2;
f_2333(2,t3,t1);}
else{
/* setup-api.scm: 304  make:form-error */
f_2267(t2,lf[147],((C_word*)t0)[3]);}}

/* k2331 in k2328 in k2319 in k2316 in a2310 in k2304 in k2295 in k2467 in setup-api#make:make/proc/helper in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_2333(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2333,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(C_word)C_i_cadr(((C_word*)t0)[3]);
t4=(C_word)C_i_listp(t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2342,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t4)){
t6=t5;
f_2342(2,t6,t4);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2372,a[2]=((C_word*)t0)[3],a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_i_cadr(((C_word*)t0)[3]);
/* setup-api.scm: 307  make:line-error */
f_2277(t6,lf[146],t7,t2);}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k2370 in k2331 in k2328 in k2319 in k2316 in a2310 in k2304 in k2295 in k2467 in setup-api#make:make/proc/helper in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_2372(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2372,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_2342(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2380,a[2]=((C_word)li36),tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[2]);
/* setup-api.scm: 308  every */
((C_proc4)C_retrieve_symbol_proc(lf[142]))(4,*((C_word*)lf[142]+1),((C_word*)t0)[3],t2,t3);}}

/* a2379 in k2370 in k2331 in k2328 in k2319 in k2316 in a2310 in k2304 in k2295 in k2467 in setup-api#make:make/proc/helper in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_2380(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2380,3,t0,t1,t2);}
t3=(C_word)C_i_stringp(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
/* setup-api.scm: 310  make:form-error */
f_2267(t1,lf[145],t2);}}

/* k2340 in k2331 in k2328 in k2319 in k2316 in a2310 in k2304 in k2295 in k2467 in setup-api#make:make/proc/helper in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_2342(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
t2=(C_word)C_i_cddr(((C_word*)t0)[4]);
t3=(C_word)C_i_nullp(t2);
if(C_truep(t3)){
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_i_caddr(((C_word*)t0)[4]);
t5=(C_word)C_i_closurep(t4);
if(C_truep(t5)){
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t6=(C_word)C_i_caddr(((C_word*)t0)[4]);
/* setup-api.scm: 314  make:line-error */
f_2277(((C_word*)t0)[3],lf[144],t6,((C_word*)t0)[2]);}}}

/* k2470 in k2467 in setup-api#make:make/proc/helper in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_2472(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2472,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2475,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)((C_word*)t0)[2])[1];
t4=(C_word)C_i_stringp(t3);
if(C_truep(t4)){
t5=t2;
f_2475(2,t5,t4);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2457,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 319  every */
((C_proc4)C_retrieve_symbol_proc(lf[142]))(4,*((C_word*)lf[142]+1),t5,*((C_word*)lf[143]+1),t3);}}

/* k2455 in k2470 in k2467 in setup-api#make:make/proc/helper in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_2457(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_2475(2,t2,t1);}
else{
/* setup-api.scm: 320  error */
((C_proc4)C_retrieve_proc(*((C_word*)lf[108]+1)))(4,*((C_word*)lf[108]+1),((C_word*)t0)[3],lf[141],((C_word*)t0)[2]);}}

/* k2473 in k2470 in k2467 in setup-api#make:make/proc/helper in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_2475(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2475,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t3,0,C_SCHEME_END_OF_LIST);
t11=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2480,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=t9,a[7]=t7,a[8]=t5,tmp=(C_word)a,a+=9,tmp);
/* setup-api.scm: 327  condition-predicate */
((C_proc3)C_retrieve_symbol_proc(lf[140]))(3,*((C_word*)lf[140]+1),t11,lf[138]);}

/* k2478 in k2473 in k2470 in k2467 in setup-api#make:make/proc/helper in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_2480(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2480,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[8])+1,t1);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2484,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* setup-api.scm: 328  condition-property-accessor */
((C_proc4)C_retrieve_symbol_proc(lf[137]))(4,*((C_word*)lf[137]+1),t3,lf[138],lf[139]);}

/* k2482 in k2478 in k2473 in k2470 in k2467 in setup-api#make:make/proc/helper in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_2484(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2484,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[8])+1,t1);
t3=C_mutate(((C_word *)((C_word*)t0)[7])+1,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2486,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[6],a[7]=((C_word)li33),tmp=(C_word)a,a+=8,tmp));
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2699,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_stringp(((C_word*)((C_word*)t0)[2])[1]))){
/* setup-api.scm: 379  make-file */
t5=((C_word*)((C_word*)t0)[7])[1];
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)((C_word*)t0)[2])[1],lf[133]);}
else{
if(C_truep((C_word)C_i_nullp(((C_word*)((C_word*)t0)[2])[1]))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2737,a[2]=t4,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 380  caar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[135]+1)))(3,*((C_word*)lf[135]+1),t5,((C_word*)t0)[4]);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2742,a[2]=((C_word*)t0)[7],a[3]=((C_word)li35),tmp=(C_word)a,a+=4,tmp);
/* for-each */
t6=*((C_word*)lf[106]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,((C_word*)((C_word*)t0)[2])[1]);}}}

/* a2741 in k2482 in k2478 in k2473 in k2470 in k2467 in setup-api#make:make/proc/helper in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_2742(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2742,3,t0,t1,t2);}
/* setup-api.scm: 381  make-file */
t3=((C_word*)((C_word*)t0)[2])[1];
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,lf[136]);}

/* k2735 in k2482 in k2478 in k2473 in k2470 in k2467 in setup-api#make:make/proc/helper in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_2737(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 380  make-file */
t2=((C_word*)((C_word*)t0)[3])[1];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,lf[134]);}

/* k2697 in k2482 in k2478 in k2473 in k2470 in k2467 in setup-api#make:make/proc/helper in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_2699(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2699,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2705,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 382  setup-verbose-flag */
((C_proc2)C_retrieve_symbol_proc(lf[25]))(2,*((C_word*)lf[25]+1),t2);}

/* k2703 in k2697 in k2482 in k2478 in k2473 in k2470 in k2467 in setup-api#make:make/proc/helper in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_2705(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2705,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2710,a[2]=((C_word)li34),tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2718,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 385  reverse */
((C_proc3)C_retrieve_proc(*((C_word*)lf[132]+1)))(3,*((C_word*)lf[132]+1),t3,((C_word*)((C_word*)t0)[2])[1]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k2716 in k2703 in k2697 in k2482 in k2478 in k2473 in k2470 in k2467 in setup-api#make:make/proc/helper in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_2718(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[106]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2709 in k2703 in k2697 in k2482 in k2478 in k2473 in k2470 in k2467 in setup-api#make:make/proc/helper in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_2710(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2710,3,t0,t1,t2);}
/* setup-api.scm: 384  printf */
((C_proc4)C_retrieve_symbol_proc(lf[56]))(4,*((C_word*)lf[56]+1),t1,lf[131],t2);}

/* f_2486 in k2482 in k2478 in k2473 in k2470 in k2467 in setup-api#make:make/proc/helper in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_2486(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[20],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2486,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2490,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t2,a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t5=t2;
t6=((C_word*)t0)[2];
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2213,a[2]=t5,a[3]=((C_word)li31),tmp=(C_word)a,a+=4,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2222,a[2]=t7,a[3]=t9,a[4]=((C_word)li32),tmp=(C_word)a,a+=5,tmp));
t11=((C_word*)t9)[1];
f_2222(t11,t4,t6);}

/* loop */
static void C_fcall f_2222(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2222,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2235,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t3,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_i_car(t3);
if(C_truep((C_word)C_i_stringp(t5))){
t6=(C_word)C_i_car(t3);
t7=t4;
f_2235(t7,(C_word)C_a_i_list(&a,1,t6));}
else{
t6=t4;
f_2235(t6,(C_word)C_i_car(t3));}}}

/* k2233 in loop */
static void C_fcall f_2235(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2235,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2241,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* setup-api.scm: 287  any */
((C_proc4)C_retrieve_symbol_proc(lf[127]))(4,*((C_word*)lf[127]+1),t2,((C_word*)t0)[2],t1);}

/* k2239 in k2233 in loop */
static void C_ccall f_2241(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[4]);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* setup-api.scm: 289  loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_2222(t3,((C_word*)t0)[5],t2);}}

/* match? */
static void C_ccall f_2213(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2213,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_string_equal_p(t2,((C_word*)t0)[2]));}

/* k2488 */
static void C_ccall f_2490(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2490,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2493,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
/* setup-api.scm: 332  fixmaketarget */
f_2135(t2,((C_word*)t0)[7]);}

/* k2491 in k2488 */
static void C_ccall f_2493(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2493,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2496,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2693,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 333  file-exists? */
((C_proc3)C_retrieve_symbol_proc(lf[126]))(3,*((C_word*)lf[126]+1),t3,t1);}

/* k2691 in k2491 in k2488 */
static void C_ccall f_2693(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* setup-api.scm: 334  file-modification-time */
((C_proc3)C_retrieve_symbol_proc(lf[124]))(3,*((C_word*)lf[124]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_2496(2,t2,C_SCHEME_FALSE);}}

/* k2494 in k2491 in k2488 */
static void C_ccall f_2496(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2496,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2499,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t1,a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2687,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* setup-api.scm: 335  setup-verbose-flag */
((C_proc2)C_retrieve_symbol_proc(lf[25]))(2,*((C_word*)lf[25]+1),t3);}

/* k2685 in k2494 in k2491 in k2488 */
static void C_ccall f_2687(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* setup-api.scm: 336  printf */
((C_proc5)C_retrieve_symbol_proc(lf[56]))(5,*((C_word*)lf[56]+1),((C_word*)t0)[4],lf[130],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
f_2499(2,t2,C_SCHEME_UNDEFINED);}}

/* k2497 in k2494 in k2491 in k2488 */
static void C_ccall f_2499(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2499,2,t0,t1);}
if(C_truep(((C_word*)t0)[11])){
t2=(C_word)C_i_cadr(((C_word*)t0)[11]);
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2508,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2669,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* setup-api.scm: 339  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[118]+1)))(4,*((C_word*)lf[118]+1),t4,lf[128],((C_word*)t0)[4]);}
else{
if(C_truep(((C_word*)t0)[10])){
t2=((C_word*)t0)[9];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2684,a[2]=((C_word*)t0)[9],tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 377  sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[59]))(4,*((C_word*)lf[59]+1),t2,lf[129],((C_word*)t0)[3]);}}}

/* k2682 in k2497 in k2494 in k2491 in k2488 */
static void C_ccall f_2684(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 377  error */
((C_proc3)C_retrieve_proc(*((C_word*)lf[108]+1)))(3,*((C_word*)lf[108]+1),((C_word*)t0)[2],t1);}

/* k2667 in k2497 in k2494 in k2491 in k2488 */
static void C_ccall f_2669(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2669,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2670,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word)li30),tmp=(C_word)a,a+=5,tmp);
/* for-each */
t3=*((C_word*)lf[106]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a2666 in k2667 in k2497 in k2494 in k2491 in k2488 */
static void C_ccall f_2670(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2670,3,t0,t1,t2);}
/* setup-api.scm: 340  make-file */
t3=((C_word*)((C_word*)t0)[3])[1];
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,((C_word*)t0)[2]);}

/* k2506 in k2497 in k2494 in k2491 in k2488 */
static void C_ccall f_2508(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2508,2,t0,t1);}
t2=(C_word)C_i_not(((C_word*)t0)[11]);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2514,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
if(C_truep(t2)){
t4=t3;
f_2514(2,t4,t2);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2638,a[2]=((C_word*)t0)[11],a[3]=((C_word)li29),tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 344  any */
((C_proc4)C_retrieve_symbol_proc(lf[127]))(4,*((C_word*)lf[127]+1),t3,t4,((C_word*)t0)[2]);}}

/* a2637 in k2506 in k2497 in k2494 in k2491 in k2488 */
static void C_ccall f_2638(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2638,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2642,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 345  fixmaketarget */
f_2135(t3,t2);}

/* k2640 in a2637 in k2506 in k2497 in k2494 in k2491 in k2488 */
static void C_ccall f_2642(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2642,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2645,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2658,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 346  file-exists? */
((C_proc3)C_retrieve_symbol_proc(lf[126]))(3,*((C_word*)lf[126]+1),t3,t1);}

/* k2656 in k2640 in a2637 in k2506 in k2497 in k2494 in k2491 in k2488 */
static void C_ccall f_2658(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2658,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_2645(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2665,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 347  sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[59]))(4,*((C_word*)lf[59]+1),t2,lf[125],((C_word*)t0)[2]);}}

/* k2663 in k2656 in k2640 in a2637 in k2506 in k2497 in k2494 in k2491 in k2488 */
static void C_ccall f_2665(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 347  error */
((C_proc3)C_retrieve_proc(*((C_word*)lf[108]+1)))(3,*((C_word*)lf[108]+1),((C_word*)t0)[2],t1);}

/* k2643 in k2640 in a2637 in k2506 in k2497 in k2494 in k2491 in k2488 */
static void C_ccall f_2645(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2645,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2655,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* setup-api.scm: 348  file-modification-time */
((C_proc3)C_retrieve_symbol_proc(lf[124]))(3,*((C_word*)lf[124]+1),t2,((C_word*)t0)[2]);}

/* k2653 in k2643 in k2640 in a2637 in k2506 in k2497 in k2494 in k2491 in k2488 */
static void C_ccall f_2655(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_greaterp(t1,((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?((C_word*)t0)[2]:C_SCHEME_FALSE));}

/* k2512 in k2506 in k2497 in k2494 in k2491 in k2488 */
static void C_ccall f_2514(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2514,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cddr(((C_word*)t0)[10]);
if(C_truep((C_word)C_i_nullp(t2))){
t3=((C_word*)t0)[9];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],((C_word*)((C_word*)t0)[7])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[7])+1,t3);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2533,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2604,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t5,tmp=(C_word)a,a+=7,tmp);
/* setup-api.scm: 355  setup-verbose-flag */
((C_proc2)C_retrieve_symbol_proc(lf[25]))(2,*((C_word*)lf[25]+1),t6);}}
else{
t2=((C_word*)t0)[9];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k2602 in k2512 in k2506 in k2497 in k2494 in k2491 in k2488 */
static void C_ccall f_2604(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2604,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2611,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[3];
if(C_truep(t3)){
if(C_truep((C_word)C_i_stringp(((C_word*)t0)[2]))){
/* setup-api.scm: 363  string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[118]+1)))(5,*((C_word*)lf[118]+1),t2,lf[119],((C_word*)t0)[2],lf[120]);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2633,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 365  sprintf */
((C_proc5)C_retrieve_symbol_proc(lf[59]))(5,*((C_word*)lf[59]+1),t4,lf[121],((C_word*)t0)[2],((C_word*)t0)[3]);}}
else{
/* setup-api.scm: 361  string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[118]+1)))(5,*((C_word*)lf[118]+1),t2,lf[122],((C_word*)t0)[4],lf[123]);}}
else{
t2=((C_word*)t0)[6];
f_2533(2,t2,C_SCHEME_UNDEFINED);}}

/* k2631 in k2602 in k2512 in k2506 in k2497 in k2494 in k2491 in k2488 */
static void C_ccall f_2633(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 365  string-append */
((C_proc3)C_retrieve_proc(*((C_word*)lf[118]+1)))(3,*((C_word*)lf[118]+1),((C_word*)t0)[2],t1);}

/* k2609 in k2602 in k2512 in k2506 in k2497 in k2494 in k2491 in k2488 */
static void C_ccall f_2611(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 356  printf */
((C_proc6)C_retrieve_symbol_proc(lf[56]))(6,*((C_word*)lf[56]+1),((C_word*)t0)[4],lf[117],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2531 in k2512 in k2506 in k2497 in k2494 in k2491 in k2488 */
static void C_ccall f_2533(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2533,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2539,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2541,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word)li28),tmp=(C_word)a,a+=7,tmp);
/* call-with-current-continuation */
((C_proc3)C_retrieve_proc(*((C_word*)lf[116]+1)))(3,*((C_word*)lf[116]+1),t2,t3);}

/* a2540 in k2531 in k2512 in k2506 in k2497 in k2494 in k2491 in k2488 */
static void C_ccall f_2541(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2541,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2547,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word)li23),tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2576,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li27),tmp=(C_word)a,a+=5,tmp);
/* with-exception-handler */
((C_proc4)C_retrieve_symbol_proc(lf[115]))(4,*((C_word*)lf[115]+1),t1,t3,t4);}

/* a2575 in a2540 in k2531 in k2512 in k2506 in k2497 in k2494 in k2491 in k2488 */
static void C_ccall f_2576(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2576,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2582,a[2]=((C_word*)t0)[3],a[3]=((C_word)li24),tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2591,a[2]=((C_word*)t0)[2],a[3]=((C_word)li26),tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a2590 in a2575 in a2540 in k2531 in k2512 in k2506 in k2497 in k2494 in k2491 in k2488 */
static void C_ccall f_2591(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_2591r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2591r(t0,t1,t2);}}

static void C_ccall f_2591r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2597,a[2]=t2,a[3]=((C_word)li25),tmp=(C_word)a,a+=4,tmp);
/* k564569 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a2596 in a2590 in a2575 in a2540 in k2531 in k2512 in k2506 in k2497 in k2494 in k2491 in k2488 */
static void C_ccall f_2597(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2597,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a2581 in a2575 in a2540 in k2531 in k2512 in k2506 in k2497 in k2494 in k2491 in k2488 */
static void C_ccall f_2582(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2582,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[2]);
t3=t2;
((C_proc2)C_retrieve_proc(t3))(2,t3,t1);}

/* a2546 in a2540 in k2531 in k2512 in k2506 in k2497 in k2494 in k2491 in k2488 */
static void C_ccall f_2547(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2547,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2553,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=((C_word)li22),tmp=(C_word)a,a+=7,tmp);
/* k564569 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a2552 in a2546 in a2540 in k2531 in k2512 in k2506 in k2497 in k2494 in k2491 in k2488 */
static void C_ccall f_2553(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2553,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2557,a[2]=((C_word*)t0)[5],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2568,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2571,a[2]=((C_word*)t0)[5],a[3]=t4,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* setup-api.scm: 371  exn? */
t6=((C_word*)((C_word*)t0)[2])[1];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[5]);}

/* k2569 in a2552 in a2546 in a2540 in k2531 in k2512 in k2506 in k2497 in k2494 in k2491 in k2488 */
static void C_ccall f_2571(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* setup-api.scm: 372  exn-message */
t2=((C_word*)((C_word*)t0)[4])[1];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_2568(2,t2,((C_word*)t0)[2]);}}

/* k2566 in a2552 in a2546 in a2540 in k2531 in k2512 in k2506 in k2497 in k2494 in k2491 in k2488 */
static void C_ccall f_2568(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 369  printf */
((C_proc5)C_retrieve_symbol_proc(lf[56]))(5,*((C_word*)lf[56]+1),((C_word*)t0)[3],lf[114],((C_word*)t0)[2],t1);}

/* k2555 in a2552 in a2546 in a2540 in k2531 in k2512 in k2506 in k2497 in k2494 in k2491 in k2488 */
static void C_ccall f_2557(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 374  signal */
((C_proc3)C_retrieve_symbol_proc(lf[113]))(3,*((C_word*)lf[113]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2537 in k2531 in k2512 in k2506 in k2497 in k2494 in k2491 in k2488 */
static void C_ccall f_2539(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* setup-api#make:line-error in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_fcall f_2277(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2277,NULL,4,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2285,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 292  sprintf */
((C_proc6)C_retrieve_symbol_proc(lf[59]))(6,*((C_word*)lf[59]+1),t5,lf[111],t2,t3,t4);}

/* k2283 in setup-api#make:line-error in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_2285(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 292  error */
((C_proc3)C_retrieve_proc(*((C_word*)lf[108]+1)))(3,*((C_word*)lf[108]+1),((C_word*)t0)[2],t1);}

/* setup-api#make:form-error in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_fcall f_2267(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2267,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2275,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 291  sprintf */
((C_proc5)C_retrieve_symbol_proc(lf[59]))(5,*((C_word*)lf[59]+1),t4,lf[109],t2,t3);}

/* k2273 in setup-api#make:form-error in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_2275(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 291  error */
((C_proc3)C_retrieve_proc(*((C_word*)lf[108]+1)))(3,*((C_word*)lf[108]+1),((C_word*)t0)[2],t1);}

/* setup-api#execute in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_2161(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2161,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2164,a[2]=((C_word)li17),tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2192,a[2]=((C_word)li18),tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2209,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* map */
t6=*((C_word*)lf[103]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t3,t2);}

/* k2207 in setup-api#execute in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_2209(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[106]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2191 in setup-api#execute in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_2192(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2192,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2196,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2202,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 261  run-verbose */
((C_proc2)C_retrieve_symbol_proc(lf[85]))(2,*((C_word*)lf[85]+1),t4);}

/* k2200 in a2191 in setup-api#execute in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_2202(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* setup-api.scm: 261  printf */
((C_proc4)C_retrieve_symbol_proc(lf[56]))(4,*((C_word*)lf[56]+1),((C_word*)t0)[3],lf[105],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_2196(2,t2,C_SCHEME_UNDEFINED);}}

/* k2194 in a2191 in setup-api#execute in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_2196(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 262  $system */
f_4670(((C_word*)t0)[3],((C_word*)t0)[2]);}

/* smooth in setup-api#execute in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_2164(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2164,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2168,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* map */
t4=*((C_word*)lf[103]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_retrieve(lf[104]),t2);}

/* k2166 in smooth in setup-api#execute in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_2168(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2168,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2179,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(t1);
if(C_truep((C_word)C_i_string_equal_p(t3,lf[95]))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2093,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2097,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2108,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(C_word)C_i_assoc(t3,C_retrieve2(lf[6],"setup-api#*installed-executables*"));
t8=(C_word)C_i_cdr(t7);
/* setup-api.scm: 238  make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[102]))(4,*((C_word*)lf[102]+1),t6,C_retrieve2(lf[16],"setup-api#*chicken-bin-path*"),t8);}
else{
t4=(C_word)C_i_assoc(t3,C_retrieve2(lf[6],"setup-api#*installed-executables*"));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2129,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t6=(C_word)C_i_cdr(t4);
/* setup-api.scm: 246  make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[102]))(4,*((C_word*)lf[102]+1),t5,C_retrieve2(lf[16],"setup-api#*chicken-bin-path*"),t6);}
else{
t5=t2;
f_2179(2,t5,t3);}}}

/* k2127 in k2166 in smooth in setup-api#execute in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_2129(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 246  shellpath */
((C_proc3)C_retrieve_symbol_proc(lf[19]))(3,*((C_word*)lf[19]+1),((C_word*)t0)[2],t1);}

/* k2106 in k2166 in smooth in setup-api#execute in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_2108(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 237  shellpath */
((C_proc3)C_retrieve_symbol_proc(lf[19]))(3,*((C_word*)lf[19]+1),((C_word*)t0)[2],t1);}

/* k2095 in k2166 in smooth in setup-api#execute in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_2097(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2097,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2104,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 242  host-extension */
((C_proc2)C_retrieve_symbol_proc(lf[15]))(2,*((C_word*)lf[15]+1),t2);}

/* k2102 in k2095 in k2166 in smooth in setup-api#execute in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_2104(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?lf[97]:lf[98]);
/* setup-api.scm: 237  cons* */
((C_proc7)C_retrieve_symbol_proc(lf[99]))(7,*((C_word*)lf[99]+1),((C_word*)t0)[3],((C_word*)t0)[2],lf[100],lf[101],t2,C_SCHEME_END_OF_LIST);}

/* k2091 in k2166 in smooth in setup-api#execute in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_2093(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 236  string-intersperse */
((C_proc4)C_retrieve_symbol_proc(lf[93]))(4,*((C_word*)lf[93]+1),((C_word*)t0)[2],t1,lf[96]);}

/* k2177 in k2166 in smooth in setup-api#execute in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_2179(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2179,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
/* setup-api.scm: 258  string-intersperse */
((C_proc4)C_retrieve_symbol_proc(lf[93]))(4,*((C_word*)lf[93]+1),((C_word*)t0)[2],t3,lf[94]);}

/* setup-api#fixmaketarget in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_fcall f_2135(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2135,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2142,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2159,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 250  pathname-extension */
((C_proc3)C_retrieve_symbol_proc(lf[91]))(3,*((C_word*)lf[91]+1),t4,t2);}

/* k2157 in setup-api#fixmaketarget in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_2159(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep((C_word)C_i_equalp(lf[89],t1))){
t2=(C_word)C_i_string_equal_p(lf[90],C_retrieve(lf[88]));
t3=((C_word*)t0)[2];
f_2142(t3,(C_word)C_i_not(t2));}
else{
t2=((C_word*)t0)[2];
f_2142(t2,C_SCHEME_FALSE);}}

/* k2140 in setup-api#fixmaketarget in k2075 in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_fcall f_2142(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* setup-api.scm: 252  pathname-replace-extension */
((C_proc4)C_retrieve_symbol_proc(lf[87]))(4,*((C_word*)lf[87]+1),((C_word*)t0)[3],((C_word*)t0)[2],C_retrieve(lf[88]));}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* setup-api#patch in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_1987(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1987,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1991,a[2]=t1,a[3]=t4,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2070,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 215  setup-verbose-flag */
((C_proc2)C_retrieve_symbol_proc(lf[25]))(2,*((C_word*)lf[25]+1),t6);}

/* k2068 in setup-api#patch in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_2070(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* setup-api.scm: 215  printf */
((C_proc4)C_retrieve_symbol_proc(lf[56]))(4,*((C_word*)lf[56]+1),((C_word*)t0)[3],lf[84],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_1991(2,t2,C_SCHEME_UNDEFINED);}}

/* k1989 in setup-api#patch in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_1991(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1991,2,t0,t1);}
if(C_truep((C_word)C_i_listp(((C_word*)t0)[5]))){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2006,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word)li14),tmp=(C_word)a,a+=6,tmp);
/* setup-api.scm: 217  with-output-to-file */
((C_proc4)C_retrieve_symbol_proc(lf[81]))(4,*((C_word*)lf[81]+1),((C_word*)t0)[2],t2,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2045,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* setup-api.scm: 226  create-temporary-file */
((C_proc2)C_retrieve_symbol_proc(lf[83]))(2,*((C_word*)lf[83]+1),t2);}}

/* k2043 in k1989 in setup-api#patch in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_2045(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2045,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2048,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_a_i_list(&a,2,t1,t1);
/* setup-api.scm: 227  patch */
((C_proc5)C_retrieve_symbol_proc(lf[77]))(5,*((C_word*)lf[77]+1),t2,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2046 in k2043 in k1989 in setup-api#patch in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_2048(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2048,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2055,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2059,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 229  shellpath */
((C_proc3)C_retrieve_symbol_proc(lf[19]))(3,*((C_word*)lf[19]+1),t3,((C_word*)t0)[2]);}

/* k2057 in k2046 in k2043 in k1989 in setup-api#patch in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_2059(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2059,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2063,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 230  shellpath */
((C_proc3)C_retrieve_symbol_proc(lf[19]))(3,*((C_word*)lf[19]+1),t2,((C_word*)t0)[2]);}

/* k2061 in k2057 in k2046 in k2043 in k1989 in setup-api#patch in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_2063(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 229  sprintf */
((C_proc6)C_retrieve_symbol_proc(lf[59]))(6,*((C_word*)lf[59]+1),((C_word*)t0)[3],lf[82],C_retrieve2(lf[31],"setup-api#*move-command*"),((C_word*)t0)[2],t1);}

/* k2053 in k2046 in k2043 in k1989 in setup-api#patch in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_2055(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 228  $system */
f_4670(((C_word*)t0)[2],t1);}

/* a2005 in k1989 in setup-api#patch in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_2006(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2006,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2016,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word)li13),tmp=(C_word)a,a+=5,tmp);
/* setup-api.scm: 219  with-input-from-file */
((C_proc4)C_retrieve_symbol_proc(lf[80]))(4,*((C_word*)lf[80]+1),t1,t2,t3);}

/* a2015 in a2005 in k1989 in setup-api#patch in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_2016(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2016,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2022,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word)li12),tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_2022(t5,t1);}

/* loop in a2015 in a2005 in k1989 in setup-api#patch in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_fcall f_2022(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2022,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2026,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* setup-api.scm: 222  read-line */
((C_proc2)C_retrieve_symbol_proc(lf[70]))(2,*((C_word*)lf[70]+1),t2);}

/* k2024 in loop in a2015 in a2005 in k1989 in setup-api#patch in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_2026(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2026,2,t0,t1);}
if(C_truep((C_word)C_eofp(t1))){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2035,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2042,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 224  string-substitute */
((C_proc6)C_retrieve_symbol_proc(lf[79]))(6,*((C_word*)lf[79]+1),t3,((C_word*)t0)[3],((C_word*)t0)[2],t1,C_SCHEME_TRUE);}}

/* k2040 in k2024 in loop in a2015 in a2005 in k1989 in setup-api#patch in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_2042(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 224  write-line */
((C_proc3)C_retrieve_symbol_proc(lf[78]))(3,*((C_word*)lf[78]+1),((C_word*)t0)[2],t1);}

/* k2033 in k2024 in loop in a2015 in a2005 in k1989 in setup-api#patch in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_2035(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 225  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_2022(t2,((C_word*)t0)[2]);}

/* setup-api#yes-or-no? in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_1907(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_1907r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1907r(t0,t1,t2,t3);}}

static void C_ccall f_1907r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1911,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* ##sys#get-keyword */
((C_proc4)C_retrieve_symbol_proc(lf[74]))(4,*((C_word*)lf[74]+1),t4,lf[76],t3);}

/* k1909 in setup-api#yes-or-no? in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_1911(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1911,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1914,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1981,a[2]=((C_word)li10),tmp=(C_word)a,a+=3,tmp);
/* ##sys#get-keyword */
((C_proc5)C_retrieve_symbol_proc(lf[74]))(5,*((C_word*)lf[74]+1),t2,lf[75],((C_word*)t0)[2],t3);}

/* a1980 in k1909 in setup-api#yes-or-no? in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_1981(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1981,2,t0,t1);}
/* setup-api.scm: 199  abort-setup */
((C_proc2)C_retrieve_symbol_proc(lf[62]))(2,*((C_word*)lf[62]+1),t1);}

/* k1912 in k1909 in setup-api#yes-or-no? in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_1914(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1914,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1919,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t1,a[6]=((C_word)li9),tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_1919(t5,((C_word*)t0)[2]);}

/* loop in k1912 in k1909 in setup-api#yes-or-no? in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_fcall f_1919(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1919,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1923,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* setup-api.scm: 201  printf */
((C_proc4)C_retrieve_symbol_proc(lf[56]))(4,*((C_word*)lf[56]+1),t2,lf[73],((C_word*)t0)[2]);}

/* k1921 in loop in k1912 in k1909 in setup-api#yes-or-no? in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_1923(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1923,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1926,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[2])){
/* setup-api.scm: 202  printf */
((C_proc4)C_retrieve_symbol_proc(lf[56]))(4,*((C_word*)lf[56]+1),t2,lf[72],((C_word*)t0)[2]);}
else{
t3=t2;
f_1926(2,t3,C_SCHEME_UNDEFINED);}}

/* k1924 in k1921 in loop in k1912 in k1909 in setup-api#yes-or-no? in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_1926(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1926,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1929,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* setup-api.scm: 203  flush-output */
((C_proc2)C_retrieve_proc(*((C_word*)lf[71]+1)))(2,*((C_word*)lf[71]+1),t2);}

/* k1927 in k1924 in k1921 in loop in k1912 in k1909 in setup-api#yes-or-no? in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_1929(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1929,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1932,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* setup-api.scm: 204  read-line */
((C_proc2)C_retrieve_symbol_proc(lf[70]))(2,*((C_word*)lf[70]+1),t2);}

/* k1930 in k1927 in k1924 in k1921 in loop in k1912 in k1909 in setup-api#yes-or-no? in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_1932(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1932,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1935,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_eofp(((C_word*)t3)[1]))){
t5=C_set_block_item(t3,0,lf[68]);
t6=t4;
f_1935(t6,t5);}
else{
t5=(C_truep(((C_word*)t0)[2])?(C_word)C_i_string_equal_p(lf[69],((C_word*)t3)[1]):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=C_set_block_item(t3,0,((C_word*)t0)[2]);
t7=t4;
f_1935(t7,t6);}
else{
t6=t4;
f_1935(t6,C_SCHEME_UNDEFINED);}}}

/* k1933 in k1930 in k1927 in k1924 in k1921 in loop in k1912 in k1909 in setup-api#yes-or-no? in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_fcall f_1935(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1935,NULL,2,t0,t1);}
if(C_truep((C_word)C_i_string_ci_equal_p(lf[64],((C_word*)((C_word*)t0)[5])[1]))){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}
else{
if(C_truep((C_word)C_i_string_ci_equal_p(lf[65],((C_word*)((C_word*)t0)[5])[1]))){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_i_string_ci_equal_p(lf[66],((C_word*)((C_word*)t0)[5])[1]))){
/* setup-api.scm: 209  abort */
t2=((C_word*)t0)[3];
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1959,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 211  printf */
((C_proc3)C_retrieve_symbol_proc(lf[56]))(3,*((C_word*)lf[56]+1),t2,lf[67]);}}}}

/* k1957 in k1933 in k1930 in k1927 in k1924 in k1921 in loop in k1912 in k1909 in setup-api#yes-or-no? in k1903 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_1959(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 212  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_1919(t2,((C_word*)t0)[2]);}

/* f_4777 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_4777(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4777,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4781,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 194  verb */
f_1888(t3,t2);}

/* k4779 */
static void C_ccall f_4781(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4781,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4788,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4792,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 195  shellpath */
((C_proc3)C_retrieve_symbol_proc(lf[19]))(3,*((C_word*)lf[19]+1),t3,((C_word*)t0)[2]);}

/* k4790 in k4779 */
static void C_ccall f_4792(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 195  sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[59]))(4,*((C_word*)lf[59]+1),((C_word*)t0)[2],lf[60],t1);}

/* k4786 in k4779 */
static void C_ccall f_4788(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 195  $system */
f_4670(((C_word*)t0)[2],t1);}

/* f_4769 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_4769(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4769,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4773,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* setup-api.scm: 191  verb */
f_1888(t3,t2);}

/* k4771 */
static void C_ccall f_4773(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 192  create-directory-0 */
t2=((C_word*)((C_word*)t0)[4])[1];
f_1856(t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* verb in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_fcall f_1888(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1888,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1895,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 188  setup-verbose-flag */
((C_proc2)C_retrieve_symbol_proc(lf[25]))(2,*((C_word*)lf[25]+1),t3);}

/* k1893 in verb in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_1895(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* setup-api.scm: 188  printf */
((C_proc4)C_retrieve_symbol_proc(lf[56]))(4,*((C_word*)lf[56]+1),((C_word*)t0)[3],lf[57],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* create-directory-0 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_fcall f_1856(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1856,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1862,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=((C_word)li4),tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_1862(t6,t1,t2);}

/* loop in create-directory-0 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_fcall f_1862(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1862,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1869,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1886,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 184  directory? */
((C_proc3)C_retrieve_symbol_proc(lf[55]))(3,*((C_word*)lf[55]+1),t4,t2);}
else{
t4=t3;
f_1869(t4,C_SCHEME_FALSE);}}

/* k1884 in loop in create-directory-0 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_1886(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_1869(t2,(C_word)C_i_not(t1));}

/* k1867 in loop in create-directory-0 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_fcall f_1869(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1869,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1872,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1879,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 185  pathname-directory */
((C_proc3)C_retrieve_symbol_proc(lf[54]))(3,*((C_word*)lf[54]+1),t3,((C_word*)t0)[3]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k1877 in k1867 in loop in create-directory-0 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_1879(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 185  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_1862(t2,((C_word*)t0)[2],t1);}

/* k1870 in k1867 in loop in create-directory-0 in k1851 in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_1872(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 186  create-directory */
t2=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* setup-api#sudo-install in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_1831(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2rv,(void*)f_1831r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_1831r(t0,t1,t2);}}

static void C_ccall f_1831r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
if(C_truep((C_word)C_vemptyp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_retrieve2(lf[12],"setup-api#*sudo*"));}
else{
if(C_truep((C_word)C_i_vector_ref(t2,C_fix(0)))){
t3=t1;
t4=lf[12] /* setup-api#*sudo* */ =C_SCHEME_TRUE;;
if(C_truep(C_retrieve2(lf[13],"setup-api#*windows-shell*"))){
t5=lf[12] /* setup-api#*sudo* */ =C_SCHEME_FALSE;;
/* setup-api.scm: 148  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[46]+1)))(3,*((C_word*)lf[46]+1),t3,lf[47]);}
else{
t5=C_mutate(&lf[29] /* (set! setup-api#*copy-command* ...) */,lf[48]);
t6=C_mutate(&lf[30] /* (set! setup-api#*remove-command* ...) */,lf[49]);
t7=C_mutate(&lf[31] /* (set! setup-api#*move-command* ...) */,lf[50]);
t8=C_mutate(&lf[32] /* (set! setup-api#*chmod-command* ...) */,lf[51]);
t9=C_mutate(&lf[33] /* (set! setup-api#*ranlib-command* ...) */,lf[52]);
t10=t3;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,t9);}}
else{
/* setup-api.scm: 172  user-install-setup */
f_1805(t1);}}}

/* setup-api#user-install-setup in k1765 in k1761 in k1757 in k1753 in k1749 in k1745 in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_fcall f_1805(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1805,NULL,1,t1);}
t2=lf[12] /* setup-api#*sudo* */ =C_SCHEME_FALSE;;
if(C_truep(C_retrieve2(lf[13],"setup-api#*windows-shell*"))){
t3=t1;
t4=C_mutate(&lf[29] /* (set! setup-api#*copy-command* ...) */,lf[35]);
t5=C_mutate(&lf[30] /* (set! setup-api#*remove-command* ...) */,lf[36]);
t6=C_mutate(&lf[31] /* (set! setup-api#*move-command* ...) */,lf[37]);
t7=C_mutate(&lf[32] /* (set! setup-api#*chmod-command* ...) */,lf[38]);
t8=C_mutate(&lf[33] /* (set! setup-api#*ranlib-command* ...) */,lf[39]);
t9=t3;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}
else{
t3=t1;
t4=C_mutate(&lf[29] /* (set! setup-api#*copy-command* ...) */,lf[40]);
t5=C_mutate(&lf[30] /* (set! setup-api#*remove-command* ...) */,lf[41]);
t6=C_mutate(&lf[31] /* (set! setup-api#*move-command* ...) */,lf[42]);
t7=C_mutate(&lf[32] /* (set! setup-api#*chmod-command* ...) */,lf[43]);
t8=C_mutate(&lf[33] /* (set! setup-api#*ranlib-command* ...) */,lf[44]);
t9=t3;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}}

/* setup-api#cross-chicken in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_1738(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1738,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_fudge(C_fix(39)));}

/* setup-api#shellpath in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_1728(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1728,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1736,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 111  normalize-pathname */
((C_proc3)C_retrieve_symbol_proc(lf[21]))(3,*((C_word*)lf[21]+1),t3,t2);}

/* k1734 in setup-api#shellpath in k1724 in k1721 in k1717 in k1714 in k1711 in k1707 in k1704 in k1701 in k1697 in k1693 in k1690 in k1684 in k1680 in k1676 in k1672 in k1668 in k4857 in k4861 in k4865 in k4869 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 */
static void C_ccall f_1736(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 111  qs */
((C_proc3)C_retrieve_symbol_proc(lf[20]))(3,*((C_word*)lf[20]+1),((C_word*)t0)[2],t1);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[408] = {
{"toplevel:setup_api_scm",(void*)C_toplevel},
{"f_1619:setup_api_scm",(void*)f_1619},
{"f_1622:setup_api_scm",(void*)f_1622},
{"f_1625:setup_api_scm",(void*)f_1625},
{"f_1628:setup_api_scm",(void*)f_1628},
{"f_1631:setup_api_scm",(void*)f_1631},
{"f_1634:setup_api_scm",(void*)f_1634},
{"f_1637:setup_api_scm",(void*)f_1637},
{"f_1640:setup_api_scm",(void*)f_1640},
{"f_1643:setup_api_scm",(void*)f_1643},
{"f_1646:setup_api_scm",(void*)f_1646},
{"f_1649:setup_api_scm",(void*)f_1649},
{"f_1652:setup_api_scm",(void*)f_1652},
{"f_1655:setup_api_scm",(void*)f_1655},
{"f_1658:setup_api_scm",(void*)f_1658},
{"f_1661:setup_api_scm",(void*)f_1661},
{"f_4871:setup_api_scm",(void*)f_4871},
{"f_4867:setup_api_scm",(void*)f_4867},
{"f_4863:setup_api_scm",(void*)f_4863},
{"f_4859:setup_api_scm",(void*)f_4859},
{"f_1670:setup_api_scm",(void*)f_1670},
{"f_1674:setup_api_scm",(void*)f_1674},
{"f_1678:setup_api_scm",(void*)f_1678},
{"f_1682:setup_api_scm",(void*)f_1682},
{"f_1686:setup_api_scm",(void*)f_1686},
{"f_4827:setup_api_scm",(void*)f_4827},
{"f_1692:setup_api_scm",(void*)f_1692},
{"f_1695:setup_api_scm",(void*)f_1695},
{"f_1699:setup_api_scm",(void*)f_1699},
{"f_1703:setup_api_scm",(void*)f_1703},
{"f_1706:setup_api_scm",(void*)f_1706},
{"f_1709:setup_api_scm",(void*)f_1709},
{"f_1713:setup_api_scm",(void*)f_1713},
{"f_1716:setup_api_scm",(void*)f_1716},
{"f_4808:setup_api_scm",(void*)f_4808},
{"f_1719:setup_api_scm",(void*)f_1719},
{"f_1723:setup_api_scm",(void*)f_1723},
{"f_4795:setup_api_scm",(void*)f_4795},
{"f_1726:setup_api_scm",(void*)f_1726},
{"f_1747:setup_api_scm",(void*)f_1747},
{"f_1751:setup_api_scm",(void*)f_1751},
{"f_1755:setup_api_scm",(void*)f_1755},
{"f_1759:setup_api_scm",(void*)f_1759},
{"f_1763:setup_api_scm",(void*)f_1763},
{"f_1767:setup_api_scm",(void*)f_1767},
{"f_1853:setup_api_scm",(void*)f_1853},
{"f_1905:setup_api_scm",(void*)f_1905},
{"f_2077:setup_api_scm",(void*)f_2077},
{"f_4765:setup_api_scm",(void*)f_4765},
{"f_2831:setup_api_scm",(void*)f_2831},
{"f_4692:setup_api_scm",(void*)f_4692},
{"f_4708:setup_api_scm",(void*)f_4708},
{"f_4745:setup_api_scm",(void*)f_4745},
{"f_4738:setup_api_scm",(void*)f_4738},
{"f_4742:setup_api_scm",(void*)f_4742},
{"f_4715:setup_api_scm",(void*)f_4715},
{"f_4416:setup_api_scm",(void*)f_4416},
{"f_4670:setup_api_scm",(void*)f_4670},
{"f_4687:setup_api_scm",(void*)f_4687},
{"f_4674:setup_api_scm",(void*)f_4674},
{"f_4639:setup_api_scm",(void*)f_4639},
{"f_4668:setup_api_scm",(void*)f_4668},
{"f_4646:setup_api_scm",(void*)f_4646},
{"f_4657:setup_api_scm",(void*)f_4657},
{"f_4653:setup_api_scm",(void*)f_4653},
{"f_4539:setup_api_scm",(void*)f_4539},
{"f_4543:setup_api_scm",(void*)f_4543},
{"f_4618:setup_api_scm",(void*)f_4618},
{"f_4574:setup_api_scm",(void*)f_4574},
{"f_4578:setup_api_scm",(void*)f_4578},
{"f_4586:setup_api_scm",(void*)f_4586},
{"f_4599:setup_api_scm",(void*)f_4599},
{"f_4605:setup_api_scm",(void*)f_4605},
{"f_4581:setup_api_scm",(void*)f_4581},
{"f_4569:setup_api_scm",(void*)f_4569},
{"f_4565:setup_api_scm",(void*)f_4565},
{"f_4486:setup_api_scm",(void*)f_4486},
{"f_4490:setup_api_scm",(void*)f_4490},
{"f_4528:setup_api_scm",(void*)f_4528},
{"f_4534:setup_api_scm",(void*)f_4534},
{"f_4493:setup_api_scm",(void*)f_4493},
{"f_4498:setup_api_scm",(void*)f_4498},
{"f_4525:setup_api_scm",(void*)f_4525},
{"f_4521:setup_api_scm",(void*)f_4521},
{"f_4505:setup_api_scm",(void*)f_4505},
{"f_4511:setup_api_scm",(void*)f_4511},
{"f_4517:setup_api_scm",(void*)f_4517},
{"f_4472:setup_api_scm",(void*)f_4472},
{"f_4484:setup_api_scm",(void*)f_4484},
{"f_4480:setup_api_scm",(void*)f_4480},
{"f_4428:setup_api_scm",(void*)f_4428},
{"f_4432:setup_api_scm",(void*)f_4432},
{"f_4451:setup_api_scm",(void*)f_4451},
{"f_4441:setup_api_scm",(void*)f_4441},
{"f_4418:setup_api_scm",(void*)f_4418},
{"f_4426:setup_api_scm",(void*)f_4426},
{"f_4239:setup_api_scm",(void*)f_4239},
{"f_4266:setup_api_scm",(void*)f_4266},
{"f_4270:setup_api_scm",(void*)f_4270},
{"f_4272:setup_api_scm",(void*)f_4272},
{"f_4385:setup_api_scm",(void*)f_4385},
{"f_4375:setup_api_scm",(void*)f_4375},
{"f_4356:setup_api_scm",(void*)f_4356},
{"f_4332:setup_api_scm",(void*)f_4332},
{"f_4300:setup_api_scm",(void*)f_4300},
{"f_4242:setup_api_scm",(void*)f_4242},
{"f_4259:setup_api_scm",(void*)f_4259},
{"f_4248:setup_api_scm",(void*)f_4248},
{"f_4252:setup_api_scm",(void*)f_4252},
{"f_4229:setup_api_scm",(void*)f_4229},
{"f_4237:setup_api_scm",(void*)f_4237},
{"f_4215:setup_api_scm",(void*)f_4215},
{"f_4223:setup_api_scm",(void*)f_4223},
{"f_4227:setup_api_scm",(void*)f_4227},
{"f_4117:setup_api_scm",(void*)f_4117},
{"f_4123:setup_api_scm",(void*)f_4123},
{"f_4136:setup_api_scm",(void*)f_4136},
{"f_4148:setup_api_scm",(void*)f_4148},
{"f_4151:setup_api_scm",(void*)f_4151},
{"f_4157:setup_api_scm",(void*)f_4157},
{"f_4186:setup_api_scm",(void*)f_4186},
{"f_4172:setup_api_scm",(void*)f_4172},
{"f_4179:setup_api_scm",(void*)f_4179},
{"f_4107:setup_api_scm",(void*)f_4107},
{"f_4115:setup_api_scm",(void*)f_4115},
{"f_4083:setup_api_scm",(void*)f_4083},
{"f_4101:setup_api_scm",(void*)f_4101},
{"f_4105:setup_api_scm",(void*)f_4105},
{"f_4090:setup_api_scm",(void*)f_4090},
{"f_4097:setup_api_scm",(void*)f_4097},
{"f_3971:setup_api_scm",(void*)f_3971},
{"f_3975:setup_api_scm",(void*)f_3975},
{"f_4077:setup_api_scm",(void*)f_4077},
{"f_3978:setup_api_scm",(void*)f_3978},
{"f_4074:setup_api_scm",(void*)f_4074},
{"f_3981:setup_api_scm",(void*)f_3981},
{"f_4071:setup_api_scm",(void*)f_4071},
{"f_3984:setup_api_scm",(void*)f_3984},
{"f_4065:setup_api_scm",(void*)f_4065},
{"f_3987:setup_api_scm",(void*)f_3987},
{"f_4062:setup_api_scm",(void*)f_4062},
{"f_3990:setup_api_scm",(void*)f_3990},
{"f_3993:setup_api_scm",(void*)f_3993},
{"f_3996:setup_api_scm",(void*)f_3996},
{"f_4056:setup_api_scm",(void*)f_4056},
{"f_3999:setup_api_scm",(void*)f_3999},
{"f_4047:setup_api_scm",(void*)f_4047},
{"f_4033:setup_api_scm",(void*)f_4033},
{"f_4036:setup_api_scm",(void*)f_4036},
{"f_4002:setup_api_scm",(void*)f_4002},
{"f_4005:setup_api_scm",(void*)f_4005},
{"f_4019:setup_api_scm",(void*)f_4019},
{"f_4015:setup_api_scm",(void*)f_4015},
{"f_4008:setup_api_scm",(void*)f_4008},
{"f_3918:setup_api_scm",(void*)f_3918},
{"f_3922:setup_api_scm",(void*)f_3922},
{"f_3931:setup_api_scm",(void*)f_3931},
{"f_3943:setup_api_scm",(void*)f_3943},
{"f_3969:setup_api_scm",(void*)f_3969},
{"f_3937:setup_api_scm",(void*)f_3937},
{"f_3867:setup_api_scm",(void*)f_3867},
{"f_3871:setup_api_scm",(void*)f_3871},
{"f_3880:setup_api_scm",(void*)f_3880},
{"f_3887:setup_api_scm",(void*)f_3887},
{"f_3891:setup_api_scm",(void*)f_3891},
{"f_3874:setup_api_scm",(void*)f_3874},
{"f_3877:setup_api_scm",(void*)f_3877},
{"f_3731:setup_api_scm",(void*)f_3731},
{"f_3735:setup_api_scm",(void*)f_3735},
{"f_3741:setup_api_scm",(void*)f_3741},
{"f_3744:setup_api_scm",(void*)f_3744},
{"f_3747:setup_api_scm",(void*)f_3747},
{"f_3833:setup_api_scm",(void*)f_3833},
{"f_3750:setup_api_scm",(void*)f_3750},
{"f_3784:setup_api_scm",(void*)f_3784},
{"f_3791:setup_api_scm",(void*)f_3791},
{"f_3794:setup_api_scm",(void*)f_3794},
{"f_3820:setup_api_scm",(void*)f_3820},
{"f_3797:setup_api_scm",(void*)f_3797},
{"f_3753:setup_api_scm",(void*)f_3753},
{"f_3782:setup_api_scm",(void*)f_3782},
{"f_3756:setup_api_scm",(void*)f_3756},
{"f_3574:setup_api_scm",(void*)f_3574},
{"f_3578:setup_api_scm",(void*)f_3578},
{"f_3594:setup_api_scm",(void*)f_3594},
{"f_3597:setup_api_scm",(void*)f_3597},
{"f_3600:setup_api_scm",(void*)f_3600},
{"f_3697:setup_api_scm",(void*)f_3697},
{"f_3603:setup_api_scm",(void*)f_3603},
{"f_3661:setup_api_scm",(void*)f_3661},
{"f_3675:setup_api_scm",(void*)f_3675},
{"f_3679:setup_api_scm",(void*)f_3679},
{"f_3606:setup_api_scm",(void*)f_3606},
{"f_3614:setup_api_scm",(void*)f_3614},
{"f_3621:setup_api_scm",(void*)f_3621},
{"f_3624:setup_api_scm",(void*)f_3624},
{"f_3650:setup_api_scm",(void*)f_3650},
{"f_3627:setup_api_scm",(void*)f_3627},
{"f_3609:setup_api_scm",(void*)f_3609},
{"f_3580:setup_api_scm",(void*)f_3580},
{"f_3253:setup_api_scm",(void*)f_3253},
{"f_3260:setup_api_scm",(void*)f_3260},
{"f_3263:setup_api_scm",(void*)f_3263},
{"f_3302:setup_api_scm",(void*)f_3302},
{"f_3306:setup_api_scm",(void*)f_3306},
{"f_3312:setup_api_scm",(void*)f_3312},
{"f_3315:setup_api_scm",(void*)f_3315},
{"f_3318:setup_api_scm",(void*)f_3318},
{"f_3321:setup_api_scm",(void*)f_3321},
{"f_3408:setup_api_scm",(void*)f_3408},
{"f_3415:setup_api_scm",(void*)f_3415},
{"f_3537:setup_api_scm",(void*)f_3537},
{"f_3508:setup_api_scm",(void*)f_3508},
{"f_3527:setup_api_scm",(void*)f_3527},
{"f_3418:setup_api_scm",(void*)f_3418},
{"f_3421:setup_api_scm",(void*)f_3421},
{"f_3505:setup_api_scm",(void*)f_3505},
{"f_3424:setup_api_scm",(void*)f_3424},
{"f_3482:setup_api_scm",(void*)f_3482},
{"f_3474:setup_api_scm",(void*)f_3474},
{"f_3439:setup_api_scm",(void*)f_3439},
{"f_3458:setup_api_scm",(void*)f_3458},
{"f_3430:setup_api_scm",(void*)f_3430},
{"f_3324:setup_api_scm",(void*)f_3324},
{"f_3386:setup_api_scm",(void*)f_3386},
{"f_3394:setup_api_scm",(void*)f_3394},
{"f_3402:setup_api_scm",(void*)f_3402},
{"f_3389:setup_api_scm",(void*)f_3389},
{"f_3330:setup_api_scm",(void*)f_3330},
{"f_3342:setup_api_scm",(void*)f_3342},
{"f_3350:setup_api_scm",(void*)f_3350},
{"f_3354:setup_api_scm",(void*)f_3354},
{"f_3357:setup_api_scm",(void*)f_3357},
{"f_3345:setup_api_scm",(void*)f_3345},
{"f_3336:setup_api_scm",(void*)f_3336},
{"f_3199:setup_api_scm",(void*)f_3199},
{"f_3205:setup_api_scm",(void*)f_3205},
{"f_3218:setup_api_scm",(void*)f_3218},
{"f_3221:setup_api_scm",(void*)f_3221},
{"f_3174:setup_api_scm",(void*)f_3174},
{"f_3194:setup_api_scm",(void*)f_3194},
{"f_3152:setup_api_scm",(void*)f_3152},
{"f_3172:setup_api_scm",(void*)f_3172},
{"f_3097:setup_api_scm",(void*)f_3097},
{"f_3104:setup_api_scm",(void*)f_3104},
{"f_3107:setup_api_scm",(void*)f_3107},
{"f_3126:setup_api_scm",(void*)f_3126},
{"f_3134:setup_api_scm",(void*)f_3134},
{"f_2947:setup_api_scm",(void*)f_2947},
{"f_3049:setup_api_scm",(void*)f_3049},
{"f_3040:setup_api_scm",(void*)f_3040},
{"f_3048:setup_api_scm",(void*)f_3048},
{"f_2949:setup_api_scm",(void*)f_2949},
{"f_2956:setup_api_scm",(void*)f_2956},
{"f_3023:setup_api_scm",(void*)f_3023},
{"f_3013:setup_api_scm",(void*)f_3013},
{"f_2959:setup_api_scm",(void*)f_2959},
{"f_2962:setup_api_scm",(void*)f_2962},
{"f_2968:setup_api_scm",(void*)f_2968},
{"f_2971:setup_api_scm",(void*)f_2971},
{"f_2990:setup_api_scm",(void*)f_2990},
{"f_2998:setup_api_scm",(void*)f_2998},
{"f_2974:setup_api_scm",(void*)f_2974},
{"f_2833:setup_api_scm",(void*)f_2833},
{"f_2945:setup_api_scm",(void*)f_2945},
{"f_2941:setup_api_scm",(void*)f_2941},
{"f_2930:setup_api_scm",(void*)f_2930},
{"f_2840:setup_api_scm",(void*)f_2840},
{"f_2843:setup_api_scm",(void*)f_2843},
{"f_2927:setup_api_scm",(void*)f_2927},
{"f_2802:setup_api_scm",(void*)f_2802},
{"f_2846:setup_api_scm",(void*)f_2846},
{"f_2919:setup_api_scm",(void*)f_2919},
{"f_2878:setup_api_scm",(void*)f_2878},
{"f_2910:setup_api_scm",(void*)f_2910},
{"f_2881:setup_api_scm",(void*)f_2881},
{"f_2900:setup_api_scm",(void*)f_2900},
{"f_2908:setup_api_scm",(void*)f_2908},
{"f_2849:setup_api_scm",(void*)f_2849},
{"f_2875:setup_api_scm",(void*)f_2875},
{"f_2755:setup_api_scm",(void*)f_2755},
{"f_2787:setup_api_scm",(void*)f_2787},
{"f_2465:setup_api_scm",(void*)f_2465},
{"f_2753:setup_api_scm",(void*)f_2753},
{"f_2469:setup_api_scm",(void*)f_2469},
{"f_2297:setup_api_scm",(void*)f_2297},
{"f_2306:setup_api_scm",(void*)f_2306},
{"f_2311:setup_api_scm",(void*)f_2311},
{"f_2318:setup_api_scm",(void*)f_2318},
{"f_2321:setup_api_scm",(void*)f_2321},
{"f_2330:setup_api_scm",(void*)f_2330},
{"f_2333:setup_api_scm",(void*)f_2333},
{"f_2372:setup_api_scm",(void*)f_2372},
{"f_2380:setup_api_scm",(void*)f_2380},
{"f_2342:setup_api_scm",(void*)f_2342},
{"f_2472:setup_api_scm",(void*)f_2472},
{"f_2457:setup_api_scm",(void*)f_2457},
{"f_2475:setup_api_scm",(void*)f_2475},
{"f_2480:setup_api_scm",(void*)f_2480},
{"f_2484:setup_api_scm",(void*)f_2484},
{"f_2742:setup_api_scm",(void*)f_2742},
{"f_2737:setup_api_scm",(void*)f_2737},
{"f_2699:setup_api_scm",(void*)f_2699},
{"f_2705:setup_api_scm",(void*)f_2705},
{"f_2718:setup_api_scm",(void*)f_2718},
{"f_2710:setup_api_scm",(void*)f_2710},
{"f_2486:setup_api_scm",(void*)f_2486},
{"f_2222:setup_api_scm",(void*)f_2222},
{"f_2235:setup_api_scm",(void*)f_2235},
{"f_2241:setup_api_scm",(void*)f_2241},
{"f_2213:setup_api_scm",(void*)f_2213},
{"f_2490:setup_api_scm",(void*)f_2490},
{"f_2493:setup_api_scm",(void*)f_2493},
{"f_2693:setup_api_scm",(void*)f_2693},
{"f_2496:setup_api_scm",(void*)f_2496},
{"f_2687:setup_api_scm",(void*)f_2687},
{"f_2499:setup_api_scm",(void*)f_2499},
{"f_2684:setup_api_scm",(void*)f_2684},
{"f_2669:setup_api_scm",(void*)f_2669},
{"f_2670:setup_api_scm",(void*)f_2670},
{"f_2508:setup_api_scm",(void*)f_2508},
{"f_2638:setup_api_scm",(void*)f_2638},
{"f_2642:setup_api_scm",(void*)f_2642},
{"f_2658:setup_api_scm",(void*)f_2658},
{"f_2665:setup_api_scm",(void*)f_2665},
{"f_2645:setup_api_scm",(void*)f_2645},
{"f_2655:setup_api_scm",(void*)f_2655},
{"f_2514:setup_api_scm",(void*)f_2514},
{"f_2604:setup_api_scm",(void*)f_2604},
{"f_2633:setup_api_scm",(void*)f_2633},
{"f_2611:setup_api_scm",(void*)f_2611},
{"f_2533:setup_api_scm",(void*)f_2533},
{"f_2541:setup_api_scm",(void*)f_2541},
{"f_2576:setup_api_scm",(void*)f_2576},
{"f_2591:setup_api_scm",(void*)f_2591},
{"f_2597:setup_api_scm",(void*)f_2597},
{"f_2582:setup_api_scm",(void*)f_2582},
{"f_2547:setup_api_scm",(void*)f_2547},
{"f_2553:setup_api_scm",(void*)f_2553},
{"f_2571:setup_api_scm",(void*)f_2571},
{"f_2568:setup_api_scm",(void*)f_2568},
{"f_2557:setup_api_scm",(void*)f_2557},
{"f_2539:setup_api_scm",(void*)f_2539},
{"f_2277:setup_api_scm",(void*)f_2277},
{"f_2285:setup_api_scm",(void*)f_2285},
{"f_2267:setup_api_scm",(void*)f_2267},
{"f_2275:setup_api_scm",(void*)f_2275},
{"f_2161:setup_api_scm",(void*)f_2161},
{"f_2209:setup_api_scm",(void*)f_2209},
{"f_2192:setup_api_scm",(void*)f_2192},
{"f_2202:setup_api_scm",(void*)f_2202},
{"f_2196:setup_api_scm",(void*)f_2196},
{"f_2164:setup_api_scm",(void*)f_2164},
{"f_2168:setup_api_scm",(void*)f_2168},
{"f_2129:setup_api_scm",(void*)f_2129},
{"f_2108:setup_api_scm",(void*)f_2108},
{"f_2097:setup_api_scm",(void*)f_2097},
{"f_2104:setup_api_scm",(void*)f_2104},
{"f_2093:setup_api_scm",(void*)f_2093},
{"f_2179:setup_api_scm",(void*)f_2179},
{"f_2135:setup_api_scm",(void*)f_2135},
{"f_2159:setup_api_scm",(void*)f_2159},
{"f_2142:setup_api_scm",(void*)f_2142},
{"f_1987:setup_api_scm",(void*)f_1987},
{"f_2070:setup_api_scm",(void*)f_2070},
{"f_1991:setup_api_scm",(void*)f_1991},
{"f_2045:setup_api_scm",(void*)f_2045},
{"f_2048:setup_api_scm",(void*)f_2048},
{"f_2059:setup_api_scm",(void*)f_2059},
{"f_2063:setup_api_scm",(void*)f_2063},
{"f_2055:setup_api_scm",(void*)f_2055},
{"f_2006:setup_api_scm",(void*)f_2006},
{"f_2016:setup_api_scm",(void*)f_2016},
{"f_2022:setup_api_scm",(void*)f_2022},
{"f_2026:setup_api_scm",(void*)f_2026},
{"f_2042:setup_api_scm",(void*)f_2042},
{"f_2035:setup_api_scm",(void*)f_2035},
{"f_1907:setup_api_scm",(void*)f_1907},
{"f_1911:setup_api_scm",(void*)f_1911},
{"f_1981:setup_api_scm",(void*)f_1981},
{"f_1914:setup_api_scm",(void*)f_1914},
{"f_1919:setup_api_scm",(void*)f_1919},
{"f_1923:setup_api_scm",(void*)f_1923},
{"f_1926:setup_api_scm",(void*)f_1926},
{"f_1929:setup_api_scm",(void*)f_1929},
{"f_1932:setup_api_scm",(void*)f_1932},
{"f_1935:setup_api_scm",(void*)f_1935},
{"f_1959:setup_api_scm",(void*)f_1959},
{"f_4777:setup_api_scm",(void*)f_4777},
{"f_4781:setup_api_scm",(void*)f_4781},
{"f_4792:setup_api_scm",(void*)f_4792},
{"f_4788:setup_api_scm",(void*)f_4788},
{"f_4769:setup_api_scm",(void*)f_4769},
{"f_4773:setup_api_scm",(void*)f_4773},
{"f_1888:setup_api_scm",(void*)f_1888},
{"f_1895:setup_api_scm",(void*)f_1895},
{"f_1856:setup_api_scm",(void*)f_1856},
{"f_1862:setup_api_scm",(void*)f_1862},
{"f_1886:setup_api_scm",(void*)f_1886},
{"f_1869:setup_api_scm",(void*)f_1869},
{"f_1879:setup_api_scm",(void*)f_1879},
{"f_1872:setup_api_scm",(void*)f_1872},
{"f_1831:setup_api_scm",(void*)f_1831},
{"f_1805:setup_api_scm",(void*)f_1805},
{"f_1738:setup_api_scm",(void*)f_1738},
{"f_1728:setup_api_scm",(void*)f_1728},
{"f_1736:setup_api_scm",(void*)f_1736},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
