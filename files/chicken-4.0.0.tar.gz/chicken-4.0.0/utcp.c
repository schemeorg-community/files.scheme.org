/* Generated from tcp.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2009-03-24 10:47
   Version 4.0.0 - SVN rev. 13887
   windows-mingw32-x86 [ manyargs dload ptables applyhook ]
   compiled 2009-03-24 on LENOVO-1 (MINGW32_NT-6.0)
   command line: tcp.scm -no-trace -optimize-level 2 -include-path . -include-path ./ -feature debugbuild -explicit-use -unsafe -no-lambda-info -output-file utcp.c
   unit: tcp
*/

#include "chicken.h"

#include <errno.h>
#ifdef _WIN32
# if _MSC_VER > 1300
# include <winsock2.h>
# include <ws2tcpip.h>
# else
# include <winsock.h>
# endif
/* Beware: winsock2.h must come BEFORE windows.h */
# define socklen_t       int
static WSADATA wsa;
# define fcntl(a, b, c)  0
# define EWOULDBLOCK     0
# define EINPROGRESS     0
# define typecorrect_getsockopt(socket, level, optname, optval, optlen)	\
    getsockopt(socket, level, optname, (char *)optval, optlen)
#else
# include <fcntl.h>
# include <sys/types.h>
# include <sys/socket.h>
# include <sys/time.h>
# include <netinet/in.h>
# include <unistd.h>
# include <netdb.h>
# include <signal.h>
# define closesocket     close
# define INVALID_SOCKET  -1
# define typecorrect_getsockopt getsockopt
#endif

#ifndef SD_RECEIVE
# define SD_RECEIVE      0
# define SD_SEND         1
#endif

#ifdef ECOS
#include <sys/sockio.h>
#endif

static char addr_buffer[ 20 ];

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_scheduler_toplevel)
C_externimport void C_ccall C_scheduler_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[95];
static double C_possibly_force_alignment;


/* from general-strerror */
static C_word C_fcall stub724(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub724(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_mpointer(&C_a,(void*)strerror(t0));
return C_r;}

/* from get-socket-error */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub718(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub718(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int socket=(int )C_unfix(C_a0);
int err, optlen;optlen = sizeof(err);if (typecorrect_getsockopt(socket, SOL_SOCKET, SO_ERROR, &err, (socklen_t *)&optlen) == -1)return(-1);return(err);
C_ret:
#undef return

return C_r;}

/* from f_1248 in k1177 in k1171 in a1279 in body322 in tcp-listen in k1025 in k941 in k938 in k935 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub289(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub289(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int socket=(int )C_unfix(C_a0);
int yes = 1; 
                      return(setsockopt(socket, SOL_SOCKET, SO_REUSEADDR, (const char *)&yes, sizeof(int)));
C_ret:
#undef return

return C_r;}

/* from k1162 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub254(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub254(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * saddr=(void * )C_data_pointer_or_null(C_a0);
unsigned short port=(unsigned short )(unsigned short)C_unfix(C_a1);
struct sockaddr_in *addr = (struct sockaddr_in *)saddr;memset(addr, 0, sizeof(struct sockaddr_in));addr->sin_family = AF_INET;addr->sin_port = htons(port);addr->sin_addr.s_addr = htonl(INADDR_ANY);
C_ret:
#undef return

return C_r;}

/* from k1059 in ##net#gethostaddr in k1025 in k941 in k938 in k935 */
#define return(x) C_cblock C_r = (C_mk_bool((x))); goto C_ret; C_cblockend
static C_word C_fcall stub204(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub204(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * saddr=(void * )C_data_pointer_or_null(C_a0);
char * host=(char * )C_string_or_null(C_a1);
unsigned short port=(unsigned short )(unsigned short)C_unfix(C_a2);
struct hostent *he = gethostbyname(host);struct sockaddr_in *addr = (struct sockaddr_in *)saddr;if(he == NULL) return(0);memset(addr, 0, sizeof(struct sockaddr_in));addr->sin_family = AF_INET;addr->sin_port = htons((short)port);addr->sin_addr = *((struct in_addr *)he->h_addr);return(1);
C_ret:
#undef return

return C_r;}

/* from ##net#select-write */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub196(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub196(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int fd=(int )C_unfix(C_a0);
fd_set out;
     struct timeval tm;
     int rv;
     FD_ZERO(&out);
     FD_SET(fd, &out);
     tm.tv_sec = tm.tv_usec = 0;
     rv = select(fd + 1, NULL, &out, NULL, &tm);
     if(rv > 0) { rv = FD_ISSET(fd, &out) ? 1 : 0; }
     return(rv);
C_ret:
#undef return

return C_r;}

/* from ##net#select in k1025 in k941 in k938 in k935 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub190(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub190(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int fd=(int )C_unfix(C_a0);
fd_set in;
     struct timeval tm;
     int rv;
     FD_ZERO(&in);
     FD_SET(fd, &in);
     tm.tv_sec = tm.tv_usec = 0;
     rv = select(fd + 1, &in, NULL, NULL, &tm);
     if(rv > 0) { rv = FD_ISSET(fd, &in) ? 1 : 0; }
     return(rv);
C_ret:
#undef return

return C_r;}

/* from k1036 in k1032 in k1121 in k1117 in loop in a2429 in k2218 in tcp-connect in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub177(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub177(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
char * serv=(char * )C_string_or_null(C_a0);
char * proto=(char * )C_string_or_null(C_a1);
struct servent *se;
     if((se = getservbyname(serv, proto)) == NULL) return(0);
     else return(ntohs(se->s_port));
C_ret:
#undef return

return C_r;}

/* from ##net#startup */
#define return(x) C_cblock C_r = (C_mk_bool((x))); goto C_ret; C_cblockend
static C_word C_fcall stub168(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub168(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
#ifdef _WIN32
     return(WSAStartup(MAKEWORD(1, 1), &wsa) == 0);
#else
     signal(SIGPIPE, SIG_IGN);
     return(1);
#endif
C_ret:
#undef return

return C_r;}

/* from ##net#getpeername */
#define return(x) C_cblock C_r = (C_mpointer(&C_a,(void*)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub161(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub161(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int s=(int )C_unfix(C_a0);
struct sockaddr_in sa;unsigned char *ptr;unsigned int len = sizeof(struct sockaddr_in);if(getpeername(s, (struct sockaddr *)&sa, ((unsigned int *)&len)) != 0) return(NULL);ptr = (unsigned char *)&sa.sin_addr;sprintf(addr_buffer, "%d.%d.%d.%d", ptr[ 0 ], ptr[ 1 ], ptr[ 2 ], ptr[ 3 ]);return(addr_buffer);
C_ret:
#undef return

return C_r;}

/* from ##net#getpeerport */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub155(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub155(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int s=(int )C_unfix(C_a0);
struct sockaddr_in sa;int len = sizeof(struct sockaddr_in);if(getpeername(s, (struct sockaddr *)&sa, (socklen_t *)(&len)) != 0) return(-1);else return(ntohs(sa.sin_port));
C_ret:
#undef return

return C_r;}

/* from ##net#getsockport in k941 in k938 in k935 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub149(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub149(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int s=(int )C_unfix(C_a0);
struct sockaddr_in sa;int len = sizeof(struct sockaddr_in);if(getsockname(s, (struct sockaddr *)&sa, (socklen_t *)(&len)) != 0) return(-1);else return(ntohs(sa.sin_port));
C_ret:
#undef return

return C_r;}

/* from ##net#getsockname */
#define return(x) C_cblock C_r = (C_mpointer(&C_a,(void*)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub141(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub141(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int s=(int )C_unfix(C_a0);
struct sockaddr_in sa;unsigned char *ptr;int len = sizeof(struct sockaddr_in);if(getsockname(s, (struct sockaddr *)&sa, (socklen_t *)&len) != 0) return(NULL);ptr = (unsigned char *)&sa.sin_addr;sprintf(addr_buffer, "%d.%d.%d.%d", ptr[ 0 ], ptr[ 1 ], ptr[ 2 ], ptr[ 3 ]);return(addr_buffer);
C_ret:
#undef return

return C_r;}

/* from ##net#make-nonblocking in k941 in k938 in k935 */
#define return(x) C_cblock C_r = (C_mk_bool((x))); goto C_ret; C_cblockend
static C_word C_fcall stub135(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub135(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int fd=(int )C_unfix(C_a0);
int val = fcntl(fd, F_GETFL, 0);if(val == -1) return(0);return(fcntl(fd, F_SETFL, val | O_NONBLOCK) != -1);
C_ret:
#undef return

return C_r;}

/* from k998 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub122(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4) C_regparm;
C_regparm static C_word C_fcall stub122(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int s=(int )C_unfix(C_a0);
void * msg=(void * )C_data_pointer_or_null(C_a1);
int offset=(int )C_unfix(C_a2);
int len=(int )C_unfix(C_a3);
int flags=(int )C_unfix(C_a4);
return(send(s, (char *)msg+offset, len, flags));
C_ret:
#undef return

return C_r;}

/* from k991 */
static C_word C_fcall stub107(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub107(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
void * t1=(void * )C_data_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
C_r=C_fix((C_word)connect(t0,t1,t2));
return C_r;}

/* from ##net#shutdown in k941 in k938 in k935 */
static C_word C_fcall stub98(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub98(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
int t1=(int )C_unfix(C_a1);
C_r=C_fix((C_word)shutdown(t0,t1));
return C_r;}

/* from k981 */
static C_word C_fcall stub85(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3) C_regparm;
C_regparm static C_word C_fcall stub85(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
void * t1=(void * )C_data_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
int t3=(int )C_unfix(C_a3);
C_r=C_fix((C_word)recv(t0,t1,t2,t3));
return C_r;}

/* from ##net#close in k941 in k938 in k935 */
static C_word C_fcall stub76(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub76(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_fix((C_word)closesocket(t0));
return C_r;}

/* from k965 */
static C_word C_fcall stub62(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub62(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
void * t1=(void * )C_c_pointer_or_null(C_a1);
void * t2=(void * )C_c_pointer_or_null(C_a2);
C_r=C_fix((C_word)accept(t0,t1,t2));
return C_r;}

/* from ##net#listen */
static C_word C_fcall stub53(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub53(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
int t1=(int )C_unfix(C_a1);
C_r=C_fix((C_word)listen(t0,t1));
return C_r;}

/* from k951 */
static C_word C_fcall stub41(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub41(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
void * t1=(void * )C_data_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
C_r=C_fix((C_word)bind(t0,t1,t2));
return C_r;}

/* from ##net#socket in k941 in k938 in k935 */
static C_word C_fcall stub31(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub31(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
int t1=(int )C_unfix(C_a1);
int t2=(int )C_unfix(C_a2);
C_r=C_fix((C_word)socket(t0,t1,t2));
return C_r;}

C_noret_decl(C_tcp_toplevel)
C_externexport void C_ccall C_tcp_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_937)
static void C_ccall f_937(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_940)
static void C_ccall f_940(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_943)
static void C_ccall f_943(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1027)
static void C_ccall f_1027(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1411)
static void C_ccall f_1411(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2639)
static void C_ccall f_2639(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1434)
static void C_ccall f_1434(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2635)
static void C_ccall f_2635(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1438)
static void C_ccall f_1438(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2631)
static void C_ccall f_2631(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1442)
static void C_ccall f_1442(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2627)
static void C_ccall f_2627(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1446)
static void C_ccall f_1446(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2616)
static void C_ccall f_2616(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2596)
static void C_ccall f_2596(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2600)
static void C_ccall f_2600(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2607)
static void C_ccall f_2607(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2567)
static void C_ccall f_2567(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2594)
static void C_ccall f_2594(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2590)
static void C_ccall f_2590(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2580)
static void C_ccall f_2580(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2519)
static void C_ccall f_2519(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2523)
static void C_ccall f_2523(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2526)
static void C_ccall f_2526(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2565)
static void C_ccall f_2565(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2561)
static void C_ccall f_2561(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2536)
static void C_ccall f_2536(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2554)
static void C_ccall f_2554(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2550)
static void C_ccall f_2550(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2543)
static void C_ccall f_2543(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2471)
static void C_ccall f_2471(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2475)
static void C_ccall f_2475(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2478)
static void C_ccall f_2478(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2485)
static void C_ccall f_2485(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2517)
static void C_ccall f_2517(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2513)
static void C_ccall f_2513(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2488)
static void C_ccall f_2488(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2492)
static void C_ccall f_2492(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2506)
static void C_ccall f_2506(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2502)
static void C_ccall f_2502(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2495)
static void C_ccall f_2495(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2453)
static void C_ccall f_2453(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2457)
static void C_ccall f_2457(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2213)
static void C_ccall f_2213(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2213)
static void C_ccall f_2213r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2220)
static void C_ccall f_2220(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2436)
static void C_ccall f_2436(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2430)
static void C_ccall f_2430(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1096)
static void C_fcall f_1096(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1119)
static void C_ccall f_1119(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1123)
static void C_ccall f_1123(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1034)
static void C_ccall f_1034(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1038)
static void C_ccall f_1038(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1135)
static void C_ccall f_1135(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1146)
static void C_ccall f_1146(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1142)
static void C_ccall f_1142(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1129)
static void C_ccall f_1129(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2422)
static void C_ccall f_2422(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2226)
static void C_ccall f_2226(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2232)
static void C_ccall f_2232(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2408)
static void C_ccall f_2408(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2419)
static void C_ccall f_2419(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2415)
static void C_ccall f_2415(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2258)
static void C_ccall f_2258(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2399)
static void C_ccall f_2399(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2261)
static void C_ccall f_2261(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2385)
static void C_ccall f_2385(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2396)
static void C_ccall f_2396(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2392)
static void C_ccall f_2392(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2264)
static void C_ccall f_2264(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2321)
static void C_fcall f_2321(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2328)
static void C_ccall f_2328(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2337)
static void C_ccall f_2337(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2340)
static void C_ccall f_2340(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2343)
static void C_ccall f_2343(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2346)
static void C_ccall f_2346(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2267)
static void C_ccall f_2267(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2307)
static void C_ccall f_2307(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2303)
static void C_ccall f_2303(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2290)
static void C_ccall f_2290(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2286)
static void C_ccall f_2286(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2273)
static void C_ccall f_2273(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2237)
static void C_fcall f_2237(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2244)
static void C_ccall f_2244(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2255)
static void C_ccall f_2255(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2251)
static void C_ccall f_2251(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2168)
static void C_ccall f_2168(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2187)
static void C_ccall f_2187(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2198)
static void C_ccall f_2198(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2194)
static void C_ccall f_2194(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2178)
static void C_ccall f_2178(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2082)
static void C_ccall f_2082(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2092)
static void C_ccall f_2092(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2097)
static void C_fcall f_2097(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2133)
static void C_ccall f_2133(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2136)
static void C_ccall f_2136(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2139)
static void C_ccall f_2139(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2142)
static void C_ccall f_2142(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2119)
static void C_ccall f_2119(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2130)
static void C_ccall f_2130(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2126)
static void C_ccall f_2126(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2110)
static void C_ccall f_2110(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1448)
static void C_fcall f_1448(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2069)
static void C_ccall f_2069(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2080)
static void C_ccall f_2080(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2076)
static void C_ccall f_2076(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1452)
static void C_ccall f_1452(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1455)
static void C_ccall f_1455(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1461)
static void C_ccall f_1461(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1464)
static void C_fcall f_1464(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1467)
static void C_ccall f_1467(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1470)
static void C_ccall f_1470(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1947)
static void C_ccall f_1947(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1957)
static void C_fcall f_1957(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2045)
static void C_ccall f_2045(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1973)
static void C_ccall f_1973(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1980)
static void C_ccall f_1980(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2002)
static void C_ccall f_2002(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2018)
static void C_ccall f_2018(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1882)
static void C_ccall f_1882(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_1888)
static void C_fcall f_1888(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1936)
static void C_ccall f_1936(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1839)
static void C_ccall f_1839(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1853)
static void C_fcall f_1853(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1856)
static void C_ccall f_1856(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1867)
static void C_ccall f_1867(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1863)
static void C_ccall f_1863(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1804)
static void C_ccall f_1804(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1826)
static void C_ccall f_1826(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1837)
static void C_ccall f_1837(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1833)
static void C_ccall f_1833(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1817)
static void C_ccall f_1817(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1782)
static void C_ccall f_1782(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1786)
static void C_ccall f_1786(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1544)
static void C_ccall f_1544(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1730)
static void C_ccall f_1730(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1740)
static void C_ccall f_1740(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1667)
static void C_ccall f_1667(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1714)
static void C_fcall f_1714(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1717)
static void C_ccall f_1717(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1675)
static void C_fcall f_1675(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1684)
static void C_fcall f_1684(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1687)
static void C_ccall f_1687(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1698)
static void C_ccall f_1698(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1694)
static void C_ccall f_1694(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1766)
static void C_ccall f_1766(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1746)
static void C_ccall f_1746(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1751)
static void C_ccall f_1751(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1760)
static void C_ccall f_1760(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1640)
static void C_ccall f_1640(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1545)
static void C_fcall f_1545(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1555)
static void C_fcall f_1555(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1609)
static void C_ccall f_1609(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1620)
static void C_ccall f_1620(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1616)
static void C_ccall f_1616(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1577)
static void C_ccall f_1577(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1580)
static void C_ccall f_1580(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1583)
static void C_ccall f_1583(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1586)
static void C_ccall f_1586(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1471)
static void C_fcall f_1471(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1477)
static void C_fcall f_1477(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1528)
static void C_ccall f_1528(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1539)
static void C_ccall f_1539(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1535)
static void C_ccall f_1535(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1496)
static void C_ccall f_1496(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1499)
static void C_ccall f_1499(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1502)
static void C_ccall f_1502(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1505)
static void C_ccall f_1505(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1417)
static void C_fcall f_1417(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1419)
static void C_ccall f_1419(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1376)
static void C_ccall f_1376(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1392)
static void C_ccall f_1392(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1403)
static void C_ccall f_1403(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1399)
static void C_ccall f_1399(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1367)
static void C_ccall f_1367(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1272)
static void C_ccall f_1272(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1272)
static void C_ccall f_1272r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1322)
static void C_fcall f_1322(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1317)
static void C_fcall f_1317(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1274)
static void C_fcall f_1274(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1286)
static void C_ccall f_1286(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1305)
static void C_ccall f_1305(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1316)
static void C_ccall f_1316(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1312)
static void C_ccall f_1312(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1296)
static void C_ccall f_1296(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1280)
static void C_ccall f_1280(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1173)
static void C_ccall f_1173(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1255)
static void C_ccall f_1255(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1179)
static void C_ccall f_1179(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1248)
static void C_ccall f_1248(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1247)
static void C_ccall f_1247(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1232)
static void C_ccall f_1232(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1243)
static void C_ccall f_1243(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1239)
static void C_ccall f_1239(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1182)
static void C_ccall f_1182(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1185)
static void C_ccall f_1185(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1220)
static void C_ccall f_1220(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1188)
static void C_ccall f_1188(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1203)
static void C_ccall f_1203(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1214)
static void C_ccall f_1214(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1210)
static void C_ccall f_1210(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1194)
static void C_ccall f_1194(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1066)
static void C_fcall f_1066(C_word t0) C_noret;
C_noret_decl(f_1072)
static void C_ccall f_1072(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1081)
static void C_ccall f_1081(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1052)
static void C_fcall f_1052(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1061)
static void C_ccall f_1061(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1046)
static C_word C_fcall f_1046(C_word t0);
C_noret_decl(f_1011)
static C_word C_fcall f_1011(C_word t0);
C_noret_decl(f_1002)
static C_word C_fcall f_1002(C_word t0);
C_noret_decl(f_985)
static C_word C_fcall f_985(C_word t0,C_word t1);
C_noret_decl(f_975)
static C_word C_fcall f_975(C_word t0);
C_noret_decl(f_945)
static C_word C_fcall f_945(C_word t0,C_word t1,C_word t2);

C_noret_decl(trf_1096)
static void C_fcall trf_1096(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1096(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1096(t0,t1,t2);}

C_noret_decl(trf_2321)
static void C_fcall trf_2321(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2321(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2321(t0,t1);}

C_noret_decl(trf_2237)
static void C_fcall trf_2237(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2237(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2237(t0,t1);}

C_noret_decl(trf_2097)
static void C_fcall trf_2097(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2097(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2097(t0,t1);}

C_noret_decl(trf_1448)
static void C_fcall trf_1448(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1448(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1448(t0,t1,t2);}

C_noret_decl(trf_1464)
static void C_fcall trf_1464(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1464(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1464(t0,t1);}

C_noret_decl(trf_1957)
static void C_fcall trf_1957(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1957(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1957(t0,t1,t2,t3);}

C_noret_decl(trf_1888)
static void C_fcall trf_1888(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1888(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1888(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1853)
static void C_fcall trf_1853(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1853(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1853(t0,t1);}

C_noret_decl(trf_1714)
static void C_fcall trf_1714(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1714(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1714(t0,t1);}

C_noret_decl(trf_1675)
static void C_fcall trf_1675(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1675(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1675(t0,t1);}

C_noret_decl(trf_1684)
static void C_fcall trf_1684(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1684(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1684(t0,t1);}

C_noret_decl(trf_1545)
static void C_fcall trf_1545(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1545(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1545(t0,t1,t2);}

C_noret_decl(trf_1555)
static void C_fcall trf_1555(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1555(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1555(t0,t1,t2,t3);}

C_noret_decl(trf_1471)
static void C_fcall trf_1471(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1471(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1471(t0,t1);}

C_noret_decl(trf_1477)
static void C_fcall trf_1477(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1477(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1477(t0,t1);}

C_noret_decl(trf_1417)
static void C_fcall trf_1417(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1417(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1417(t0,t1);}

C_noret_decl(trf_1322)
static void C_fcall trf_1322(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1322(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1322(t0,t1);}

C_noret_decl(trf_1317)
static void C_fcall trf_1317(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1317(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1317(t0,t1,t2);}

C_noret_decl(trf_1274)
static void C_fcall trf_1274(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1274(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1274(t0,t1,t2,t3);}

C_noret_decl(trf_1066)
static void C_fcall trf_1066(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1066(void *dummy){
C_word t0=C_pick(0);
C_adjust_stack(-1);
f_1066(t0);}

C_noret_decl(trf_1052)
static void C_fcall trf_1052(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1052(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1052(t0,t1,t2,t3);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr3rv)
static void C_fcall tr3rv(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3rv(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n+1);
t3=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_tcp_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_tcp_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("tcp_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(440)){
C_save(t1);
C_rereclaim2(440*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,95);
lf[7]=C_h_intern(&lf[7],17,"\003sysmake-c-string");
lf[9]=C_h_intern(&lf[9],18,"\003syscurrent-thread");
lf[10]=C_h_intern(&lf[10],12,"\003sysschedule");
lf[11]=C_h_intern(&lf[11],10,"tcp-listen");
lf[12]=C_h_intern(&lf[12],15,"\003syssignal-hook");
lf[13]=C_h_intern(&lf[13],14,"\000network-error");
lf[14]=C_h_intern(&lf[14],17,"\003sysstring-append");
lf[15]=C_decode_literal(C_heaptop,"\376B\000\000\030cannot bind to socket - ");
lf[16]=C_h_intern(&lf[16],17,"\003syspeek-c-string");
lf[17]=C_h_intern(&lf[17],16,"\003sysupdate-errno");
lf[18]=C_decode_literal(C_heaptop,"\376B\000\000\042getting listener host IP failed - ");
lf[19]=C_h_intern(&lf[19],11,"make-string");
lf[20]=C_decode_literal(C_heaptop,"\376B\000\000 error while setting up socket - ");
lf[21]=C_h_intern(&lf[21],9,"\003syserror");
lf[22]=C_decode_literal(C_heaptop,"\376B\000\000\024cannot create socket");
lf[23]=C_h_intern(&lf[23],13,"\000domain-error");
lf[24]=C_decode_literal(C_heaptop,"\376B\000\000\023invalid port number");
lf[25]=C_h_intern(&lf[25],12,"tcp-listener");
lf[26]=C_decode_literal(C_heaptop,"\376B\000\000\032cannot listen on socket - ");
lf[27]=C_h_intern(&lf[27],13,"tcp-listener\077");
lf[28]=C_h_intern(&lf[28],9,"tcp-close");
lf[29]=C_decode_literal(C_heaptop,"\376B\000\000\032cannot close TCP socket - ");
lf[30]=C_h_intern(&lf[30],15,"tcp-buffer-size");
lf[31]=C_h_intern(&lf[31],16,"tcp-read-timeout");
lf[32]=C_h_intern(&lf[32],17,"tcp-write-timeout");
lf[33]=C_h_intern(&lf[33],19,"tcp-connect-timeout");
lf[34]=C_h_intern(&lf[34],18,"tcp-accept-timeout");
lf[36]=C_decode_literal(C_heaptop,"\376B\000\000\030read operation timed out");
lf[37]=C_h_intern(&lf[37],25,"\003systhread-block-for-i/o!");
lf[38]=C_h_intern(&lf[38],29,"\003systhread-block-for-timeout!");
lf[39]=C_decode_literal(C_heaptop,"\376B\000\000\032cannot read from socket - ");
lf[40]=C_decode_literal(C_heaptop,"\376B\000\000\031write operation timed out");
lf[41]=C_decode_literal(C_heaptop,"\376B\000\000\031cannot write to socket - ");
lf[42]=C_decode_literal(C_heaptop,"\376B\000\000\005(tcp)");
lf[43]=C_decode_literal(C_heaptop,"\376B\000\000\005(tcp)");
lf[44]=C_h_intern(&lf[44],6,"socket");
lf[45]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[46]=C_decode_literal(C_heaptop,"\376B\000\000\042cannot close socket output port - ");
lf[47]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[48]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[49]=C_h_intern(&lf[49],16,"make-output-port");
lf[50]=C_decode_literal(C_heaptop,"\376B\000\000 cannot check socket for input - ");
lf[51]=C_decode_literal(C_heaptop,"\376B\000\000!cannot close socket input port - ");
lf[52]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[53]=C_h_intern(&lf[53],15,"\003sysmake-string");
lf[54]=C_h_intern(&lf[54],20,"\003sysscan-buffer-line");
lf[55]=C_h_intern(&lf[55],15,"make-input-port");
lf[56]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[57]=C_decode_literal(C_heaptop,"\376B\000\000\032cannot create TCP ports - ");
lf[58]=C_h_intern(&lf[58],10,"tcp-accept");
lf[59]=C_decode_literal(C_heaptop,"\376B\000\000!could not accept from listener - ");
lf[60]=C_decode_literal(C_heaptop,"\376B\000\000\032accept operation timed out");
lf[61]=C_h_intern(&lf[61],17,"tcp-accept-ready\077");
lf[62]=C_decode_literal(C_heaptop,"\376B\000\000 cannot check socket for input - ");
lf[63]=C_h_intern(&lf[63],11,"tcp-connect");
lf[64]=C_decode_literal(C_heaptop,"\376B\000\000\033cannot connect to socket - ");
lf[65]=C_decode_literal(C_heaptop,"\376B\000\000\026getsockopt() failed - ");
lf[66]=C_decode_literal(C_heaptop,"\376B\000\000\027cannot create socket - ");
lf[67]=C_decode_literal(C_heaptop,"\376B\000\000\033connect operation timed out");
lf[68]=C_h_intern(&lf[68],4,"\000all");
lf[69]=C_decode_literal(C_heaptop,"\376B\000\000\021fcntl() failed - ");
lf[70]=C_decode_literal(C_heaptop,"\376B\000\000\030cannot find host address");
lf[71]=C_decode_literal(C_heaptop,"\376B\000\000\027cannot create socket - ");
lf[72]=C_decode_literal(C_heaptop,"\376B\000\000\021no port specified");
lf[73]=C_decode_literal(C_heaptop,"\376B\000\000#cannot compute port from service - ");
lf[74]=C_decode_literal(C_heaptop,"\376B\000\000\003tcp");
lf[75]=C_h_intern(&lf[75],13,"\003syssubstring");
lf[76]=C_h_intern(&lf[76],20,"\003systcp-port->fileno");
lf[77]=C_h_intern(&lf[77],5,"error");
lf[78]=C_decode_literal(C_heaptop,"\376B\000\000)argument does not appear to be a TCP port");
lf[79]=C_h_intern(&lf[79],13,"\003sysport-data");
lf[80]=C_h_intern(&lf[80],13,"tcp-addresses");
lf[81]=C_decode_literal(C_heaptop,"\376B\000\000 cannot compute remote address - ");
lf[82]=C_decode_literal(C_heaptop,"\376B\000\000\037cannot compute local address - ");
lf[83]=C_h_intern(&lf[83],14,"\003syscheck-port");
lf[84]=C_h_intern(&lf[84],16,"tcp-port-numbers");
lf[85]=C_decode_literal(C_heaptop,"\376B\000\000\035cannot compute remote port - ");
lf[86]=C_decode_literal(C_heaptop,"\376B\000\000\034cannot compute local port - ");
lf[87]=C_h_intern(&lf[87],17,"tcp-listener-port");
lf[88]=C_decode_literal(C_heaptop,"\376B\000\000\036cannot obtain listener port - ");
lf[89]=C_h_intern(&lf[89],16,"tcp-abandon-port");
lf[90]=C_h_intern(&lf[90],19,"tcp-listener-fileno");
lf[91]=C_h_intern(&lf[91],14,"make-parameter");
lf[92]=C_decode_literal(C_heaptop,"\376B\000\000\031cannot initialize Winsock");
lf[93]=C_h_intern(&lf[93],17,"register-feature!");
lf[94]=C_h_intern(&lf[94],3,"tcp");
C_register_lf2(lf,95,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_937,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k935 */
static void C_ccall f_937(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_937,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_940,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_scheduler_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k938 in k935 */
static void C_ccall f_940(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_940,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_943,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* tcp.scm: 91   register-feature! */
t3=*((C_word*)lf[93]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[94]);}

/* k941 in k938 in k935 */
static void C_ccall f_943(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_943,2,t0,t1);}
t2=C_mutate(&lf[0] /* (set! socket ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_945,tmp=(C_word)a,a+=2,tmp));
t3=C_mutate(&lf[1] /* (set! close ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_975,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate(&lf[2] /* (set! shutdown ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_985,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate(&lf[3] /* (set! make-nonblocking ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1002,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate(&lf[4] /* (set! getsockport ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1011,tmp=(C_word)a,a+=2,tmp));
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1027,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)stub168(C_SCHEME_UNDEFINED))){
t8=t7;
f_1027(2,t8,C_SCHEME_UNDEFINED);}
else{
/* tcp.scm: 176  ##sys#signal-hook */
t8=*((C_word*)lf[12]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,lf[13],lf[92]);}}

/* k1025 in k941 in k938 in k935 */
static void C_ccall f_1027(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1027,2,t0,t1);}
t2=C_mutate(&lf[5] /* (set! select ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1046,tmp=(C_word)a,a+=2,tmp));
t3=C_mutate(&lf[6] /* (set! gethostaddr ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1052,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate(&lf[8] /* (set! yield ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1066,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[11]+1 /* (set! tcp-listen ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1272,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[27]+1 /* (set! tcp-listener? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1367,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate((C_word*)lf[28]+1 /* (set! tcp-close ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1376,tmp=(C_word)a,a+=2,tmp));
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1411,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* tcp.scm: 310  make-parameter */
t9=*((C_word*)lf[91]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,C_SCHEME_FALSE);}

/* k1409 in k1025 in k941 in k938 in k935 */
static void C_ccall f_1411(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1411,2,t0,t1);}
t2=C_mutate((C_word*)lf[30]+1 /* (set! tcp-buffer-size ...) */,t1);
t3=C_set_block_item(lf[31] /* tcp-read-timeout */,0,C_SCHEME_UNDEFINED);
t4=C_set_block_item(lf[32] /* tcp-write-timeout */,0,C_SCHEME_UNDEFINED);
t5=C_set_block_item(lf[33] /* tcp-connect-timeout */,0,C_SCHEME_UNDEFINED);
t6=C_set_block_item(lf[34] /* tcp-accept-timeout */,0,C_SCHEME_UNDEFINED);
t7=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1417,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1434,a[2]=t7,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2639,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
/* tcp.scm: 321  check */
f_1417(t9,lf[31]);}

/* k2637 in k1409 in k1025 in k941 in k938 in k935 */
static void C_ccall f_2639(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 321  make-parameter */
t2=*((C_word*)lf[91]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_fix(60000),t1);}

/* k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_ccall f_1434(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1434,2,t0,t1);}
t2=C_mutate((C_word*)lf[31]+1 /* (set! tcp-read-timeout ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1438,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2635,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* tcp.scm: 322  check */
f_1417(t4,lf[32]);}

/* k2633 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_ccall f_2635(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 322  make-parameter */
t2=*((C_word*)lf[91]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_fix(60000),t1);}

/* k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_ccall f_1438(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1438,2,t0,t1);}
t2=C_mutate((C_word*)lf[32]+1 /* (set! tcp-write-timeout ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1442,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2631,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* tcp.scm: 323  check */
f_1417(t4,lf[33]);}

/* k2629 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_ccall f_2631(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 323  make-parameter */
t2=*((C_word*)lf[91]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_SCHEME_FALSE,t1);}

/* k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_ccall f_1442(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1442,2,t0,t1);}
t2=C_mutate((C_word*)lf[33]+1 /* (set! tcp-connect-timeout ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1446,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2627,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* tcp.scm: 324  check */
f_1417(t4,lf[34]);}

/* k2625 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_ccall f_2627(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 324  make-parameter */
t2=*((C_word*)lf[91]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_SCHEME_FALSE,t1);}

/* k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_ccall f_1446(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[22],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1446,2,t0,t1);}
t2=C_mutate((C_word*)lf[34]+1 /* (set! tcp-accept-timeout ...) */,t1);
t3=*((C_word*)lf[30]+1);
t4=*((C_word*)lf[19]+1);
t5=C_mutate(&lf[35] /* (set! io-ports ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1448,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t6=C_mutate((C_word*)lf[58]+1 /* (set! tcp-accept ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2082,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate((C_word*)lf[61]+1 /* (set! tcp-accept-ready? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2168,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate((C_word*)lf[63]+1 /* (set! tcp-connect ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2213,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate((C_word*)lf[76]+1 /* (set! tcp-port->fileno ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2453,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate((C_word*)lf[80]+1 /* (set! tcp-addresses ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2471,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate((C_word*)lf[84]+1 /* (set! tcp-port-numbers ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2519,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate((C_word*)lf[87]+1 /* (set! tcp-listener-port ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2567,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate((C_word*)lf[89]+1 /* (set! tcp-abandon-port ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2596,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate((C_word*)lf[90]+1 /* (set! tcp-listener-fileno ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2616,tmp=(C_word)a,a+=2,tmp));
t15=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,C_SCHEME_UNDEFINED);}

/* tcp-listener-fileno in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_ccall f_2616(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2616,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[25],lf[90]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(1)));}

/* tcp-abandon-port in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_ccall f_2596(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2596,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2600,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 639  ##sys#check-port */
t4=*((C_word*)lf[83]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[89]);}

/* k2598 in tcp-abandon-port in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_ccall f_2600(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2600,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2607,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 641  ##sys#port-data */
t3=*((C_word*)lf[79]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* k2605 in k2598 in tcp-abandon-port in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_ccall f_2607(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
t3=(C_truep(t2)?C_fix(2):C_fix(1));
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_set_i_slot(t1,t3,C_SCHEME_TRUE));}

/* tcp-listener-port in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_ccall f_2567(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2567,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[25],lf[87]);
t4=(C_word)C_slot(t2,C_fix(1));
t5=f_1011(t4);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2580,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_eqp(C_fix(-1),t5);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2590,a[2]=t4,a[3]=t2,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2594,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t10=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t9,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}
else{
t8=t6;
f_2580(2,t8,C_SCHEME_UNDEFINED);}}

/* k2592 in tcp-listener-port in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_ccall f_2594(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 634  ##sys#string-append */
t2=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[88],t1);}

/* k2588 in tcp-listener-port in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_ccall f_2590(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 633  ##sys#signal-hook */
t2=*((C_word*)lf[12]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[4],lf[13],lf[87],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2578 in tcp-listener-port in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_ccall f_2580(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* tcp-port-numbers in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_ccall f_2519(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2519,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2523,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 620  ##sys#check-port */
t4=*((C_word*)lf[83]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[84]);}

/* k2521 in tcp-port-numbers in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_ccall f_2523(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2523,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2526,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 621  ##sys#tcp-port->fileno */
t3=*((C_word*)lf[76]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k2524 in k2521 in tcp-port-numbers in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_ccall f_2526(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2526,2,t0,t1);}
t2=f_1011(t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2536,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t2)){
t4=t3;
f_2536(2,t4,t2);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2561,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2565,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t6=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}}

/* k2563 in k2524 in k2521 in tcp-port-numbers in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_ccall f_2565(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 624  ##sys#string-append */
t2=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[86],t1);}

/* k2559 in k2524 in k2521 in tcp-port-numbers in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_ccall f_2561(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 624  ##sys#signal-hook */
t2=*((C_word*)lf[12]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[13],lf[84],t1,((C_word*)t0)[2]);}

/* k2534 in k2524 in k2521 in tcp-port-numbers in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_ccall f_2536(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2536,2,t0,t1);}
t2=((C_word*)t0)[4];
t3=(C_word)stub155(C_SCHEME_UNDEFINED,t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2543,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t3)){
t5=t4;
f_2543(2,t5,t3);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2550,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2554,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t7=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}}

/* k2552 in k2534 in k2524 in k2521 in tcp-port-numbers in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_ccall f_2554(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 626  ##sys#string-append */
t2=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[85],t1);}

/* k2548 in k2534 in k2524 in k2521 in tcp-port-numbers in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_ccall f_2550(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 626  ##sys#signal-hook */
t2=*((C_word*)lf[12]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[13],lf[84],t1,((C_word*)t0)[2]);}

/* k2541 in k2534 in k2524 in k2521 in tcp-port-numbers in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_ccall f_2543(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 622  values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* tcp-addresses in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_ccall f_2471(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2471,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2475,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 611  ##sys#check-port */
t4=*((C_word*)lf[83]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[80]);}

/* k2473 in tcp-addresses in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_ccall f_2475(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2475,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2478,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 612  ##sys#tcp-port->fileno */
t3=*((C_word*)lf[76]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k2476 in k2473 in tcp-addresses in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_ccall f_2478(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2478,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2485,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=t1;
t4=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t5=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,(C_word)stub141(t4,t3),C_fix(0));}

/* k2483 in k2476 in k2473 in tcp-addresses in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_ccall f_2485(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2485,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2488,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=t2;
f_2488(2,t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2513,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2517,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t5=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}}

/* k2515 in k2483 in k2476 in k2473 in tcp-addresses in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_ccall f_2517(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 615  ##sys#string-append */
t2=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[82],t1);}

/* k2511 in k2483 in k2476 in k2473 in tcp-addresses in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_ccall f_2513(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 615  ##sys#signal-hook */
t2=*((C_word*)lf[12]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[13],lf[80],t1,((C_word*)t0)[2]);}

/* k2486 in k2483 in k2476 in k2473 in tcp-addresses in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_ccall f_2488(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2488,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2492,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[2];
t4=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t5=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,(C_word)stub161(t4,t3),C_fix(0));}

/* k2490 in k2486 in k2483 in k2476 in k2473 in tcp-addresses in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_ccall f_2492(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2492,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2495,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=t2;
f_2495(2,t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2502,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2506,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t5=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}}

/* k2504 in k2490 in k2486 in k2483 in k2476 in k2473 in tcp-addresses in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_ccall f_2506(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 617  ##sys#string-append */
t2=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[81],t1);}

/* k2500 in k2490 in k2486 in k2483 in k2476 in k2473 in tcp-addresses in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_ccall f_2502(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 617  ##sys#signal-hook */
t2=*((C_word*)lf[12]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[13],lf[80],t1,((C_word*)t0)[2]);}

/* k2493 in k2490 in k2486 in k2483 in k2476 in k2473 in tcp-addresses in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_ccall f_2495(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 613  values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* ##sys#tcp-port->fileno in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_ccall f_2453(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2453,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2457,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 605  ##sys#port-data */
t4=*((C_word*)lf[79]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k2455 in ##sys#tcp-port->fileno in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_ccall f_2457(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_vectorp(t1))){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_slot(t1,C_fix(0)));}
else{
/* tcp.scm: 608  error */
t2=*((C_word*)lf[77]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[76],lf[78],((C_word*)t0)[2]);}}

/* tcp-connect in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_ccall f_2213(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr3rv,(void*)f_2213r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_2213r(t0,t1,t2,t3);}}

static void C_ccall f_2213r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(9);
t4=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t5=(C_word)C_vemptyp(t3);
t6=(C_truep(t5)?C_SCHEME_FALSE:(C_word)C_slot(t3,C_fix(0)));
t7=t6;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2220,a[2]=t1,a[3]=t8,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* tcp.scm: 556  tcp-connect-timeout */
t10=*((C_word*)lf[33]+1);
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,t9);}

/* k2218 in tcp-connect in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_ccall f_2220(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2220,2,t0,t1);}
t2=(C_word)C_i_check_string(((C_word*)((C_word*)t0)[4])[1]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2226,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)((C_word*)t0)[3])[1])){
t4=t3;
f_2226(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2422,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2430,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2436,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t4,t5,t6);}}

/* a2435 in k2218 in tcp-connect in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_ccall f_2436(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2436,4,t0,t1,t2,t3);}
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t5=C_mutate(((C_word *)((C_word*)t0)[2])+1,t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}

/* a2429 in k2218 in tcp-connect in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_ccall f_2430(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2430,2,t0,t1);}
t2=((C_word*)((C_word*)t0)[2])[1];
t3=(C_word)C_block_size(t2);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1096,a[2]=t5,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_1096(t7,t1,C_fix(0));}

/* loop in a2429 in k2218 in tcp-connect in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_fcall f_1096(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(5);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1096,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[4]))){
/* tcp.scm: 232  values */
C_values(4,0,t1,((C_word*)t0)[3],C_SCHEME_FALSE);}
else{
t3=(C_word)C_subchar(((C_word*)t0)[3],t2);
t4=(C_word)C_eqp(t3,C_make_character(58));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1119,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_u_fixnum_increase(t2);
/* substring */
t7=*((C_word*)lf[75]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t5,((C_word*)t0)[3],t6,((C_word*)t0)[4]);}
else{
t5=(C_word)C_u_fixnum_plus(t2,C_fix(1));
/* tcp.scm: 245  loop */
t9=t1;
t10=t5;
t1=t9;
t2=t10;
goto loop;}}}

/* k1117 in loop in a2429 in k2218 in tcp-connect in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_ccall f_1119(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1119,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1123,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* substring */
t3=*((C_word*)lf[75]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[3],C_fix(0),((C_word*)t0)[2]);}

/* k1121 in k1117 in loop in a2429 in k2218 in tcp-connect in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_ccall f_1123(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1123,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1034,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t2)){
/* ##sys#make-c-string */
t4=*((C_word*)lf[7]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}
else{
t4=t3;
f_1034(2,t4,C_SCHEME_FALSE);}}

/* k1032 in k1121 in k1117 in loop in a2429 in k2218 in tcp-connect in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_ccall f_1034(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1034,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1038,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* ##sys#make-c-string */
t3=*((C_word*)lf[7]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[74]);}

/* k1036 in k1032 in k1121 in k1117 in loop in a2429 in k2218 in tcp-connect in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_ccall f_1038(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1038,2,t0,t1);}
t2=(C_word)stub177(C_SCHEME_UNDEFINED,((C_word*)t0)[5],t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1129,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_eqp(C_fix(0),t2);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1135,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 240  ##sys#update-errno */
t6=*((C_word*)lf[17]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t5=t3;
f_1129(2,t5,C_SCHEME_UNDEFINED);}}

/* k1133 in k1036 in k1032 in k1121 in k1117 in loop in a2429 in k2218 in tcp-connect in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_ccall f_1135(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1135,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1142,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1146,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k1144 in k1133 in k1036 in k1032 in k1121 in k1117 in loop in a2429 in k2218 in tcp-connect in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_ccall f_1146(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 242  ##sys#string-append */
t2=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[73],t1);}

/* k1140 in k1133 in k1036 in k1032 in k1121 in k1117 in loop in a2429 in k2218 in tcp-connect in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_ccall f_1142(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 241  ##sys#signal-hook */
t2=*((C_word*)lf[12]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[13],lf[63],t1,((C_word*)t0)[2]);}

/* k1127 in k1036 in k1032 in k1121 in k1117 in loop in a2429 in k2218 in tcp-connect in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_ccall f_1129(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 235  values */
C_values(4,0,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2420 in k2218 in tcp-connect in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_ccall f_2422(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t2=((C_word*)t0)[3];
f_2226(2,t2,C_SCHEME_UNDEFINED);}
else{
/* tcp.scm: 560  ##sys#signal-hook */
t2=*((C_word*)lf[12]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[13],lf[63],lf[72],((C_word*)((C_word*)t0)[2])[1]);}}

/* k2224 in k2218 in tcp-connect in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_ccall f_2226(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2226,2,t0,t1);}
t2=(C_word)C_i_check_exact(((C_word*)((C_word*)t0)[5])[1]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2232,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* tcp.scm: 562  make-string */
t4=*((C_word*)lf[19]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,C_fix((C_word)sizeof(struct sockaddr_in)));}

/* k2230 in k2224 in k2218 in tcp-connect in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_ccall f_2232(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2232,2,t0,t1);}
t2=f_945(C_fix((C_word)AF_INET),C_fix((C_word)SOCK_STREAM),C_fix(0));
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2237,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2258,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=((C_word*)t0)[2],a[6]=t1,a[7]=((C_word*)t0)[3],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
t5=(C_word)C_eqp(C_fix(-1),t2);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2408,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* tcp.scm: 571  ##sys#update-errno */
t7=*((C_word*)lf[17]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t6=t4;
f_2258(2,t6,C_SCHEME_UNDEFINED);}}

/* k2406 in k2230 in k2224 in k2218 in tcp-connect in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_ccall f_2408(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2408,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2415,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2419,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k2417 in k2406 in k2230 in k2224 in k2218 in tcp-connect in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_ccall f_2419(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 572  ##sys#string-append */
t2=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[71],t1);}

/* k2413 in k2406 in k2230 in k2224 in k2218 in tcp-connect in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_ccall f_2415(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 572  ##sys#signal-hook */
t2=*((C_word*)lf[12]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[4],lf[13],lf[63],t1,((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1]);}

/* k2256 in k2230 in k2224 in k2218 in tcp-connect in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_ccall f_2258(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2258,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2261,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2399,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 573  ##net#gethostaddr */
f_1052(t3,((C_word*)t0)[6],((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1]);}

/* k2397 in k2256 in k2230 in k2224 in k2218 in tcp-connect in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_ccall f_2399(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_2261(2,t2,C_SCHEME_UNDEFINED);}
else{
/* tcp.scm: 574  ##sys#signal-hook */
t2=*((C_word*)lf[12]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[13],lf[63],lf[70],((C_word*)((C_word*)t0)[2])[1]);}}

/* k2259 in k2256 in k2230 in k2224 in k2218 in tcp-connect in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_ccall f_2261(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2261,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2264,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=f_1002(((C_word*)t0)[6]);
if(C_truep(t3)){
t4=t2;
f_2264(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2385,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* tcp.scm: 576  ##sys#update-errno */
t5=*((C_word*)lf[17]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k2383 in k2259 in k2256 in k2230 in k2224 in k2218 in tcp-connect in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_ccall f_2385(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2385,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2392,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2396,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k2394 in k2383 in k2259 in k2256 in k2230 in k2224 in k2218 in tcp-connect in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_ccall f_2396(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 577  ##sys#string-append */
t2=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[69],t1);}

/* k2390 in k2383 in k2259 in k2256 in k2230 in k2224 in k2218 in tcp-connect in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_ccall f_2392(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 577  ##sys#signal-hook */
t2=*((C_word*)lf[12]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[13],lf[63],t1);}

/* k2262 in k2259 in k2256 in k2230 in k2224 in k2218 in tcp-connect in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_ccall f_2264(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2264,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2267,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[4];
t4=C_fix((C_word)sizeof(struct sockaddr_in));
t5=(C_truep(t3)?t3:C_SCHEME_FALSE);
t6=(C_word)stub107(C_SCHEME_UNDEFINED,((C_word*)t0)[6],t5,t4);
t7=(C_word)C_eqp(C_fix(-1),t6);
if(C_truep(t7)){
t8=(C_word)C_eqp(C_fix((C_word)errno),C_fix((C_word)EINPROGRESS));
if(C_truep(t8)){
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2321,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t10,a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp));
t12=((C_word*)t10)[1];
f_2321(t12,t2);}
else{
/* tcp.scm: 596  fail */
t9=((C_word*)t0)[2];
f_2237(t9,t2);}}
else{
t8=t2;
f_2267(2,t8,C_SCHEME_UNDEFINED);}}

/* loop in k2262 in k2259 in k2256 in k2230 in k2224 in k2218 in tcp-connect in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_fcall f_2321(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2321,NULL,2,t0,t1);}
t2=(C_word)stub196(C_SCHEME_UNDEFINED,((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2328,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_eqp(t2,C_fix(-1));
if(C_truep(t4)){
/* tcp.scm: 582  fail */
t5=((C_word*)t0)[2];
f_2237(t5,t3);}
else{
t5=t3;
f_2328(2,t5,C_SCHEME_UNDEFINED);}}

/* k2326 in loop in k2262 in k2259 in k2256 in k2230 in k2224 in k2218 in tcp-connect in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_ccall f_2328(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2328,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[6],C_fix(1));
if(C_truep(t2)){
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2337,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
t4=(C_word)C_fudge(C_fix(16));
t5=(C_word)C_u_fixnum_plus(t4,((C_word*)t0)[2]);
/* tcp.scm: 585  ##sys#thread-block-for-timeout! */
t6=*((C_word*)lf[38]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,*((C_word*)lf[9]+1),t5);}
else{
t4=t3;
f_2337(2,t4,C_SCHEME_UNDEFINED);}}}

/* k2335 in k2326 in loop in k2262 in k2259 in k2256 in k2230 in k2224 in k2218 in tcp-connect in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_ccall f_2337(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2337,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2340,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* tcp.scm: 588  ##sys#thread-block-for-i/o! */
t3=*((C_word*)lf[37]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,*((C_word*)lf[9]+1),((C_word*)t0)[2],lf[68]);}

/* k2338 in k2335 in k2326 in loop in k2262 in k2259 in k2256 in k2230 in k2224 in k2218 in tcp-connect in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_ccall f_2340(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2340,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2343,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* tcp.scm: 589  yield */
f_1066(t2);}

/* k2341 in k2338 in k2335 in k2326 in loop in k2262 in k2259 in k2256 in k2230 in k2224 in k2218 in tcp-connect in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_ccall f_2343(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2343,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2346,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_slot(*((C_word*)lf[9]+1),C_fix(13)))){
/* tcp.scm: 591  ##sys#signal-hook */
t3=*((C_word*)lf[12]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,lf[13],lf[63],lf[67],((C_word*)t0)[2]);}
else{
t3=t2;
f_2346(2,t3,C_SCHEME_UNDEFINED);}}

/* k2344 in k2341 in k2338 in k2335 in k2326 in loop in k2262 in k2259 in k2256 in k2230 in k2224 in k2218 in tcp-connect in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_ccall f_2346(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 595  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_2321(t2,((C_word*)t0)[2]);}

/* k2265 in k2262 in k2259 in k2256 in k2230 in k2224 in k2218 in tcp-connect in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_ccall f_2267(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2267,2,t0,t1);}
t2=(C_word)stub718(C_SCHEME_UNDEFINED,((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2273,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_eqp(t2,C_fix(-1));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2286,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2290,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t7=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}
else{
if(C_truep((C_word)C_fixnum_greaterp(t2,C_fix(0)))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2303,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2307,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t8=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,(C_word)stub724(t7,t2),C_fix(0));}
else{
t5=t3;
f_2273(2,t5,C_SCHEME_UNDEFINED);}}}

/* k2305 in k2265 in k2262 in k2259 in k2256 in k2230 in k2224 in k2218 in tcp-connect in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_ccall f_2307(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 601  ##sys#string-append */
t2=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[66],t1);}

/* k2301 in k2265 in k2262 in k2259 in k2256 in k2230 in k2224 in k2218 in tcp-connect in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_ccall f_2303(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 601  ##sys#signal-hook */
t2=*((C_word*)lf[12]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[13],lf[63],t1);}

/* k2288 in k2265 in k2262 in k2259 in k2256 in k2230 in k2224 in k2218 in tcp-connect in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_ccall f_2290(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 599  ##sys#string-append */
t2=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[65],t1);}

/* k2284 in k2265 in k2262 in k2259 in k2256 in k2230 in k2224 in k2218 in tcp-connect in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_ccall f_2286(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 599  ##sys#signal-hook */
t2=*((C_word*)lf[12]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[13],lf[63],t1);}

/* k2271 in k2265 in k2262 in k2259 in k2256 in k2230 in k2224 in k2218 in tcp-connect in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_ccall f_2273(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 602  ##net#io-ports */
t2=lf[35];
f_1448(t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* fail in k2230 in k2224 in k2218 in tcp-connect in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_fcall f_2237(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2237,NULL,2,t0,t1);}
t2=f_975(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2244,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* tcp.scm: 566  ##sys#update-errno */
t4=*((C_word*)lf[17]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k2242 in fail in k2230 in k2224 in k2218 in tcp-connect in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_ccall f_2244(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2244,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2251,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2255,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k2253 in k2242 in fail in k2230 in k2224 in k2218 in tcp-connect in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_ccall f_2255(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 568  ##sys#string-append */
t2=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[64],t1);}

/* k2249 in k2242 in fail in k2230 in k2224 in k2218 in tcp-connect in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_ccall f_2251(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 567  ##sys#signal-hook */
t2=*((C_word*)lf[12]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[4],lf[13],lf[63],t1,((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1]);}

/* tcp-accept-ready? in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_ccall f_2168(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2168,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[25],lf[61]);
t4=(C_word)C_slot(t2,C_fix(1));
t5=f_1046(t4);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2178,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_eqp(C_fix(-1),t5);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2187,a[2]=t2,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 538  ##sys#update-errno */
t9=*((C_word*)lf[17]+1);
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}
else{
t8=t6;
f_2178(2,t8,C_SCHEME_UNDEFINED);}}

/* k2185 in tcp-accept-ready? in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_ccall f_2187(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2187,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2194,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2198,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k2196 in k2185 in tcp-accept-ready? in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_ccall f_2198(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 540  ##sys#string-append */
t2=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[62],t1);}

/* k2192 in k2185 in tcp-accept-ready? in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_ccall f_2194(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 539  ##sys#signal-hook */
t2=*((C_word*)lf[12]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[13],lf[61],t1,((C_word*)t0)[2]);}

/* k2176 in tcp-accept-ready? in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_ccall f_2178(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_eqp(C_fix(1),((C_word*)t0)[2]));}

/* tcp-accept in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_ccall f_2082(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2082,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[25]);
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2092,a[2]=t1,a[3]=t2,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* tcp.scm: 510  tcp-accept-timeout */
t6=*((C_word*)lf[34]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}

/* k2090 in tcp-accept in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_ccall f_2092(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2092,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2097,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_2097(t5,((C_word*)t0)[2]);}

/* loop in k2090 in tcp-accept in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_fcall f_2097(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2097,NULL,2,t0,t1);}
t2=f_1046(((C_word*)t0)[5]);
t3=(C_word)C_eqp(C_fix(1),t2);
if(C_truep(t3)){
t4=(C_word)stub62(C_SCHEME_UNDEFINED,((C_word*)t0)[5],C_SCHEME_FALSE,C_SCHEME_FALSE);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2110,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_eqp(C_fix(-1),t4);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2119,a[2]=((C_word*)t0)[4],a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 515  ##sys#update-errno */
t8=*((C_word*)lf[17]+1);
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}
else{
t7=t5;
f_2110(2,t7,C_SCHEME_UNDEFINED);}}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2133,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
t5=(C_word)C_fudge(C_fix(16));
t6=(C_word)C_u_fixnum_plus(t5,((C_word*)t0)[2]);
/* tcp.scm: 522  ##sys#thread-block-for-timeout! */
t7=*((C_word*)lf[38]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t4,*((C_word*)lf[9]+1),t6);}
else{
t5=t4;
f_2133(2,t5,C_SCHEME_UNDEFINED);}}}

/* k2131 in loop in k2090 in tcp-accept in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_ccall f_2133(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2133,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2136,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* tcp.scm: 525  ##sys#thread-block-for-i/o! */
t3=*((C_word*)lf[37]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,*((C_word*)lf[9]+1),((C_word*)t0)[2],C_SCHEME_TRUE);}

/* k2134 in k2131 in loop in k2090 in tcp-accept in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_ccall f_2136(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2136,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2139,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* tcp.scm: 526  yield */
f_1066(t2);}

/* k2137 in k2134 in k2131 in loop in k2090 in tcp-accept in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_ccall f_2139(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2139,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2142,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_slot(*((C_word*)lf[9]+1),C_fix(13)))){
/* tcp.scm: 528  ##sys#signal-hook */
t3=*((C_word*)lf[12]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,lf[13],lf[58],lf[60],((C_word*)t0)[2]);}
else{
t3=t2;
f_2142(2,t3,C_SCHEME_UNDEFINED);}}

/* k2140 in k2137 in k2134 in k2131 in loop in k2090 in tcp-accept in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_ccall f_2142(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 532  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_2097(t2,((C_word*)t0)[2]);}

/* k2117 in loop in k2090 in tcp-accept in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_ccall f_2119(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2119,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2126,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2130,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k2128 in k2117 in loop in k2090 in tcp-accept in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_ccall f_2130(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 517  ##sys#string-append */
t2=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[59],t1);}

/* k2124 in k2117 in loop in k2090 in tcp-accept in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_ccall f_2126(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 516  ##sys#signal-hook */
t2=*((C_word*)lf[12]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[13],lf[58],t1,((C_word*)t0)[2]);}

/* k2108 in loop in k2090 in tcp-accept in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_ccall f_2110(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 519  ##net#io-ports */
t2=lf[35];
f_1448(t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##net#io-ports in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_fcall f_1448(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1448,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1452,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=f_1002(t2);
if(C_truep(t4)){
t5=t3;
f_1452(2,t5,C_SCHEME_UNDEFINED);}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2069,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* tcp.scm: 333  ##sys#update-errno */
t6=*((C_word*)lf[17]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}}

/* k2067 in ##net#io-ports in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_ccall f_2069(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2069,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2076,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2080,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k2078 in k2067 in ##net#io-ports in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_ccall f_2080(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 334  ##sys#string-append */
t2=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[57],t1);}

/* k2074 in k2067 in ##net#io-ports in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_ccall f_2076(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 334  ##sys#signal-hook */
t2=*((C_word*)lf[12]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[13],t1);}

/* k1450 in ##net#io-ports in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_ccall f_1452(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1452,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1455,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* tcp.scm: 335  make-string */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,C_fix(1024));}

/* k1453 in k1450 in ##net#io-ports in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_ccall f_1455(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[22],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1455,2,t0,t1);}
t2=(C_word)C_a_i_vector(&a,3,((C_word*)t0)[4],C_SCHEME_FALSE,C_SCHEME_FALSE);
t3=C_fix(0);
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_fix(0);
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_FALSE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_FALSE;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1461,a[2]=t8,a[3]=t10,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=t6,a[7]=t4,a[8]=t1,a[9]=((C_word*)t0)[4],tmp=(C_word)a,a+=10,tmp);
/* tcp.scm: 341  tbs */
t12=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,t11);}

/* k1459 in k1453 in k1450 in ##net#io-ports in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_ccall f_1461(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1461,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1464,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
if(C_truep(t1)){
t3=(C_word)C_fixnum_greaterp(t1,C_fix(0));
t4=t2;
f_1464(t4,(C_truep(t3)?lf[56]:C_SCHEME_FALSE));}
else{
t3=t2;
f_1464(t3,C_SCHEME_FALSE);}}

/* k1462 in k1459 in k1453 in k1450 in ##net#io-ports in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_fcall f_1464(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1464,NULL,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_1467,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* tcp.scm: 343  tcp-read-timeout */
t5=*((C_word*)lf[31]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* k1465 in k1462 in k1459 in k1453 in k1450 in ##net#io-ports in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_ccall f_1467(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1467,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_1470,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t1,a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
/* tcp.scm: 344  tcp-write-timeout */
t3=*((C_word*)lf[32]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k1468 in k1465 in k1462 in k1459 in k1453 in k1450 in ##net#io-ports in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_ccall f_1470(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[46],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1470,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1471,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[12],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1544,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[12],tmp=(C_word)a,a+=10,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1782,a[2]=t2,a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1804,a[2]=((C_word*)t0)[12],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1839,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1882,a[2]=t2,a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1947,a[2]=t2,a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
/* tcp.scm: 372  make-input-port */
t9=*((C_word*)lf[55]+1);
((C_proc8)(void*)(*((C_word*)t9+1)))(8,t9,t3,t4,t5,t6,C_SCHEME_FALSE,t7,t8);}

/* a1946 in k1468 in k1465 in k1462 in k1459 in k1453 in k1450 in ##net#io-ports in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_ccall f_1947(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1947,4,t0,t1,t2,t3);}
t4=(C_truep(t3)?t3:(C_word)C_fudge(C_fix(21)));
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1957,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t6,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp));
t8=((C_word*)t6)[1];
f_1957(t8,t1,C_SCHEME_FALSE,t4);}

/* loop in a1946 in k1468 in k1465 in k1462 in k1459 in k1453 in k1450 in ##net#io-ports in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_fcall f_1957(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1957,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[7])[1],((C_word*)((C_word*)t0)[6])[1]))){
t4=(C_word)C_i_fixnum_min(((C_word*)((C_word*)t0)[6])[1],t3);
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1973,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=t3,a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp);
/* tcp.scm: 420  ##sys#scan-buffer-line */
t6=*((C_word*)lf[54]+1);
((C_proc6)(void*)(*((C_word*)t6+1)))(6,t6,t1,((C_word*)t0)[5],t4,((C_word*)((C_word*)t0)[7])[1],t5);}
else{
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2045,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* tcp.scm: 441  read-input */
t5=((C_word*)t0)[3];
f_1471(t5,t4);}}

/* k2043 in loop in a1946 in k1468 in k1465 in k1462 in k1459 in k1453 in k1450 in ##net#io-ports in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_ccall f_2045(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[7])[1],((C_word*)((C_word*)t0)[6])[1]))){
/* tcp.scm: 443  loop */
t2=((C_word*)((C_word*)t0)[5])[1];
f_1957(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_FILE);}}

/* a1972 in loop in a1946 in k1468 in k1465 in k1462 in k1459 in k1453 in k1450 in ##net#io-ports in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_ccall f_1973(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1973,4,t0,t1,t2,t3);}
t4=(C_word)C_u_fixnum_difference(t2,((C_word*)((C_word*)t0)[9])[1]);
t5=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_1980,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t4,a[6]=((C_word*)t0)[5],a[7]=t1,a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=t3,a[11]=t2,a[12]=((C_word*)t0)[9],a[13]=((C_word*)t0)[8],tmp=(C_word)a,a+=14,tmp);
/* tcp.scm: 426  ##sys#make-string */
t6=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t4);}

/* k1978 in a1972 in loop in a1946 in k1468 in k1465 in k1462 in k1459 in k1453 in k1450 in ##net#io-ports in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_ccall f_1980(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1980,2,t0,t1);}
t2=(C_word)C_substring_copy(((C_word*)t0)[13],t1,((C_word*)((C_word*)t0)[12])[1],((C_word*)t0)[11],C_fix(0));
t3=C_mutate(((C_word *)((C_word*)t0)[12])+1,((C_word*)t0)[10]);
t4=(C_word)C_eqp(((C_word*)t0)[11],((C_word*)t0)[9]);
if(C_truep(t4)){
if(C_truep(((C_word*)t0)[8])){
/* tcp.scm: 430  ##sys#string-append */
t5=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,((C_word*)t0)[7],((C_word*)t0)[8],t1);}
else{
t5=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t1);}}
else{
t5=(C_word)C_eqp(((C_word*)t0)[11],((C_word*)t0)[10]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2002,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[12],tmp=(C_word)a,a+=10,tmp);
/* tcp.scm: 432  read-input */
t7=((C_word*)t0)[3];
f_1471(t7,t6);}
else{
t6=(C_word)C_slot(((C_word*)t0)[2],C_fix(4));
t7=(C_word)C_u_fixnum_plus(t6,C_fix(1));
t8=(C_word)C_i_set_i_slot(((C_word*)t0)[2],C_fix(4),t7);
if(C_truep(((C_word*)t0)[8])){
/* tcp.scm: 439  ##sys#string-append */
t9=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,((C_word*)t0)[7],((C_word*)t0)[8],t1);}
else{
t9=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t1);}}}}

/* k2000 in k1978 in a1972 in loop in a1946 in k1468 in k1465 in k1462 in k1459 in k1453 in k1450 in ##net#io-ports in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_ccall f_2002(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2002,2,t0,t1);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(((C_word*)((C_word*)t0)[9])[1],((C_word*)((C_word*)t0)[8])[1]))){
t2=((C_word*)t0)[7];
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?t2:lf[52]));}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2018,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[7])){
/* tcp.scm: 435  ##sys#string-append */
t3=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[7],((C_word*)t0)[2]);}
else{
t3=t2;
f_2018(2,t3,((C_word*)t0)[2]);}}}

/* k2016 in k2000 in k1978 in a1972 in loop in a1946 in k1468 in k1465 in k1462 in k1459 in k1453 in k1450 in ##net#io-ports in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_ccall f_2018(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_difference(((C_word*)t0)[5],((C_word*)t0)[4]);
/* tcp.scm: 435  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1957(t3,((C_word*)t0)[2],t1,t2);}

/* a1881 in k1468 in k1465 in k1462 in k1459 in k1453 in k1450 in ##net#io-ports in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_ccall f_1882(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_1882,6,t0,t1,t2,t3,t4,t5);}
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1888,a[2]=((C_word*)t0)[2],a[3]=t7,a[4]=t4,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp));
t9=((C_word*)t7)[1];
f_1888(t9,t1,t3,C_fix(0),t5);}

/* loop in a1881 in k1468 in k1465 in k1462 in k1459 in k1453 in k1450 in ##net#io-ports in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_fcall f_1888(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word *a;
loop:
a=C_alloc(8);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1888,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t3);}
else{
if(C_truep((C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[7])[1],((C_word*)((C_word*)t0)[6])[1]))){
t6=(C_word)C_u_fixnum_difference(((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[7])[1]);
t7=(C_word)C_fixnum_lessp(t2,t6);
t8=(C_truep(t7)?t2:t6);
t9=(C_word)C_u_fixnum_plus(((C_word*)((C_word*)t0)[7])[1],t8);
t10=(C_word)C_substring_copy(((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)((C_word*)t0)[7])[1],t9,t4);
t11=(C_word)C_u_fixnum_plus(((C_word*)((C_word*)t0)[7])[1],t8);
t12=C_mutate(((C_word *)((C_word*)t0)[7])+1,t11);
t13=(C_word)C_u_fixnum_difference(t2,t8);
t14=(C_word)C_u_fixnum_plus(t3,t8);
t15=(C_word)C_u_fixnum_plus(t4,t8);
/* tcp.scm: 410  loop */
t18=t1;
t19=t13;
t20=t14;
t21=t15;
t1=t18;
t2=t19;
t3=t20;
t4=t21;
goto loop;}
else{
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1936,a[2]=t4,a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* tcp.scm: 412  read-input */
t7=((C_word*)t0)[2];
f_1471(t7,t6);}}}

/* k1934 in loop in a1881 in k1468 in k1465 in k1462 in k1459 in k1453 in k1450 in ##net#io-ports in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_ccall f_1936(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(((C_word*)((C_word*)t0)[7])[1],C_fix(0));
if(C_truep(t2)){
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[5]);}
else{
/* tcp.scm: 415  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_1888(t3,((C_word*)t0)[6],((C_word*)t0)[3],((C_word*)t0)[5],((C_word*)t0)[2]);}}

/* a1838 in k1468 in k1465 in k1462 in k1459 in k1453 in k1450 in ##net#io-ports in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_ccall f_1839(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1839,2,t0,t1);}
if(C_truep(((C_word*)((C_word*)t0)[5])[1])){
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=C_set_block_item(((C_word*)t0)[5],0,C_SCHEME_TRUE);
t3=(C_truep((C_word)C_slot(((C_word*)t0)[4],C_fix(1)))?C_SCHEME_UNDEFINED:f_985(((C_word*)t0)[3],C_fix((C_word)SD_RECEIVE)));
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1853,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t5=f_975(((C_word*)t0)[3]);
t6=t4;
f_1853(t6,(C_word)C_eqp(C_fix(-1),t5));}
else{
t5=t4;
f_1853(t5,C_SCHEME_FALSE);}}}

/* k1851 in a1838 in k1468 in k1465 in k1462 in k1459 in k1453 in k1450 in ##net#io-ports in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_fcall f_1853(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1853,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1856,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 396  ##sys#update-errno */
t3=*((C_word*)lf[17]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k1854 in k1851 in a1838 in k1468 in k1465 in k1462 in k1459 in k1453 in k1450 in ##net#io-ports in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_ccall f_1856(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1856,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1863,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1867,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k1865 in k1854 in k1851 in a1838 in k1468 in k1465 in k1462 in k1459 in k1453 in k1450 in ##net#io-ports in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_ccall f_1867(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 399  ##sys#string-append */
t2=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[51],t1);}

/* k1861 in k1854 in k1851 in a1838 in k1468 in k1465 in k1462 in k1459 in k1453 in k1450 in ##net#io-ports in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_ccall f_1863(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 397  ##sys#signal-hook */
t2=*((C_word*)lf[12]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[13],t1,((C_word*)t0)[2]);}

/* a1803 in k1468 in k1465 in k1462 in k1459 in k1453 in k1450 in ##net#io-ports in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_ccall f_1804(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1804,2,t0,t1);}
t2=(C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[4])[1],((C_word*)((C_word*)t0)[3])[1]);
if(C_truep(t2)){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=f_1046(((C_word*)t0)[2]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1817,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_eqp(t3,C_fix(-1));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1826,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 385  ##sys#update-errno */
t7=*((C_word*)lf[17]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t6=t4;
f_1817(2,t6,C_SCHEME_UNDEFINED);}}}

/* k1824 in a1803 in k1468 in k1465 in k1462 in k1459 in k1453 in k1450 in ##net#io-ports in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_ccall f_1826(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1826,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1833,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1837,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k1835 in k1824 in a1803 in k1468 in k1465 in k1462 in k1459 in k1453 in k1450 in ##net#io-ports in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_ccall f_1837(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 388  ##sys#string-append */
t2=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[50],t1);}

/* k1831 in k1824 in a1803 in k1468 in k1465 in k1462 in k1459 in k1453 in k1450 in ##net#io-ports in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_ccall f_1833(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 386  ##sys#signal-hook */
t2=*((C_word*)lf[12]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[13],t1,((C_word*)t0)[2]);}

/* k1815 in a1803 in k1468 in k1465 in k1462 in k1459 in k1453 in k1450 in ##net#io-ports in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_ccall f_1817(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_eqp(((C_word*)t0)[2],C_fix(1)));}

/* a1781 in k1468 in k1465 in k1462 in k1459 in k1453 in k1450 in ##net#io-ports in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_ccall f_1782(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1782,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1786,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(((C_word*)((C_word*)t0)[5])[1],((C_word*)((C_word*)t0)[4])[1]))){
/* tcp.scm: 375  read-input */
t3=((C_word*)t0)[2];
f_1471(t3,t2);}
else{
t3=t2;
f_1786(2,t3,C_SCHEME_UNDEFINED);}}

/* k1784 in a1781 in k1468 in k1465 in k1462 in k1459 in k1453 in k1450 in ##net#io-ports in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_ccall f_1786(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(((C_word*)((C_word*)t0)[5])[1],((C_word*)((C_word*)t0)[4])[1]))){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_FILE);}
else{
t2=(C_word)C_subchar(((C_word*)t0)[2],((C_word*)((C_word*)t0)[5])[1]);
t3=(C_word)C_u_fixnum_plus(((C_word*)((C_word*)t0)[5])[1],C_fix(1));
t4=C_mutate(((C_word *)((C_word*)t0)[5])+1,t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t2);}}

/* k1542 in k1468 in k1465 in k1462 in k1459 in k1453 in k1450 in ##net#io-ports in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_ccall f_1544(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[26],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1544,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1545,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1640,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_truep(((C_word*)((C_word*)t0)[5])[1])?(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1746,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp):(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1766,a[2]=t2,tmp=(C_word)a,a+=3,tmp));
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1667,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[3],tmp=(C_word)a,a+=8,tmp);
t6=(C_truep(((C_word*)((C_word*)t0)[5])[1])?(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1730,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp):C_SCHEME_FALSE);
/* tcp.scm: 473  make-output-port */
t7=*((C_word*)lf[49]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t3,t4,t5,t6);}

/* f_1730 in k1542 in k1468 in k1465 in k1462 in k1459 in k1453 in k1450 in ##net#io-ports in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_ccall f_1730(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1730,2,t0,t1);}
t2=(C_word)C_block_size(((C_word*)((C_word*)t0)[3])[1]);
if(C_truep((C_word)C_fixnum_greaterp(t2,C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1740,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 497  output */
t4=((C_word*)t0)[2];
f_1545(t4,t3,((C_word*)((C_word*)t0)[3])[1]);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k1738 */
static void C_ccall f_1740(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,lf[48]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* a1666 in k1542 in k1468 in k1465 in k1462 in k1459 in k1453 in k1450 in ##net#io-ports in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_ccall f_1667(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1667,2,t0,t1);}
if(C_truep(((C_word*)((C_word*)t0)[7])[1])){
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=C_set_block_item(((C_word*)t0)[7],0,C_SCHEME_TRUE);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1675,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1714,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)((C_word*)t0)[3])[1])){
t5=(C_word)C_block_size(((C_word*)((C_word*)t0)[3])[1]);
t6=t4;
f_1714(t6,(C_word)C_fixnum_greaterp(t5,C_fix(0)));}
else{
t5=t4;
f_1714(t5,C_SCHEME_FALSE);}}}

/* k1712 in a1666 in k1542 in k1468 in k1465 in k1462 in k1459 in k1453 in k1450 in ##net#io-ports in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_fcall f_1714(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1714,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1717,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 487  output */
t3=((C_word*)t0)[2];
f_1545(t3,t2,((C_word*)((C_word*)t0)[4])[1]);}
else{
t2=((C_word*)t0)[3];
f_1675(t2,C_SCHEME_UNDEFINED);}}

/* k1715 in k1712 in a1666 in k1542 in k1468 in k1465 in k1462 in k1459 in k1453 in k1450 in ##net#io-ports in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_ccall f_1717(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,lf[47]);
t3=((C_word*)t0)[2];
f_1675(t3,t2);}

/* k1673 in a1666 in k1542 in k1468 in k1465 in k1462 in k1459 in k1453 in k1450 in ##net#io-ports in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_fcall f_1675(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1675,NULL,2,t0,t1);}
t2=(C_truep((C_word)C_slot(((C_word*)t0)[5],C_fix(2)))?C_SCHEME_UNDEFINED:f_985(((C_word*)t0)[4],C_fix((C_word)SD_SEND)));
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1684,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t4=f_975(((C_word*)t0)[4]);
t5=t3;
f_1684(t5,(C_word)C_eqp(C_fix(-1),t4));}
else{
t4=t3;
f_1684(t4,C_SCHEME_FALSE);}}

/* k1682 in k1673 in a1666 in k1542 in k1468 in k1465 in k1462 in k1459 in k1453 in k1450 in ##net#io-ports in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_fcall f_1684(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1684,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1687,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 491  ##sys#update-errno */
t3=*((C_word*)lf[17]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k1685 in k1682 in k1673 in a1666 in k1542 in k1468 in k1465 in k1462 in k1459 in k1453 in k1450 in ##net#io-ports in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_ccall f_1687(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1687,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1694,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1698,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k1696 in k1685 in k1682 in k1673 in a1666 in k1542 in k1468 in k1465 in k1462 in k1459 in k1453 in k1450 in ##net#io-ports in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_ccall f_1698(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 493  ##sys#string-append */
t2=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[46],t1);}

/* k1692 in k1685 in k1682 in k1673 in a1666 in k1542 in k1468 in k1465 in k1462 in k1459 in k1453 in k1450 in ##net#io-ports in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_ccall f_1694(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 492  ##sys#signal-hook */
t2=*((C_word*)lf[12]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[13],t1,((C_word*)t0)[2]);}

/* f_1766 in k1542 in k1468 in k1465 in k1462 in k1459 in k1453 in k1450 in ##net#io-ports in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_ccall f_1766(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1766,3,t0,t1,t2);}
t3=(C_word)C_block_size(t2);
if(C_truep((C_word)C_fixnum_greaterp(t3,C_fix(0)))){
/* tcp.scm: 482  output */
t4=((C_word*)t0)[2];
f_1545(t4,t1,t2);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* f_1746 in k1542 in k1468 in k1465 in k1462 in k1459 in k1453 in k1450 in ##net#io-ports in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_ccall f_1746(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1746,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1751,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* tcp.scm: 476  ##sys#string-append */
t4=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)((C_word*)t0)[4])[1],t2);}

/* k1749 */
static void C_ccall f_1751(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1751,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=(C_word)C_block_size(((C_word*)((C_word*)t0)[5])[1]);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[4]))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1760,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 478  output */
t5=((C_word*)t0)[2];
f_1545(t5,t4,((C_word*)((C_word*)t0)[5])[1]);}
else{
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k1758 in k1749 */
static void C_ccall f_1760(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,lf[45]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k1638 in k1542 in k1468 in k1465 in k1462 in k1459 in k1453 in k1450 in ##net#io-ports in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_ccall f_1640(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[4],C_fix(3),lf[42]);
t3=(C_word)C_i_setslot(t1,C_fix(3),lf[43]);
t4=(C_word)C_i_setslot(((C_word*)t0)[4],C_fix(7),lf[44]);
t5=(C_word)C_i_setslot(t1,C_fix(7),lf[44]);
t6=(C_word)C_i_setslot(((C_word*)t0)[4],C_fix(9),((C_word*)t0)[3]);
t7=(C_word)C_i_setslot(t1,C_fix(9),((C_word*)t0)[3]);
/* tcp.scm: 505  values */
C_values(4,0,((C_word*)t0)[2],((C_word*)t0)[4],t1);}

/* output in k1542 in k1468 in k1465 in k1462 in k1459 in k1453 in k1450 in ##net#io-ports in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_fcall f_1545(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1545,NULL,3,t0,t1,t2);}
t3=(C_word)C_block_size(t2);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1555,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=t2,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_1555(t7,t1,t3,C_fix(0));}

/* loop in output in k1542 in k1468 in k1465 in k1462 in k1459 in k1453 in k1450 in ##net#io-ports in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_fcall f_1555(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word *a;
loop:
a=C_alloc(7);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1555,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_fixnum_min(C_fix(8192),t2);
t5=((C_word*)t0)[5];
t6=((C_word*)t0)[4];
t7=t3;
t8=(C_truep(t6)?t6:C_SCHEME_FALSE);
t9=(C_word)stub122(C_SCHEME_UNDEFINED,t5,t8,t7,t4,C_fix(0));
t10=(C_word)C_eqp(C_fix(-1),t9);
if(C_truep(t10)){
t11=(C_word)C_eqp(C_fix((C_word)errno),C_fix((C_word)EWOULDBLOCK));
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1577,a[2]=((C_word*)t0)[5],a[3]=t3,a[4]=t2,a[5]=t1,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[2])){
t13=(C_word)C_fudge(C_fix(16));
t14=(C_word)C_u_fixnum_plus(t13,((C_word*)t0)[2]);
/* tcp.scm: 454  ##sys#thread-block-for-timeout! */
t15=*((C_word*)lf[38]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t12,*((C_word*)lf[9]+1),t14);}
else{
t13=t12;
f_1577(2,t13,C_SCHEME_UNDEFINED);}}
else{
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1609,a[2]=((C_word*)t0)[5],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 465  ##sys#update-errno */
t13=*((C_word*)lf[17]+1);
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,t12);}}
else{
if(C_truep((C_word)C_fixnum_lessp(t9,t2))){
t11=(C_word)C_u_fixnum_difference(t2,t9);
t12=(C_word)C_u_fixnum_plus(t3,t9);
/* tcp.scm: 471  loop */
t19=t1;
t20=t11;
t21=t12;
t1=t19;
t2=t20;
t3=t21;
goto loop;}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_UNDEFINED);}}}

/* k1607 in loop in output in k1542 in k1468 in k1465 in k1462 in k1459 in k1453 in k1450 in ##net#io-ports in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_ccall f_1609(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1609,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1616,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1620,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k1618 in k1607 in loop in output in k1542 in k1468 in k1465 in k1462 in k1459 in k1453 in k1450 in ##net#io-ports in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_ccall f_1620(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 468  ##sys#string-append */
t2=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[41],t1);}

/* k1614 in k1607 in loop in output in k1542 in k1468 in k1465 in k1462 in k1459 in k1453 in k1450 in ##net#io-ports in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_ccall f_1616(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 466  ##sys#signal-hook */
t2=*((C_word*)lf[12]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[13],t1,((C_word*)t0)[2]);}

/* k1575 in loop in output in k1542 in k1468 in k1465 in k1462 in k1459 in k1453 in k1450 in ##net#io-ports in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_ccall f_1577(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1577,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1580,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* tcp.scm: 457  ##sys#thread-block-for-i/o! */
t3=*((C_word*)lf[37]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,*((C_word*)lf[9]+1),((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k1578 in k1575 in loop in output in k1542 in k1468 in k1465 in k1462 in k1459 in k1453 in k1450 in ##net#io-ports in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_ccall f_1580(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1580,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1583,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* tcp.scm: 458  yield */
f_1066(t2);}

/* k1581 in k1578 in k1575 in loop in output in k1542 in k1468 in k1465 in k1462 in k1459 in k1453 in k1450 in ##net#io-ports in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_ccall f_1583(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1583,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1586,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_slot(*((C_word*)lf[9]+1),C_fix(13)))){
/* tcp.scm: 460  ##sys#signal-hook */
t3=*((C_word*)lf[12]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[13],lf[40],((C_word*)t0)[2]);}
else{
t3=t2;
f_1586(2,t3,C_SCHEME_UNDEFINED);}}

/* k1584 in k1581 in k1578 in k1575 in loop in output in k1542 in k1468 in k1465 in k1462 in k1459 in k1453 in k1450 in ##net#io-ports in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_ccall f_1586(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 463  loop */
t2=((C_word*)((C_word*)t0)[5])[1];
f_1555(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* read-input in k1468 in k1465 in k1462 in k1459 in k1453 in k1450 in ##net#io-ports in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_fcall f_1471(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1471,NULL,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1477,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp));
t5=((C_word*)t3)[1];
f_1477(t5,t1);}

/* loop in read-input in k1468 in k1465 in k1462 in k1459 in k1453 in k1450 in ##net#io-ports in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_fcall f_1477(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1477,NULL,2,t0,t1);}
t2=((C_word*)t0)[7];
t3=((C_word*)t0)[6];
t4=(C_truep(t3)?t3:C_SCHEME_FALSE);
t5=(C_word)stub85(C_SCHEME_UNDEFINED,t2,t4,C_fix(1024),C_fix(0));
t6=(C_word)C_eqp(C_fix(-1),t5);
if(C_truep(t6)){
t7=(C_word)C_eqp(C_fix((C_word)errno),C_fix((C_word)EWOULDBLOCK));
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1496,a[2]=((C_word*)t0)[7],a[3]=t1,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[4])){
t9=(C_word)C_fudge(C_fix(16));
t10=(C_word)C_u_fixnum_plus(t9,((C_word*)t0)[4]);
/* tcp.scm: 352  ##sys#thread-block-for-timeout! */
t11=*((C_word*)lf[38]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t8,*((C_word*)lf[9]+1),t10);}
else{
t9=t8;
f_1496(2,t9,C_SCHEME_UNDEFINED);}}
else{
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1528,a[2]=((C_word*)t0)[7],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 363  ##sys#update-errno */
t9=*((C_word*)lf[17]+1);
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}}
else{
t7=C_mutate(((C_word *)((C_word*)t0)[3])+1,t5);
t8=C_set_block_item(((C_word*)t0)[2],0,C_fix(0));
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}}

/* k1526 in loop in read-input in k1468 in k1465 in k1462 in k1459 in k1453 in k1450 in ##net#io-ports in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_ccall f_1528(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1528,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1535,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1539,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k1537 in k1526 in loop in read-input in k1468 in k1465 in k1462 in k1459 in k1453 in k1450 in ##net#io-ports in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_ccall f_1539(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 366  ##sys#string-append */
t2=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[39],t1);}

/* k1533 in k1526 in loop in read-input in k1468 in k1465 in k1462 in k1459 in k1453 in k1450 in ##net#io-ports in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_ccall f_1535(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 364  ##sys#signal-hook */
t2=*((C_word*)lf[12]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[13],t1,((C_word*)t0)[2]);}

/* k1494 in loop in read-input in k1468 in k1465 in k1462 in k1459 in k1453 in k1450 in ##net#io-ports in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_ccall f_1496(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1496,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1499,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* tcp.scm: 355  ##sys#thread-block-for-i/o! */
t3=*((C_word*)lf[37]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,*((C_word*)lf[9]+1),((C_word*)t0)[2],C_SCHEME_TRUE);}

/* k1497 in k1494 in loop in read-input in k1468 in k1465 in k1462 in k1459 in k1453 in k1450 in ##net#io-ports in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_ccall f_1499(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1499,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1502,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* tcp.scm: 356  yield */
f_1066(t2);}

/* k1500 in k1497 in k1494 in loop in read-input in k1468 in k1465 in k1462 in k1459 in k1453 in k1450 in ##net#io-ports in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_ccall f_1502(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1502,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1505,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_slot(*((C_word*)lf[9]+1),C_fix(13)))){
/* tcp.scm: 358  ##sys#signal-hook */
t3=*((C_word*)lf[12]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[13],lf[36],((C_word*)t0)[2]);}
else{
t3=t2;
f_1505(2,t3,C_SCHEME_UNDEFINED);}}

/* k1503 in k1500 in k1497 in k1494 in loop in read-input in k1468 in k1465 in k1462 in k1459 in k1453 in k1450 in ##net#io-ports in k1444 in k1440 in k1436 in k1432 in k1409 in k1025 in k941 in k938 in k935 */
static void C_ccall f_1505(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 361  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_1477(t2,((C_word*)t0)[2]);}

/* check in k1409 in k1025 in k941 in k938 in k935 */
static void C_fcall f_1417(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1417,NULL,2,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1419,a[2]=t2,tmp=(C_word)a,a+=3,tmp));}

/* f_1419 in check in k1409 in k1025 in k941 in k938 in k935 */
static void C_ccall f_1419(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1419,3,t0,t1,t2);}
t3=(C_truep(t2)?(C_word)C_i_check_exact_2(t2,((C_word*)t0)[2]):C_SCHEME_UNDEFINED);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}

/* tcp-close in k1025 in k941 in k938 in k935 */
static void C_ccall f_1376(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1376,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[25]);
t4=(C_word)C_slot(t2,C_fix(1));
t5=f_975(t4);
t6=(C_word)C_eqp(C_fix(-1),t5);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1392,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 304  ##sys#update-errno */
t8=*((C_word*)lf[17]+1);
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}
else{
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_SCHEME_UNDEFINED);}}

/* k1390 in tcp-close in k1025 in k941 in k938 in k935 */
static void C_ccall f_1392(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1392,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1399,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1403,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k1401 in k1390 in tcp-close in k1025 in k941 in k938 in k935 */
static void C_ccall f_1403(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 305  ##sys#string-append */
t2=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[29],t1);}

/* k1397 in k1390 in tcp-close in k1025 in k941 in k938 in k935 */
static void C_ccall f_1399(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 305  ##sys#signal-hook */
t2=*((C_word*)lf[12]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[13],lf[28],t1,((C_word*)t0)[2]);}

/* tcp-listener? in k1025 in k941 in k938 in k935 */
static void C_ccall f_1367(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1367,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep((C_word)C_blockp(t2))?(C_word)C_i_structurep(t2,lf[25]):C_SCHEME_FALSE));}

/* tcp-listen in k1025 in k941 in k938 in k935 */
static void C_ccall f_1272(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr3r,(void*)f_1272r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1272r(t0,t1,t2,t3);}}

static void C_ccall f_1272r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(9);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1274,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1317,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1322,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-w324360 */
t7=t6;
f_1322(t7,t1);}
else{
t7=(C_word)C_u_i_car(t3);
t8=(C_word)C_slot(t3,C_fix(1));
if(C_truep((C_word)C_i_nullp(t8))){
/* def-host325356 */
t9=t5;
f_1317(t9,t1,t7);}
else{
t9=(C_word)C_u_i_car(t8);
t10=(C_word)C_slot(t8,C_fix(1));
/* body322331 */
t11=t4;
f_1274(t11,t1,t7,t9);}}}

/* def-w324 in tcp-listen in k1025 in k941 in k938 in k935 */
static void C_fcall f_1322(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1322,NULL,2,t0,t1);}
/* def-host325356 */
t2=((C_word*)t0)[2];
f_1317(t2,t1,C_fix(10));}

/* def-host325 in tcp-listen in k1025 in k941 in k938 in k935 */
static void C_fcall f_1317(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1317,NULL,3,t0,t1,t2);}
/* body322331 */
t3=((C_word*)t0)[2];
f_1274(t3,t1,t2,C_SCHEME_FALSE);}

/* body322 in tcp-listen in k1025 in k941 in k938 in k935 */
static void C_fcall f_1274(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1274,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1280,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1286,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t4,t5);}

/* a1285 in body322 in tcp-listen in k1025 in k941 in k938 in k935 */
static void C_ccall f_1286(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1286,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact(((C_word*)t0)[3]);
t5=t2;
t6=((C_word*)t0)[3];
t7=(C_word)stub53(C_SCHEME_UNDEFINED,t5,t6);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1296,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t9=(C_word)C_eqp(C_fix(-1),t7);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1305,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t8,tmp=(C_word)a,a+=5,tmp);
/* tcp.scm: 292  ##sys#update-errno */
t11=*((C_word*)lf[17]+1);
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,t10);}
else{
t10=t8;
f_1296(2,t10,C_SCHEME_UNDEFINED);}}

/* k1303 in a1285 in body322 in tcp-listen in k1025 in k941 in k938 in k935 */
static void C_ccall f_1305(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1305,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1312,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1316,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k1314 in k1303 in a1285 in body322 in tcp-listen in k1025 in k941 in k938 in k935 */
static void C_ccall f_1316(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 293  ##sys#string-append */
t2=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[26],t1);}

/* k1310 in k1303 in a1285 in body322 in tcp-listen in k1025 in k941 in k938 in k935 */
static void C_ccall f_1312(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 293  ##sys#signal-hook */
t2=*((C_word*)lf[12]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[4],lf[13],lf[11],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1294 in a1285 in body322 in tcp-listen in k1025 in k941 in k938 in k935 */
static void C_ccall f_1296(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1296,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,2,lf[25],((C_word*)t0)[2]));}

/* a1279 in body322 in tcp-listen in k1025 in k941 in k938 in k935 */
static void C_ccall f_1280(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1280,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=C_fix((C_word)SOCK_STREAM);
t4=((C_word*)t0)[2];
t5=(C_word)C_i_check_exact(t2);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1173,a[2]=t4,a[3]=t2,a[4]=t1,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_fixnum_lessp(t2,C_fix(0));
t8=(C_truep(t7)?t7:(C_word)C_fixnum_greater_or_equal_p(t2,C_fix(65535)));
if(C_truep(t8)){
/* tcp.scm: 261  ##sys#signal-hook */
t9=*((C_word*)lf[12]+1);
((C_proc6)(void*)(*((C_word*)t9+1)))(6,t9,t6,lf[23],lf[11],lf[24],t2);}
else{
t9=t6;
f_1173(2,t9,C_SCHEME_UNDEFINED);}}

/* k1171 in a1279 in body322 in tcp-listen in k1025 in k941 in k938 in k935 */
static void C_ccall f_1173(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1173,2,t0,t1);}
t2=f_945(C_fix((C_word)AF_INET),((C_word*)t0)[5],C_fix(0));
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1179,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_eqp(C_fix((C_word)INVALID_SOCKET),t2);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1255,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* tcp.scm: 264  ##sys#update-errno */
t6=*((C_word*)lf[17]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t5=t3;
f_1179(2,t5,C_SCHEME_UNDEFINED);}}

/* k1253 in k1171 in a1279 in body322 in tcp-listen in k1025 in k941 in k938 in k935 */
static void C_ccall f_1255(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 265  ##sys#error */
t2=*((C_word*)lf[21]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],lf[22]);}

/* k1177 in k1171 in a1279 in body322 in tcp-listen in k1025 in k941 in k938 in k935 */
static void C_ccall f_1179(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1179,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1182,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1247,a[2]=((C_word*)t0)[5],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1248,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[5]);}

/* f_1248 in k1177 in k1171 in a1279 in body322 in tcp-listen in k1025 in k941 in k938 in k935 */
static void C_ccall f_1248(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1248,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)stub289(C_SCHEME_UNDEFINED,t2));}

/* k1245 in k1177 in k1171 in a1279 in body322 in tcp-listen in k1025 in k941 in k938 in k935 */
static void C_ccall f_1247(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1247,2,t0,t1);}
t2=(C_word)C_eqp(C_fix(-1),t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1232,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 271  ##sys#update-errno */
t4=*((C_word*)lf[17]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=((C_word*)t0)[3];
f_1182(2,t3,C_SCHEME_UNDEFINED);}}

/* k1230 in k1245 in k1177 in k1171 in a1279 in body322 in tcp-listen in k1025 in k941 in k938 in k935 */
static void C_ccall f_1232(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1232,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1239,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1243,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k1241 in k1230 in k1245 in k1177 in k1171 in a1279 in body322 in tcp-listen in k1025 in k941 in k938 in k935 */
static void C_ccall f_1243(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 272  ##sys#string-append */
t2=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[20],t1);}

/* k1237 in k1230 in k1245 in k1177 in k1171 in a1279 in body322 in tcp-listen in k1025 in k941 in k938 in k935 */
static void C_ccall f_1239(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 272  ##sys#signal-hook */
t2=*((C_word*)lf[12]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[13],lf[11],t1,((C_word*)t0)[2]);}

/* k1180 in k1177 in k1171 in a1279 in body322 in tcp-listen in k1025 in k941 in k938 in k935 */
static void C_ccall f_1182(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1182,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1185,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* tcp.scm: 273  make-string */
t3=*((C_word*)lf[19]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,C_fix((C_word)sizeof(struct sockaddr_in)));}

/* k1183 in k1180 in k1177 in k1171 in a1279 in body322 in tcp-listen in k1025 in k941 in k938 in k935 */
static void C_ccall f_1185(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1185,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1188,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1220,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* tcp.scm: 275  ##net#gethostaddr */
f_1052(t3,t1,((C_word*)t0)[2],((C_word*)t0)[3]);}
else{
t3=t1;
t4=(C_truep(t3)?t3:C_SCHEME_FALSE);
t5=t2;
f_1188(2,t5,(C_word)stub254(C_SCHEME_UNDEFINED,t4,((C_word*)t0)[3]));}}

/* k1218 in k1183 in k1180 in k1177 in k1171 in a1279 in body322 in tcp-listen in k1025 in k941 in k938 in k935 */
static void C_ccall f_1220(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_1188(2,t2,C_SCHEME_UNDEFINED);}
else{
/* tcp.scm: 276  ##sys#signal-hook */
t2=*((C_word*)lf[12]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[4],lf[13],lf[11],lf[18],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k1186 in k1183 in k1180 in k1177 in k1171 in a1279 in body322 in tcp-listen in k1025 in k941 in k938 in k935 */
static void C_ccall f_1188(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1188,2,t0,t1);}
t2=((C_word*)t0)[5];
t3=C_fix((C_word)sizeof(struct sockaddr_in));
t4=(C_truep(t2)?t2:C_SCHEME_FALSE);
t5=(C_word)stub41(C_SCHEME_UNDEFINED,((C_word*)t0)[4],t4,t3);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1194,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_eqp(C_fix(-1),t5);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1203,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=t6,tmp=(C_word)a,a+=5,tmp);
/* tcp.scm: 280  ##sys#update-errno */
t9=*((C_word*)lf[17]+1);
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}
else{
t8=t6;
f_1194(2,t8,C_SCHEME_UNDEFINED);}}

/* k1201 in k1186 in k1183 in k1180 in k1177 in k1171 in a1279 in body322 in tcp-listen in k1025 in k941 in k938 in k935 */
static void C_ccall f_1203(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1203,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1210,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1214,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k1212 in k1201 in k1186 in k1183 in k1180 in k1177 in k1171 in a1279 in body322 in tcp-listen in k1025 in k941 in k938 in k935 */
static void C_ccall f_1214(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 281  ##sys#string-append */
t2=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[15],t1);}

/* k1208 in k1201 in k1186 in k1183 in k1180 in k1177 in k1171 in a1279 in body322 in tcp-listen in k1025 in k941 in k938 in k935 */
static void C_ccall f_1210(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 281  ##sys#signal-hook */
t2=*((C_word*)lf[12]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[4],lf[13],lf[11],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1192 in k1186 in k1183 in k1180 in k1177 in k1171 in a1279 in body322 in tcp-listen in k1025 in k941 in k938 in k935 */
static void C_ccall f_1194(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 282  values */
C_values(4,0,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* yield in k1025 in k941 in k938 in k935 */
static void C_fcall f_1066(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1066,NULL,1,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1072,tmp=(C_word)a,a+=2,tmp);
/* tcp.scm: 220  ##sys#call-with-current-continuation */
C_call_cc(3,0,t1,t2);}

/* a1071 in yield in k1025 in k941 in k938 in k935 */
static void C_ccall f_1072(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1072,3,t0,t1,t2);}
t3=*((C_word*)lf[9]+1);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1081,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_i_setslot(t3,C_fix(1),t4);
/* tcp.scm: 224  ##sys#schedule */
t6=*((C_word*)lf[10]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t1);}

/* a1080 in a1071 in yield in k1025 in k941 in k938 in k935 */
static void C_ccall f_1081(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1081,2,t0,t1);}
/* tcp.scm: 223  return */
t2=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,C_SCHEME_UNDEFINED);}

/* ##net#gethostaddr in k1025 in k941 in k938 in k935 */
static void C_fcall f_1052(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1052,NULL,4,t1,t2,t3,t4);}
t5=(C_truep(t2)?t2:C_SCHEME_FALSE);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1061,a[2]=t4,a[3]=t5,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t3)){
/* ##sys#make-c-string */
t7=*((C_word*)lf[7]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t3);}
else{
t7=t6;
f_1061(2,t7,C_SCHEME_FALSE);}}

/* k1059 in ##net#gethostaddr in k1025 in k941 in k938 in k935 */
static void C_ccall f_1061(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub204(C_SCHEME_UNDEFINED,((C_word*)t0)[3],t1,((C_word*)t0)[2]));}

/* ##net#select in k1025 in k941 in k938 in k935 */
static C_word C_fcall f_1046(C_word t1){
C_word tmp;
C_word t2;
return((C_word)stub190(C_SCHEME_UNDEFINED,t1));}

/* ##net#getsockport in k941 in k938 in k935 */
static C_word C_fcall f_1011(C_word t1){
C_word tmp;
C_word t2;
return((C_word)stub149(C_SCHEME_UNDEFINED,t1));}

/* ##net#make-nonblocking in k941 in k938 in k935 */
static C_word C_fcall f_1002(C_word t1){
C_word tmp;
C_word t2;
return((C_word)stub135(C_SCHEME_UNDEFINED,t1));}

/* ##net#shutdown in k941 in k938 in k935 */
static C_word C_fcall f_985(C_word t1,C_word t2){
C_word tmp;
C_word t3;
return((C_word)stub98(C_SCHEME_UNDEFINED,t1,t2));}

/* ##net#close in k941 in k938 in k935 */
static C_word C_fcall f_975(C_word t1){
C_word tmp;
C_word t2;
return((C_word)stub76(C_SCHEME_UNDEFINED,t1));}

/* ##net#socket in k941 in k938 in k935 */
static C_word C_fcall f_945(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
return((C_word)stub31(C_SCHEME_UNDEFINED,t1,t2,t3));}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[213] = {
{"toplevel:tcp_scm",(void*)C_tcp_toplevel},
{"f_937:tcp_scm",(void*)f_937},
{"f_940:tcp_scm",(void*)f_940},
{"f_943:tcp_scm",(void*)f_943},
{"f_1027:tcp_scm",(void*)f_1027},
{"f_1411:tcp_scm",(void*)f_1411},
{"f_2639:tcp_scm",(void*)f_2639},
{"f_1434:tcp_scm",(void*)f_1434},
{"f_2635:tcp_scm",(void*)f_2635},
{"f_1438:tcp_scm",(void*)f_1438},
{"f_2631:tcp_scm",(void*)f_2631},
{"f_1442:tcp_scm",(void*)f_1442},
{"f_2627:tcp_scm",(void*)f_2627},
{"f_1446:tcp_scm",(void*)f_1446},
{"f_2616:tcp_scm",(void*)f_2616},
{"f_2596:tcp_scm",(void*)f_2596},
{"f_2600:tcp_scm",(void*)f_2600},
{"f_2607:tcp_scm",(void*)f_2607},
{"f_2567:tcp_scm",(void*)f_2567},
{"f_2594:tcp_scm",(void*)f_2594},
{"f_2590:tcp_scm",(void*)f_2590},
{"f_2580:tcp_scm",(void*)f_2580},
{"f_2519:tcp_scm",(void*)f_2519},
{"f_2523:tcp_scm",(void*)f_2523},
{"f_2526:tcp_scm",(void*)f_2526},
{"f_2565:tcp_scm",(void*)f_2565},
{"f_2561:tcp_scm",(void*)f_2561},
{"f_2536:tcp_scm",(void*)f_2536},
{"f_2554:tcp_scm",(void*)f_2554},
{"f_2550:tcp_scm",(void*)f_2550},
{"f_2543:tcp_scm",(void*)f_2543},
{"f_2471:tcp_scm",(void*)f_2471},
{"f_2475:tcp_scm",(void*)f_2475},
{"f_2478:tcp_scm",(void*)f_2478},
{"f_2485:tcp_scm",(void*)f_2485},
{"f_2517:tcp_scm",(void*)f_2517},
{"f_2513:tcp_scm",(void*)f_2513},
{"f_2488:tcp_scm",(void*)f_2488},
{"f_2492:tcp_scm",(void*)f_2492},
{"f_2506:tcp_scm",(void*)f_2506},
{"f_2502:tcp_scm",(void*)f_2502},
{"f_2495:tcp_scm",(void*)f_2495},
{"f_2453:tcp_scm",(void*)f_2453},
{"f_2457:tcp_scm",(void*)f_2457},
{"f_2213:tcp_scm",(void*)f_2213},
{"f_2220:tcp_scm",(void*)f_2220},
{"f_2436:tcp_scm",(void*)f_2436},
{"f_2430:tcp_scm",(void*)f_2430},
{"f_1096:tcp_scm",(void*)f_1096},
{"f_1119:tcp_scm",(void*)f_1119},
{"f_1123:tcp_scm",(void*)f_1123},
{"f_1034:tcp_scm",(void*)f_1034},
{"f_1038:tcp_scm",(void*)f_1038},
{"f_1135:tcp_scm",(void*)f_1135},
{"f_1146:tcp_scm",(void*)f_1146},
{"f_1142:tcp_scm",(void*)f_1142},
{"f_1129:tcp_scm",(void*)f_1129},
{"f_2422:tcp_scm",(void*)f_2422},
{"f_2226:tcp_scm",(void*)f_2226},
{"f_2232:tcp_scm",(void*)f_2232},
{"f_2408:tcp_scm",(void*)f_2408},
{"f_2419:tcp_scm",(void*)f_2419},
{"f_2415:tcp_scm",(void*)f_2415},
{"f_2258:tcp_scm",(void*)f_2258},
{"f_2399:tcp_scm",(void*)f_2399},
{"f_2261:tcp_scm",(void*)f_2261},
{"f_2385:tcp_scm",(void*)f_2385},
{"f_2396:tcp_scm",(void*)f_2396},
{"f_2392:tcp_scm",(void*)f_2392},
{"f_2264:tcp_scm",(void*)f_2264},
{"f_2321:tcp_scm",(void*)f_2321},
{"f_2328:tcp_scm",(void*)f_2328},
{"f_2337:tcp_scm",(void*)f_2337},
{"f_2340:tcp_scm",(void*)f_2340},
{"f_2343:tcp_scm",(void*)f_2343},
{"f_2346:tcp_scm",(void*)f_2346},
{"f_2267:tcp_scm",(void*)f_2267},
{"f_2307:tcp_scm",(void*)f_2307},
{"f_2303:tcp_scm",(void*)f_2303},
{"f_2290:tcp_scm",(void*)f_2290},
{"f_2286:tcp_scm",(void*)f_2286},
{"f_2273:tcp_scm",(void*)f_2273},
{"f_2237:tcp_scm",(void*)f_2237},
{"f_2244:tcp_scm",(void*)f_2244},
{"f_2255:tcp_scm",(void*)f_2255},
{"f_2251:tcp_scm",(void*)f_2251},
{"f_2168:tcp_scm",(void*)f_2168},
{"f_2187:tcp_scm",(void*)f_2187},
{"f_2198:tcp_scm",(void*)f_2198},
{"f_2194:tcp_scm",(void*)f_2194},
{"f_2178:tcp_scm",(void*)f_2178},
{"f_2082:tcp_scm",(void*)f_2082},
{"f_2092:tcp_scm",(void*)f_2092},
{"f_2097:tcp_scm",(void*)f_2097},
{"f_2133:tcp_scm",(void*)f_2133},
{"f_2136:tcp_scm",(void*)f_2136},
{"f_2139:tcp_scm",(void*)f_2139},
{"f_2142:tcp_scm",(void*)f_2142},
{"f_2119:tcp_scm",(void*)f_2119},
{"f_2130:tcp_scm",(void*)f_2130},
{"f_2126:tcp_scm",(void*)f_2126},
{"f_2110:tcp_scm",(void*)f_2110},
{"f_1448:tcp_scm",(void*)f_1448},
{"f_2069:tcp_scm",(void*)f_2069},
{"f_2080:tcp_scm",(void*)f_2080},
{"f_2076:tcp_scm",(void*)f_2076},
{"f_1452:tcp_scm",(void*)f_1452},
{"f_1455:tcp_scm",(void*)f_1455},
{"f_1461:tcp_scm",(void*)f_1461},
{"f_1464:tcp_scm",(void*)f_1464},
{"f_1467:tcp_scm",(void*)f_1467},
{"f_1470:tcp_scm",(void*)f_1470},
{"f_1947:tcp_scm",(void*)f_1947},
{"f_1957:tcp_scm",(void*)f_1957},
{"f_2045:tcp_scm",(void*)f_2045},
{"f_1973:tcp_scm",(void*)f_1973},
{"f_1980:tcp_scm",(void*)f_1980},
{"f_2002:tcp_scm",(void*)f_2002},
{"f_2018:tcp_scm",(void*)f_2018},
{"f_1882:tcp_scm",(void*)f_1882},
{"f_1888:tcp_scm",(void*)f_1888},
{"f_1936:tcp_scm",(void*)f_1936},
{"f_1839:tcp_scm",(void*)f_1839},
{"f_1853:tcp_scm",(void*)f_1853},
{"f_1856:tcp_scm",(void*)f_1856},
{"f_1867:tcp_scm",(void*)f_1867},
{"f_1863:tcp_scm",(void*)f_1863},
{"f_1804:tcp_scm",(void*)f_1804},
{"f_1826:tcp_scm",(void*)f_1826},
{"f_1837:tcp_scm",(void*)f_1837},
{"f_1833:tcp_scm",(void*)f_1833},
{"f_1817:tcp_scm",(void*)f_1817},
{"f_1782:tcp_scm",(void*)f_1782},
{"f_1786:tcp_scm",(void*)f_1786},
{"f_1544:tcp_scm",(void*)f_1544},
{"f_1730:tcp_scm",(void*)f_1730},
{"f_1740:tcp_scm",(void*)f_1740},
{"f_1667:tcp_scm",(void*)f_1667},
{"f_1714:tcp_scm",(void*)f_1714},
{"f_1717:tcp_scm",(void*)f_1717},
{"f_1675:tcp_scm",(void*)f_1675},
{"f_1684:tcp_scm",(void*)f_1684},
{"f_1687:tcp_scm",(void*)f_1687},
{"f_1698:tcp_scm",(void*)f_1698},
{"f_1694:tcp_scm",(void*)f_1694},
{"f_1766:tcp_scm",(void*)f_1766},
{"f_1746:tcp_scm",(void*)f_1746},
{"f_1751:tcp_scm",(void*)f_1751},
{"f_1760:tcp_scm",(void*)f_1760},
{"f_1640:tcp_scm",(void*)f_1640},
{"f_1545:tcp_scm",(void*)f_1545},
{"f_1555:tcp_scm",(void*)f_1555},
{"f_1609:tcp_scm",(void*)f_1609},
{"f_1620:tcp_scm",(void*)f_1620},
{"f_1616:tcp_scm",(void*)f_1616},
{"f_1577:tcp_scm",(void*)f_1577},
{"f_1580:tcp_scm",(void*)f_1580},
{"f_1583:tcp_scm",(void*)f_1583},
{"f_1586:tcp_scm",(void*)f_1586},
{"f_1471:tcp_scm",(void*)f_1471},
{"f_1477:tcp_scm",(void*)f_1477},
{"f_1528:tcp_scm",(void*)f_1528},
{"f_1539:tcp_scm",(void*)f_1539},
{"f_1535:tcp_scm",(void*)f_1535},
{"f_1496:tcp_scm",(void*)f_1496},
{"f_1499:tcp_scm",(void*)f_1499},
{"f_1502:tcp_scm",(void*)f_1502},
{"f_1505:tcp_scm",(void*)f_1505},
{"f_1417:tcp_scm",(void*)f_1417},
{"f_1419:tcp_scm",(void*)f_1419},
{"f_1376:tcp_scm",(void*)f_1376},
{"f_1392:tcp_scm",(void*)f_1392},
{"f_1403:tcp_scm",(void*)f_1403},
{"f_1399:tcp_scm",(void*)f_1399},
{"f_1367:tcp_scm",(void*)f_1367},
{"f_1272:tcp_scm",(void*)f_1272},
{"f_1322:tcp_scm",(void*)f_1322},
{"f_1317:tcp_scm",(void*)f_1317},
{"f_1274:tcp_scm",(void*)f_1274},
{"f_1286:tcp_scm",(void*)f_1286},
{"f_1305:tcp_scm",(void*)f_1305},
{"f_1316:tcp_scm",(void*)f_1316},
{"f_1312:tcp_scm",(void*)f_1312},
{"f_1296:tcp_scm",(void*)f_1296},
{"f_1280:tcp_scm",(void*)f_1280},
{"f_1173:tcp_scm",(void*)f_1173},
{"f_1255:tcp_scm",(void*)f_1255},
{"f_1179:tcp_scm",(void*)f_1179},
{"f_1248:tcp_scm",(void*)f_1248},
{"f_1247:tcp_scm",(void*)f_1247},
{"f_1232:tcp_scm",(void*)f_1232},
{"f_1243:tcp_scm",(void*)f_1243},
{"f_1239:tcp_scm",(void*)f_1239},
{"f_1182:tcp_scm",(void*)f_1182},
{"f_1185:tcp_scm",(void*)f_1185},
{"f_1220:tcp_scm",(void*)f_1220},
{"f_1188:tcp_scm",(void*)f_1188},
{"f_1203:tcp_scm",(void*)f_1203},
{"f_1214:tcp_scm",(void*)f_1214},
{"f_1210:tcp_scm",(void*)f_1210},
{"f_1194:tcp_scm",(void*)f_1194},
{"f_1066:tcp_scm",(void*)f_1066},
{"f_1072:tcp_scm",(void*)f_1072},
{"f_1081:tcp_scm",(void*)f_1081},
{"f_1052:tcp_scm",(void*)f_1052},
{"f_1061:tcp_scm",(void*)f_1061},
{"f_1046:tcp_scm",(void*)f_1046},
{"f_1011:tcp_scm",(void*)f_1011},
{"f_1002:tcp_scm",(void*)f_1002},
{"f_985:tcp_scm",(void*)f_985},
{"f_975:tcp_scm",(void*)f_975},
{"f_945:tcp_scm",(void*)f_945},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
