/* Generated from csc.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2009-03-24 10:49
   Version 4.0.0 - SVN rev. 13887
   windows-mingw32-x86 [ manyargs dload ptables applyhook ]
   compiled 2009-03-24 on LENOVO-1 (MINGW32_NT-6.0)
   command line: csc.scm -no-trace -optimize-level 2 -include-path . -include-path ./ -feature debugbuild -no-lambda-info -inline -local -output-file csc.c
   used units: library eval data_structures ports extras srfi_69 data_structures ports srfi_1 srfi_13 utils files extras
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_69_toplevel)
C_externimport void C_ccall C_srfi_69_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_1_toplevel)
C_externimport void C_ccall C_srfi_1_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_13_toplevel)
C_externimport void C_ccall C_srfi_13_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_utils_toplevel)
C_externimport void C_ccall C_utils_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_files_toplevel)
C_externimport void C_ccall C_files_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[366];
static double C_possibly_force_alignment;


C_noret_decl(C_toplevel)
C_externexport void C_ccall C_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_890)
static void C_ccall f_890(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_893)
static void C_ccall f_893(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_896)
static void C_ccall f_896(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_899)
static void C_ccall f_899(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_902)
static void C_ccall f_902(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_905)
static void C_ccall f_905(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_908)
static void C_ccall f_908(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_911)
static void C_ccall f_911(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_914)
static void C_ccall f_914(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_917)
static void C_ccall f_917(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_920)
static void C_ccall f_920(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_923)
static void C_ccall f_923(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_926)
static void C_ccall f_926(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3692)
static void C_ccall f_3692(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3688)
static void C_ccall f_3688(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3684)
static void C_ccall f_3684(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3680)
static void C_ccall f_3680(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3676)
static void C_ccall f_3676(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_942)
static void C_fcall f_942(C_word t0,C_word t1) C_noret;
C_noret_decl(f_959)
static void C_ccall f_959(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_963)
static void C_ccall f_963(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3660)
static void C_ccall f_3660(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3656)
static void C_ccall f_3656(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_998)
static void C_ccall f_998(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3642)
static void C_ccall f_3642(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3646)
static void C_ccall f_3646(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3638)
static void C_ccall f_3638(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3634)
static void C_ccall f_3634(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1002)
static void C_ccall f_1002(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3624)
static void C_ccall f_3624(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1006)
static void C_ccall f_1006(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3614)
static void C_ccall f_3614(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1010)
static void C_ccall f_1010(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3601)
static void C_ccall f_3601(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1014)
static void C_ccall f_1014(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3588)
static void C_ccall f_3588(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1018)
static void C_ccall f_1018(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1050)
static void C_ccall f_1050(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1054)
static void C_ccall f_1054(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3567)
static void C_ccall f_3567(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1059)
static void C_ccall f_1059(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3557)
static void C_ccall f_3557(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1064)
static void C_ccall f_1064(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1090)
static void C_ccall f_1090(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1094)
static void C_ccall f_1094(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3531)
static void C_ccall f_3531(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3535)
static void C_ccall f_3535(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3527)
static void C_ccall f_3527(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3523)
static void C_ccall f_3523(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3519)
static void C_ccall f_3519(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3515)
static void C_ccall f_3515(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1102)
static void C_fcall f_1102(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3498)
static void C_ccall f_3498(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3502)
static void C_ccall f_3502(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3494)
static void C_ccall f_3494(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3490)
static void C_ccall f_3490(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3486)
static void C_ccall f_3486(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3482)
static void C_ccall f_3482(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1110)
static void C_fcall f_1110(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3469)
static void C_ccall f_3469(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1119)
static void C_ccall f_1119(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3458)
static void C_ccall f_3458(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3454)
static void C_ccall f_3454(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1127)
static void C_fcall f_1127(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3441)
static void C_ccall f_3441(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1135)
static void C_ccall f_1135(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3434)
static void C_ccall f_3434(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3408)
static void C_ccall f_3408(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3424)
static void C_ccall f_3424(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3420)
static void C_ccall f_3420(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3416)
static void C_ccall f_3416(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3412)
static void C_ccall f_3412(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3401)
static void C_ccall f_3401(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3397)
static void C_ccall f_3397(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3387)
static void C_ccall f_3387(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3383)
static void C_ccall f_3383(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1140)
static void C_fcall f_1140(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3370)
static void C_ccall f_3370(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3366)
static void C_ccall f_3366(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3362)
static void C_ccall f_3362(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1238)
static void C_fcall f_1238(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1436)
static void C_ccall f_1436(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1956)
static void C_fcall f_1956(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2197)
static void C_fcall f_2197(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2200)
static void C_fcall f_2200(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2203)
static void C_fcall f_2203(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2585)
static void C_ccall f_2585(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2254)
static void C_fcall f_2254(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2263)
static void C_fcall f_2263(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2440)
static void C_ccall f_2440(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2548)
static void C_ccall f_2548(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2554)
static void C_ccall f_2554(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2451)
static void C_ccall f_2451(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2462)
static void C_ccall f_2462(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2538)
static void C_ccall f_2538(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2530)
static void C_ccall f_2530(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2513)
static void C_ccall f_2513(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2489)
static void C_fcall f_2489(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2494)
static void C_ccall f_2494(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2476)
static void C_ccall f_2476(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2445)
static void C_ccall f_2445(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2410)
static void C_ccall f_2410(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2341)
static void C_fcall f_2341(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2393)
static void C_ccall f_2393(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2389)
static void C_ccall f_2389(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2374)
static void C_ccall f_2374(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2372)
static void C_ccall f_2372(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2368)
static void C_ccall f_2368(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2345)
static void C_ccall f_2345(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2331)
static void C_ccall f_2331(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2318)
static void C_ccall f_2318(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2301)
static void C_ccall f_2301(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2287)
static void C_ccall f_2287(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2273)
static void C_ccall f_2273(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2235)
static void C_ccall f_2235(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2241)
static void C_ccall f_2241(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2244)
static void C_ccall f_2244(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2190)
static void C_ccall f_2190(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2194)
static void C_ccall f_2194(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2144)
static void C_ccall f_2144(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2174)
static void C_ccall f_2174(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2166)
static void C_ccall f_2166(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2154)
static void C_ccall f_2154(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2133)
static void C_ccall f_2133(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2108)
static void C_ccall f_2108(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2120)
static void C_ccall f_2120(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2112)
static void C_ccall f_2112(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2095)
static void C_ccall f_2095(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2069)
static void C_ccall f_2069(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2081)
static void C_ccall f_2081(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2073)
static void C_ccall f_2073(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2048)
static void C_ccall f_2048(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2052)
static void C_ccall f_2052(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2031)
static void C_ccall f_2031(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2014)
static void C_ccall f_2014(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1997)
static void C_ccall f_1997(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1980)
static void C_ccall f_1980(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1939)
static void C_ccall f_1939(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1929)
static void C_ccall f_1929(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1919)
static void C_ccall f_1919(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1909)
static void C_ccall f_1909(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1899)
static void C_ccall f_1899(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1889)
static void C_ccall f_1889(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1879)
static void C_ccall f_1879(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1858)
static void C_ccall f_1858(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1834)
static void C_ccall f_1834(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1845)
static void C_ccall f_1845(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1837)
static void C_fcall f_1837(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1821)
static void C_ccall f_1821(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1810)
static void C_ccall f_1810(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1770)
static void C_ccall f_1770(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1774)
static void C_ccall f_1774(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1777)
static void C_ccall f_1777(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1738)
static void C_ccall f_1738(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1742)
static void C_ccall f_1742(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1745)
static void C_ccall f_1745(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1647)
static void C_ccall f_1647(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1665)
static void C_ccall f_1665(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1650)
static void C_fcall f_1650(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1590)
static void C_ccall f_1590(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1578)
static void C_ccall f_1578(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1566)
static void C_ccall f_1566(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1554)
static void C_ccall f_1554(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1528)
static void C_ccall f_1528(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1517)
static void C_ccall f_1517(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1486)
static void C_ccall f_1486(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1479)
static void C_ccall f_1479(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1470)
static void C_ccall f_1470(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1463)
static void C_ccall f_1463(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1451)
static void C_ccall f_1451(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1439)
static void C_ccall f_1439(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1249)
static void C_ccall f_1249(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1253)
static void C_ccall f_1253(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1427)
static void C_ccall f_1427(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1394)
static void C_ccall f_1394(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1420)
static void C_ccall f_1420(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1397)
static void C_ccall f_1397(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1413)
static void C_ccall f_1413(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1400)
static void C_ccall f_1400(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1403)
static void C_ccall f_1403(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1256)
static void C_ccall f_1256(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1357)
static void C_fcall f_1357(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1367)
static void C_ccall f_1367(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1360)
static void C_fcall f_1360(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2663)
static void C_ccall f_2663(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2667)
static void C_ccall f_2667(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2708)
static void C_ccall f_2708(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2735)
static void C_ccall f_2735(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2716)
static void C_fcall f_2716(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2724)
static void C_ccall f_2724(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2720)
static void C_ccall f_2720(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2712)
static void C_ccall f_2712(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2704)
static void C_ccall f_2704(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2700)
static void C_ccall f_2700(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2696)
static void C_ccall f_2696(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2670)
static void C_ccall f_2670(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2674)
static void C_ccall f_2674(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2678)
static void C_ccall f_2678(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2655)
static void C_ccall f_2655(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1319)
static void C_ccall f_1319(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1322)
static void C_ccall f_1322(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1329)
static void C_ccall f_1329(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1259)
static void C_ccall f_1259(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2775)
static void C_ccall f_2775(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2779)
static void C_ccall f_2779(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2816)
static void C_ccall f_2816(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2828)
static void C_ccall f_2828(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2820)
static void C_ccall f_2820(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2824)
static void C_ccall f_2824(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2804)
static void C_ccall f_2804(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2800)
static void C_ccall f_2800(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2782)
static void C_ccall f_2782(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2759)
static void C_ccall f_2759(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2773)
static void C_ccall f_2773(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2763)
static void C_ccall f_2763(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1265)
static void C_ccall f_1265(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1280)
static void C_ccall f_1280(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1305)
static void C_ccall f_1305(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1313)
static void C_ccall f_1313(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1309)
static void C_ccall f_1309(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1297)
static void C_ccall f_1297(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1293)
static void C_ccall f_1293(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1271)
static void C_ccall f_1271(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2976)
static void C_ccall f_2976(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2976)
static void C_ccall f_2976r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2970)
static void C_ccall f_2970(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2968)
static void C_ccall f_2968(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2964)
static void C_ccall f_2964(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2855)
static void C_ccall f_2855(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2858)
static void C_ccall f_2858(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2952)
static void C_ccall f_2952(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2956)
static void C_ccall f_2956(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2960)
static void C_ccall f_2960(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2944)
static void C_ccall f_2944(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2936)
static void C_ccall f_2936(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2932)
static void C_ccall f_2932(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2928)
static void C_ccall f_2928(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2861)
static void C_ccall f_2861(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2873)
static void C_fcall f_2873(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2906)
static void C_ccall f_2906(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2902)
static void C_ccall f_2902(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2898)
static void C_ccall f_2898(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2894)
static void C_ccall f_2894(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2890)
static void C_ccall f_2890(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2886)
static void C_ccall f_2886(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2864)
static void C_ccall f_2864(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1209)
static void C_fcall f_1209(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1214)
static void C_ccall f_1214(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1218)
static void C_ccall f_1218(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1170)
static void C_fcall f_1170(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1188)
static void C_ccall f_1188(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1163)
static void C_fcall f_1163(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1168)
static void C_ccall f_1168(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3352)
static void C_ccall f_3352(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3358)
static void C_ccall f_3358(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3355)
static void C_ccall f_3355(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3336)
static void C_ccall f_3336(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3340)
static void C_ccall f_3340(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3305)
static void C_fcall f_3305(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3309)
static void C_ccall f_3309(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3312)
static void C_ccall f_3312(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3316)
static void C_ccall f_3316(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3319)
static void C_ccall f_3319(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3280)
static void C_ccall f_3280(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3292)
static void C_ccall f_3292(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3287)
static void C_ccall f_3287(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3231)
static void C_ccall f_3231(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3233)
static void C_fcall f_3233(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3263)
static void C_fcall f_3263(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3270)
static void C_ccall f_3270(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3256)
static void C_ccall f_3256(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3227)
static void C_ccall f_3227(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3213)
static void C_ccall f_3213(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3223)
static void C_ccall f_3223(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3131)
static void C_fcall f_3131(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3135)
static void C_ccall f_3135(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3183)
static void C_ccall f_3183(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3183)
static void C_ccall f_3183r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3177)
static void C_ccall f_3177(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3146)
static void C_ccall f_3146(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3142)
static void C_ccall f_3142(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3079)
static void C_fcall f_3079(C_word t0) C_noret;
C_noret_decl(f_3125)
static void C_ccall f_3125(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3125)
static void C_ccall f_3125r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3119)
static void C_ccall f_3119(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3117)
static void C_ccall f_3117(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3113)
static void C_ccall f_3113(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3087)
static void C_ccall f_3087(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2982)
static void C_fcall f_2982(C_word t0) C_noret;
C_noret_decl(f_2986)
static void C_ccall f_2986(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2997)
static void C_fcall f_2997(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3018)
static void C_ccall f_3018(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3056)
static void C_ccall f_3056(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3038)
static void C_fcall f_3038(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3042)
static void C_fcall f_3042(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3011)
static void C_ccall f_3011(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3015)
static void C_ccall f_3015(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2830)
static void C_fcall f_2830(C_word t0) C_noret;
C_noret_decl(f_2842)
static void C_ccall f_2842(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2838)
static void C_ccall f_2838(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_986)
static void C_ccall f_986(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_994)
static void C_ccall f_994(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_973)
static void C_fcall f_973(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_944)
static void C_fcall f_944(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_955)
static void C_ccall f_955(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_948)
static void C_ccall f_948(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_942)
static void C_fcall trf_942(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_942(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_942(t0,t1);}

C_noret_decl(trf_1102)
static void C_fcall trf_1102(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1102(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1102(t0,t1);}

C_noret_decl(trf_1110)
static void C_fcall trf_1110(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1110(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1110(t0,t1);}

C_noret_decl(trf_1127)
static void C_fcall trf_1127(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1127(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1127(t0,t1);}

C_noret_decl(trf_1140)
static void C_fcall trf_1140(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1140(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1140(t0,t1);}

C_noret_decl(trf_1238)
static void C_fcall trf_1238(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1238(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1238(t0,t1,t2);}

C_noret_decl(trf_1956)
static void C_fcall trf_1956(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1956(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1956(t0,t1);}

C_noret_decl(trf_2197)
static void C_fcall trf_2197(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2197(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2197(t0,t1);}

C_noret_decl(trf_2200)
static void C_fcall trf_2200(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2200(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2200(t0,t1);}

C_noret_decl(trf_2203)
static void C_fcall trf_2203(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2203(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2203(t0,t1);}

C_noret_decl(trf_2254)
static void C_fcall trf_2254(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2254(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2254(t0,t1);}

C_noret_decl(trf_2263)
static void C_fcall trf_2263(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2263(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2263(t0,t1);}

C_noret_decl(trf_2489)
static void C_fcall trf_2489(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2489(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2489(t0,t1);}

C_noret_decl(trf_2341)
static void C_fcall trf_2341(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2341(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2341(t0,t1);}

C_noret_decl(trf_1837)
static void C_fcall trf_1837(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1837(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1837(t0,t1);}

C_noret_decl(trf_1650)
static void C_fcall trf_1650(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1650(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1650(t0,t1);}

C_noret_decl(trf_1357)
static void C_fcall trf_1357(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1357(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1357(t0,t1);}

C_noret_decl(trf_1360)
static void C_fcall trf_1360(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1360(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1360(t0,t1);}

C_noret_decl(trf_2716)
static void C_fcall trf_2716(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2716(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2716(t0,t1);}

C_noret_decl(trf_2873)
static void C_fcall trf_2873(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2873(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2873(t0,t1);}

C_noret_decl(trf_1209)
static void C_fcall trf_1209(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1209(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1209(t0,t1);}

C_noret_decl(trf_1170)
static void C_fcall trf_1170(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1170(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1170(t0,t1,t2,t3);}

C_noret_decl(trf_1163)
static void C_fcall trf_1163(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1163(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1163(t0,t1);}

C_noret_decl(trf_3305)
static void C_fcall trf_3305(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3305(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3305(t0,t1);}

C_noret_decl(trf_3233)
static void C_fcall trf_3233(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3233(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3233(t0,t1,t2);}

C_noret_decl(trf_3263)
static void C_fcall trf_3263(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3263(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3263(t0,t1);}

C_noret_decl(trf_3131)
static void C_fcall trf_3131(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3131(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3131(t0,t1);}

C_noret_decl(trf_3079)
static void C_fcall trf_3079(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3079(void *dummy){
C_word t0=C_pick(0);
C_adjust_stack(-1);
f_3079(t0);}

C_noret_decl(trf_2982)
static void C_fcall trf_2982(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2982(void *dummy){
C_word t0=C_pick(0);
C_adjust_stack(-1);
f_2982(t0);}

C_noret_decl(trf_2997)
static void C_fcall trf_2997(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2997(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_2997(t0,t1,t2,t3,t4);}

C_noret_decl(trf_3038)
static void C_fcall trf_3038(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3038(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3038(t0,t1);}

C_noret_decl(trf_3042)
static void C_fcall trf_3042(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3042(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3042(t0,t1);}

C_noret_decl(trf_2830)
static void C_fcall trf_2830(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2830(void *dummy){
C_word t0=C_pick(0);
C_adjust_stack(-1);
f_2830(t0);}

C_noret_decl(trf_973)
static void C_fcall trf_973(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_973(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_973(t0,t1,t2,t3);}

C_noret_decl(trf_944)
static void C_fcall trf_944(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_944(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_944(t0,t1,t2);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr2rv)
static void C_fcall tr2rv(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2rv(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n+1);
t2=C_restore_rest_vector(a,n);
(k)(t0,t1,t2);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_main_entry_point
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("toplevel"));
C_resize_stack(131072);
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(2432)){
C_save(t1);
C_rereclaim2(2432*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,366);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[2]=C_h_intern(&lf[2],7,"mingw32");
lf[4]=C_h_intern(&lf[4],4,"msvc");
lf[6]=C_h_intern(&lf[6],6,"macosx");
lf[10]=C_h_intern(&lf[10],4,"exit");
lf[11]=C_h_intern(&lf[11],7,"fprintf");
lf[12]=C_decode_literal(C_heaptop,"\376B\000\000\011csc: ~\077~%");
lf[13]=C_h_intern(&lf[13],18,"current-error-port");
lf[16]=C_decode_literal(C_heaptop,"\376B\000\000\005-host");
lf[20]=C_h_intern(&lf[20],13,"make-pathname");
lf[22]=C_h_intern(&lf[22],2,"qs");
lf[23]=C_h_intern(&lf[23],18,"normalize-pathname");
lf[30]=C_decode_literal(C_heaptop,"\376B\000\000\003obj");
lf[31]=C_decode_literal(C_heaptop,"\376B\000\000\001o");
lf[33]=C_decode_literal(C_heaptop,"\376B\000\000\003lib");
lf[34]=C_decode_literal(C_heaptop,"\376B\000\000\001a");
lf[36]=C_decode_literal(C_heaptop,"\376B\000\000\005-out:");
lf[37]=C_decode_literal(C_heaptop,"\376B\000\000\003-o ");
lf[39]=C_decode_literal(C_heaptop,"\376B\000\000\003exe");
lf[40]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[42]=C_decode_literal(C_heaptop,"\376B\000\000\003-Fo");
lf[43]=C_decode_literal(C_heaptop,"\376B\000\000\003-o ");
lf[46]=C_h_intern(&lf[46],26,"\003sysload-dynamic-extension");
lf[47]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\005-DPIC\376\377\016");
lf[48]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\005-fPIC\376\003\000\000\002\376B\000\000\005-DPIC\376\377\016");
lf[82]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\014/usr/include\376\003\000\000\002\376B\000\000\000\376\377\016");
lf[104]=C_h_intern(&lf[104],18,"string-intersperse");
lf[105]=C_h_intern(&lf[105],7,"\003sysmap");
lf[107]=C_h_intern(&lf[107],6,"append");
lf[109]=C_h_intern(&lf[109],7,"reverse");
lf[110]=C_h_intern(&lf[110],6,"static");
lf[111]=C_h_intern(&lf[111],14,"static-options");
lf[112]=C_h_intern(&lf[112],21,"extension-information");
lf[113]=C_h_intern(&lf[113],15,"repository-path");
lf[115]=C_decode_literal(C_heaptop,"\376B\000\000\010 -static");
lf[116]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[117]=C_h_intern(&lf[117],13,"string-append");
lf[119]=C_h_intern(&lf[119],9,"\003syserror");
lf[121]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000\134\376\003\000\000\002\376\377\012\000\000#\376\377\016");
lf[122]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[123]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[124]=C_h_intern(&lf[124],17,"string-translate*");
lf[125]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376B\000\000\001\042\376B\000\000\002\134\042\376\377\016");
lf[126]=C_h_intern(&lf[126],16,"\003syslist->string");
lf[127]=C_h_intern(&lf[127],5,"cons*");
lf[128]=C_h_intern(&lf[128],16,"\003sysstring->list");
lf[129]=C_h_intern(&lf[129],10,"string-any");
lf[132]=C_h_intern(&lf[132],6,"printf");
lf[133]=C_decode_literal(C_heaptop,"\376B\000\000C\012Error: shell command terminated with non-zero exit status ~S: ~A~%");
lf[134]=C_h_intern(&lf[134],6,"system");
lf[135]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[136]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[137]=C_h_intern(&lf[137],5,"print");
lf[139]=C_h_intern(&lf[139],11,"delete-file");
lf[140]=C_decode_literal(C_heaptop,"\376B\000\000\003rm ");
lf[141]=C_h_intern(&lf[141],25,"\003sysimplicit-exit-handler");
lf[142]=C_decode_literal(C_heaptop,"\376B\000\000#not enough arguments to option `~A\047");
lf[143]=C_decode_literal(C_heaptop,"\376B\000\000\013-dynamiclib");
lf[144]=C_decode_literal(C_heaptop,"\376B\000\000\007-bundle");
lf[145]=C_decode_literal(C_heaptop,"\376B\000\000\004-dll");
lf[146]=C_decode_literal(C_heaptop,"\376B\000\000\007-shared");
lf[147]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\012-DC_SHARED\376\377\016");
lf[148]=C_decode_literal(C_heaptop,"\376B\000\000\010-feature");
lf[149]=C_decode_literal(C_heaptop,"\376B\000\000\026chicken-compile-shared");
lf[150]=C_h_intern(&lf[150],12,"\003sysfor-each");
lf[151]=C_decode_literal(C_heaptop,"\376B\000\000+install_name_tool -change libchicken.dylib ");
lf[152]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[153]=C_decode_literal(C_heaptop,"\376B\000\000\020libchicken.dylib");
lf[154]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[155]=C_decode_literal(C_heaptop,"\376B\000\000\003lib");
lf[156]=C_h_intern(&lf[156],17,"\003syspeek-c-string");
lf[157]=C_h_intern(&lf[157],15,"*windows-shell*");
lf[158]=C_decode_literal(C_heaptop,"\376B\000\000\004move");
lf[159]=C_decode_literal(C_heaptop,"\376B\000\000\002mv");
lf[160]=C_h_intern(&lf[160],7,"sprintf");
lf[161]=C_decode_literal(C_heaptop,"\376B\000\000\010~A ~A ~A");
lf[162]=C_decode_literal(C_heaptop,"\376B\000\000\004.old");
lf[163]=C_decode_literal(C_heaptop,"\376B\000\000TWarning: output file will overwrite source file `~A\047 - renaming source to `"
"~A.old\047~%");
lf[164]=C_decode_literal(C_heaptop,"\376B\000\000\002-c");
lf[165]=C_h_intern(&lf[165],26,"pathname-replace-extension");
lf[166]=C_h_intern(&lf[166],4,"last");
lf[167]=C_decode_literal(C_heaptop,"\376B\000\000\031no source files specified");
lf[168]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[169]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\012-to-stdout\376\377\016");
lf[170]=C_decode_literal(C_heaptop,"\376B\000\000\014-output-file");
lf[171]=C_decode_literal(C_heaptop,"\376B\000\000\003cpp");
lf[172]=C_decode_literal(C_heaptop,"\376B\000\000\001m");
lf[173]=C_decode_literal(C_heaptop,"\376B\000\000\001c");
lf[174]=C_decode_literal(C_heaptop,"\376B\000\000\010-dynamic");
lf[175]=C_h_intern(&lf[175],7,"newline");
lf[176]=C_h_intern(&lf[176],6,"print*");
lf[177]=C_h_intern(&lf[177],5,"-help");
lf[178]=C_h_intern(&lf[178],6,"--help");
lf[179]=C_h_intern(&lf[179],7,"display");
lf[180]=C_decode_literal(C_heaptop,"\376B\000$\363Usage: csc FILENAME | OPTION ...\012\012  `csc\047 is a driver program for the CHICK"
"EN compiler. Files given on the\012  command line are translated, compiled or linke"
"d as needed.\012\012  FILENAME is a Scheme source file name with optional extension or"
" a\012  C/C++/Objective-C source, object or library file name with extension. OPTIO"
"N\012  may be one of the following:\012\012  General options:\012\012    -h  -help             "
"         display this text and exit\012    -v                             show inte"
"rmediate compilation stages\012    -v2  -verbose                  display informati"
"on about translation\012                                    progress\012    -v3       "
"                     display information about all compilation\012                 "
"                   stages\012    -V  -version                   display Scheme comp"
"iler version and exit\012    -release                       display release number "
"and exit\012\012  File and pathname options:\012\012    -o -output-file FILENAME       speci"
"fies target executable name\012    -I -include-path PATHNAME      specifies alterna"
"tive path for included\012                                    files\012    -to-stdout "
"                    write compiler to stdout (implies -t)\012    -s -shared -dynami"
"c            generate dynamically loadable shared object\012                       "
"             file\012\012  Language options:\012\012    -D  -DSYMBOL  -feature SYMBOL  regis"
"ter feature identifier\012    -c++                           compile via a C++ sour"
"ce file (.cpp) \012    -objc                          compile via Objective-C sourc"
"e file (.m)\012\012  Syntax related options:\012\012    -i -case-insensitive           don\047t"
" preserve case of read symbols    \012    -k  -keyword-style STYLE       enable alt"
"ernative keyword-syntax\012                                    (prefix, suffix or n"
"one)\012        -no-parentheses-synonyms   disables list delimiter synonyms\012       "
" -no-symbol-escape          disables support for escaped symbols\012        -r5rs-s"
"yntax               disables the Chicken extensions to\012                         "
"           R5RS syntax\012    -compile-syntax                macros are made availa"
"ble at run-time\012    -j -emit-import-library MODULE write compile-time module inf"
"ormation into\012                                    separate file\012\012  Translation o"
"ptions:\012\012    -x  -explicit-use              do not use units `library\047 and `eval"
"\047 by\012                                    default\012    -P  -check-syntax          "
"    stop compilation after macro-expansion\012    -A  -analyze-only              st"
"op compilation after first analysis pass\012\012  Debugging options:\012\012    -w  -no-warn"
"ings               disable warnings\012    -disable-warning CLASS         disable s"
"pecific class of warnings\012    -d0 -d1 -d2 -debug-level NUMBER\012                  "
"                 set level of available debugging information\012    -no-trace     "
"                 disable rudimentary debugging information\012    -profile         "
"              executable emits profiling information \012    -accumulate-profile   "
"         executable emits profiling information in\012                             "
"       append mode\012    -profile-name FILENAME         name of the generated prof"
"ile information\012                                    file\012\012  Optimization options"
":\012\012    -O -O1 -O2 -O3 -O4 -optimize-level NUMBER\012                               "
"    enable certain sets of optimization options\012    -optimize-leaf-routines     "
"   enable leaf routine optimization\012    -N  -no-usual-integrations     standard "
"procedures may be redefined\012    -u  -unsafe                    disable safety ch"
"ecks\012    -local                         assume globals are only modified in curr"
"ent\012                                    file\012    -b  -block                     "
"enable block-compilation\012    -disable-interrupts            disable interrupts i"
"n compiled code\012    -f  -fixnum-arithmetic         assume all numbers are fixnum"
"s\012    -Ob  -benchmark-mode           equivalent to \047-block -optimize-level 4\012   "
"                                 -debug-level 0 -fixnum-arithmetic\012             "
"                       -lambda-lift -inline -disable-interrupts\047\012    -lambda-lif"
"t                   perform lambda-lifting\012    -unsafe-libraries              li"
"nk with unsafe runtime system\012    -disable-stack-overflow-checks disables detect"
"ion of stack-overflows\012    -inline                        enable inlining\012    -i"
"nline-limit                  set inlining threshold\012    -inline-global          "
"       enable cross-module inlining\012    -n -emit-inline-file FILENAME  generate "
"file with globally inlinable\012                                    procedures (imp"
"lies -inline -local)\012\012  Configuration options:\012\012    -unit NAME                  "
"   compile file as a library unit\012    -uses NAME                     declare lib"
"rary unit as used.\012    -heap-size NUMBER              specifies heap-size of com"
"piled executable\012    -heap-initial-size NUMBER      specifies heap-size at start"
"up time\012    -heap-growth PERCENTAGE        specifies growth-rate of expanding he"
"ap\012    -heap-shrinkage PERCENTAGE     specifies shrink-rate of contracting heap\012"
"    -nursery NUMBER  -stack-size NUMBER\012                                   speci"
"fies nursery size of compiled\012                                   executable\012    "
"-X -extend FILENAME            load file before compilation commences\012    -prelu"
"de EXPRESSION            add expression to beginning of source file\012    -postlud"
"e EXPRESSION           add expression to end of source file\012    -prologue FILENA"
"ME             include file before main source file\012    -epilogue FILENAME      "
"       include file after main source file\012\012    -e  -embedded                  c"
"ompile as embedded\012                                    (don\047t generate `main()\047)"
"\012    -W  -windows                   compile as Windows GUI application\012         "
"                           (MSVC only)\012    -R  -require-extension NAME    requir"
"e extension and import in compiled\012                                    code\012    "
"-E  -extension                 compile as extension (dynamic or static)\012    -dll"
" -library                  compile multiple units into a dynamic\012               "
"                     library\012\012  Options to other passes:\012\012    -C OPTION         "
"             pass option to C compiler\012    -L OPTION                      pass o"
"ption to linker\012    -I<DIR>                        pass \134\042-I<DIR>\134\042 to C compile"
"r\012                                    (add include path)\012    -L<DIR>            "
"            pass \134\042-L<DIR>\134\042 to linker\012                                    (add "
"library path)\012    -k                             keep intermediate files\012    -c "
"                            stop after compilation to object files\012    -t       "
"                      stop after translation to C\012    -cc COMPILER              "
"     select other C compiler than the default one\012    -cxx COMPILER             "
"     select other C++ compiler than the default one\012    -ld COMPILER            "
"       select other linker than the default one\012    -lLIBNAME                   "
"   link with given library\012                                    (`libLIBNAME\047 on "
"UNIX,\012                                     `LIBNAME.lib\047 on Windows)\012    -static"
"-libs                   link with static CHICKEN libraries\012    -static          "
"              generate completely statically linked\012                            "
"        executable\012    -static-extension NAME         link extension NAME static"
"ally\012                                    (if available)\012    -F<DIR>             "
"           pass \134\042-F<DIR>\134\042 to C compiler\012                                    (a"
"dd framework header path on Mac OS X)\012    -framework NAME                passed "
"to linker on Mac OS X\012    -rpath PATHNAME                add directory to runtim"
"e library search path\012    -Wl,...                        pass linker options\012   "
" -strip                         strip resulting binary\012\012  Inquiry options:\012\012    "
"-home                          show home-directory (where support files go)\012    "
"-cflags                        show required C-compiler flags and exit\012    -ldfl"
"ags                       show required linker flags and exit\012    -libs         "
"                 show required libraries and exit\012    -cc-name                  "
"     show name of default C compiler used\012    -cxx-name                      sho"
"w name of default C++ compiler used\012    -ld-name                       show name"
" of default linker used\012    -dry-run                       just show commands ex"
"ecuted, don\047t run them\012                                    (implies `-v\047)\012\012  Obs"
"cure options:\012\012    -debug MODES                   display debugging output for t"
"he given modes\012    -compiler PATHNAME             use other compiler than defaul"
"t `chicken\047\012    -disable-c-syntax-checks       disable syntax checks of C code f"
"ragments\012    -raw                           do not generate implicit init- and e"
"xit code\012    -emit-external-prototypes-first\012                                   "
"emit protoypes for callbacks before foreign\012                                    "
"declarations\012    -ignore-repository             do not refer to repository for e"
"xtensions\012    -keep-shadowed-macros          do not remove shadowed macro\012    -h"
"ost                          compile for host when configured for\012              "
"                      cross-compiling\012\012  Options can be collapsed if unambiguous"
", so\012\012    -vkfO\012\012  is the same as\012\012    -v -k -fixnum-arithmetic -optimize\012\012  The"
" contents of the environment variable CSC_OPTIONS are implicitly passed to\012  eve"
"ry invocation of `csc\047.\012");
lf[181]=C_h_intern(&lf[181],8,"-release");
lf[182]=C_h_intern(&lf[182],15,"chicken-version");
lf[183]=C_h_intern(&lf[183],8,"-version");
lf[184]=C_decode_literal(C_heaptop,"\376B\000\000\011 -version");
lf[185]=C_h_intern(&lf[185],4,"-c++");
lf[186]=C_decode_literal(C_heaptop,"\376B\000\000\017-no-cpp-precomp");
lf[187]=C_h_intern(&lf[187],5,"-objc");
lf[188]=C_h_intern(&lf[188],7,"-static");
lf[189]=C_decode_literal(C_heaptop,"\376B\000\000\010-feature");
lf[190]=C_decode_literal(C_heaptop,"\376B\000\000\026chicken-compile-static");
lf[191]=C_h_intern(&lf[191],12,"-static-libs");
lf[192]=C_decode_literal(C_heaptop,"\376B\000\000\010-feature");
lf[193]=C_decode_literal(C_heaptop,"\376B\000\000\026chicken-compile-static");
lf[194]=C_h_intern(&lf[194],7,"-cflags");
lf[195]=C_h_intern(&lf[195],8,"-ldflags");
lf[196]=C_h_intern(&lf[196],8,"-cc-name");
lf[197]=C_h_intern(&lf[197],9,"-cxx-name");
lf[198]=C_h_intern(&lf[198],8,"-ld-name");
lf[199]=C_h_intern(&lf[199],5,"-home");
lf[200]=C_h_intern(&lf[200],5,"-libs");
lf[201]=C_h_intern(&lf[201],2,"-v");
lf[202]=C_h_intern(&lf[202],3,"-v2");
lf[203]=C_h_intern(&lf[203],8,"-verbose");
lf[204]=C_decode_literal(C_heaptop,"\376B\000\000\010-verbose");
lf[205]=C_h_intern(&lf[205],2,"-w");
lf[206]=C_h_intern(&lf[206],12,"-no-warnings");
lf[207]=C_decode_literal(C_heaptop,"\376B\000\000\002-w");
lf[208]=C_decode_literal(C_heaptop,"\376B\000\000\014-no-warnings");
lf[209]=C_h_intern(&lf[209],3,"-v3");
lf[210]=C_decode_literal(C_heaptop,"\376B\000\000\010-VERBOSE");
lf[211]=C_decode_literal(C_heaptop,"\376B\000\000\002-v");
lf[212]=C_decode_literal(C_heaptop,"\376B\000\000\002-v");
lf[213]=C_decode_literal(C_heaptop,"\376B\000\000\002-Q");
lf[214]=C_decode_literal(C_heaptop,"\376B\000\000\010-verbose");
lf[215]=C_h_intern(&lf[215],2,"-A");
lf[216]=C_h_intern(&lf[216],13,"-analyze-only");
lf[217]=C_decode_literal(C_heaptop,"\376B\000\000\015-analyze-only");
lf[218]=C_h_intern(&lf[218],2,"-P");
lf[219]=C_h_intern(&lf[219],13,"-check-syntax");
lf[220]=C_decode_literal(C_heaptop,"\376B\000\000\015-check-syntax");
lf[221]=C_h_intern(&lf[221],2,"-k");
lf[222]=C_h_intern(&lf[222],2,"-c");
lf[223]=C_h_intern(&lf[223],2,"-t");
lf[224]=C_h_intern(&lf[224],2,"-e");
lf[225]=C_h_intern(&lf[225],9,"-embedded");
lf[226]=C_decode_literal(C_heaptop,"\376B\000\000\014-DC_EMBEDDED");
lf[227]=C_h_intern(&lf[227],18,"-require-extension");
lf[228]=C_h_intern(&lf[228],2,"-R");
lf[229]=C_decode_literal(C_heaptop,"\376B\000\000\022-require-extension");
lf[230]=C_h_intern(&lf[230],17,"-static-extension");
lf[231]=C_decode_literal(C_heaptop,"\376B\000\000\021-static-extension");
lf[232]=C_h_intern(&lf[232],8,"-windows");
lf[233]=C_h_intern(&lf[233],2,"-W");
lf[234]=C_decode_literal(C_heaptop,"\376B\000\000\017-DC_WINDOWS_GUI");
lf[235]=C_decode_literal(C_heaptop,"\376B\000\000\012-lkernel32");
lf[236]=C_decode_literal(C_heaptop,"\376B\000\000\010-luser32");
lf[237]=C_decode_literal(C_heaptop,"\376B\000\000\007-lgdi32");
lf[238]=C_decode_literal(C_heaptop,"\376B\000\000\011-mwindows");
lf[239]=C_decode_literal(C_heaptop,"\376B\000\000\017-DC_WINDOWS_GUI");
lf[240]=C_decode_literal(C_heaptop,"\376B\000\000\014kernel32.lib");
lf[241]=C_decode_literal(C_heaptop,"\376B\000\000\012user32.lib");
lf[242]=C_decode_literal(C_heaptop,"\376B\000\000\011gdi32.lib");
lf[243]=C_h_intern(&lf[243],10,"-framework");
lf[244]=C_decode_literal(C_heaptop,"\376B\000\000\012-framework");
lf[245]=C_h_intern(&lf[245],2,"-o");
lf[246]=C_h_intern(&lf[246],2,"-O");
lf[247]=C_h_intern(&lf[247],3,"-O1");
lf[248]=C_decode_literal(C_heaptop,"\376B\000\000\017-optimize-level");
lf[249]=C_decode_literal(C_heaptop,"\376B\000\000\0011");
lf[250]=C_h_intern(&lf[250],3,"-O2");
lf[251]=C_decode_literal(C_heaptop,"\376B\000\000\017-optimize-level");
lf[252]=C_decode_literal(C_heaptop,"\376B\000\000\0012");
lf[253]=C_h_intern(&lf[253],3,"-O3");
lf[254]=C_decode_literal(C_heaptop,"\376B\000\000\017-optimize-level");
lf[255]=C_decode_literal(C_heaptop,"\376B\000\000\0013");
lf[256]=C_h_intern(&lf[256],3,"-O4");
lf[257]=C_decode_literal(C_heaptop,"\376B\000\000\017-optimize-level");
lf[258]=C_decode_literal(C_heaptop,"\376B\000\000\0014");
lf[259]=C_h_intern(&lf[259],3,"-d0");
lf[260]=C_decode_literal(C_heaptop,"\376B\000\000\014-debug-level");
lf[261]=C_decode_literal(C_heaptop,"\376B\000\000\0010");
lf[262]=C_h_intern(&lf[262],3,"-d1");
lf[263]=C_decode_literal(C_heaptop,"\376B\000\000\014-debug-level");
lf[264]=C_decode_literal(C_heaptop,"\376B\000\000\0011");
lf[265]=C_h_intern(&lf[265],3,"-d2");
lf[266]=C_decode_literal(C_heaptop,"\376B\000\000\014-debug-level");
lf[267]=C_decode_literal(C_heaptop,"\376B\000\000\0012");
lf[268]=C_h_intern(&lf[268],8,"-dry-run");
lf[269]=C_h_intern(&lf[269],2,"-s");
lf[270]=C_h_intern(&lf[270],4,"-dll");
lf[271]=C_h_intern(&lf[271],8,"-library");
lf[272]=C_h_intern(&lf[272],9,"-compiler");
lf[273]=C_h_intern(&lf[273],3,"-cc");
lf[274]=C_h_intern(&lf[274],4,"-cxx");
lf[275]=C_h_intern(&lf[275],3,"-ld");
lf[276]=C_h_intern(&lf[276],2,"-I");
lf[277]=C_decode_literal(C_heaptop,"\376B\000\000\015-include-path");
lf[278]=C_h_intern(&lf[278],2,"-C");
lf[279]=C_h_intern(&lf[279],12,"string-split");
lf[280]=C_h_intern(&lf[280],6,"-strip");
lf[281]=C_decode_literal(C_heaptop,"\376B\000\000\002-s");
lf[282]=C_h_intern(&lf[282],2,"-L");
lf[283]=C_h_intern(&lf[283],17,"-unsafe-libraries");
lf[284]=C_h_intern(&lf[284],6,"-rpath");
lf[285]=C_h_intern(&lf[285],3,"gnu");
lf[286]=C_decode_literal(C_heaptop,"\376B\000\000\006-Wl,-R");
lf[287]=C_h_intern(&lf[287],14,"build-platform");
lf[288]=C_h_intern(&lf[288],5,"-host");
lf[289]=C_h_intern(&lf[289],1,"-");
lf[290]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\001-\376\377\016");
lf[291]=C_decode_literal(C_heaptop,"\376B\000\000\001a");
lf[292]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-h\376\003\000\000\002\376B\000\000\005-help\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-s\376\003\000\000\002\376B\000\000\007-shared\376\377\016\376\003\000\000\002\376\003\000"
"\000\002\376\001\000\000\002-P\376\003\000\000\002\376B\000\000\015-check-syntax\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-V\376\003\000\000\002\376B\000\000\010-version\376\377\016\376\003\000\000\002\376\003"
"\000\000\002\376\001\000\000\003-Ob\376\003\000\000\002\376B\000\000\017-benchmark-mode\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-f\376\003\000\000\002\376B\000\000\022-fixnum-arithm"
"etic\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-D\376\003\000\000\002\376B\000\000\010-feature\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-i\376\003\000\000\002\376B\000\000\021-case-in"
"sensitive\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-K\376\003\000\000\002\376B\000\000\016-keyword-style\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-X\376\003\000\000\002\376B"
"\000\000\007-extend\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-N\376\003\000\000\002\376B\000\000\026-no-usual-integrations\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002"
"-x\376\003\000\000\002\376B\000\000\015-explicit-use\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-u\376\003\000\000\002\376B\000\000\007-unsafe\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002"
"-j\376\003\000\000\002\376B\000\000\024-emit-import-library\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-n\376\003\000\000\002\376B\000\000\021-emit-inline-file\376"
"\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-b\376\003\000\000\002\376B\000\000\006-block\376\377\016\376\377\016");
lf[293]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\015-explicit-use\376\003\000\000\002\376\001\000\000\011-no-trace\376\003\000\000\002\376\001\000\000\014-no-warnings\376\003\000\000\002\376\001\000\000\026-no-us"
"ual-integrations\376\003\000\000\002\376\001\000\000\027-optimize-leaf-routines\376\003\000\000\002\376\001\000\000\007-unsafe\376\003\000\000\002\376\001\000\000\006-blo"
"ck\376\003\000\000\002\376\001\000\000\023-disable-interrupts\376\003\000\000\002\376\001\000\000\022-fixnum-arithmetic\376\003\000\000\002\376\001\000\000\012-to-stdout\376"
"\003\000\000\002\376\001\000\000\010-profile\376\003\000\000\002\376\001\000\000\004-raw\376\003\000\000\002\376\001\000\000\023-accumulate-profile\376\003\000\000\002\376\001\000\000\015-check-syn"
"tax\376\003\000\000\002\376\001\000\000\021-case-insensitive\376\003\000\000\002\376\001\000\000\017-benchmark-mode\376\003\000\000\002\376\001\000\000\007-shared\376\003\000\000\002\376\001\000"
"\000\017-compile-syntax\376\003\000\000\002\376\001\000\000\017-no-lambda-info\376\003\000\000\002\376\001\000\000\014-lambda-lift\376\003\000\000\002\376\001\000\000\010-dynam"
"ic\376\003\000\000\002\376\001\000\000\036-disable-stack-overflow-checks\376\003\000\000\002\376\001\000\000\006-local\376\003\000\000\002\376\001\000\000\037-emit-extern"
"al-prototypes-first\376\003\000\000\002\376\001\000\000\007-inline\376\003\000\000\002\376\001\000\000\010-release\376\003\000\000\002\376\001\000\000\015-analyze-only\376\003\000"
"\000\002\376\001\000\000\025-keep-shadowed-macros\376\003\000\000\002\376\001\000\000\016-inline-global\376\003\000\000\002\376\001\000\000\022-ignore-repository"
"\376\003\000\000\002\376\001\000\000\021-no-symbol-escape\376\003\000\000\002\376\001\000\000\030-no-parentheses-synonyms\376\003\000\000\002\376\001\000\000\014-r5rs-syn"
"tax\376\377\016");
lf[294]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006-debug\376\003\000\000\002\376\001\000\000\014-output-file\376\003\000\000\002\376\001\000\000\012-heap-size\376\003\000\000\002\376\001\000\000\010-nursery\376\003\000\000"
"\002\376\001\000\000\013-stack-size\376\003\000\000\002\376\001\000\000\011-compiler\376\003\000\000\002\376\001\000\000\005-unit\376\003\000\000\002\376\001\000\000\005-uses\376\003\000\000\002\376\001\000\000\016-key"
"word-style\376\003\000\000\002\376\001\000\000\017-optimize-level\376\003\000\000\002\376\001\000\000\015-include-path\376\003\000\000\002\376\001\000\000\016-database-si"
"ze\376\003\000\000\002\376\001\000\000\007-extend\376\003\000\000\002\376\001\000\000\010-prelude\376\003\000\000\002\376\001\000\000\011-postlude\376\003\000\000\002\376\001\000\000\011-prologue\376\003\000\000\002"
"\376\001\000\000\011-epilogue\376\003\000\000\002\376\001\000\000\015-inline-limit\376\003\000\000\002\376\001\000\000\015-profile-name\376\003\000\000\002\376\001\000\000\020-disable-w"
"arning\376\003\000\000\002\376\001\000\000\021-emit-inline-file\376\003\000\000\002\376\001\000\000\010-feature\376\003\000\000\002\376\001\000\000\014-debug-level\376\003\000\000\002\376\001"
"\000\000\014-heap-growth\376\003\000\000\002\376\001\000\000\017-heap-shrinkage\376\003\000\000\002\376\001\000\000\022-heap-initial-size\376\003\000\000\002\376\001\000\000\024-e"
"mit-import-library\376\003\000\000\002\376\001\000\000\021-static-extension\376\377\016");
lf[295]=C_decode_literal(C_heaptop,"\376B\000\000\010-feature");
lf[296]=C_h_intern(&lf[296],9,"substring");
lf[297]=C_decode_literal(C_heaptop,"\376B\000\000\001-");
lf[298]=C_decode_literal(C_heaptop,"\376B\000\000\023invalid option `~A\047");
lf[299]=C_h_intern(&lf[299],15,"lset-difference");
lf[300]=C_h_intern(&lf[300],6,"char=\077");
lf[301]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000P\376\003\000\000\002\376\377\012\000\000H\376\003\000\000\002\376\377\012\000\000h\376\003\000\000\002\376\377\012\000\000s\376\003\000\000\002\376\377\012\000\000f\376\003\000\000\002\376\377\012\000\000i\376\003\000\000\002\376\377\012\000\000E\376\003\000"
"\000\002\376\377\012\000\000N\376\003\000\000\002\376\377\012\000\000x\376\003\000\000\002\376\377\012\000\000u\376\003\000\000\002\376\377\012\000\000b\376\003\000\000\002\376\377\012\000\000v\376\003\000\000\002\376\377\012\000\000w\376\003\000\000\002\376\377\012\000\000A\376\003\000\000\002\376"
"\377\012\000\000O\376\003\000\000\002\376\377\012\000\000e\376\003\000\000\002\376\377\012\000\000W\376\003\000\000\002\376\377\012\000\000k\376\003\000\000\002\376\377\012\000\000c\376\003\000\000\002\376\377\012\000\000t\376\003\000\000\002\376\377\012\000\000g\376\377\016");
lf[302]=C_decode_literal(C_heaptop,"\376B\000\000\023invalid option `~A\047");
lf[303]=C_decode_literal(C_heaptop,"\376B\000\000\004-Wl,");
lf[304]=C_h_intern(&lf[304],18,"decompose-pathname");
lf[305]=C_decode_literal(C_heaptop,"\376B\000\000\001h");
lf[306]=C_decode_literal(C_heaptop,"\376B\000\000\001c");
lf[307]=C_decode_literal(C_heaptop,"\376B\000\000\003cpp");
lf[308]=C_decode_literal(C_heaptop,"\376B\000\000\001C");
lf[309]=C_decode_literal(C_heaptop,"\376B\000\000\002cc");
lf[310]=C_decode_literal(C_heaptop,"\376B\000\000\003cxx");
lf[311]=C_decode_literal(C_heaptop,"\376B\000\000\003hpp");
lf[312]=C_decode_literal(C_heaptop,"\376B\000\000\017-no-cpp-precomp");
lf[313]=C_decode_literal(C_heaptop,"\376B\000\000\001m");
lf[314]=C_decode_literal(C_heaptop,"\376B\000\000\001M");
lf[315]=C_decode_literal(C_heaptop,"\376B\000\000\002mm");
lf[316]=C_decode_literal(C_heaptop,"\376B\000\000\030file `~A\047 does not exist");
lf[317]=C_h_intern(&lf[317],12,"file-exists\077");
lf[318]=C_decode_literal(C_heaptop,"\376B\000\000\004.scm");
lf[319]=C_decode_literal(C_heaptop,"\376B\000\000\002-:");
lf[320]=C_h_intern(&lf[320],15,"-optimize-level");
lf[321]=C_h_intern(&lf[321],15,"-benchmark-mode");
lf[322]=C_h_intern(&lf[322],10,"-to-stdout");
lf[323]=C_h_intern(&lf[323],7,"-unsafe");
lf[324]=C_h_intern(&lf[324],7,"-shared");
lf[325]=C_h_intern(&lf[325],8,"-dynamic");
lf[326]=C_h_intern(&lf[326],14,"string->symbol");
lf[327]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[328]=C_h_intern(&lf[328],6,"getenv");
lf[329]=C_decode_literal(C_heaptop,"\376B\000\000\013CSC_OPTIONS");
lf[330]=C_h_intern(&lf[330],4,"conc");
lf[331]=C_decode_literal(C_heaptop,"\376B\000\000\002-L");
lf[332]=C_decode_literal(C_heaptop,"\376B\000\000\011-LIBPATH:");
lf[333]=C_decode_literal(C_heaptop,"\376B\000\000\007 -Wl,-R");
lf[334]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[335]=C_decode_literal(C_heaptop,"\376B\000\000\003lib");
lf[336]=C_decode_literal(C_heaptop,"\376B\000\000\002-L");
lf[337]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[338]=C_decode_literal(C_heaptop,"\376B\000\000\003lib");
lf[339]=C_decode_literal(C_heaptop,"\376B\000\000\002-I");
lf[340]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[341]=C_decode_literal(C_heaptop,"\376B\000\000\007include");
lf[342]=C_decode_literal(C_heaptop,"\376B\000\000\014libuchicken.");
lf[343]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\012-luchicken\376\377\016");
lf[344]=C_decode_literal(C_heaptop,"\376B\000\000\003lib");
lf[345]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[346]=C_decode_literal(C_heaptop,"\376B\000\000\013libchicken.");
lf[347]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\011-lchicken\376\377\016");
lf[348]=C_decode_literal(C_heaptop,"\376B\000\000\003lib");
lf[349]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[350]=C_decode_literal(C_heaptop,"\376B\000\000\023libuchicken-static.");
lf[351]=C_decode_literal(C_heaptop,"\376B\000\000\014libuchicken.");
lf[352]=C_decode_literal(C_heaptop,"\376B\000\000\022libchicken-static.");
lf[353]=C_decode_literal(C_heaptop,"\376B\000\000\013libchicken.");
lf[354]=C_decode_literal(C_heaptop,"\376B\000\000\004link");
lf[355]=C_decode_literal(C_heaptop,"\376B\000\000\004link");
lf[356]=C_decode_literal(C_heaptop,"\376B\000\000\007chicken");
lf[357]=C_decode_literal(C_heaptop,"\376B\000\000\003bin");
lf[358]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[359]=C_decode_literal(C_heaptop,"\376B\000\000\005share");
lf[360]=C_h_intern(&lf[360],22,"command-line-arguments");
lf[361]=C_decode_literal(C_heaptop,"\376B\000\000\016CHICKEN_PREFIX");
lf[362]=C_h_intern(&lf[362],4,"hpux");
lf[363]=C_h_intern(&lf[363],4,"hppa");
lf[364]=C_h_intern(&lf[364],12,"machine-type");
lf[365]=C_h_intern(&lf[365],16,"software-version");
C_register_lf2(lf,366,create_ptable());
t2=C_mutate(&lf[0] /* (set! c196 ...) */,lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_890,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t3);}

/* k888 */
static void C_ccall f_890(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_890,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_893,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k891 in k888 */
static void C_ccall f_893(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_893,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_896,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k894 in k891 in k888 */
static void C_ccall f_896(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_896,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_899,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k897 in k894 in k891 in k888 */
static void C_ccall f_899(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_899,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_902,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_902(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_902,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_905,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_905(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_905,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_908,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_908(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_908,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_911,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_911(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_911,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_914,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_1_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_914(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_914,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_917,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_13_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_917(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_917,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_920,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_utils_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_920(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_920,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_923,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_files_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_923(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_923,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_926,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_926(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_926,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3692,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 61   build-platform */
((C_proc2)C_retrieve_symbol_proc(lf[287]))(2,*((C_word*)lf[287]+1),t2);}

/* k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_3692(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3692,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[2]);
t3=C_mutate(&lf[3] /* (set! mingw ...) */,t2);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3688,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 62   build-platform */
((C_proc2)C_retrieve_symbol_proc(lf[287]))(2,*((C_word*)lf[287]+1),t4);}

/* k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_3688(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3688,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[4]);
t3=C_mutate(&lf[5] /* (set! msvc ...) */,t2);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3684,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 63   software-version */
((C_proc2)C_retrieve_symbol_proc(lf[365]))(2,*((C_word*)lf[365]+1),t4);}

/* k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_3684(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3684,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[6]);
t3=C_mutate(&lf[7] /* (set! osx ...) */,t2);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_942,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3680,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 64   software-version */
((C_proc2)C_retrieve_symbol_proc(lf[365]))(2,*((C_word*)lf[365]+1),t5);}

/* k3678 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_3680(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3680,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[362]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3676,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 65   machine-type */
((C_proc2)C_retrieve_symbol_proc(lf[364]))(2,*((C_word*)lf[364]+1),t3);}
else{
t3=((C_word*)t0)[2];
f_942(t3,C_SCHEME_FALSE);}}

/* k3674 in k3678 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_3676(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_942(t2,(C_word)C_eqp(t1,lf[363]));}

/* k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_fcall f_942(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_942,NULL,2,t0,t1);}
t2=C_mutate(&lf[8] /* (set! hpux-hppa ...) */,t1);
t3=C_mutate(&lf[9] /* (set! quit ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_944,tmp=(C_word)a,a+=2,tmp));
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_959,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 71   getenv */
((C_proc3)C_retrieve_symbol_proc(lf[328]))(3,*((C_word*)lf[328]+1),t4,lf[361]);}

/* k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_959(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_959,2,t0,t1);}
t2=C_mutate(&lf[14] /* (set! chicken-prefix ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_963,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 72   command-line-arguments */
((C_proc2)C_retrieve_symbol_proc(lf[360]))(2,*((C_word*)lf[360]+1),t3);}

/* k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_963(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_963,2,t0,t1);}
t2=C_mutate(&lf[15] /* (set! arguments ...) */,t1);
t3=(C_word)C_i_member(lf[16],C_retrieve2(lf[15],"arguments"));
t4=C_mutate(&lf[17] /* (set! host-mode ...) */,t3);
t5=(C_word)C_fudge(C_fix(39));
t6=C_mutate(&lf[18] /* (set! cross-chicken ...) */,t5);
t7=C_mutate(&lf[19] /* (set! prefix ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_973,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate(&lf[21] /* (set! quotewrap ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_986,tmp=(C_word)a,a+=2,tmp));
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_998,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3656,a[2]=t9,tmp=(C_word)a,a+=3,tmp);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3660,a[2]=t10,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[17],"host-mode"))){
/* ##sys#peek-c-string */
t12=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t11,C_mpointer(&a,(void*)C_INSTALL_SHARE_HOME),C_fix(0));}
else{
/* ##sys#peek-c-string */
t12=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t11,C_mpointer(&a,(void*)C_TARGET_SHARE_HOME),C_fix(0));}}

/* k3658 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_3660(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 86   prefix */
f_973(((C_word*)t0)[2],lf[358],lf[359],t1);}

/* k3654 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_3656(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 85   quotewrap */
t2=C_retrieve2(lf[21],"quotewrap");
f_986(3,t2,((C_word*)t0)[2],t1);}

/* k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_998(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_998,2,t0,t1);}
t2=C_mutate(&lf[24] /* (set! home ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1002,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3634,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3638,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3642,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[17],"host-mode"))){
/* ##sys#peek-c-string */
t7=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,C_mpointer(&a,(void*)C_INSTALL_BIN_HOME),C_fix(0));}
else{
/* ##sys#peek-c-string */
t7=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,C_mpointer(&a,(void*)C_TARGET_BIN_HOME),C_fix(0));}}

/* k3640 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_3642(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3642,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3646,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* ##sys#peek-c-string */
t3=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_CHICKEN_PROGRAM),C_fix(0));}

/* k3644 in k3640 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_3646(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 91   make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[20]))(4,*((C_word*)lf[20]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3636 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_3638(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 90   prefix */
f_973(((C_word*)t0)[2],lf[356],lf[357],t1);}

/* k3632 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_3634(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 89   quotewrap */
t2=C_retrieve2(lf[21],"quotewrap");
f_986(3,t2,((C_word*)t0)[2],t1);}

/* k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_1002(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1002,2,t0,t1);}
t2=C_mutate(&lf[25] /* (set! translator ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1006,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3624,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[17],"host-mode"))){
/* ##sys#peek-c-string */
t5=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_INSTALL_CC),C_fix(0));}
else{
/* ##sys#peek-c-string */
t5=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_TARGET_CC),C_fix(0));}}

/* k3622 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_3624(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 95   quotewrap */
t2=C_retrieve2(lf[21],"quotewrap");
f_986(3,t2,((C_word*)t0)[2],t1);}

/* k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_1006(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1006,2,t0,t1);}
t2=C_mutate(&lf[26] /* (set! compiler ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1010,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3614,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[17],"host-mode"))){
/* ##sys#peek-c-string */
t5=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_INSTALL_CXX),C_fix(0));}
else{
/* ##sys#peek-c-string */
t5=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_TARGET_CXX),C_fix(0));}}

/* k3612 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_3614(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 96   quotewrap */
t2=C_retrieve2(lf[21],"quotewrap");
f_986(3,t2,((C_word*)t0)[2],t1);}

/* k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_1010(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1010,2,t0,t1);}
t2=C_mutate(&lf[27] /* (set! c++-compiler ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1014,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3601,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[5],"msvc"))){
t5=t4;
f_3601(2,t5,lf[355]);}
else{
if(C_truep(C_retrieve2(lf[17],"host-mode"))){
/* ##sys#peek-c-string */
t5=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_INSTALL_CC),C_fix(0));}
else{
/* ##sys#peek-c-string */
t5=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_TARGET_CC),C_fix(0));}}}

/* k3599 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_3601(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 97   quotewrap */
t2=C_retrieve2(lf[21],"quotewrap");
f_986(3,t2,((C_word*)t0)[2],t1);}

/* k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_1014(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1014,2,t0,t1);}
t2=C_mutate(&lf[28] /* (set! linker ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1018,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3588,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[5],"msvc"))){
t5=t4;
f_3588(2,t5,lf[354]);}
else{
if(C_truep(C_retrieve2(lf[17],"host-mode"))){
/* ##sys#peek-c-string */
t5=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_INSTALL_CXX),C_fix(0));}
else{
/* ##sys#peek-c-string */
t5=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_TARGET_CXX),C_fix(0));}}}

/* k3586 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_3588(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 98   quotewrap */
t2=C_retrieve2(lf[21],"quotewrap");
f_986(3,t2,((C_word*)t0)[2],t1);}

/* k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_1018(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1018,2,t0,t1);}
t2=C_mutate(&lf[29] /* (set! c++-linker ...) */,t1);
t3=(C_truep(C_retrieve2(lf[5],"msvc"))?lf[30]:lf[31]);
t4=C_mutate(&lf[32] /* (set! object-extension ...) */,t3);
t5=(C_truep(C_retrieve2(lf[5],"msvc"))?lf[33]:lf[34]);
t6=C_mutate(&lf[35] /* (set! library-extension ...) */,t5);
t7=(C_truep(C_retrieve2(lf[5],"msvc"))?lf[36]:lf[37]);
t8=C_mutate(&lf[38] /* (set! link-output-flag ...) */,t7);
t9=(C_truep(C_retrieve2(lf[5],"msvc"))?lf[39]:lf[40]);
t10=C_mutate(&lf[41] /* (set! executable-extension ...) */,t9);
t11=(C_truep(C_retrieve2(lf[5],"msvc"))?lf[42]:lf[43]);
t12=C_mutate(&lf[44] /* (set! compile-output-flag ...) */,t11);
t13=C_mutate(&lf[45] /* (set! shared-library-extension ...) */,C_retrieve(lf[46]));
t14=(C_truep(C_retrieve2(lf[3],"mingw"))?C_retrieve2(lf[3],"mingw"):C_retrieve2(lf[5],"msvc"));
t15=(C_truep(t14)?lf[47]:lf[48]);
t16=C_mutate(&lf[49] /* (set! pic-options ...) */,t15);
t17=C_mutate(&lf[50] /* (set! windows-shell ...) */,C_mk_bool(C_WINDOWS_SHELL));
t18=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1050,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t19=(C_truep(C_retrieve2(lf[5],"msvc"))?lf[352]:lf[353]);
/* csc.scm: 110  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[117]+1)))(4,*((C_word*)lf[117]+1),t18,t19,C_retrieve2(lf[35],"library-extension"));}

/* k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_1050(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1050,2,t0,t1);}
t2=C_mutate(&lf[51] /* (set! default-library ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1054,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(C_truep(C_retrieve2(lf[5],"msvc"))?lf[350]:lf[351]);
/* csc.scm: 113  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[117]+1)))(4,*((C_word*)lf[117]+1),t3,t4,C_retrieve2(lf[35],"library-extension"));}

/* k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_1054(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1054,2,t0,t1);}
t2=C_mutate(&lf[52] /* (set! default-unsafe-library ...) */,t1);
t3=C_mutate(&lf[53] /* (set! cleanup-filename ...) */,C_retrieve2(lf[21],"quotewrap"));
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1059,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3567,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[17],"host-mode"))){
/* ##sys#peek-c-string */
t6=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,C_mpointer(&a,(void*)C_INSTALL_CFLAGS),C_fix(0));}
else{
/* ##sys#peek-c-string */
t6=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,C_mpointer(&a,(void*)C_TARGET_CFLAGS),C_fix(0));}}

/* k3565 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_3567(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 119  string-split */
((C_proc3)C_retrieve_symbol_proc(lf[279]))(3,*((C_word*)lf[279]+1),((C_word*)t0)[2],t1);}

/* k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_1059(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1059,2,t0,t1);}
t2=C_mutate(&lf[54] /* (set! default-compilation-optimization-options ...) */,t1);
t3=C_mutate(&lf[55] /* (set! best-compilation-optimization-options ...) */,C_retrieve2(lf[54],"default-compilation-optimization-options"));
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1064,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3557,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[17],"host-mode"))){
/* ##sys#peek-c-string */
t6=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,C_mpointer(&a,(void*)C_INSTALL_LDFLAGS),C_fix(0));}
else{
/* ##sys#peek-c-string */
t6=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,C_mpointer(&a,(void*)C_TARGET_LDFLAGS),C_fix(0));}}

/* k3555 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_3557(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 121  string-split */
((C_proc3)C_retrieve_symbol_proc(lf[279]))(3,*((C_word*)lf[279]+1),((C_word*)t0)[2],t1);}

/* k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_1064(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1064,2,t0,t1);}
t2=C_mutate(&lf[56] /* (set! default-linking-optimization-options ...) */,t1);
t3=C_mutate(&lf[57] /* (set! best-linking-optimization-options ...) */,C_retrieve2(lf[56],"default-linking-optimization-options"));
t4=lf[58] /* scheme-files */ =C_SCHEME_END_OF_LIST;;
t5=lf[59] /* c-files */ =C_SCHEME_END_OF_LIST;;
t6=lf[60] /* generated-c-files */ =C_SCHEME_END_OF_LIST;;
t7=lf[61] /* object-files */ =C_SCHEME_END_OF_LIST;;
t8=lf[62] /* generated-object-files */ =C_SCHEME_END_OF_LIST;;
t9=lf[63] /* cpp-mode */ =C_SCHEME_FALSE;;
t10=lf[64] /* objc-mode */ =C_SCHEME_FALSE;;
t11=lf[65] /* embedded */ =C_SCHEME_FALSE;;
t12=lf[66] /* inquiry-only */ =C_SCHEME_FALSE;;
t13=lf[67] /* show-cflags */ =C_SCHEME_FALSE;;
t14=lf[68] /* show-ldflags */ =C_SCHEME_FALSE;;
t15=lf[69] /* show-libs */ =C_SCHEME_FALSE;;
t16=lf[70] /* dry-run */ =C_SCHEME_FALSE;;
t17=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1090,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[17],"host-mode"))){
/* ##sys#peek-c-string */
t18=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t18+1)))(4,t18,t17,C_mpointer(&a,(void*)C_INSTALL_MORE_STATIC_LIBS),C_fix(0));}
else{
/* ##sys#peek-c-string */
t18=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t18+1)))(4,t18,t17,C_mpointer(&a,(void*)C_TARGET_MORE_STATIC_LIBS),C_fix(0));}}

/* k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_1090(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1090,2,t0,t1);}
t2=C_mutate(&lf[71] /* (set! extra-libraries ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1094,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[17],"host-mode"))){
/* ##sys#peek-c-string */
t4=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)C_INSTALL_MORE_LIBS),C_fix(0));}
else{
/* ##sys#peek-c-string */
t4=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)C_TARGET_MORE_LIBS),C_fix(0));}}

/* k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_1094(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1094,2,t0,t1);}
t2=C_mutate(&lf[72] /* (set! extra-shared-libraries ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3519,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3523,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3527,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3531,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[17],"host-mode"))){
/* ##sys#peek-c-string */
t7=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,C_mpointer(&a,(void*)C_INSTALL_LIB_HOME),C_fix(0));}
else{
/* ##sys#peek-c-string */
t7=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,C_mpointer(&a,(void*)C_TARGET_LIB_HOME),C_fix(0));}}

/* k3529 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_3531(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3531,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3535,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 193  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[117]+1)))(4,*((C_word*)lf[117]+1),t2,lf[349],C_retrieve2(lf[51],"default-library"));}

/* k3533 in k3529 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_3535(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 191  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[117]+1)))(4,*((C_word*)lf[117]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3525 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_3527(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 190  prefix */
f_973(((C_word*)t0)[2],C_retrieve2(lf[51],"default-library"),lf[348],t1);}

/* k3521 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_3523(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 189  quotewrap */
t2=C_retrieve2(lf[21],"quotewrap");
f_986(3,t2,((C_word*)t0)[2],t1);}

/* k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_3519(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3519,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=C_mutate(&lf[73] /* (set! default-library-files ...) */,t2);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1102,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[5],"msvc"))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3515,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 195  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[117]+1)))(4,*((C_word*)lf[117]+1),t5,lf[346],C_retrieve2(lf[35],"library-extension"));}
else{
t5=t4;
f_1102(t5,lf[347]);}}

/* k3513 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_3515(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3515,2,t0,t1);}
t2=((C_word*)t0)[2];
f_1102(t2,(C_word)C_a_i_list(&a,1,t1));}

/* k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_fcall f_1102(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1102,NULL,2,t0,t1);}
t2=C_mutate(&lf[74] /* (set! default-shared-library-files ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3486,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3490,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3494,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3498,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[17],"host-mode"))){
/* ##sys#peek-c-string */
t7=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,C_mpointer(&a,(void*)C_INSTALL_LIB_HOME),C_fix(0));}
else{
/* ##sys#peek-c-string */
t7=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,C_mpointer(&a,(void*)C_TARGET_LIB_HOME),C_fix(0));}}

/* k3496 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_3498(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3498,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3502,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 203  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[117]+1)))(4,*((C_word*)lf[117]+1),t2,lf[345],C_retrieve2(lf[52],"default-unsafe-library"));}

/* k3500 in k3496 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_3502(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 201  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[117]+1)))(4,*((C_word*)lf[117]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3492 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_3494(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 200  prefix */
f_973(((C_word*)t0)[2],C_retrieve2(lf[52],"default-unsafe-library"),lf[344],t1);}

/* k3488 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_3490(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 199  quotewrap */
t2=C_retrieve2(lf[21],"quotewrap");
f_986(3,t2,((C_word*)t0)[2],t1);}

/* k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_3486(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3486,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=C_mutate(&lf[75] /* (set! unsafe-library-files ...) */,t2);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1110,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[5],"msvc"))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3482,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 205  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[117]+1)))(4,*((C_word*)lf[117]+1),t5,lf[342],C_retrieve2(lf[35],"library-extension"));}
else{
t5=t4;
f_1110(t5,lf[343]);}}

/* k3480 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_3482(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3482,2,t0,t1);}
t2=((C_word*)t0)[2];
f_1110(t2,(C_word)C_a_i_list(&a,1,t1));}

/* k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_fcall f_1110(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1110,NULL,2,t0,t1);}
t2=C_mutate(&lf[76] /* (set! unsafe-shared-library-files ...) */,t1);
t3=C_mutate(&lf[77] /* (set! gui-library-files ...) */,C_retrieve2(lf[73],"default-library-files"));
t4=C_mutate(&lf[78] /* (set! gui-shared-library-files ...) */,C_retrieve2(lf[74],"default-shared-library-files"));
t5=C_mutate(&lf[79] /* (set! library-files ...) */,C_retrieve2(lf[73],"default-library-files"));
t6=C_mutate(&lf[80] /* (set! shared-library-files ...) */,C_retrieve2(lf[74],"default-shared-library-files"));
t7=lf[81] /* translate-options */ =C_SCHEME_END_OF_LIST;;
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1119,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3469,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[17],"host-mode"))){
/* ##sys#peek-c-string */
t10=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t9,C_mpointer(&a,(void*)C_INSTALL_INCLUDE_HOME),C_fix(0));}
else{
/* ##sys#peek-c-string */
t10=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t9,C_mpointer(&a,(void*)C_TARGET_INCLUDE_HOME),C_fix(0));}}

/* k3467 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_3469(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 215  prefix */
f_973(((C_word*)t0)[2],lf[340],lf[341],t1);}

/* k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_1119(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1119,2,t0,t1);}
t2=(C_word)C_i_member(t1,lf[82]);
t3=(C_truep(t2)?C_SCHEME_FALSE:t1);
t4=C_mutate(&lf[83] /* (set! include-dir ...) */,t3);
t5=lf[84] /* compile-options */ =C_SCHEME_END_OF_LIST;;
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1127,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[83],"include-dir"))){
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3454,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3458,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 222  quotewrap */
t9=C_retrieve2(lf[21],"quotewrap");
f_986(3,t9,t8,C_retrieve2(lf[83],"include-dir"));}
else{
t7=t6;
f_1127(t7,C_SCHEME_END_OF_LIST);}}

/* k3456 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_3458(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 222  conc */
((C_proc4)C_retrieve_symbol_proc(lf[330]))(4,*((C_word*)lf[330]+1),((C_word*)t0)[2],lf[339],t1);}

/* k3452 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_3454(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3454,2,t0,t1);}
t2=((C_word*)t0)[2];
f_1127(t2,(C_word)C_a_i_list(&a,1,t1));}

/* k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_fcall f_1127(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1127,NULL,2,t0,t1);}
t2=C_mutate(&lf[85] /* (set! builtin-compile-options ...) */,t1);
t3=C_mutate(&lf[86] /* (set! compilation-optimization-options ...) */,C_retrieve2(lf[54],"default-compilation-optimization-options"));
t4=C_mutate(&lf[87] /* (set! linking-optimization-options ...) */,C_retrieve2(lf[56],"default-linking-optimization-options"));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1135,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3441,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[17],"host-mode"))){
/* ##sys#peek-c-string */
t7=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,C_mpointer(&a,(void*)C_INSTALL_LIB_HOME),C_fix(0));}
else{
/* ##sys#peek-c-string */
t7=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,C_mpointer(&a,(void*)C_TARGET_LIB_HOME),C_fix(0));}}

/* k3439 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_3441(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 230  prefix */
f_973(((C_word*)t0)[2],lf[337],lf[338],t1);}

/* k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_1135(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1135,2,t0,t1);}
t2=C_mutate(&lf[88] /* (set! library-dir ...) */,t1);
t3=lf[89] /* link-options */ =C_SCHEME_END_OF_LIST;;
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1140,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t5=(C_truep(C_retrieve2(lf[7],"osx"))?C_retrieve2(lf[7],"osx"):(C_truep(C_retrieve2(lf[8],"hpux-hppa"))?C_retrieve2(lf[8],"hpux-hppa"):C_retrieve2(lf[3],"mingw")));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3383,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3387,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 238  quotewrap */
t8=C_retrieve2(lf[21],"quotewrap");
f_986(3,t8,t7,C_retrieve2(lf[88],"library-dir"));}
else{
if(C_truep(C_retrieve2(lf[5],"msvc"))){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3397,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3401,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 240  quotewrap */
t8=C_retrieve2(lf[21],"quotewrap");
f_986(3,t8,t7,C_retrieve2(lf[88],"library-dir"));}
else{
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3408,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3434,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 243  quotewrap */
t8=C_retrieve2(lf[21],"quotewrap");
f_986(3,t8,t7,C_retrieve2(lf[88],"library-dir"));}}}

/* k3432 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_3434(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 243  conc */
((C_proc4)C_retrieve_symbol_proc(lf[330]))(4,*((C_word*)lf[330]+1),((C_word*)t0)[2],lf[336],t1);}

/* k3406 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_3408(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3408,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3412,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3416,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3420,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3424,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[17],"host-mode"))){
/* ##sys#peek-c-string */
t6=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,C_mpointer(&a,(void*)C_INSTALL_LIB_HOME),C_fix(0));}
else{
/* ##sys#peek-c-string */
t6=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,C_mpointer(&a,(void*)C_TARGET_RUN_LIB_HOME),C_fix(0));}}

/* k3422 in k3406 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_3424(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 244  prefix */
f_973(((C_word*)t0)[2],lf[334],lf[335],t1);}

/* k3418 in k3406 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_3420(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 244  quotewrap */
t2=C_retrieve2(lf[21],"quotewrap");
f_986(3,t2,((C_word*)t0)[2],t1);}

/* k3414 in k3406 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_3416(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 244  conc */
((C_proc4)C_retrieve_symbol_proc(lf[330]))(4,*((C_word*)lf[330]+1),((C_word*)t0)[2],lf[333],t1);}

/* k3410 in k3406 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_3412(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3412,2,t0,t1);}
t2=((C_word*)t0)[3];
f_1140(t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[2],t1));}

/* k3399 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_3401(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 240  conc */
((C_proc4)C_retrieve_symbol_proc(lf[330]))(4,*((C_word*)lf[330]+1),((C_word*)t0)[2],lf[332],t1);}

/* k3395 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_3397(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3397,2,t0,t1);}
t2=((C_word*)t0)[2];
f_1140(t2,(C_word)C_a_i_list(&a,1,t1));}

/* k3385 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_3387(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 238  conc */
((C_proc4)C_retrieve_symbol_proc(lf[330]))(4,*((C_word*)lf[330]+1),((C_word*)t0)[2],lf[331],t1);}

/* k3381 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_3383(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3383,2,t0,t1);}
t2=((C_word*)t0)[2];
f_1140(t2,(C_word)C_a_i_list(&a,1,t1));}

/* k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_fcall f_1140(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word ab[26],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1140,NULL,2,t0,t1);}
t2=C_mutate(&lf[90] /* (set! builtin-link-options ...) */,t1);
t3=lf[91] /* target-filename */ =C_SCHEME_FALSE;;
t4=lf[92] /* verbose */ =C_SCHEME_FALSE;;
t5=lf[93] /* keep-files */ =C_SCHEME_FALSE;;
t6=lf[94] /* translate-only */ =C_SCHEME_FALSE;;
t7=lf[95] /* compile-only */ =C_SCHEME_FALSE;;
t8=lf[96] /* to-stdout */ =C_SCHEME_FALSE;;
t9=lf[97] /* shared */ =C_SCHEME_FALSE;;
t10=lf[98] /* static */ =C_SCHEME_FALSE;;
t11=lf[99] /* static-libs */ =C_SCHEME_FALSE;;
t12=lf[100] /* static-extensions */ =C_SCHEME_END_OF_LIST;;
t13=lf[101] /* required-extensions */ =C_SCHEME_END_OF_LIST;;
t14=lf[102] /* gui */ =C_SCHEME_FALSE;;
t15=C_mutate(&lf[103] /* (set! compiler-options ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2830,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate(&lf[108] /* (set! static-extension-info ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2982,tmp=(C_word)a,a+=2,tmp));
t17=C_mutate(&lf[114] /* (set! linker-options ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3079,tmp=(C_word)a,a+=2,tmp));
t18=C_mutate(&lf[118] /* (set! linker-libraries ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3131,tmp=(C_word)a,a+=2,tmp));
t19=C_mutate(&lf[120] /* (set! constant697 ...) */,lf[121]);
t20=C_mutate(&lf[106] /* (set! quote-option ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3280,tmp=(C_word)a,a+=2,tmp));
t21=lf[130] /* last-exit-code */ =C_SCHEME_FALSE;;
t22=C_mutate(&lf[131] /* (set! $system ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3305,tmp=(C_word)a,a+=2,tmp));
t23=C_mutate(&lf[138] /* (set! $delete-file ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3336,tmp=(C_word)a,a+=2,tmp));
t24=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3352,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t25=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3362,a[2]=t24,tmp=(C_word)a,a+=3,tmp);
t26=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3366,a[2]=t25,tmp=(C_word)a,a+=3,tmp);
t27=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3370,a[2]=t26,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 921  getenv */
((C_proc3)C_retrieve_symbol_proc(lf[328]))(3,*((C_word*)lf[328]+1),t27,lf[329]);}

/* k3368 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_3370(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?t1:lf[327]);
/* csc.scm: 921  string-split */
((C_proc3)C_retrieve_symbol_proc(lf[279]))(3,*((C_word*)lf[279]+1),((C_word*)t0)[2],t2);}

/* k3364 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_3366(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 921  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[107]+1)))(4,*((C_word*)lf[107]+1),((C_word*)t0)[2],t1,C_retrieve2(lf[15],"arguments"));}

/* k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_3362(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3362,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1163,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1170,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1209,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1238,a[2]=t4,a[3]=t3,a[4]=t2,a[5]=t6,tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_1238(t8,((C_word*)t0)[2],t1);}

/* loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_fcall f_1238(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1238,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1249,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 480  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[107]+1)))(4,*((C_word*)lf[107]+1),t3,C_retrieve2(lf[84],"compile-options"),C_retrieve2(lf[85],"builtin-compile-options"));}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=t4;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1436,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t6,a[7]=t1,a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
/* csc.scm: 526  string->symbol */
((C_proc3)C_retrieve_proc(*((C_word*)lf[326]+1)))(3,*((C_word*)lf[326]+1),t7,t3);}}

/* k1434 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_1436(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word t98;
C_word t99;
C_word t100;
C_word t101;
C_word t102;
C_word t103;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1436,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1439,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_eqp(t1,lf[177]);
t4=(C_truep(t3)?t3:(C_word)C_eqp(t1,lf[178]));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1451,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 266  display */
((C_proc3)C_retrieve_proc(*((C_word*)lf[179]+1)))(3,*((C_word*)lf[179]+1),t5,lf[180]);}
else{
t5=(C_word)C_eqp(t1,lf[181]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1463,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1470,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 532  chicken-version */
((C_proc2)C_retrieve_symbol_proc(lf[182]))(2,*((C_word*)lf[182]+1),t7);}
else{
t6=(C_word)C_eqp(t1,lf[183]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1479,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1486,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 535  sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[160]))(4,*((C_word*)lf[160]+1),t8,C_retrieve2(lf[25],"translator"),lf[184]);}
else{
t7=(C_word)C_eqp(t1,lf[185]);
if(C_truep(t7)){
t8=lf[63] /* cpp-mode */ =C_SCHEME_TRUE;;
if(C_truep(C_retrieve2(lf[7],"osx"))){
t9=(C_word)C_a_i_cons(&a,2,lf[186],C_retrieve2(lf[84],"compile-options"));
t10=C_mutate(&lf[84] /* (set! compile-options ...) */,t9);
t11=t2;
f_1439(2,t11,t10);}
else{
t9=t2;
f_1439(2,t9,C_SCHEME_UNDEFINED);}}
else{
t8=(C_word)C_eqp(t1,lf[187]);
if(C_truep(t8)){
t9=lf[64] /* objc-mode */ =C_SCHEME_TRUE;;
t10=t2;
f_1439(2,t10,t9);}
else{
t9=(C_word)C_eqp(t1,lf[188]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1517,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 543  cons* */
((C_proc5)C_retrieve_symbol_proc(lf[127]))(5,*((C_word*)lf[127]+1),t10,lf[189],lf[190],C_retrieve2(lf[81],"translate-options"));}
else{
t10=(C_word)C_eqp(t1,lf[191]);
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1528,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 546  cons* */
((C_proc5)C_retrieve_symbol_proc(lf[127]))(5,*((C_word*)lf[127]+1),t11,lf[192],lf[193],C_retrieve2(lf[81],"translate-options"));}
else{
t11=(C_word)C_eqp(t1,lf[194]);
if(C_truep(t11)){
t12=lf[66] /* inquiry-only */ =C_SCHEME_TRUE;;
t13=lf[67] /* show-cflags */ =C_SCHEME_TRUE;;
t14=t2;
f_1439(2,t14,t13);}
else{
t12=(C_word)C_eqp(t1,lf[195]);
if(C_truep(t12)){
t13=lf[66] /* inquiry-only */ =C_SCHEME_TRUE;;
t14=lf[68] /* show-ldflags */ =C_SCHEME_TRUE;;
t15=t2;
f_1439(2,t15,t14);}
else{
t13=(C_word)C_eqp(t1,lf[196]);
if(C_truep(t13)){
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1554,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 554  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[137]+1)))(3,*((C_word*)lf[137]+1),t14,C_retrieve2(lf[26],"compiler"));}
else{
t14=(C_word)C_eqp(t1,lf[197]);
if(C_truep(t14)){
t15=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1566,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 555  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[137]+1)))(3,*((C_word*)lf[137]+1),t15,C_retrieve2(lf[27],"c++-compiler"));}
else{
t15=(C_word)C_eqp(t1,lf[198]);
if(C_truep(t15)){
t16=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1578,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 556  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[137]+1)))(3,*((C_word*)lf[137]+1),t16,C_retrieve2(lf[28],"linker"));}
else{
t16=(C_word)C_eqp(t1,lf[199]);
if(C_truep(t16)){
t17=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1590,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 557  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[137]+1)))(3,*((C_word*)lf[137]+1),t17,C_retrieve2(lf[24],"home"));}
else{
t17=(C_word)C_eqp(t1,lf[200]);
if(C_truep(t17)){
t18=lf[66] /* inquiry-only */ =C_SCHEME_TRUE;;
t19=lf[69] /* show-libs */ =C_SCHEME_TRUE;;
t20=t2;
f_1439(2,t20,t19);}
else{
t18=(C_word)C_eqp(t1,lf[201]);
if(C_truep(t18)){
t19=lf[92] /* verbose */ =C_SCHEME_TRUE;;
t20=t2;
f_1439(2,t20,t19);}
else{
t19=(C_word)C_eqp(t1,lf[202]);
t20=(C_truep(t19)?t19:(C_word)C_eqp(t1,lf[203]));
if(C_truep(t20)){
t21=lf[92] /* verbose */ =C_SCHEME_TRUE;;
/* csc.scm: 565  t-options */
f_1163(t2,(C_word)C_a_i_list(&a,1,lf[204]));}
else{
t21=(C_word)C_eqp(t1,lf[205]);
t22=(C_truep(t21)?t21:(C_word)C_eqp(t1,lf[206]));
if(C_truep(t22)){
t23=(C_word)C_a_i_cons(&a,2,lf[207],C_retrieve2(lf[84],"compile-options"));
t24=C_mutate(&lf[84] /* (set! compile-options ...) */,t23);
/* csc.scm: 568  t-options */
f_1163(t2,(C_word)C_a_i_list(&a,1,lf[208]));}
else{
t23=(C_word)C_eqp(t1,lf[209]);
if(C_truep(t23)){
t24=lf[92] /* verbose */ =C_SCHEME_TRUE;;
t25=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1647,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 571  t-options */
f_1163(t25,(C_word)C_a_i_list(&a,1,lf[214]));}
else{
t24=(C_word)C_eqp(t1,lf[215]);
t25=(C_truep(t24)?t24:(C_word)C_eqp(t1,lf[216]));
if(C_truep(t25)){
t26=lf[94] /* translate-only */ =C_SCHEME_TRUE;;
/* csc.scm: 577  t-options */
f_1163(t2,(C_word)C_a_i_list(&a,1,lf[217]));}
else{
t26=(C_word)C_eqp(t1,lf[218]);
t27=(C_truep(t26)?t26:(C_word)C_eqp(t1,lf[219]));
if(C_truep(t27)){
t28=lf[94] /* translate-only */ =C_SCHEME_TRUE;;
/* csc.scm: 580  t-options */
f_1163(t2,(C_word)C_a_i_list(&a,1,lf[220]));}
else{
t28=(C_word)C_eqp(t1,lf[221]);
if(C_truep(t28)){
t29=lf[93] /* keep-files */ =C_SCHEME_TRUE;;
t30=t2;
f_1439(2,t30,t29);}
else{
t29=(C_word)C_eqp(t1,lf[222]);
if(C_truep(t29)){
t30=lf[95] /* compile-only */ =C_SCHEME_TRUE;;
t31=t2;
f_1439(2,t31,t30);}
else{
t30=(C_word)C_eqp(t1,lf[223]);
if(C_truep(t30)){
t31=lf[94] /* translate-only */ =C_SCHEME_TRUE;;
t32=t2;
f_1439(2,t32,t31);}
else{
t31=(C_word)C_eqp(t1,lf[224]);
t32=(C_truep(t31)?t31:(C_word)C_eqp(t1,lf[225]));
if(C_truep(t32)){
t33=lf[65] /* embedded */ =C_SCHEME_TRUE;;
t34=(C_word)C_a_i_cons(&a,2,lf[226],C_retrieve2(lf[84],"compile-options"));
t35=C_mutate(&lf[84] /* (set! compile-options ...) */,t34);
t36=t2;
f_1439(2,t36,t35);}
else{
t33=(C_word)C_eqp(t1,lf[227]);
t34=(C_truep(t33)?t33:(C_word)C_eqp(t1,lf[228]));
if(C_truep(t34)){
t35=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1738,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* csc.scm: 588  check */
f_1170(t35,t1,((C_word*)((C_word*)t0)[6])[1],C_SCHEME_END_OF_LIST);}
else{
t35=(C_word)C_eqp(t1,lf[230]);
if(C_truep(t35)){
t36=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1770,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* csc.scm: 593  check */
f_1170(t36,t1,((C_word*)((C_word*)t0)[6])[1],C_SCHEME_END_OF_LIST);}
else{
t36=(C_word)C_eqp(t1,lf[232]);
t37=(C_truep(t36)?t36:(C_word)C_eqp(t1,lf[233]));
if(C_truep(t37)){
t38=lf[102] /* gui */ =C_SCHEME_TRUE;;
if(C_truep(C_retrieve2(lf[3],"mingw"))){
t39=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1810,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 602  cons* */
((C_proc7)C_retrieve_symbol_proc(lf[127]))(7,*((C_word*)lf[127]+1),t39,lf[235],lf[236],lf[237],lf[238],C_retrieve2(lf[89],"link-options"));}
else{
if(C_truep(C_retrieve2(lf[5],"msvc"))){
t39=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1821,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 607  cons* */
((C_proc6)C_retrieve_symbol_proc(lf[127]))(6,*((C_word*)lf[127]+1),t39,lf[240],lf[241],lf[242],C_retrieve2(lf[89],"link-options"));}
else{
t39=t2;
f_1439(2,t39,C_SCHEME_UNDEFINED);}}}
else{
t38=(C_word)C_eqp(t1,lf[243]);
if(C_truep(t38)){
t39=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1834,a[2]=t2,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 610  check */
f_1170(t39,t1,((C_word*)((C_word*)t0)[6])[1],C_SCHEME_END_OF_LIST);}
else{
t39=(C_word)C_eqp(t1,lf[245]);
if(C_truep(t39)){
t40=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1858,a[2]=t2,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 615  check */
f_1170(t40,t1,((C_word*)((C_word*)t0)[6])[1],C_SCHEME_END_OF_LIST);}
else{
t40=(C_word)C_eqp(t1,lf[246]);
t41=(C_truep(t40)?t40:(C_word)C_eqp(t1,lf[247]));
if(C_truep(t41)){
t42=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1879,a[2]=t2,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 619  cons* */
((C_proc5)C_retrieve_symbol_proc(lf[127]))(5,*((C_word*)lf[127]+1),t42,lf[248],lf[249],((C_word*)((C_word*)t0)[6])[1]);}
else{
t42=(C_word)C_eqp(t1,lf[250]);
if(C_truep(t42)){
t43=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1889,a[2]=t2,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 620  cons* */
((C_proc5)C_retrieve_symbol_proc(lf[127]))(5,*((C_word*)lf[127]+1),t43,lf[251],lf[252],((C_word*)((C_word*)t0)[6])[1]);}
else{
t43=(C_word)C_eqp(t1,lf[253]);
if(C_truep(t43)){
t44=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1899,a[2]=t2,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 621  cons* */
((C_proc5)C_retrieve_symbol_proc(lf[127]))(5,*((C_word*)lf[127]+1),t44,lf[254],lf[255],((C_word*)((C_word*)t0)[6])[1]);}
else{
t44=(C_word)C_eqp(t1,lf[256]);
if(C_truep(t44)){
t45=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1909,a[2]=t2,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 622  cons* */
((C_proc5)C_retrieve_symbol_proc(lf[127]))(5,*((C_word*)lf[127]+1),t45,lf[257],lf[258],((C_word*)((C_word*)t0)[6])[1]);}
else{
t45=(C_word)C_eqp(t1,lf[259]);
if(C_truep(t45)){
t46=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1919,a[2]=t2,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 623  cons* */
((C_proc5)C_retrieve_symbol_proc(lf[127]))(5,*((C_word*)lf[127]+1),t46,lf[260],lf[261],((C_word*)((C_word*)t0)[6])[1]);}
else{
t46=(C_word)C_eqp(t1,lf[262]);
if(C_truep(t46)){
t47=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1929,a[2]=t2,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 624  cons* */
((C_proc5)C_retrieve_symbol_proc(lf[127]))(5,*((C_word*)lf[127]+1),t47,lf[263],lf[264],((C_word*)((C_word*)t0)[6])[1]);}
else{
t47=(C_word)C_eqp(t1,lf[265]);
if(C_truep(t47)){
t48=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1939,a[2]=t2,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 625  cons* */
((C_proc5)C_retrieve_symbol_proc(lf[127]))(5,*((C_word*)lf[127]+1),t48,lf[266],lf[267],((C_word*)((C_word*)t0)[6])[1]);}
else{
t48=(C_word)C_eqp(t1,lf[268]);
if(C_truep(t48)){
t49=lf[92] /* verbose */ =C_SCHEME_TRUE;;
t50=lf[70] /* dry-run */ =C_SCHEME_TRUE;;
t51=t2;
f_1439(2,t51,t50);}
else{
t49=(C_word)C_eqp(t1,lf[269]);
t50=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1956,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=t2,a[8]=((C_word*)t0)[3],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t49)){
t51=t50;
f_1956(t51,t49);}
else{
t51=(C_word)C_eqp(t1,lf[324]);
t52=t50;
f_1956(t52,(C_truep(t51)?t51:(C_word)C_eqp(t1,lf[325])));}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}

/* k1954 in k1434 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_fcall f_1956(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1956,NULL,2,t0,t1);}
if(C_truep(t1)){
/* csc.scm: 630  shared-build */
f_1209(((C_word*)t0)[7],C_SCHEME_FALSE);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[6],lf[270]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(((C_word*)t0)[6],lf[271]));
if(C_truep(t3)){
/* csc.scm: 632  shared-build */
f_1209(((C_word*)t0)[7],C_SCHEME_TRUE);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[6],lf[272]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1980,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 634  check */
f_1170(t5,((C_word*)t0)[6],((C_word*)((C_word*)t0)[5])[1],C_SCHEME_END_OF_LIST);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[6],lf[273]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1997,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 638  check */
f_1170(t6,((C_word*)t0)[6],((C_word*)((C_word*)t0)[5])[1],C_SCHEME_END_OF_LIST);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[6],lf[274]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2014,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 642  check */
f_1170(t7,((C_word*)t0)[6],((C_word*)((C_word*)t0)[5])[1],C_SCHEME_END_OF_LIST);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[6],lf[275]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2031,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 646  check */
f_1170(t8,((C_word*)t0)[6],((C_word*)((C_word*)t0)[5])[1],C_SCHEME_END_OF_LIST);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[6],lf[276]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2048,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 650  check */
f_1170(t9,((C_word*)t0)[6],((C_word*)((C_word*)t0)[5])[1],C_SCHEME_END_OF_LIST);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[6],lf[278]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2069,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 653  check */
f_1170(t10,((C_word*)t0)[6],((C_word*)((C_word*)t0)[5])[1],C_SCHEME_END_OF_LIST);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[6],lf[280]);
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2095,a[2]=((C_word*)t0)[7],tmp=(C_word)a,a+=3,tmp);
t12=(C_word)C_a_i_list(&a,1,lf[281]);
/* csc.scm: 657  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[107]+1)))(4,*((C_word*)lf[107]+1),t11,C_retrieve2(lf[89],"link-options"),t12);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[6],lf[282]);
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2108,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 659  check */
f_1170(t12,((C_word*)t0)[6],((C_word*)((C_word*)t0)[5])[1],C_SCHEME_END_OF_LIST);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[6],lf[283]);
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2133,a[2]=((C_word*)t0)[7],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 663  t-options */
f_1163(t13,(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]));}
else{
t13=(C_word)C_eqp(((C_word*)t0)[6],lf[284]);
if(C_truep(t13)){
t14=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2144,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 667  check */
f_1170(t14,((C_word*)t0)[6],((C_word*)((C_word*)t0)[5])[1],C_SCHEME_END_OF_LIST);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[6],lf[288]);
if(C_truep(t14)){
t15=((C_word*)t0)[7];
f_1439(2,t15,C_SCHEME_FALSE);}
else{
t15=(C_word)C_eqp(((C_word*)t0)[6],lf[289]);
if(C_truep(t15)){
t16=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2190,a[2]=((C_word*)t0)[7],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 673  make-pathname */
((C_proc5)C_retrieve_symbol_proc(lf[20]))(5,*((C_word*)lf[20]+1),t16,C_SCHEME_FALSE,lf[291],C_retrieve2(lf[41],"executable-extension"));}
else{
t16=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2197,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t17=((C_word*)t0)[6];
if(C_truep((C_truep((C_word)C_eqp(t17,lf[323]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t17,lf[321]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
t18=(C_word)C_eqp(((C_word*)t0)[6],lf[321]);
if(C_truep(t18)){
t19=C_mutate(&lf[79] /* (set! library-files ...) */,C_retrieve2(lf[75],"unsafe-library-files"));
t20=C_mutate(&lf[80] /* (set! shared-library-files ...) */,C_retrieve2(lf[76],"unsafe-shared-library-files"));
t21=t16;
f_2197(t21,t20);}
else{
t19=t16;
f_2197(t19,C_SCHEME_UNDEFINED);}}
else{
t18=t16;
f_2197(t18,C_SCHEME_UNDEFINED);}}}}}}}}}}}}}}}}

/* k2195 in k1954 in k1434 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_fcall f_2197(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2197,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2200,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[7],lf[322]);
if(C_truep(t3)){
t4=lf[96] /* to-stdout */ =C_SCHEME_TRUE;;
t5=lf[94] /* translate-only */ =C_SCHEME_TRUE;;
t6=t2;
f_2200(t6,t5);}
else{
t4=t2;
f_2200(t4,C_SCHEME_UNDEFINED);}}

/* k2198 in k2195 in k1954 in k1434 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_fcall f_2200(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2200,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2203,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=((C_word*)t0)[7];
if(C_truep((C_truep((C_word)C_eqp(t3,lf[320]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,lf[321]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
t4=C_mutate(&lf[86] /* (set! compilation-optimization-options ...) */,C_retrieve2(lf[55],"best-compilation-optimization-options"));
t5=C_mutate(&lf[87] /* (set! linking-optimization-options ...) */,C_retrieve2(lf[57],"best-linking-optimization-options"));
t6=t2;
f_2203(t6,t5);}
else{
t4=t2;
f_2203(t4,C_SCHEME_UNDEFINED);}}

/* k2201 in k2198 in k2195 in k1954 in k1434 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_fcall f_2203(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2203,NULL,2,t0,t1);}
t2=(C_word)C_i_assq(((C_word*)t0)[7],lf[292]);
if(C_truep(t2)){
t3=(C_word)C_i_cadr(t2);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)((C_word*)t0)[6])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[6])+1,t4);
t6=((C_word*)t0)[5];
f_1439(2,t6,t5);}
else{
if(C_truep((C_word)C_i_memq(((C_word*)t0)[7],lf[293]))){
/* csc.scm: 687  t-options */
f_1163(((C_word*)t0)[5],(C_word)C_a_i_list(&a,1,((C_word*)t0)[3]));}
else{
if(C_truep((C_word)C_i_memq(((C_word*)t0)[7],lf[294]))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2235,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* csc.scm: 689  check */
f_1170(t3,((C_word*)t0)[7],((C_word*)((C_word*)t0)[6])[1],C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2254,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_i_string_length(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_greaterp(t4,C_fix(2)))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2585,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 694  substring */
((C_proc5)C_retrieve_proc(*((C_word*)lf[296]+1)))(5,*((C_word*)lf[296]+1),t5,((C_word*)t0)[3],C_fix(0),C_fix(2));}
else{
t5=t3;
f_2254(t5,C_SCHEME_FALSE);}}}}}

/* k2583 in k2201 in k2198 in k2195 in k1954 in k1434 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_2585(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_2254(t2,(C_word)C_i_string_equal_p(lf[319],t1));}

/* k2252 in k2201 in k2198 in k2195 in k1954 in k1434 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_fcall f_2254(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2254,NULL,2,t0,t1);}
if(C_truep(t1)){
/* csc.scm: 695  t-options */
f_1163(((C_word*)t0)[5],(C_word)C_a_i_list(&a,1,((C_word*)t0)[4]));}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2263,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_string_length(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_greaterp(t3,C_fix(1)))){
t4=(C_word)C_i_string_ref(((C_word*)t0)[4],C_fix(0));
t5=t2;
f_2263(t5,(C_word)C_eqp(C_make_character(45),t4));}
else{
t4=t2;
f_2263(t4,C_SCHEME_FALSE);}}}

/* k2261 in k2252 in k2201 in k2198 in k2195 in k1954 in k1434 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_fcall f_2263(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2263,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_string_ref(((C_word*)t0)[6],C_fix(1));
t3=(C_word)C_eqp(C_make_character(108),t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2273,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_a_i_list(&a,1,((C_word*)t0)[6]);
/* csc.scm: 699  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[107]+1)))(4,*((C_word*)lf[107]+1),t4,C_retrieve2(lf[89],"link-options"),t5);}
else{
t4=(C_word)C_i_string_ref(((C_word*)t0)[6],C_fix(1));
t5=(C_word)C_eqp(C_make_character(76),t4);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2287,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t7=(C_word)C_a_i_list(&a,1,((C_word*)t0)[6]);
/* csc.scm: 701  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[107]+1)))(4,*((C_word*)lf[107]+1),t6,C_retrieve2(lf[89],"link-options"),t7);}
else{
t6=(C_word)C_i_string_ref(((C_word*)t0)[6],C_fix(1));
t7=(C_word)C_eqp(C_make_character(73),t6);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2301,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t9=(C_word)C_a_i_list(&a,1,((C_word*)t0)[6]);
/* csc.scm: 703  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[107]+1)))(4,*((C_word*)lf[107]+1),t8,C_retrieve2(lf[84],"compile-options"),t9);}
else{
t8=(C_word)C_i_string_ref(((C_word*)t0)[6],C_fix(1));
t9=(C_word)C_eqp(C_make_character(68),t8);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2318,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 705  substring */
((C_proc4)C_retrieve_proc(*((C_word*)lf[296]+1)))(4,*((C_word*)lf[296]+1),t10,((C_word*)t0)[6],C_fix(2));}
else{
t10=(C_word)C_i_string_ref(((C_word*)t0)[6],C_fix(1));
t11=(C_word)C_eqp(C_make_character(70),t10);
if(C_truep(t11)){
if(C_truep(C_retrieve2(lf[7],"osx"))){
t12=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2331,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t13=(C_word)C_a_i_list(&a,1,((C_word*)t0)[6]);
/* csc.scm: 708  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[107]+1)))(4,*((C_word*)lf[107]+1),t12,C_retrieve2(lf[84],"compile-options"),t13);}
else{
t12=((C_word*)t0)[5];
f_1439(2,t12,C_SCHEME_UNDEFINED);}}
else{
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2341,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t13=(C_word)C_i_string_length(((C_word*)t0)[6]);
if(C_truep((C_word)C_i_greaterp(t13,C_fix(3)))){
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2410,a[2]=t12,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 709  substring */
((C_proc5)C_retrieve_proc(*((C_word*)lf[296]+1)))(5,*((C_word*)lf[296]+1),t14,((C_word*)t0)[6],C_fix(0),C_fix(4));}
else{
t14=t12;
f_2341(t14,C_SCHEME_FALSE);}}}}}}}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2440,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* csc.scm: 718  file-exists? */
((C_proc3)C_retrieve_symbol_proc(lf[317]))(3,*((C_word*)lf[317]+1),t2,((C_word*)t0)[6]);}}

/* k2438 in k2261 in k2252 in k2201 in k2198 in k2195 in k1954 in k1434 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_2440(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2440,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2445,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2451,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[3],t2,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2548,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* csc.scm: 735  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[117]+1)))(4,*((C_word*)lf[117]+1),t2,((C_word*)t0)[4],lf[318]);}}

/* k2546 in k2438 in k2261 in k2252 in k2201 in k2198 in k2195 in k1954 in k1434 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_2548(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2548,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2554,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* csc.scm: 736  file-exists? */
((C_proc3)C_retrieve_symbol_proc(lf[317]))(3,*((C_word*)lf[317]+1),t2,t1);}

/* k2552 in k2546 in k2438 in k2261 in k2252 in k2201 in k2198 in k2195 in k1954 in k1434 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_2554(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2554,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)((C_word*)t0)[4])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[4])+1,t2);
t4=((C_word*)t0)[3];
f_1439(2,t4,t3);}
else{
/* csc.scm: 738  quit */
f_944(((C_word*)t0)[3],lf[316],(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]));}}

/* a2450 in k2438 in k2261 in k2252 in k2201 in k2198 in k2195 in k1954 in k1434 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_2451(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word ab[7],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2451,5,t0,t1,t2,t3,t4);}
t5=t4;
if(C_truep(t5)){
t6=t4;
if(C_truep((C_truep((C_word)C_i_equalp(t6,lf[305]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t6,lf[306]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2476,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
/* csc.scm: 722  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[107]+1)))(4,*((C_word*)lf[107]+1),t7,C_retrieve2(lf[59],"c-files"),t8);}
else{
t7=t4;
if(C_truep((C_truep((C_word)C_i_equalp(t7,lf[307]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t7,lf[308]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t7,lf[309]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t7,lf[310]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t7,lf[311]))?C_SCHEME_TRUE:C_SCHEME_FALSE))))))){
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2489,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[7],"osx"))){
t9=(C_word)C_a_i_cons(&a,2,lf[312],C_retrieve2(lf[84],"compile-options"));
t10=C_mutate(&lf[84] /* (set! compile-options ...) */,t9);
t11=t8;
f_2489(t11,t10);}
else{
t9=t8;
f_2489(t9,C_SCHEME_UNDEFINED);}}
else{
t8=t4;
if(C_truep((C_truep((C_word)C_i_equalp(t8,lf[313]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t8,lf[314]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t8,lf[315]))?C_SCHEME_TRUE:C_SCHEME_FALSE))))){
t9=lf[64] /* objc-mode */ =C_SCHEME_TRUE;;
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2513,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t11=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
/* csc.scm: 729  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[107]+1)))(4,*((C_word*)lf[107]+1),t10,C_retrieve2(lf[59],"c-files"),t11);}
else{
t9=(C_word)C_i_string_equal_p(t4,C_retrieve2(lf[32],"object-extension"));
t10=(C_truep(t9)?t9:(C_word)C_i_string_equal_p(t4,C_retrieve2(lf[35],"library-extension")));
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2530,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t12=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
/* csc.scm: 732  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[107]+1)))(4,*((C_word*)lf[107]+1),t11,C_retrieve2(lf[61],"object-files"),t12);}
else{
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2538,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t12=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
/* csc.scm: 733  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[107]+1)))(4,*((C_word*)lf[107]+1),t11,C_retrieve2(lf[58],"scheme-files"),t12);}}}}}
else{
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2462,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t7=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
/* csc.scm: 720  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[107]+1)))(4,*((C_word*)lf[107]+1),t6,C_retrieve2(lf[58],"scheme-files"),t7);}}

/* k2460 in a2450 in k2438 in k2261 in k2252 in k2201 in k2198 in k2195 in k1954 in k1434 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_2462(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[58] /* (set! scheme-files ...) */,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2536 in a2450 in k2438 in k2261 in k2252 in k2201 in k2198 in k2195 in k1954 in k1434 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_2538(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[58] /* (set! scheme-files ...) */,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2528 in a2450 in k2438 in k2261 in k2252 in k2201 in k2198 in k2195 in k1954 in k1434 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_2530(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[61] /* (set! object-files ...) */,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2511 in a2450 in k2438 in k2261 in k2252 in k2201 in k2198 in k2195 in k1954 in k1434 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_2513(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[59] /* (set! c-files ...) */,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2487 in a2450 in k2438 in k2261 in k2252 in k2201 in k2198 in k2195 in k1954 in k1434 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_fcall f_2489(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2489,NULL,2,t0,t1);}
t2=lf[63] /* cpp-mode */ =C_SCHEME_TRUE;;
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2494,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
/* csc.scm: 726  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[107]+1)))(4,*((C_word*)lf[107]+1),t3,C_retrieve2(lf[59],"c-files"),t4);}

/* k2492 in k2487 in a2450 in k2438 in k2261 in k2252 in k2201 in k2198 in k2195 in k1954 in k1434 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_2494(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[59] /* (set! c-files ...) */,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2474 in a2450 in k2438 in k2261 in k2252 in k2201 in k2198 in k2195 in k1954 in k1434 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_2476(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[59] /* (set! c-files ...) */,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* a2444 in k2438 in k2261 in k2252 in k2201 in k2198 in k2195 in k1954 in k1434 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_2445(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2445,2,t0,t1);}
/* csc.scm: 719  decompose-pathname */
((C_proc3)C_retrieve_symbol_proc(lf[304]))(3,*((C_word*)lf[304]+1),t1,((C_word*)t0)[2]);}

/* k2408 in k2261 in k2252 in k2201 in k2198 in k2195 in k1954 in k1434 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_2410(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_2341(t2,(C_word)C_i_string_equal_p(lf[303],t1));}

/* k2339 in k2261 in k2252 in k2201 in k2198 in k2195 in k1954 in k1434 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_fcall f_2341(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2341,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2345,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_a_i_list(&a,1,((C_word*)t0)[4]);
/* csc.scm: 710  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[107]+1)))(4,*((C_word*)lf[107]+1),t2,C_retrieve2(lf[89],"link-options"),t3);}
else{
t2=(C_word)C_i_string_length(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_greaterp(t2,C_fix(2)))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2393,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* string->list */
t4=C_retrieve(lf[128]);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[4]);}
else{
/* csc.scm: 717  quit */
f_944(((C_word*)t0)[5],lf[302],(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]));}}}

/* k2391 in k2339 in k2261 in k2252 in k2201 in k2198 in k2195 in k1954 in k1434 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_2393(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2393,2,t0,t1);}
t2=(C_word)C_i_cdr(t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2389,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* csc.scm: 713  lset-difference */
((C_proc5)C_retrieve_symbol_proc(lf[299]))(5,*((C_word*)lf[299]+1),t3,*((C_word*)lf[300]+1),t2,lf[301]);}

/* k2387 in k2391 in k2339 in k2261 in k2252 in k2201 in k2198 in k2195 in k1954 in k1434 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_2389(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2389,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2368,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2372,a[2]=((C_word*)t0)[5],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2374,tmp=(C_word)a,a+=2,tmp);
/* map */
t5=*((C_word*)lf[105]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[3]);}
else{
/* csc.scm: 716  quit */
f_944(((C_word*)t0)[4],lf[298],(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]));}}

/* a2373 in k2387 in k2391 in k2339 in k2261 in k2252 in k2201 in k2198 in k2195 in k1954 in k1434 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_2374(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2374,3,t0,t1,t2);}
t3=(C_word)C_a_i_string(&a,1,t2);
/* csc.scm: 715  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[117]+1)))(4,*((C_word*)lf[117]+1),t1,lf[297],t3);}

/* k2370 in k2387 in k2391 in k2339 in k2261 in k2252 in k2201 in k2198 in k2195 in k1954 in k1434 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_2372(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 715  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[107]+1)))(4,*((C_word*)lf[107]+1),((C_word*)t0)[3],t1,((C_word*)((C_word*)t0)[2])[1]);}

/* k2366 in k2387 in k2391 in k2339 in k2261 in k2252 in k2201 in k2198 in k2195 in k1954 in k1434 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_2368(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_1439(2,t3,t2);}

/* k2343 in k2339 in k2261 in k2252 in k2201 in k2198 in k2195 in k1954 in k1434 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_2345(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[89] /* (set! link-options ...) */,t1);
t3=((C_word*)t0)[2];
f_1439(2,t3,t2);}

/* k2329 in k2261 in k2252 in k2201 in k2198 in k2195 in k1954 in k1434 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_2331(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[84] /* (set! compile-options ...) */,t1);
t3=((C_word*)t0)[2];
f_1439(2,t3,t2);}

/* k2316 in k2261 in k2252 in k2201 in k2198 in k2195 in k1954 in k1434 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_2318(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2318,2,t0,t1);}
/* csc.scm: 705  t-options */
f_1163(((C_word*)t0)[2],(C_word)C_a_i_list(&a,2,lf[295],t1));}

/* k2299 in k2261 in k2252 in k2201 in k2198 in k2195 in k1954 in k1434 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_2301(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[84] /* (set! compile-options ...) */,t1);
t3=((C_word*)t0)[2];
f_1439(2,t3,t2);}

/* k2285 in k2261 in k2252 in k2201 in k2198 in k2195 in k1954 in k1434 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_2287(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[89] /* (set! link-options ...) */,t1);
t3=((C_word*)t0)[2];
f_1439(2,t3,t2);}

/* k2271 in k2261 in k2252 in k2201 in k2198 in k2195 in k1954 in k1434 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_2273(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[89] /* (set! link-options ...) */,t1);
t3=((C_word*)t0)[2];
f_1439(2,t3,t2);}

/* k2233 in k2201 in k2198 in k2195 in k1954 in k1434 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_2235(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2235,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)((C_word*)t0)[5])[1]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2241,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* csc.scm: 691  string->number */
C_string_to_number(3,0,t3,t2);}

/* k2239 in k2233 in k2201 in k2198 in k2195 in k1954 in k1434 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_2241(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2241,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2244,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 692  t-options */
f_1163(t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]));}

/* k2242 in k2239 in k2233 in k2201 in k2198 in k2195 in k1954 in k1434 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_2244(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
f_1439(2,t4,t3);}

/* k2188 in k1954 in k1434 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_2190(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2190,2,t0,t1);}
t2=C_mutate(&lf[91] /* (set! target-filename ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2194,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 674  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[107]+1)))(4,*((C_word*)lf[107]+1),t3,C_retrieve2(lf[58],"scheme-files"),lf[290]);}

/* k2192 in k2188 in k1954 in k1434 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_2194(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[58] /* (set! scheme-files ...) */,t1);
t3=((C_word*)t0)[2];
f_1439(2,t3,t2);}

/* k2142 in k1954 in k1434 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_2144(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2144,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2174,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 668  build-platform */
((C_proc2)C_retrieve_symbol_proc(lf[287]))(2,*((C_word*)lf[287]+1),t2);}

/* k2172 in k2142 in k1954 in k1434 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_2174(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2174,2,t0,t1);}
t2=(C_word)C_eqp(lf[285],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2154,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2166,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_i_car(((C_word*)((C_word*)t0)[3])[1]);
/* csc.scm: 669  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[117]+1)))(4,*((C_word*)lf[117]+1),t4,lf[286],t5);}
else{
t3=((C_word*)t0)[2];
f_1439(2,t3,C_SCHEME_UNDEFINED);}}

/* k2164 in k2172 in k2142 in k1954 in k1434 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_2166(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2166,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* csc.scm: 669  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[107]+1)))(4,*((C_word*)lf[107]+1),((C_word*)t0)[2],C_retrieve2(lf[89],"link-options"),t2);}

/* k2152 in k2172 in k2142 in k1954 in k1434 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_2154(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(&lf[89] /* (set! link-options ...) */,t1);
t3=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=((C_word*)t0)[2];
f_1439(2,t5,t4);}

/* k2131 in k1954 in k1434 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_2133(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(&lf[79] /* (set! library-files ...) */,C_retrieve2(lf[75],"unsafe-library-files"));
t3=C_mutate(&lf[80] /* (set! shared-library-files ...) */,C_retrieve2(lf[76],"unsafe-shared-library-files"));
t4=((C_word*)t0)[2];
f_1439(2,t4,t3);}

/* k2106 in k1954 in k1434 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_2108(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2108,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2112,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2120,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_car(((C_word*)((C_word*)t0)[3])[1]);
/* csc.scm: 660  string-split */
((C_proc3)C_retrieve_symbol_proc(lf[279]))(3,*((C_word*)lf[279]+1),t3,t4);}

/* k2118 in k2106 in k1954 in k1434 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_2120(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 660  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[107]+1)))(4,*((C_word*)lf[107]+1),((C_word*)t0)[2],C_retrieve2(lf[89],"link-options"),t1);}

/* k2110 in k2106 in k1954 in k1434 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_2112(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(&lf[89] /* (set! link-options ...) */,t1);
t3=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=((C_word*)t0)[2];
f_1439(2,t5,t4);}

/* k2093 in k1954 in k1434 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_2095(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[89] /* (set! link-options ...) */,t1);
t3=((C_word*)t0)[2];
f_1439(2,t3,t2);}

/* k2067 in k1954 in k1434 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_2069(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2069,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2073,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2081,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_car(((C_word*)((C_word*)t0)[3])[1]);
/* csc.scm: 654  string-split */
((C_proc3)C_retrieve_symbol_proc(lf[279]))(3,*((C_word*)lf[279]+1),t3,t4);}

/* k2079 in k2067 in k1954 in k1434 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_2081(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 654  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[107]+1)))(4,*((C_word*)lf[107]+1),((C_word*)t0)[2],C_retrieve2(lf[84],"compile-options"),t1);}

/* k2071 in k2067 in k1954 in k1434 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_2073(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(&lf[84] /* (set! compile-options ...) */,t1);
t3=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=((C_word*)t0)[2];
f_1439(2,t5,t4);}

/* k2046 in k1954 in k1434 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_2048(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2048,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2052,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)((C_word*)t0)[3])[1]);
t4=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
/* csc.scm: 651  cons* */
((C_proc5)C_retrieve_symbol_proc(lf[127]))(5,*((C_word*)lf[127]+1),t2,lf[277],t3,t4);}

/* k2050 in k2046 in k1954 in k1434 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_2052(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_1439(2,t3,t2);}

/* k2029 in k1954 in k1434 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_2031(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_word)C_i_car(((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(&lf[28] /* (set! linker ...) */,t2);
t4=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[3])+1,t4);
t6=((C_word*)t0)[2];
f_1439(2,t6,t5);}

/* k2012 in k1954 in k1434 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_2014(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_word)C_i_car(((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(&lf[27] /* (set! c++-compiler ...) */,t2);
t4=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[3])+1,t4);
t6=((C_word*)t0)[2];
f_1439(2,t6,t5);}

/* k1995 in k1954 in k1434 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_1997(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_word)C_i_car(((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(&lf[26] /* (set! compiler ...) */,t2);
t4=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[3])+1,t4);
t6=((C_word*)t0)[2];
f_1439(2,t6,t5);}

/* k1978 in k1954 in k1434 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_1980(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_word)C_i_car(((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(&lf[25] /* (set! translator ...) */,t2);
t4=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[3])+1,t4);
t6=((C_word*)t0)[2];
f_1439(2,t6,t5);}

/* k1937 in k1434 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_1939(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_1439(2,t3,t2);}

/* k1927 in k1434 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_1929(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_1439(2,t3,t2);}

/* k1917 in k1434 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_1919(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_1439(2,t3,t2);}

/* k1907 in k1434 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_1909(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_1439(2,t3,t2);}

/* k1897 in k1434 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_1899(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_1439(2,t3,t2);}

/* k1887 in k1434 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_1889(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_1439(2,t3,t2);}

/* k1877 in k1434 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_1879(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_1439(2,t3,t2);}

/* k1856 in k1434 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_1858(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_word)C_i_car(((C_word*)((C_word*)t0)[3])[1]);
t3=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=C_mutate(&lf[91] /* (set! target-filename ...) */,t2);
t6=((C_word*)t0)[2];
f_1439(2,t6,t5);}

/* k1832 in k1434 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_1834(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1834,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1837,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[7],"osx"))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1845,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_car(((C_word*)((C_word*)t0)[3])[1]);
/* csc.scm: 612  cons* */
((C_proc5)C_retrieve_symbol_proc(lf[127]))(5,*((C_word*)lf[127]+1),t3,lf[244],t4,C_retrieve2(lf[89],"link-options"));}
else{
t3=t2;
f_1837(t3,C_SCHEME_UNDEFINED);}}

/* k1843 in k1832 in k1434 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_1845(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[89] /* (set! link-options ...) */,t1);
t3=((C_word*)t0)[2];
f_1837(t3,t2);}

/* k1835 in k1832 in k1434 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_fcall f_1837(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
f_1439(2,t4,t3);}

/* k1819 in k1434 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_1821(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1821,2,t0,t1);}
t2=C_mutate(&lf[89] /* (set! link-options ...) */,t1);
t3=(C_word)C_a_i_cons(&a,2,lf[239],C_retrieve2(lf[84],"compile-options"));
t4=C_mutate(&lf[84] /* (set! compile-options ...) */,t3);
t5=((C_word*)t0)[2];
f_1439(2,t5,t4);}

/* k1808 in k1434 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_1810(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1810,2,t0,t1);}
t2=C_mutate(&lf[89] /* (set! link-options ...) */,t1);
t3=(C_word)C_a_i_cons(&a,2,lf[234],C_retrieve2(lf[84],"compile-options"));
t4=C_mutate(&lf[84] /* (set! compile-options ...) */,t3);
t5=((C_word*)t0)[2];
f_1439(2,t5,t4);}

/* k1768 in k1434 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_1770(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1770,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1774,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_car(((C_word*)((C_word*)t0)[4])[1]);
t4=(C_word)C_a_i_list(&a,1,t3);
/* csc.scm: 594  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[107]+1)))(4,*((C_word*)lf[107]+1),t2,C_retrieve2(lf[100],"static-extensions"),t4);}

/* k1772 in k1768 in k1434 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_1774(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1774,2,t0,t1);}
t2=C_mutate(&lf[100] /* (set! static-extensions ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1777,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_car(((C_word*)((C_word*)t0)[4])[1]);
/* csc.scm: 595  t-options */
f_1163(t3,(C_word)C_a_i_list(&a,2,lf[231],t4));}

/* k1775 in k1772 in k1768 in k1434 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_1777(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
f_1439(2,t4,t3);}

/* k1736 in k1434 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_1738(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1738,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1742,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_car(((C_word*)((C_word*)t0)[4])[1]);
t4=(C_word)C_a_i_list(&a,1,t3);
/* csc.scm: 589  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[107]+1)))(4,*((C_word*)lf[107]+1),t2,C_retrieve2(lf[101],"required-extensions"),t4);}

/* k1740 in k1736 in k1434 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_1742(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1742,2,t0,t1);}
t2=C_mutate(&lf[101] /* (set! required-extensions ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1745,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_car(((C_word*)((C_word*)t0)[4])[1]);
/* csc.scm: 590  t-options */
f_1163(t3,(C_word)C_a_i_list(&a,2,lf[229],t4));}

/* k1743 in k1740 in k1736 in k1434 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_1745(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
f_1439(2,t4,t3);}

/* k1645 in k1434 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_1647(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1647,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1650,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[5],"msvc"))){
t3=t2;
f_1650(t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1665,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 573  cons* */
((C_proc5)C_retrieve_symbol_proc(lf[127]))(5,*((C_word*)lf[127]+1),t3,lf[212],lf[213],C_retrieve2(lf[84],"compile-options"));}}

/* k1663 in k1645 in k1434 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_1665(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[84] /* (set! compile-options ...) */,t1);
t3=((C_word*)t0)[2];
f_1650(t3,t2);}

/* k1648 in k1645 in k1434 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_fcall f_1650(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1650,NULL,2,t0,t1);}
t2=(C_truep(C_retrieve2(lf[5],"msvc"))?lf[210]:lf[211]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_retrieve2(lf[89],"link-options"));
t4=C_mutate(&lf[89] /* (set! link-options ...) */,t3);
t5=((C_word*)t0)[2];
f_1439(2,t5,t4);}

/* k1588 in k1434 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_1590(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 557  exit */
((C_proc3)C_retrieve_symbol_proc(lf[10]))(3,*((C_word*)lf[10]+1),((C_word*)t0)[2],C_fix(0));}

/* k1576 in k1434 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_1578(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 556  exit */
((C_proc3)C_retrieve_symbol_proc(lf[10]))(3,*((C_word*)lf[10]+1),((C_word*)t0)[2],C_fix(0));}

/* k1564 in k1434 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_1566(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 555  exit */
((C_proc3)C_retrieve_symbol_proc(lf[10]))(3,*((C_word*)lf[10]+1),((C_word*)t0)[2],C_fix(0));}

/* k1552 in k1434 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_1554(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 554  exit */
((C_proc3)C_retrieve_symbol_proc(lf[10]))(3,*((C_word*)lf[10]+1),((C_word*)t0)[2],C_fix(0));}

/* k1526 in k1434 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_1528(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(&lf[81] /* (set! translate-options ...) */,t1);
t3=lf[99] /* static-libs */ =C_SCHEME_TRUE;;
t4=((C_word*)t0)[2];
f_1439(2,t4,t3);}

/* k1515 in k1434 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_1517(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(&lf[81] /* (set! translate-options ...) */,t1);
t3=lf[98] /* static */ =C_SCHEME_TRUE;;
t4=((C_word*)t0)[2];
f_1439(2,t4,t3);}

/* k1484 in k1434 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_1486(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 535  system */
((C_proc3)C_retrieve_symbol_proc(lf[134]))(3,*((C_word*)lf[134]+1),((C_word*)t0)[2],t1);}

/* k1477 in k1434 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_1479(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 536  exit */
((C_proc2)C_retrieve_symbol_proc(lf[10]))(2,*((C_word*)lf[10]+1),((C_word*)t0)[2]);}

/* k1468 in k1434 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_1470(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 532  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[137]+1)))(3,*((C_word*)lf[137]+1),((C_word*)t0)[2],t1);}

/* k1461 in k1434 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_1463(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 533  exit */
((C_proc2)C_retrieve_symbol_proc(lf[10]))(2,*((C_word*)lf[10]+1),((C_word*)t0)[2]);}

/* k1449 in k1434 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_1451(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 530  exit */
((C_proc2)C_retrieve_symbol_proc(lf[10]))(2,*((C_word*)lf[10]+1),((C_word*)t0)[2]);}

/* k1437 in k1434 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_1439(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 739  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_1238(t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* k1247 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_1249(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1249,2,t0,t1);}
t2=C_mutate(&lf[84] /* (set! compile-options ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1253,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 481  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[107]+1)))(4,*((C_word*)lf[107]+1),t3,C_retrieve2(lf[89],"link-options"),C_retrieve2(lf[90],"builtin-link-options"));}

/* k1251 in k1247 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_1253(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1253,2,t0,t1);}
t2=C_mutate(&lf[89] /* (set! link-options ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1256,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[66],"inquiry-only"))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1394,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[67],"show-cflags"))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1427,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 484  compiler-options */
f_2830(t5);}
else{
t5=t4;
f_1394(2,t5,C_SCHEME_UNDEFINED);}}
else{
t4=t3;
f_1256(2,t4,C_SCHEME_UNDEFINED);}}

/* k1425 in k1251 in k1247 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_1427(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 484  print* */
((C_proc4)C_retrieve_proc(*((C_word*)lf[176]+1)))(4,*((C_word*)lf[176]+1),((C_word*)t0)[2],t1,C_make_character(32));}

/* k1392 in k1251 in k1247 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_1394(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1394,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1397,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[68],"show-ldflags"))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1420,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 485  linker-options */
f_3079(t3);}
else{
t3=t2;
f_1397(2,t3,C_SCHEME_UNDEFINED);}}

/* k1418 in k1392 in k1251 in k1247 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_1420(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 485  print* */
((C_proc4)C_retrieve_proc(*((C_word*)lf[176]+1)))(4,*((C_word*)lf[176]+1),((C_word*)t0)[2],t1,C_make_character(32));}

/* k1395 in k1392 in k1251 in k1247 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_1397(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1397,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1400,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[69],"show-libs"))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1413,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 486  linker-libraries */
f_3131(t3,(C_word)C_a_i_list(&a,1,C_SCHEME_TRUE));}
else{
t3=t2;
f_1400(2,t3,C_SCHEME_UNDEFINED);}}

/* k1411 in k1395 in k1392 in k1251 in k1247 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_1413(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 486  print* */
((C_proc4)C_retrieve_proc(*((C_word*)lf[176]+1)))(4,*((C_word*)lf[176]+1),((C_word*)t0)[2],t1,C_make_character(32));}

/* k1398 in k1395 in k1392 in k1251 in k1247 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_1400(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1400,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1403,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 487  newline */
((C_proc2)C_retrieve_proc(*((C_word*)lf[175]+1)))(2,*((C_word*)lf[175]+1),t2);}

/* k1401 in k1398 in k1395 in k1392 in k1251 in k1247 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_1403(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 488  exit */
((C_proc2)C_retrieve_symbol_proc(lf[10]))(2,*((C_word*)lf[10]+1),((C_word*)t0)[2]);}

/* k1254 in k1251 in k1247 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_1256(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1256,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1259,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(C_retrieve2(lf[58],"scheme-files")))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1319,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_nullp(C_retrieve2(lf[59],"c-files"));
t5=(C_truep(t4)?(C_word)C_i_nullp(C_retrieve2(lf[61],"object-files")):C_SCHEME_FALSE);
if(C_truep(t5)){
/* csc.scm: 495  quit */
f_944(t3,lf[167],C_SCHEME_END_OF_LIST);}
else{
t6=t3;
f_1319(2,t6,C_SCHEME_UNDEFINED);}}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1357,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_truep(C_retrieve2(lf[97],"shared"))?(C_word)C_i_not(C_retrieve2(lf[65],"embedded")):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=(C_word)C_a_i_cons(&a,2,lf[174],C_retrieve2(lf[81],"translate-options"));
t6=C_mutate(&lf[81] /* (set! translate-options ...) */,t5);
t7=t3;
f_1357(t7,t6);}
else{
t5=t3;
f_1357(t5,C_SCHEME_UNDEFINED);}}}

/* k1355 in k1254 in k1251 in k1247 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_fcall f_1357(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1357,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1360,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[91],"target-filename"))){
t3=t2;
f_1360(t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1367,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[97],"shared"))){
t4=(C_word)C_i_car(C_retrieve2(lf[58],"scheme-files"));
/* csc.scm: 508  pathname-replace-extension */
((C_proc4)C_retrieve_symbol_proc(lf[165]))(4,*((C_word*)lf[165]+1),t3,t4,C_retrieve2(lf[45],"shared-library-extension"));}
else{
t4=(C_word)C_i_car(C_retrieve2(lf[58],"scheme-files"));
/* csc.scm: 509  pathname-replace-extension */
((C_proc4)C_retrieve_symbol_proc(lf[165]))(4,*((C_word*)lf[165]+1),t3,t4,C_retrieve2(lf[41],"executable-extension"));}}}

/* k1365 in k1355 in k1254 in k1251 in k1247 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_1367(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[91] /* (set! target-filename ...) */,t1);
t3=((C_word*)t0)[2];
f_1360(t3,t2);}

/* k1358 in k1355 in k1254 in k1251 in k1247 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_fcall f_1360(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1360,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2655,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2663,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[150]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_retrieve2(lf[58],"scheme-files"));}

/* a2662 in k1358 in k1355 in k1254 in k1251 in k1247 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_2663(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2663,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2667,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_length(C_retrieve2(lf[58],"scheme-files"));
t5=(C_word)C_i_nequalp(C_fix(1),t4);
t6=(C_truep(t5)?C_retrieve2(lf[91],"target-filename"):t2);
t7=(C_truep(C_retrieve2(lf[63],"cpp-mode"))?lf[171]:(C_truep(C_retrieve2(lf[64],"objc-mode"))?lf[172]:lf[173]));
/* csc.scm: 747  pathname-replace-extension */
((C_proc4)C_retrieve_symbol_proc(lf[165]))(4,*((C_word*)lf[165]+1),t3,t6,t7);}

/* k2665 in a2662 in k1358 in k1355 in k1254 in k1251 in k1247 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_2667(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2667,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2670,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2696,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2700,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2704,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2708,a[2]=t1,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 757  cleanup-filename */
((C_proc3)C_retrieve2_symbol_proc(lf[53],"cleanup-filename"))(3,lf[53],t6,((C_word*)t0)[2]);}

/* k2706 in k2665 in a2662 in k1358 in k1355 in k1254 in k1251 in k1247 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_2708(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2708,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2712,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2716,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[96],"to-stdout"))){
t4=t3;
f_2716(t4,lf[169]);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2735,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 761  cleanup-filename */
((C_proc3)C_retrieve2_symbol_proc(lf[53],"cleanup-filename"))(3,lf[53],t4,((C_word*)t0)[2]);}}

/* k2733 in k2706 in k2665 in a2662 in k1358 in k1355 in k1254 in k1251 in k1247 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_2735(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2735,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[2];
f_2716(t3,(C_word)C_a_i_cons(&a,2,lf[170],t2));}

/* k2714 in k2706 in k2665 in a2662 in k1358 in k1355 in k1254 in k1251 in k1247 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_fcall f_2716(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2716,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2720,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2724,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 762  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[107]+1)))(4,*((C_word*)lf[107]+1),t3,C_retrieve2(lf[81],"translate-options"),C_SCHEME_END_OF_LIST);}

/* k2722 in k2714 in k2706 in k2665 in a2662 in k1358 in k1355 in k1254 in k1251 in k1247 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_2724(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[105]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve2(lf[106],"quote-option"),t1);}

/* k2718 in k2714 in k2706 in k2665 in a2662 in k1358 in k1355 in k1254 in k1251 in k1247 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_2720(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 758  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[107]+1)))(4,*((C_word*)lf[107]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2710 in k2706 in k2665 in a2662 in k1358 in k1355 in k1254 in k1251 in k1247 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_2712(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 757  cons* */
((C_proc5)C_retrieve_symbol_proc(lf[127]))(5,*((C_word*)lf[127]+1),((C_word*)t0)[3],C_retrieve2(lf[25],"translator"),((C_word*)t0)[2],t1);}

/* k2702 in k2665 in a2662 in k1358 in k1355 in k1254 in k1251 in k1247 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_2704(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 756  string-intersperse */
((C_proc4)C_retrieve_symbol_proc(lf[104]))(4,*((C_word*)lf[104]+1),((C_word*)t0)[2],t1,lf[168]);}

/* k2698 in k2665 in a2662 in k1358 in k1355 in k1254 in k1251 in k1247 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_2700(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 755  $system */
f_3305(((C_word*)t0)[2],t1);}

/* k2694 in k2665 in a2662 in k1358 in k1355 in k1254 in k1251 in k1247 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_2696(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_zerop(t1))){
t2=((C_word*)t0)[2];
f_2670(2,t2,C_SCHEME_UNDEFINED);}
else{
/* csc.scm: 764  exit */
((C_proc3)C_retrieve_symbol_proc(lf[10]))(3,*((C_word*)lf[10]+1),((C_word*)t0)[2],C_retrieve2(lf[130],"last-exit-code"));}}

/* k2668 in k2665 in a2662 in k1358 in k1355 in k1254 in k1251 in k1247 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_2670(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2670,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2674,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
/* csc.scm: 765  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[107]+1)))(4,*((C_word*)lf[107]+1),t2,t3,C_retrieve2(lf[59],"c-files"));}

/* k2672 in k2668 in k2665 in a2662 in k1358 in k1355 in k1254 in k1251 in k1247 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_2674(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2674,2,t0,t1);}
t2=C_mutate(&lf[59] /* (set! c-files ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2678,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
/* csc.scm: 766  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[107]+1)))(4,*((C_word*)lf[107]+1),t3,t4,C_retrieve2(lf[60],"generated-c-files"));}

/* k2676 in k2672 in k2668 in k2665 in a2662 in k1358 in k1355 in k1254 in k1251 in k1247 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_2678(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[60] /* (set! generated-c-files ...) */,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2653 in k1358 in k1355 in k1254 in k1251 in k1247 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_2655(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(C_retrieve2(lf[93],"keep-files"))){
t2=((C_word*)t0)[2];
f_1259(2,t2,C_SCHEME_UNDEFINED);}
else{
/* for-each */
t2=*((C_word*)lf[150]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve2(lf[138],"$delete-file"),C_SCHEME_END_OF_LIST);}}

/* k1317 in k1254 in k1251 in k1247 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_1319(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1319,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1322,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_nullp(C_retrieve2(lf[59],"c-files"));
t4=(C_truep(t3)?C_retrieve2(lf[61],"object-files"):C_retrieve2(lf[59],"c-files"));
/* csc.scm: 496  last */
((C_proc3)C_retrieve_symbol_proc(lf[166]))(3,*((C_word*)lf[166]+1),t2,t4);}

/* k1320 in k1317 in k1254 in k1251 in k1247 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_1322(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1322,2,t0,t1);}
if(C_truep(C_retrieve2(lf[91],"target-filename"))){
t2=((C_word*)t0)[2];
f_1259(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1329,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[97],"shared"))){
/* csc.scm: 500  pathname-replace-extension */
((C_proc4)C_retrieve_symbol_proc(lf[165]))(4,*((C_word*)lf[165]+1),t2,t1,C_retrieve2(lf[45],"shared-library-extension"));}
else{
/* csc.scm: 501  pathname-replace-extension */
((C_proc4)C_retrieve_symbol_proc(lf[165]))(4,*((C_word*)lf[165]+1),t2,t1,C_retrieve2(lf[41],"executable-extension"));}}}

/* k1327 in k1320 in k1317 in k1254 in k1251 in k1247 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_1329(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[91] /* (set! target-filename ...) */,t1);
t3=((C_word*)t0)[2];
f_1259(2,t3,t2);}

/* k1257 in k1254 in k1251 in k1247 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_1259(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1259,2,t0,t1);}
if(C_truep(C_retrieve2(lf[94],"translate-only"))){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1265,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2759,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2775,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* for-each */
t7=*((C_word*)lf[150]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,C_retrieve2(lf[59],"c-files"));}}

/* a2774 in k1257 in k1254 in k1251 in k1247 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_2775(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2775,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2779,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* csc.scm: 777  pathname-replace-extension */
((C_proc4)C_retrieve_symbol_proc(lf[165]))(4,*((C_word*)lf[165]+1),t3,t2,C_retrieve2(lf[32],"object-extension"));}

/* k2777 in a2774 in k1257 in k1254 in k1251 in k1247 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_2779(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2779,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2782,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2800,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2804,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(C_truep(C_retrieve2(lf[63],"cpp-mode"))?C_retrieve2(lf[27],"c++-compiler"):C_retrieve2(lf[26],"compiler"));
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2816,a[2]=t1,a[3]=t4,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* csc.scm: 783  cleanup-filename */
((C_proc3)C_retrieve2_symbol_proc(lf[53],"cleanup-filename"))(3,lf[53],t6,((C_word*)t0)[2]);}

/* k2814 in k2777 in a2774 in k1257 in k1254 in k1251 in k1247 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_2816(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2816,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2820,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2828,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 784  cleanup-filename */
((C_proc3)C_retrieve2_symbol_proc(lf[53],"cleanup-filename"))(3,lf[53],t3,((C_word*)t0)[2]);}

/* k2826 in k2814 in k2777 in a2774 in k1257 in k1254 in k1251 in k1247 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_2828(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 784  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[117]+1)))(4,*((C_word*)lf[117]+1),((C_word*)t0)[2],C_retrieve2(lf[44],"compile-output-flag"),t1);}

/* k2818 in k2814 in k2777 in a2774 in k1257 in k1254 in k1251 in k1247 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_2820(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2820,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2824,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* csc.scm: 786  compiler-options */
f_2830(t2);}

/* k2822 in k2818 in k2814 in k2777 in a2774 in k1257 in k1254 in k1251 in k1247 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_2824(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2824,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,5,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],lf[164],t1);
/* csc.scm: 780  string-intersperse */
((C_proc3)C_retrieve_symbol_proc(lf[104]))(3,*((C_word*)lf[104]+1),((C_word*)t0)[2],t2);}

/* k2802 in k2777 in a2774 in k1257 in k1254 in k1251 in k1247 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_2804(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 779  $system */
f_3305(((C_word*)t0)[2],t1);}

/* k2798 in k2777 in a2774 in k1257 in k1254 in k1251 in k1247 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_2800(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_zerop(t1))){
t2=((C_word*)t0)[2];
f_2782(2,t2,C_SCHEME_UNDEFINED);}
else{
/* csc.scm: 787  exit */
((C_proc3)C_retrieve_symbol_proc(lf[10]))(3,*((C_word*)lf[10]+1),((C_word*)t0)[2],C_retrieve2(lf[130],"last-exit-code"));}}

/* k2780 in k2777 in a2774 in k1257 in k1254 in k1251 in k1247 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_2782(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2782,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_retrieve2(lf[62],"generated-object-files"));
t3=C_mutate(&lf[62] /* (set! generated-object-files ...) */,t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[3])+1,t4);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}

/* k2757 in k1257 in k1254 in k1251 in k1247 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_2759(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2759,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2763,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2773,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 791  reverse */
((C_proc3)C_retrieve_proc(*((C_word*)lf[109]+1)))(3,*((C_word*)lf[109]+1),t3,((C_word*)((C_word*)t0)[2])[1]);}

/* k2771 in k2757 in k1257 in k1254 in k1251 in k1247 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_2773(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 791  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[107]+1)))(4,*((C_word*)lf[107]+1),((C_word*)t0)[2],t1,C_retrieve2(lf[61],"object-files"));}

/* k2761 in k2757 in k1257 in k1254 in k1251 in k1247 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_2763(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[61] /* (set! object-files ...) */,t1);
if(C_truep(C_retrieve2(lf[93],"keep-files"))){
t3=((C_word*)t0)[2];
f_1265(2,t3,C_SCHEME_UNDEFINED);}
else{
/* for-each */
t3=*((C_word*)lf[150]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],C_retrieve2(lf[138],"$delete-file"),C_retrieve2(lf[60],"generated-c-files"));}}

/* k1263 in k1257 in k1254 in k1251 in k1247 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_1265(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1265,2,t0,t1);}
if(C_truep(C_retrieve2(lf[95],"compile-only"))){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1271,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_member(C_retrieve2(lf[91],"target-filename"),C_retrieve2(lf[58],"scheme-files")))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1280,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 515  printf */
((C_proc5)C_retrieve_symbol_proc(lf[132]))(5,*((C_word*)lf[132]+1),t3,lf[163],C_retrieve2(lf[91],"target-filename"),C_retrieve2(lf[91],"target-filename"));}
else{
t3=t2;
f_1271(2,t3,C_SCHEME_UNDEFINED);}}}

/* k1278 in k1263 in k1257 in k1254 in k1251 in k1247 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_1280(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1280,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1293,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1297,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_truep(C_retrieve(lf[157]))?lf[158]:lf[159]);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1305,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 519  quotewrap */
t6=C_retrieve2(lf[21],"quotewrap");
f_986(3,t6,t5,C_retrieve2(lf[91],"target-filename"));}

/* k1303 in k1278 in k1263 in k1257 in k1254 in k1251 in k1247 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_1305(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1305,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1309,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1313,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 520  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[117]+1)))(4,*((C_word*)lf[117]+1),t3,C_retrieve2(lf[91],"target-filename"),lf[162]);}

/* k1311 in k1303 in k1278 in k1263 in k1257 in k1254 in k1251 in k1247 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_1313(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 520  quotewrap */
t2=C_retrieve2(lf[21],"quotewrap");
f_986(3,t2,((C_word*)t0)[2],t1);}

/* k1307 in k1303 in k1278 in k1263 in k1257 in k1254 in k1251 in k1247 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_1309(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 517  sprintf */
((C_proc6)C_retrieve_symbol_proc(lf[160]))(6,*((C_word*)lf[160]+1),((C_word*)t0)[4],lf[161],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1295 in k1278 in k1263 in k1257 in k1254 in k1251 in k1247 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_1297(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 517  $system */
f_3305(((C_word*)t0)[2],t1);}

/* k1291 in k1278 in k1263 in k1257 in k1254 in k1251 in k1247 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_1293(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_zerop(t1))){
t2=((C_word*)t0)[2];
f_1271(2,t2,C_SCHEME_UNDEFINED);}
else{
/* csc.scm: 521  exit */
((C_proc3)C_retrieve_symbol_proc(lf[10]))(3,*((C_word*)lf[10]+1),((C_word*)t0)[2],C_retrieve2(lf[130],"last-exit-code"));}}

/* k1269 in k1263 in k1257 in k1254 in k1251 in k1247 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_1271(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1271,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2855,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2964,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2968,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2970,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2976,tmp=(C_word)a,a+=2,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t5,t6,t7);}

/* a2975 in k1269 in k1263 in k1257 in k1254 in k1251 in k1247 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_2976(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2rv,(void*)f_2976r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_2976r(t0,t1,t2);}}

static void C_ccall f_2976r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_vector_ref(t2,C_fix(0)));}

/* a2969 in k1269 in k1263 in k1257 in k1254 in k1251 in k1247 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_2970(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2970,2,t0,t1);}
/* csc.scm: 808  static-extension-info */
f_2982(t1);}

/* k2966 in k1269 in k1263 in k1257 in k1254 in k1251 in k1247 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_2968(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 807  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[107]+1)))(4,*((C_word*)lf[107]+1),((C_word*)t0)[2],C_retrieve2(lf[61],"object-files"),t1);}

/* k2962 in k1269 in k1263 in k1257 in k1254 in k1251 in k1247 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_2964(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[105]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve2(lf[53],"cleanup-filename"),t1);}

/* k2853 in k1269 in k1263 in k1257 in k1254 in k1251 in k1247 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_2855(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2855,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2858,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 809  cleanup-filename */
((C_proc3)C_retrieve2_symbol_proc(lf[53],"cleanup-filename"))(3,lf[53],t2,C_retrieve2(lf[91],"target-filename"));}

/* k2856 in k2853 in k1269 in k1263 in k1257 in k1254 in k1251 in k1247 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_2858(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[21],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2858,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2861,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2928,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2932,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2936,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(C_truep(C_retrieve2(lf[63],"cpp-mode"))?C_retrieve2(lf[29],"c++-linker"):C_retrieve2(lf[28],"linker"));
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2944,a[2]=t6,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2952,a[2]=((C_word*)t0)[2],a[3]=t7,tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 817  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[117]+1)))(4,*((C_word*)lf[117]+1),t8,C_retrieve2(lf[38],"link-output-flag"),t1);}

/* k2950 in k2856 in k2853 in k1269 in k1263 in k1257 in k1254 in k1251 in k1247 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_2952(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2952,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2956,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* csc.scm: 818  linker-options */
f_3079(t2);}

/* k2954 in k2950 in k2856 in k2853 in k1269 in k1263 in k1257 in k1254 in k1251 in k1247 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_2956(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2956,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2960,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* csc.scm: 819  linker-libraries */
f_3131(t2,(C_word)C_a_i_list(&a,1,C_SCHEME_FALSE));}

/* k2958 in k2954 in k2950 in k2856 in k2853 in k1269 in k1263 in k1257 in k1254 in k1251 in k1247 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_2960(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2960,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,((C_word*)t0)[5],((C_word*)t0)[4],t1);
/* csc.scm: 815  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[107]+1)))(4,*((C_word*)lf[107]+1),((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k2942 in k2856 in k2853 in k1269 in k1263 in k1257 in k1254 in k1251 in k1247 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_2944(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 813  cons* */
((C_proc4)C_retrieve_symbol_proc(lf[127]))(4,*((C_word*)lf[127]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2934 in k2856 in k2853 in k1269 in k1263 in k1257 in k1254 in k1251 in k1247 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_2936(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 812  string-intersperse */
((C_proc3)C_retrieve_symbol_proc(lf[104]))(3,*((C_word*)lf[104]+1),((C_word*)t0)[2],t1);}

/* k2930 in k2856 in k2853 in k1269 in k1263 in k1257 in k1254 in k1251 in k1247 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_2932(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 811  $system */
f_3305(((C_word*)t0)[2],t1);}

/* k2926 in k2856 in k2853 in k1269 in k1263 in k1257 in k1254 in k1251 in k1247 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_2928(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_zerop(t1))){
t2=((C_word*)t0)[2];
f_2861(2,t2,C_SCHEME_UNDEFINED);}
else{
/* csc.scm: 820  exit */
((C_proc3)C_retrieve_symbol_proc(lf[10]))(3,*((C_word*)lf[10]+1),((C_word*)t0)[2],C_retrieve2(lf[130],"last-exit-code"));}}

/* k2859 in k2856 in k2853 in k1269 in k1263 in k1257 in k1254 in k1251 in k1247 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_2861(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2861,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2864,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2873,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[7],"osx"))){
t4=(C_word)C_i_not(C_retrieve2(lf[18],"cross-chicken"));
t5=t3;
f_2873(t5,(C_truep(t4)?t4:C_retrieve2(lf[17],"host-mode")));}
else{
t4=t3;
f_2873(t4,C_SCHEME_FALSE);}}

/* k2871 in k2859 in k2856 in k2853 in k1269 in k1263 in k1257 in k1254 in k1251 in k1247 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_fcall f_2873(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[22],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2873,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2886,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2890,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2894,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2898,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2902,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2906,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[17],"host-mode"))){
/* ##sys#peek-c-string */
t8=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,C_mpointer(&a,(void*)C_INSTALL_LIB_HOME),C_fix(0));}
else{
/* ##sys#peek-c-string */
t8=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,C_mpointer(&a,(void*)C_TARGET_RUN_LIB_HOME),C_fix(0));}}
else{
t2=((C_word*)t0)[3];
f_2864(2,t2,C_SCHEME_UNDEFINED);}}

/* k2904 in k2871 in k2859 in k2856 in k2853 in k1269 in k1263 in k1257 in k1254 in k1251 in k1247 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_2906(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 827  prefix */
f_973(((C_word*)t0)[2],lf[154],lf[155],t1);}

/* k2900 in k2871 in k2859 in k2856 in k2853 in k1269 in k1263 in k1257 in k1254 in k1251 in k1247 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_2902(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 826  make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[20]))(4,*((C_word*)lf[20]+1),((C_word*)t0)[2],t1,lf[153]);}

/* k2896 in k2871 in k2859 in k2856 in k2853 in k1269 in k1263 in k1257 in k1254 in k1251 in k1247 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_2898(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 825  quotewrap */
t2=C_retrieve2(lf[21],"quotewrap");
f_986(3,t2,((C_word*)t0)[2],t1);}

/* k2892 in k2871 in k2859 in k2856 in k2853 in k1269 in k1263 in k1257 in k1254 in k1251 in k1247 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_2894(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 823  string-append */
((C_proc6)C_retrieve_proc(*((C_word*)lf[117]+1)))(6,*((C_word*)lf[117]+1),((C_word*)t0)[3],lf[151],t1,lf[152],((C_word*)t0)[2]);}

/* k2888 in k2871 in k2859 in k2856 in k2853 in k1269 in k1263 in k1257 in k1254 in k1251 in k1247 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_2890(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 822  $system */
f_3305(((C_word*)t0)[2],t1);}

/* k2884 in k2871 in k2859 in k2856 in k2853 in k1269 in k1263 in k1257 in k1254 in k1251 in k1247 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_2886(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_zerop(t1))){
t2=((C_word*)t0)[2];
f_2864(2,t2,C_SCHEME_UNDEFINED);}
else{
/* csc.scm: 834  exit */
((C_proc3)C_retrieve_symbol_proc(lf[10]))(3,*((C_word*)lf[10]+1),((C_word*)t0)[2],C_retrieve2(lf[130],"last-exit-code"));}}

/* k2862 in k2859 in k2856 in k2853 in k1269 in k1263 in k1257 in k1254 in k1251 in k1247 in loop in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_2864(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(C_retrieve2(lf[93],"keep-files"))){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
/* for-each */
t2=*((C_word*)lf[150]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve2(lf[138],"$delete-file"),C_retrieve2(lf[62],"generated-object-files"));}}

/* shared-build in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_fcall f_1209(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1209,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1214,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 468  cons* */
((C_proc5)C_retrieve_symbol_proc(lf[127]))(5,*((C_word*)lf[127]+1),t3,lf[148],lf[149],C_retrieve2(lf[81],"translate-options"));}

/* k1212 in shared-build in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_1214(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1214,2,t0,t1);}
t2=C_mutate(&lf[81] /* (set! translate-options ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1218,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 469  append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[107]+1)))(5,*((C_word*)lf[107]+1),t3,C_retrieve2(lf[49],"pic-options"),lf[147],C_retrieve2(lf[84],"compile-options"));}

/* k1216 in k1212 in shared-build in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_1218(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1218,2,t0,t1);}
t2=C_mutate(&lf[84] /* (set! compile-options ...) */,t1);
t3=(C_truep(C_retrieve2(lf[7],"osx"))?(C_truep(((C_word*)t0)[3])?lf[143]:lf[144]):(C_truep(C_retrieve2(lf[5],"msvc"))?lf[145]:lf[146]));
t4=(C_word)C_a_i_cons(&a,2,t3,C_retrieve2(lf[89],"link-options"));
t5=C_mutate(&lf[89] /* (set! link-options ...) */,t4);
t6=lf[97] /* shared */ =C_SCHEME_TRUE;;
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}

/* check in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_fcall f_1170(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1170,NULL,4,t1,t2,t3,t4);}
t5=(C_word)C_i_length(t3);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1188,a[2]=t2,a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t7=t6;
f_1188(2,t7,C_fix(1));}
else{
t7=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t7))){
t8=t6;
f_1188(2,t8,(C_word)C_i_car(t4));}
else{
/* ##sys#error */
t8=*((C_word*)lf[119]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,lf[0],t4);}}}

/* k1186 in check in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_1188(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1188,2,t0,t1);}
if(C_truep((C_word)C_i_greater_or_equalp(((C_word*)t0)[4],t1))){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
/* csc.scm: 465  quit */
f_944(((C_word*)t0)[3],lf[142],(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]));}}

/* t-options in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_fcall f_1163(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1163,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1168,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 461  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[107]+1)))(4,*((C_word*)lf[107]+1),t3,C_retrieve2(lf[81],"translate-options"),t2);}

/* k1166 in t-options in k3360 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_1168(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[81] /* (set! translate-options ...) */,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k3350 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_3352(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3352,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3355,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3358,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#implicit-exit-handler */
((C_proc2)C_retrieve_symbol_proc(lf[141]))(2,*((C_word*)lf[141]+1),t3);}

/* k3356 in k3350 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_3358(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k3353 in k3350 in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_3355(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* $delete-file in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_3336(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3336,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3340,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[92],"verbose"))){
/* csc.scm: 915  print */
((C_proc4)C_retrieve_proc(*((C_word*)lf[137]+1)))(4,*((C_word*)lf[137]+1),t3,lf[140],t2);}
else{
t4=t3;
f_3340(2,t4,C_SCHEME_UNDEFINED);}}

/* k3338 in $delete-file in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_3340(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(C_retrieve2(lf[70],"dry-run"))){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
/* csc.scm: 916  delete-file */
((C_proc3)C_retrieve_symbol_proc(lf[139]))(3,*((C_word*)lf[139]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* $system in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_fcall f_3305(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3305,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3309,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[92],"verbose"))){
/* csc.scm: 901  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[137]+1)))(3,*((C_word*)lf[137]+1),t3,t2);}
else{
t4=t3;
f_3309(2,t4,C_SCHEME_UNDEFINED);}}

/* k3307 in $system in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_3309(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3309,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3312,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[50],"windows-shell"))){
/* csc.scm: 903  string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[117]+1)))(5,*((C_word*)lf[117]+1),t2,lf[135],((C_word*)t0)[2],lf[136]);}
else{
t3=t2;
f_3312(2,t3,((C_word*)t0)[2]);}}

/* k3310 in k3307 in $system in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_3312(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3312,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3316,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[70],"dry-run"))){
t3=t2;
f_3316(2,t3,C_fix(0));}
else{
/* csc.scm: 908  system */
((C_proc3)C_retrieve_symbol_proc(lf[134]))(3,*((C_word*)lf[134]+1),t2,t1);}}

/* k3314 in k3310 in k3307 in $system in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_3316(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3316,2,t0,t1);}
t2=C_mutate(&lf[130] /* (set! last-exit-code ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3319,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_zerop(C_retrieve2(lf[130],"last-exit-code")))){
t4=t3;
f_3319(2,t4,C_SCHEME_UNDEFINED);}
else{
/* csc.scm: 910  printf */
((C_proc5)C_retrieve_symbol_proc(lf[132]))(5,*((C_word*)lf[132]+1),t3,lf[133],C_retrieve2(lf[130],"last-exit-code"),((C_word*)t0)[2]);}}

/* k3317 in k3314 in k3310 in k3307 in $system in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_3319(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_retrieve2(lf[130],"last-exit-code"));}

/* quote-option in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_3280(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3280,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3287,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3292,tmp=(C_word)a,a+=2,tmp);
/* csc.scm: 892  string-any */
((C_proc4)C_retrieve_symbol_proc(lf[129]))(4,*((C_word*)lf[129]+1),t3,t4,t2);}

/* a3291 in quote-option in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_3292(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3292,3,t0,t1,t2);}
t3=(C_word)C_u_i_char_whitespacep(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?t3:(C_word)C_i_memq(t2,lf[120])));}

/* k3285 in quote-option in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_3287(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3287,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[2];
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3213,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3227,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3231,a[2]=t7,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* string->list */
t9=C_retrieve(lf[128]);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t3);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* k3229 in k3285 in quote-option in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_3231(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3231,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3233,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_3233(t5,((C_word*)t0)[2],t1);}

/* fold in k3229 in k3285 in quote-option in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_fcall f_3233(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(6);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3233,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_memq(t3,lf[120]))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3256,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_cdr(t2);
/* csc.scm: 883  fold */
t9=t4;
t10=t5;
t1=t9;
t2=t10;
goto loop;}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3263,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_u_i_char_whitespacep(t3))){
t5=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_TRUE);
t6=t4;
f_3263(t6,t5);}
else{
t5=t4;
f_3263(t5,C_SCHEME_UNDEFINED);}}}}

/* k3261 in fold in k3229 in k3285 in quote-option in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_fcall f_3263(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3263,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3270,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* csc.scm: 886  fold */
t4=((C_word*)((C_word*)t0)[2])[1];
f_3233(t4,t2,t3);}

/* k3268 in k3261 in fold in k3229 in k3285 in quote-option in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_3270(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3270,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k3254 in fold in k3229 in k3285 in quote-option in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_3256(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 883  cons* */
((C_proc5)C_retrieve_symbol_proc(lf[127]))(5,*((C_word*)lf[127]+1),((C_word*)t0)[3],C_make_character(92),((C_word*)t0)[2],t1);}

/* k3225 in k3285 in quote-option in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_3227(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* list->string */
t2=C_retrieve(lf[126]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3211 in k3285 in quote-option in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_3213(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3213,2,t0,t1);}
if(C_truep(((C_word*)((C_word*)t0)[3])[1])){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3223,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 888  string-translate* */
((C_proc4)C_retrieve_symbol_proc(lf[124]))(4,*((C_word*)lf[124]+1),t2,t1,lf[125]);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}}

/* k3221 in k3211 in k3285 in quote-option in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_3223(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 888  string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[117]+1)))(5,*((C_word*)lf[117]+1),((C_word*)t0)[2],lf[122],t1,lf[123]);}

/* linker-libraries in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_fcall f_3131(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3131,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3135,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
t4=t3;
f_3135(2,t4,C_SCHEME_FALSE);}
else{
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t4))){
t5=t3;
f_3135(2,t5,(C_word)C_i_car(t2));}
else{
/* ##sys#error */
t5=*((C_word*)lf[119]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,lf[0],t2);}}}

/* k3133 in linker-libraries in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_3135(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3135,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3142,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3146,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3177,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3183,tmp=(C_word)a,a+=2,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t3,t4,t5);}
else{
t4=t3;
f_3146(2,t4,C_SCHEME_END_OF_LIST);}}

/* a3182 in k3133 in linker-libraries in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_3183(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2rv,(void*)f_3183r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_3183r(t0,t1,t2);}}

static void C_ccall f_3183r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_vector_ref(t2,C_fix(0)));}

/* a3176 in k3133 in linker-libraries in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_3177(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3177,2,t0,t1);}
/* csc.scm: 863  static-extension-info */
f_2982(t1);}

/* k3144 in k3133 in linker-libraries in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_3146(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3146,2,t0,t1);}
t2=C_retrieve2(lf[98],"static");
t3=(C_truep(t2)?t2:C_retrieve2(lf[99],"static-libs"));
t4=(C_truep(t3)?(C_truep(C_retrieve2(lf[102],"gui"))?C_retrieve2(lf[77],"gui-library-files"):C_retrieve2(lf[79],"library-files")):(C_truep(C_retrieve2(lf[102],"gui"))?C_retrieve2(lf[78],"gui-shared-library-files"):C_retrieve2(lf[80],"shared-library-files")));
t5=C_retrieve2(lf[98],"static");
t6=(C_truep(t5)?t5:C_retrieve2(lf[99],"static-libs"));
t7=(C_truep(t6)?(C_word)C_a_i_list(&a,1,C_retrieve2(lf[71],"extra-libraries")):(C_word)C_a_i_list(&a,1,C_retrieve2(lf[72],"extra-shared-libraries")));
/* csc.scm: 862  append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[107]+1)))(5,*((C_word*)lf[107]+1),((C_word*)t0)[2],t1,t4,t7);}

/* k3140 in k3133 in linker-libraries in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_3142(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 861  string-intersperse */
((C_proc3)C_retrieve_symbol_proc(lf[104]))(3,*((C_word*)lf[104]+1),((C_word*)t0)[2],t1);}

/* linker-options in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_fcall f_3079(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3079,NULL,1,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3087,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3113,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3117,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3119,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3125,tmp=(C_word)a,a+=2,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t4,t5,t6);}

/* a3124 in linker-options in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_3125(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2rv,(void*)f_3125r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_3125r(t0,t1,t2);}}

static void C_ccall f_3125r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_vector_ref(t2,C_fix(1)));}

/* a3118 in linker-options in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_3119(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3119,2,t0,t1);}
/* csc.scm: 857  static-extension-info */
f_2982(t1);}

/* k3115 in linker-options in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_3117(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 856  append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[107]+1)))(5,*((C_word*)lf[107]+1),((C_word*)t0)[2],C_retrieve2(lf[87],"linking-optimization-options"),C_retrieve2(lf[89],"link-options"),t1);}

/* k3111 in linker-options in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_3113(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 855  string-intersperse */
((C_proc3)C_retrieve_symbol_proc(lf[104]))(3,*((C_word*)lf[104]+1),((C_word*)t0)[2],t1);}

/* k3085 in linker-options in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_3087(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_truep(C_retrieve2(lf[98],"static"))?(C_truep(C_retrieve2(lf[3],"mingw"))?C_SCHEME_FALSE:(C_truep(C_retrieve2(lf[5],"msvc"))?C_SCHEME_FALSE:(C_word)C_i_not(C_retrieve2(lf[7],"osx")))):C_SCHEME_FALSE);
t3=(C_truep(t2)?lf[115]:lf[116]);
/* csc.scm: 854  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[117]+1)))(4,*((C_word*)lf[117]+1),((C_word*)t0)[2],t1,t3);}

/* static-extension-info in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_fcall f_2982(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2982,NULL,1,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2986,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 838  repository-path */
((C_proc2)C_retrieve_symbol_proc(lf[113]))(2,*((C_word*)lf[113]+1),t2);}

/* k2984 in static-extension-info in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_2986(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2986,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_i_pairp(C_retrieve2(lf[100],"static-extensions")):C_SCHEME_FALSE);
if(C_truep(t2)){
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2997,a[2]=t1,a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_2997(t6,((C_word*)t0)[2],C_retrieve2(lf[100],"static-extensions"),C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}
else{
/* csc.scm: 851  values */
C_values(4,0,((C_word*)t0)[2],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}}

/* loop in k2984 in static-extension-info in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_fcall f_2997(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2997,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3011,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 842  reverse */
((C_proc3)C_retrieve_proc(*((C_word*)lf[109]+1)))(3,*((C_word*)lf[109]+1),t5,t3);}
else{
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3018,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t4,a[5]=t1,a[6]=((C_word*)t0)[3],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t6=(C_word)C_i_car(t2);
/* csc.scm: 843  extension-information */
((C_proc3)C_retrieve_symbol_proc(lf[112]))(3,*((C_word*)lf[112]+1),t5,t6);}}

/* k3016 in loop in k2984 in static-extension-info in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_3018(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3018,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_assq(lf[110],t1);
t3=(C_word)C_i_assq(lf[111],t1);
t4=(C_word)C_i_cdr(((C_word*)t0)[7]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3038,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=t4,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t2)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3056,a[2]=((C_word*)t0)[3],a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_i_cadr(t2);
/* csc.scm: 848  make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[20]))(4,*((C_word*)lf[20]+1),t6,((C_word*)t0)[2],t7);}
else{
t6=t5;
f_3038(t6,((C_word*)t0)[3]);}}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
/* csc.scm: 850  loop */
t3=((C_word*)((C_word*)t0)[6])[1];
f_2997(t3,((C_word*)t0)[5],t2,((C_word*)t0)[3],((C_word*)t0)[4]);}}

/* k3054 in k3016 in loop in k2984 in static-extension-info in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_3056(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3056,2,t0,t1);}
t2=((C_word*)t0)[3];
f_3038(t2,(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[2]));}

/* k3036 in k3016 in loop in k2984 in static-extension-info in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_fcall f_3038(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3038,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3042,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=(C_word)C_i_cadr(((C_word*)t0)[3]);
t4=t2;
f_3042(t4,(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[2]));}
else{
t3=t2;
f_3042(t3,((C_word*)t0)[2]);}}

/* k3040 in k3036 in k3016 in loop in k2984 in static-extension-info in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_fcall f_3042(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 847  loop */
t2=((C_word*)((C_word*)t0)[5])[1];
f_2997(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3009 in loop in k2984 in static-extension-info in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_3011(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3011,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3015,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 842  reverse */
((C_proc3)C_retrieve_proc(*((C_word*)lf[109]+1)))(3,*((C_word*)lf[109]+1),t2,((C_word*)t0)[2]);}

/* k3013 in k3009 in loop in k2984 in static-extension-info in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_3015(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 842  values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* compiler-options in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_fcall f_2830(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2830,NULL,1,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2838,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2842,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=C_retrieve2(lf[98],"static");
t5=(C_truep(t4)?t4:C_retrieve2(lf[99],"static-libs"));
t6=(C_truep(t5)?C_SCHEME_END_OF_LIST:C_SCHEME_END_OF_LIST);
/* csc.scm: 797  append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[107]+1)))(5,*((C_word*)lf[107]+1),t3,t6,C_retrieve2(lf[86],"compilation-optimization-options"),C_retrieve2(lf[84],"compile-options"));}

/* k2840 in compiler-options in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_2842(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[105]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve2(lf[106],"quote-option"),t1);}

/* k2836 in compiler-options in k1138 in k1133 in k1125 in k1117 in k1108 in k3484 in k1100 in k3517 in k1092 in k1088 in k1062 in k1057 in k1052 in k1048 in k1016 in k1012 in k1008 in k1004 in k1000 in k996 in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_2838(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 795  string-intersperse */
((C_proc3)C_retrieve_symbol_proc(lf[104]))(3,*((C_word*)lf[104]+1),((C_word*)t0)[2],t1);}

/* quotewrap in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_986(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_986,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_994,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 82   normalize-pathname */
((C_proc3)C_retrieve_symbol_proc(lf[23]))(3,*((C_word*)lf[23]+1),t3,t2);}

/* k992 in quotewrap in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_994(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 82   qs */
((C_proc3)C_retrieve_symbol_proc(lf[22]))(3,*((C_word*)lf[22]+1),((C_word*)t0)[2],t1);}

/* prefix in k961 in k957 in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_fcall f_973(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_973,NULL,4,t1,t2,t3,t4);}
if(C_truep(C_retrieve2(lf[14],"chicken-prefix"))){
t5=(C_word)C_a_i_list(&a,2,C_retrieve2(lf[14],"chicken-prefix"),t3);
/* csc.scm: 78   make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[20]))(4,*((C_word*)lf[20]+1),t1,t5,t2);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* quit in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_fcall f_944(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_944,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_948,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_955,a[2]=t3,a[3]=t2,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* csc.scm: 68   current-error-port */
((C_proc2)C_retrieve_symbol_proc(lf[13]))(2,*((C_word*)lf[13]+1),t5);}

/* k953 in quit in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_955(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 68   fprintf */
((C_proc6)C_retrieve_symbol_proc(lf[11]))(6,*((C_word*)lf[11]+1),((C_word*)t0)[4],t1,lf[12],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k946 in quit in k940 in k3682 in k3686 in k3690 in k924 in k921 in k918 in k915 in k912 in k909 in k906 in k903 in k900 in k897 in k894 in k891 in k888 */
static void C_ccall f_948(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 69   exit */
((C_proc3)C_retrieve_symbol_proc(lf[10]))(3,*((C_word*)lf[10]+1),((C_word*)t0)[2],C_fix(64));}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[305] = {
{"toplevel:csc_scm",(void*)C_toplevel},
{"f_890:csc_scm",(void*)f_890},
{"f_893:csc_scm",(void*)f_893},
{"f_896:csc_scm",(void*)f_896},
{"f_899:csc_scm",(void*)f_899},
{"f_902:csc_scm",(void*)f_902},
{"f_905:csc_scm",(void*)f_905},
{"f_908:csc_scm",(void*)f_908},
{"f_911:csc_scm",(void*)f_911},
{"f_914:csc_scm",(void*)f_914},
{"f_917:csc_scm",(void*)f_917},
{"f_920:csc_scm",(void*)f_920},
{"f_923:csc_scm",(void*)f_923},
{"f_926:csc_scm",(void*)f_926},
{"f_3692:csc_scm",(void*)f_3692},
{"f_3688:csc_scm",(void*)f_3688},
{"f_3684:csc_scm",(void*)f_3684},
{"f_3680:csc_scm",(void*)f_3680},
{"f_3676:csc_scm",(void*)f_3676},
{"f_942:csc_scm",(void*)f_942},
{"f_959:csc_scm",(void*)f_959},
{"f_963:csc_scm",(void*)f_963},
{"f_3660:csc_scm",(void*)f_3660},
{"f_3656:csc_scm",(void*)f_3656},
{"f_998:csc_scm",(void*)f_998},
{"f_3642:csc_scm",(void*)f_3642},
{"f_3646:csc_scm",(void*)f_3646},
{"f_3638:csc_scm",(void*)f_3638},
{"f_3634:csc_scm",(void*)f_3634},
{"f_1002:csc_scm",(void*)f_1002},
{"f_3624:csc_scm",(void*)f_3624},
{"f_1006:csc_scm",(void*)f_1006},
{"f_3614:csc_scm",(void*)f_3614},
{"f_1010:csc_scm",(void*)f_1010},
{"f_3601:csc_scm",(void*)f_3601},
{"f_1014:csc_scm",(void*)f_1014},
{"f_3588:csc_scm",(void*)f_3588},
{"f_1018:csc_scm",(void*)f_1018},
{"f_1050:csc_scm",(void*)f_1050},
{"f_1054:csc_scm",(void*)f_1054},
{"f_3567:csc_scm",(void*)f_3567},
{"f_1059:csc_scm",(void*)f_1059},
{"f_3557:csc_scm",(void*)f_3557},
{"f_1064:csc_scm",(void*)f_1064},
{"f_1090:csc_scm",(void*)f_1090},
{"f_1094:csc_scm",(void*)f_1094},
{"f_3531:csc_scm",(void*)f_3531},
{"f_3535:csc_scm",(void*)f_3535},
{"f_3527:csc_scm",(void*)f_3527},
{"f_3523:csc_scm",(void*)f_3523},
{"f_3519:csc_scm",(void*)f_3519},
{"f_3515:csc_scm",(void*)f_3515},
{"f_1102:csc_scm",(void*)f_1102},
{"f_3498:csc_scm",(void*)f_3498},
{"f_3502:csc_scm",(void*)f_3502},
{"f_3494:csc_scm",(void*)f_3494},
{"f_3490:csc_scm",(void*)f_3490},
{"f_3486:csc_scm",(void*)f_3486},
{"f_3482:csc_scm",(void*)f_3482},
{"f_1110:csc_scm",(void*)f_1110},
{"f_3469:csc_scm",(void*)f_3469},
{"f_1119:csc_scm",(void*)f_1119},
{"f_3458:csc_scm",(void*)f_3458},
{"f_3454:csc_scm",(void*)f_3454},
{"f_1127:csc_scm",(void*)f_1127},
{"f_3441:csc_scm",(void*)f_3441},
{"f_1135:csc_scm",(void*)f_1135},
{"f_3434:csc_scm",(void*)f_3434},
{"f_3408:csc_scm",(void*)f_3408},
{"f_3424:csc_scm",(void*)f_3424},
{"f_3420:csc_scm",(void*)f_3420},
{"f_3416:csc_scm",(void*)f_3416},
{"f_3412:csc_scm",(void*)f_3412},
{"f_3401:csc_scm",(void*)f_3401},
{"f_3397:csc_scm",(void*)f_3397},
{"f_3387:csc_scm",(void*)f_3387},
{"f_3383:csc_scm",(void*)f_3383},
{"f_1140:csc_scm",(void*)f_1140},
{"f_3370:csc_scm",(void*)f_3370},
{"f_3366:csc_scm",(void*)f_3366},
{"f_3362:csc_scm",(void*)f_3362},
{"f_1238:csc_scm",(void*)f_1238},
{"f_1436:csc_scm",(void*)f_1436},
{"f_1956:csc_scm",(void*)f_1956},
{"f_2197:csc_scm",(void*)f_2197},
{"f_2200:csc_scm",(void*)f_2200},
{"f_2203:csc_scm",(void*)f_2203},
{"f_2585:csc_scm",(void*)f_2585},
{"f_2254:csc_scm",(void*)f_2254},
{"f_2263:csc_scm",(void*)f_2263},
{"f_2440:csc_scm",(void*)f_2440},
{"f_2548:csc_scm",(void*)f_2548},
{"f_2554:csc_scm",(void*)f_2554},
{"f_2451:csc_scm",(void*)f_2451},
{"f_2462:csc_scm",(void*)f_2462},
{"f_2538:csc_scm",(void*)f_2538},
{"f_2530:csc_scm",(void*)f_2530},
{"f_2513:csc_scm",(void*)f_2513},
{"f_2489:csc_scm",(void*)f_2489},
{"f_2494:csc_scm",(void*)f_2494},
{"f_2476:csc_scm",(void*)f_2476},
{"f_2445:csc_scm",(void*)f_2445},
{"f_2410:csc_scm",(void*)f_2410},
{"f_2341:csc_scm",(void*)f_2341},
{"f_2393:csc_scm",(void*)f_2393},
{"f_2389:csc_scm",(void*)f_2389},
{"f_2374:csc_scm",(void*)f_2374},
{"f_2372:csc_scm",(void*)f_2372},
{"f_2368:csc_scm",(void*)f_2368},
{"f_2345:csc_scm",(void*)f_2345},
{"f_2331:csc_scm",(void*)f_2331},
{"f_2318:csc_scm",(void*)f_2318},
{"f_2301:csc_scm",(void*)f_2301},
{"f_2287:csc_scm",(void*)f_2287},
{"f_2273:csc_scm",(void*)f_2273},
{"f_2235:csc_scm",(void*)f_2235},
{"f_2241:csc_scm",(void*)f_2241},
{"f_2244:csc_scm",(void*)f_2244},
{"f_2190:csc_scm",(void*)f_2190},
{"f_2194:csc_scm",(void*)f_2194},
{"f_2144:csc_scm",(void*)f_2144},
{"f_2174:csc_scm",(void*)f_2174},
{"f_2166:csc_scm",(void*)f_2166},
{"f_2154:csc_scm",(void*)f_2154},
{"f_2133:csc_scm",(void*)f_2133},
{"f_2108:csc_scm",(void*)f_2108},
{"f_2120:csc_scm",(void*)f_2120},
{"f_2112:csc_scm",(void*)f_2112},
{"f_2095:csc_scm",(void*)f_2095},
{"f_2069:csc_scm",(void*)f_2069},
{"f_2081:csc_scm",(void*)f_2081},
{"f_2073:csc_scm",(void*)f_2073},
{"f_2048:csc_scm",(void*)f_2048},
{"f_2052:csc_scm",(void*)f_2052},
{"f_2031:csc_scm",(void*)f_2031},
{"f_2014:csc_scm",(void*)f_2014},
{"f_1997:csc_scm",(void*)f_1997},
{"f_1980:csc_scm",(void*)f_1980},
{"f_1939:csc_scm",(void*)f_1939},
{"f_1929:csc_scm",(void*)f_1929},
{"f_1919:csc_scm",(void*)f_1919},
{"f_1909:csc_scm",(void*)f_1909},
{"f_1899:csc_scm",(void*)f_1899},
{"f_1889:csc_scm",(void*)f_1889},
{"f_1879:csc_scm",(void*)f_1879},
{"f_1858:csc_scm",(void*)f_1858},
{"f_1834:csc_scm",(void*)f_1834},
{"f_1845:csc_scm",(void*)f_1845},
{"f_1837:csc_scm",(void*)f_1837},
{"f_1821:csc_scm",(void*)f_1821},
{"f_1810:csc_scm",(void*)f_1810},
{"f_1770:csc_scm",(void*)f_1770},
{"f_1774:csc_scm",(void*)f_1774},
{"f_1777:csc_scm",(void*)f_1777},
{"f_1738:csc_scm",(void*)f_1738},
{"f_1742:csc_scm",(void*)f_1742},
{"f_1745:csc_scm",(void*)f_1745},
{"f_1647:csc_scm",(void*)f_1647},
{"f_1665:csc_scm",(void*)f_1665},
{"f_1650:csc_scm",(void*)f_1650},
{"f_1590:csc_scm",(void*)f_1590},
{"f_1578:csc_scm",(void*)f_1578},
{"f_1566:csc_scm",(void*)f_1566},
{"f_1554:csc_scm",(void*)f_1554},
{"f_1528:csc_scm",(void*)f_1528},
{"f_1517:csc_scm",(void*)f_1517},
{"f_1486:csc_scm",(void*)f_1486},
{"f_1479:csc_scm",(void*)f_1479},
{"f_1470:csc_scm",(void*)f_1470},
{"f_1463:csc_scm",(void*)f_1463},
{"f_1451:csc_scm",(void*)f_1451},
{"f_1439:csc_scm",(void*)f_1439},
{"f_1249:csc_scm",(void*)f_1249},
{"f_1253:csc_scm",(void*)f_1253},
{"f_1427:csc_scm",(void*)f_1427},
{"f_1394:csc_scm",(void*)f_1394},
{"f_1420:csc_scm",(void*)f_1420},
{"f_1397:csc_scm",(void*)f_1397},
{"f_1413:csc_scm",(void*)f_1413},
{"f_1400:csc_scm",(void*)f_1400},
{"f_1403:csc_scm",(void*)f_1403},
{"f_1256:csc_scm",(void*)f_1256},
{"f_1357:csc_scm",(void*)f_1357},
{"f_1367:csc_scm",(void*)f_1367},
{"f_1360:csc_scm",(void*)f_1360},
{"f_2663:csc_scm",(void*)f_2663},
{"f_2667:csc_scm",(void*)f_2667},
{"f_2708:csc_scm",(void*)f_2708},
{"f_2735:csc_scm",(void*)f_2735},
{"f_2716:csc_scm",(void*)f_2716},
{"f_2724:csc_scm",(void*)f_2724},
{"f_2720:csc_scm",(void*)f_2720},
{"f_2712:csc_scm",(void*)f_2712},
{"f_2704:csc_scm",(void*)f_2704},
{"f_2700:csc_scm",(void*)f_2700},
{"f_2696:csc_scm",(void*)f_2696},
{"f_2670:csc_scm",(void*)f_2670},
{"f_2674:csc_scm",(void*)f_2674},
{"f_2678:csc_scm",(void*)f_2678},
{"f_2655:csc_scm",(void*)f_2655},
{"f_1319:csc_scm",(void*)f_1319},
{"f_1322:csc_scm",(void*)f_1322},
{"f_1329:csc_scm",(void*)f_1329},
{"f_1259:csc_scm",(void*)f_1259},
{"f_2775:csc_scm",(void*)f_2775},
{"f_2779:csc_scm",(void*)f_2779},
{"f_2816:csc_scm",(void*)f_2816},
{"f_2828:csc_scm",(void*)f_2828},
{"f_2820:csc_scm",(void*)f_2820},
{"f_2824:csc_scm",(void*)f_2824},
{"f_2804:csc_scm",(void*)f_2804},
{"f_2800:csc_scm",(void*)f_2800},
{"f_2782:csc_scm",(void*)f_2782},
{"f_2759:csc_scm",(void*)f_2759},
{"f_2773:csc_scm",(void*)f_2773},
{"f_2763:csc_scm",(void*)f_2763},
{"f_1265:csc_scm",(void*)f_1265},
{"f_1280:csc_scm",(void*)f_1280},
{"f_1305:csc_scm",(void*)f_1305},
{"f_1313:csc_scm",(void*)f_1313},
{"f_1309:csc_scm",(void*)f_1309},
{"f_1297:csc_scm",(void*)f_1297},
{"f_1293:csc_scm",(void*)f_1293},
{"f_1271:csc_scm",(void*)f_1271},
{"f_2976:csc_scm",(void*)f_2976},
{"f_2970:csc_scm",(void*)f_2970},
{"f_2968:csc_scm",(void*)f_2968},
{"f_2964:csc_scm",(void*)f_2964},
{"f_2855:csc_scm",(void*)f_2855},
{"f_2858:csc_scm",(void*)f_2858},
{"f_2952:csc_scm",(void*)f_2952},
{"f_2956:csc_scm",(void*)f_2956},
{"f_2960:csc_scm",(void*)f_2960},
{"f_2944:csc_scm",(void*)f_2944},
{"f_2936:csc_scm",(void*)f_2936},
{"f_2932:csc_scm",(void*)f_2932},
{"f_2928:csc_scm",(void*)f_2928},
{"f_2861:csc_scm",(void*)f_2861},
{"f_2873:csc_scm",(void*)f_2873},
{"f_2906:csc_scm",(void*)f_2906},
{"f_2902:csc_scm",(void*)f_2902},
{"f_2898:csc_scm",(void*)f_2898},
{"f_2894:csc_scm",(void*)f_2894},
{"f_2890:csc_scm",(void*)f_2890},
{"f_2886:csc_scm",(void*)f_2886},
{"f_2864:csc_scm",(void*)f_2864},
{"f_1209:csc_scm",(void*)f_1209},
{"f_1214:csc_scm",(void*)f_1214},
{"f_1218:csc_scm",(void*)f_1218},
{"f_1170:csc_scm",(void*)f_1170},
{"f_1188:csc_scm",(void*)f_1188},
{"f_1163:csc_scm",(void*)f_1163},
{"f_1168:csc_scm",(void*)f_1168},
{"f_3352:csc_scm",(void*)f_3352},
{"f_3358:csc_scm",(void*)f_3358},
{"f_3355:csc_scm",(void*)f_3355},
{"f_3336:csc_scm",(void*)f_3336},
{"f_3340:csc_scm",(void*)f_3340},
{"f_3305:csc_scm",(void*)f_3305},
{"f_3309:csc_scm",(void*)f_3309},
{"f_3312:csc_scm",(void*)f_3312},
{"f_3316:csc_scm",(void*)f_3316},
{"f_3319:csc_scm",(void*)f_3319},
{"f_3280:csc_scm",(void*)f_3280},
{"f_3292:csc_scm",(void*)f_3292},
{"f_3287:csc_scm",(void*)f_3287},
{"f_3231:csc_scm",(void*)f_3231},
{"f_3233:csc_scm",(void*)f_3233},
{"f_3263:csc_scm",(void*)f_3263},
{"f_3270:csc_scm",(void*)f_3270},
{"f_3256:csc_scm",(void*)f_3256},
{"f_3227:csc_scm",(void*)f_3227},
{"f_3213:csc_scm",(void*)f_3213},
{"f_3223:csc_scm",(void*)f_3223},
{"f_3131:csc_scm",(void*)f_3131},
{"f_3135:csc_scm",(void*)f_3135},
{"f_3183:csc_scm",(void*)f_3183},
{"f_3177:csc_scm",(void*)f_3177},
{"f_3146:csc_scm",(void*)f_3146},
{"f_3142:csc_scm",(void*)f_3142},
{"f_3079:csc_scm",(void*)f_3079},
{"f_3125:csc_scm",(void*)f_3125},
{"f_3119:csc_scm",(void*)f_3119},
{"f_3117:csc_scm",(void*)f_3117},
{"f_3113:csc_scm",(void*)f_3113},
{"f_3087:csc_scm",(void*)f_3087},
{"f_2982:csc_scm",(void*)f_2982},
{"f_2986:csc_scm",(void*)f_2986},
{"f_2997:csc_scm",(void*)f_2997},
{"f_3018:csc_scm",(void*)f_3018},
{"f_3056:csc_scm",(void*)f_3056},
{"f_3038:csc_scm",(void*)f_3038},
{"f_3042:csc_scm",(void*)f_3042},
{"f_3011:csc_scm",(void*)f_3011},
{"f_3015:csc_scm",(void*)f_3015},
{"f_2830:csc_scm",(void*)f_2830},
{"f_2842:csc_scm",(void*)f_2842},
{"f_2838:csc_scm",(void*)f_2838},
{"f_986:csc_scm",(void*)f_986},
{"f_994:csc_scm",(void*)f_994},
{"f_973:csc_scm",(void*)f_973},
{"f_944:csc_scm",(void*)f_944},
{"f_955:csc_scm",(void*)f_955},
{"f_948:csc_scm",(void*)f_948},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
