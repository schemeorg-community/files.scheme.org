/* Generated from chicken-install.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2009-03-24 10:49
   Version 4.0.0 - SVN rev. 13887
   windows-mingw32-x86 [ manyargs dload ptables applyhook ]
   compiled 2009-03-24 on LENOVO-1 (MINGW32_NT-6.0)
   command line: chicken-install.scm -no-trace -optimize-level 2 -include-path . -include-path ./ -feature debugbuild -no-lambda-info -inline -local -ignore-repository -output-file chicken-install.c
   used units: library eval data_structures ports extras srfi_69 srfi_1 posix data_structures utils regex ports extras srfi_13 files
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_69_toplevel)
C_externimport void C_ccall C_srfi_69_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_1_toplevel)
C_externimport void C_ccall C_srfi_1_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_posix_toplevel)
C_externimport void C_ccall C_posix_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_utils_toplevel)
C_externimport void C_ccall C_utils_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_regex_toplevel)
C_externimport void C_ccall C_regex_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_13_toplevel)
C_externimport void C_ccall C_srfi_13_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_files_toplevel)
C_externimport void C_ccall C_files_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[240];
static double C_possibly_force_alignment;


C_noret_decl(C_toplevel)
C_externexport void C_ccall C_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_971)
static void C_ccall f_971(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_974)
static void C_ccall f_974(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_977)
static void C_ccall f_977(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_980)
static void C_ccall f_980(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_983)
static void C_ccall f_983(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_986)
static void C_ccall f_986(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_989)
static void C_ccall f_989(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_992)
static void C_ccall f_992(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_995)
static void C_ccall f_995(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_998)
static void C_ccall f_998(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1001)
static void C_ccall f_1001(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1004)
static void C_ccall f_1004(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1007)
static void C_ccall f_1007(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1010)
static void C_ccall f_1010(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1013)
static void C_ccall f_1013(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1016)
static void C_ccall f_1016(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1019)
static void C_ccall f_1019(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1024)
static void C_ccall f_1024(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1027)
static void C_ccall f_1027(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1030)
static void C_ccall f_1030(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3000)
static void C_ccall f_3000(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1424)
static void C_ccall f_1424(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2924)
static void C_ccall f_2924(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2939)
static void C_ccall f_2939(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2967)
static void C_ccall f_2967(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2986)
static void C_ccall f_2986(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2986)
static void C_ccall f_2986r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2992)
static void C_ccall f_2992(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2973)
static void C_ccall f_2973(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2984)
static void C_ccall f_2984(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1072)
static void C_ccall f_1072(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1051)
static void C_ccall f_1051(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1068)
static void C_ccall f_1068(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1061)
static void C_ccall f_1061(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2275)
static void C_fcall f_2275(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2280)
static void C_fcall f_2280(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2370)
static void C_fcall f_2370(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2723)
static void C_fcall f_2723(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2868)
static void C_ccall f_2868(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2831)
static void C_ccall f_2831(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2845)
static void C_ccall f_2845(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2786)
static void C_ccall f_2786(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2809)
static void C_ccall f_2809(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2818)
static void C_ccall f_2818(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2825)
static void C_ccall f_2825(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2812)
static void C_ccall f_2812(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2790)
static void C_ccall f_2790(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2770)
static void C_ccall f_2770(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2732)
static void C_ccall f_2732(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2766)
static void C_ccall f_2766(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2755)
static void C_ccall f_2755(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2749)
static void C_ccall f_2749(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2745)
static void C_ccall f_2745(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2696)
static void C_ccall f_2696(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2666)
static void C_ccall f_2666(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2609)
static void C_ccall f_2609(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1136)
static void C_ccall f_1136(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1142)
static void C_ccall f_1142(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1147)
static void C_ccall f_1147(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1167)
static void C_ccall f_1167(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1159)
static void C_ccall f_1159(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1163)
static void C_ccall f_1163(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1155)
static void C_ccall f_1155(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2612)
static void C_ccall f_2612(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2580)
static void C_ccall f_2580(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2573)
static void C_ccall f_2573(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2522)
static void C_ccall f_2522(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2485)
static void C_ccall f_2485(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2489)
static void C_ccall f_2489(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2452)
static void C_ccall f_2452(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2416)
static void C_ccall f_2416(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2324)
static void C_ccall f_2324(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2355)
static void C_ccall f_2355(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2340)
static void C_ccall f_2340(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2348)
static void C_ccall f_2348(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2338)
static void C_ccall f_2338(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2334)
static void C_ccall f_2334(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2296)
static void C_ccall f_2296(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2309)
static void C_ccall f_2309(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2299)
static void C_ccall f_2299(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2306)
static void C_ccall f_2306(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1942)
static void C_ccall f_1942(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1950)
static void C_ccall f_1950(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1954)
static void C_ccall f_1954(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1957)
static void C_ccall f_1957(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1974)
static void C_ccall f_1974(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1886)
static void C_ccall f_1886(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1928)
static void C_ccall f_1928(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1906)
static void C_ccall f_1906(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1914)
static void C_ccall f_1914(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1910)
static void C_ccall f_1910(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1978)
static void C_ccall f_1978(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1981)
static void C_ccall f_1981(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1984)
static void C_ccall f_1984(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2012)
static void C_ccall f_2012(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2018)
static void C_ccall f_2018(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1990)
static void C_ccall f_1990(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1993)
static void C_ccall f_1993(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1996)
static void C_ccall f_1996(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1999)
static void C_ccall f_1999(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1961)
static void C_ccall f_1961(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1965)
static void C_ccall f_1965(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1968)
static void C_ccall f_1968(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2237)
static void C_ccall f_2237(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2233)
static void C_ccall f_2233(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2054)
static void C_ccall f_2054(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2057)
static void C_ccall f_2057(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2060)
static void C_ccall f_2060(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2063)
static void C_ccall f_2063(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2226)
static void C_ccall f_2226(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2195)
static void C_ccall f_2195(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2201)
static void C_ccall f_2201(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2205)
static void C_ccall f_2205(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2220)
static void C_ccall f_2220(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2190)
static void C_ccall f_2190(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2066)
static void C_ccall f_2066(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2069)
static void C_ccall f_2069(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2135)
static void C_ccall f_2135(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2142)
static void C_ccall f_2142(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2145)
static void C_ccall f_2145(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2156)
static void C_ccall f_2156(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2180)
static void C_ccall f_2180(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2164)
static void C_ccall f_2164(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2170)
static void C_ccall f_2170(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2168)
static void C_ccall f_2168(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2150)
static void C_ccall f_2150(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2111)
static void C_ccall f_2111(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2113)
static void C_ccall f_2113(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2121)
static void C_ccall f_2121(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2125)
static void C_ccall f_2125(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2072)
static void C_ccall f_2072(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2075)
static void C_ccall f_2075(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2094)
static void C_ccall f_2094(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2100)
static void C_ccall f_2100(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2104)
static void C_ccall f_2104(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2078)
static void C_ccall f_2078(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2092)
static void C_ccall f_2092(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2088)
static void C_ccall f_2088(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2081)
static void C_ccall f_2081(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2977)
static void C_ccall f_2977(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2945)
static void C_ccall f_2945(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2951)
static void C_ccall f_2951(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2965)
static void C_ccall f_2965(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2955)
static void C_ccall f_2955(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2958)
static void C_ccall f_2958(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2937)
static void C_ccall f_2937(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2928)
static void C_ccall f_2928(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2934)
static void C_ccall f_2934(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2931)
static void C_ccall f_2931(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2261)
static void C_fcall f_2261(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2265)
static void C_ccall f_2265(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2239)
static void C_fcall f_2239(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2256)
static void C_ccall f_2256(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2243)
static void C_ccall f_2243(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2035)
static void C_fcall f_2035(C_word t0) C_noret;
C_noret_decl(f_2042)
static void C_ccall f_2042(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1668)
static void C_fcall f_1668(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1672)
static void C_ccall f_1672(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1814)
static void C_ccall f_1814(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1846)
static void C_ccall f_1846(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1850)
static void C_ccall f_1850(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1853)
static void C_ccall f_1853(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1857)
static void C_ccall f_1857(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1840)
static void C_ccall f_1840(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1543)
static void C_fcall f_1543(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1545)
static void C_fcall f_1545(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1609)
static void C_ccall f_1609(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1599)
static void C_ccall f_1599(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1575)
static void C_ccall f_1575(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1115)
static void C_ccall f_1115(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1569)
static void C_ccall f_1569(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1435)
static void C_ccall f_1435(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1504)
static void C_ccall f_1504(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1523)
static void C_ccall f_1523(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1523)
static void C_ccall f_1523r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1529)
static void C_ccall f_1529(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1510)
static void C_ccall f_1510(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1518)
static void C_ccall f_1518(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1441)
static void C_ccall f_1441(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1447)
static void C_ccall f_1447(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1457)
static void C_fcall f_1457(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1469)
static void C_fcall f_1469(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1472)
static void C_ccall f_1472(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1460)
static void C_ccall f_1460(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1433)
static void C_ccall f_1433(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1829)
static void C_ccall f_1829(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1675)
static void C_ccall f_1675(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1683)
static void C_ccall f_1683(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1697)
static void C_ccall f_1697(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1703)
static void C_ccall f_1703(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1792)
static void C_ccall f_1792(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1706)
static void C_ccall f_1706(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1709)
static void C_ccall f_1709(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1720)
static void C_ccall f_1720(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1781)
static void C_ccall f_1781(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1774)
static void C_ccall f_1774(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1724)
static void C_ccall f_1724(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1632)
static void C_ccall f_1632(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1658)
static void C_ccall f_1658(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1630)
static void C_ccall f_1630(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1622)
static void C_ccall f_1622(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1768)
static void C_ccall f_1768(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1730)
static void C_ccall f_1730(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1733)
static void C_ccall f_1733(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1755)
static void C_ccall f_1755(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1736)
static void C_ccall f_1736(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1744)
static void C_ccall f_1744(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1748)
static void C_ccall f_1748(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1739)
static void C_ccall f_1739(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1714)
static void C_ccall f_1714(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1415)
static void C_fcall f_1415(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1220)
static void C_ccall f_1220(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1225)
static void C_fcall f_1225(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1281)
static void C_fcall f_1281(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1367)
static void C_ccall f_1367(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1284)
static void C_ccall f_1284(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1293)
static void C_ccall f_1293(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1304)
static void C_ccall f_1304(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1308)
static void C_ccall f_1308(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1300)
static void C_ccall f_1300(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1356)
static void C_ccall f_1356(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1326)
static void C_ccall f_1326(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1337)
static void C_ccall f_1337(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1341)
static void C_ccall f_1341(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1333)
static void C_ccall f_1333(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1268)
static void C_ccall f_1268(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1275)
static void C_ccall f_1275(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1265)
static void C_fcall f_1265(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1239)
static void C_ccall f_1239(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1243)
static void C_ccall f_1243(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1169)
static void C_fcall f_1169(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1214)
static void C_ccall f_1214(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1179)
static void C_fcall f_1179(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1185)
static void C_ccall f_1185(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_2275)
static void C_fcall trf_2275(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2275(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2275(t0,t1);}

C_noret_decl(trf_2280)
static void C_fcall trf_2280(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2280(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2280(t0,t1,t2,t3);}

C_noret_decl(trf_2370)
static void C_fcall trf_2370(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2370(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2370(t0,t1);}

C_noret_decl(trf_2723)
static void C_fcall trf_2723(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2723(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2723(t0,t1);}

C_noret_decl(trf_2261)
static void C_fcall trf_2261(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2261(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2261(t0,t1);}

C_noret_decl(trf_2239)
static void C_fcall trf_2239(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2239(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2239(t0,t1);}

C_noret_decl(trf_2035)
static void C_fcall trf_2035(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2035(void *dummy){
C_word t0=C_pick(0);
C_adjust_stack(-1);
f_2035(t0);}

C_noret_decl(trf_1668)
static void C_fcall trf_1668(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1668(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1668(t0,t1);}

C_noret_decl(trf_1543)
static void C_fcall trf_1543(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1543(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1543(t0,t1);}

C_noret_decl(trf_1545)
static void C_fcall trf_1545(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1545(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1545(t0,t1,t2);}

C_noret_decl(trf_1457)
static void C_fcall trf_1457(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1457(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1457(t0,t1);}

C_noret_decl(trf_1469)
static void C_fcall trf_1469(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1469(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1469(t0,t1);}

C_noret_decl(trf_1415)
static void C_fcall trf_1415(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1415(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1415(t0,t1);}

C_noret_decl(trf_1225)
static void C_fcall trf_1225(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1225(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1225(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1281)
static void C_fcall trf_1281(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1281(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1281(t0,t1);}

C_noret_decl(trf_1265)
static void C_fcall trf_1265(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1265(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1265(t0,t1);}

C_noret_decl(trf_1169)
static void C_fcall trf_1169(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1169(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1169(t0,t1);}

C_noret_decl(trf_1179)
static void C_fcall trf_1179(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1179(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1179(t0,t1);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_main_entry_point
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("toplevel"));
C_resize_stack(131072);
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(1127)){
C_save(t1);
C_rereclaim2(1127*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,240);
lf[13]=C_h_intern(&lf[13],4,"http");
lf[16]=C_decode_literal(C_heaptop,"\376B\000\000\012modules.db");
lf[18]=C_h_intern(&lf[18],7,"chicken");
lf[19]=C_h_intern(&lf[19],15,"chicken-version");
lf[20]=C_h_intern(&lf[20],7,"version");
lf[21]=C_h_intern(&lf[21],8,"->string");
lf[22]=C_decode_literal(C_heaptop,"\376B\000\000\0051.0.0");
lf[23]=C_h_intern(&lf[23],21,"extension-information");
lf[24]=C_decode_literal(C_heaptop,"\376B\000\000\007chicken");
lf[25]=C_h_intern(&lf[25],24,"\003syscore-library-modules");
lf[30]=C_h_intern(&lf[30],7,"reverse");
lf[31]=C_h_intern(&lf[31],10,"alist-cons");
lf[32]=C_h_intern(&lf[32],20,"setup-api#version>=\077");
lf[33]=C_h_intern(&lf[33],7,"warning");
lf[34]=C_decode_literal(C_heaptop,"\376B\000\000Ainstalled extension has unknown version - assuming it is outdated");
lf[35]=C_decode_literal(C_heaptop,"\376B\000\0007invalid dependency syntax in extension meta information");
lf[36]=C_h_intern(&lf[36],7,"depends");
lf[37]=C_h_intern(&lf[37],5,"needs");
lf[38]=C_h_intern(&lf[38],6,"append");
lf[39]=C_h_intern(&lf[39],12,"test-depends");
lf[40]=C_h_intern(&lf[40],26,"setup-api#remove-extension");
lf[41]=C_h_intern(&lf[41],5,"print");
lf[42]=C_decode_literal(C_heaptop,"\376B\000\000)removing previously installed extension `");
lf[43]=C_decode_literal(C_heaptop,"\376B\000\000\005\047 ...");
lf[44]=C_h_intern(&lf[44],12,"\003sysfor-each");
lf[45]=C_decode_literal(C_heaptop,"\376B\000\000\012 upgrade: ");
lf[46]=C_h_intern(&lf[46],18,"string-intersperse");
lf[47]=C_decode_literal(C_heaptop,"\376B\000\000\002, ");
lf[48]=C_h_intern(&lf[48],6,"unzip1");
lf[49]=C_h_intern(&lf[49],20,"setup-api#yes-or-no\077");
lf[50]=C_decode_literal(C_heaptop,"\376B\000\000\002no");
lf[51]=C_h_intern(&lf[51],18,"string-concatenate");
lf[52]=C_decode_literal(C_heaptop,"\376B\000\000:The following installed extensions are outdated, because `");
lf[53]=C_decode_literal(C_heaptop,"\376B\000\000\033\047 requires later versions:\012");
lf[54]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\0000\012Do you want to replace the existing extensions\077\376\377\016");
lf[55]=C_decode_literal(C_heaptop,"\376B\000\000\003\077\077\077");
lf[56]=C_h_intern(&lf[56],4,"conc");
lf[57]=C_decode_literal(C_heaptop,"\376B\000\000\002  ");
lf[58]=C_decode_literal(C_heaptop,"\376B\000\000\002 (");
lf[59]=C_decode_literal(C_heaptop,"\376B\000\000\004 -> ");
lf[60]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[61]=C_h_intern(&lf[61],7,"\003sysmap");
lf[62]=C_decode_literal(C_heaptop,"\376B\000\000\012 missing: ");
lf[63]=C_decode_literal(C_heaptop,"\376B\000\000\002, ");
lf[64]=C_decode_literal(C_heaptop,"\376B\000\000\033checking dependencies for `");
lf[65]=C_decode_literal(C_heaptop,"\376B\000\000\005\047 ...");
lf[66]=C_h_intern(&lf[66],20,"with-input-from-file");
lf[67]=C_h_intern(&lf[67],4,"read");
lf[68]=C_h_intern(&lf[68],13,"string-append");
lf[69]=C_decode_literal(C_heaptop,"\376B\000\000\013extension `");
lf[70]=C_decode_literal(C_heaptop,"\376B\000\000\024\047 has no .meta file ");
lf[71]=C_decode_literal(C_heaptop,"\376B\000\000!- assuming it has no dependencies");
lf[72]=C_h_intern(&lf[72],12,"file-exists\077");
lf[73]=C_h_intern(&lf[73],13,"make-pathname");
lf[74]=C_decode_literal(C_heaptop,"\376B\000\000\004meta");
lf[75]=C_h_intern(&lf[75],6,"delete");
lf[76]=C_h_intern(&lf[76],3,"eq\077");
lf[77]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[78]=C_h_intern(&lf[78],8,"location");
lf[79]=C_h_intern(&lf[79],9,"transport");
lf[80]=C_h_intern(&lf[80],9,"condition");
lf[81]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[82]=C_decode_literal(C_heaptop,"\376B\000\000\023TCP connect timeout");
lf[83]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[84]=C_decode_literal(C_heaptop,"\376B\000\000\023HTTP protocol error");
lf[85]=C_h_intern(&lf[85],5,"abort");
lf[86]=C_h_intern(&lf[86],3,"exn");
lf[87]=C_h_intern(&lf[87],10,"http-fetch");
lf[88]=C_h_intern(&lf[88],3,"net");
lf[89]=C_h_intern(&lf[89],33,"setup-download#retrieve-extension");
lf[90]=C_h_intern(&lf[90],8,"\000version");
lf[91]=C_h_intern(&lf[91],12,"\000destination");
lf[92]=C_h_intern(&lf[92],6,"\000tests");
lf[93]=C_h_intern(&lf[93],9,"\000username");
lf[94]=C_h_intern(&lf[94],9,"\000password");
lf[95]=C_h_intern(&lf[95],17,"current-directory");
lf[96]=C_h_intern(&lf[96],22,"with-exception-handler");
lf[97]=C_h_intern(&lf[97],30,"call-with-current-continuation");
lf[98]=C_h_intern(&lf[98],5,"error");
lf[99]=C_decode_literal(C_heaptop,"\376B\000\000\027missing transport entry");
lf[100]=C_decode_literal(C_heaptop,"\376B\000\000\026missing location entry");
lf[101]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[102]=C_decode_literal(C_heaptop,"\376B\000\000\014 located at ");
lf[103]=C_decode_literal(C_heaptop,"\376B\000\000\036extension or version not found");
lf[104]=C_decode_literal(C_heaptop,"\376B\000\000\016retrieving ...");
lf[106]=C_h_intern(&lf[106],26,"setup-api#remove-directory");
lf[107]=C_h_intern(&lf[107],34,"setup-download#temporary-directory");
lf[109]=C_decode_literal(C_heaptop,"\376B\000\000/shell command terminated with nonzero exit code");
lf[110]=C_h_intern(&lf[110],6,"system");
lf[111]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[112]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[114]=C_h_intern(&lf[114],4,"exit");
lf[115]=C_decode_literal(C_heaptop,"\376B\000\004\257usage: chicken-install [OPTION | EXTENSION[:VERSION]] ...\012\012  -h   -help    "
"                show this message and exit\012  -v   -version                 show "
"version and exit\012       -force                   don\047t ask, install even if vers"
"ions don\047t match\012  -k   -keep                    keep temporary files\012  -l   -lo"
"cation LOCATION       install from given location instead of default\012  -t   -tra"
"nsport TRANSPORT     use given transport instead of default\012  -s   -sudo        "
"            use sudo(1) for installing or removing files\012  -r   -retrieve       "
"         only retrieve egg into current directory, don\047t install\012  -n   -no-inst"
"all              do not install, just build (implies `-keep\047)\012  -p   -prefix PRE"
"FIX           change installation prefix to PREFIX\012       -host-extension       "
"   when cross-compiling, compile extension for host\012       -test                "
"    run included test-cases, if available\012       -username USER           set us"
"ername for transports that require this\012       -password PASS           set pass"
"word for transports that require this\012  -i   -init DIRECTORY          initialize"
" empty alternative repository\012  -u   -update-db               update export data"
"base");
lf[116]=C_h_intern(&lf[116],35,"\010compilercompiler-macro-environment");
lf[117]=C_h_intern(&lf[117],25,"\003sysimplicit-exit-handler");
lf[118]=C_h_intern(&lf[118],19,"print-error-message");
lf[119]=C_h_intern(&lf[119],18,"current-error-port");
lf[120]=C_h_intern(&lf[120],19,"setup-api#copy-file");
lf[121]=C_h_intern(&lf[121],15,"repository-path");
lf[122]=C_h_intern(&lf[122],7,"newline");
lf[123]=C_h_intern(&lf[123],5,"write");
lf[124]=C_h_intern(&lf[124],19,"with-output-to-file");
lf[125]=C_h_intern(&lf[125],8,"string<\077");
lf[126]=C_h_intern(&lf[126],14,"symbol->string");
lf[127]=C_h_intern(&lf[127],4,"sort");
lf[128]=C_h_intern(&lf[128],18,"\003sysmodule-exports");
lf[129]=C_h_intern(&lf[129],5,"value");
lf[130]=C_h_intern(&lf[130],6,"syntax");
lf[131]=C_h_intern(&lf[131],6,"print*");
lf[132]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[133]=C_h_intern(&lf[133],15,"\003sysmodule-name");
lf[134]=C_h_intern(&lf[134],10,"append-map");
lf[135]=C_h_intern(&lf[135],16,"\003sysmodule-table");
lf[136]=C_decode_literal(C_heaptop,"\376B\000\000\023generating database");
lf[137]=C_h_intern(&lf[137],20,"\003syswarnings-enabled");
lf[138]=C_h_intern(&lf[138],6,"import");
lf[139]=C_h_intern(&lf[139],4,"eval");
lf[140]=C_h_intern(&lf[140],14,"string->symbol");
lf[141]=C_h_intern(&lf[141],12,"string-match");
lf[142]=C_h_intern(&lf[142],16,"\003sysdynamic-wind");
lf[143]=C_h_intern(&lf[143],6,"regexp");
lf[144]=C_decode_literal(C_heaptop,"\376B\000\000\034.*/([^/]+)\134.import\134.(scm|so)");
lf[145]=C_h_intern(&lf[145],36,"setup-api#create-temporary-directory");
lf[146]=C_h_intern(&lf[146],4,"glob");
lf[147]=C_decode_literal(C_heaptop,"\376B\000\000\012*.import.*");
lf[148]=C_decode_literal(C_heaptop,"\376B\000\000\002  ");
lf[149]=C_h_intern(&lf[149],7,"sprintf");
lf[150]=C_decode_literal(C_heaptop,"\376B\000\000\020~a -s run.scm ~a");
lf[151]=C_decode_literal(C_heaptop,"\376B\000\000\005tests");
lf[152]=C_decode_literal(C_heaptop,"\376B\000\000\015tests/run.scm");
lf[153]=C_h_intern(&lf[153],10,"directory\077");
lf[154]=C_decode_literal(C_heaptop,"\376B\000\000\005tests");
lf[155]=C_decode_literal(C_heaptop,"\376B\000\000\005tests");
lf[156]=C_decode_literal(C_heaptop,"\376B\000\000\002  ");
lf[157]=C_decode_literal(C_heaptop,"\376B\000\000\027 -e \042(sudo-install #t)\042");
lf[158]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[159]=C_decode_literal(C_heaptop,"\376B\000\000\035 -e \042(keep-intermediates #t)\042");
lf[160]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[161]=C_decode_literal(C_heaptop,"\376B\000\000\035 -e \042(setup-install-flag #f)\042");
lf[162]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[163]=C_decode_literal(C_heaptop,"\376B\000\000\031 -e \042(host-extension #t)\042");
lf[164]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[165]=C_decode_literal(C_heaptop,"\376B\000\000> -bnq -e \042(require-library setup-api)\042 -e \042(import setup-api)\042");
lf[166]=C_h_intern(&lf[166],19,"setup-api#shellpath");
lf[167]=C_decode_literal(C_heaptop,"\376B\000\000\005setup");
lf[168]=C_decode_literal(C_heaptop,"\376B\000\000\042 -e \042(installation-prefix \134\042~a\134\042)\042");
lf[169]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[170]=C_h_intern(&lf[170],22,"setup-api#sudo-install");
lf[171]=C_decode_literal(C_heaptop,"\376B\000\0003 -e \042(extension-name-and-version \047(\134\042~a\134\042 \134\042~a\134\042))\042");
lf[172]=C_decode_literal(C_heaptop,"\376B\000\000\036changing current directory to ");
lf[173]=C_decode_literal(C_heaptop,"\376B\000\000\013installing ");
lf[174]=C_decode_literal(C_heaptop,"\376B\000\000\004 ...");
lf[175]=C_decode_literal(C_heaptop,"\376B\000\000;no default location defined - please use `-location\047 option");
lf[176]=C_decode_literal(C_heaptop,"\376B\000\000=no default transport defined - please use `-transport\047 option");
lf[177]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[178]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[179]=C_h_intern(&lf[179],13,"pathname-file");
lf[180]=C_decode_literal(C_heaptop,"\376B\000\000\033no setup-scripts to process");
lf[181]=C_decode_literal(C_heaptop,"\376B\000\000\007*.setup");
lf[182]=C_decode_literal(C_heaptop,"\376B\000\000\005-help");
lf[183]=C_decode_literal(C_heaptop,"\376B\000\000\006-force");
lf[184]=C_decode_literal(C_heaptop,"\376B\000\000\002-k");
lf[185]=C_decode_literal(C_heaptop,"\376B\000\000\005-keep");
lf[186]=C_decode_literal(C_heaptop,"\376B\000\000\002-s");
lf[187]=C_decode_literal(C_heaptop,"\376B\000\000\005-sudo");
lf[188]=C_decode_literal(C_heaptop,"\376B\000\000\002-r");
lf[189]=C_decode_literal(C_heaptop,"\376B\000\000\011-retrieve");
lf[190]=C_decode_literal(C_heaptop,"\376B\000\000\002-l");
lf[191]=C_decode_literal(C_heaptop,"\376B\000\000\011-location");
lf[192]=C_decode_literal(C_heaptop,"\376B\000\000\002-t");
lf[193]=C_decode_literal(C_heaptop,"\376B\000\000\012-transport");
lf[194]=C_decode_literal(C_heaptop,"\376B\000\000\002-p");
lf[195]=C_decode_literal(C_heaptop,"\376B\000\000\007-prefix");
lf[196]=C_decode_literal(C_heaptop,"\376B\000\000\002-n");
lf[197]=C_decode_literal(C_heaptop,"\376B\000\000\013-no-install");
lf[198]=C_decode_literal(C_heaptop,"\376B\000\000\002-v");
lf[199]=C_decode_literal(C_heaptop,"\376B\000\000\010-version");
lf[200]=C_decode_literal(C_heaptop,"\376B\000\000\002-u");
lf[201]=C_decode_literal(C_heaptop,"\376B\000\000\012-update-db");
lf[202]=C_decode_literal(C_heaptop,"\376B\000\000\002-i");
lf[203]=C_decode_literal(C_heaptop,"\376B\000\000\005-init");
lf[204]=C_decode_literal(C_heaptop,"\376B\000\000\004copy");
lf[205]=C_decode_literal(C_heaptop,"\376B\000\000\005cp -r");
lf[206]=C_decode_literal(C_heaptop,"\376B\000\000\010~a ~a ~a");
lf[207]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\014setup-api.so\376\003\000\000\002\376B\000\000\023setup-api.import.so\376\003\000\000\002\376B\000\000\016setup-utils.so\376\003\000\000\002"
"\376B\000\000\025setup-utils.import.so\376\003\000\000\002\376B\000\000\021setup-download.so\376\003\000\000\002\376B\000\000\030setup-download.im"
"port.so\376\003\000\000\002\376B\000\000\021chicken.import.so\376\003\000\000\002\376B\000\000\021lolevel.import.so\376\003\000\000\002\376B\000\000\020srfi-1.im"
"port.so\376\003\000\000\002\376B\000\000\020srfi-4.import.so\376\003\000\000\002\376B\000\000\031data-structures.import.so\376\003\000\000\002\376B\000\000\017po"
"rts.import.so\376\003\000\000\002\376B\000\000\017files.import.so\376\003\000\000\002\376B\000\000\017posix.import.so\376\003\000\000\002\376B\000\000\021srfi-13"
".import.so\376\003\000\000\002\376B\000\000\021srfi-69.import.so\376\003\000\000\002\376B\000\000\020extras.import.so\376\003\000\000\002\376B\000\000\017regex.i"
"mport.so\376\003\000\000\002\376B\000\000\021srfi-14.import.so\376\003\000\000\002\376B\000\000\015tcp.import.so\376\003\000\000\002\376B\000\000\021foreign.impo"
"rt.so\376\003\000\000\002\376B\000\000\020scheme.import.so\376\003\000\000\002\376B\000\000\021srfi-18.import.so\376\003\000\000\002\376B\000\000\017utils.import"
".so\376\003\000\000\002\376B\000\000\015csi.import.so\376\003\000\000\002\376B\000\000\021irregex.import.so\376\003\000\000\002\376B\000\000\022compiler.import.s"
"o\376\377\016");
lf[208]=C_decode_literal(C_heaptop,"\376B\000\000\032copying required files to ");
lf[209]=C_decode_literal(C_heaptop,"\376B\000\000\004 ...");
lf[210]=C_decode_literal(C_heaptop,"\376B\000\000\005-test");
lf[211]=C_decode_literal(C_heaptop,"\376B\000\000\017-host-extension");
lf[212]=C_decode_literal(C_heaptop,"\376B\000\000\011-username");
lf[213]=C_decode_literal(C_heaptop,"\376B\000\000\011-password");
lf[214]=C_h_intern(&lf[214],17,"lset-intersection");
lf[215]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000h\376\003\000\000\002\376\377\012\000\000k\376\003\000\000\002\376\377\012\000\000l\376\003\000\000\002\376\377\012\000\000t\376\003\000\000\002\376\377\012\000\000s\376\003\000\000\002\376\377\012\000\000p\376\003\000\000\002\376\377\012\000\000r\376\003\000"
"\000\002\376\377\012\000\000n\376\003\000\000\002\376\377\012\000\000v\376\003\000\000\002\376\377\012\000\000i\376\003\000\000\002\376\377\012\000\000u\376\377\016");
lf[216]=C_h_intern(&lf[216],16,"\003sysstring->list");
lf[217]=C_h_intern(&lf[217],9,"substring");
lf[218]=C_decode_literal(C_heaptop,"\376B\000\000\005setup");
lf[219]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[220]=C_h_intern(&lf[220],18,"absolute-pathname\077");
lf[221]=C_h_intern(&lf[221],18,"pathname-directory");
lf[222]=C_decode_literal(C_heaptop,"\376B\000\000\014([^:]+):(.+)");
lf[223]=C_h_intern(&lf[223],18,"pathname-extension");
lf[224]=C_decode_literal(C_heaptop,"\376B\000\000\002-h");
lf[225]=C_decode_literal(C_heaptop,"\376B\000\000\006--help");
lf[226]=C_h_intern(&lf[226],9,"read-file");
lf[227]=C_decode_literal(C_heaptop,"\376B\000\000\016setup.defaults");
lf[228]=C_h_intern(&lf[228],12,"chicken-home");
lf[229]=C_h_intern(&lf[229],22,"command-line-arguments");
lf[230]=C_h_intern(&lf[230],17,"register-feature!");
lf[231]=C_h_intern(&lf[231],15,"chicken-install");
lf[232]=C_decode_literal(C_heaptop,"\376B\000\000\003csi");
lf[233]=C_h_intern(&lf[233],17,"\003syspeek-c-string");
lf[234]=C_decode_literal(C_heaptop,"\376B\000\000\003bin");
lf[235]=C_h_intern(&lf[235],6,"getenv");
lf[236]=C_decode_literal(C_heaptop,"\376B\000\000\016CHICKEN_PREFIX");
lf[237]=C_h_intern(&lf[237],11,"\003sysrequire");
lf[238]=C_h_intern(&lf[238],9,"setup-api");
lf[239]=C_h_intern(&lf[239],14,"setup-download");
C_register_lf2(lf,240,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_971,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k969 */
static void C_ccall f_971(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_971,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_974,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k972 in k969 */
static void C_ccall f_974(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_974,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_977,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k975 in k972 in k969 */
static void C_ccall f_977(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_977,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_980,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k978 in k975 in k972 in k969 */
static void C_ccall f_980(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_980,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_983,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_983(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_983,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_986,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_986(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_986,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_989,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_1_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_989(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_989,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_992,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_posix_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_992(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_992,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_995,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_995(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_995,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_998,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_utils_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_998(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_998,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1001,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_regex_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_1001(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1001,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1004,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_1004(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1004,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1007,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_1007(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1007,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1010,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_13_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_1010(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1010,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1013,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_files_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_1013(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1013,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1016,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#require */
((C_proc3)C_retrieve_symbol_proc(lf[237]))(3,*((C_word*)lf[237]+1),t2,lf[239]);}

/* k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_1016(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1016,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1019,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#require */
((C_proc3)C_retrieve_symbol_proc(lf[237]))(3,*((C_word*)lf[237]+1),t2,lf[238]);}

/* k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_1019(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1019,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1024,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 67   getenv */
((C_proc3)C_retrieve_symbol_proc(lf[235]))(3,*((C_word*)lf[235]+1),t2,lf[236]);}

/* k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_1024(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1024,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1027,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
/* chicken-install.scm: 68   make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[73]))(4,*((C_word*)lf[73]+1),t2,t1,lf[234]);}
else{
t3=t2;
f_1027(2,t3,C_SCHEME_FALSE);}}

/* k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_1027(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1027,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1030,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
t3=t2;
f_1030(2,t3,t1);}
else{
/* ##sys#peek-c-string */
t3=*((C_word*)lf[233]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_INSTALL_BIN_HOME),C_fix(0));}}

/* k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_1030(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1030,2,t0,t1);}
t2=C_mutate(&lf[0] /* (set! main#*program-path* ...) */,t1);
t3=lf[1] /* main#*keep* */ =C_SCHEME_FALSE;;
t4=lf[2] /* main#*force* */ =C_SCHEME_FALSE;;
t5=lf[3] /* main#*prefix* */ =C_SCHEME_FALSE;;
t6=lf[4] /* main#*host-extension* */ =C_SCHEME_FALSE;;
t7=lf[5] /* main#*run-tests* */ =C_SCHEME_FALSE;;
t8=lf[6] /* main#*retrieve-only* */ =C_SCHEME_FALSE;;
t9=lf[7] /* main#*no-install* */ =C_SCHEME_FALSE;;
t10=lf[8] /* main#*username* */ =C_SCHEME_FALSE;;
t11=lf[9] /* main#*password* */ =C_SCHEME_FALSE;;
t12=lf[10] /* main#*default-sources* */ =C_SCHEME_END_OF_LIST;;
t13=lf[11] /* main#*default-location* */ =C_SCHEME_FALSE;;
t14=C_mutate(&lf[12] /* (set! main#*default-transport* ...) */,lf[13]);
t15=C_mutate(&lf[14] /* (set! main#*windows-shell* ...) */,C_mk_bool(C_WINDOWS_SHELL));
t16=C_mutate(&lf[15] /* (set! main#constant218 ...) */,lf[16]);
t17=C_mutate(&lf[17] /* (set! main#ext-version ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1169,tmp=(C_word)a,a+=2,tmp));
t18=lf[26] /* main#*eggs+dirs+vers* */ =C_SCHEME_END_OF_LIST;;
t19=lf[27] /* main#*checked* */ =C_SCHEME_END_OF_LIST;;
t20=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1424,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t21=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3000,a[2]=t20,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 176  make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[73]))(4,*((C_word*)lf[73]+1),t21,C_retrieve2(lf[0],"main#*program-path*"),lf[232]);}

/* k2998 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_3000(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 176  setup-api#shellpath */
((C_proc3)C_retrieve_symbol_proc(lf[166]))(3,*((C_word*)lf[166]+1),((C_word*)t0)[2],t1);}

/* k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_1424(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1424,2,t0,t1);}
t2=C_mutate(&lf[28] /* (set! main#*csi* ...) */,t1);
t3=C_mutate(&lf[29] /* (set! main#retrieve ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1668,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate(&lf[105] /* (set! main#cleanup ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2035,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate(&lf[108] /* (set! main#$system ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2239,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate(&lf[113] /* (set! main#usage ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2261,tmp=(C_word)a,a+=2,tmp));
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2924,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 494  register-feature! */
((C_proc3)C_retrieve_symbol_proc(lf[230]))(3,*((C_word*)lf[230]+1),t7,lf[231]);}

/* k2922 in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_2924(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2924,2,t0,t1);}
t2=C_set_block_item(lf[116] /* compiler-macro-environment */,0,C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2928,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2937,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2939,tmp=(C_word)a,a+=2,tmp);
/* call-with-current-continuation */
((C_proc3)C_retrieve_proc(*((C_word*)lf[97]+1)))(3,*((C_word*)lf[97]+1),t4,t5);}

/* a2938 in k2922 in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_2939(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2939,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2945,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2967,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* with-exception-handler */
((C_proc4)C_retrieve_symbol_proc(lf[96]))(4,*((C_word*)lf[96]+1),t1,t3,t4);}

/* a2966 in a2938 in k2922 in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_2967(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2967,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2973,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2986,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a2985 in a2966 in a2938 in k2922 in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_2986(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_2986r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2986r(t0,t1,t2);}}

static void C_ccall f_2986r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2992,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* k889894 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a2991 in a2985 in a2966 in a2938 in k2922 in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_2992(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2992,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a2972 in a2966 in a2938 in k2922 in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_2973(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2973,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2977,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2984,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 502  command-line-arguments */
((C_proc2)C_retrieve_symbol_proc(lf[229]))(2,*((C_word*)lf[229]+1),t3);}

/* k2982 in a2972 in a2966 in a2938 in k2922 in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_2984(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2984,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2275,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1051,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1072,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 89   chicken-home */
((C_proc2)C_retrieve_symbol_proc(lf[228]))(2,*((C_word*)lf[228]+1),t4);}

/* k1070 in k2982 in a2972 in a2966 in a2938 in k2922 in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_1072(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 89   make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[73]))(4,*((C_word*)lf[73]+1),((C_word*)t0)[2],t1,lf[227]);}

/* k1049 in k2982 in a2972 in a2966 in a2938 in k2922 in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_1051(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1051,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1068,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm: 90   file-exists? */
((C_proc3)C_retrieve_symbol_proc(lf[72]))(3,*((C_word*)lf[72]+1),t2,t1);}

/* k1066 in k1049 in k2982 in a2972 in a2966 in a2938 in k2922 in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_1068(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1068,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1061,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 93   read-file */
((C_proc3)C_retrieve_symbol_proc(lf[226]))(3,*((C_word*)lf[226]+1),t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_2275(t2,C_SCHEME_END_OF_LIST);}}

/* k1059 in k1066 in k1049 in k2982 in a2972 in a2966 in a2938 in k2922 in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_1061(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[10] /* (set! main#*default-sources* ...) */,t1);
t3=((C_word*)t0)[2];
f_2275(t3,(C_word)C_i_pairp(C_retrieve2(lf[10],"main#*default-sources*")));}

/* k2273 in k2982 in a2972 in a2966 in a2938 in k2922 in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_fcall f_2275(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2275,NULL,2,t0,t1);}
t2=C_SCHEME_FALSE;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2280,a[2]=t5,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_2280(t7,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* loop in k2273 in k2982 in a2972 in a2966 in a2938 in k2922 in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_fcall f_2280(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2280,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t4=t1;
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2054,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2233,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2237,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 316  repository-path */
((C_proc2)C_retrieve_symbol_proc(lf[121]))(2,*((C_word*)lf[121]+1),t7);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2296,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2324,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 391  glob */
((C_proc3)C_retrieve_symbol_proc(lf[146]))(3,*((C_word*)lf[146]+1),t5,lf[181]);}
else{
t5=t4;
f_2296(2,t5,C_SCHEME_UNDEFINED);}}}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_string_equal_p(t4,lf[182]);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2370,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t2,a[6]=t4,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
if(C_truep(t5)){
t7=t6;
f_2370(t7,t5);}
else{
t7=(C_word)C_i_string_equal_p(t4,lf[224]);
t8=t6;
f_2370(t8,(C_truep(t7)?t7:(C_word)C_i_string_equal_p(t4,lf[225])));}}}

/* k2368 in loop in k2273 in k2982 in a2972 in a2966 in a2938 in k2922 in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_fcall f_2370(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2370,NULL,2,t0,t1);}
if(C_truep(t1)){
/* chicken-install.scm: 413  usage */
f_2261(((C_word*)t0)[7],C_fix(0));}
else{
if(C_truep((C_word)C_i_string_equal_p(((C_word*)t0)[6],lf[183]))){
t2=lf[2] /* main#*force* */ =C_SCHEME_TRUE;;
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* chicken-install.scm: 416  loop */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2280(t4,((C_word*)t0)[7],t3,((C_word*)t0)[3]);}
else{
t2=(C_word)C_i_string_equal_p(((C_word*)t0)[6],lf[184]);
t3=(C_truep(t2)?t2:(C_word)C_i_string_equal_p(((C_word*)t0)[6],lf[185]));
if(C_truep(t3)){
t4=lf[1] /* main#*keep* */ =C_SCHEME_TRUE;;
t5=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* chicken-install.scm: 419  loop */
t6=((C_word*)((C_word*)t0)[4])[1];
f_2280(t6,((C_word*)t0)[7],t5,((C_word*)t0)[3]);}
else{
t4=(C_word)C_i_string_equal_p(((C_word*)t0)[6],lf[186]);
t5=(C_truep(t4)?t4:(C_word)C_i_string_equal_p(((C_word*)t0)[6],lf[187]));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2416,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* chicken-install.scm: 421  setup-api#sudo-install */
((C_proc3)C_retrieve_symbol_proc(lf[170]))(3,*((C_word*)lf[170]+1),t6,C_SCHEME_TRUE);}
else{
t6=(C_word)C_i_string_equal_p(((C_word*)t0)[6],lf[188]);
t7=(C_truep(t6)?t6:(C_word)C_i_string_equal_p(((C_word*)t0)[6],lf[189]));
if(C_truep(t7)){
t8=lf[6] /* main#*retrieve-only* */ =C_SCHEME_TRUE;;
t9=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* chicken-install.scm: 425  loop */
t10=((C_word*)((C_word*)t0)[4])[1];
f_2280(t10,((C_word*)t0)[7],t9,((C_word*)t0)[3]);}
else{
t8=(C_word)C_i_string_equal_p(((C_word*)t0)[6],lf[190]);
t9=(C_truep(t8)?t8:(C_word)C_i_string_equal_p(((C_word*)t0)[6],lf[191]));
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2452,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t11=(C_word)C_i_cdr(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_pairp(t11))){
t12=t10;
f_2452(2,t12,C_SCHEME_UNDEFINED);}
else{
/* chicken-install.scm: 427  usage */
f_2261(t10,C_fix(1));}}
else{
t10=(C_word)C_i_string_equal_p(((C_word*)t0)[6],lf[192]);
t11=(C_truep(t10)?t10:(C_word)C_i_string_equal_p(((C_word*)t0)[6],lf[193]));
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2485,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t13=(C_word)C_i_cdr(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_pairp(t13))){
t14=t12;
f_2485(2,t14,C_SCHEME_UNDEFINED);}
else{
/* chicken-install.scm: 431  usage */
f_2261(t12,C_fix(1));}}
else{
t12=(C_word)C_i_string_equal_p(((C_word*)t0)[6],lf[194]);
t13=(C_truep(t12)?t12:(C_word)C_i_string_equal_p(((C_word*)t0)[6],lf[195]));
if(C_truep(t13)){
t14=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2522,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t15=(C_word)C_i_cdr(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_pairp(t15))){
t16=t14;
f_2522(2,t16,C_SCHEME_UNDEFINED);}
else{
/* chicken-install.scm: 435  usage */
f_2261(t14,C_fix(1));}}
else{
t14=(C_word)C_i_string_equal_p(((C_word*)t0)[6],lf[196]);
t15=(C_truep(t14)?t14:(C_word)C_i_string_equal_p(((C_word*)t0)[6],lf[197]));
if(C_truep(t15)){
t16=lf[1] /* main#*keep* */ =C_SCHEME_TRUE;;
t17=lf[7] /* main#*no-install* */ =C_SCHEME_TRUE;;
t18=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* chicken-install.scm: 441  loop */
t19=((C_word*)((C_word*)t0)[4])[1];
f_2280(t19,((C_word*)t0)[7],t18,((C_word*)t0)[3]);}
else{
t16=(C_word)C_i_string_equal_p(((C_word*)t0)[6],lf[198]);
t17=(C_truep(t16)?t16:(C_word)C_i_string_equal_p(((C_word*)t0)[6],lf[199]));
if(C_truep(t17)){
t18=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2573,a[2]=((C_word*)t0)[7],tmp=(C_word)a,a+=3,tmp);
t19=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2580,a[2]=t18,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 443  chicken-version */
((C_proc2)C_retrieve_symbol_proc(lf[19]))(2,*((C_word*)lf[19]+1),t19);}
else{
t18=(C_word)C_i_string_equal_p(((C_word*)t0)[6],lf[200]);
t19=(C_truep(t18)?t18:(C_word)C_i_string_equal_p(((C_word*)t0)[6],lf[201]));
if(C_truep(t19)){
t20=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_TRUE);
t21=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* chicken-install.scm: 447  loop */
t22=((C_word*)((C_word*)t0)[4])[1];
f_2280(t22,((C_word*)t0)[7],t21,((C_word*)t0)[3]);}
else{
t20=(C_word)C_i_string_equal_p(((C_word*)t0)[6],lf[202]);
t21=(C_truep(t20)?t20:(C_word)C_i_string_equal_p(((C_word*)t0)[6],lf[203]));
if(C_truep(t21)){
t22=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2609,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
t23=(C_word)C_i_cdr(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_pairp(t23))){
t24=t22;
f_2609(2,t24,C_SCHEME_UNDEFINED);}
else{
/* chicken-install.scm: 449  usage */
f_2261(t22,C_fix(1));}}
else{
if(C_truep((C_word)C_i_string_equal_p(lf[210],((C_word*)t0)[6]))){
t22=lf[5] /* main#*run-tests* */ =C_SCHEME_TRUE;;
t23=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* chicken-install.scm: 454  loop */
t24=((C_word*)((C_word*)t0)[4])[1];
f_2280(t24,((C_word*)t0)[7],t23,((C_word*)t0)[3]);}
else{
if(C_truep((C_word)C_i_string_equal_p(lf[211],((C_word*)t0)[6]))){
t22=lf[4] /* main#*host-extension* */ =C_SCHEME_TRUE;;
t23=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* chicken-install.scm: 457  loop */
t24=((C_word*)((C_word*)t0)[4])[1];
f_2280(t24,((C_word*)t0)[7],t23,((C_word*)t0)[3]);}
else{
if(C_truep((C_word)C_i_string_equal_p(lf[212],((C_word*)t0)[6]))){
t22=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2666,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t23=(C_word)C_i_cdr(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_pairp(t23))){
t24=t22;
f_2666(2,t24,C_SCHEME_UNDEFINED);}
else{
/* chicken-install.scm: 459  usage */
f_2261(t22,C_fix(1));}}
else{
if(C_truep((C_word)C_i_string_equal_p(lf[213],((C_word*)t0)[6]))){
t22=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2696,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t23=(C_word)C_i_cdr(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_pairp(t23))){
t24=t22;
f_2696(2,t24,C_SCHEME_UNDEFINED);}
else{
/* chicken-install.scm: 463  usage */
f_2261(t22,C_fix(1));}}
else{
t22=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2723,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t23=(C_word)C_i_string_length(((C_word*)t0)[6]);
if(C_truep((C_word)C_i_positivep(t23))){
t24=(C_word)C_i_string_ref(((C_word*)t0)[6],C_fix(0));
t25=t22;
f_2723(t25,(C_word)C_eqp(C_make_character(45),t24));}
else{
t24=t22;
f_2723(t24,C_SCHEME_FALSE);}}}}}}}}}}}}}}}}}}

/* k2721 in k2368 in loop in k2273 in k2982 in a2972 in a2966 in a2938 in k2922 in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_fcall f_2723(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2723,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_string_length(((C_word*)t0)[6]);
if(C_truep((C_word)C_i_greaterp(t2,C_fix(2)))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2732,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2770,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 469  substring */
((C_proc4)C_retrieve_proc(*((C_word*)lf[217]+1)))(4,*((C_word*)lf[217]+1),t4,((C_word*)t0)[6],C_fix(1));}
else{
/* chicken-install.scm: 473  usage */
f_2261(((C_word*)t0)[4],C_fix(1));}}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2868,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
/* chicken-install.scm: 474  pathname-extension */
((C_proc3)C_retrieve_symbol_proc(lf[223]))(3,*((C_word*)lf[223]+1),t2,((C_word*)t0)[6]);}}

/* k2866 in k2721 in k2368 in loop in k2273 in k2982 in a2972 in a2966 in a2938 in k2922 in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_2868(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2868,2,t0,t1);}
if(C_truep((C_word)C_i_equalp(lf[218],t1))){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2786,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* chicken-install.scm: 475  pathname-file */
((C_proc3)C_retrieve_symbol_proc(lf[179]))(3,*((C_word*)lf[179]+1),t2,((C_word*)t0)[2]);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2831,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* chicken-install.scm: 489  string-match */
((C_proc4)C_retrieve_symbol_proc(lf[141]))(4,*((C_word*)lf[141]+1),t2,lf[222],((C_word*)t0)[2]);}}

/* k2829 in k2866 in k2721 in k2368 in loop in k2273 in k2982 in a2972 in a2966 in a2938 in k2922 in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_2831(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2831,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2845,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_cadr(t1);
t5=(C_word)C_i_caddr(t1);
/* chicken-install.scm: 491  alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[31]))(5,*((C_word*)lf[31]+1),t3,t4,t5,((C_word*)t0)[3]);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[6]);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)t0)[3]);
/* chicken-install.scm: 492  loop */
t4=((C_word*)((C_word*)t0)[5])[1];
f_2280(t4,((C_word*)t0)[4],t2,t3);}}

/* k2843 in k2829 in k2866 in k2721 in k2368 in loop in k2273 in k2982 in a2972 in a2966 in a2938 in k2922 in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_2845(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 491  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_2280(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2784 in k2866 in k2721 in k2368 in loop in k2273 in k2982 in a2972 in a2966 in a2938 in k2922 in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_2786(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2786,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2790,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2809,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm: 480  pathname-directory */
((C_proc3)C_retrieve_symbol_proc(lf[221]))(3,*((C_word*)lf[221]+1),t3,((C_word*)t0)[2]);}

/* k2807 in k2784 in k2866 in k2721 in k2368 in loop in k2273 in k2982 in a2972 in a2966 in a2938 in k2922 in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_2809(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2809,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2812,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2818,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm: 482  absolute-pathname? */
((C_proc3)C_retrieve_symbol_proc(lf[220]))(3,*((C_word*)lf[220]+1),t3,t1);}
else{
/* chicken-install.scm: 485  current-directory */
((C_proc2)C_retrieve_symbol_proc(lf[95]))(2,*((C_word*)lf[95]+1),t2);}}

/* k2816 in k2807 in k2784 in k2866 in k2721 in k2368 in loop in k2273 in k2982 in a2972 in a2966 in a2938 in k2922 in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_2818(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2818,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_2812(2,t2,((C_word*)t0)[2]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2825,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm: 484  current-directory */
((C_proc2)C_retrieve_symbol_proc(lf[95]))(2,*((C_word*)lf[95]+1),t2);}}

/* k2823 in k2816 in k2807 in k2784 in k2866 in k2721 in k2368 in loop in k2273 in k2982 in a2972 in a2966 in a2938 in k2922 in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_2825(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 484  make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[73]))(4,*((C_word*)lf[73]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2810 in k2807 in k2784 in k2866 in k2721 in k2368 in loop in k2273 in k2982 in a2972 in a2966 in a2938 in k2922 in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_2812(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2812,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,lf[219]);
/* chicken-install.scm: 477  alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[31]))(5,*((C_word*)lf[31]+1),((C_word*)t0)[3],((C_word*)t0)[2],t2,C_retrieve2(lf[26],"main#*eggs+dirs+vers*"));}

/* k2788 in k2784 in k2866 in k2721 in k2368 in loop in k2273 in k2982 in a2972 in a2966 in a2938 in k2922 in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_2790(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2790,2,t0,t1);}
t2=C_mutate(&lf[26] /* (set! main#*eggs+dirs+vers* / ...) */,t1);
t3=(C_word)C_i_cdr(((C_word*)t0)[6]);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[4]);
/* chicken-install.scm: 488  loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_2280(t5,((C_word*)t0)[2],t3,t4);}

/* k2768 in k2721 in k2368 in loop in k2273 in k2982 in a2972 in a2966 in a2938 in k2922 in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_2770(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* string->list */
t2=C_retrieve(lf[216]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2730 in k2721 in k2368 in loop in k2273 in k2982 in a2972 in a2966 in a2938 in k2922 in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_2732(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2732,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2766,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* chicken-install.scm: 470  lset-intersection */
((C_proc5)C_retrieve_symbol_proc(lf[214]))(5,*((C_word*)lf[214]+1),t2,*((C_word*)lf[76]+1),lf[215],t1);}

/* k2764 in k2730 in k2721 in k2368 in loop in k2273 in k2982 in a2972 in a2966 in a2938 in k2922 in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_2766(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2766,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2745,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2749,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2755,tmp=(C_word)a,a+=2,tmp);
/* map */
t5=*((C_word*)lf[61]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}
else{
/* chicken-install.scm: 472  usage */
f_2261(((C_word*)t0)[5],C_fix(1));}}

/* a2754 in k2764 in k2730 in k2721 in k2368 in loop in k2273 in k2982 in a2972 in a2966 in a2938 in k2922 in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_2755(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2755,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_string(&a,2,C_make_character(45),t2));}

/* k2747 in k2764 in k2730 in k2721 in k2368 in loop in k2273 in k2982 in a2972 in a2966 in a2938 in k2922 in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_2749(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* chicken-install.scm: 471  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[38]+1)))(4,*((C_word*)lf[38]+1),((C_word*)t0)[2],t1,t2);}

/* k2743 in k2764 in k2730 in k2721 in k2368 in loop in k2273 in k2982 in a2972 in a2966 in a2938 in k2922 in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_2745(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 471  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_2280(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2694 in k2368 in loop in k2273 in k2982 in a2972 in a2966 in a2938 in k2922 in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_2696(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=C_mutate(&lf[9] /* (set! main#*password* ...) */,t2);
t4=(C_word)C_i_cddr(((C_word*)t0)[5]);
/* chicken-install.scm: 465  loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_2280(t5,((C_word*)t0)[3],t4,((C_word*)t0)[2]);}

/* k2664 in k2368 in loop in k2273 in k2982 in a2972 in a2966 in a2938 in k2922 in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_2666(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=C_mutate(&lf[8] /* (set! main#*username* ...) */,t2);
t4=(C_word)C_i_cddr(((C_word*)t0)[5]);
/* chicken-install.scm: 461  loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_2280(t5,((C_word*)t0)[3],t4,((C_word*)t0)[2]);}

/* k2607 in k2368 in loop in k2273 in k2982 in a2972 in a2966 in a2938 in k2922 in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_2609(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2609,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2612,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[2]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1136,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm: 111  repository-path */
((C_proc2)C_retrieve_symbol_proc(lf[121]))(2,*((C_word*)lf[121]+1),t4);}

/* k1134 in k2607 in k2368 in loop in k2273 in k2982 in a2972 in a2966 in a2938 in k2922 in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_1136(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1136,2,t0,t1);}
t2=(C_truep(C_retrieve2(lf[14],"main#*windows-shell*"))?lf[204]:lf[205]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1142,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken-install.scm: 115  print */
((C_proc5)C_retrieve_proc(*((C_word*)lf[41]+1)))(5,*((C_word*)lf[41]+1),t3,lf[208],((C_word*)t0)[3],lf[209]);}

/* k1140 in k1134 in k2607 in k2368 in loop in k2273 in k2982 in a2972 in a2966 in a2938 in k2922 in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_1142(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1142,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1147,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* for-each */
t3=*((C_word*)lf[44]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t2,lf[207]);}

/* a1146 in k1140 in k1134 in k2607 in k2368 in loop in k2273 in k2982 in a2972 in a2966 in a2938 in k2922 in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_1147(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1147,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1155,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1159,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1167,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 118  make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[73]))(4,*((C_word*)lf[73]+1),t5,((C_word*)t0)[2],t2);}

/* k1165 in a1146 in k1140 in k1134 in k2607 in k2368 in loop in k2273 in k2982 in a2972 in a2966 in a2938 in k2922 in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_1167(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 118  setup-api#shellpath */
((C_proc3)C_retrieve_symbol_proc(lf[166]))(3,*((C_word*)lf[166]+1),((C_word*)t0)[2],t1);}

/* k1157 in a1146 in k1140 in k1134 in k2607 in k2368 in loop in k2273 in k2982 in a2972 in a2966 in a2938 in k2922 in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_1159(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1159,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1163,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken-install.scm: 118  setup-api#shellpath */
((C_proc3)C_retrieve_symbol_proc(lf[166]))(3,*((C_word*)lf[166]+1),t2,((C_word*)t0)[2]);}

/* k1161 in k1157 in a1146 in k1140 in k1134 in k2607 in k2368 in loop in k2273 in k2982 in a2972 in a2966 in a2938 in k2922 in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_1163(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 118  sprintf */
((C_proc6)C_retrieve_symbol_proc(lf[149]))(6,*((C_word*)lf[149]+1),((C_word*)t0)[4],lf[206],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1153 in a1146 in k1140 in k1134 in k2607 in k2368 in loop in k2273 in k2982 in a2972 in a2966 in a2938 in k2922 in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_1155(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 118  $system */
f_2239(((C_word*)t0)[2],t1);}

/* k2610 in k2607 in k2368 in loop in k2273 in k2982 in a2972 in a2966 in a2938 in k2922 in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_2612(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 451  exit */
((C_proc3)C_retrieve_symbol_proc(lf[114]))(3,*((C_word*)lf[114]+1),((C_word*)t0)[2],C_fix(0));}

/* k2578 in k2368 in loop in k2273 in k2982 in a2972 in a2966 in a2938 in k2922 in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_2580(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 443  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[41]+1)))(3,*((C_word*)lf[41]+1),((C_word*)t0)[2],t1);}

/* k2571 in k2368 in loop in k2273 in k2982 in a2972 in a2966 in a2938 in k2922 in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_2573(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 444  exit */
((C_proc3)C_retrieve_symbol_proc(lf[114]))(3,*((C_word*)lf[114]+1),((C_word*)t0)[2],C_fix(0));}

/* k2520 in k2368 in loop in k2273 in k2982 in a2972 in a2966 in a2938 in k2922 in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_2522(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=C_mutate(&lf[3] /* (set! main#*prefix* ...) */,t2);
t4=(C_word)C_i_cddr(((C_word*)t0)[5]);
/* chicken-install.scm: 437  loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_2280(t5,((C_word*)t0)[3],t4,((C_word*)t0)[2]);}

/* k2483 in k2368 in loop in k2273 in k2982 in a2972 in a2966 in a2938 in k2922 in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_2485(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2485,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2489,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* chicken-install.scm: 432  string->symbol */
((C_proc3)C_retrieve_proc(*((C_word*)lf[140]+1)))(3,*((C_word*)lf[140]+1),t2,t3);}

/* k2487 in k2483 in k2368 in loop in k2273 in k2982 in a2972 in a2966 in a2938 in k2922 in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_2489(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(&lf[12] /* (set! main#*default-transport* ...) */,t1);
t3=(C_word)C_i_cddr(((C_word*)t0)[5]);
/* chicken-install.scm: 433  loop */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2280(t4,((C_word*)t0)[3],t3,((C_word*)t0)[2]);}

/* k2450 in k2368 in loop in k2273 in k2982 in a2972 in a2966 in a2938 in k2922 in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_2452(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=C_mutate(&lf[11] /* (set! main#*default-location* ...) */,t2);
t4=(C_word)C_i_cddr(((C_word*)t0)[5]);
/* chicken-install.scm: 429  loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_2280(t5,((C_word*)t0)[3],t4,((C_word*)t0)[2]);}

/* k2414 in k2368 in loop in k2273 in k2982 in a2972 in a2966 in a2938 in k2922 in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_2416(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* chicken-install.scm: 422  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2280(t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k2322 in loop in k2273 in k2982 in a2972 in a2966 in a2938 in k2922 in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_2324(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2324,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2334,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2338,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2340,tmp=(C_word)a,a+=2,tmp);
/* map */
t5=*((C_word*)lf[61]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2355,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 400  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[41]+1)))(3,*((C_word*)lf[41]+1),t2,lf[180]);}}

/* k2353 in k2322 in loop in k2273 in k2982 in a2972 in a2966 in a2938 in k2922 in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_2355(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 401  exit */
((C_proc3)C_retrieve_symbol_proc(lf[114]))(3,*((C_word*)lf[114]+1),((C_word*)t0)[2],C_fix(1));}

/* a2339 in k2322 in loop in k2273 in k2982 in a2972 in a2966 in a2938 in k2922 in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_2340(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2340,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2348,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 396  pathname-file */
((C_proc3)C_retrieve_symbol_proc(lf[179]))(3,*((C_word*)lf[179]+1),t3,t2);}

/* k2346 in a2339 in k2322 in loop in k2273 in k2982 in a2972 in a2966 in a2938 in k2922 in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_2348(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2348,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[177],lf[178]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,t1,t2));}

/* k2336 in k2322 in loop in k2273 in k2982 in a2972 in a2966 in a2938 in k2922 in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_2338(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 394  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[38]+1)))(4,*((C_word*)lf[38]+1),((C_word*)t0)[2],t1,C_retrieve2(lf[26],"main#*eggs+dirs+vers*"));}

/* k2332 in k2322 in loop in k2273 in k2982 in a2972 in a2966 in a2938 in k2922 in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_2334(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[26] /* (set! main#*eggs+dirs+vers* ...) */,t1);
t3=((C_word*)t0)[2];
f_2296(2,t3,t2);}

/* k2294 in loop in k2273 in k2982 in a2972 in a2966 in a2938 in k2922 in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_2296(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2296,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2299,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=t2;
f_2299(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2309,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[12],"main#*default-transport*"))){
t4=t3;
f_2309(2,t4,C_SCHEME_UNDEFINED);}
else{
/* chicken-install.scm: 404  error */
((C_proc3)C_retrieve_proc(*((C_word*)lf[98]+1)))(3,*((C_word*)lf[98]+1),t3,lf[176]);}}}

/* k2307 in k2294 in loop in k2273 in k2982 in a2972 in a2966 in a2938 in k2922 in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_2309(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(C_retrieve2(lf[11],"main#*default-location*"))){
t2=((C_word*)t0)[2];
f_2299(2,t2,C_SCHEME_UNDEFINED);}
else{
/* chicken-install.scm: 406  error */
((C_proc3)C_retrieve_proc(*((C_word*)lf[98]+1)))(3,*((C_word*)lf[98]+1),((C_word*)t0)[2],lf[175]);}}

/* k2297 in k2294 in loop in k2273 in k2982 in a2972 in a2966 in a2938 in k2922 in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_2299(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2299,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2306,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 407  reverse */
((C_proc3)C_retrieve_proc(*((C_word*)lf[30]+1)))(3,*((C_word*)lf[30]+1),t2,((C_word*)t0)[2]);}

/* k2304 in k2297 in k2294 in loop in k2273 in k2982 in a2972 in a2966 in a2938 in k2922 in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_2306(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2306,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1942,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 290  retrieve */
f_1668(t3,t1);}

/* k1940 in k2304 in k2297 in k2294 in loop in k2273 in k2982 in a2972 in a2966 in a2938 in k2922 in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_1942(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1942,2,t0,t1);}
if(C_truep(C_retrieve2(lf[6],"main#*retrieve-only*"))){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1950,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t3=*((C_word*)lf[44]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t2,C_retrieve2(lf[26],"main#*eggs+dirs+vers*"));}}

/* a1949 in k1940 in k2304 in k2297 in k2294 in loop in k2273 in k2982 in a2972 in a2966 in a2938 in k2922 in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_1950(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1950,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1954,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_caddr(t2);
/* chicken-install.scm: 294  print */
((C_proc7)C_retrieve_proc(*((C_word*)lf[41]+1)))(7,*((C_word*)lf[41]+1),t3,lf[173],t4,C_make_character(58),t5,lf[174]);}

/* k1952 in a1949 in k1940 in k2304 in k2297 in k2294 in loop in k2273 in k2982 in a2972 in a2966 in a2938 in k2922 in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_1954(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1954,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1957,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[3]);
/* chicken-install.scm: 295  print */
((C_proc4)C_retrieve_proc(*((C_word*)lf[41]+1)))(4,*((C_word*)lf[41]+1),t2,lf[172],t3);}

/* k1955 in k1952 in a1949 in k1940 in k2304 in k2297 in k2294 in loop in k2273 in k2982 in a2972 in a2966 in a2938 in k2922 in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_1957(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1957,2,t0,t1);}
t2=C_retrieve(lf[95]);
t3=(C_word)C_i_cadr(((C_word*)t0)[3]);
t4=t3;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1961,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1974,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* ##sys#dynamic-wind */
t8=*((C_word*)lf[142]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,((C_word*)t0)[2],t6,t7,t6);}

/* a1973 in k1955 in k1952 in a1949 in k1940 in k2304 in k2297 in k2294 in loop in k2273 in k2982 in a2972 in a2966 in a2938 in k2922 in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_1974(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1974,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1978,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[2];
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1886,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_car(t3);
t6=(C_word)C_i_caddr(t3);
/* chicken-install.scm: 281  sprintf */
((C_proc5)C_retrieve_symbol_proc(lf[149]))(5,*((C_word*)lf[149]+1),t4,lf[171],t5,t6);}

/* k1884 in a1973 in k1955 in k1952 in a1949 in k1940 in k2304 in k2297 in k2294 in loop in k2273 in k2982 in a2972 in a2966 in a2938 in k2922 in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_1886(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1886,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1928,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* chicken-install.scm: 282  setup-api#sudo-install */
((C_proc2)C_retrieve_symbol_proc(lf[170]))(2,*((C_word*)lf[170]+1),t2);}

/* k1926 in k1884 in a1973 in k1955 in k1952 in a1949 in k1940 in k2304 in k2297 in k2294 in loop in k2273 in k2982 in a2972 in a2966 in a2938 in k2922 in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_1928(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1928,2,t0,t1);}
t2=(C_truep(t1)?lf[157]:lf[158]);
t3=(C_truep(C_retrieve2(lf[1],"main#*keep*"))?lf[159]:lf[160]);
t4=(C_truep(C_retrieve2(lf[7],"main#*no-install*"))?lf[161]:lf[162]);
t5=(C_truep(C_retrieve2(lf[4],"main#*host-extension*"))?lf[163]:lf[164]);
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1906,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=t4,a[5]=t3,a[6]=t2,a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[4],tmp=(C_word)a,a+=9,tmp);
if(C_truep(C_retrieve2(lf[3],"main#*prefix*"))){
/* chicken-install.scm: 286  sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[149]))(4,*((C_word*)lf[149]+1),t6,lf[168],C_retrieve2(lf[3],"main#*prefix*"));}
else{
t7=t6;
f_1906(2,t7,lf[169]);}}

/* k1904 in k1926 in k1884 in a1973 in k1955 in k1952 in a1949 in k1940 in k2304 in k2297 in k2294 in loop in k2273 in k2982 in a2972 in a2966 in a2938 in k2922 in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_1906(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1906,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1910,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1914,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_cadr(((C_word*)t0)[2]);
t5=(C_word)C_i_car(((C_word*)t0)[2]);
/* chicken-install.scm: 287  make-pathname */
((C_proc5)C_retrieve_symbol_proc(lf[73]))(5,*((C_word*)lf[73]+1),t3,t4,t5,lf[167]);}

/* k1912 in k1904 in k1926 in k1884 in a1973 in k1955 in k1952 in a1949 in k1940 in k2304 in k2297 in k2294 in loop in k2273 in k2982 in a2972 in a2966 in a2938 in k2922 in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_1914(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 287  setup-api#shellpath */
((C_proc3)C_retrieve_symbol_proc(lf[166]))(3,*((C_word*)lf[166]+1),((C_word*)t0)[2],t1);}

/* k1908 in k1904 in k1926 in k1884 in a1973 in k1955 in k1952 in a1949 in k1940 in k2304 in k2297 in k2294 in loop in k2273 in k2982 in a2972 in a2966 in a2938 in k2922 in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_1910(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 278  conc */
((C_proc12)C_retrieve_symbol_proc(lf[56]))(12,*((C_word*)lf[56]+1),((C_word*)t0)[8],C_retrieve2(lf[28],"main#*csi*"),lf[165],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],C_make_character(32),t1);}

/* k1976 in a1973 in k1955 in k1952 in a1949 in k1940 in k2304 in k2297 in k2294 in loop in k2273 in k2982 in a2972 in a2966 in a2938 in k2922 in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_1978(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1978,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1981,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* chicken-install.scm: 298  print */
((C_proc4)C_retrieve_proc(*((C_word*)lf[41]+1)))(4,*((C_word*)lf[41]+1),t2,lf[156],t1);}

/* k1979 in k1976 in a1973 in k1955 in k1952 in a1949 in k1940 in k2304 in k2297 in k2294 in loop in k2273 in k2982 in a2972 in a2966 in a2938 in k2922 in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_1981(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1981,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1984,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm: 299  $system */
f_2239(t2,((C_word*)t0)[2]);}

/* k1982 in k1979 in k1976 in a1973 in k1955 in k1952 in a1949 in k1940 in k2304 in k2297 in k2294 in loop in k2273 in k2982 in a2972 in a2966 in a2938 in k2922 in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_1984(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1984,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1990,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[5],"main#*run-tests*"))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2012,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 301  file-exists? */
((C_proc3)C_retrieve_symbol_proc(lf[72]))(3,*((C_word*)lf[72]+1),t3,lf[155]);}
else{
t3=t2;
f_1990(2,t3,C_SCHEME_FALSE);}}

/* k2010 in k1982 in k1979 in k1976 in a1973 in k1955 in k1952 in a1949 in k1940 in k2304 in k2297 in k2294 in loop in k2273 in k2982 in a2972 in a2966 in a2938 in k2922 in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_2012(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2012,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2018,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 302  directory? */
((C_proc3)C_retrieve_symbol_proc(lf[153]))(3,*((C_word*)lf[153]+1),t2,lf[154]);}
else{
t2=((C_word*)t0)[2];
f_1990(2,t2,C_SCHEME_FALSE);}}

/* k2016 in k2010 in k1982 in k1979 in k1976 in a1973 in k1955 in k1952 in a1949 in k1940 in k2304 in k2297 in k2294 in loop in k2273 in k2982 in a2972 in a2966 in a2938 in k2922 in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_2018(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* chicken-install.scm: 303  file-exists? */
((C_proc3)C_retrieve_symbol_proc(lf[72]))(3,*((C_word*)lf[72]+1),((C_word*)t0)[2],lf[152]);}
else{
t2=((C_word*)t0)[2];
f_1990(2,t2,C_SCHEME_FALSE);}}

/* k1988 in k1982 in k1979 in k1976 in a1973 in k1955 in k1952 in a1949 in k1940 in k2304 in k2297 in k2294 in loop in k2273 in k2982 in a2972 in a2966 in a2938 in k2922 in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_1990(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1990,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1993,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm: 304  current-directory */
((C_proc3)C_retrieve_symbol_proc(lf[95]))(3,*((C_word*)lf[95]+1),t2,lf[151]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k1991 in k1988 in k1982 in k1979 in k1976 in a1973 in k1955 in k1952 in a1949 in k1940 in k2304 in k2297 in k2294 in loop in k2273 in k2982 in a2972 in a2966 in a2938 in k2922 in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_1993(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1993,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1996,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[2]);
/* chicken-install.scm: 305  sprintf */
((C_proc5)C_retrieve_symbol_proc(lf[149]))(5,*((C_word*)lf[149]+1),t2,lf[150],C_retrieve2(lf[28],"main#*csi*"),t3);}

/* k1994 in k1991 in k1988 in k1982 in k1979 in k1976 in a1973 in k1955 in k1952 in a1949 in k1940 in k2304 in k2297 in k2294 in loop in k2273 in k2982 in a2972 in a2966 in a2938 in k2922 in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_1996(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1996,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1999,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm: 306  print */
((C_proc4)C_retrieve_proc(*((C_word*)lf[41]+1)))(4,*((C_word*)lf[41]+1),t2,lf[148],t1);}

/* k1997 in k1994 in k1991 in k1988 in k1982 in k1979 in k1976 in a1973 in k1955 in k1952 in a1949 in k1940 in k2304 in k2297 in k2294 in loop in k2273 in k2982 in a2972 in a2966 in a2938 in k2922 in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_1999(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 307  $system */
f_2239(((C_word*)t0)[3],((C_word*)t0)[2]);}

/* swap563 in k1955 in k1952 in a1949 in k1940 in k2304 in k2297 in k2294 in loop in k2273 in k2982 in a2972 in a2966 in a2938 in k2922 in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_1961(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1961,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1965,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* g566567570 */
t3=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k1963 in swap563 in k1955 in k1952 in a1949 in k1940 in k2304 in k2297 in k2294 in loop in k2273 in k2982 in a2972 in a2966 in a2938 in k2922 in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_1965(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1965,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1968,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* g566567570 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)((C_word*)t0)[4])[1]);}

/* k1966 in k1963 in swap563 in k1955 in k1952 in a1949 in k1940 in k2304 in k2297 in k2294 in loop in k2273 in k2982 in a2972 in a2966 in a2938 in k2922 in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_1968(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2235 in loop in k2273 in k2982 in a2972 in a2966 in a2938 in k2922 in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_2237(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 316  make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[73]))(4,*((C_word*)lf[73]+1),((C_word*)t0)[2],t1,lf[147]);}

/* k2231 in loop in k2273 in k2982 in a2972 in a2966 in a2938 in k2922 in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_2233(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 316  glob */
((C_proc3)C_retrieve_symbol_proc(lf[146]))(3,*((C_word*)lf[146]+1),((C_word*)t0)[2],t1);}

/* k2052 in loop in k2273 in k2982 in a2972 in a2966 in a2938 in k2922 in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_2054(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2054,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2057,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm: 317  setup-api#create-temporary-directory */
((C_proc2)C_retrieve_symbol_proc(lf[145]))(2,*((C_word*)lf[145]+1),t2);}

/* k2055 in k2052 in loop in k2273 in k2982 in a2972 in a2966 in a2938 in k2922 in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_2057(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2057,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2060,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* chicken-install.scm: 318  make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[73]))(4,*((C_word*)lf[73]+1),t2,t1,C_retrieve2(lf[15],"main#constant218"));}

/* k2058 in k2055 in k2052 in loop in k2273 in k2982 in a2972 in a2966 in a2938 in k2922 in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_2060(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2060,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2063,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* chicken-install.scm: 319  regexp */
((C_proc3)C_retrieve_symbol_proc(lf[143]))(3,*((C_word*)lf[143]+1),t2,lf[144]);}

/* k2061 in k2058 in k2055 in k2052 in loop in k2273 in k2982 in a2972 in a2966 in a2938 in k2922 in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_2063(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[21],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2063,2,t0,t1);}
t2=C_SCHEME_FALSE;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2066,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2190,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2195,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2226,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* ##sys#dynamic-wind */
t10=*((C_word*)lf[142]+1);
((C_proc5)(void*)(*((C_word*)t10+1)))(5,t10,t6,t7,t8,t9);}

/* a2225 in k2061 in k2058 in k2055 in k2052 in loop in k2273 in k2982 in a2972 in a2966 in a2938 in k2922 in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_2226(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2226,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,C_retrieve(lf[137]));
t3=C_mutate((C_word*)lf[137]+1 /* (set! warnings-enabled ...) */,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* a2194 in k2061 in k2058 in k2055 in k2052 in loop in k2273 in k2982 in a2972 in a2966 in a2938 in k2922 in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_2195(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2195,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2201,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* for-each */
t3=*((C_word*)lf[44]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,((C_word*)t0)[2]);}

/* a2200 in a2194 in k2061 in k2058 in k2055 in k2052 in loop in k2273 in k2982 in a2972 in a2966 in a2938 in k2922 in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_2201(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2201,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2205,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 323  string-match */
((C_proc4)C_retrieve_symbol_proc(lf[141]))(4,*((C_word*)lf[141]+1),t3,((C_word*)t0)[2],t2);}

/* k2203 in a2200 in a2194 in k2061 in k2058 in k2055 in k2052 in loop in k2273 in k2982 in a2972 in a2966 in a2938 in k2922 in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_2205(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2205,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2220,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cadr(t1);
/* chicken-install.scm: 324  string->symbol */
((C_proc3)C_retrieve_proc(*((C_word*)lf[140]+1)))(3,*((C_word*)lf[140]+1),t2,t3);}

/* k2218 in k2203 in a2200 in a2194 in k2061 in k2058 in k2055 in k2052 in loop in k2273 in k2982 in a2972 in a2966 in a2938 in k2922 in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_2220(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2220,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[138],t2);
/* chicken-install.scm: 324  eval */
((C_proc3)C_retrieve_symbol_proc(lf[139]))(3,*((C_word*)lf[139]+1),((C_word*)t0)[2],t3);}

/* a2189 in k2061 in k2058 in k2055 in k2052 in loop in k2273 in k2982 in a2972 in a2966 in a2938 in k2922 in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_2190(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2190,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,C_retrieve(lf[137]));
t3=C_mutate((C_word*)lf[137]+1 /* (set! warnings-enabled ...) */,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* k2064 in k2061 in k2058 in k2055 in k2052 in loop in k2273 in k2982 in a2972 in a2966 in a2938 in k2922 in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_2066(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2066,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2069,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken-install.scm: 326  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[41]+1)))(3,*((C_word*)lf[41]+1),t2,lf[136]);}

/* k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in loop in k2273 in k2982 in a2972 in a2966 in a2938 in k2922 in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_2069(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2069,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2072,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2111,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2135,tmp=(C_word)a,a+=2,tmp);
/* chicken-install.scm: 329  append-map */
((C_proc4)C_retrieve_symbol_proc(lf[134]))(4,*((C_word*)lf[134]+1),t3,t4,C_retrieve(lf[135]));}

/* a2134 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in loop in k2273 in k2982 in a2972 in a2966 in a2938 in k2922 in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_2135(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2135,3,t0,t1,t2);}
t3=(C_word)C_i_cdr(t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2142,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm: 332  ##sys#module-name */
((C_proc3)C_retrieve_symbol_proc(lf[133]))(3,*((C_word*)lf[133]+1),t4,t3);}

/* k2140 in a2134 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in loop in k2273 in k2982 in a2972 in a2966 in a2938 in k2922 in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_2142(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2142,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2145,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* chicken-install.scm: 333  print* */
((C_proc4)C_retrieve_proc(*((C_word*)lf[131]+1)))(4,*((C_word*)lf[131]+1),t2,lf[132],t1);}

/* k2143 in k2140 in a2134 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in loop in k2273 in k2982 in a2972 in a2966 in a2938 in k2922 in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_2145(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2145,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2150,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2156,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a2155 in k2143 in k2140 in a2134 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in loop in k2273 in k2982 in a2972 in a2966 in a2938 in k2922 in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_2156(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2156,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2164,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2180,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* map */
t7=*((C_word*)lf[61]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,t4);}

/* a2179 in a2155 in k2143 in k2140 in a2134 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in loop in k2273 in k2982 in a2972 in a2966 in a2938 in k2922 in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_2180(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2180,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,t3,lf[130],((C_word*)t0)[2]));}

/* k2162 in a2155 in k2143 in k2140 in a2134 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in loop in k2273 in k2982 in a2972 in a2966 in a2938 in k2922 in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_2164(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2164,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2168,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2170,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* map */
t4=*((C_word*)lf[61]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a2169 in k2162 in a2155 in k2143 in k2140 in a2134 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in loop in k2273 in k2982 in a2972 in a2966 in a2938 in k2922 in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_2170(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2170,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,t3,lf[129],((C_word*)t0)[2]));}

/* k2166 in k2162 in a2155 in k2143 in k2140 in a2134 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in loop in k2273 in k2982 in a2972 in a2966 in a2938 in k2922 in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_2168(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 335  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[38]+1)))(4,*((C_word*)lf[38]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2149 in k2143 in k2140 in a2134 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in loop in k2273 in k2982 in a2972 in a2966 in a2938 in k2922 in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_2150(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2150,2,t0,t1);}
/* chicken-install.scm: 334  ##sys#module-exports */
((C_proc3)C_retrieve_symbol_proc(lf[128]))(3,*((C_word*)lf[128]+1),t1,((C_word*)t0)[2]);}

/* k2109 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in loop in k2273 in k2982 in a2972 in a2966 in a2938 in k2922 in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_2111(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2111,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2113,tmp=(C_word)a,a+=2,tmp);
/* chicken-install.scm: 328  sort */
((C_proc4)C_retrieve_symbol_proc(lf[127]))(4,*((C_word*)lf[127]+1),((C_word*)t0)[2],t1,t2);}

/* a2112 in k2109 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in loop in k2273 in k2982 in a2972 in a2966 in a2938 in k2922 in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_2113(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2113,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2121,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_car(t2);
/* chicken-install.scm: 340  symbol->string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[126]+1)))(3,*((C_word*)lf[126]+1),t4,t5);}

/* k2119 in a2112 in k2109 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in loop in k2273 in k2982 in a2972 in a2966 in a2938 in k2922 in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_2121(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2121,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2125,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[2]);
/* chicken-install.scm: 340  symbol->string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[126]+1)))(3,*((C_word*)lf[126]+1),t2,t3);}

/* k2123 in k2119 in a2112 in k2109 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in loop in k2273 in k2982 in a2972 in a2966 in a2938 in k2922 in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_2125(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 340  string<? */
((C_proc4)C_retrieve_proc(*((C_word*)lf[125]+1)))(4,*((C_word*)lf[125]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in loop in k2273 in k2982 in a2972 in a2966 in a2938 in k2922 in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_2072(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2072,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2075,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* chicken-install.scm: 341  newline */
((C_proc2)C_retrieve_proc(*((C_word*)lf[122]+1)))(2,*((C_word*)lf[122]+1),t2);}

/* k2073 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in loop in k2273 in k2982 in a2972 in a2966 in a2938 in k2922 in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_2075(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2075,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2078,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2094,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 342  with-output-to-file */
((C_proc4)C_retrieve_symbol_proc(lf[124]))(4,*((C_word*)lf[124]+1),t2,((C_word*)t0)[3],t3);}

/* a2093 in k2073 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in loop in k2273 in k2982 in a2972 in a2966 in a2938 in k2922 in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_2094(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2094,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2100,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t3=*((C_word*)lf[44]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,((C_word*)t0)[2]);}

/* a2099 in a2093 in k2073 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in loop in k2273 in k2982 in a2972 in a2966 in a2938 in k2922 in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_2100(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2100,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2104,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 344  write */
((C_proc3)C_retrieve_proc(*((C_word*)lf[123]+1)))(3,*((C_word*)lf[123]+1),t3,t2);}

/* k2102 in a2099 in a2093 in k2073 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in loop in k2273 in k2982 in a2972 in a2966 in a2938 in k2922 in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_2104(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 344  newline */
((C_proc2)C_retrieve_proc(*((C_word*)lf[122]+1)))(2,*((C_word*)lf[122]+1),((C_word*)t0)[2]);}

/* k2076 in k2073 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in loop in k2273 in k2982 in a2972 in a2966 in a2938 in k2922 in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_2078(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2078,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2081,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2088,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2092,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 345  repository-path */
((C_proc2)C_retrieve_symbol_proc(lf[121]))(2,*((C_word*)lf[121]+1),t4);}

/* k2090 in k2076 in k2073 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in loop in k2273 in k2982 in a2972 in a2966 in a2938 in k2922 in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_2092(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 345  make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[73]))(4,*((C_word*)lf[73]+1),((C_word*)t0)[2],t1,C_retrieve2(lf[15],"main#constant218"));}

/* k2086 in k2076 in k2073 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in loop in k2273 in k2982 in a2972 in a2966 in a2938 in k2922 in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_2088(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 345  setup-api#copy-file */
((C_proc4)C_retrieve_symbol_proc(lf[120]))(4,*((C_word*)lf[120]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2079 in k2076 in k2073 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in loop in k2273 in k2982 in a2972 in a2966 in a2938 in k2922 in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_2081(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 346  setup-api#remove-directory */
((C_proc3)C_retrieve_symbol_proc(lf[106]))(3,*((C_word*)lf[106]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2975 in a2972 in a2966 in a2938 in k2922 in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_2977(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 503  cleanup */
f_2035(((C_word*)t0)[2]);}

/* a2944 in a2938 in k2922 in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_2945(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2945,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2951,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* k889894 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a2950 in a2944 in a2938 in k2922 in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_2951(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2951,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2955,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2965,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm: 499  current-error-port */
((C_proc2)C_retrieve_symbol_proc(lf[119]))(2,*((C_word*)lf[119]+1),t3);}

/* k2963 in a2950 in a2944 in a2938 in k2922 in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_2965(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 499  print-error-message */
((C_proc4)C_retrieve_symbol_proc(lf[118]))(4,*((C_word*)lf[118]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2953 in a2950 in a2944 in a2938 in k2922 in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_2955(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2955,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2958,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 500  cleanup */
f_2035(t2);}

/* k2956 in k2953 in a2950 in a2944 in a2938 in k2922 in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_2958(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 501  exit */
((C_proc3)C_retrieve_symbol_proc(lf[114]))(3,*((C_word*)lf[114]+1),((C_word*)t0)[2],C_fix(1));}

/* k2935 in k2922 in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_2937(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k2926 in k2922 in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_2928(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2928,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2931,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2934,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#implicit-exit-handler */
((C_proc2)C_retrieve_symbol_proc(lf[117]))(2,*((C_word*)lf[117]+1),t3);}

/* k2932 in k2926 in k2922 in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_2934(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k2929 in k2926 in k2922 in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_2931(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* main#usage in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_fcall f_2261(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2261,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2265,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm: 357  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[41]+1)))(3,*((C_word*)lf[41]+1),t3,lf[115]);}

/* k2263 in main#usage in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_2265(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 378  exit */
((C_proc3)C_retrieve_symbol_proc(lf[114]))(3,*((C_word*)lf[114]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* main#$system in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_fcall f_2239(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2239,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2243,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2256,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[14],"main#*windows-shell*"))){
/* chicken-install.scm: 351  string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[68]+1)))(5,*((C_word*)lf[68]+1),t4,lf[111],t2,lf[112]);}
else{
t5=t4;
f_2256(2,t5,t2);}}

/* k2254 in main#$system in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_2256(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 349  system */
((C_proc3)C_retrieve_symbol_proc(lf[110]))(3,*((C_word*)lf[110]+1),((C_word*)t0)[2],t1);}

/* k2241 in main#$system in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_2243(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_zerop(t1))){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
/* chicken-install.scm: 354  error */
((C_proc5)C_retrieve_proc(*((C_word*)lf[98]+1)))(5,*((C_word*)lf[98]+1),((C_word*)t0)[3],lf[109],t1,((C_word*)t0)[2]);}}

/* main#cleanup in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_fcall f_2035(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2035,NULL,1,t1);}
if(C_truep(C_retrieve2(lf[1],"main#*keep*"))){
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2042,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 312  setup-download#temporary-directory */
((C_proc2)C_retrieve_symbol_proc(lf[107]))(2,*((C_word*)lf[107]+1),t2);}}

/* k2040 in main#cleanup in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_2042(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* chicken-install.scm: 313  setup-api#remove-directory */
((C_proc3)C_retrieve_symbol_proc(lf[106]))(3,*((C_word*)lf[106]+1),((C_word*)t0)[2],t1);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* main#retrieve in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_fcall f_1668(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1668,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1672,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm: 229  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[41]+1)))(3,*((C_word*)lf[41]+1),t3,lf[104]);}

/* k1670 in main#retrieve in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_1672(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1672,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1675,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1814,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[44]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a1813 in k1670 in main#retrieve in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_1814(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1814,3,t0,t1,t2);}
t3=(C_word)C_i_assoc(t2,C_retrieve2(lf[26],"main#*eggs+dirs+vers*"));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1829,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm: 235  delete */
((C_proc5)C_retrieve_symbol_proc(lf[75]))(5,*((C_word*)lf[75]+1),t4,t3,C_retrieve2(lf[26],"main#*eggs+dirs+vers*"),*((C_word*)lf[76]+1));}
else{
t4=(C_word)C_i_pairp(t2);
t5=(C_truep(t4)?(C_word)C_i_car(t2):t2);
t6=(C_word)C_i_pairp(t2);
t7=(C_truep(t6)?(C_word)C_i_cdr(t2):C_SCHEME_FALSE);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1840,a[2]=t7,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1846,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t8,t9);}}

/* a1845 in a1813 in k1670 in main#retrieve in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_1846(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1846,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1850,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t5=t4;
f_1850(2,t5,C_SCHEME_UNDEFINED);}
else{
/* chicken-install.scm: 240  error */
((C_proc3)C_retrieve_proc(*((C_word*)lf[98]+1)))(3,*((C_word*)lf[98]+1),t4,lf[103]);}}

/* k1848 in a1845 in a1813 in k1670 in main#retrieve in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_1850(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1850,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1853,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* chicken-install.scm: 241  print */
((C_proc6)C_retrieve_proc(*((C_word*)lf[41]+1)))(6,*((C_word*)lf[41]+1),t2,lf[101],((C_word*)t0)[2],lf[102],((C_word*)t0)[4]);}

/* k1851 in k1848 in a1845 in a1813 in k1670 in main#retrieve in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_1853(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1853,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1857,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],((C_word*)t0)[3]);
/* chicken-install.scm: 242  alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[31]))(5,*((C_word*)lf[31]+1),t2,((C_word*)t0)[2],t3,C_retrieve2(lf[26],"main#*eggs+dirs+vers*"));}

/* k1855 in k1851 in k1848 in a1845 in a1813 in k1670 in main#retrieve in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_1857(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[26] /* (set! main#*eggs+dirs+vers* ...) */,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* a1839 in a1813 in k1670 in main#retrieve in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_1840(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[26],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1840,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1543,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=(C_truep(C_retrieve2(lf[11],"main#*default-location*"))?C_retrieve2(lf[12],"main#*default-transport*"):C_SCHEME_FALSE);
if(C_truep(t3)){
t4=(C_word)C_a_i_cons(&a,2,C_retrieve2(lf[11],"main#*default-location*"),C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[78],t4);
t6=(C_word)C_a_i_cons(&a,2,C_retrieve2(lf[12],"main#*default-transport*"),C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,lf[79],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,t5,t8);
t10=t2;
f_1543(t10,(C_word)C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST));}
else{
t4=t2;
f_1543(t4,C_retrieve2(lf[10],"main#*default-sources*"));}}

/* k1541 in a1839 in a1813 in k1670 in main#retrieve in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_fcall f_1543(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1543,NULL,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1545,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_1545(t5,((C_word*)t0)[2],t1);}

/* trying-sources in k1541 in a1839 in a1813 in k1670 in main#retrieve in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_fcall f_1545(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1545,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
/* chicken-install.scm: 199  values */
C_values(4,0,t1,C_SCHEME_FALSE,lf[77]);}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_assq(lf[78],t3);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1609,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t3,tmp=(C_word)a,a+=8,tmp);
if(C_truep(t4)){
t6=t5;
f_1609(2,t6,t4);}
else{
/* chicken-install.scm: 202  error */
((C_proc4)C_retrieve_proc(*((C_word*)lf[98]+1)))(4,*((C_word*)lf[98]+1),t5,lf[100],t3);}}}

/* k1607 in trying-sources in k1541 in a1839 in a1813 in k1670 in main#retrieve in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_1609(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1609,2,t0,t1);}
t2=(C_word)C_i_cadr(t1);
t3=(C_word)C_i_assq(lf[79],((C_word*)t0)[7]);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1599,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t2,a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t3)){
t5=t4;
f_1599(2,t5,t3);}
else{
/* chicken-install.scm: 204  error */
((C_proc4)C_retrieve_proc(*((C_word*)lf[98]+1)))(4,*((C_word*)lf[98]+1),t4,lf[99],((C_word*)t0)[7]);}}

/* k1597 in k1607 in trying-sources in k1541 in a1839 in a1813 in k1670 in main#retrieve in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_1599(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1599,2,t0,t1);}
t2=(C_word)C_i_cadr(t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1569,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t2,a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1575,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t3,t4);}

/* a1574 in k1597 in k1607 in trying-sources in k1541 in a1839 in a1813 in k1670 in main#retrieve in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_1575(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1575,4,t0,t1,t2,t3);}
if(C_truep(t2)){
/* chicken-install.scm: 207  values */
C_values(4,0,t1,t2,t3);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1115,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken-install.scm: 103  delete */
((C_proc5)C_retrieve_symbol_proc(lf[75]))(5,*((C_word*)lf[75]+1),t4,((C_word*)t0)[2],C_retrieve2(lf[10],"main#*default-sources*"),*((C_word*)lf[76]+1));}}

/* k1113 in a1574 in k1597 in k1607 in trying-sources in k1541 in a1839 in a1813 in k1670 in main#retrieve in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_1115(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(&lf[10] /* (set! main#*default-sources* ...) */,t1);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* chicken-install.scm: 210  trying-sources */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1545(t4,((C_word*)t0)[2],t3);}

/* a1568 in k1597 in k1607 in trying-sources in k1541 in a1839 in a1813 in k1670 in main#retrieve in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_1569(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1569,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1433,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1435,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* call-with-current-continuation */
((C_proc3)C_retrieve_proc(*((C_word*)lf[97]+1)))(3,*((C_word*)lf[97]+1),t2,t3);}

/* a1434 in a1568 in k1597 in k1607 in trying-sources in k1541 in a1839 in a1813 in k1670 in main#retrieve in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_1435(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1435,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1441,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1504,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* with-exception-handler */
((C_proc4)C_retrieve_symbol_proc(lf[96]))(4,*((C_word*)lf[96]+1),t1,t3,t4);}

/* a1503 in a1434 in a1568 in k1597 in k1607 in trying-sources in k1541 in a1839 in a1813 in k1670 in main#retrieve in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_1504(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1504,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1510,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1523,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a1522 in a1503 in a1434 in a1568 in k1597 in k1607 in trying-sources in k1541 in a1839 in a1813 in k1670 in main#retrieve in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_1523(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_1523r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1523r(t0,t1,t2);}}

static void C_ccall f_1523r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1529,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* k363369 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a1528 in a1522 in a1503 in a1434 in a1568 in k1597 in k1607 in trying-sources in k1541 in a1839 in a1813 in k1670 in main#retrieve in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_1529(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1529,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a1509 in a1503 in a1434 in a1568 in k1597 in k1607 in trying-sources in k1541 in a1839 in a1813 in k1670 in main#retrieve in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_1510(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1510,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1518,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(C_retrieve2(lf[6],"main#*retrieve-only*"))){
/* chicken-install.scm: 183  current-directory */
((C_proc2)C_retrieve_symbol_proc(lf[95]))(2,*((C_word*)lf[95]+1),t2);}
else{
t3=t2;
f_1518(2,t3,C_SCHEME_FALSE);}}

/* k1516 in a1509 in a1503 in a1434 in a1568 in k1597 in k1607 in trying-sources in k1541 in a1839 in a1813 in k1670 in main#retrieve in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_1518(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 180  setup-download#retrieve-extension */
((C_proc15)C_retrieve_symbol_proc(lf[89]))(15,*((C_word*)lf[89]+1),((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],lf[90],((C_word*)t0)[2],lf[91],t1,lf[92],C_retrieve2(lf[5],"main#*run-tests*"),lf[93],C_retrieve2(lf[8],"main#*username*"),lf[94],C_retrieve2(lf[9],"main#*password*"));}

/* a1440 in a1434 in a1568 in k1597 in k1607 in trying-sources in k1541 in a1839 in a1813 in k1670 in main#retrieve in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_1441(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1441,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1447,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* k363369 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a1446 in a1440 in a1434 in a1568 in k1597 in k1607 in trying-sources in k1541 in a1839 in a1813 in k1670 in main#retrieve in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_1447(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1447,2,t0,t1);}
t2=(C_word)C_i_structurep(((C_word*)t0)[2],lf[80]);
t3=(C_truep(t2)?(C_word)C_slot(((C_word*)t0)[2],C_fix(1)):C_SCHEME_FALSE);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1457,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t3)){
t5=(C_word)C_i_memv(lf[86],t3);
t6=t4;
f_1457(t6,(C_truep(t5)?(C_word)C_i_memv(lf[88],t3):C_SCHEME_FALSE));}
else{
t5=t4;
f_1457(t5,C_SCHEME_FALSE);}}

/* k1455 in a1446 in a1440 in a1434 in a1568 in k1597 in k1607 in trying-sources in k1541 in a1839 in a1813 in k1670 in main#retrieve in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_fcall f_1457(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1457,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1460,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 188  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[41]+1)))(3,*((C_word*)lf[41]+1),t2,lf[82]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1469,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(C_word)C_i_memv(lf[86],((C_word*)t0)[2]);
t4=t2;
f_1469(t4,(C_truep(t3)?(C_word)C_i_memv(lf[87],((C_word*)t0)[2]):C_SCHEME_FALSE));}
else{
t3=t2;
f_1469(t3,C_SCHEME_FALSE);}}}

/* k1467 in k1455 in a1446 in a1440 in a1434 in a1568 in k1597 in k1607 in trying-sources in k1541 in a1839 in a1813 in k1670 in main#retrieve in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_fcall f_1469(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1469,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1472,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 191  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[41]+1)))(3,*((C_word*)lf[41]+1),t2,lf[84]);}
else{
t2=((C_word*)t0)[2];
/* chicken-install.scm: 194  abort */
((C_proc3)C_retrieve_symbol_proc(lf[85]))(3,*((C_word*)lf[85]+1),((C_word*)t0)[3],t2);}}

/* k1470 in k1467 in k1455 in a1446 in a1440 in a1434 in a1568 in k1597 in k1607 in trying-sources in k1541 in a1839 in a1813 in k1670 in main#retrieve in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_1472(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 192  values */
C_values(4,0,((C_word*)t0)[2],C_SCHEME_FALSE,lf[83]);}

/* k1458 in k1455 in a1446 in a1440 in a1434 in a1568 in k1597 in k1607 in trying-sources in k1541 in a1839 in a1813 in k1670 in main#retrieve in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_1460(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 189  values */
C_values(4,0,((C_word*)t0)[2],C_SCHEME_FALSE,lf[81]);}

/* k1431 in a1568 in k1597 in k1607 in trying-sources in k1541 in a1839 in a1813 in k1670 in main#retrieve in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_1433(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k1827 in a1813 in k1670 in main#retrieve in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_1829(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1829,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=C_mutate(&lf[26] /* (set! main#*eggs+dirs+vers* ...) */,t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k1673 in k1670 in main#retrieve in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_1675(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1675,2,t0,t1);}
if(C_truep(C_retrieve2(lf[6],"main#*retrieve-only*"))){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1683,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t3=*((C_word*)lf[44]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t2,C_retrieve2(lf[26],"main#*eggs+dirs+vers*"));}}

/* a1682 in k1673 in k1670 in main#retrieve in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_1683(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1683,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_member(t3,C_retrieve2(lf[27],"main#*checked*")))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_a_i_cons(&a,2,t4,C_retrieve2(lf[27],"main#*checked*"));
t6=C_mutate(&lf[27] /* (set! main#*checked* ...) */,t5);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1697,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t8=(C_word)C_i_cadr(t2);
t9=(C_word)C_i_car(t2);
/* chicken-install.scm: 249  make-pathname */
((C_proc5)C_retrieve_symbol_proc(lf[73]))(5,*((C_word*)lf[73]+1),t7,t8,t9,lf[74]);}}

/* k1695 in a1682 in k1673 in k1670 in main#retrieve in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_1697(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1697,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1703,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* chicken-install.scm: 250  file-exists? */
((C_proc3)C_retrieve_symbol_proc(lf[72]))(3,*((C_word*)lf[72]+1),t2,t1);}

/* k1701 in k1695 in a1682 in k1673 in k1670 in main#retrieve in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_1703(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1703,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1706,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm: 251  with-input-from-file */
((C_proc4)C_retrieve_symbol_proc(lf[66]))(4,*((C_word*)lf[66]+1),t2,((C_word*)t0)[2],*((C_word*)lf[67]+1));}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1792,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* chicken-install.scm: 272  string-append */
((C_proc6)C_retrieve_proc(*((C_word*)lf[68]+1)))(6,*((C_word*)lf[68]+1),t2,lf[69],t3,lf[70],lf[71]);}}

/* k1790 in k1701 in k1695 in a1682 in k1673 in k1670 in main#retrieve in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_1792(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 271  warning */
((C_proc3)C_retrieve_symbol_proc(lf[33]))(3,*((C_word*)lf[33]+1),((C_word*)t0)[2],t1);}

/* k1704 in k1701 in k1695 in a1682 in k1673 in k1670 in main#retrieve in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_1706(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1706,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1709,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
/* chicken-install.scm: 252  print */
((C_proc5)C_retrieve_proc(*((C_word*)lf[41]+1)))(5,*((C_word*)lf[41]+1),t2,lf[64],t3,lf[65]);}

/* k1707 in k1704 in k1701 in k1695 in a1682 in k1673 in k1670 in main#retrieve in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_1709(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1709,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1714,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1720,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a1719 in k1707 in k1704 in k1701 in k1695 in a1682 in k1673 in k1670 in main#retrieve in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_1720(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1720,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1724,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1774,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1781,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 255  string-intersperse */
((C_proc4)C_retrieve_symbol_proc(lf[46]))(4,*((C_word*)lf[46]+1),t6,t2,lf[63]);}
else{
t5=t4;
f_1724(2,t5,C_SCHEME_UNDEFINED);}}

/* k1779 in a1719 in k1707 in k1704 in k1701 in k1695 in a1682 in k1673 in k1670 in main#retrieve in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_1781(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 255  print */
((C_proc4)C_retrieve_proc(*((C_word*)lf[41]+1)))(4,*((C_word*)lf[41]+1),((C_word*)t0)[2],lf[62],t1);}

/* k1772 in a1719 in k1707 in k1704 in k1701 in k1695 in a1682 in k1673 in k1670 in main#retrieve in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_1774(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 256  retrieve */
f_1668(((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1722 in a1719 in k1707 in k1704 in k1701 in k1695 in a1682 in k1673 in k1670 in main#retrieve in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_1724(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[25],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1724,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1730,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
t3=C_retrieve2(lf[2],"main#*force*");
if(C_truep(t3)){
t4=t2;
f_1730(2,t4,t3);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1768,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=((C_word*)t0)[2];
t6=((C_word*)t0)[3];
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1622,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_i_car(t5);
t9=(C_word)C_a_i_list(&a,3,lf[52],t8,lf[53]);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1630,a[2]=t9,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
t11=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1632,tmp=(C_word)a,a+=2,tmp);
/* map */
t12=*((C_word*)lf[61]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t10,t11,t6);}}
else{
t3=t2;
f_1730(2,t3,C_SCHEME_FALSE);}}

/* a1631 in k1722 in a1719 in k1707 in k1704 in k1701 in k1695 in a1682 in k1673 in k1670 in main#retrieve in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_1632(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1632,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1658,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_car(t2);
/* chicken-install.scm: 222  extension-information */
((C_proc3)C_retrieve_symbol_proc(lf[23]))(3,*((C_word*)lf[23]+1),t4,t5);}

/* k1656 in a1631 in k1722 in a1719 in k1707 in k1704 in k1701 in k1695 in a1682 in k1673 in k1670 in main#retrieve in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_1658(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_i_assq(lf[20],t1);
t3=(C_truep(t2)?(C_word)C_i_cadr(t2):lf[55]);
t4=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* chicken-install.scm: 220  conc */
((C_proc10)C_retrieve_symbol_proc(lf[56]))(10,*((C_word*)lf[56]+1),((C_word*)t0)[3],lf[57],((C_word*)t0)[2],lf[58],t3,lf[59],t4,lf[60],C_make_character(10));}

/* k1628 in k1722 in a1719 in k1707 in k1704 in k1701 in k1695 in a1682 in k1673 in k1670 in main#retrieve in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_1630(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 214  append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[38]+1)))(5,*((C_word*)lf[38]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1,lf[54]);}

/* k1620 in k1722 in a1719 in k1707 in k1704 in k1701 in k1695 in a1682 in k1673 in k1670 in main#retrieve in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_1622(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 213  string-concatenate */
((C_proc3)C_retrieve_symbol_proc(lf[51]))(3,*((C_word*)lf[51]+1),((C_word*)t0)[2],t1);}

/* k1766 in k1722 in a1719 in k1707 in k1704 in k1701 in k1695 in a1682 in k1673 in k1670 in main#retrieve in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_1768(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 259  setup-api#yes-or-no? */
((C_proc4)C_retrieve_symbol_proc(lf[49]))(4,*((C_word*)lf[49]+1),((C_word*)t0)[2],t1,lf[50]);}

/* k1728 in k1722 in a1719 in k1707 in k1704 in k1701 in k1695 in a1682 in k1673 in k1670 in main#retrieve in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_1730(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1730,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1733,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 262  unzip1 */
((C_proc3)C_retrieve_symbol_proc(lf[48]))(3,*((C_word*)lf[48]+1),t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k1731 in k1728 in k1722 in a1719 in k1707 in k1704 in k1701 in k1695 in a1682 in k1673 in k1670 in main#retrieve in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_1733(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1733,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1736,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1755,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 263  string-intersperse */
((C_proc4)C_retrieve_symbol_proc(lf[46]))(4,*((C_word*)lf[46]+1),t3,t1,lf[47]);}

/* k1753 in k1731 in k1728 in k1722 in a1719 in k1707 in k1704 in k1701 in k1695 in a1682 in k1673 in k1670 in main#retrieve in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_1755(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 263  print */
((C_proc4)C_retrieve_proc(*((C_word*)lf[41]+1)))(4,*((C_word*)lf[41]+1),((C_word*)t0)[2],lf[45],t1);}

/* k1734 in k1731 in k1728 in k1722 in a1719 in k1707 in k1704 in k1701 in k1695 in a1682 in k1673 in k1670 in main#retrieve in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_1736(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1736,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1739,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1744,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[44]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a1743 in k1734 in k1731 in k1728 in k1722 in a1719 in k1707 in k1704 in k1701 in k1695 in a1682 in k1673 in k1670 in main#retrieve in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_1744(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1744,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1748,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm: 266  print */
((C_proc5)C_retrieve_proc(*((C_word*)lf[41]+1)))(5,*((C_word*)lf[41]+1),t3,lf[42],t2,lf[43]);}

/* k1746 in a1743 in k1734 in k1731 in k1728 in k1722 in a1719 in k1707 in k1704 in k1701 in k1695 in a1682 in k1673 in k1670 in main#retrieve in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_1748(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 267  setup-api#remove-extension */
((C_proc3)C_retrieve_symbol_proc(lf[40]))(3,*((C_word*)lf[40]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1737 in k1734 in k1731 in k1728 in k1722 in a1719 in k1707 in k1704 in k1701 in k1695 in a1682 in k1673 in k1670 in main#retrieve in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_1739(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 269  retrieve */
f_1668(((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a1713 in k1707 in k1704 in k1701 in k1695 in a1682 in k1673 in k1670 in main#retrieve in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_1714(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[8],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1714,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1220,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_assq(lf[36],t2);
t5=(C_truep(t4)?(C_word)C_i_cdr(t4):C_SCHEME_FALSE);
t6=(C_truep(t5)?t5:C_SCHEME_END_OF_LIST);
t7=(C_word)C_i_assq(lf[37],t2);
t8=(C_truep(t7)?(C_word)C_i_cdr(t7):C_SCHEME_FALSE);
t9=(C_truep(t8)?t8:C_SCHEME_END_OF_LIST);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1415,a[2]=t9,a[3]=t6,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve2(lf[5],"main#*run-tests*"))){
t11=(C_word)C_i_assq(lf[39],t2);
t12=(C_truep(t11)?(C_word)C_i_cdr(t11):C_SCHEME_FALSE);
t13=t10;
f_1415(t13,(C_truep(t12)?t12:C_SCHEME_END_OF_LIST));}
else{
t11=t10;
f_1415(t11,C_SCHEME_END_OF_LIST);}}

/* k1413 in a1713 in k1707 in k1704 in k1701 in k1695 in a1682 in k1673 in k1670 in main#retrieve in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_fcall f_1415(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 135  append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[38]+1)))(5,*((C_word*)lf[38]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1218 in a1713 in k1707 in k1704 in k1701 in k1695 in a1682 in k1673 in k1670 in main#retrieve in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_1220(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1220,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1225,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_1225(t5,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}

/* loop in k1218 in a1713 in k1707 in k1704 in k1701 in k1695 in a1682 in k1673 in k1670 in main#retrieve in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_fcall f_1225(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1225,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1239,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm: 141  reverse */
((C_proc3)C_retrieve_proc(*((C_word*)lf[30]+1)))(3,*((C_word*)lf[30]+1),t5,t3);}
else{
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_cdr(t2);
t7=(C_word)C_i_symbolp(t5);
t8=(C_truep(t7)?t7:(C_word)C_i_stringp(t5));
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1265,a[2]=t4,a[3]=t6,a[4]=t1,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1268,a[2]=t5,a[3]=t3,a[4]=t9,tmp=(C_word)a,a+=5,tmp);
/* chicken-install.scm: 146  ext-version */
f_1169(t10,t5);}
else{
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1281,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t6,a[6]=t1,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_i_listp(t5))){
t10=(C_word)C_i_length(t5);
if(C_truep((C_word)C_i_nequalp(C_fix(2),t10))){
t11=(C_word)C_i_car(t5);
t12=(C_word)C_i_stringp(t11);
if(C_truep(t12)){
t13=t9;
f_1281(t13,t12);}
else{
t13=(C_word)C_i_car(t5);
t14=t9;
f_1281(t14,(C_word)C_i_symbolp(t13));}}
else{
t11=t9;
f_1281(t11,C_SCHEME_FALSE);}}
else{
t10=t9;
f_1281(t10,C_SCHEME_FALSE);}}}}

/* k1279 in loop in k1218 in a1713 in k1707 in k1704 in k1701 in k1695 in a1682 in k1673 in k1670 in main#retrieve in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_fcall f_1281(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1281,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1284,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[2]);
/* chicken-install.scm: 152  ext-version */
f_1169(t2,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1367,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* chicken-install.scm: 169  warning */
((C_proc4)C_retrieve_symbol_proc(lf[33]))(4,*((C_word*)lf[33]+1),t2,lf[35],((C_word*)t0)[2]);}}

/* k1365 in k1279 in loop in k1218 in a1713 in k1707 in k1704 in k1701 in k1695 in a1682 in k1673 in k1670 in main#retrieve in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_1367(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 172  loop */
t2=((C_word*)((C_word*)t0)[6])[1];
f_1225(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1282 in k1279 in loop in k1218 in a1713 in k1707 in k1704 in k1701 in k1695 in a1682 in k1673 in k1670 in main#retrieve in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_1284(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1284,2,t0,t1);}
t2=t1;
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1326,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1356,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_cadr(((C_word*)t0)[2]);
/* chicken-install.scm: 162  ->string */
((C_proc3)C_retrieve_symbol_proc(lf[21]))(3,*((C_word*)lf[21]+1),t4,t5);}
else{
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1293,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[2]);
/* chicken-install.scm: 154  warning */
((C_proc4)C_retrieve_symbol_proc(lf[33]))(4,*((C_word*)lf[33]+1),t3,lf[34],t4);}}

/* k1291 in k1282 in k1279 in loop in k1218 in a1713 in k1707 in k1704 in k1701 in k1695 in a1682 in k1673 in k1670 in main#retrieve in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_1293(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1293,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1300,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1304,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[2]);
/* chicken-install.scm: 159  ->string */
((C_proc3)C_retrieve_symbol_proc(lf[21]))(3,*((C_word*)lf[21]+1),t3,t4);}

/* k1302 in k1291 in k1282 in k1279 in loop in k1218 in a1713 in k1707 in k1704 in k1701 in k1695 in a1682 in k1673 in k1670 in main#retrieve in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_1304(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1304,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1308,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[2]);
/* chicken-install.scm: 160  ->string */
((C_proc3)C_retrieve_symbol_proc(lf[21]))(3,*((C_word*)lf[21]+1),t2,t3);}

/* k1306 in k1302 in k1291 in k1282 in k1279 in loop in k1218 in a1713 in k1707 in k1704 in k1701 in k1695 in a1682 in k1673 in k1670 in main#retrieve in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_1308(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 158  alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[31]))(5,*((C_word*)lf[31]+1),((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k1298 in k1291 in k1282 in k1279 in loop in k1218 in a1713 in k1707 in k1704 in k1701 in k1695 in a1682 in k1673 in k1670 in main#retrieve in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_1300(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 157  loop */
t2=((C_word*)((C_word*)t0)[5])[1];
f_1225(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1354 in k1282 in k1279 in loop in k1218 in a1713 in k1707 in k1704 in k1701 in k1695 in a1682 in k1673 in k1670 in main#retrieve in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_1356(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 162  setup-api#version>=? */
((C_proc4)C_retrieve_symbol_proc(lf[32]))(4,*((C_word*)lf[32]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k1324 in k1282 in k1279 in loop in k1218 in a1713 in k1707 in k1704 in k1701 in k1695 in a1682 in k1673 in k1670 in main#retrieve in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_1326(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1326,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1333,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1337,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[2]);
/* chicken-install.scm: 165  ->string */
((C_proc3)C_retrieve_symbol_proc(lf[21]))(3,*((C_word*)lf[21]+1),t3,t4);}
else{
/* chicken-install.scm: 167  loop */
t2=((C_word*)((C_word*)t0)[7])[1];
f_1225(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);}}

/* k1335 in k1324 in k1282 in k1279 in loop in k1218 in a1713 in k1707 in k1704 in k1701 in k1695 in a1682 in k1673 in k1670 in main#retrieve in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_1337(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1337,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1341,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[2]);
/* chicken-install.scm: 165  ->string */
((C_proc3)C_retrieve_symbol_proc(lf[21]))(3,*((C_word*)lf[21]+1),t2,t3);}

/* k1339 in k1335 in k1324 in k1282 in k1279 in loop in k1218 in a1713 in k1707 in k1704 in k1701 in k1695 in a1682 in k1673 in k1670 in main#retrieve in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_1341(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 164  alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[31]))(5,*((C_word*)lf[31]+1),((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k1331 in k1324 in k1282 in k1279 in loop in k1218 in a1713 in k1707 in k1704 in k1701 in k1695 in a1682 in k1673 in k1670 in main#retrieve in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_1333(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 163  loop */
t2=((C_word*)((C_word*)t0)[5])[1];
f_1225(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1266 in loop in k1218 in a1713 in k1707 in k1704 in k1701 in k1695 in a1682 in k1673 in k1670 in main#retrieve in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_1268(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1268,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_1265(t2,((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1275,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm: 148  ->string */
((C_proc3)C_retrieve_symbol_proc(lf[21]))(3,*((C_word*)lf[21]+1),t2,((C_word*)t0)[2]);}}

/* k1273 in k1266 in loop in k1218 in a1713 in k1707 in k1704 in k1701 in k1695 in a1682 in k1673 in k1670 in main#retrieve in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_1275(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1275,2,t0,t1);}
t2=((C_word*)t0)[3];
f_1265(t2,(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[2]));}

/* k1263 in loop in k1218 in a1713 in k1707 in k1704 in k1701 in k1695 in a1682 in k1673 in k1670 in main#retrieve in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_fcall f_1265(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 145  loop */
t2=((C_word*)((C_word*)t0)[5])[1];
f_1225(t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k1237 in loop in k1218 in a1713 in k1707 in k1704 in k1701 in k1695 in a1682 in k1673 in k1670 in main#retrieve in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_1239(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1239,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1243,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm: 141  reverse */
((C_proc3)C_retrieve_proc(*((C_word*)lf[30]+1)))(3,*((C_word*)lf[30]+1),t2,((C_word*)t0)[2]);}

/* k1241 in k1237 in loop in k1218 in a1713 in k1707 in k1704 in k1701 in k1695 in a1682 in k1673 in k1670 in main#retrieve in k1422 in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_1243(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 141  values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* main#ext-version in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_fcall f_1169(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1169,NULL,2,t1,t2);}
t3=(C_word)C_eqp(t2,lf[18]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1179,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t3)){
t5=t4;
f_1179(t5,t3);}
else{
t5=(C_word)C_i_equalp(t2,lf[24]);
if(C_truep(t5)){
t6=t4;
f_1179(t6,t5);}
else{
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1214,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 124  ->string */
((C_proc3)C_retrieve_symbol_proc(lf[21]))(3,*((C_word*)lf[21]+1),t6,t2);}}}

/* k1212 in main#ext-version in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_1214(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_1179(t2,(C_word)C_i_member(t1,C_retrieve(lf[25])));}

/* k1177 in main#ext-version in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_fcall f_1179(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1179,NULL,2,t0,t1);}
if(C_truep(t1)){
/* chicken-install.scm: 125  chicken-version */
((C_proc2)C_retrieve_symbol_proc(lf[19]))(2,*((C_word*)lf[19]+1),((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1185,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 126  extension-information */
((C_proc3)C_retrieve_symbol_proc(lf[23]))(3,*((C_word*)lf[23]+1),t2,((C_word*)t0)[2]);}}

/* k1183 in k1177 in main#ext-version in k1028 in k1025 in k1022 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in k999 in k996 in k993 in k990 in k987 in k984 in k981 in k978 in k975 in k972 in k969 */
static void C_ccall f_1185(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_assq(lf[20],t1);
if(C_truep(t2)){
t3=(C_word)C_i_cadr(t2);
/* chicken-install.scm: 130  ->string */
((C_proc3)C_retrieve_symbol_proc(lf[21]))(3,*((C_word*)lf[21]+1),((C_word*)t0)[2],t3);}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[22]);}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[234] = {
{"toplevel:chicken_install_scm",(void*)C_toplevel},
{"f_971:chicken_install_scm",(void*)f_971},
{"f_974:chicken_install_scm",(void*)f_974},
{"f_977:chicken_install_scm",(void*)f_977},
{"f_980:chicken_install_scm",(void*)f_980},
{"f_983:chicken_install_scm",(void*)f_983},
{"f_986:chicken_install_scm",(void*)f_986},
{"f_989:chicken_install_scm",(void*)f_989},
{"f_992:chicken_install_scm",(void*)f_992},
{"f_995:chicken_install_scm",(void*)f_995},
{"f_998:chicken_install_scm",(void*)f_998},
{"f_1001:chicken_install_scm",(void*)f_1001},
{"f_1004:chicken_install_scm",(void*)f_1004},
{"f_1007:chicken_install_scm",(void*)f_1007},
{"f_1010:chicken_install_scm",(void*)f_1010},
{"f_1013:chicken_install_scm",(void*)f_1013},
{"f_1016:chicken_install_scm",(void*)f_1016},
{"f_1019:chicken_install_scm",(void*)f_1019},
{"f_1024:chicken_install_scm",(void*)f_1024},
{"f_1027:chicken_install_scm",(void*)f_1027},
{"f_1030:chicken_install_scm",(void*)f_1030},
{"f_3000:chicken_install_scm",(void*)f_3000},
{"f_1424:chicken_install_scm",(void*)f_1424},
{"f_2924:chicken_install_scm",(void*)f_2924},
{"f_2939:chicken_install_scm",(void*)f_2939},
{"f_2967:chicken_install_scm",(void*)f_2967},
{"f_2986:chicken_install_scm",(void*)f_2986},
{"f_2992:chicken_install_scm",(void*)f_2992},
{"f_2973:chicken_install_scm",(void*)f_2973},
{"f_2984:chicken_install_scm",(void*)f_2984},
{"f_1072:chicken_install_scm",(void*)f_1072},
{"f_1051:chicken_install_scm",(void*)f_1051},
{"f_1068:chicken_install_scm",(void*)f_1068},
{"f_1061:chicken_install_scm",(void*)f_1061},
{"f_2275:chicken_install_scm",(void*)f_2275},
{"f_2280:chicken_install_scm",(void*)f_2280},
{"f_2370:chicken_install_scm",(void*)f_2370},
{"f_2723:chicken_install_scm",(void*)f_2723},
{"f_2868:chicken_install_scm",(void*)f_2868},
{"f_2831:chicken_install_scm",(void*)f_2831},
{"f_2845:chicken_install_scm",(void*)f_2845},
{"f_2786:chicken_install_scm",(void*)f_2786},
{"f_2809:chicken_install_scm",(void*)f_2809},
{"f_2818:chicken_install_scm",(void*)f_2818},
{"f_2825:chicken_install_scm",(void*)f_2825},
{"f_2812:chicken_install_scm",(void*)f_2812},
{"f_2790:chicken_install_scm",(void*)f_2790},
{"f_2770:chicken_install_scm",(void*)f_2770},
{"f_2732:chicken_install_scm",(void*)f_2732},
{"f_2766:chicken_install_scm",(void*)f_2766},
{"f_2755:chicken_install_scm",(void*)f_2755},
{"f_2749:chicken_install_scm",(void*)f_2749},
{"f_2745:chicken_install_scm",(void*)f_2745},
{"f_2696:chicken_install_scm",(void*)f_2696},
{"f_2666:chicken_install_scm",(void*)f_2666},
{"f_2609:chicken_install_scm",(void*)f_2609},
{"f_1136:chicken_install_scm",(void*)f_1136},
{"f_1142:chicken_install_scm",(void*)f_1142},
{"f_1147:chicken_install_scm",(void*)f_1147},
{"f_1167:chicken_install_scm",(void*)f_1167},
{"f_1159:chicken_install_scm",(void*)f_1159},
{"f_1163:chicken_install_scm",(void*)f_1163},
{"f_1155:chicken_install_scm",(void*)f_1155},
{"f_2612:chicken_install_scm",(void*)f_2612},
{"f_2580:chicken_install_scm",(void*)f_2580},
{"f_2573:chicken_install_scm",(void*)f_2573},
{"f_2522:chicken_install_scm",(void*)f_2522},
{"f_2485:chicken_install_scm",(void*)f_2485},
{"f_2489:chicken_install_scm",(void*)f_2489},
{"f_2452:chicken_install_scm",(void*)f_2452},
{"f_2416:chicken_install_scm",(void*)f_2416},
{"f_2324:chicken_install_scm",(void*)f_2324},
{"f_2355:chicken_install_scm",(void*)f_2355},
{"f_2340:chicken_install_scm",(void*)f_2340},
{"f_2348:chicken_install_scm",(void*)f_2348},
{"f_2338:chicken_install_scm",(void*)f_2338},
{"f_2334:chicken_install_scm",(void*)f_2334},
{"f_2296:chicken_install_scm",(void*)f_2296},
{"f_2309:chicken_install_scm",(void*)f_2309},
{"f_2299:chicken_install_scm",(void*)f_2299},
{"f_2306:chicken_install_scm",(void*)f_2306},
{"f_1942:chicken_install_scm",(void*)f_1942},
{"f_1950:chicken_install_scm",(void*)f_1950},
{"f_1954:chicken_install_scm",(void*)f_1954},
{"f_1957:chicken_install_scm",(void*)f_1957},
{"f_1974:chicken_install_scm",(void*)f_1974},
{"f_1886:chicken_install_scm",(void*)f_1886},
{"f_1928:chicken_install_scm",(void*)f_1928},
{"f_1906:chicken_install_scm",(void*)f_1906},
{"f_1914:chicken_install_scm",(void*)f_1914},
{"f_1910:chicken_install_scm",(void*)f_1910},
{"f_1978:chicken_install_scm",(void*)f_1978},
{"f_1981:chicken_install_scm",(void*)f_1981},
{"f_1984:chicken_install_scm",(void*)f_1984},
{"f_2012:chicken_install_scm",(void*)f_2012},
{"f_2018:chicken_install_scm",(void*)f_2018},
{"f_1990:chicken_install_scm",(void*)f_1990},
{"f_1993:chicken_install_scm",(void*)f_1993},
{"f_1996:chicken_install_scm",(void*)f_1996},
{"f_1999:chicken_install_scm",(void*)f_1999},
{"f_1961:chicken_install_scm",(void*)f_1961},
{"f_1965:chicken_install_scm",(void*)f_1965},
{"f_1968:chicken_install_scm",(void*)f_1968},
{"f_2237:chicken_install_scm",(void*)f_2237},
{"f_2233:chicken_install_scm",(void*)f_2233},
{"f_2054:chicken_install_scm",(void*)f_2054},
{"f_2057:chicken_install_scm",(void*)f_2057},
{"f_2060:chicken_install_scm",(void*)f_2060},
{"f_2063:chicken_install_scm",(void*)f_2063},
{"f_2226:chicken_install_scm",(void*)f_2226},
{"f_2195:chicken_install_scm",(void*)f_2195},
{"f_2201:chicken_install_scm",(void*)f_2201},
{"f_2205:chicken_install_scm",(void*)f_2205},
{"f_2220:chicken_install_scm",(void*)f_2220},
{"f_2190:chicken_install_scm",(void*)f_2190},
{"f_2066:chicken_install_scm",(void*)f_2066},
{"f_2069:chicken_install_scm",(void*)f_2069},
{"f_2135:chicken_install_scm",(void*)f_2135},
{"f_2142:chicken_install_scm",(void*)f_2142},
{"f_2145:chicken_install_scm",(void*)f_2145},
{"f_2156:chicken_install_scm",(void*)f_2156},
{"f_2180:chicken_install_scm",(void*)f_2180},
{"f_2164:chicken_install_scm",(void*)f_2164},
{"f_2170:chicken_install_scm",(void*)f_2170},
{"f_2168:chicken_install_scm",(void*)f_2168},
{"f_2150:chicken_install_scm",(void*)f_2150},
{"f_2111:chicken_install_scm",(void*)f_2111},
{"f_2113:chicken_install_scm",(void*)f_2113},
{"f_2121:chicken_install_scm",(void*)f_2121},
{"f_2125:chicken_install_scm",(void*)f_2125},
{"f_2072:chicken_install_scm",(void*)f_2072},
{"f_2075:chicken_install_scm",(void*)f_2075},
{"f_2094:chicken_install_scm",(void*)f_2094},
{"f_2100:chicken_install_scm",(void*)f_2100},
{"f_2104:chicken_install_scm",(void*)f_2104},
{"f_2078:chicken_install_scm",(void*)f_2078},
{"f_2092:chicken_install_scm",(void*)f_2092},
{"f_2088:chicken_install_scm",(void*)f_2088},
{"f_2081:chicken_install_scm",(void*)f_2081},
{"f_2977:chicken_install_scm",(void*)f_2977},
{"f_2945:chicken_install_scm",(void*)f_2945},
{"f_2951:chicken_install_scm",(void*)f_2951},
{"f_2965:chicken_install_scm",(void*)f_2965},
{"f_2955:chicken_install_scm",(void*)f_2955},
{"f_2958:chicken_install_scm",(void*)f_2958},
{"f_2937:chicken_install_scm",(void*)f_2937},
{"f_2928:chicken_install_scm",(void*)f_2928},
{"f_2934:chicken_install_scm",(void*)f_2934},
{"f_2931:chicken_install_scm",(void*)f_2931},
{"f_2261:chicken_install_scm",(void*)f_2261},
{"f_2265:chicken_install_scm",(void*)f_2265},
{"f_2239:chicken_install_scm",(void*)f_2239},
{"f_2256:chicken_install_scm",(void*)f_2256},
{"f_2243:chicken_install_scm",(void*)f_2243},
{"f_2035:chicken_install_scm",(void*)f_2035},
{"f_2042:chicken_install_scm",(void*)f_2042},
{"f_1668:chicken_install_scm",(void*)f_1668},
{"f_1672:chicken_install_scm",(void*)f_1672},
{"f_1814:chicken_install_scm",(void*)f_1814},
{"f_1846:chicken_install_scm",(void*)f_1846},
{"f_1850:chicken_install_scm",(void*)f_1850},
{"f_1853:chicken_install_scm",(void*)f_1853},
{"f_1857:chicken_install_scm",(void*)f_1857},
{"f_1840:chicken_install_scm",(void*)f_1840},
{"f_1543:chicken_install_scm",(void*)f_1543},
{"f_1545:chicken_install_scm",(void*)f_1545},
{"f_1609:chicken_install_scm",(void*)f_1609},
{"f_1599:chicken_install_scm",(void*)f_1599},
{"f_1575:chicken_install_scm",(void*)f_1575},
{"f_1115:chicken_install_scm",(void*)f_1115},
{"f_1569:chicken_install_scm",(void*)f_1569},
{"f_1435:chicken_install_scm",(void*)f_1435},
{"f_1504:chicken_install_scm",(void*)f_1504},
{"f_1523:chicken_install_scm",(void*)f_1523},
{"f_1529:chicken_install_scm",(void*)f_1529},
{"f_1510:chicken_install_scm",(void*)f_1510},
{"f_1518:chicken_install_scm",(void*)f_1518},
{"f_1441:chicken_install_scm",(void*)f_1441},
{"f_1447:chicken_install_scm",(void*)f_1447},
{"f_1457:chicken_install_scm",(void*)f_1457},
{"f_1469:chicken_install_scm",(void*)f_1469},
{"f_1472:chicken_install_scm",(void*)f_1472},
{"f_1460:chicken_install_scm",(void*)f_1460},
{"f_1433:chicken_install_scm",(void*)f_1433},
{"f_1829:chicken_install_scm",(void*)f_1829},
{"f_1675:chicken_install_scm",(void*)f_1675},
{"f_1683:chicken_install_scm",(void*)f_1683},
{"f_1697:chicken_install_scm",(void*)f_1697},
{"f_1703:chicken_install_scm",(void*)f_1703},
{"f_1792:chicken_install_scm",(void*)f_1792},
{"f_1706:chicken_install_scm",(void*)f_1706},
{"f_1709:chicken_install_scm",(void*)f_1709},
{"f_1720:chicken_install_scm",(void*)f_1720},
{"f_1781:chicken_install_scm",(void*)f_1781},
{"f_1774:chicken_install_scm",(void*)f_1774},
{"f_1724:chicken_install_scm",(void*)f_1724},
{"f_1632:chicken_install_scm",(void*)f_1632},
{"f_1658:chicken_install_scm",(void*)f_1658},
{"f_1630:chicken_install_scm",(void*)f_1630},
{"f_1622:chicken_install_scm",(void*)f_1622},
{"f_1768:chicken_install_scm",(void*)f_1768},
{"f_1730:chicken_install_scm",(void*)f_1730},
{"f_1733:chicken_install_scm",(void*)f_1733},
{"f_1755:chicken_install_scm",(void*)f_1755},
{"f_1736:chicken_install_scm",(void*)f_1736},
{"f_1744:chicken_install_scm",(void*)f_1744},
{"f_1748:chicken_install_scm",(void*)f_1748},
{"f_1739:chicken_install_scm",(void*)f_1739},
{"f_1714:chicken_install_scm",(void*)f_1714},
{"f_1415:chicken_install_scm",(void*)f_1415},
{"f_1220:chicken_install_scm",(void*)f_1220},
{"f_1225:chicken_install_scm",(void*)f_1225},
{"f_1281:chicken_install_scm",(void*)f_1281},
{"f_1367:chicken_install_scm",(void*)f_1367},
{"f_1284:chicken_install_scm",(void*)f_1284},
{"f_1293:chicken_install_scm",(void*)f_1293},
{"f_1304:chicken_install_scm",(void*)f_1304},
{"f_1308:chicken_install_scm",(void*)f_1308},
{"f_1300:chicken_install_scm",(void*)f_1300},
{"f_1356:chicken_install_scm",(void*)f_1356},
{"f_1326:chicken_install_scm",(void*)f_1326},
{"f_1337:chicken_install_scm",(void*)f_1337},
{"f_1341:chicken_install_scm",(void*)f_1341},
{"f_1333:chicken_install_scm",(void*)f_1333},
{"f_1268:chicken_install_scm",(void*)f_1268},
{"f_1275:chicken_install_scm",(void*)f_1275},
{"f_1265:chicken_install_scm",(void*)f_1265},
{"f_1239:chicken_install_scm",(void*)f_1239},
{"f_1243:chicken_install_scm",(void*)f_1243},
{"f_1169:chicken_install_scm",(void*)f_1169},
{"f_1214:chicken_install_scm",(void*)f_1214},
{"f_1179:chicken_install_scm",(void*)f_1179},
{"f_1185:chicken_install_scm",(void*)f_1185},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
