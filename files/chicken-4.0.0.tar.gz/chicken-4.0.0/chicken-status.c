/* Generated from chicken-status.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2009-03-24 10:49
   Version 4.0.0 - SVN rev. 13887
   windows-mingw32-x86 [ manyargs dload ptables applyhook ]
   compiled 2009-03-24 on LENOVO-1 (MINGW32_NT-6.0)
   command line: chicken-status.scm -no-trace -optimize-level 2 -include-path . -include-path ./ -feature debugbuild -no-lambda-info -inline -local -ignore-repository -output-file chicken-status.c
   used units: library eval data_structures ports extras srfi_69 srfi_1 posix data_structures utils ports regex files
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_69_toplevel)
C_externimport void C_ccall C_srfi_69_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_1_toplevel)
C_externimport void C_ccall C_srfi_1_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_posix_toplevel)
C_externimport void C_ccall C_posix_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_utils_toplevel)
C_externimport void C_ccall C_utils_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_regex_toplevel)
C_externimport void C_ccall C_regex_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_files_toplevel)
C_externimport void C_ccall C_files_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[55];
static double C_possibly_force_alignment;


C_noret_decl(C_toplevel)
C_externexport void C_ccall C_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_380)
static void C_ccall f_380(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_383)
static void C_ccall f_383(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_386)
static void C_ccall f_386(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_389)
static void C_ccall f_389(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_392)
static void C_ccall f_392(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_395)
static void C_ccall f_395(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_398)
static void C_ccall f_398(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_401)
static void C_ccall f_401(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_404)
static void C_ccall f_404(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_407)
static void C_ccall f_407(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_410)
static void C_ccall f_410(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_413)
static void C_ccall f_413(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_416)
static void C_ccall f_416(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_419)
static void C_ccall f_419(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_875)
static void C_ccall f_875(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_679)
static void C_fcall f_679(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_723)
static void C_fcall f_723(C_word t0,C_word t1) C_noret;
C_noret_decl(f_768)
static void C_fcall f_768(C_word t0,C_word t1) C_noret;
C_noret_decl(f_815)
static void C_ccall f_815(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_777)
static void C_ccall f_777(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_811)
static void C_ccall f_811(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_800)
static void C_ccall f_800(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_794)
static void C_ccall f_794(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_790)
static void C_ccall f_790(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_762)
static void C_ccall f_762(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_755)
static void C_ccall f_755(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_454)
static void C_ccall f_454(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_450)
static void C_ccall f_450(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_446)
static void C_ccall f_446(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_425)
static void C_ccall f_425(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_438)
static void C_ccall f_438(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_436)
static void C_ccall f_436(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_432)
static void C_ccall f_432(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_689)
static void C_ccall f_689(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_865)
static void C_ccall f_865(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_871)
static void C_ccall f_871(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_868)
static void C_ccall f_868(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_663)
static void C_fcall f_663(C_word t0,C_word t1) C_noret;
C_noret_decl(f_667)
static void C_ccall f_667(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_633)
static void C_ccall f_633(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_647)
static void C_ccall f_647(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_661)
static void C_ccall f_661(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_645)
static void C_ccall f_645(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_641)
static void C_ccall f_641(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_569)
static void C_ccall f_569(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_540)
static void C_ccall f_540(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_546)
static void C_ccall f_546(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_563)
static void C_ccall f_563(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_563)
static void C_ccall f_563r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_557)
static void C_ccall f_557(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_549)
static void C_ccall f_549(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_631)
static void C_fcall f_631(C_word t0,C_word t1) C_noret;
C_noret_decl(f_573)
static void C_ccall f_573(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_623)
static void C_ccall f_623(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_578)
static void C_ccall f_578(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_619)
static void C_ccall f_619(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_612)
static void C_ccall f_612(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_592)
static void C_ccall f_592(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_604)
static void C_ccall f_604(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_600)
static void C_ccall f_600(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_596)
static void C_ccall f_596(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_456)
static void C_fcall f_456(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_488)
static void C_fcall f_488(C_word t0,C_word t1) C_noret;
C_noret_decl(f_483)
static void C_fcall f_483(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_458)
static void C_fcall f_458(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_465)
static void C_ccall f_465(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_679)
static void C_fcall trf_679(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_679(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_679(t0,t1,t2,t3);}

C_noret_decl(trf_723)
static void C_fcall trf_723(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_723(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_723(t0,t1);}

C_noret_decl(trf_768)
static void C_fcall trf_768(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_768(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_768(t0,t1);}

C_noret_decl(trf_663)
static void C_fcall trf_663(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_663(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_663(t0,t1);}

C_noret_decl(trf_631)
static void C_fcall trf_631(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_631(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_631(t0,t1);}

C_noret_decl(trf_456)
static void C_fcall trf_456(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_456(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_456(t0,t1,t2,t3);}

C_noret_decl(trf_488)
static void C_fcall trf_488(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_488(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_488(t0,t1);}

C_noret_decl(trf_483)
static void C_fcall trf_483(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_483(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_483(t0,t1,t2);}

C_noret_decl(trf_458)
static void C_fcall trf_458(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_458(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_458(t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr2rv)
static void C_fcall tr2rv(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2rv(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n+1);
t2=C_restore_rest_vector(a,n);
(k)(t0,t1,t2);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_main_entry_point
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("toplevel"));
C_resize_stack(131072);
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(359)){
C_save(t1);
C_rereclaim2(359*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,55);
lf[1]=C_h_intern(&lf[1],13,"string-append");
lf[2]=C_h_intern(&lf[2],11,"make-string");
lf[3]=C_h_intern(&lf[3],9,"\003syserror");
lf[4]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[6]=C_h_intern(&lf[6],7,"version");
lf[7]=C_h_intern(&lf[7],5,"print");
lf[8]=C_decode_literal(C_heaptop,"\376B\000\000\012 version: ");
lf[9]=C_h_intern(&lf[9],8,"->string");
lf[10]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[11]=C_h_intern(&lf[11],19,"setup-api#read-info");
lf[12]=C_h_intern(&lf[12],12,"\003sysfor-each");
lf[13]=C_h_intern(&lf[13],4,"sort");
lf[14]=C_h_intern(&lf[14],8,"string<\077");
lf[15]=C_h_intern(&lf[15],13,"terminal-size");
lf[16]=C_h_intern(&lf[16],14,"terminal-port\077");
lf[17]=C_h_intern(&lf[17],19,"current-output-port");
lf[19]=C_h_intern(&lf[19],5,"files");
lf[20]=C_h_intern(&lf[20],10,"append-map");
lf[22]=C_h_intern(&lf[22],4,"exit");
lf[23]=C_decode_literal(C_heaptop,"\376B\000\000\312usage: chicken-status [OPTION | PATTERN] ...\012\012  -h   -help                 "
"   show this message\012  -v   -version                 show version and exit\012  -f "
"  -files                   list installed files");
lf[24]=C_h_intern(&lf[24],25,"\003sysimplicit-exit-handler");
lf[25]=C_decode_literal(C_heaptop,"\376B\000\000\006(none)");
lf[26]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002.*\376\377\016");
lf[27]=C_h_intern(&lf[27],17,"delete-duplicates");
lf[28]=C_h_intern(&lf[28],8,"string=\077");
lf[29]=C_h_intern(&lf[29],11,"concatenate");
lf[30]=C_h_intern(&lf[30],4,"grep");
lf[31]=C_h_intern(&lf[31],7,"\003sysmap");
lf[32]=C_h_intern(&lf[32],13,"pathname-file");
lf[33]=C_h_intern(&lf[33],4,"glob");
lf[34]=C_h_intern(&lf[34],13,"make-pathname");
lf[35]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[36]=C_decode_literal(C_heaptop,"\376B\000\000\012setup-info");
lf[37]=C_h_intern(&lf[37],15,"repository-path");
lf[38]=C_decode_literal(C_heaptop,"\376B\000\000\005-help");
lf[39]=C_decode_literal(C_heaptop,"\376B\000\000\002-f");
lf[40]=C_decode_literal(C_heaptop,"\376B\000\000\006-files");
lf[41]=C_decode_literal(C_heaptop,"\376B\000\000\002-v");
lf[42]=C_decode_literal(C_heaptop,"\376B\000\000\010-version");
lf[43]=C_h_intern(&lf[43],15,"chicken-version");
lf[44]=C_h_intern(&lf[44],6,"append");
lf[45]=C_h_intern(&lf[45],17,"lset-intersection");
lf[46]=C_h_intern(&lf[46],3,"eq\077");
lf[47]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000h\376\003\000\000\002\376\377\012\000\000f\376\377\016");
lf[48]=C_h_intern(&lf[48],16,"\003sysstring->list");
lf[49]=C_h_intern(&lf[49],9,"substring");
lf[50]=C_decode_literal(C_heaptop,"\376B\000\000\002-h");
lf[51]=C_decode_literal(C_heaptop,"\376B\000\000\006--help");
lf[52]=C_h_intern(&lf[52],22,"command-line-arguments");
lf[53]=C_h_intern(&lf[53],11,"\003sysrequire");
lf[54]=C_h_intern(&lf[54],9,"setup-api");
C_register_lf2(lf,55,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_380,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k378 */
static void C_ccall f_380(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_380,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_383,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k381 in k378 */
static void C_ccall f_383(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_383,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_386,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k384 in k381 in k378 */
static void C_ccall f_386(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_386,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_389,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k387 in k384 in k381 in k378 */
static void C_ccall f_389(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_389,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_392,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_392(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_392,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_395,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_395(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_395,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_398,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_1_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_398(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_398,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_401,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_posix_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_401(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_401,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_404,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_404(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_404,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_407,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_utils_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_407(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_407,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_410,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_410(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_410,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_413,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_regex_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_413(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_413,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_416,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_files_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_416(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_416,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_419,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#require */
((C_proc3)C_retrieve_symbol_proc(lf[53]))(3,*((C_word*)lf[53]+1),t2,lf[54]);}

/* k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_419(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_419,2,t0,t1);}
t2=C_mutate(&lf[0] /* (set! main#format-string ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_456,tmp=(C_word)a,a+=2,tmp));
t3=C_mutate(&lf[5] /* (set! main#list-installed-eggs ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_569,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate(&lf[18] /* (set! main#list-installed-files ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_633,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate(&lf[21] /* (set! main#usage ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_663,tmp=(C_word)a,a+=2,tmp));
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_865,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_875,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* chicken-status.scm: 129  command-line-arguments */
((C_proc2)C_retrieve_symbol_proc(lf[52]))(2,*((C_word*)lf[52]+1),t7);}

/* k873 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_875(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_875,2,t0,t1);}
t2=C_SCHEME_FALSE;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_679,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_679(t7,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* loop in k873 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_fcall f_679(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_679,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_689,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_nullp(t3);
t6=(C_truep(t5)?lf[26]:t3);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_425,a[2]=t6,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_446,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_450,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_454,a[2]=t9,tmp=(C_word)a,a+=3,tmp);
/* chicken-status.scm: 38   repository-path */
((C_proc2)C_retrieve_symbol_proc(lf[37]))(2,*((C_word*)lf[37]+1),t10);}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_string_equal_p(t4,lf[38]);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_723,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=t4,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
if(C_truep(t5)){
t7=t6;
f_723(t7,t5);}
else{
t7=(C_word)C_i_string_equal_p(t4,lf[50]);
t8=t6;
f_723(t8,(C_truep(t7)?t7:(C_word)C_i_string_equal_p(t4,lf[51])));}}}

/* k721 in loop in k873 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_fcall f_723(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_723,NULL,2,t0,t1);}
if(C_truep(t1)){
/* chicken-status.scm: 112  usage */
f_663(((C_word*)t0)[7],C_fix(0));}
else{
t2=(C_word)C_i_string_equal_p(((C_word*)t0)[6],lf[39]);
t3=(C_truep(t2)?t2:(C_word)C_i_string_equal_p(((C_word*)t0)[6],lf[40]));
if(C_truep(t3)){
t4=C_set_block_item(((C_word*)t0)[5],0,C_SCHEME_TRUE);
t5=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* chicken-status.scm: 115  loop */
t6=((C_word*)((C_word*)t0)[3])[1];
f_679(t6,((C_word*)t0)[7],t5,((C_word*)t0)[2]);}
else{
t4=(C_word)C_i_string_equal_p(((C_word*)t0)[6],lf[41]);
t5=(C_truep(t4)?t4:(C_word)C_i_string_equal_p(((C_word*)t0)[6],lf[42]));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_755,a[2]=((C_word*)t0)[7],tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_762,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* chicken-status.scm: 117  chicken-version */
((C_proc2)C_retrieve_symbol_proc(lf[43]))(2,*((C_word*)lf[43]+1),t7);}
else{
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_768,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t7=(C_word)C_i_string_length(((C_word*)t0)[6]);
if(C_truep((C_word)C_i_positivep(t7))){
t8=(C_word)C_i_string_ref(((C_word*)t0)[6],C_fix(0));
t9=t6;
f_768(t9,(C_word)C_eqp(C_make_character(45),t8));}
else{
t8=t6;
f_768(t8,C_SCHEME_FALSE);}}}}}

/* k766 in k721 in loop in k873 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_fcall f_768(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_768,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_string_length(((C_word*)t0)[6]);
if(C_truep((C_word)C_i_greaterp(t2,C_fix(2)))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_777,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_815,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* chicken-status.scm: 122  substring */
((C_proc4)C_retrieve_proc(*((C_word*)lf[49]+1)))(4,*((C_word*)lf[49]+1),t4,((C_word*)t0)[6],C_fix(1));}
else{
/* chicken-status.scm: 126  usage */
f_663(((C_word*)t0)[4],C_fix(1));}}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[2]);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],((C_word*)t0)[3]);
/* chicken-status.scm: 127  loop */
t4=((C_word*)((C_word*)t0)[5])[1];
f_679(t4,((C_word*)t0)[4],t2,t3);}}

/* k813 in k766 in k721 in loop in k873 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_815(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* string->list */
t2=C_retrieve(lf[48]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k775 in k766 in k721 in loop in k873 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_777(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_777,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_811,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* chicken-status.scm: 123  lset-intersection */
((C_proc5)C_retrieve_symbol_proc(lf[45]))(5,*((C_word*)lf[45]+1),t2,*((C_word*)lf[46]+1),lf[47],t1);}

/* k809 in k775 in k766 in k721 in loop in k873 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_811(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_811,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_790,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_794,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_800,tmp=(C_word)a,a+=2,tmp);
/* map */
t5=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}
else{
/* chicken-status.scm: 125  usage */
f_663(((C_word*)t0)[5],C_fix(1));}}

/* a799 in k809 in k775 in k766 in k721 in loop in k873 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_800(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_800,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_string(&a,2,C_make_character(45),t2));}

/* k792 in k809 in k775 in k766 in k721 in loop in k873 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_794(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* chicken-status.scm: 124  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[44]+1)))(4,*((C_word*)lf[44]+1),((C_word*)t0)[2],t1,t2);}

/* k788 in k809 in k775 in k766 in k721 in loop in k873 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_790(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-status.scm: 124  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_679(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k760 in k721 in loop in k873 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_762(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-status.scm: 117  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[7]+1)))(3,*((C_word*)lf[7]+1),((C_word*)t0)[2],t1);}

/* k753 in k721 in loop in k873 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_755(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-status.scm: 118  exit */
((C_proc3)C_retrieve_symbol_proc(lf[22]))(3,*((C_word*)lf[22]+1),((C_word*)t0)[2],C_fix(0));}

/* k452 in loop in k873 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_454(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-status.scm: 38   make-pathname */
((C_proc5)C_retrieve_symbol_proc(lf[34]))(5,*((C_word*)lf[34]+1),((C_word*)t0)[2],t1,lf[35],lf[36]);}

/* k448 in loop in k873 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_450(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-status.scm: 38   glob */
((C_proc3)C_retrieve_symbol_proc(lf[33]))(3,*((C_word*)lf[33]+1),((C_word*)t0)[2],t1);}

/* k444 in loop in k873 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_446(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve(lf[32]),t1);}

/* k423 in loop in k873 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_425(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_425,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_432,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_436,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_438,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* map */
t5=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a437 in k423 in loop in k873 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_438(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_438,3,t0,t1,t2);}
/* grep */
((C_proc4)C_retrieve_symbol_proc(lf[30]))(4,*((C_word*)lf[30]+1),t1,t2,((C_word*)t0)[2]);}

/* k434 in k423 in loop in k873 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_436(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-status.scm: 40   concatenate */
((C_proc3)C_retrieve_symbol_proc(lf[29]))(3,*((C_word*)lf[29]+1),((C_word*)t0)[2],t1);}

/* k430 in k423 in loop in k873 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_432(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-status.scm: 39   delete-duplicates */
((C_proc4)C_retrieve_symbol_proc(lf[27]))(4,*((C_word*)lf[27]+1),((C_word*)t0)[2],t1,*((C_word*)lf[28]+1));}

/* k687 in loop in k873 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_689(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep((C_word)C_i_nullp(t1))){
/* chicken-status.scm: 105  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[7]+1)))(3,*((C_word*)lf[7]+1),((C_word*)t0)[3],lf[25]);}
else{
t2=(C_truep(((C_word*)((C_word*)t0)[2])[1])?C_retrieve2(lf[18],"main#list-installed-files"):C_retrieve2(lf[5],"main#list-installed-eggs"));
t3=t2;
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[3],t1);}}

/* k863 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_865(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_865,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_868,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_871,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#implicit-exit-handler */
((C_proc2)C_retrieve_symbol_proc(lf[24]))(2,*((C_word*)lf[24]+1),t3);}

/* k869 in k863 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_871(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k866 in k863 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_868(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* main#usage in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_fcall f_663(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_663,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_667,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-status.scm: 87   print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[7]+1)))(3,*((C_word*)lf[7]+1),t3,lf[23]);}

/* k665 in main#usage in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_667(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-status.scm: 95   exit */
((C_proc3)C_retrieve_symbol_proc(lf[22]))(3,*((C_word*)lf[22]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* main#list-installed-files in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_633(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_633,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_641,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_645,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_647,tmp=(C_word)a,a+=2,tmp);
/* chicken-status.scm: 77   append-map */
((C_proc4)C_retrieve_symbol_proc(lf[20]))(4,*((C_word*)lf[20]+1),t4,t5,t2);}

/* a646 in main#list-installed-files in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_647(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_647,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_661,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* chicken-status.scm: 79   setup-api#read-info */
((C_proc3)C_retrieve_symbol_proc(lf[11]))(3,*((C_word*)lf[11]+1),t3,t2);}

/* k659 in a646 in main#list-installed-files in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_661(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_assq(lf[19],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?(C_word)C_i_cdr(t2):C_SCHEME_END_OF_LIST));}

/* k643 in main#list-installed-files in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_645(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-status.scm: 76   sort */
((C_proc4)C_retrieve_symbol_proc(lf[13]))(4,*((C_word*)lf[13]+1),((C_word*)t0)[2],t1,*((C_word*)lf[14]+1));}

/* k639 in main#list-installed-files in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_641(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[12]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],*((C_word*)lf[7]+1),t1);}

/* main#list-installed-eggs in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_569(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_569,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_573,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_631,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_540,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* chicken-status.scm: 53   current-output-port */
((C_proc2)C_retrieve_proc(*((C_word*)lf[17]+1)))(2,*((C_word*)lf[17]+1),t5);}

/* k538 in main#list-installed-eggs in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_540(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_540,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_546,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken-status.scm: 54   terminal-port? */
((C_proc3)C_retrieve_symbol_proc(lf[16]))(3,*((C_word*)lf[16]+1),t2,t1);}

/* k544 in k538 in main#list-installed-eggs in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_546(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_546,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_549,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_557,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_563,tmp=(C_word)a,a+=2,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t2,t3,t4);}
else{
t2=((C_word*)t0)[3];
f_631(t2,C_fix(80));}}

/* a562 in k544 in k538 in main#list-installed-eggs in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_563(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2rv,(void*)f_563r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_563r(t0,t1,t2);}}

static void C_ccall f_563r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_vector_ref(t2,C_fix(1)));}

/* a556 in k544 in k538 in main#list-installed-eggs in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_557(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_557,2,t0,t1);}
/* chicken-status.scm: 55   terminal-size */
((C_proc3)C_retrieve_symbol_proc(lf[15]))(3,*((C_word*)lf[15]+1),t1,((C_word*)t0)[2]);}

/* k547 in k544 in k538 in main#list-installed-eggs in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_549(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_zerop(t1);
t3=((C_word*)t0)[2];
f_631(t3,(C_truep(t2)?C_fix(80):t1));}

/* k629 in main#list-installed-eggs in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_fcall f_631(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_631,NULL,2,t0,t1);}
t2=(C_word)C_a_i_minus(&a,2,t1,C_fix(2));
C_quotient(4,0,((C_word*)t0)[2],t2,C_fix(2));}

/* k571 in main#list-installed-eggs in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_573(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_573,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_578,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_623,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken-status.scm: 71   sort */
((C_proc4)C_retrieve_symbol_proc(lf[13]))(4,*((C_word*)lf[13]+1),t3,((C_word*)t0)[2],*((C_word*)lf[14]+1));}

/* k621 in k571 in main#list-installed-eggs in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_623(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[12]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a577 in k571 in main#list-installed-eggs in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_578(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_578,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_619,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* chicken-status.scm: 63   setup-api#read-info */
((C_proc3)C_retrieve_symbol_proc(lf[11]))(3,*((C_word*)lf[11]+1),t3,t2);}

/* k617 in a577 in k571 in main#list-installed-eggs in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_619(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_619,2,t0,t1);}
t2=(C_word)C_i_assq(lf[6],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_592,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_612,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* chicken-status.scm: 66   string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[1]+1)))(4,*((C_word*)lf[1]+1),t4,((C_word*)t0)[2],lf[10]);}
else{
/* chicken-status.scm: 70   print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[7]+1)))(3,*((C_word*)lf[7]+1),((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* k610 in k617 in a577 in k571 in main#list-installed-eggs in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_612(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_612,2,t0,t1);}
/* chicken-status.scm: 66   format-string */
f_456(((C_word*)t0)[3],t1,((C_word*)t0)[2],(C_word)C_a_i_list(&a,2,C_SCHEME_FALSE,C_make_character(46)));}

/* k590 in k617 in a577 in k571 in main#list-installed-eggs in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_592(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_592,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_596,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_600,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_604,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_i_cadr(((C_word*)t0)[2]);
/* chicken-status.scm: 68   ->string */
((C_proc3)C_retrieve_symbol_proc(lf[9]))(3,*((C_word*)lf[9]+1),t4,t5);}

/* k602 in k590 in k617 in a577 in k571 in main#list-installed-eggs in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_604(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-status.scm: 68   string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[1]+1)))(4,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[8],t1);}

/* k598 in k590 in k617 in a577 in k571 in main#list-installed-eggs in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_600(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_600,2,t0,t1);}
/* chicken-status.scm: 67   format-string */
f_456(((C_word*)t0)[3],t1,((C_word*)t0)[2],(C_word)C_a_i_list(&a,2,C_SCHEME_TRUE,C_make_character(46)));}

/* k594 in k590 in k617 in a577 in k571 in main#list-installed-eggs in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_596(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-status.scm: 65   print */
((C_proc4)C_retrieve_proc(*((C_word*)lf[7]+1)))(4,*((C_word*)lf[7]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* main#format-string in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_fcall f_456(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_456,NULL,4,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_458,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_483,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_488,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-right221243 */
t8=t7;
f_488(t8,t1);}
else{
t8=(C_word)C_i_car(t4);
t9=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t9))){
/* def-padc222239 */
t10=t6;
f_483(t10,t1,t8);}
else{
t10=(C_word)C_i_car(t9);
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
/* body219228 */
t12=t5;
f_458(t12,t1,t8,t10);}
else{
/* ##sys#error */
t12=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t1,lf[4],t11);}}}}

/* def-right221 in main#format-string in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_fcall f_488(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_488,NULL,2,t0,t1);}
/* def-padc222239 */
t2=((C_word*)t0)[2];
f_483(t2,t1,C_SCHEME_FALSE);}

/* def-padc222 in main#format-string in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_fcall f_483(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_483,NULL,3,t0,t1,t2);}
/* body219228 */
t3=((C_word*)t0)[2];
f_458(t3,t1,t2,C_make_character(32));}

/* body219 in main#format-string in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_fcall f_458(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_458,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_string_length(((C_word*)t0)[3]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_465,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_fixnum_difference(((C_word*)t0)[2],t4);
t7=(C_word)C_i_fixnum_max(C_fix(0),t6);
/* chicken-status.scm: 45   make-string */
((C_proc4)C_retrieve_proc(*((C_word*)lf[2]+1)))(4,*((C_word*)lf[2]+1),t5,t7,t3);}

/* k463 in body219 in main#format-string in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 */
static void C_ccall f_465(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(((C_word*)t0)[4])){
/* chicken-status.scm: 47   string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[1]+1)))(4,*((C_word*)lf[1]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}
else{
/* chicken-status.scm: 48   string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[1]+1)))(4,*((C_word*)lf[1]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[67] = {
{"toplevel:chicken_status_scm",(void*)C_toplevel},
{"f_380:chicken_status_scm",(void*)f_380},
{"f_383:chicken_status_scm",(void*)f_383},
{"f_386:chicken_status_scm",(void*)f_386},
{"f_389:chicken_status_scm",(void*)f_389},
{"f_392:chicken_status_scm",(void*)f_392},
{"f_395:chicken_status_scm",(void*)f_395},
{"f_398:chicken_status_scm",(void*)f_398},
{"f_401:chicken_status_scm",(void*)f_401},
{"f_404:chicken_status_scm",(void*)f_404},
{"f_407:chicken_status_scm",(void*)f_407},
{"f_410:chicken_status_scm",(void*)f_410},
{"f_413:chicken_status_scm",(void*)f_413},
{"f_416:chicken_status_scm",(void*)f_416},
{"f_419:chicken_status_scm",(void*)f_419},
{"f_875:chicken_status_scm",(void*)f_875},
{"f_679:chicken_status_scm",(void*)f_679},
{"f_723:chicken_status_scm",(void*)f_723},
{"f_768:chicken_status_scm",(void*)f_768},
{"f_815:chicken_status_scm",(void*)f_815},
{"f_777:chicken_status_scm",(void*)f_777},
{"f_811:chicken_status_scm",(void*)f_811},
{"f_800:chicken_status_scm",(void*)f_800},
{"f_794:chicken_status_scm",(void*)f_794},
{"f_790:chicken_status_scm",(void*)f_790},
{"f_762:chicken_status_scm",(void*)f_762},
{"f_755:chicken_status_scm",(void*)f_755},
{"f_454:chicken_status_scm",(void*)f_454},
{"f_450:chicken_status_scm",(void*)f_450},
{"f_446:chicken_status_scm",(void*)f_446},
{"f_425:chicken_status_scm",(void*)f_425},
{"f_438:chicken_status_scm",(void*)f_438},
{"f_436:chicken_status_scm",(void*)f_436},
{"f_432:chicken_status_scm",(void*)f_432},
{"f_689:chicken_status_scm",(void*)f_689},
{"f_865:chicken_status_scm",(void*)f_865},
{"f_871:chicken_status_scm",(void*)f_871},
{"f_868:chicken_status_scm",(void*)f_868},
{"f_663:chicken_status_scm",(void*)f_663},
{"f_667:chicken_status_scm",(void*)f_667},
{"f_633:chicken_status_scm",(void*)f_633},
{"f_647:chicken_status_scm",(void*)f_647},
{"f_661:chicken_status_scm",(void*)f_661},
{"f_645:chicken_status_scm",(void*)f_645},
{"f_641:chicken_status_scm",(void*)f_641},
{"f_569:chicken_status_scm",(void*)f_569},
{"f_540:chicken_status_scm",(void*)f_540},
{"f_546:chicken_status_scm",(void*)f_546},
{"f_563:chicken_status_scm",(void*)f_563},
{"f_557:chicken_status_scm",(void*)f_557},
{"f_549:chicken_status_scm",(void*)f_549},
{"f_631:chicken_status_scm",(void*)f_631},
{"f_573:chicken_status_scm",(void*)f_573},
{"f_623:chicken_status_scm",(void*)f_623},
{"f_578:chicken_status_scm",(void*)f_578},
{"f_619:chicken_status_scm",(void*)f_619},
{"f_612:chicken_status_scm",(void*)f_612},
{"f_592:chicken_status_scm",(void*)f_592},
{"f_604:chicken_status_scm",(void*)f_604},
{"f_600:chicken_status_scm",(void*)f_600},
{"f_596:chicken_status_scm",(void*)f_596},
{"f_456:chicken_status_scm",(void*)f_456},
{"f_488:chicken_status_scm",(void*)f_488},
{"f_483:chicken_status_scm",(void*)f_483},
{"f_458:chicken_status_scm",(void*)f_458},
{"f_465:chicken_status_scm",(void*)f_465},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
