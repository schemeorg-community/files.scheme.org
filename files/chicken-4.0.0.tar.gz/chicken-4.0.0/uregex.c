/* Generated from regex.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2009-03-24 10:47
   Version 4.0.0 - SVN rev. 13887
   windows-mingw32-x86 [ manyargs dload ptables applyhook ]
   compiled 2009-03-24 on LENOVO-1 (MINGW32_NT-6.0)
   command line: regex.scm -no-trace -optimize-level 2 -include-path . -include-path ./ -feature debugbuild -explicit-use -unsafe -no-lambda-info -output-file uregex.c
   unit: regex
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);

static C_TLS C_word lf[332];
static double C_possibly_force_alignment;


C_noret_decl(C_regex_toplevel)
C_externexport void C_ccall C_regex_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4871)
static void C_ccall f_4871(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_21492)
static void C_ccall f_21492(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_21499)
static void C_ccall f_21499(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_21507)
static void C_fcall f_21507(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_21539)
static void C_ccall f_21539(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_21526)
static void C_ccall f_21526(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_21529)
static void C_ccall f_21529(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_21452)
static void C_ccall f_21452(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_21461)
static void C_fcall f_21461(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_21480)
static void C_ccall f_21480(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_21487)
static void C_ccall f_21487(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_21175)
static void C_ccall f_21175(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_21190)
static void C_ccall f_21190(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_21192)
static void C_fcall f_21192(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_21447)
static void C_ccall f_21447(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_21443)
static void C_ccall f_21443(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_21432)
static void C_ccall f_21432(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_21254)
static void C_fcall f_21254(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_21284)
static void C_fcall f_21284(C_word t0,C_word t1) C_noret;
C_noret_decl(f_21313)
static void C_fcall f_21313(C_word t0,C_word t1) C_noret;
C_noret_decl(f_21361)
static void C_ccall f_21361(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_21340)
static void C_ccall f_21340(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_21336)
static void C_ccall f_21336(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_21303)
static void C_ccall f_21303(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_21299)
static void C_ccall f_21299(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_21274)
static void C_ccall f_21274(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_21252)
static void C_ccall f_21252(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_21239)
static void C_ccall f_21239(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_21226)
static void C_ccall f_21226(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_21222)
static void C_ccall f_21222(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_21186)
static void C_ccall f_21186(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_21090)
static void C_ccall f_21090(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_21103)
static void C_fcall f_21103(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_21122)
static void C_fcall f_21122(C_word t0,C_word t1) C_noret;
C_noret_decl(f_21038)
static void C_ccall f_21038(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_21038)
static void C_ccall f_21038r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_21053)
static void C_fcall f_21053(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_21070)
static void C_ccall f_21070(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20786)
static void C_ccall f_20786(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_20786)
static void C_ccall f_20786r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_20925)
static void C_fcall f_20925(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_20929)
static void C_ccall f_20929(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_21020)
static void C_ccall f_21020(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_21016)
static void C_ccall f_21016(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20987)
static void C_ccall f_20987(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20969)
static void C_ccall f_20969(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20962)
static void C_ccall f_20962(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20819)
static void C_fcall f_20819(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_20825)
static void C_fcall f_20825(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_20892)
static void C_ccall f_20892(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20880)
static void C_ccall f_20880(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20839)
static void C_ccall f_20839(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20804)
static C_word C_fcall f_20804(C_word *a,C_word t0,C_word t1);
C_noret_decl(f_20604)
static void C_ccall f_20604(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_20604)
static void C_ccall f_20604r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_20768)
static void C_ccall f_20768(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_20742)
static void C_ccall f_20742(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_20767)
static void C_ccall f_20767(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20722)
static void C_ccall f_20722(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_20623)
static void C_fcall f_20623(C_word t0,C_word t1) C_noret;
C_noret_decl(f_20631)
static void C_fcall f_20631(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_20635)
static void C_ccall f_20635(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20696)
static void C_ccall f_20696(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20677)
static void C_ccall f_20677(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20711)
static void C_ccall f_20711(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_20706)
static void C_ccall f_20706(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_20484)
static void C_ccall f_20484(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_20484)
static void C_ccall f_20484r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_20559)
static void C_fcall f_20559(C_word t0,C_word t1) C_noret;
C_noret_decl(f_20550)
static void C_fcall f_20550(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_20486)
static void C_fcall f_20486(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_20490)
static void C_ccall f_20490(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20545)
static void C_ccall f_20545(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20499)
static void C_ccall f_20499(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20509)
static void C_ccall f_20509(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20511)
static void C_fcall f_20511(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_20372)
static void C_ccall f_20372(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_20372)
static void C_ccall f_20372r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_20439)
static void C_fcall f_20439(C_word t0,C_word t1) C_noret;
C_noret_decl(f_20430)
static void C_fcall f_20430(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_20374)
static void C_fcall f_20374(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_20378)
static void C_ccall f_20378(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20425)
static void C_ccall f_20425(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20387)
static void C_ccall f_20387(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20397)
static void C_ccall f_20397(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20399)
static void C_fcall f_20399(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_20421)
static void C_ccall f_20421(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20310)
static void C_ccall f_20310(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_20314)
static void C_ccall f_20314(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20317)
static void C_ccall f_20317(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20327)
static void C_ccall f_20327(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20329)
static void C_fcall f_20329(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_20264)
static void C_ccall f_20264(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_20268)
static void C_ccall f_20268(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20271)
static void C_ccall f_20271(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20281)
static void C_ccall f_20281(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20283)
static void C_fcall f_20283(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_20308)
static void C_ccall f_20308(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20243)
static void C_fcall f_20243(C_word t0,C_word t1) C_noret;
C_noret_decl(f_20250)
static void C_ccall f_20250(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20259)
static void C_ccall f_20259(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20140)
static void C_ccall f_20140(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_20140)
static void C_ccall f_20140r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_20183)
static void C_fcall f_20183(C_word t0,C_word t1) C_noret;
C_noret_decl(f_20178)
static void C_fcall f_20178(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_20173)
static void C_fcall f_20173(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_20142)
static void C_fcall f_20142(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_20154)
static void C_fcall f_20154(C_word t0,C_word t1) C_noret;
C_noret_decl(f_20157)
static void C_fcall f_20157(C_word t0,C_word t1) C_noret;
C_noret_decl(f_20160)
static void C_fcall f_20160(C_word t0,C_word t1) C_noret;
C_noret_decl(f_20150)
static void C_ccall f_20150(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20122)
static void C_ccall f_20122(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_19940)
static void C_fcall f_19940(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_19946)
static void C_fcall f_19946(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_20068)
static void C_ccall f_20068(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20072)
static void C_ccall f_20072(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20080)
static void C_ccall f_20080(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20064)
static void C_ccall f_20064(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20039)
static void C_ccall f_20039(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20043)
static void C_ccall f_20043(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20035)
static void C_ccall f_20035(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20002)
static void C_ccall f_20002(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_19974)
static void C_ccall f_19974(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_19884)
static void C_ccall f_19884(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_19884)
static void C_ccall f_19884r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_19723)
static void C_ccall f_19723(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_19726)
static void C_ccall f_19726(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_19809)
static void C_fcall f_19809(C_word t0,C_word t1) C_noret;
C_noret_decl(f_19780)
static void C_fcall f_19780(C_word t0,C_word t1) C_noret;
C_noret_decl(f_19743)
static void C_fcall f_19743(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_19756)
static void C_ccall f_19756(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_19768)
static void C_ccall f_19768(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_19771)
static void C_ccall f_19771(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_19774)
static void C_ccall f_19774(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_19829)
static void C_ccall f_19829(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_19917)
static void C_ccall f_19917(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_19938)
static void C_ccall f_19938(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_19928)
static void C_fcall f_19928(C_word t0,C_word t1) C_noret;
C_noret_decl(f_19890)
static void C_fcall f_19890(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_19894)
static void C_ccall f_19894(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_19901)
static void C_ccall f_19901(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_19915)
static void C_ccall f_19915(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_19905)
static void C_fcall f_19905(C_word t0,C_word t1) C_noret;
C_noret_decl(f_19832)
static void C_ccall f_19832(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_19832)
static void C_ccall f_19832r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_19882)
static void C_ccall f_19882(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_19836)
static void C_ccall f_19836(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_19874)
static void C_ccall f_19874(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_19850)
static void C_ccall f_19850(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_19858)
static void C_ccall f_19858(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_19870)
static void C_ccall f_19870(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_19866)
static void C_ccall f_19866(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_19854)
static void C_ccall f_19854(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_19554)
static void C_ccall f_19554(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_19560)
static void C_fcall f_19560(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_19576)
static void C_fcall f_19576(C_word t0,C_word t1) C_noret;
C_noret_decl(f_19613)
static void C_fcall f_19613(C_word t0,C_word t1) C_noret;
C_noret_decl(f_19671)
static void C_ccall f_19671(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_19628)
static void C_ccall f_19628(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_19624)
static void C_ccall f_19624(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_19596)
static void C_ccall f_19596(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_19544)
static void C_fcall f_19544(C_word t0,C_word t1) C_noret;
C_noret_decl(f_19552)
static void C_ccall f_19552(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_19426)
static void C_ccall f_19426(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_19432)
static void C_fcall f_19432(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_19534)
static void C_ccall f_19534(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_19442)
static void C_ccall f_19442(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_19509)
static void C_ccall f_19509(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_19450)
static void C_ccall f_19450(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_19501)
static void C_ccall f_19501(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_19454)
static void C_ccall f_19454(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_19463)
static void C_ccall f_19463(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_19466)
static void C_ccall f_19466(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_19473)
static void C_ccall f_19473(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_19305)
static void C_fcall f_19305(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_19412)
static void C_ccall f_19412(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_19328)
static void C_ccall f_19328(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_19387)
static void C_ccall f_19387(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_19336)
static void C_ccall f_19336(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_19379)
static void C_ccall f_19379(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_19340)
static void C_ccall f_19340(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_19349)
static void C_ccall f_19349(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_19352)
static void C_ccall f_19352(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_19218)
static void C_ccall f_19218(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_19295)
static void C_ccall f_19295(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_19228)
static void C_ccall f_19228(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_19274)
static void C_ccall f_19274(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_19246)
static void C_ccall f_19246(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_19238)
static void C_ccall f_19238(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_19073)
static void C_fcall f_19073(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_19089)
static void C_fcall f_19089(C_word t0,C_word t1) C_noret;
C_noret_decl(f_19061)
static C_word C_fcall f_19061(C_word *a,C_word t0);
C_noret_decl(f_19023)
static void C_fcall f_19023(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_19029)
static void C_ccall f_19029(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_18742)
static void C_fcall f_18742(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_18752)
static void C_fcall f_18752(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_18916)
static void C_ccall f_18916(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_18920)
static void C_ccall f_18920(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13500)
static void C_fcall f_13500(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_13527)
static void C_ccall f_13527(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13523)
static void C_ccall f_13523(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_18899)
static void C_ccall f_18899(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_18666)
static void C_fcall f_18666(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_18889)
static void C_ccall f_18889(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_18868)
static void C_ccall f_18868(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_18872)
static void C_ccall f_18872(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_18860)
static void C_ccall f_18860(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_18837)
static void C_ccall f_18837(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_18841)
static void C_ccall f_18841(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_18812)
static void C_ccall f_18812(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_18816)
static void C_ccall f_18816(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_18808)
static void C_ccall f_18808(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_18781)
static void C_ccall f_18781(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_18755)
static void C_ccall f_18755(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_18625)
static void C_fcall f_18625(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_18627)
static void C_ccall f_18627(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_18634)
static void C_ccall f_18634(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16261)
static void C_fcall f_16261(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_16301)
static void C_ccall f_16301(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16180)
static void C_fcall f_16180(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_16186)
static void C_fcall f_16186(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_16235)
static void C_ccall f_16235(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_16233)
static void C_ccall f_16233(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16225)
static void C_ccall f_16225(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16213)
static void C_ccall f_16213(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16217)
static void C_ccall f_16217(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16064)
static void C_fcall f_16064(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_16097)
static void C_fcall f_16097(C_word t0,C_word t1) C_noret;
C_noret_decl(f_16101)
static void C_fcall f_16101(C_word t0,C_word t1) C_noret;
C_noret_decl(f_16109)
static void C_fcall f_16109(C_word t0,C_word t1) C_noret;
C_noret_decl(f_16078)
static void C_ccall f_16078(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15990)
static void C_fcall f_15990(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_15998)
static void C_fcall f_15998(C_word t0,C_word t1) C_noret;
C_noret_decl(f_16002)
static void C_fcall f_16002(C_word t0,C_word t1) C_noret;
C_noret_decl(f_15978)
static C_word C_fcall f_15978(C_word *a,C_word t0,C_word t1);
C_noret_decl(f_15516)
static void C_fcall f_15516(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_15725)
static void C_fcall f_15725(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_15753)
static void C_fcall f_15753(C_word t0,C_word t1) C_noret;
C_noret_decl(f_15910)
static void C_fcall f_15910(C_word t0,C_word t1) C_noret;
C_noret_decl(f_15811)
static void C_fcall f_15811(C_word t0,C_word t1) C_noret;
C_noret_decl(f_15881)
static void C_ccall f_15881(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15816)
static void C_ccall f_15816(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_15869)
static void C_ccall f_15869(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15829)
static void C_fcall f_15829(C_word t0,C_word t1) C_noret;
C_noret_decl(f_15832)
static void C_fcall f_15832(C_word t0,C_word t1) C_noret;
C_noret_decl(f_15839)
static void C_ccall f_15839(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15797)
static void C_ccall f_15797(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15758)
static void C_ccall f_15758(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_15785)
static void C_ccall f_15785(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15769)
static void C_ccall f_15769(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15547)
static void C_fcall f_15547(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_15596)
static void C_fcall f_15596(C_word t0,C_word t1) C_noret;
C_noret_decl(f_15663)
static void C_ccall f_15663(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15601)
static void C_ccall f_15601(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_15651)
static void C_ccall f_15651(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15617)
static void C_fcall f_15617(C_word t0,C_word t1) C_noret;
C_noret_decl(f_15621)
static void C_fcall f_15621(C_word t0,C_word t1) C_noret;
C_noret_decl(f_15613)
static void C_ccall f_15613(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15582)
static void C_ccall f_15582(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15519)
static void C_fcall f_15519(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_15219)
static void C_fcall f_15219(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_15334)
static void C_ccall f_15334(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15232)
static void C_fcall f_15232(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_15427)
static void C_fcall f_15427(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_15506)
static void C_ccall f_15506(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15445)
static void C_ccall f_15445(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_15457)
static void C_ccall f_15457(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15265)
static void C_ccall f_15265(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15277)
static void C_fcall f_15277(C_word t0,C_word t1) C_noret;
C_noret_decl(f_15312)
static void C_ccall f_15312(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15284)
static void C_ccall f_15284(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15308)
static void C_ccall f_15308(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15300)
static void C_ccall f_15300(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15246)
static void C_ccall f_15246(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15411)
static void C_ccall f_15411(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15415)
static void C_ccall f_15415(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15354)
static void C_ccall f_15354(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15373)
static void C_ccall f_15373(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_15387)
static void C_ccall f_15387(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_15385)
static void C_ccall f_15385(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15371)
static void C_ccall f_15371(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15356)
static C_word C_fcall f_15356(C_word t0,C_word t1);
C_noret_decl(f_14429)
static void C_fcall f_14429(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_14447)
static void C_fcall f_14447(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_14710)
static void C_fcall f_14710(C_word t0,C_word t1) C_noret;
C_noret_decl(f_14764)
static void C_fcall f_14764(C_word t0,C_word t1) C_noret;
C_noret_decl(f_15024)
static void C_ccall f_15024(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15112)
static void C_ccall f_15112(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15030)
static void C_ccall f_15030(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15108)
static void C_ccall f_15108(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15033)
static void C_ccall f_15033(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15088)
static void C_ccall f_15088(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15039)
static void C_fcall f_15039(C_word t0,C_word t1) C_noret;
C_noret_decl(f_15058)
static void C_ccall f_15058(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14964)
static void C_ccall f_14964(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15008)
static void C_ccall f_15008(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14970)
static void C_ccall f_14970(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14992)
static void C_ccall f_14992(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14861)
static void C_ccall f_14861(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14943)
static void C_ccall f_14943(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14864)
static void C_ccall f_14864(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14928)
static void C_ccall f_14928(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14867)
static void C_ccall f_14867(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14893)
static void C_ccall f_14893(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14885)
static void C_ccall f_14885(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14889)
static void C_ccall f_14889(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14881)
static void C_ccall f_14881(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14852)
static void C_ccall f_14852(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14767)
static void C_ccall f_14767(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14794)
static void C_ccall f_14794(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14822)
static void C_ccall f_14822(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_14820)
static void C_ccall f_14820(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14808)
static void C_ccall f_14808(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14812)
static void C_ccall f_14812(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14783)
static void C_ccall f_14783(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14713)
static void C_ccall f_14713(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14716)
static void C_ccall f_14716(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14730)
static void C_ccall f_14730(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14693)
static void C_ccall f_14693(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14670)
static void C_ccall f_14670(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14593)
static void C_ccall f_14593(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14560)
static void C_fcall f_14560(C_word t0,C_word t1) C_noret;
C_noret_decl(f_14582)
static void C_ccall f_14582(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14567)
static void C_ccall f_14567(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14537)
static void C_ccall f_14537(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14516)
static void C_ccall f_14516(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14512)
static void C_ccall f_14512(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14464)
static void C_fcall f_14464(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_14479)
static void C_ccall f_14479(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14485)
static void C_ccall f_14485(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_14483)
static void C_ccall f_14483(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14450)
static void C_fcall f_14450(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_14322)
static void C_fcall f_14322(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_14336)
static void C_fcall f_14336(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_14374)
static void C_ccall f_14374(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_14349)
static void C_ccall f_14349(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14227)
static C_word C_fcall f_14227(C_word t0);
C_noret_decl(f_14217)
static C_word C_fcall f_14217(C_word t0,C_word t1);
C_noret_decl(f_14211)
static C_word C_fcall f_14211(C_word t0);
C_noret_decl(f_14144)
static void C_ccall f_14144(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_14148)
static void C_ccall f_14148(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14151)
static void C_ccall f_14151(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14163)
static void C_ccall f_14163(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14191)
static void C_ccall f_14191(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14208)
static void C_ccall f_14208(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14194)
static void C_ccall f_14194(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14188)
static void C_ccall f_14188(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14166)
static void C_ccall f_14166(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14184)
static void C_ccall f_14184(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14181)
static void C_ccall f_14181(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13985)
static void C_ccall f_13985(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_13992)
static void C_ccall f_13992(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14108)
static void C_ccall f_14108(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14113)
static void C_fcall f_14113(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_14141)
static void C_ccall f_14141(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14123)
static void C_ccall f_14123(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14105)
static void C_ccall f_14105(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13998)
static void C_ccall f_13998(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14101)
static void C_ccall f_14101(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14243)
static void C_fcall f_14243(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_14278)
static void C_ccall f_14278(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_14262)
static void C_ccall f_14262(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14023)
static void C_ccall f_14023(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14097)
static void C_ccall f_14097(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14032)
static void C_ccall f_14032(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14038)
static void C_ccall f_14038(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14043)
static void C_fcall f_14043(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_14053)
static void C_ccall f_14053(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14068)
static void C_ccall f_14068(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14065)
static void C_ccall f_14065(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14020)
static void C_ccall f_14020(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14001)
static void C_ccall f_14001(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14016)
static void C_ccall f_14016(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14013)
static void C_ccall f_14013(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13939)
static void C_ccall f_13939(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_13939)
static void C_ccall f_13939r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_13943)
static void C_ccall f_13943(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13961)
static void C_fcall f_13961(C_word t0,C_word t1) C_noret;
C_noret_decl(f_13952)
static void C_ccall f_13952(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13822)
static void C_ccall f_13822(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_13841)
static void C_fcall f_13841(C_word t0,C_word t1) C_noret;
C_noret_decl(f_13912)
static void C_ccall f_13912(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13879)
static void C_ccall f_13879(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13786)
static void C_fcall f_13786(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_13816)
static void C_ccall f_13816(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13808)
static void C_ccall f_13808(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13556)
static void C_fcall f_13556(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_13654)
static void C_fcall f_13654(C_word t0,C_word t1) C_noret;
C_noret_decl(f_13441)
static void C_ccall f_13441(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_13416)
static C_word C_fcall f_13416(C_word *a,C_word t0);
C_noret_decl(f_13391)
static C_word C_fcall f_13391(C_word *a,C_word t0);
C_noret_decl(f_12296)
static void C_fcall f_12296(C_word t0,C_word t1) C_noret;
C_noret_decl(f_12302)
static void C_ccall f_12302(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_12327)
static void C_fcall f_12327(C_word t0,C_word t1) C_noret;
C_noret_decl(f_12270)
static void C_ccall f_12270(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12184)
static void C_ccall f_12184(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12223)
static void C_fcall f_12223(C_word t0,C_word t1) C_noret;
C_noret_decl(f_12236)
static void C_ccall f_12236(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12098)
static void C_ccall f_12098(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12137)
static void C_fcall f_12137(C_word t0,C_word t1) C_noret;
C_noret_decl(f_12042)
static C_word C_fcall f_12042(C_word t0);
C_noret_decl(f_11966)
static void C_ccall f_11966(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11991)
static void C_fcall f_11991(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11838)
static void C_ccall f_11838(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11857)
static void C_fcall f_11857(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11906)
static void C_fcall f_11906(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11697)
static void C_ccall f_11697(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_11697)
static void C_ccall f_11697r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_11701)
static void C_ccall f_11701(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11384)
static void C_ccall f_11384(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11388)
static void C_ccall f_11388(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11390)
static void C_fcall f_11390(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_11644)
static void C_ccall f_11644(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11655)
static void C_ccall f_11655(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11651)
static void C_ccall f_11651(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11503)
static void C_fcall f_11503(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11607)
static void C_ccall f_11607(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11588)
static void C_ccall f_11588(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11512)
static void C_ccall f_11512(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11533)
static void C_ccall f_11533(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11543)
static void C_ccall f_11543(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11518)
static void C_ccall f_11518(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11528)
static void C_ccall f_11528(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11486)
static void C_ccall f_11486(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11484)
static void C_ccall f_11484(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11459)
static void C_ccall f_11459(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11457)
static void C_ccall f_11457(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11393)
static void C_ccall f_11393(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11704)
static void C_ccall f_11704(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11707)
static void C_ccall f_11707(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11710)
static void C_ccall f_11710(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11713)
static void C_fcall f_11713(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11787)
static void C_ccall f_11787(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11716)
static void C_ccall f_11716(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11719)
static void C_ccall f_11719(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11722)
static void C_ccall f_11722(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16317)
static void C_fcall f_16317(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_16641)
static void C_ccall f_16641(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16331)
static void C_ccall f_16331(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_16344)
static void C_ccall f_16344(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16335)
static void C_ccall f_16335(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16336)
static void C_ccall f_16336(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_16592)
static void C_ccall f_16592(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16593)
static void C_ccall f_16593(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_16597)
static void C_ccall f_16597(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16600)
static void C_fcall f_16600(C_word t0,C_word t1) C_noret;
C_noret_decl(f_16567)
static void C_ccall f_16567(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16568)
static void C_ccall f_16568(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_16572)
static void C_ccall f_16572(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16511)
static void C_ccall f_16511(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16536)
static void C_ccall f_16536(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_16540)
static void C_ccall f_16540(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16513)
static void C_ccall f_16513(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_16517)
static void C_ccall f_16517(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16461)
static void C_ccall f_16461(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16486)
static void C_ccall f_16486(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16464)
static void C_ccall f_16464(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16465)
static void C_ccall f_16465(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_16469)
static void C_ccall f_16469(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16368)
static void C_ccall f_16368(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16437)
static void C_ccall f_16437(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16371)
static void C_ccall f_16371(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16372)
static void C_ccall f_16372(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_16378)
static void C_fcall f_16378(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_16388)
static void C_ccall f_16388(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16391)
static void C_ccall f_16391(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11725)
static void C_ccall f_11725(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11728)
static void C_ccall f_11728(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11731)
static void C_ccall f_11731(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12359)
static void C_ccall f_12359(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13380)
static void C_ccall f_13380(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12362)
static void C_ccall f_12362(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12371)
static void C_fcall f_12371(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_12416)
static void C_fcall f_12416(C_word t0,C_word t1) C_noret;
C_noret_decl(f_12445)
static void C_fcall f_12445(C_word t0,C_word t1) C_noret;
C_noret_decl(f_13175)
static void C_fcall f_13175(C_word t0,C_word t1) C_noret;
C_noret_decl(f_13225)
static void C_fcall f_13225(C_word t0,C_word t1) C_noret;
C_noret_decl(f_13202)
static void C_ccall f_13202(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13148)
static void C_ccall f_13148(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_13118)
static void C_ccall f_13118(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_12974)
static void C_fcall f_12974(C_word t0,C_word t1) C_noret;
C_noret_decl(f_12977)
static void C_fcall f_12977(C_word t0,C_word t1) C_noret;
C_noret_decl(f_13042)
static void C_ccall f_13042(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_12995)
static void C_ccall f_12995(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_13007)
static void C_fcall f_13007(C_word t0,C_word t1) C_noret;
C_noret_decl(f_12954)
static void C_ccall f_12954(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_12945)
static void C_ccall f_12945(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12832)
static void C_ccall f_12832(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12895)
static void C_ccall f_12895(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12841)
static void C_fcall f_12841(C_word t0,C_word t1) C_noret;
C_noret_decl(f_12792)
static void C_ccall f_12792(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_12621)
static void C_fcall f_12621(C_word t0,C_word t1) C_noret;
C_noret_decl(f_12627)
static void C_ccall f_12627(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12630)
static void C_ccall f_12630(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12712)
static void C_fcall f_12712(C_word t0,C_word t1) C_noret;
C_noret_decl(f_12639)
static void C_ccall f_12639(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_12653)
static void C_ccall f_12653(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_12665)
static void C_ccall f_12665(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12667)
static void C_ccall f_12667(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_12696)
static void C_ccall f_12696(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12692)
static void C_ccall f_12692(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12679)
static void C_fcall f_12679(C_word t0,C_word t1) C_noret;
C_noret_decl(f_12536)
static void C_fcall f_12536(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_12569)
static void C_ccall f_12569(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_12602)
static void C_ccall f_12602(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12585)
static void C_ccall f_12585(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12589)
static void C_ccall f_12589(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12454)
static void C_fcall f_12454(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_12487)
static void C_ccall f_12487(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_12517)
static void C_ccall f_12517(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12432)
static void C_ccall f_12432(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12374)
static void C_fcall f_12374(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12369)
static void C_ccall f_12369(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11753)
static void C_ccall f_11753(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11760)
static void C_ccall f_11760(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11737)
static void C_ccall f_11737(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_18607)
static void C_fcall f_18607(C_word t0,C_word t1) C_noret;
C_noret_decl(f_16648)
static void C_ccall f_16648(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16660)
static void C_fcall f_16660(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_18595)
static void C_ccall f_18595(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_18514)
static void C_ccall f_18514(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_18547)
static void C_ccall f_18547(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_18554)
static void C_fcall f_18554(C_word t0,C_word t1) C_noret;
C_noret_decl(f_18515)
static void C_ccall f_18515(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_18522)
static void C_ccall f_18522(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_18418)
static void C_ccall f_18418(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_18425)
static void C_fcall f_18425(C_word t0,C_word t1) C_noret;
C_noret_decl(f_18360)
static void C_ccall f_18360(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_18379)
static void C_fcall f_18379(C_word t0,C_word t1) C_noret;
C_noret_decl(f_18367)
static void C_fcall f_18367(C_word t0,C_word t1) C_noret;
C_noret_decl(f_18326)
static void C_ccall f_18326(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_18336)
static void C_fcall f_18336(C_word t0,C_word t1) C_noret;
C_noret_decl(f_18302)
static void C_ccall f_18302(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_18244)
static void C_ccall f_18244(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_18263)
static void C_fcall f_18263(C_word t0,C_word t1) C_noret;
C_noret_decl(f_18251)
static void C_fcall f_18251(C_word t0,C_word t1) C_noret;
C_noret_decl(f_18210)
static void C_ccall f_18210(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_18220)
static void C_fcall f_18220(C_word t0,C_word t1) C_noret;
C_noret_decl(f_18190)
static void C_ccall f_18190(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_18148)
static void C_ccall f_18148(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_18155)
static void C_fcall f_18155(C_word t0,C_word t1) C_noret;
C_noret_decl(f_18120)
static void C_ccall f_18120(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_16706)
static void C_fcall f_16706(C_word t0,C_word t1) C_noret;
C_noret_decl(f_18072)
static void C_ccall f_18072(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_18032)
static void C_ccall f_18032(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_18044)
static void C_ccall f_18044(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_18002)
static void C_ccall f_18002(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_18003)
static void C_ccall f_18003(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_18015)
static void C_ccall f_18015(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17875)
static void C_ccall f_17875(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17931)
static void C_ccall f_17931(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17879)
static void C_ccall f_17879(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_17883)
static void C_ccall f_17883(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17917)
static void C_ccall f_17917(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17901)
static void C_ccall f_17901(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17733)
static void C_ccall f_17733(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17736)
static void C_ccall f_17736(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17843)
static void C_ccall f_17843(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_17838)
static void C_ccall f_17838(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17834)
static void C_ccall f_17834(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17739)
static void C_ccall f_17739(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17748)
static void C_fcall f_17748(C_word t0,C_word t1) C_noret;
C_noret_decl(f_17794)
static void C_ccall f_17794(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17795)
static void C_ccall f_17795(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_17801)
static void C_ccall f_17801(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17751)
static void C_ccall f_17751(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17752)
static void C_ccall f_17752(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_17719)
static void C_ccall f_17719(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_17696)
static void C_ccall f_17696(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17697)
static void C_ccall f_17697(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_17712)
static void C_ccall f_17712(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17701)
static void C_ccall f_17701(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17678)
static void C_ccall f_17678(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_17647)
static void C_ccall f_17647(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17648)
static void C_ccall f_17648(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_17669)
static void C_ccall f_17669(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17671)
static void C_ccall f_17671(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17665)
static void C_ccall f_17665(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17629)
static void C_ccall f_17629(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_17598)
static void C_ccall f_17598(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17599)
static void C_ccall f_17599(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_17620)
static void C_ccall f_17620(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17622)
static void C_ccall f_17622(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17616)
static void C_ccall f_17616(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17584)
static void C_ccall f_17584(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_17561)
static void C_ccall f_17561(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17562)
static void C_ccall f_17562(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_17577)
static void C_ccall f_17577(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17569)
static void C_ccall f_17569(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17547)
static void C_ccall f_17547(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_17524)
static void C_ccall f_17524(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17525)
static void C_ccall f_17525(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_17540)
static void C_ccall f_17540(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17532)
static void C_ccall f_17532(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17511)
static void C_ccall f_17511(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17486)
static void C_ccall f_17486(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17421)
static void C_ccall f_17421(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17234)
static void C_fcall f_17234(C_word t0,C_word t1) C_noret;
C_noret_decl(f_17237)
static void C_fcall f_17237(C_word t0,C_word t1) C_noret;
C_noret_decl(f_17260)
static void C_ccall f_17260(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17326)
static void C_ccall f_17326(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17310)
static void C_ccall f_17310(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_17263)
static void C_ccall f_17263(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17295)
static void C_ccall f_17295(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17290)
static void C_ccall f_17290(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_17284)
static void C_ccall f_17284(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17280)
static void C_ccall f_17280(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17238)
static void C_ccall f_17238(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_17215)
static void C_ccall f_17215(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17182)
static void C_ccall f_17182(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17133)
static void C_ccall f_17133(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17070)
static void C_ccall f_17070(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17094)
static void C_ccall f_17094(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_17100)
static void C_ccall f_17100(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17077)
static void C_ccall f_17077(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17078)
static void C_ccall f_17078(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_17084)
static void C_ccall f_17084(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17012)
static void C_ccall f_17012(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17036)
static void C_ccall f_17036(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_17042)
static void C_ccall f_17042(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17019)
static void C_ccall f_17019(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17020)
static void C_ccall f_17020(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_17026)
static void C_ccall f_17026(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16981)
static void C_ccall f_16981(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16982)
static void C_ccall f_16982(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_16988)
static void C_ccall f_16988(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16953)
static void C_ccall f_16953(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16954)
static void C_ccall f_16954(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_16960)
static void C_ccall f_16960(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16932)
static void C_ccall f_16932(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16913)
static void C_ccall f_16913(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16875)
static void C_ccall f_16875(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16854)
static void C_ccall f_16854(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16833)
static void C_ccall f_16833(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16812)
static void C_ccall f_16812(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16753)
static void C_ccall f_16753(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16779)
static void C_ccall f_16779(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16756)
static void C_ccall f_16756(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16757)
static void C_ccall f_16757(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_16763)
static void C_ccall f_16763(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16733)
static void C_ccall f_16733(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_16717)
static void C_ccall f_16717(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16713)
static void C_ccall f_16713(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16694)
static void C_ccall f_16694(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16686)
static void C_ccall f_16686(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16663)
static void C_fcall f_16663(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_16657)
static void C_ccall f_16657(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_11746)
static void C_ccall f_11746(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11687)
static void C_ccall f_11687(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_11687)
static void C_ccall f_11687r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_11695)
static void C_ccall f_11695(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11666)
static void C_ccall f_11666(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_11666)
static void C_ccall f_11666r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_11673)
static void C_ccall f_11673(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11216)
static void C_fcall f_11216(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11222)
static void C_fcall f_11222(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_11310)
static void C_ccall f_11310(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11313)
static void C_ccall f_11313(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10375)
static void C_ccall f_10375(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10378)
static void C_ccall f_10378(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11079)
static void C_ccall f_11079(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11077)
static void C_ccall f_11077(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11057)
static void C_ccall f_11057(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11053)
static void C_ccall f_11053(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10971)
static void C_ccall f_10971(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11049)
static void C_ccall f_11049(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11045)
static void C_ccall f_11045(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11041)
static void C_ccall f_11041(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11037)
static void C_ccall f_11037(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11013)
static void C_ccall f_11013(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10989)
static void C_ccall f_10989(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10987)
static void C_ccall f_10987(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10879)
static void C_ccall f_10879(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10953)
static void C_ccall f_10953(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10901)
static void C_ccall f_10901(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10899)
static void C_ccall f_10899(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10871)
static void C_ccall f_10871(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10399)
static void C_ccall f_10399(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10404)
static void C_fcall f_10404(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10476)
static void C_ccall f_10476(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11154)
static void C_fcall f_11154(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11160)
static void C_ccall f_11160(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11158)
static void C_ccall f_11158(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10484)
static void C_ccall f_10484(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10461)
static void C_ccall f_10461(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10465)
static void C_ccall f_10465(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10432)
static void C_ccall f_10432(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11328)
static void C_ccall f_11328(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11270)
static void C_ccall f_11270(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11240)
static void C_ccall f_11240(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11258)
static void C_ccall f_11258(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11244)
static void C_fcall f_11244(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11236)
static void C_ccall f_11236(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10732)
static void C_fcall f_10732(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10850)
static void C_ccall f_10850(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10842)
static void C_ccall f_10842(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10834)
static void C_ccall f_10834(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10802)
static void C_ccall f_10802(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10830)
static void C_ccall f_10830(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10798)
static void C_ccall f_10798(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10754)
static void C_ccall f_10754(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10752)
static void C_ccall f_10752(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10604)
static void C_fcall f_10604(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10722)
static void C_ccall f_10722(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10714)
static void C_ccall f_10714(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10706)
static void C_ccall f_10706(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10674)
static void C_ccall f_10674(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10702)
static void C_ccall f_10702(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10670)
static void C_ccall f_10670(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10626)
static void C_ccall f_10626(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10624)
static void C_ccall f_10624(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10518)
static void C_fcall f_10518(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_10552)
static void C_ccall f_10552(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10560)
static void C_ccall f_10560(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10570)
static void C_ccall f_10570(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10568)
static void C_ccall f_10568(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10564)
static void C_ccall f_10564(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10548)
static void C_ccall f_10548(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10242)
static void C_fcall f_10242(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10366)
static void C_ccall f_10366(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10330)
static void C_ccall f_10330(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10362)
static void C_ccall f_10362(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10358)
static void C_ccall f_10358(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10334)
static void C_ccall f_10334(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10354)
static void C_ccall f_10354(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10350)
static void C_ccall f_10350(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10338)
static void C_ccall f_10338(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10346)
static void C_ccall f_10346(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10342)
static void C_ccall f_10342(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10317)
static void C_ccall f_10317(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10293)
static void C_ccall f_10293(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10313)
static void C_ccall f_10313(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10309)
static void C_ccall f_10309(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10297)
static void C_ccall f_10297(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10305)
static void C_ccall f_10305(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10301)
static void C_ccall f_10301(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10280)
static void C_ccall f_10280(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10268)
static void C_ccall f_10268(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10276)
static void C_ccall f_10276(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10272)
static void C_ccall f_10272(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10182)
static void C_fcall f_10182(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9957)
static void C_fcall f_9957(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10132)
static void C_ccall f_10132(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10084)
static void C_ccall f_10084(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10120)
static void C_ccall f_10120(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10088)
static void C_ccall f_10088(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10108)
static void C_ccall f_10108(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10092)
static void C_ccall f_10092(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10096)
static void C_ccall f_10096(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10080)
static void C_ccall f_10080(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10063)
static void C_ccall f_10063(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10031)
static void C_ccall f_10031(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10051)
static void C_ccall f_10051(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10035)
static void C_ccall f_10035(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10039)
static void C_ccall f_10039(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10027)
static void C_ccall f_10027(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10010)
static void C_ccall f_10010(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9994)
static void C_ccall f_9994(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9998)
static void C_ccall f_9998(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9960)
static C_word C_fcall f_9960(C_word t0,C_word t1);
C_noret_decl(f_9947)
static C_word C_fcall f_9947(C_word t0);
C_noret_decl(f_9937)
static void C_ccall f_9937(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9214)
static void C_fcall f_9214(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9281)
static void C_ccall f_9281(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9284)
static void C_ccall f_9284(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5364)
static void C_fcall f_5364(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9233)
static void C_ccall f_9233(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9245)
static void C_ccall f_9245(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9248)
static void C_ccall f_9248(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9172)
static C_word C_fcall f_9172(C_word t0);
C_noret_decl(f_6263)
static void C_ccall f_6263(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6263)
static void C_ccall f_6263r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6270)
static void C_ccall f_6270(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6275)
static void C_fcall f_6275(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_9121)
static void C_ccall f_9121(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9124)
static void C_ccall f_9124(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9142)
static void C_ccall f_9142(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9087)
static void C_ccall f_9087(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9102)
static void C_ccall f_9102(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9075)
static void C_ccall f_9075(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9072)
static void C_ccall f_9072(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9044)
static void C_ccall f_9044(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9041)
static void C_ccall f_9041(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9013)
static void C_ccall f_9013(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8980)
static void C_ccall f_8980(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8962)
static void C_ccall f_8962(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5422)
static void C_fcall f_5422(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8870)
static void C_ccall f_8870(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8913)
static void C_ccall f_8913(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8906)
static void C_ccall f_8906(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8902)
static void C_ccall f_8902(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8894)
static void C_ccall f_8894(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8890)
static void C_ccall f_8890(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8756)
static void C_ccall f_8756(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8765)
static void C_fcall f_8765(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8827)
static void C_ccall f_8827(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8672)
static void C_fcall f_8672(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8675)
static void C_ccall f_8675(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8678)
static void C_ccall f_8678(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8728)
static void C_ccall f_8728(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8725)
static void C_ccall f_8725(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8717)
static void C_ccall f_8717(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8713)
static void C_ccall f_8713(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8647)
static void C_ccall f_8647(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8619)
static void C_ccall f_8619(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8643)
static void C_ccall f_8643(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8639)
static void C_ccall f_8639(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8608)
static void C_ccall f_8608(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8604)
static void C_ccall f_8604(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8579)
static void C_ccall f_8579(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8575)
static void C_ccall f_8575(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8550)
static void C_ccall f_8550(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8546)
static void C_ccall f_8546(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8521)
static void C_ccall f_8521(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8517)
static void C_ccall f_8517(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8492)
static void C_ccall f_8492(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8488)
static void C_ccall f_8488(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8459)
static void C_ccall f_8459(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8455)
static void C_ccall f_8455(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8422)
static void C_ccall f_8422(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8418)
static void C_ccall f_8418(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8393)
static void C_ccall f_8393(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8389)
static void C_ccall f_8389(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8356)
static void C_ccall f_8356(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8352)
static void C_ccall f_8352(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8303)
static void C_ccall f_8303(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8299)
static void C_ccall f_8299(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8258)
static void C_ccall f_8258(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8254)
static void C_ccall f_8254(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8221)
static void C_ccall f_8221(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8217)
static void C_ccall f_8217(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8188)
static void C_ccall f_8188(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8184)
static void C_ccall f_8184(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8155)
static void C_ccall f_8155(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8151)
static void C_ccall f_8151(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8122)
static void C_ccall f_8122(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8118)
static void C_ccall f_8118(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8052)
static void C_fcall f_8052(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7871)
static void C_fcall f_7871(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7881)
static void C_ccall f_7881(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7890)
static void C_ccall f_7890(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8034)
static void C_ccall f_8034(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5463)
static void C_fcall f_5463(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5508)
static void C_ccall f_5508(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5487)
static void C_ccall f_5487(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5466)
static void C_fcall f_5466(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5474)
static void C_ccall f_5474(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7893)
static void C_ccall f_7893(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7896)
static void C_ccall f_7896(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7902)
static void C_ccall f_7902(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8000)
static void C_ccall f_8000(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7965)
static void C_ccall f_7965(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7931)
static void C_ccall f_7931(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9325)
static void C_ccall f_9325(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9928)
static void C_ccall f_9928(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9327)
static void C_fcall f_9327(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9875)
static void C_ccall f_9875(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9893)
static void C_ccall f_9893(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9741)
static void C_fcall f_9741(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9802)
static void C_ccall f_9802(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9786)
static void C_ccall f_9786(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9771)
static void C_ccall f_9771(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9744)
static void C_ccall f_9744(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9767)
static void C_ccall f_9767(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9755)
static void C_ccall f_9755(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9763)
static void C_ccall f_9763(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9759)
static void C_ccall f_9759(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9616)
static void C_ccall f_9616(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9625)
static void C_fcall f_9625(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9668)
static void C_ccall f_9668(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9664)
static void C_ccall f_9664(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9631)
static void C_ccall f_9631(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9634)
static void C_ccall f_9634(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9657)
static void C_ccall f_9657(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9645)
static void C_ccall f_9645(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9653)
static void C_ccall f_9653(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9649)
static void C_ccall f_9649(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9564)
static void C_fcall f_9564(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9477)
static void C_fcall f_9477(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9540)
static void C_ccall f_9540(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9509)
static void C_ccall f_9509(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9525)
static void C_ccall f_9525(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9366)
static void C_ccall f_9366(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9369)
static void C_ccall f_9369(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5968)
static void C_fcall f_5968(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5992)
static void C_ccall f_5992(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5989)
static void C_fcall f_5989(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9372)
static void C_ccall f_9372(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9445)
static void C_ccall f_9445(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9449)
static void C_ccall f_9449(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9441)
static void C_ccall f_9441(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9437)
static void C_ccall f_9437(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9392)
static void C_fcall f_9392(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9420)
static void C_ccall f_9420(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9402)
static void C_ccall f_9402(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_18707)
static void C_fcall f_18707(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9413)
static void C_ccall f_9413(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9396)
static void C_fcall f_9396(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9379)
static void C_ccall f_9379(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7852)
static void C_ccall f_7852(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7828)
static void C_ccall f_7828(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7848)
static void C_ccall f_7848(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7813)
static void C_ccall f_7813(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7078)
static void C_ccall f_7078(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7082)
static void C_ccall f_7082(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7547)
static void C_fcall f_7547(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7732)
static void C_ccall f_7732(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7744)
static void C_ccall f_7744(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7711)
static void C_ccall f_7711(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7707)
static void C_ccall f_7707(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7662)
static void C_ccall f_7662(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7642)
static void C_ccall f_7642(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7625)
static void C_ccall f_7625(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7608)
static void C_ccall f_7608(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7559)
static void C_fcall f_7559(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7563)
static void C_ccall f_7563(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7566)
static void C_ccall f_7566(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7550)
static void C_fcall f_7550(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7505)
static void C_ccall f_7505(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7509)
static void C_ccall f_7509(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7448)
static void C_ccall f_7448(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7482)
static void C_ccall f_7482(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7451)
static void C_ccall f_7451(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7466)
static void C_ccall f_7466(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7474)
static void C_ccall f_7474(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7388)
static void C_ccall f_7388(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7431)
static void C_ccall f_7431(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7391)
static void C_ccall f_7391(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7415)
static void C_ccall f_7415(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7423)
static void C_ccall f_7423(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7360)
static void C_ccall f_7360(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7364)
static void C_ccall f_7364(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7268)
static void C_ccall f_7268(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7286)
static void C_ccall f_7286(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7306)
static void C_ccall f_7306(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7298)
static void C_ccall f_7298(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7294)
static void C_ccall f_7294(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7261)
static void C_ccall f_7261(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7265)
static void C_ccall f_7265(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7236)
static void C_ccall f_7236(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7240)
static void C_ccall f_7240(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7193)
static void C_ccall f_7193(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7197)
static void C_ccall f_7197(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7168)
static void C_ccall f_7168(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7172)
static void C_ccall f_7172(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7143)
static void C_ccall f_7143(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7147)
static void C_ccall f_7147(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7103)
static void C_ccall f_7103(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7118)
static void C_ccall f_7118(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6991)
static void C_ccall f_6991(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6997)
static void C_ccall f_6997(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7012)
static void C_ccall f_7012(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6794)
static void C_ccall f_6794(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6961)
static void C_ccall f_6961(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6932)
static void C_ccall f_6932(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6907)
static void C_ccall f_6907(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6890)
static void C_ccall f_6890(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6873)
static void C_ccall f_6873(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6848)
static void C_ccall f_6848(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6825)
static void C_fcall f_6825(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6785)
static void C_ccall f_6785(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6782)
static void C_ccall f_6782(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6720)
static void C_fcall f_6720(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6732)
static void C_ccall f_6732(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6420)
static void C_fcall f_6420(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6424)
static void C_ccall f_6424(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6718)
static void C_ccall f_6718(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6427)
static void C_fcall f_6427(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6680)
static void C_fcall f_6680(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6691)
static void C_ccall f_6691(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6430)
static void C_fcall f_6430(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6673)
static void C_ccall f_6673(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6662)
static void C_ccall f_6662(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6433)
static void C_ccall f_6433(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6438)
static void C_fcall f_6438(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6602)
static void C_ccall f_6602(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6540)
static void C_fcall f_6540(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6507)
static void C_fcall f_6507(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6441)
static C_word C_fcall f_6441(C_word *a,C_word t0);
C_noret_decl(f_6348)
static void C_fcall f_6348(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6352)
static void C_ccall f_6352(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10147)
static void C_fcall f_10147(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6355)
static void C_ccall f_6355(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6392)
static void C_ccall f_6392(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6364)
static void C_ccall f_6364(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6388)
static void C_ccall f_6388(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6384)
static void C_ccall f_6384(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6328)
static void C_fcall f_6328(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6346)
static void C_ccall f_6346(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6342)
static void C_ccall f_6342(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6308)
static void C_fcall f_6308(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6315)
static void C_ccall f_6315(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6326)
static void C_ccall f_6326(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6322)
static void C_ccall f_6322(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6278)
static void C_ccall f_6278(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6303)
static void C_ccall f_6303(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6163)
static void C_fcall f_6163(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6169)
static void C_fcall f_6169(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6200)
static void C_fcall f_6200(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6194)
static void C_fcall f_6194(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6187)
static void C_ccall f_6187(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6144)
static void C_ccall f_6144(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6135)
static void C_ccall f_6135(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6125)
static void C_fcall f_6125(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6133)
static void C_ccall f_6133(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6078)
static void C_fcall f_6078(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6110)
static void C_ccall f_6110(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6114)
static void C_ccall f_6114(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6106)
static void C_ccall f_6106(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6031)
static void C_fcall f_6031(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6063)
static void C_ccall f_6063(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6067)
static void C_ccall f_6067(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6059)
static void C_ccall f_6059(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6015)
static void C_fcall f_6015(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6023)
static void C_ccall f_6023(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6005)
static void C_fcall f_6005(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6013)
static void C_ccall f_6013(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5919)
static void C_fcall f_5919(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5925)
static void C_fcall f_5925(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5949)
static void C_ccall f_5949(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5946)
static void C_fcall f_5946(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5889)
static void C_fcall f_5889(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5895)
static void C_fcall f_5895(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5913)
static void C_ccall f_5913(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5840)
static void C_fcall f_5840(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5860)
static void C_fcall f_5860(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5876)
static void C_ccall f_5876(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5791)
static void C_fcall f_5791(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5811)
static void C_fcall f_5811(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5824)
static void C_ccall f_5824(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5749)
static void C_fcall f_5749(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5764)
static C_word C_fcall f_5764(C_word t0);
C_noret_decl(f_5717)
static void C_fcall f_5717(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5723)
static void C_fcall f_5723(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5736)
static void C_ccall f_5736(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5705)
static void C_fcall f_5705(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5709)
static void C_ccall f_5709(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5662)
static void C_fcall f_5662(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5668)
static void C_fcall f_5668(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5675)
static void C_fcall f_5675(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5623)
static void C_fcall f_5623(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5639)
static void C_fcall f_5639(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5566)
static void C_fcall f_5566(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5576)
static void C_ccall f_5576(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5574)
static void C_ccall f_5574(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5590)
static void C_ccall f_5590(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5595)
static void C_fcall f_5595(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5539)
static void C_fcall f_5539(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5614)
static void C_ccall f_5614(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5593)
static void C_ccall f_5593(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5521)
static C_word C_fcall f_5521(C_word t0);
C_noret_decl(f_5306)
static void C_fcall f_5306(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5319)
static void C_fcall f_5319(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5291)
static void C_ccall f_5291(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5291)
static void C_ccall f_5291r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5299)
static void C_ccall f_5299(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5268)
static void C_ccall f_5268(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5268)
static void C_ccall f_5268r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5272)
static void C_ccall f_5272(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5225)
static void C_ccall f_5225(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5225)
static void C_ccall f_5225r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5229)
static void C_ccall f_5229(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5242)
static void C_ccall f_5242(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5193)
static C_word C_fcall f_5193(C_word *a,C_word t0,C_word t1);
C_noret_decl(f_5147)
static void C_fcall f_5147(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5133)
static C_word C_fcall f_5133(C_word *a,C_word t0,C_word t1,C_word t2);
C_noret_decl(f_5119)
static C_word C_fcall f_5119(C_word *a,C_word t0,C_word t1,C_word t2);
C_noret_decl(f_5105)
static C_word C_fcall f_5105(C_word *a,C_word t0,C_word t1);
C_noret_decl(f_5091)
static C_word C_fcall f_5091(C_word *a,C_word t0,C_word t1);
C_noret_decl(f_5085)
static C_word C_fcall f_5085(C_word t0,C_word t1);
C_noret_decl(f_5073)
static void C_ccall f_5073(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5055)
static void C_ccall f_5055(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5063)
static void C_ccall f_5063(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5002)
static void C_ccall f_5002(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4968)
static void C_ccall f_4968(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4978)
static void C_fcall f_4978(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4954)
static void C_ccall f_4954(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4962)
static void C_ccall f_4962(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4966)
static void C_ccall f_4966(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5032)
static void C_ccall f_5032(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4948)
static void C_ccall f_4948(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4942)
static void C_ccall f_4942(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4936)
static void C_ccall f_4936(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4930)
static void C_ccall f_4930(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4924)
static void C_ccall f_4924(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4918)
static void C_ccall f_4918(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4912)
static void C_ccall f_4912(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4906)
static void C_ccall f_4906(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4880)
static void C_ccall f_4880(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4874)
static C_word C_fcall f_4874(C_word *a,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7);

C_noret_decl(trf_21507)
static void C_fcall trf_21507(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_21507(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_21507(t0,t1,t2);}

C_noret_decl(trf_21461)
static void C_fcall trf_21461(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_21461(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_21461(t0,t1,t2);}

C_noret_decl(trf_21192)
static void C_fcall trf_21192(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_21192(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_21192(t0,t1,t2);}

C_noret_decl(trf_21254)
static void C_fcall trf_21254(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_21254(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_21254(t0,t1,t2);}

C_noret_decl(trf_21284)
static void C_fcall trf_21284(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_21284(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_21284(t0,t1);}

C_noret_decl(trf_21313)
static void C_fcall trf_21313(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_21313(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_21313(t0,t1);}

C_noret_decl(trf_21103)
static void C_fcall trf_21103(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_21103(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_21103(t0,t1,t2);}

C_noret_decl(trf_21122)
static void C_fcall trf_21122(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_21122(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_21122(t0,t1);}

C_noret_decl(trf_21053)
static void C_fcall trf_21053(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_21053(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_21053(t0,t1,t2,t3);}

C_noret_decl(trf_20925)
static void C_fcall trf_20925(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_20925(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_20925(t0,t1,t2,t3);}

C_noret_decl(trf_20819)
static void C_fcall trf_20819(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_20819(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_20819(t0,t1,t2);}

C_noret_decl(trf_20825)
static void C_fcall trf_20825(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_20825(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_20825(t0,t1,t2,t3);}

C_noret_decl(trf_20623)
static void C_fcall trf_20623(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_20623(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_20623(t0,t1);}

C_noret_decl(trf_20631)
static void C_fcall trf_20631(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_20631(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_20631(t0,t1,t2,t3);}

C_noret_decl(trf_20559)
static void C_fcall trf_20559(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_20559(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_20559(t0,t1);}

C_noret_decl(trf_20550)
static void C_fcall trf_20550(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_20550(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_20550(t0,t1,t2);}

C_noret_decl(trf_20486)
static void C_fcall trf_20486(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_20486(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_20486(t0,t1,t2,t3);}

C_noret_decl(trf_20511)
static void C_fcall trf_20511(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_20511(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_20511(t0,t1,t2,t3);}

C_noret_decl(trf_20439)
static void C_fcall trf_20439(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_20439(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_20439(t0,t1);}

C_noret_decl(trf_20430)
static void C_fcall trf_20430(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_20430(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_20430(t0,t1,t2);}

C_noret_decl(trf_20374)
static void C_fcall trf_20374(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_20374(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_20374(t0,t1,t2,t3);}

C_noret_decl(trf_20399)
static void C_fcall trf_20399(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_20399(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_20399(t0,t1,t2,t3);}

C_noret_decl(trf_20329)
static void C_fcall trf_20329(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_20329(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_20329(t0,t1,t2,t3);}

C_noret_decl(trf_20283)
static void C_fcall trf_20283(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_20283(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_20283(t0,t1,t2,t3);}

C_noret_decl(trf_20243)
static void C_fcall trf_20243(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_20243(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_20243(t0,t1);}

C_noret_decl(trf_20183)
static void C_fcall trf_20183(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_20183(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_20183(t0,t1);}

C_noret_decl(trf_20178)
static void C_fcall trf_20178(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_20178(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_20178(t0,t1,t2);}

C_noret_decl(trf_20173)
static void C_fcall trf_20173(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_20173(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_20173(t0,t1,t2,t3);}

C_noret_decl(trf_20142)
static void C_fcall trf_20142(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_20142(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_20142(t0,t1,t2,t3,t4);}

C_noret_decl(trf_20154)
static void C_fcall trf_20154(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_20154(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_20154(t0,t1);}

C_noret_decl(trf_20157)
static void C_fcall trf_20157(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_20157(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_20157(t0,t1);}

C_noret_decl(trf_20160)
static void C_fcall trf_20160(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_20160(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_20160(t0,t1);}

C_noret_decl(trf_19940)
static void C_fcall trf_19940(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_19940(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_19940(t0,t1,t2);}

C_noret_decl(trf_19946)
static void C_fcall trf_19946(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_19946(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_19946(t0,t1,t2,t3);}

C_noret_decl(trf_19809)
static void C_fcall trf_19809(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_19809(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_19809(t0,t1);}

C_noret_decl(trf_19780)
static void C_fcall trf_19780(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_19780(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_19780(t0,t1);}

C_noret_decl(trf_19743)
static void C_fcall trf_19743(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_19743(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_19743(t0,t1,t2,t3);}

C_noret_decl(trf_19928)
static void C_fcall trf_19928(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_19928(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_19928(t0,t1);}

C_noret_decl(trf_19890)
static void C_fcall trf_19890(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_19890(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_19890(t0,t1,t2,t3,t4);}

C_noret_decl(trf_19905)
static void C_fcall trf_19905(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_19905(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_19905(t0,t1);}

C_noret_decl(trf_19560)
static void C_fcall trf_19560(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_19560(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_19560(t0,t1,t2,t3);}

C_noret_decl(trf_19576)
static void C_fcall trf_19576(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_19576(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_19576(t0,t1);}

C_noret_decl(trf_19613)
static void C_fcall trf_19613(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_19613(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_19613(t0,t1);}

C_noret_decl(trf_19544)
static void C_fcall trf_19544(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_19544(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_19544(t0,t1);}

C_noret_decl(trf_19432)
static void C_fcall trf_19432(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_19432(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_19432(t0,t1,t2,t3,t4);}

C_noret_decl(trf_19305)
static void C_fcall trf_19305(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_19305(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_19305(t0,t1,t2);}

C_noret_decl(trf_19073)
static void C_fcall trf_19073(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_19073(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_19073(t0,t1,t2);}

C_noret_decl(trf_19089)
static void C_fcall trf_19089(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_19089(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_19089(t0,t1);}

C_noret_decl(trf_19023)
static void C_fcall trf_19023(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_19023(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_19023(t0,t1,t2);}

C_noret_decl(trf_18742)
static void C_fcall trf_18742(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_18742(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_18742(t0,t1,t2);}

C_noret_decl(trf_18752)
static void C_fcall trf_18752(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_18752(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_18752(t0,t1,t2,t3);}

C_noret_decl(trf_13500)
static void C_fcall trf_13500(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_13500(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_13500(t0,t1,t2,t3);}

C_noret_decl(trf_18666)
static void C_fcall trf_18666(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_18666(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_18666(t0,t1,t2,t3);}

C_noret_decl(trf_18625)
static void C_fcall trf_18625(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_18625(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_18625(t0,t1,t2);}

C_noret_decl(trf_16261)
static void C_fcall trf_16261(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_16261(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_16261(t0,t1,t2);}

C_noret_decl(trf_16180)
static void C_fcall trf_16180(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_16180(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_16180(t0,t1,t2);}

C_noret_decl(trf_16186)
static void C_fcall trf_16186(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_16186(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_16186(t0,t1,t2,t3);}

C_noret_decl(trf_16064)
static void C_fcall trf_16064(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_16064(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_16064(t0,t1,t2);}

C_noret_decl(trf_16097)
static void C_fcall trf_16097(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_16097(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_16097(t0,t1);}

C_noret_decl(trf_16101)
static void C_fcall trf_16101(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_16101(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_16101(t0,t1);}

C_noret_decl(trf_16109)
static void C_fcall trf_16109(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_16109(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_16109(t0,t1);}

C_noret_decl(trf_15990)
static void C_fcall trf_15990(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_15990(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_15990(t0,t1,t2);}

C_noret_decl(trf_15998)
static void C_fcall trf_15998(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_15998(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_15998(t0,t1);}

C_noret_decl(trf_16002)
static void C_fcall trf_16002(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_16002(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_16002(t0,t1);}

C_noret_decl(trf_15516)
static void C_fcall trf_15516(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_15516(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_15516(t0,t1,t2);}

C_noret_decl(trf_15725)
static void C_fcall trf_15725(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_15725(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_15725(t0,t1,t2,t3);}

C_noret_decl(trf_15753)
static void C_fcall trf_15753(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_15753(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_15753(t0,t1);}

C_noret_decl(trf_15910)
static void C_fcall trf_15910(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_15910(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_15910(t0,t1);}

C_noret_decl(trf_15811)
static void C_fcall trf_15811(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_15811(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_15811(t0,t1);}

C_noret_decl(trf_15829)
static void C_fcall trf_15829(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_15829(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_15829(t0,t1);}

C_noret_decl(trf_15832)
static void C_fcall trf_15832(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_15832(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_15832(t0,t1);}

C_noret_decl(trf_15547)
static void C_fcall trf_15547(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_15547(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_15547(t0,t1,t2,t3);}

C_noret_decl(trf_15596)
static void C_fcall trf_15596(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_15596(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_15596(t0,t1);}

C_noret_decl(trf_15617)
static void C_fcall trf_15617(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_15617(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_15617(t0,t1);}

C_noret_decl(trf_15621)
static void C_fcall trf_15621(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_15621(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_15621(t0,t1);}

C_noret_decl(trf_15519)
static void C_fcall trf_15519(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_15519(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_15519(t0,t1,t2,t3);}

C_noret_decl(trf_15219)
static void C_fcall trf_15219(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_15219(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_15219(t0,t1,t2);}

C_noret_decl(trf_15232)
static void C_fcall trf_15232(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_15232(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_15232(t0,t1,t2,t3,t4);}

C_noret_decl(trf_15427)
static void C_fcall trf_15427(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_15427(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_15427(t0,t1,t2,t3,t4);}

C_noret_decl(trf_15277)
static void C_fcall trf_15277(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_15277(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_15277(t0,t1);}

C_noret_decl(trf_14429)
static void C_fcall trf_14429(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_14429(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_14429(t0,t1,t2);}

C_noret_decl(trf_14447)
static void C_fcall trf_14447(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_14447(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_14447(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_14710)
static void C_fcall trf_14710(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_14710(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_14710(t0,t1);}

C_noret_decl(trf_14764)
static void C_fcall trf_14764(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_14764(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_14764(t0,t1);}

C_noret_decl(trf_15039)
static void C_fcall trf_15039(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_15039(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_15039(t0,t1);}

C_noret_decl(trf_14560)
static void C_fcall trf_14560(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_14560(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_14560(t0,t1);}

C_noret_decl(trf_14464)
static void C_fcall trf_14464(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_14464(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_14464(t0,t1,t2,t3);}

C_noret_decl(trf_14450)
static void C_fcall trf_14450(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_14450(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_14450(t0,t1,t2);}

C_noret_decl(trf_14322)
static void C_fcall trf_14322(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_14322(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_14322(t0,t1,t2,t3,t4);}

C_noret_decl(trf_14336)
static void C_fcall trf_14336(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_14336(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_14336(t0,t1,t2,t3,t4);}

C_noret_decl(trf_14113)
static void C_fcall trf_14113(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_14113(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_14113(t0,t1,t2);}

C_noret_decl(trf_14243)
static void C_fcall trf_14243(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_14243(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_14243(t0,t1,t2,t3);}

C_noret_decl(trf_14043)
static void C_fcall trf_14043(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_14043(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_14043(t0,t1,t2);}

C_noret_decl(trf_13961)
static void C_fcall trf_13961(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_13961(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_13961(t0,t1);}

C_noret_decl(trf_13841)
static void C_fcall trf_13841(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_13841(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_13841(t0,t1);}

C_noret_decl(trf_13786)
static void C_fcall trf_13786(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_13786(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_13786(t0,t1,t2,t3);}

C_noret_decl(trf_13556)
static void C_fcall trf_13556(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_13556(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_13556(t0,t1,t2,t3);}

C_noret_decl(trf_13654)
static void C_fcall trf_13654(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_13654(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_13654(t0,t1);}

C_noret_decl(trf_12296)
static void C_fcall trf_12296(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12296(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_12296(t0,t1);}

C_noret_decl(trf_12327)
static void C_fcall trf_12327(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12327(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_12327(t0,t1);}

C_noret_decl(trf_12223)
static void C_fcall trf_12223(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12223(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_12223(t0,t1);}

C_noret_decl(trf_12137)
static void C_fcall trf_12137(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12137(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_12137(t0,t1);}

C_noret_decl(trf_11991)
static void C_fcall trf_11991(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11991(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11991(t0,t1);}

C_noret_decl(trf_11857)
static void C_fcall trf_11857(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11857(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11857(t0,t1);}

C_noret_decl(trf_11906)
static void C_fcall trf_11906(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11906(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11906(t0,t1);}

C_noret_decl(trf_11390)
static void C_fcall trf_11390(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11390(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_11390(t0,t1,t2,t3,t4);}

C_noret_decl(trf_11503)
static void C_fcall trf_11503(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11503(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11503(t0,t1);}

C_noret_decl(trf_11713)
static void C_fcall trf_11713(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11713(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11713(t0,t1);}

C_noret_decl(trf_16317)
static void C_fcall trf_16317(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_16317(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_16317(t0,t1,t2,t3,t4);}

C_noret_decl(trf_16600)
static void C_fcall trf_16600(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_16600(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_16600(t0,t1);}

C_noret_decl(trf_16378)
static void C_fcall trf_16378(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_16378(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_16378(t0,t1,t2,t3);}

C_noret_decl(trf_12371)
static void C_fcall trf_12371(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12371(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_12371(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_12416)
static void C_fcall trf_12416(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12416(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_12416(t0,t1);}

C_noret_decl(trf_12445)
static void C_fcall trf_12445(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12445(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_12445(t0,t1);}

C_noret_decl(trf_13175)
static void C_fcall trf_13175(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_13175(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_13175(t0,t1);}

C_noret_decl(trf_13225)
static void C_fcall trf_13225(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_13225(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_13225(t0,t1);}

C_noret_decl(trf_12974)
static void C_fcall trf_12974(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12974(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_12974(t0,t1);}

C_noret_decl(trf_12977)
static void C_fcall trf_12977(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12977(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_12977(t0,t1);}

C_noret_decl(trf_13007)
static void C_fcall trf_13007(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_13007(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_13007(t0,t1);}

C_noret_decl(trf_12841)
static void C_fcall trf_12841(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12841(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_12841(t0,t1);}

C_noret_decl(trf_12621)
static void C_fcall trf_12621(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12621(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_12621(t0,t1);}

C_noret_decl(trf_12712)
static void C_fcall trf_12712(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12712(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_12712(t0,t1);}

C_noret_decl(trf_12679)
static void C_fcall trf_12679(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12679(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_12679(t0,t1);}

C_noret_decl(trf_12536)
static void C_fcall trf_12536(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12536(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_12536(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_12454)
static void C_fcall trf_12454(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12454(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_12454(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_12374)
static void C_fcall trf_12374(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12374(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_12374(t0,t1,t2);}

C_noret_decl(trf_18607)
static void C_fcall trf_18607(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_18607(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_18607(t0,t1);}

C_noret_decl(trf_16660)
static void C_fcall trf_16660(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_16660(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_16660(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_18554)
static void C_fcall trf_18554(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_18554(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_18554(t0,t1);}

C_noret_decl(trf_18425)
static void C_fcall trf_18425(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_18425(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_18425(t0,t1);}

C_noret_decl(trf_18379)
static void C_fcall trf_18379(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_18379(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_18379(t0,t1);}

C_noret_decl(trf_18367)
static void C_fcall trf_18367(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_18367(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_18367(t0,t1);}

C_noret_decl(trf_18336)
static void C_fcall trf_18336(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_18336(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_18336(t0,t1);}

C_noret_decl(trf_18263)
static void C_fcall trf_18263(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_18263(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_18263(t0,t1);}

C_noret_decl(trf_18251)
static void C_fcall trf_18251(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_18251(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_18251(t0,t1);}

C_noret_decl(trf_18220)
static void C_fcall trf_18220(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_18220(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_18220(t0,t1);}

C_noret_decl(trf_18155)
static void C_fcall trf_18155(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_18155(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_18155(t0,t1);}

C_noret_decl(trf_16706)
static void C_fcall trf_16706(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_16706(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_16706(t0,t1);}

C_noret_decl(trf_17748)
static void C_fcall trf_17748(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_17748(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_17748(t0,t1);}

C_noret_decl(trf_17234)
static void C_fcall trf_17234(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_17234(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_17234(t0,t1);}

C_noret_decl(trf_17237)
static void C_fcall trf_17237(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_17237(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_17237(t0,t1);}

C_noret_decl(trf_16663)
static void C_fcall trf_16663(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_16663(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_16663(t0,t1,t2);}

C_noret_decl(trf_11216)
static void C_fcall trf_11216(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11216(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11216(t0,t1);}

C_noret_decl(trf_11222)
static void C_fcall trf_11222(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11222(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_11222(t0,t1,t2,t3,t4);}

C_noret_decl(trf_10404)
static void C_fcall trf_10404(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10404(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_10404(t0,t1,t2,t3);}

C_noret_decl(trf_11154)
static void C_fcall trf_11154(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11154(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11154(t0,t1);}

C_noret_decl(trf_11244)
static void C_fcall trf_11244(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11244(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11244(t0,t1);}

C_noret_decl(trf_10732)
static void C_fcall trf_10732(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10732(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10732(t0,t1);}

C_noret_decl(trf_10604)
static void C_fcall trf_10604(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10604(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10604(t0,t1);}

C_noret_decl(trf_10518)
static void C_fcall trf_10518(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10518(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_10518(t0,t1,t2,t3,t4);}

C_noret_decl(trf_10242)
static void C_fcall trf_10242(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10242(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10242(t0,t1);}

C_noret_decl(trf_10182)
static void C_fcall trf_10182(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10182(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10182(t0,t1);}

C_noret_decl(trf_9957)
static void C_fcall trf_9957(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9957(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_9957(t0,t1,t2,t3);}

C_noret_decl(trf_9214)
static void C_fcall trf_9214(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9214(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_9214(t0,t1,t2,t3);}

C_noret_decl(trf_5364)
static void C_fcall trf_5364(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5364(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5364(t0,t1,t2);}

C_noret_decl(trf_6275)
static void C_fcall trf_6275(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6275(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_6275(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_5422)
static void C_fcall trf_5422(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5422(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5422(t0,t1,t2);}

C_noret_decl(trf_8765)
static void C_fcall trf_8765(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8765(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8765(t0,t1,t2);}

C_noret_decl(trf_8672)
static void C_fcall trf_8672(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8672(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8672(t0,t1);}

C_noret_decl(trf_8052)
static void C_fcall trf_8052(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8052(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8052(t0,t1);}

C_noret_decl(trf_7871)
static void C_fcall trf_7871(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7871(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7871(t0,t1);}

C_noret_decl(trf_5463)
static void C_fcall trf_5463(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5463(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_5463(t0,t1,t2,t3,t4);}

C_noret_decl(trf_5466)
static void C_fcall trf_5466(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5466(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5466(t0,t1);}

C_noret_decl(trf_9327)
static void C_fcall trf_9327(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9327(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_9327(t0,t1,t2,t3,t4);}

C_noret_decl(trf_9741)
static void C_fcall trf_9741(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9741(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9741(t0,t1);}

C_noret_decl(trf_9625)
static void C_fcall trf_9625(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9625(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9625(t0,t1);}

C_noret_decl(trf_9564)
static void C_fcall trf_9564(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9564(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9564(t0,t1);}

C_noret_decl(trf_9477)
static void C_fcall trf_9477(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9477(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9477(t0,t1);}

C_noret_decl(trf_5968)
static void C_fcall trf_5968(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5968(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5968(t0,t1,t2,t3);}

C_noret_decl(trf_5989)
static void C_fcall trf_5989(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5989(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5989(t0,t1);}

C_noret_decl(trf_9392)
static void C_fcall trf_9392(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9392(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9392(t0,t1);}

C_noret_decl(trf_18707)
static void C_fcall trf_18707(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_18707(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_18707(t0,t1,t2,t3);}

C_noret_decl(trf_9396)
static void C_fcall trf_9396(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9396(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9396(t0,t1);}

C_noret_decl(trf_7547)
static void C_fcall trf_7547(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7547(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_7547(t0,t1,t2,t3,t4);}

C_noret_decl(trf_7559)
static void C_fcall trf_7559(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7559(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7559(t0,t1,t2);}

C_noret_decl(trf_7550)
static void C_fcall trf_7550(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7550(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7550(t0,t1,t2);}

C_noret_decl(trf_6825)
static void C_fcall trf_6825(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6825(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6825(t0,t1);}

C_noret_decl(trf_6720)
static void C_fcall trf_6720(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6720(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6720(t0,t1);}

C_noret_decl(trf_6420)
static void C_fcall trf_6420(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6420(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6420(t0,t1);}

C_noret_decl(trf_6427)
static void C_fcall trf_6427(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6427(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6427(t0,t1);}

C_noret_decl(trf_6680)
static void C_fcall trf_6680(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6680(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6680(t0,t1);}

C_noret_decl(trf_6430)
static void C_fcall trf_6430(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6430(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6430(t0,t1);}

C_noret_decl(trf_6438)
static void C_fcall trf_6438(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6438(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_6438(t0,t1,t2,t3,t4);}

C_noret_decl(trf_6540)
static void C_fcall trf_6540(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6540(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6540(t0,t1);}

C_noret_decl(trf_6507)
static void C_fcall trf_6507(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6507(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6507(t0,t1);}

C_noret_decl(trf_6348)
static void C_fcall trf_6348(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6348(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6348(t0,t1);}

C_noret_decl(trf_10147)
static void C_fcall trf_10147(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10147(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10147(t0,t1,t2);}

C_noret_decl(trf_6328)
static void C_fcall trf_6328(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6328(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6328(t0,t1);}

C_noret_decl(trf_6308)
static void C_fcall trf_6308(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6308(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6308(t0,t1,t2);}

C_noret_decl(trf_6163)
static void C_fcall trf_6163(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6163(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6163(t0,t1);}

C_noret_decl(trf_6169)
static void C_fcall trf_6169(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6169(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6169(t0,t1,t2,t3);}

C_noret_decl(trf_6200)
static void C_fcall trf_6200(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6200(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6200(t0,t1);}

C_noret_decl(trf_6194)
static void C_fcall trf_6194(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6194(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6194(t0,t1);}

C_noret_decl(trf_6125)
static void C_fcall trf_6125(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6125(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6125(t0,t1,t2);}

C_noret_decl(trf_6078)
static void C_fcall trf_6078(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6078(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6078(t0,t1,t2);}

C_noret_decl(trf_6031)
static void C_fcall trf_6031(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6031(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6031(t0,t1,t2);}

C_noret_decl(trf_6015)
static void C_fcall trf_6015(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6015(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6015(t0,t1,t2);}

C_noret_decl(trf_6005)
static void C_fcall trf_6005(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6005(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6005(t0,t1,t2);}

C_noret_decl(trf_5919)
static void C_fcall trf_5919(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5919(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5919(t0,t1,t2);}

C_noret_decl(trf_5925)
static void C_fcall trf_5925(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5925(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5925(t0,t1,t2,t3);}

C_noret_decl(trf_5946)
static void C_fcall trf_5946(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5946(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5946(t0,t1);}

C_noret_decl(trf_5889)
static void C_fcall trf_5889(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5889(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5889(t0,t1,t2,t3);}

C_noret_decl(trf_5895)
static void C_fcall trf_5895(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5895(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5895(t0,t1,t2,t3);}

C_noret_decl(trf_5840)
static void C_fcall trf_5840(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5840(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5840(t0,t1,t2);}

C_noret_decl(trf_5860)
static void C_fcall trf_5860(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5860(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5860(t0,t1,t2,t3);}

C_noret_decl(trf_5791)
static void C_fcall trf_5791(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5791(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5791(t0,t1,t2);}

C_noret_decl(trf_5811)
static void C_fcall trf_5811(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5811(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5811(t0,t1,t2,t3);}

C_noret_decl(trf_5749)
static void C_fcall trf_5749(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5749(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5749(t0,t1);}

C_noret_decl(trf_5717)
static void C_fcall trf_5717(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5717(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5717(t0,t1,t2);}

C_noret_decl(trf_5723)
static void C_fcall trf_5723(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5723(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5723(t0,t1,t2);}

C_noret_decl(trf_5705)
static void C_fcall trf_5705(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5705(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5705(t0,t1,t2);}

C_noret_decl(trf_5662)
static void C_fcall trf_5662(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5662(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5662(t0,t1,t2);}

C_noret_decl(trf_5668)
static void C_fcall trf_5668(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5668(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5668(t0,t1,t2,t3);}

C_noret_decl(trf_5675)
static void C_fcall trf_5675(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5675(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5675(t0,t1);}

C_noret_decl(trf_5623)
static void C_fcall trf_5623(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5623(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5623(t0,t1);}

C_noret_decl(trf_5639)
static void C_fcall trf_5639(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5639(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5639(t0,t1,t2,t3);}

C_noret_decl(trf_5566)
static void C_fcall trf_5566(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5566(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5566(t0,t1);}

C_noret_decl(trf_5595)
static void C_fcall trf_5595(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5595(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5595(t0,t1,t2,t3);}

C_noret_decl(trf_5539)
static void C_fcall trf_5539(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5539(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5539(t0,t1,t2,t3);}

C_noret_decl(trf_5306)
static void C_fcall trf_5306(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5306(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5306(t0,t1,t2,t3);}

C_noret_decl(trf_5319)
static void C_fcall trf_5319(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5319(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5319(t0,t1,t2);}

C_noret_decl(trf_5147)
static void C_fcall trf_5147(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5147(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5147(t0,t1,t2);}

C_noret_decl(trf_4978)
static void C_fcall trf_4978(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4978(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4978(t0,t1,t2);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr7)
static void C_fcall tr7(C_proc7 k) C_regparm C_noret;
C_regparm static void C_fcall tr7(C_proc7 k){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
(k)(7,t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr5rv)
static void C_fcall tr5rv(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5rv(C_proc5 k){
int n;
C_word *a,t5;
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
n=C_rest_count(0);
a=C_alloc(n+1);
t5=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr4rv)
static void C_fcall tr4rv(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4rv(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n+1);
t4=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_regex_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_regex_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("regex_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(2520)){
C_save(t1);
C_rereclaim2(2520*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,332);
lf[1]=C_h_intern(&lf[1],13,"*irregex-tag*");
lf[2]=C_h_intern(&lf[2],8,"irregex\077");
lf[3]=C_h_intern(&lf[3],11,"irregex-dfa");
lf[4]=C_h_intern(&lf[4],18,"irregex-dfa/search");
lf[5]=C_h_intern(&lf[5],19,"irregex-dfa/extract");
lf[6]=C_h_intern(&lf[6],11,"irregex-nfa");
lf[7]=C_h_intern(&lf[7],13,"irregex-flags");
lf[8]=C_h_intern(&lf[8],18,"irregex-submatches");
lf[9]=C_h_intern(&lf[9],15,"irregex-lengths");
lf[10]=C_h_intern(&lf[10],13,"irregex-names");
lf[11]=C_h_intern(&lf[11],19,"irregex-new-matches");
lf[12]=C_h_intern(&lf[12],19,"*irregex-match-tag*");
lf[13]=C_h_intern(&lf[13],11,"make-vector");
lf[14]=C_h_intern(&lf[14],22,"irregex-reset-matches!");
lf[15]=C_h_intern(&lf[15],19,"irregex-match-data\077");
lf[16]=C_h_intern(&lf[16],28,"irregex-match-num-submatches");
lf[17]=C_h_intern(&lf[17],20,"irregex-match-string");
lf[24]=C_h_intern(&lf[24],5,"error");
lf[25]=C_decode_literal(C_heaptop,"\376B\000\000\022unknown match name");
lf[27]=C_h_intern(&lf[27],23,"irregex-match-substring");
lf[28]=C_h_intern(&lf[28],13,"\003syssubstring");
lf[29]=C_h_intern(&lf[29],19,"irregex-match-start");
lf[30]=C_h_intern(&lf[30],17,"irregex-match-end");
lf[31]=C_h_intern(&lf[31],1,"/");
lf[36]=C_h_intern(&lf[36],11,"make-string");
lf[40]=C_h_intern(&lf[40],7,"reverse");
lf[44]=C_decode_literal(C_heaptop,"\376B\000\000\035can\047t take last of empty list");
lf[49]=C_h_intern(&lf[49],4,"expt");
lf[57]=C_h_intern(&lf[57],1,"i");
lf[58]=C_h_intern(&lf[58],1,"m");
lf[59]=C_h_intern(&lf[59],10,"multi-line");
lf[60]=C_h_intern(&lf[60],1,"s");
lf[61]=C_h_intern(&lf[61],11,"single-line");
lf[62]=C_h_intern(&lf[62],1,"x");
lf[63]=C_h_intern(&lf[63],12,"ignore-space");
lf[64]=C_h_intern(&lf[64],1,"u");
lf[65]=C_h_intern(&lf[65],4,"utf8");
lf[66]=C_h_intern(&lf[66],2,"ci");
lf[67]=C_h_intern(&lf[67],16,"case-insensitive");
lf[68]=C_h_intern(&lf[68],11,"string->sre");
lf[70]=C_h_intern(&lf[70],2,"or");
lf[72]=C_h_intern(&lf[72],7,"\003sysmap");
lf[73]=C_h_intern(&lf[73],16,"\003sysstring->list");
lf[76]=C_h_intern(&lf[76],8,"submatch");
lf[77]=C_h_intern(&lf[77],2,"if");
lf[78]=C_h_intern(&lf[78],10,"look-ahead");
lf[79]=C_h_intern(&lf[79],14,"neg-look-ahead");
lf[80]=C_h_intern(&lf[80],11,"look-behind");
lf[81]=C_h_intern(&lf[81],15,"neg-look-behind");
lf[82]=C_h_intern(&lf[82],3,"seq");
lf[83]=C_h_intern(&lf[83],7,"epsilon");
lf[84]=C_h_intern(&lf[84],10,"\003sysappend");
lf[85]=C_h_intern(&lf[85],14,"submatch-named");
lf[86]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006atomic\376\003\000\000\002\376\001\000\000\002if\376\003\000\000\002\376\001\000\000\012look-ahead\376\003\000\000\002\376\001\000\000\016neg-look-ahead\376\003\000\000\002\376\001\000"
"\000\013look-behind\376\003\000\000\002\376\001\000\000\017neg-look-behind\376\003\000\000\002\376\001\000\000\016submatch-named\376\003\000\000\002\376\001\000\000\006w/utf8\376\003"
"\000\000\002\376\001\000\000\010w/noutf8\376\377\016");
lf[87]=C_decode_literal(C_heaptop,"\376B\000\000\042unterminated parenthesis in regexp");
lf[88]=C_h_intern(&lf[88],3,"any");
lf[89]=C_h_intern(&lf[89],4,"nonl");
lf[90]=C_decode_literal(C_heaptop,"\376B\000\000\030\077 can\047t follow empty sre");
lf[91]=C_h_intern(&lf[91],1,"*");
lf[92]=C_h_intern(&lf[92],2,"*\077");
lf[93]=C_h_intern(&lf[93],1,"+");
lf[94]=C_h_intern(&lf[94],3,"**\077");
lf[95]=C_h_intern(&lf[95],1,"\077");
lf[96]=C_h_intern(&lf[96],2,"\077\077");
lf[97]=C_h_intern(&lf[97],2,"**");
lf[98]=C_h_intern(&lf[98],1,"=");
lf[99]=C_h_intern(&lf[99],2,">=");
lf[101]=C_decode_literal(C_heaptop,"\376B\000\000%duplicate repetition (e.g. **) in sre");
lf[102]=C_decode_literal(C_heaptop,"\376B\000\000!can\047t repeat empty sre (e.g. ()*)");
lf[104]=C_h_intern(&lf[104],14,"string->symbol");
lf[105]=C_decode_literal(C_heaptop,"\376B\000\000\042unterminated parenthesis in regexp");
lf[106]=C_decode_literal(C_heaptop,"\376B\000\000\042unterminated parenthesis in regexp");
lf[107]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\012look-ahead\376\377\016");
lf[108]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016neg-look-ahead\376\377\016");
lf[109]=C_decode_literal(C_heaptop,"\376B\000\000\042unterminated parenthesis in regexp");
lf[110]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\013look-behind\376\377\016");
lf[111]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\017neg-look-behind\376\377\016");
lf[112]=C_decode_literal(C_heaptop,"\376B\000\000\024invalid (\077< sequence");
lf[113]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006atomic\376\377\016");
lf[114]=C_decode_literal(C_heaptop,"\376B\000\000\042unterminated parenthesis in regexp");
lf[115]=C_decode_literal(C_heaptop,"\376B\000\000\035invalid conditional reference");
lf[116]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\002if\376\377\016");
lf[117]=C_decode_literal(C_heaptop,"\376B\000\000\036unsupported Perl-style cluster");
lf[118]=C_h_intern(&lf[118],6,"w/utf8");
lf[119]=C_h_intern(&lf[119],8,"w/noutf8");
lf[120]=C_decode_literal(C_heaptop,"\376B\000\000\022incomplete cluster");
lf[121]=C_decode_literal(C_heaptop,"\376B\000\000\036unknown regex cluster modifier");
lf[122]=C_decode_literal(C_heaptop,"\376B\000\000\026too many )\047s in regexp");
lf[123]=C_decode_literal(C_heaptop,"\376B\000\000\023incomplete char set");
lf[124]=C_h_intern(&lf[124],1,"~");
lf[125]=C_h_intern(&lf[125],6,"append");
lf[127]=C_h_intern(&lf[127],16,"\003syslist->string");
lf[129]=C_decode_literal(C_heaptop,"\376B\000\000\014bad char-set");
lf[131]=C_decode_literal(C_heaptop,"\376B\000\000\032inverted range in char-set");
lf[132]=C_decode_literal(C_heaptop,"\376B\000\000\032incomplete character class");
lf[133]=C_h_intern(&lf[133],5,"pair\077");
lf[134]=C_h_intern(&lf[134],5,"char\077");
lf[137]=C_decode_literal(C_heaptop,"\376B\000\000!collating sequences not supported");
lf[138]=C_decode_literal(C_heaptop,"\376B\000\000\023bad character class");
lf[141]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000\012\376\377\016");
lf[142]=C_decode_literal(C_heaptop,"\376B\000\000\032incomplete escape sequence");
lf[143]=C_h_intern(&lf[143],7,"numeric");
lf[144]=C_h_intern(&lf[144],5,"space");
lf[145]=C_decode_literal(C_heaptop,"\376B\000\000\001_");
lf[146]=C_h_intern(&lf[146],12,"alphanumeric");
lf[147]=C_decode_literal(C_heaptop,"\376B\000\000\001_");
lf[148]=C_h_intern(&lf[148],3,"eow");
lf[149]=C_h_intern(&lf[149],3,"bow");
lf[150]=C_h_intern(&lf[150],3,"nwb");
lf[151]=C_h_intern(&lf[151],3,"bos");
lf[152]=C_h_intern(&lf[152],3,"eos");
lf[153]=C_h_intern(&lf[153],7,"newline");
lf[154]=C_h_intern(&lf[154],5,"reset");
lf[155]=C_h_intern(&lf[155],10,"backref-ci");
lf[156]=C_h_intern(&lf[156],7,"backref");
lf[157]=C_decode_literal(C_heaptop,"\376B\000\000\032interminated named backref");
lf[158]=C_decode_literal(C_heaptop,"\376B\000\000\036bad \134k usage, expected \134k<...>");
lf[159]=C_decode_literal(C_heaptop,"\376B\000\000\027unknown escape sequence");
lf[160]=C_h_intern(&lf[160],3,"bol");
lf[161]=C_h_intern(&lf[161],3,"eol");
lf[162]=C_decode_literal(C_heaptop,"\376B\000\000\025incomplete hex escape");
lf[163]=C_decode_literal(C_heaptop,"\376B\000\000\024bad hex brace escape");
lf[164]=C_decode_literal(C_heaptop,"\376B\000\000\033incomplete hex brace escape");
lf[165]=C_decode_literal(C_heaptop,"\376B\000\000\025incomplete hex escape");
lf[166]=C_decode_literal(C_heaptop,"\376B\000\000\016bad hex escape");
lf[167]=C_decode_literal(C_heaptop,"\376\000\000\001\000\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000"
"\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376"
"\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000"
"\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001"
"\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001"
"\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000"
"\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377"
"\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000"
"\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376"
"\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000"
"\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001"
"\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001"
"\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000"
"\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377"
"\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000"
"\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376"
"\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\002\376\377\001\000"
"\000\000\002\376\377\001\000\000\000\002\376\377\001\000\000\000\002\376\377\001\000\000\000\002\376\377\001\000\000\000\002\376\377\001\000\000\000\002\376\377\001\000\000\000\002\376\377\001\000\000\000\002\376\377\001\000\000\000\002\376\377\001\000\000\000\002\376\377\001\000\000\000\002\376\377\001\000\000\000\002"
"\376\377\001\000\000\000\002\376\377\001\000\000\000\002\376\377\001\000\000\000\002\376\377\001\000\000\000\002\376\377\001\000\000\000\002\376\377\001\000\000\000\002\376\377\001\000\000\000\002\376\377\001\000\000\000\002\376\377\001\000\000\000\002\376\377\001\000\000\000\002\376\377\001\000\000\000\002\376\377\001"
"\000\000\000\002\376\377\001\000\000\000\002\376\377\001\000\000\000\002\376\377\001\000\000\000\002\376\377\001\000\000\000\002\376\377\001\000\000\000\002\376\377\001\000\000\000\002\376\377\001\000\000\000\002\376\377\001\000\000\000\003\376\377\001\000\000\000\003\376\377\001\000\000\000\003\376\377\001\000\000\000"
"\003\376\377\001\000\000\000\003\376\377\001\000\000\000\003\376\377\001\000\000\000\003\376\377\001\000\000\000\003\376\377\001\000\000\000\003\376\377\001\000\000\000\003\376\377\001\000\000\000\003\376\377\001\000\000\000\003\376\377\001\000\000\000\003\376\377\001\000\000\000\003\376\377\001\000\000\000\003\376\377"
"\001\000\000\000\003\376\377\001\000\000\000\004\376\377\001\000\000\000\004\376\377\001\000\000\000\004\376\377\001\000\000\000\004\376\377\001\000\000\000\004\376\377\001\000\000\000\004\376\377\001\000\000\000\004\376\377\001\000\000\000\004\376\377\001\000\000\000\005\376\377\001\000\000\000\005\376\377\001\000\000"
"\000\005\376\377\001\000\000\000\005\376\377\001\000\000\000\006\376\377\001\000\000\000\006\376\377\001\000\000\000\000\376\377\001\000\000\000\000");
lf[168]=C_decode_literal(C_heaptop,"\376B\000\000\023invalid utf8 length");
lf[170]=C_decode_literal(C_heaptop,"\376B\000\000\023invalid utf8 length");
lf[172]=C_decode_literal(C_heaptop,"\376B\000\000\037unicode codepoint out of range:");
lf[174]=C_h_intern(&lf[174],13,"integer->char");
lf[178]=C_decode_literal(C_heaptop,"\376B\000\000\023invalid utf8 length");
lf[179]=C_h_intern(&lf[179],7,"irregex");
lf[180]=C_h_intern(&lf[180],15,"string->irregex");
lf[181]=C_h_intern(&lf[181],12,"sre->irregex");
lf[184]=C_h_intern(&lf[184],6,"w/case");
lf[185]=C_h_intern(&lf[185],8,"w/nocase");
lf[186]=C_h_intern(&lf[186],1,":");
lf[187]=C_decode_literal(C_heaptop,"\376B\000\000\024invalid sre: empty *");
lf[188]=C_decode_literal(C_heaptop,"\376B\000\000\025invalid sre: empty *\077");
lf[190]=C_h_intern(&lf[190],4,"word");
lf[191]=C_h_intern(&lf[191],5,"word+");
lf[192]=C_decode_literal(C_heaptop,"\376B\000\000\001_");
lf[193]=C_h_intern(&lf[193],1,"&");
lf[194]=C_h_intern(&lf[194],12,"posix-string");
lf[195]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001*\376\003\000\000\002\376\001\000\000\003any\376\377\016");
lf[196]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001*\376\003\000\000\002\376\001\000\000\003any\376\377\016");
lf[197]=C_h_intern(&lf[197],6,"atomic");
lf[198]=C_decode_literal(C_heaptop,"\376B\000\000\037unknown named backref in SRE IF");
lf[199]=C_h_intern(&lf[199],11,"string-ci=\077");
lf[200]=C_h_intern(&lf[200],8,"string=\077");
lf[201]=C_decode_literal(C_heaptop,"\376B\000\000\025unknown backreference");
lf[202]=C_h_intern(&lf[202],3,"dsm");
lf[203]=C_decode_literal(C_heaptop,"\376B\000\000\027unknown regexp operator");
lf[204]=C_h_intern(&lf[204],1,"-");
lf[206]=C_decode_literal(C_heaptop,"\376B\000\000\016unknown regexp");
lf[207]=C_h_intern(&lf[207],9,"char-ci=\077");
lf[208]=C_decode_literal(C_heaptop,"\376B\000\000\016unknown regexp");
lf[211]=C_h_intern(&lf[211],3,"max");
lf[212]=C_h_intern(&lf[212],3,"min");
lf[213]=C_decode_literal(C_heaptop,"\376B\000\000!sre-length: invalid backreference");
lf[214]=C_decode_literal(C_heaptop,"\376B\000\000)sre-length: invalid forward backreference");
lf[215]=C_decode_literal(C_heaptop,"\376B\000\000\025unknown backreference");
lf[216]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\002>=\376\003\000\000\002\376\001\000\000\003>=\077\376\377\016");
lf[217]=C_decode_literal(C_heaptop,"\376B\000\000\047sre-length-ranges: unknown sre operator");
lf[218]=C_h_intern(&lf[218],2,"=\077");
lf[219]=C_h_intern(&lf[219],3,">=\077");
lf[220]=C_h_intern(&lf[220],6,"commit");
lf[221]=C_decode_literal(C_heaptop,"\376B\000\000\036sre-length-ranges: unknown sre");
lf[222]=C_h_intern(&lf[222],4,"cons");
lf[223]=C_decode_literal(C_heaptop,"\376B\000\000\027unknown regexp operator");
lf[224]=C_decode_literal(C_heaptop,"\376B\000\000\016unknown regexp");
lf[229]=C_h_intern(&lf[229],5,"small");
lf[230]=C_h_intern(&lf[230],4,"fast");
lf[233]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001*\376\003\000\000\002\376\001\000\000\003any\376\377\016");
lf[234]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001*\376\003\000\000\002\376\001\000\000\004nonl\376\377\016");
lf[235]=C_h_intern(&lf[235],8,"utf8-any");
lf[236]=C_h_intern(&lf[236],9,"utf8-nonl");
lf[237]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\007epsilon\376\003\000\000\002\376\001\000\000\003bos\376\003\000\000\002\376\001\000\000\003eos\376\003\000\000\002\376\001\000\000\003bol\376\003\000\000\002\376\001\000\000\003eol\376\003\000\000\002\376\001\000\000\003b"
"ow\376\003\000\000\002\376\001\000\000\003eow\376\003\000\000\002\376\001\000\000\006commit\376\377\016");
lf[239]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001*\376\003\000\000\002\376\001\000\000\001+\376\377\016");
lf[241]=C_h_intern(&lf[241],14,"irregex-search");
lf[242]=C_h_intern(&lf[242],22,"irregex-search/matches");
lf[246]=C_h_intern(&lf[246],13,"irregex-match");
lf[247]=C_h_intern(&lf[247],10,"alphabetic");
lf[248]=C_h_intern(&lf[248],5,"alpha");
lf[249]=C_h_intern(&lf[249],8,"alphanum");
lf[250]=C_h_intern(&lf[250],5,"alnum");
lf[251]=C_h_intern(&lf[251],10,"lower-case");
lf[252]=C_h_intern(&lf[252],5,"lower");
lf[253]=C_h_intern(&lf[253],10,"upper-case");
lf[254]=C_h_intern(&lf[254],5,"upper");
lf[255]=C_h_intern(&lf[255],3,"num");
lf[256]=C_h_intern(&lf[256],5,"digit");
lf[257]=C_h_intern(&lf[257],11,"punctuation");
lf[258]=C_h_intern(&lf[258],5,"punct");
lf[259]=C_h_intern(&lf[259],7,"graphic");
lf[260]=C_h_intern(&lf[260],5,"graph");
lf[261]=C_h_intern(&lf[261],5,"blank");
lf[262]=C_h_intern(&lf[262],10,"whitespace");
lf[263]=C_h_intern(&lf[263],5,"white");
lf[264]=C_h_intern(&lf[264],8,"printing");
lf[265]=C_h_intern(&lf[265],5,"print");
lf[266]=C_h_intern(&lf[266],7,"control");
lf[267]=C_h_intern(&lf[267],5,"cntrl");
lf[268]=C_h_intern(&lf[268],9,"hex-digit");
lf[269]=C_h_intern(&lf[269],6,"xdigit");
lf[270]=C_h_intern(&lf[270],5,"ascii");
lf[271]=C_h_intern(&lf[271],10,"ascii-nonl");
lf[272]=C_h_intern(&lf[272],14,"utf8-tail-char");
lf[273]=C_h_intern(&lf[273],11,"utf8-2-char");
lf[274]=C_h_intern(&lf[274],11,"utf8-3-char");
lf[275]=C_h_intern(&lf[275],11,"utf8-4-char");
lf[276]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006w/case\376\003\000\000\002\376\001\000\000\010w/nocase\376\377\016");
lf[277]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006w/case\376\003\000\000\002\376\001\000\000\006w/utf8\376\377\016");
lf[278]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\007epsilon\376\377\016");
lf[279]=C_h_intern(&lf[279],12,"list->vector");
lf[280]=C_h_intern(&lf[280],3,"map");
lf[281]=C_h_intern(&lf[281],3,"car");
lf[282]=C_h_intern(&lf[282],3,"cdr");
lf[293]=C_decode_literal(C_heaptop,"\376B\000\000!not a valid sre char-set operator");
lf[294]=C_decode_literal(C_heaptop,"\376B\000\000\030not a valid sre char-set");
lf[297]=C_h_intern(&lf[297],15,"irregex-replace");
lf[299]=C_h_intern(&lf[299],19,"irregex-replace/all");
lf[300]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[301]=C_h_intern(&lf[301],3,"pre");
lf[302]=C_h_intern(&lf[302],4,"post");
lf[303]=C_decode_literal(C_heaptop,"\376B\000\000\031unknown match replacement");
lf[304]=C_h_intern(&lf[304],7,"regexp\077");
lf[305]=C_h_intern(&lf[305],6,"regexp");
lf[307]=C_h_intern(&lf[307],12,"string-match");
lf[308]=C_h_intern(&lf[308],22,"string-match-positions");
lf[309]=C_h_intern(&lf[309],13,"string-search");
lf[310]=C_h_intern(&lf[310],23,"string-search-positions");
lf[311]=C_h_intern(&lf[311],9,"substring");
lf[312]=C_h_intern(&lf[312],19,"string-split-fields");
lf[313]=C_h_intern(&lf[313],6,"\000infix");
lf[314]=C_h_intern(&lf[314],7,"\000suffix");
lf[315]=C_h_intern(&lf[315],9,"\003syserror");
lf[316]=C_decode_literal(C_heaptop,"\376B\000\000\037record does not end with suffix");
lf[317]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[318]=C_h_intern(&lf[318],17,"string-substitute");
lf[319]=C_decode_literal(C_heaptop,"\376B\000\000\030empty substitution match");
lf[320]=C_h_intern(&lf[320],21,"\003sysfragments->string");
lf[321]=C_h_intern(&lf[321],18,"string-substitute*");
lf[322]=C_h_intern(&lf[322],5,"glob\077");
lf[323]=C_h_intern(&lf[323],12,"glob->regexp");
lf[324]=C_decode_literal(C_heaptop,"\376B\000\000!unexpected end of character class");
lf[325]=C_h_intern(&lf[325],4,"grep");
lf[326]=C_h_intern(&lf[326],13,"regexp-escape");
lf[327]=C_h_intern(&lf[327],17,"get-output-string");
lf[328]=C_h_intern(&lf[328],16,"\003syswrite-char-0");
lf[329]=C_h_intern(&lf[329],18,"open-output-string");
lf[330]=C_h_intern(&lf[330],17,"register-feature!");
lf[331]=C_h_intern(&lf[331],5,"regex");
C_register_lf2(lf,332,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4871,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* regex.scm: 64   register-feature! */
t3=*((C_word*)lf[330]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[331],lf[179]);}

/* k4869 */
static void C_ccall f_4871(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word t98;
C_word t99;
C_word t100;
C_word t101;
C_word t102;
C_word t103;
C_word t104;
C_word t105;
C_word t106;
C_word t107;
C_word t108;
C_word t109;
C_word t110;
C_word t111;
C_word t112;
C_word t113;
C_word t114;
C_word t115;
C_word t116;
C_word t117;
C_word t118;
C_word t119;
C_word t120;
C_word t121;
C_word t122;
C_word t123;
C_word t124;
C_word t125;
C_word t126;
C_word t127;
C_word t128;
C_word t129;
C_word t130;
C_word t131;
C_word t132;
C_word t133;
C_word t134;
C_word t135;
C_word t136;
C_word t137;
C_word t138;
C_word t139;
C_word t140;
C_word t141;
C_word t142;
C_word t143;
C_word t144;
C_word t145;
C_word t146;
C_word t147;
C_word t148;
C_word t149;
C_word t150;
C_word t151;
C_word t152;
C_word t153;
C_word t154;
C_word t155;
C_word t156;
C_word t157;
C_word t158;
C_word t159;
C_word t160;
C_word t161;
C_word t162;
C_word t163;
C_word t164;
C_word t165;
C_word t166;
C_word t167;
C_word t168;
C_word t169;
C_word t170;
C_word t171;
C_word t172;
C_word t173;
C_word t174;
C_word t175;
C_word t176;
C_word t177;
C_word t178;
C_word t179;
C_word t180;
C_word t181;
C_word t182;
C_word t183;
C_word t184;
C_word t185;
C_word t186;
C_word t187;
C_word t188;
C_word t189;
C_word t190;
C_word t191;
C_word t192;
C_word t193;
C_word t194;
C_word t195;
C_word t196;
C_word t197;
C_word t198;
C_word t199;
C_word t200;
C_word t201;
C_word t202;
C_word t203;
C_word t204;
C_word t205;
C_word t206;
C_word t207;
C_word t208;
C_word t209;
C_word t210;
C_word t211;
C_word t212;
C_word t213;
C_word t214;
C_word t215;
C_word t216;
C_word t217;
C_word t218;
C_word t219;
C_word t220;
C_word t221;
C_word t222;
C_word t223;
C_word t224;
C_word t225;
C_word t226;
C_word t227;
C_word t228;
C_word t229;
C_word t230;
C_word t231;
C_word t232;
C_word t233;
C_word t234;
C_word t235;
C_word t236;
C_word t237;
C_word t238;
C_word t239;
C_word t240;
C_word t241;
C_word t242;
C_word t243;
C_word t244;
C_word t245;
C_word t246;
C_word t247;
C_word t248;
C_word t249;
C_word t250;
C_word t251;
C_word t252;
C_word t253;
C_word t254;
C_word t255;
C_word t256;
C_word t257;
C_word t258;
C_word t259;
C_word t260;
C_word t261;
C_word t262;
C_word t263;
C_word t264;
C_word t265;
C_word t266;
C_word t267;
C_word t268;
C_word t269;
C_word t270;
C_word t271;
C_word t272;
C_word t273;
C_word t274;
C_word t275;
C_word t276;
C_word t277;
C_word t278;
C_word t279;
C_word t280;
C_word t281;
C_word t282;
C_word t283;
C_word t284;
C_word t285;
C_word t286;
C_word t287;
C_word t288;
C_word t289;
C_word t290;
C_word t291;
C_word t292;
C_word t293;
C_word t294;
C_word t295;
C_word t296;
C_word t297;
C_word t298;
C_word t299;
C_word t300;
C_word t301;
C_word t302;
C_word t303;
C_word t304;
C_word t305;
C_word t306;
C_word t307;
C_word t308;
C_word t309;
C_word t310;
C_word t311;
C_word t312;
C_word t313;
C_word t314;
C_word t315;
C_word t316;
C_word t317;
C_word t318;
C_word t319;
C_word t320;
C_word t321;
C_word t322;
C_word t323;
C_word t324;
C_word t325;
C_word t326;
C_word t327;
C_word t328;
C_word t329;
C_word t330;
C_word t331;
C_word t332;
C_word t333;
C_word t334;
C_word t335;
C_word t336;
C_word t337;
C_word t338;
C_word t339;
C_word t340;
C_word t341;
C_word t342;
C_word t343;
C_word t344;
C_word t345;
C_word t346;
C_word t347;
C_word t348;
C_word t349;
C_word t350;
C_word t351;
C_word t352;
C_word t353;
C_word t354;
C_word t355;
C_word t356;
C_word t357;
C_word t358;
C_word t359;
C_word t360;
C_word t361;
C_word t362;
C_word t363;
C_word t364;
C_word ab[942],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4871,2,t0,t1);}
t2=C_mutate(&lf[0] /* (set! make-irregex ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4874,tmp=(C_word)a,a+=2,tmp));
t3=C_mutate((C_word*)lf[2]+1 /* (set! irregex? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4880,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate((C_word*)lf[3]+1 /* (set! irregex-dfa ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4906,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[4]+1 /* (set! irregex-dfa/search ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4912,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[5]+1 /* (set! irregex-dfa/extract ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4918,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate((C_word*)lf[6]+1 /* (set! irregex-nfa ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4924,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate((C_word*)lf[7]+1 /* (set! irregex-flags ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4930,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate((C_word*)lf[8]+1 /* (set! irregex-submatches ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4936,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate((C_word*)lf[9]+1 /* (set! irregex-lengths ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4942,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate((C_word*)lf[10]+1 /* (set! irregex-names ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4948,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate((C_word*)lf[11]+1 /* (set! irregex-new-matches ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4954,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate((C_word*)lf[14]+1 /* (set! irregex-reset-matches! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4968,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate((C_word*)lf[15]+1 /* (set! irregex-match-data? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5002,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate((C_word*)lf[16]+1 /* (set! irregex-match-num-submatches ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5055,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate((C_word*)lf[17]+1 /* (set! irregex-match-string ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5073,tmp=(C_word)a,a+=2,tmp));
t17=C_mutate(&lf[18] /* (set! irregex-match-string-set! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5085,tmp=(C_word)a,a+=2,tmp));
t18=C_mutate(&lf[19] /* (set! irregex-match-start-index ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5091,tmp=(C_word)a,a+=2,tmp));
t19=C_mutate(&lf[20] /* (set! irregex-match-end-index ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5105,tmp=(C_word)a,a+=2,tmp));
t20=C_mutate(&lf[21] /* (set! irregex-match-start-index-set! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5119,tmp=(C_word)a,a+=2,tmp));
t21=C_mutate(&lf[22] /* (set! irregex-match-end-index-set! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5133,tmp=(C_word)a,a+=2,tmp));
t22=C_mutate(&lf[23] /* (set! irregex-match-index ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5147,tmp=(C_word)a,a+=2,tmp));
t23=C_mutate(&lf[26] /* (set! irregex-match-valid-index? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5193,tmp=(C_word)a,a+=2,tmp));
t24=C_mutate((C_word*)lf[27]+1 /* (set! irregex-match-substring ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5225,tmp=(C_word)a,a+=2,tmp));
t25=C_mutate((C_word*)lf[29]+1 /* (set! irregex-match-start ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5268,tmp=(C_word)a,a+=2,tmp));
t26=C_mutate((C_word*)lf[30]+1 /* (set! irregex-match-end ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5291,tmp=(C_word)a,a+=2,tmp));
t27=(C_word)C_a_i_cons(&a,2,C_make_character(1114111),C_SCHEME_END_OF_LIST);
t28=(C_word)C_a_i_cons(&a,2,C_make_character(57344),t27);
t29=(C_word)C_a_i_cons(&a,2,C_make_character(55295),t28);
t30=(C_word)C_a_i_cons(&a,2,C_make_character(0),t29);
t31=(C_word)C_a_i_cons(&a,2,lf[31],t30);
t32=C_mutate(&lf[32] /* (set! *all-chars* ...) */,t31);
t33=C_mutate(&lf[33] /* (set! string-scan-char ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5306,tmp=(C_word)a,a+=2,tmp));
t34=C_mutate(&lf[34] /* (set! char-alphanumeric? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5521,tmp=(C_word)a,a+=2,tmp));
t35=C_mutate(&lf[35] /* (set! string-cat-reverse ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5566,tmp=(C_word)a,a+=2,tmp));
t36=C_mutate(&lf[38] /* (set! zero-to ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5623,tmp=(C_word)a,a+=2,tmp));
t37=C_mutate(&lf[39] /* (set! take-up-to ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5662,tmp=(C_word)a,a+=2,tmp));
t38=C_mutate(&lf[41] /* (set! find ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5705,tmp=(C_word)a,a+=2,tmp));
t39=C_mutate(&lf[42] /* (set! find-tail ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5717,tmp=(C_word)a,a+=2,tmp));
t40=C_mutate(&lf[43] /* (set! last ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5749,tmp=(C_word)a,a+=2,tmp));
t41=C_mutate(&lf[45] /* (set! any ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5791,tmp=(C_word)a,a+=2,tmp));
t42=C_mutate(&lf[46] /* (set! every ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5840,tmp=(C_word)a,a+=2,tmp));
t43=C_mutate(&lf[37] /* (set! fold ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5889,tmp=(C_word)a,a+=2,tmp));
t44=C_mutate(&lf[47] /* (set! filter ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5919,tmp=(C_word)a,a+=2,tmp));
t45=C_mutate(&lf[48] /* (set! bit-shr ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6005,tmp=(C_word)a,a+=2,tmp));
t46=C_mutate(&lf[50] /* (set! bit-shl ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6015,tmp=(C_word)a,a+=2,tmp));
t47=C_mutate(&lf[51] /* (set! bit-ior ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6031,tmp=(C_word)a,a+=2,tmp));
t48=C_mutate(&lf[52] /* (set! bit-and ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6078,tmp=(C_word)a,a+=2,tmp));
t49=C_mutate(&lf[53] /* (set! flag-set? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6125,tmp=(C_word)a,a+=2,tmp));
t50=C_mutate(&lf[54] /* (set! flag-join ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6135,tmp=(C_word)a,a+=2,tmp));
t51=C_mutate(&lf[55] /* (set! flag-clear ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6144,tmp=(C_word)a,a+=2,tmp));
t52=C_mutate(&lf[56] /* (set! symbol-list->flags ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6163,tmp=(C_word)a,a+=2,tmp));
t53=C_mutate((C_word*)lf[68]+1 /* (set! string->sre ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6263,tmp=(C_word)a,a+=2,tmp));
t54=(C_word)C_a_i_cons(&a,2,C_make_character(110),C_make_character(10));
t55=(C_word)C_a_i_cons(&a,2,C_make_character(114),C_make_character(13));
t56=(C_word)C_a_i_cons(&a,2,C_make_character(116),C_make_character(9));
t57=(C_word)C_a_i_cons(&a,2,C_make_character(97),C_make_character(7));
t58=(C_word)C_a_i_cons(&a,2,C_make_character(101),C_make_character(27));
t59=(C_word)C_a_i_cons(&a,2,C_make_character(102),C_make_character(12));
t60=(C_word)C_a_i_cons(&a,2,t59,C_SCHEME_END_OF_LIST);
t61=(C_word)C_a_i_cons(&a,2,t58,t60);
t62=(C_word)C_a_i_cons(&a,2,t57,t61);
t63=(C_word)C_a_i_cons(&a,2,t56,t62);
t64=(C_word)C_a_i_cons(&a,2,t55,t63);
t65=(C_word)C_a_i_cons(&a,2,t54,t64);
t66=C_mutate(&lf[140] /* (set! posix-escape-sequences ...) */,t65);
t67=C_mutate(&lf[69] /* (set! char-altcase ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9172,tmp=(C_word)a,a+=2,tmp));
t68=C_mutate(&lf[139] /* (set! string-parse-hex-escape ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9214,tmp=(C_word)a,a+=2,tmp));
t69=C_mutate(&lf[128] /* (set! high-char? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9937,tmp=(C_word)a,a+=2,tmp));
t70=C_mutate(&lf[130] /* (set! utf8-start-char->length ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9947,tmp=(C_word)a,a+=2,tmp));
t71=C_mutate(&lf[74] /* (set! utf8-string-ref ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9957,tmp=(C_word)a,a+=2,tmp));
t72=C_mutate(&lf[169] /* (set! utf8-lowest-digit-of-length ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10182,tmp=(C_word)a,a+=2,tmp));
t73=C_mutate(&lf[171] /* (set! char->utf8-list ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10242,tmp=(C_word)a,a+=2,tmp));
t74=C_mutate(&lf[173] /* (set! unicode-range-helper ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10518,tmp=(C_word)a,a+=2,tmp));
t75=C_mutate(&lf[175] /* (set! unicode-range-up-from ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10604,tmp=(C_word)a,a+=2,tmp));
t76=C_mutate(&lf[176] /* (set! unicode-range-up-to ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10732,tmp=(C_word)a,a+=2,tmp));
t77=C_mutate(&lf[177] /* (set! cset->utf8-pattern ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11216,tmp=(C_word)a,a+=2,tmp));
t78=C_mutate((C_word*)lf[179]+1 /* (set! irregex ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11666,tmp=(C_word)a,a+=2,tmp));
t79=C_mutate((C_word*)lf[180]+1 /* (set! string->irregex ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11687,tmp=(C_word)a,a+=2,tmp));
t80=C_mutate((C_word*)lf[181]+1 /* (set! sre->irregex ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11697,tmp=(C_word)a,a+=2,tmp));
t81=C_mutate(&lf[103] /* (set! sre-empty? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11838,tmp=(C_word)a,a+=2,tmp));
t82=C_mutate(&lf[238] /* (set! sre-any? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11966,tmp=(C_word)a,a+=2,tmp));
t83=C_mutate(&lf[100] /* (set! sre-repeater? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12042,tmp=(C_word)a,a+=2,tmp));
t84=C_mutate(&lf[232] /* (set! sre-searcher? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12098,tmp=(C_word)a,a+=2,tmp));
t85=C_mutate(&lf[210] /* (set! sre-consumer? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12184,tmp=(C_word)a,a+=2,tmp));
t86=C_mutate(&lf[228] /* (set! sre-has-submatchs? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12270,tmp=(C_word)a,a+=2,tmp));
t87=C_mutate(&lf[183] /* (set! sre-count-submatches ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12296,tmp=(C_word)a,a+=2,tmp));
t88=C_mutate(&lf[71] /* (set! sre-sequence ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_13391,tmp=(C_word)a,a+=2,tmp));
t89=C_mutate(&lf[75] /* (set! sre-alternate ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_13416,tmp=(C_word)a,a+=2,tmp));
t90=C_mutate(&lf[189] /* (set! sre-strip-submatches ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_13441,tmp=(C_word)a,a+=2,tmp));
t91=C_mutate(&lf[209] /* (set! sre-names ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_13556,tmp=(C_word)a,a+=2,tmp));
t92=C_mutate(&lf[240] /* (set! sre-sequence-names ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_13786,tmp=(C_word)a,a+=2,tmp));
t93=C_mutate(&lf[231] /* (set! sre-remove-initial-bos ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_13822,tmp=(C_word)a,a+=2,tmp));
t94=C_mutate((C_word*)lf[241]+1 /* (set! irregex-search ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_13939,tmp=(C_word)a,a+=2,tmp));
t95=C_mutate((C_word*)lf[242]+1 /* (set! irregex-search/matches ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_13985,tmp=(C_word)a,a+=2,tmp));
t96=C_mutate((C_word*)lf[246]+1 /* (set! irregex-match ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_14144,tmp=(C_word)a,a+=2,tmp));
t97=C_mutate(&lf[243] /* (set! dfa-init-state ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_14211,tmp=(C_word)a,a+=2,tmp));
t98=C_mutate(&lf[245] /* (set! dfa-next-state ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_14217,tmp=(C_word)a,a+=2,tmp));
t99=C_mutate(&lf[244] /* (set! dfa-final-state? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_14227,tmp=(C_word)a,a+=2,tmp));
t100=C_mutate(&lf[225] /* (set! dfa-match/longest ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_14322,tmp=(C_word)a,a+=2,tmp));
t101=(C_word)C_a_i_cons(&a,2,lf[88],lf[32]);
t102=(C_word)C_a_i_string(&a,1,C_make_character(10));
t103=(C_word)C_a_i_cons(&a,2,t102,C_SCHEME_END_OF_LIST);
t104=(C_word)C_a_i_cons(&a,2,t103,C_SCHEME_END_OF_LIST);
t105=(C_word)C_a_i_cons(&a,2,lf[32],t104);
t106=(C_word)C_a_i_cons(&a,2,lf[204],t105);
t107=(C_word)C_a_i_cons(&a,2,lf[89],t106);
t108=(C_word)C_a_i_cons(&a,2,C_make_character(90),C_SCHEME_END_OF_LIST);
t109=(C_word)C_a_i_cons(&a,2,C_make_character(65),t108);
t110=(C_word)C_a_i_cons(&a,2,C_make_character(122),t109);
t111=(C_word)C_a_i_cons(&a,2,C_make_character(97),t110);
t112=(C_word)C_a_i_cons(&a,2,lf[31],t111);
t113=(C_word)C_a_i_cons(&a,2,lf[247],t112);
t114=(C_word)C_a_i_cons(&a,2,lf[248],lf[247]);
t115=(C_word)C_a_i_cons(&a,2,C_make_character(57),C_SCHEME_END_OF_LIST);
t116=(C_word)C_a_i_cons(&a,2,C_make_character(48),t115);
t117=(C_word)C_a_i_cons(&a,2,C_make_character(90),t116);
t118=(C_word)C_a_i_cons(&a,2,C_make_character(65),t117);
t119=(C_word)C_a_i_cons(&a,2,C_make_character(122),t118);
t120=(C_word)C_a_i_cons(&a,2,C_make_character(97),t119);
t121=(C_word)C_a_i_cons(&a,2,lf[31],t120);
t122=(C_word)C_a_i_cons(&a,2,lf[146],t121);
t123=(C_word)C_a_i_cons(&a,2,lf[249],lf[146]);
t124=(C_word)C_a_i_cons(&a,2,lf[250],lf[146]);
t125=(C_word)C_a_i_cons(&a,2,C_make_character(122),C_SCHEME_END_OF_LIST);
t126=(C_word)C_a_i_cons(&a,2,C_make_character(97),t125);
t127=(C_word)C_a_i_cons(&a,2,lf[31],t126);
t128=(C_word)C_a_i_cons(&a,2,lf[251],t127);
t129=(C_word)C_a_i_cons(&a,2,lf[252],lf[251]);
t130=(C_word)C_a_i_cons(&a,2,C_make_character(90),C_SCHEME_END_OF_LIST);
t131=(C_word)C_a_i_cons(&a,2,C_make_character(65),t130);
t132=(C_word)C_a_i_cons(&a,2,lf[31],t131);
t133=(C_word)C_a_i_cons(&a,2,lf[253],t132);
t134=(C_word)C_a_i_cons(&a,2,lf[254],lf[253]);
t135=(C_word)C_a_i_cons(&a,2,C_make_character(57),C_SCHEME_END_OF_LIST);
t136=(C_word)C_a_i_cons(&a,2,C_make_character(48),t135);
t137=(C_word)C_a_i_cons(&a,2,lf[31],t136);
t138=(C_word)C_a_i_cons(&a,2,lf[143],t137);
t139=(C_word)C_a_i_cons(&a,2,lf[255],lf[143]);
t140=(C_word)C_a_i_cons(&a,2,lf[256],lf[143]);
t141=(C_word)C_a_i_cons(&a,2,C_make_character(125),C_SCHEME_END_OF_LIST);
t142=(C_word)C_a_i_cons(&a,2,C_make_character(123),t141);
t143=(C_word)C_a_i_cons(&a,2,C_make_character(95),t142);
t144=(C_word)C_a_i_cons(&a,2,C_make_character(93),t143);
t145=(C_word)C_a_i_cons(&a,2,C_make_character(92),t144);
t146=(C_word)C_a_i_cons(&a,2,C_make_character(91),t145);
t147=(C_word)C_a_i_cons(&a,2,C_make_character(64),t146);
t148=(C_word)C_a_i_cons(&a,2,C_make_character(63),t147);
t149=(C_word)C_a_i_cons(&a,2,C_make_character(59),t148);
t150=(C_word)C_a_i_cons(&a,2,C_make_character(58),t149);
t151=(C_word)C_a_i_cons(&a,2,C_make_character(47),t150);
t152=(C_word)C_a_i_cons(&a,2,C_make_character(46),t151);
t153=(C_word)C_a_i_cons(&a,2,C_make_character(45),t152);
t154=(C_word)C_a_i_cons(&a,2,C_make_character(44),t153);
t155=(C_word)C_a_i_cons(&a,2,C_make_character(42),t154);
t156=(C_word)C_a_i_cons(&a,2,C_make_character(41),t155);
t157=(C_word)C_a_i_cons(&a,2,C_make_character(40),t156);
t158=(C_word)C_a_i_cons(&a,2,C_make_character(39),t157);
t159=(C_word)C_a_i_cons(&a,2,C_make_character(38),t158);
t160=(C_word)C_a_i_cons(&a,2,C_make_character(37),t159);
t161=(C_word)C_a_i_cons(&a,2,C_make_character(35),t160);
t162=(C_word)C_a_i_cons(&a,2,C_make_character(34),t161);
t163=(C_word)C_a_i_cons(&a,2,C_make_character(33),t162);
t164=(C_word)C_a_i_cons(&a,2,lf[70],t163);
t165=(C_word)C_a_i_cons(&a,2,lf[257],t164);
t166=(C_word)C_a_i_cons(&a,2,lf[258],lf[257]);
t167=(C_word)C_a_i_cons(&a,2,C_make_character(126),C_SCHEME_END_OF_LIST);
t168=(C_word)C_a_i_cons(&a,2,C_make_character(124),t167);
t169=(C_word)C_a_i_cons(&a,2,C_make_character(96),t168);
t170=(C_word)C_a_i_cons(&a,2,C_make_character(94),t169);
t171=(C_word)C_a_i_cons(&a,2,C_make_character(62),t170);
t172=(C_word)C_a_i_cons(&a,2,C_make_character(61),t171);
t173=(C_word)C_a_i_cons(&a,2,C_make_character(60),t172);
t174=(C_word)C_a_i_cons(&a,2,C_make_character(43),t173);
t175=(C_word)C_a_i_cons(&a,2,C_make_character(36),t174);
t176=(C_word)C_a_i_cons(&a,2,lf[257],t175);
t177=(C_word)C_a_i_cons(&a,2,lf[146],t176);
t178=(C_word)C_a_i_cons(&a,2,lf[70],t177);
t179=(C_word)C_a_i_cons(&a,2,lf[259],t178);
t180=(C_word)C_a_i_cons(&a,2,lf[260],lf[259]);
t181=(C_word)C_a_i_cons(&a,2,C_make_character(9),C_SCHEME_END_OF_LIST);
t182=(C_word)C_a_i_cons(&a,2,C_make_character(32),t181);
t183=(C_word)C_a_i_cons(&a,2,lf[70],t182);
t184=(C_word)C_a_i_cons(&a,2,lf[261],t183);
t185=(C_word)C_a_i_cons(&a,2,C_make_character(10),C_SCHEME_END_OF_LIST);
t186=(C_word)C_a_i_cons(&a,2,lf[261],t185);
t187=(C_word)C_a_i_cons(&a,2,lf[70],t186);
t188=(C_word)C_a_i_cons(&a,2,lf[262],t187);
t189=(C_word)C_a_i_cons(&a,2,lf[144],lf[262]);
t190=(C_word)C_a_i_cons(&a,2,lf[263],lf[262]);
t191=(C_word)C_a_i_cons(&a,2,lf[262],C_SCHEME_END_OF_LIST);
t192=(C_word)C_a_i_cons(&a,2,lf[259],t191);
t193=(C_word)C_a_i_cons(&a,2,lf[70],t192);
t194=(C_word)C_a_i_cons(&a,2,lf[264],t193);
t195=(C_word)C_a_i_cons(&a,2,lf[265],lf[264]);
t196=(C_word)C_a_i_cons(&a,2,C_make_character(31),C_SCHEME_END_OF_LIST);
t197=(C_word)C_a_i_cons(&a,2,C_make_character(0),t196);
t198=(C_word)C_a_i_cons(&a,2,lf[31],t197);
t199=(C_word)C_a_i_cons(&a,2,lf[266],t198);
t200=(C_word)C_a_i_cons(&a,2,lf[267],lf[266]);
t201=(C_word)C_a_i_cons(&a,2,C_make_character(70),C_SCHEME_END_OF_LIST);
t202=(C_word)C_a_i_cons(&a,2,C_make_character(65),t201);
t203=(C_word)C_a_i_cons(&a,2,C_make_character(102),t202);
t204=(C_word)C_a_i_cons(&a,2,C_make_character(97),t203);
t205=(C_word)C_a_i_cons(&a,2,lf[31],t204);
t206=(C_word)C_a_i_cons(&a,2,t205,C_SCHEME_END_OF_LIST);
t207=(C_word)C_a_i_cons(&a,2,lf[143],t206);
t208=(C_word)C_a_i_cons(&a,2,lf[70],t207);
t209=(C_word)C_a_i_cons(&a,2,lf[268],t208);
t210=(C_word)C_a_i_cons(&a,2,lf[269],lf[268]);
t211=(C_word)C_a_i_cons(&a,2,C_make_character(127),C_SCHEME_END_OF_LIST);
t212=(C_word)C_a_i_cons(&a,2,C_make_character(0),t211);
t213=(C_word)C_a_i_cons(&a,2,lf[31],t212);
t214=(C_word)C_a_i_cons(&a,2,lf[270],t213);
t215=(C_word)C_a_i_cons(&a,2,C_make_character(127),C_SCHEME_END_OF_LIST);
t216=(C_word)C_a_i_cons(&a,2,C_make_character(11),t215);
t217=(C_word)C_a_i_cons(&a,2,C_make_character(9),t216);
t218=(C_word)C_a_i_cons(&a,2,C_make_character(0),t217);
t219=(C_word)C_a_i_cons(&a,2,lf[31],t218);
t220=(C_word)C_a_i_cons(&a,2,lf[271],t219);
t221=(C_word)C_a_i_cons(&a,2,C_make_character(10),C_SCHEME_END_OF_LIST);
t222=(C_word)C_a_i_cons(&a,2,C_make_character(13),t221);
t223=(C_word)C_a_i_cons(&a,2,lf[82],t222);
t224=(C_word)C_a_i_cons(&a,2,C_make_character(13),C_SCHEME_END_OF_LIST);
t225=(C_word)C_a_i_cons(&a,2,C_make_character(10),t224);
t226=(C_word)C_a_i_cons(&a,2,lf[31],t225);
t227=(C_word)C_a_i_cons(&a,2,t226,C_SCHEME_END_OF_LIST);
t228=(C_word)C_a_i_cons(&a,2,t223,t227);
t229=(C_word)C_a_i_cons(&a,2,lf[70],t228);
t230=(C_word)C_a_i_cons(&a,2,lf[153],t229);
t231=(C_word)C_a_i_cons(&a,2,C_make_character(95),C_SCHEME_END_OF_LIST);
t232=(C_word)C_a_i_cons(&a,2,lf[146],t231);
t233=(C_word)C_a_i_cons(&a,2,lf[70],t232);
t234=(C_word)C_a_i_cons(&a,2,t233,C_SCHEME_END_OF_LIST);
t235=(C_word)C_a_i_cons(&a,2,lf[93],t234);
t236=(C_word)C_a_i_cons(&a,2,lf[148],C_SCHEME_END_OF_LIST);
t237=(C_word)C_a_i_cons(&a,2,t235,t236);
t238=(C_word)C_a_i_cons(&a,2,lf[149],t237);
t239=(C_word)C_a_i_cons(&a,2,lf[82],t238);
t240=(C_word)C_a_i_cons(&a,2,lf[190],t239);
t241=(C_word)C_a_i_cons(&a,2,C_make_character(193),C_SCHEME_END_OF_LIST);
t242=(C_word)C_a_i_cons(&a,2,C_make_character(128),t241);
t243=(C_word)C_a_i_cons(&a,2,lf[31],t242);
t244=(C_word)C_a_i_cons(&a,2,lf[272],t243);
t245=(C_word)C_a_i_cons(&a,2,C_make_character(223),C_SCHEME_END_OF_LIST);
t246=(C_word)C_a_i_cons(&a,2,C_make_character(194),t245);
t247=(C_word)C_a_i_cons(&a,2,lf[31],t246);
t248=(C_word)C_a_i_cons(&a,2,lf[272],C_SCHEME_END_OF_LIST);
t249=(C_word)C_a_i_cons(&a,2,t247,t248);
t250=(C_word)C_a_i_cons(&a,2,lf[82],t249);
t251=(C_word)C_a_i_cons(&a,2,lf[273],t250);
t252=(C_word)C_a_i_cons(&a,2,C_make_character(239),C_SCHEME_END_OF_LIST);
t253=(C_word)C_a_i_cons(&a,2,C_make_character(224),t252);
t254=(C_word)C_a_i_cons(&a,2,lf[31],t253);
t255=(C_word)C_a_i_cons(&a,2,lf[272],C_SCHEME_END_OF_LIST);
t256=(C_word)C_a_i_cons(&a,2,lf[272],t255);
t257=(C_word)C_a_i_cons(&a,2,t254,t256);
t258=(C_word)C_a_i_cons(&a,2,lf[82],t257);
t259=(C_word)C_a_i_cons(&a,2,lf[274],t258);
t260=(C_word)C_a_i_cons(&a,2,C_make_character(247),C_SCHEME_END_OF_LIST);
t261=(C_word)C_a_i_cons(&a,2,C_make_character(240),t260);
t262=(C_word)C_a_i_cons(&a,2,lf[31],t261);
t263=(C_word)C_a_i_cons(&a,2,lf[272],C_SCHEME_END_OF_LIST);
t264=(C_word)C_a_i_cons(&a,2,lf[272],t263);
t265=(C_word)C_a_i_cons(&a,2,lf[272],t264);
t266=(C_word)C_a_i_cons(&a,2,t262,t265);
t267=(C_word)C_a_i_cons(&a,2,lf[82],t266);
t268=(C_word)C_a_i_cons(&a,2,lf[275],t267);
t269=(C_word)C_a_i_cons(&a,2,lf[275],C_SCHEME_END_OF_LIST);
t270=(C_word)C_a_i_cons(&a,2,lf[274],t269);
t271=(C_word)C_a_i_cons(&a,2,lf[273],t270);
t272=(C_word)C_a_i_cons(&a,2,lf[270],t271);
t273=(C_word)C_a_i_cons(&a,2,lf[70],t272);
t274=(C_word)C_a_i_cons(&a,2,lf[235],t273);
t275=(C_word)C_a_i_cons(&a,2,lf[275],C_SCHEME_END_OF_LIST);
t276=(C_word)C_a_i_cons(&a,2,lf[274],t275);
t277=(C_word)C_a_i_cons(&a,2,lf[273],t276);
t278=(C_word)C_a_i_cons(&a,2,lf[271],t277);
t279=(C_word)C_a_i_cons(&a,2,lf[70],t278);
t280=(C_word)C_a_i_cons(&a,2,lf[236],t279);
t281=(C_word)C_a_i_cons(&a,2,t280,C_SCHEME_END_OF_LIST);
t282=(C_word)C_a_i_cons(&a,2,t274,t281);
t283=(C_word)C_a_i_cons(&a,2,t268,t282);
t284=(C_word)C_a_i_cons(&a,2,t259,t283);
t285=(C_word)C_a_i_cons(&a,2,t251,t284);
t286=(C_word)C_a_i_cons(&a,2,t244,t285);
t287=(C_word)C_a_i_cons(&a,2,t240,t286);
t288=(C_word)C_a_i_cons(&a,2,t230,t287);
t289=(C_word)C_a_i_cons(&a,2,t220,t288);
t290=(C_word)C_a_i_cons(&a,2,t214,t289);
t291=(C_word)C_a_i_cons(&a,2,t210,t290);
t292=(C_word)C_a_i_cons(&a,2,t209,t291);
t293=(C_word)C_a_i_cons(&a,2,t200,t292);
t294=(C_word)C_a_i_cons(&a,2,t199,t293);
t295=(C_word)C_a_i_cons(&a,2,t195,t294);
t296=(C_word)C_a_i_cons(&a,2,t194,t295);
t297=(C_word)C_a_i_cons(&a,2,t190,t296);
t298=(C_word)C_a_i_cons(&a,2,t189,t297);
t299=(C_word)C_a_i_cons(&a,2,t188,t298);
t300=(C_word)C_a_i_cons(&a,2,t184,t299);
t301=(C_word)C_a_i_cons(&a,2,t180,t300);
t302=(C_word)C_a_i_cons(&a,2,t179,t301);
t303=(C_word)C_a_i_cons(&a,2,t166,t302);
t304=(C_word)C_a_i_cons(&a,2,t165,t303);
t305=(C_word)C_a_i_cons(&a,2,t140,t304);
t306=(C_word)C_a_i_cons(&a,2,t139,t305);
t307=(C_word)C_a_i_cons(&a,2,t138,t306);
t308=(C_word)C_a_i_cons(&a,2,t134,t307);
t309=(C_word)C_a_i_cons(&a,2,t133,t308);
t310=(C_word)C_a_i_cons(&a,2,t129,t309);
t311=(C_word)C_a_i_cons(&a,2,t128,t310);
t312=(C_word)C_a_i_cons(&a,2,t124,t311);
t313=(C_word)C_a_i_cons(&a,2,t123,t312);
t314=(C_word)C_a_i_cons(&a,2,t122,t313);
t315=(C_word)C_a_i_cons(&a,2,t114,t314);
t316=(C_word)C_a_i_cons(&a,2,t113,t315);
t317=(C_word)C_a_i_cons(&a,2,t107,t316);
t318=(C_word)C_a_i_cons(&a,2,t101,t317);
t319=C_mutate(&lf[205] /* (set! sre-named-definitions ...) */,t318);
t320=C_mutate(&lf[227] /* (set! sre->nfa ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_14429,tmp=(C_word)a,a+=2,tmp));
t321=C_mutate(&lf[226] /* (set! nfa->dfa ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_15219,tmp=(C_word)a,a+=2,tmp));
t322=C_mutate(&lf[284] /* (set! nfa-join-transitions! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_15516,tmp=(C_word)a,a+=2,tmp));
t323=C_mutate(&lf[288] /* (set! char-range ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_15978,tmp=(C_word)a,a+=2,tmp));
t324=C_mutate(&lf[286] /* (set! split-char-range ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_15990,tmp=(C_word)a,a+=2,tmp));
t325=C_mutate(&lf[287] /* (set! intersect-char-ranges ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_16064,tmp=(C_word)a,a+=2,tmp));
t326=C_mutate(&lf[283] /* (set! nfa-closure ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_16180,tmp=(C_word)a,a+=2,tmp));
t327=C_mutate(&lf[285] /* (set! insert-sorted ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_16261,tmp=(C_word)a,a+=2,tmp));
t328=C_mutate(&lf[182] /* (set! sre-cset->procedure ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_18625,tmp=(C_word)a,a+=2,tmp));
t329=C_mutate(&lf[136] /* (set! sre->cset ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_18742,tmp=(C_word)a,a+=2,tmp));
t330=C_mutate(&lf[289] /* (set! cset-contains? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_19023,tmp=(C_word)a,a+=2,tmp));
t331=C_mutate(&lf[295] /* (set! cset-range ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_19061,tmp=(C_word)a,a+=2,tmp));
t332=C_mutate(&lf[296] /* (set! char-ranges-overlap? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_19073,tmp=(C_word)a,a+=2,tmp));
t333=C_mutate(&lf[290] /* (set! cset-union ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_19218,tmp=(C_word)a,a+=2,tmp));
t334=C_mutate(&lf[292] /* (set! cset-difference ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_19305,tmp=(C_word)a,a+=2,tmp));
t335=C_mutate(&lf[291] /* (set! cset-intersection ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_19426,tmp=(C_word)a,a+=2,tmp));
t336=C_mutate(&lf[135] /* (set! cset-complement ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_19544,tmp=(C_word)a,a+=2,tmp));
t337=C_mutate(&lf[126] /* (set! cset-case-insensitive ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_19554,tmp=(C_word)a,a+=2,tmp));
t338=C_mutate((C_word*)lf[297]+1 /* (set! irregex-replace ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_19832,tmp=(C_word)a,a+=2,tmp));
t339=C_mutate((C_word*)lf[299]+1 /* (set! irregex-replace/all ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_19884,tmp=(C_word)a,a+=2,tmp));
t340=C_mutate(&lf[298] /* (set! irregex-apply-match ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_19940,tmp=(C_word)a,a+=2,tmp));
t341=C_mutate((C_word*)lf[304]+1 /* (set! regexp? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_20122,tmp=(C_word)a,a+=2,tmp));
t342=C_mutate((C_word*)lf[305]+1 /* (set! regexp ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_20140,tmp=(C_word)a,a+=2,tmp));
t343=C_mutate(&lf[306] /* (set! unregexp ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_20243,tmp=(C_word)a,a+=2,tmp));
t344=C_mutate((C_word*)lf[307]+1 /* (set! string-match ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_20264,tmp=(C_word)a,a+=2,tmp));
t345=C_mutate((C_word*)lf[308]+1 /* (set! string-match-positions ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_20310,tmp=(C_word)a,a+=2,tmp));
t346=C_mutate((C_word*)lf[309]+1 /* (set! string-search ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_20372,tmp=(C_word)a,a+=2,tmp));
t347=C_mutate((C_word*)lf[310]+1 /* (set! string-search-positions ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_20484,tmp=(C_word)a,a+=2,tmp));
t348=*((C_word*)lf[40]+1);
t349=*((C_word*)lf[311]+1);
t350=*((C_word*)lf[310]+1);
t351=C_mutate((C_word*)lf[312]+1 /* (set! string-split-fields ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_20604,a[2]=t348,a[3]=t350,a[4]=t349,tmp=(C_word)a,a+=5,tmp));
t352=*((C_word*)lf[311]+1);
t353=*((C_word*)lf[40]+1);
t354=*((C_word*)lf[36]+1);
t355=*((C_word*)lf[310]+1);
t356=C_mutate((C_word*)lf[318]+1 /* (set! string-substitute ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_20786,a[2]=t355,a[3]=t353,a[4]=t352,tmp=(C_word)a,a+=5,tmp));
t357=*((C_word*)lf[318]+1);
t358=C_mutate((C_word*)lf[321]+1 /* (set! string-substitute* ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_21038,a[2]=t357,tmp=(C_word)a,a+=3,tmp));
t359=C_mutate((C_word*)lf[322]+1 /* (set! glob? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_21090,tmp=(C_word)a,a+=2,tmp));
t360=C_mutate((C_word*)lf[323]+1 /* (set! glob->regexp ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_21175,tmp=(C_word)a,a+=2,tmp));
t361=*((C_word*)lf[309]+1);
t362=C_mutate((C_word*)lf[325]+1 /* (set! grep ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_21452,a[2]=t361,tmp=(C_word)a,a+=3,tmp));
t363=C_mutate((C_word*)lf[326]+1 /* (set! regexp-escape ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_21492,tmp=(C_word)a,a+=2,tmp));
t364=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t364+1)))(2,t364,C_SCHEME_UNDEFINED);}

/* regexp-escape in k4869 */
static void C_ccall f_21492(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_21492,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[326]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_21499,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* regex.scm: 317  open-output-string */
t5=*((C_word*)lf[329]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* k21497 in regexp-escape in k4869 */
static void C_ccall f_21499(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_21499,2,t0,t1);}
t2=(C_word)C_block_size(((C_word*)t0)[3]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_21507,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_21507(t6,((C_word*)t0)[2],C_fix(0));}

/* loop in k21497 in regexp-escape in k4869 */
static void C_fcall f_21507(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_21507,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
/* regex.scm: 320  get-output-string */
t3=*((C_word*)lf[327]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,((C_word*)t0)[4]);}
else{
t3=(C_word)C_subchar(((C_word*)t0)[3],t2);
if(C_truep((C_truep((C_word)C_eqp(t3,C_make_character(46)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(92)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(63)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(42)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(43)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(94)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(36)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(40)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(41)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(91)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(93)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(124)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(123)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(125)))?C_SCHEME_TRUE:C_SCHEME_FALSE)))))))))))))))){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_21526,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* regex.scm: 323  ##sys#write-char-0 */
t5=*((C_word*)lf[328]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_make_character(92),((C_word*)t0)[4]);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_21539,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* regex.scm: 327  ##sys#write-char-0 */
t5=*((C_word*)lf[328]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,(C_word)C_subchar(((C_word*)t0)[3],t2),((C_word*)t0)[4]);}}}

/* k21537 in loop in k21497 in regexp-escape in k4869 */
static void C_ccall f_21539(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* regex.scm: 328  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_21507(t3,((C_word*)t0)[2],t2);}

/* k21524 in loop in k21497 in regexp-escape in k4869 */
static void C_ccall f_21526(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_21526,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_21529,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* regex.scm: 324  ##sys#write-char-0 */
t3=*((C_word*)lf[328]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,(C_word)C_subchar(((C_word*)t0)[3],((C_word*)t0)[6]),((C_word*)t0)[2]);}

/* k21527 in k21524 in loop in k21497 in regexp-escape in k4869 */
static void C_ccall f_21529(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* regex.scm: 325  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_21507(t3,((C_word*)t0)[2],t2);}

/* grep in k4869 */
static void C_ccall f_21452(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_21452,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_list_2(t3,lf[325]);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_21461,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t6,tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_21461(t8,t1,t3);}

/* loop in grep in k4869 */
static void C_fcall f_21461(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_21461,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_21480,a[2]=t4,a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* regex.scm: 305  string-search */
t6=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,((C_word*)t0)[2],t3);}}

/* k21478 in loop in grep in k4869 */
static void C_ccall f_21480(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_21480,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_21487,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* regex.scm: 306  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_21461(t3,t2,((C_word*)t0)[2]);}
else{
/* regex.scm: 307  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_21461(t2,((C_word*)t0)[5],((C_word*)t0)[2]);}}

/* k21485 in k21478 in loop in grep in k4869 */
static void C_ccall f_21487(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_21487,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* glob->regexp in k4869 */
static void C_ccall f_21175(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_21175,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[323]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_21186,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_21190,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* string->list */
t6=*((C_word*)lf[73]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k21188 in glob->regexp in k4869 */
static void C_ccall f_21190(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_21190,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_21192,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_21192(t5,((C_word*)t0)[2],t1);}

/* loop in k21188 in glob->regexp in k4869 */
static void C_fcall f_21192(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word *a;
loop:
a=C_alloc(10);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_21192,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_slot(t2,C_fix(1));
switch(t3){
case C_make_character(42):
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_21222,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_21226,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* regex.scm: 271  loop */
t18=t6;
t19=t4;
t1=t18;
t2=t19;
goto loop;
case C_make_character(63):
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_21239,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* regex.scm: 272  loop */
t18=t5;
t19=t4;
t1=t18;
t2=t19;
goto loop;
case C_make_character(91):
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_21252,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_21254,a[2]=((C_word*)t0)[2],a[3]=t7,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp));
t9=((C_word*)t7)[1];
f_21254(t9,t5,t4);
default:
t5=(C_word)C_u_i_char_alphabeticp(t3);
t6=(C_truep(t5)?t5:(C_word)C_u_i_char_numericp(t3));
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_21432,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* regex.scm: 290  loop */
t18=t7;
t19=t4;
t1=t18;
t2=t19;
goto loop;}
else{
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_21443,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_21447,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
/* regex.scm: 291  loop */
t18=t8;
t19=t4;
t1=t18;
t2=t19;
goto loop;}}}}

/* k21445 in loop in k21188 in glob->regexp in k4869 */
static void C_ccall f_21447(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[84]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k21441 in loop in k21188 in glob->regexp in k4869 */
static void C_ccall f_21443(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_21443,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,C_make_character(92),t2));}

/* k21430 in loop in k21188 in glob->regexp in k4869 */
static void C_ccall f_21432(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_21432,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* loop2 in loop in k21188 in glob->regexp in k4869 */
static void C_fcall f_21254(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_21254,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_eqp(C_make_character(93),t3);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_21274,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=(C_word)C_slot(t2,C_fix(1));
/* regex.scm: 279  loop */
t7=((C_word*)((C_word*)t0)[4])[1];
f_21192(t7,t5,t6);}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_21284,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_u_i_car(t2);
t7=(C_word)C_eqp(C_make_character(45),t6);
if(C_truep(t7)){
t8=(C_word)C_slot(t2,C_fix(1));
t9=t5;
f_21284(t9,(C_word)C_i_pairp(t8));}
else{
t8=t5;
f_21284(t8,C_SCHEME_FALSE);}}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k21282 in loop2 in loop in k21188 in glob->regexp in k4869 */
static void C_fcall f_21284(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_21284,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_u_i_cadr(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_21299,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_21303,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_u_i_cddr(((C_word*)t0)[5]);
/* regex.scm: 281  loop2 */
t6=((C_word*)((C_word*)t0)[3])[1];
f_21254(t6,t4,t5);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_21313,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
if(C_truep((C_word)C_i_pairp(t3))){
t4=(C_word)C_u_i_cddr(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_pairp(t4))){
t5=(C_word)C_u_i_cadr(((C_word*)t0)[5]);
t6=t2;
f_21313(t6,(C_word)C_eqp(C_make_character(45),t5));}
else{
t5=t2;
f_21313(t5,C_SCHEME_FALSE);}}
else{
t4=t2;
f_21313(t4,C_SCHEME_FALSE);}}}

/* k21311 in k21282 in loop2 in loop in k21188 in glob->regexp in k4869 */
static void C_fcall f_21313(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_21313,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_u_i_car(((C_word*)t0)[5]);
t3=(C_word)C_u_i_caddr(((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_21336,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_21340,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(C_word)C_u_i_cdddr(((C_word*)t0)[5]);
/* regex.scm: 285  loop2 */
t7=((C_word*)((C_word*)t0)[3])[1];
f_21254(t7,t5,t6);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[5]))){
t2=(C_word)C_u_i_car(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_21361,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* regex.scm: 287  loop2 */
t5=((C_word*)((C_word*)t0)[3])[1];
f_21254(t5,t3,t4);}
else{
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[5]))){
/* regex.scm: 289  error */
t2=*((C_word*)lf[24]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],lf[323],lf[324],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}}}

/* k21359 in k21311 in k21282 in loop2 in loop in k21188 in glob->regexp in k4869 */
static void C_ccall f_21361(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_21361,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k21338 in k21311 in k21282 in loop2 in loop in k21188 in glob->regexp in k4869 */
static void C_ccall f_21340(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[84]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k21334 in k21311 in k21282 in loop2 in loop in k21188 in glob->regexp in k4869 */
static void C_ccall f_21336(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_21336,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,C_make_character(45),t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* k21301 in k21282 in loop2 in loop in k21188 in glob->regexp in k4869 */
static void C_ccall f_21303(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[84]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k21297 in k21282 in loop2 in loop in k21188 in glob->regexp in k4869 */
static void C_ccall f_21299(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_21299,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,C_make_character(45),t2));}

/* k21272 in loop2 in loop in k21188 in glob->regexp in k4869 */
static void C_ccall f_21274(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_21274,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,C_make_character(93),t1));}

/* k21250 in loop in k21188 in glob->regexp in k4869 */
static void C_ccall f_21252(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_21252,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,C_make_character(91),t1));}

/* k21237 in loop in k21188 in glob->regexp in k4869 */
static void C_ccall f_21239(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_21239,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,C_make_character(46),t1));}

/* k21224 in loop in k21188 in glob->regexp in k4869 */
static void C_ccall f_21226(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[84]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k21220 in loop in k21188 in glob->regexp in k4869 */
static void C_ccall f_21222(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_21222,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_make_character(42),t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,C_make_character(46),t2));}

/* k21184 in glob->regexp in k4869 */
static void C_ccall f_21186(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* list->string */
t2=*((C_word*)lf[127]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* glob? in k4869 */
static void C_ccall f_21090(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_21090,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[322]);
t4=(C_word)C_fix((C_word)C_header_size(t2));
t5=(C_word)C_u_fixnum_difference(t4,C_fix(1));
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_21103,a[2]=t7,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_21103(t9,t1,t5);}

/* loop in glob? in k4869 */
static void C_fcall f_21103(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_21103,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_less_or_equal_p(C_fix(0),t2))){
t3=(C_word)C_subchar(((C_word*)t0)[3],t2);
t4=(C_word)C_eqp(t3,C_make_character(42));
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_21122,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t4)){
t6=t5;
f_21122(t6,t4);}
else{
t6=(C_word)C_eqp(t3,C_make_character(93));
t7=t5;
f_21122(t7,(C_truep(t6)?t6:(C_word)C_eqp(t3,C_make_character(63))));}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k21120 in loop in glob? in k4869 */
static void C_fcall f_21122(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_eqp(C_fix(0),((C_word*)t0)[5]);
if(C_truep(t2)){
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(C_word)C_u_fixnum_difference(((C_word*)t0)[5],C_fix(1));
t4=(C_word)C_subchar(((C_word*)t0)[3],t3);
t5=(C_word)C_eqp(C_make_character(92),t4);
t6=(C_word)C_i_not(t5);
if(C_truep(t6)){
t7=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t7=(C_word)C_u_fixnum_difference(((C_word*)t0)[5],C_fix(2));
/* regex.scm: 256  loop */
t8=((C_word*)((C_word*)t0)[2])[1];
f_21103(t8,((C_word*)t0)[4],t7);}}}
else{
t2=(C_word)C_u_fixnum_difference(((C_word*)t0)[5],C_fix(1));
/* regex.scm: 258  loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_21103(t3,((C_word*)t0)[4],t2);}}

/* string-substitute* in k4869 */
static void C_ccall f_21038(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr4rv,(void*)f_21038r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_21038r(t0,t1,t2,t3,t4);}}

static void C_ccall f_21038r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(7);
t5=(C_word)C_i_check_string_2(t2,lf[321]);
t6=(C_word)C_i_check_list_2(t3,lf[321]);
t7=(C_word)C_notvemptyp(t4);
t8=(C_truep(t7)?(C_word)C_slot(t4,C_fix(0)):C_SCHEME_FALSE);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_21053,a[2]=t8,a[3]=((C_word*)t0)[2],a[4]=t10,tmp=(C_word)a,a+=5,tmp));
t12=((C_word*)t10)[1];
f_21053(t12,t1,t2,t3);}

/* loop in string-substitute* in k4869 */
static void C_fcall f_21053(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_21053,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}
else{
t4=(C_word)C_u_i_car(t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_21070,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_u_i_car(t4);
t7=(C_word)C_slot(t4,C_fix(1));
/* regex.scm: 241  string-substitute */
t8=((C_word*)t0)[3];
((C_proc6)(void*)(*((C_word*)t8+1)))(6,t8,t5,t6,t7,t2,((C_word*)t0)[2]);}}

/* k21068 in loop in string-substitute* in k4869 */
static void C_ccall f_21070(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* regex.scm: 241  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_21053(t3,((C_word*)t0)[2],t1,t2);}

/* string-substitute in k4869 */
static void C_ccall f_20786(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(!C_demand(c*C_SIZEOF_PAIR+32)){
C_save_and_reclaim((void*)tr5rv,(void*)f_20786r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest_vector(a,C_rest_count(0));
f_20786r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_20786r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word *a=C_alloc(32);
t6=(C_word)C_i_check_string_2(t3,lf[318]);
t7=(C_word)C_notvemptyp(t5);
t8=(C_truep(t7)?(C_word)C_slot(t5,C_fix(0)):C_fix(1));
t9=(C_word)C_block_size(t3);
t10=(C_word)C_block_size(t4);
t11=(C_word)C_u_fixnum_difference(t9,C_fix(1));
t12=C_SCHEME_END_OF_LIST;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_fix(0);
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_20804,a[2]=t15,a[3]=t13,tmp=(C_word)a,a+=4,tmp);
t17=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_20819,a[2]=t4,a[3]=t9,a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=t16,a[7]=t11,tmp=(C_word)a,a+=8,tmp);
t18=C_SCHEME_UNDEFINED;
t19=(*a=C_VECTOR_TYPE|1,a[1]=t18,tmp=(C_word)a,a+=2,tmp);
t20=C_set_block_item(t19,0,(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_20925,a[2]=((C_word*)t0)[2],a[3]=t10,a[4]=t13,a[5]=((C_word*)t0)[3],a[6]=t15,a[7]=t4,a[8]=((C_word*)t0)[4],a[9]=t17,a[10]=t19,a[11]=t16,a[12]=t8,a[13]=t2,tmp=(C_word)a,a+=14,tmp));
t21=((C_word*)t19)[1];
f_20925(t21,t1,C_fix(0),C_fix(1));}

/* loop in string-substitute in k4869 */
static void C_fcall f_20925(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_20925,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_20929,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t2,a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=t3,a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=t1,tmp=(C_word)a,a+=15,tmp);
if(C_truep((C_word)C_fixnum_lessp(t2,((C_word*)t0)[3]))){
/* regex.scm: 212  string-search-positions */
t5=((C_word*)t0)[2];
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,((C_word*)t0)[13],((C_word*)t0)[7],t2);}
else{
t5=t4;
f_20929(2,t5,C_SCHEME_FALSE);}}

/* k20927 in loop in string-substitute in k4869 */
static void C_ccall f_20929(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_20929,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_u_i_car(t1);
t3=(C_word)C_u_i_cadr(t2);
t4=(C_word)C_u_i_cadr(t2);
t5=(C_word)C_u_i_car(t2);
t6=(C_word)C_u_fixnum_difference(t4,t5);
t7=(C_word)C_eqp(C_fix(0),t6);
if(C_truep(t7)){
/* regex.scm: 217  ##sys#error */
t8=*((C_word*)lf[315]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,((C_word*)t0)[14],lf[318],lf[319],((C_word*)t0)[13]);}
else{
t8=(C_word)C_fixnump(((C_word*)t0)[12]);
t9=(C_word)C_i_not(t8);
t10=(C_truep(t9)?t9:(C_word)C_eqp(((C_word*)t0)[11],((C_word*)t0)[12]));
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_20969,a[2]=t1,a[3]=((C_word*)t0)[8],a[4]=t3,a[5]=((C_word*)t0)[14],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
t12=(C_word)C_u_i_car(t2);
/* regex.scm: 221  substring */
t13=((C_word*)t0)[7];
((C_proc5)(void*)(*((C_word*)t13+1)))(5,t13,t11,((C_word*)t0)[6],((C_word*)t0)[5],t12);}
else{
t11=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_20987,a[2]=t3,a[3]=((C_word*)t0)[14],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
/* regex.scm: 225  substring */
t12=((C_word*)t0)[7];
((C_proc5)(void*)(*((C_word*)t12+1)))(5,t12,t11,((C_word*)t0)[6],((C_word*)t0)[5],t3);}}}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_21020,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[14],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[6]);
/* regex.scm: 228  substring */
t4=((C_word*)t0)[7];
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,((C_word*)t0)[6],((C_word*)t0)[5],t3);}}

/* k21018 in k20927 in loop in string-substitute in k4869 */
static void C_ccall f_21020(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_21020,2,t0,t1);}
t2=f_20804(C_a_i(&a,3),((C_word*)t0)[6],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_21016,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* regex.scm: 229  reverse */
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)((C_word*)t0)[2])[1]);}

/* k21014 in k21018 in k20927 in loop in string-substitute in k4869 */
static void C_ccall f_21016(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* regex.scm: 229  ##sys#fragments->string */
t2=*((C_word*)lf[320]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t1);}

/* k20985 in k20927 in loop in string-substitute in k4869 */
static void C_ccall f_20987(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_20987,2,t0,t1);}
t2=f_20804(C_a_i(&a,3),((C_word*)t0)[6],t1);
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[5],C_fix(1));
/* regex.scm: 226  loop */
t4=((C_word*)((C_word*)t0)[4])[1];
f_20925(t4,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* k20967 in k20927 in loop in string-substitute in k4869 */
static void C_ccall f_20969(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_20969,2,t0,t1);}
t2=f_20804(C_a_i(&a,3),((C_word*)t0)[7],t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_20962,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* regex.scm: 222  substitute */
t4=((C_word*)t0)[3];
f_20819(t4,t3,((C_word*)t0)[2]);}

/* k20960 in k20967 in k20927 in loop in string-substitute in k4869 */
static void C_ccall f_20962(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* regex.scm: 223  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_20925(t2,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}

/* substitute in string-substitute in k4869 */
static void C_fcall f_20819(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_20819,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_20825,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp));
t6=((C_word*)t4)[1];
f_20825(t6,t1,C_fix(0),C_fix(0));}

/* loop in substitute in string-substitute in k4869 */
static void C_fcall f_20825(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word *a;
loop:
a=C_alloc(10);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_20825,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[9]))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_20839,a[2]=((C_word*)t0)[8],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t5)){
t6=t4;
f_20839(2,t6,((C_word*)t0)[7]);}
else{
/* regex.scm: 198  substring */
t6=((C_word*)t0)[6];
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t4,((C_word*)t0)[7],t2,((C_word*)t0)[5]);}}
else{
t4=(C_word)C_subchar(((C_word*)t0)[7],t3);
t5=(C_word)C_u_fixnum_plus(t3,C_fix(1));
t6=(C_word)C_eqp(t4,C_make_character(92));
if(C_truep(t6)){
t7=(C_word)C_subchar(((C_word*)t0)[7],t5);
t8=(C_word)C_eqp(C_make_character(92),t7);
t9=(C_truep(t8)?C_SCHEME_FALSE:(C_word)C_u_i_char_numericp(t7));
if(C_truep(t9)){
t10=(C_word)C_fix((C_word)C_character_code(t7));
t11=(C_word)C_u_fixnum_difference(t10,C_fix(48));
t12=(C_word)C_u_i_list_ref(((C_word*)t0)[4],t11);
t13=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_20892,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],a[4]=t12,a[5]=t5,a[6]=t1,a[7]=((C_word*)t0)[3],a[8]=t3,a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* regex.scm: 205  substring */
t14=((C_word*)t0)[6];
((C_proc5)(void*)(*((C_word*)t14+1)))(5,t14,t13,((C_word*)t0)[7],t2,t3);}
else{
t10=(C_word)C_u_fixnum_plus(t5,C_fix(1));
/* regex.scm: 208  loop */
t18=t1;
t19=t2;
t20=t10;
t1=t18;
t2=t19;
t3=t20;
goto loop;}}
else{
/* regex.scm: 209  loop */
t18=t1;
t19=t2;
t20=t5;
t1=t18;
t2=t19;
t3=t20;
goto loop;}}}

/* k20890 in loop in substitute in string-substitute in k4869 */
static void C_ccall f_20892(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_20892,2,t0,t1);}
t2=f_20804(C_a_i(&a,3),((C_word*)t0)[9],t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_20880,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_u_i_car(((C_word*)t0)[4]);
t5=(C_word)C_u_i_cadr(((C_word*)t0)[4]);
/* regex.scm: 206  substring */
t6=((C_word*)t0)[3];
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t3,((C_word*)t0)[2],t4,t5);}

/* k20878 in k20890 in loop in substitute in string-substitute in k4869 */
static void C_ccall f_20880(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_20880,2,t0,t1);}
t2=f_20804(C_a_i(&a,3),((C_word*)t0)[6],t1);
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[5],C_fix(2));
/* regex.scm: 207  loop */
t4=((C_word*)((C_word*)t0)[4])[1];
f_20825(t4,((C_word*)t0)[3],t3,((C_word*)t0)[2]);}

/* k20837 in loop in substitute in string-substitute in k4869 */
static void C_ccall f_20839(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_20839,2,t0,t1);}
/* regex.scm: 198  push */
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,f_20804(C_a_i(&a,3),((C_word*)t0)[2],t1));}

/* push in string-substitute in k4869 */
static C_word C_fcall f_20804(C_word *a,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=(C_word)C_block_size(t1);
t5=(C_word)C_u_fixnum_plus(((C_word*)((C_word*)t0)[2])[1],t4);
t6=C_mutate(((C_word *)((C_word*)t0)[2])+1,t5);
return(t6);}

/* string-split-fields in k4869 */
static void C_ccall f_20604(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+16)){
C_save_and_reclaim((void*)tr4rv,(void*)f_20604r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_20604r(t0,t1,t2,t3,t4);}}

static void C_ccall f_20604r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(16);
t5=(C_word)C_i_check_string_2(t3,lf[312]);
t6=(C_word)C_block_size(t4);
t7=(C_word)C_block_size(t3);
t8=(C_word)C_fixnum_greaterp(t6,C_fix(0));
t9=(C_truep(t8)?(C_word)C_slot(t4,C_fix(0)):C_SCHEME_TRUE);
t10=(C_word)C_fixnum_greaterp(t6,C_fix(1));
t11=(C_truep(t10)?(C_word)C_slot(t4,C_fix(1)):C_fix(0));
t12=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_20623,a[2]=t11,a[3]=t1,a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=t7,a[7]=t3,a[8]=((C_word*)t0)[4],a[9]=t9,tmp=(C_word)a,a+=10,tmp);
t13=(C_word)C_eqp(t9,lf[314]);
if(C_truep(t13)){
t14=t12;
f_20623(t14,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_20722,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=t7,tmp=(C_word)a,a+=6,tmp));}
else{
t14=(C_word)C_eqp(t9,lf[313]);
t15=t12;
f_20623(t15,(C_truep(t14)?(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_20742,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],a[5]=t7,tmp=(C_word)a,a+=6,tmp):(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_20768,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp)));}}

/* f_20768 in string-split-fields in k4869 */
static void C_ccall f_20768(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_20768,4,t0,t1,t2,t3);}
/* regex.scm: 159  reverse */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t2);}

/* f_20742 in string-split-fields in k4869 */
static void C_ccall f_20742(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_20742,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[5]))){
t4=(C_word)C_a_i_cons(&a,2,lf[317],t2);
/* regex.scm: 157  reverse */
t5=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t1,t4);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_20767,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* regex.scm: 158  substring */
t5=((C_word*)t0)[3];
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,((C_word*)t0)[2],t3,((C_word*)t0)[5]);}}

/* k20765 */
static void C_ccall f_20767(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_20767,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[4]);
/* regex.scm: 158  reverse */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t2);}

/* f_20722 in string-split-fields in k4869 */
static void C_ccall f_20722(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_20722,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_lessp(t3,((C_word*)t0)[5]))){
/* regex.scm: 151  ##sys#error */
t4=*((C_word*)lf[315]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t1,lf[312],lf[316],((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
/* regex.scm: 153  reverse */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t2);}}

/* k20621 in string-split-fields in k4869 */
static void C_fcall f_20623(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_20623,NULL,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[9],lf[313]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(((C_word*)t0)[9],lf[314]));
t4=(C_truep(t3)?(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_20706,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp):(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_20711,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp));
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_20631,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t4,a[6]=t6,a[7]=t1,a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp));
t8=((C_word*)t6)[1];
f_20631(t8,((C_word*)t0)[3],C_SCHEME_END_OF_LIST,((C_word*)t0)[2]);}

/* loop in k20621 in string-split-fields in k4869 */
static void C_fcall f_20631(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_20631,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_20635,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t3,a[5]=t2,a[6]=t1,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* regex.scm: 164  string-search-positions */
t5=((C_word*)t0)[4];
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* k20633 in loop in k20621 in string-split-fields in k4869 */
static void C_ccall f_20635(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_20635,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_u_i_car(t1);
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_u_i_cadr(t2);
t5=(C_word)C_eqp(t3,t4);
if(C_truep(t5)){
t6=(C_word)C_eqp(t4,((C_word*)t0)[8]);
if(C_truep(t6)){
/* regex.scm: 171  fini */
t7=((C_word*)t0)[7];
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_20677,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t8=(C_word)C_u_fixnum_plus(t3,C_fix(1));
t9=(C_word)C_u_fixnum_plus(t4,C_fix(2));
/* regex.scm: 172  fetch */
t10=((C_word*)t0)[2];
((C_proc5)(void*)(*((C_word*)t10+1)))(5,t10,t7,((C_word*)t0)[4],t8,t9);}}
else{
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_20696,a[2]=t4,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* regex.scm: 173  fetch */
t7=((C_word*)t0)[2];
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t6,((C_word*)t0)[4],t3,t4);}}
else{
/* regex.scm: 174  fini */
t2=((C_word*)t0)[7];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);}}

/* k20694 in k20633 in loop in k20621 in string-split-fields in k4869 */
static void C_ccall f_20696(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_20696,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
/* regex.scm: 173  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_20631(t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k20675 in k20633 in loop in k20621 in string-split-fields in k4869 */
static void C_ccall f_20677(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_20677,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* regex.scm: 172  loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_20631(t4,((C_word*)t0)[2],t2,t3);}

/* f_20711 in k20621 in string-split-fields in k4869 */
static void C_ccall f_20711(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_20711,5,t0,t1,t2,t3,t4);}
/* regex.scm: 162  substring */
t5=((C_word*)t0)[3];
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,((C_word*)t0)[2],t3,t4);}

/* f_20706 in k20621 in string-split-fields in k4869 */
static void C_ccall f_20706(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_20706,5,t0,t1,t2,t3,t4);}
/* regex.scm: 161  substring */
t5=((C_word*)t0)[3];
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,((C_word*)t0)[2],t2,t3);}

/* string-search-positions in k4869 */
static void C_ccall f_20484(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+11)){
C_save_and_reclaim((void*)tr4r,(void*)f_20484r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_20484r(t0,t1,t2,t3,t4);}}

static void C_ccall f_20484r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(11);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_20486,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_20550,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_20559,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-start44624494 */
t8=t7;
f_20559(t8,t1);}
else{
t8=(C_word)C_u_i_car(t4);
t9=(C_word)C_slot(t4,C_fix(1));
if(C_truep((C_word)C_i_nullp(t9))){
/* def-range44634490 */
t10=t6;
f_20550(t10,t1,t8);}
else{
t10=(C_word)C_u_i_car(t9);
t11=(C_word)C_slot(t9,C_fix(1));
/* body44604469 */
t12=t5;
f_20486(t12,t1,t8,t10);}}}

/* def-start4462 in string-search-positions in k4869 */
static void C_fcall f_20559(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_20559,NULL,2,t0,t1);}
/* def-range44634490 */
t2=((C_word*)t0)[2];
f_20550(t2,t1,C_fix(0));}

/* def-range4463 in string-search-positions in k4869 */
static void C_fcall f_20550(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_20550,NULL,3,t0,t1,t2);}
t3=(C_word)C_fix((C_word)C_header_size(((C_word*)t0)[3]));
/* body44604469 */
t4=((C_word*)t0)[2];
f_20486(t4,t1,t2,t3);}

/* body4460 in string-search-positions in k4869 */
static void C_fcall f_20486(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_20486,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_20490,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* regex.scm: 123  unregexp */
f_20243(t4,((C_word*)t0)[2]);}

/* k20488 in body4460 in string-search-positions in k4869 */
static void C_ccall f_20490(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_20490,2,t0,t1);}
t2=(C_word)C_fix((C_word)C_header_size(((C_word*)t0)[5]));
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_20499,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_20545,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_u_fixnum_plus(((C_word*)t0)[3],((C_word*)t0)[2]);
/* regex.scm: 125  min */
t6=*((C_word*)lf[212]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t2,t5);}
else{
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k20543 in k20488 in body4460 in string-search-positions in k4869 */
static void C_ccall f_20545(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* regex.scm: 125  irregex-search */
t2=*((C_word*)lf[241]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k20497 in k20488 in body4460 in string-search-positions in k4869 */
static void C_ccall f_20499(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_20499,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_20509,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* regex.scm: 126  irregex-match-num-submatches */
t3=*((C_word*)lf[16]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k20507 in k20497 in k20488 in body4460 in string-search-positions in k4869 */
static void C_ccall f_20509(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_20509,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_20511,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_20511(t5,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* loop in k20507 in k20497 in k20488 in body4460 in string-search-positions in k4869 */
static void C_fcall f_20511(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(25);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_20511,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_u_fixnum_difference(t2,C_fix(1));
t5=f_5091(C_a_i(&a,8),((C_word*)t0)[3],t2);
t6=f_5105(C_a_i(&a,8),((C_word*)t0)[3],t2);
t7=(C_word)C_a_i_list(&a,2,t5,t6);
t8=(C_word)C_a_i_cons(&a,2,t7,t3);
/* regex.scm: 130  loop */
t10=t1;
t11=t4;
t12=t8;
t1=t10;
t2=t11;
t3=t12;
goto loop;}}

/* string-search in k4869 */
static void C_ccall f_20372(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+11)){
C_save_and_reclaim((void*)tr4r,(void*)f_20372r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_20372r(t0,t1,t2,t3,t4);}}

static void C_ccall f_20372r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(11);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_20374,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_20430,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_20439,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-start43994431 */
t8=t7;
f_20439(t8,t1);}
else{
t8=(C_word)C_u_i_car(t4);
t9=(C_word)C_slot(t4,C_fix(1));
if(C_truep((C_word)C_i_nullp(t9))){
/* def-range44004427 */
t10=t6;
f_20430(t10,t1,t8);}
else{
t10=(C_word)C_u_i_car(t9);
t11=(C_word)C_slot(t9,C_fix(1));
/* body43974406 */
t12=t5;
f_20374(t12,t1,t8,t10);}}}

/* def-start4399 in string-search in k4869 */
static void C_fcall f_20439(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_20439,NULL,2,t0,t1);}
/* def-range44004427 */
t2=((C_word*)t0)[2];
f_20430(t2,t1,C_fix(0));}

/* def-range4400 in string-search in k4869 */
static void C_fcall f_20430(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_20430,NULL,3,t0,t1,t2);}
t3=(C_word)C_fix((C_word)C_header_size(((C_word*)t0)[3]));
/* body43974406 */
t4=((C_word*)t0)[2];
f_20374(t4,t1,t2,t3);}

/* body4397 in string-search in k4869 */
static void C_fcall f_20374(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_20374,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_20378,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* regex.scm: 113  unregexp */
f_20243(t4,((C_word*)t0)[2]);}

/* k20376 in body4397 in string-search in k4869 */
static void C_ccall f_20378(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_20378,2,t0,t1);}
t2=(C_word)C_fix((C_word)C_header_size(((C_word*)t0)[5]));
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_20387,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_20425,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_u_fixnum_plus(((C_word*)t0)[3],((C_word*)t0)[2]);
/* regex.scm: 115  min */
t6=*((C_word*)lf[212]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t2,t5);}
else{
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k20423 in k20376 in body4397 in string-search in k4869 */
static void C_ccall f_20425(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* regex.scm: 115  irregex-search */
t2=*((C_word*)lf[241]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k20385 in k20376 in body4397 in string-search in k4869 */
static void C_ccall f_20387(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_20387,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_20397,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* regex.scm: 116  irregex-match-num-submatches */
t3=*((C_word*)lf[16]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k20395 in k20385 in k20376 in body4397 in string-search in k4869 */
static void C_ccall f_20397(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_20397,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_20399,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_20399(t5,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* loop in k20395 in k20385 in k20376 in body4397 in string-search in k4869 */
static void C_fcall f_20399(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_20399,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_u_fixnum_difference(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_20421,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* regex.scm: 120  irregex-match-substring */
t6=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,((C_word*)t0)[2],t2);}}

/* k20419 in loop in k20395 in k20385 in k20376 in body4397 in string-search in k4869 */
static void C_ccall f_20421(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_20421,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
/* regex.scm: 120  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_20399(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* string-match-positions in k4869 */
static void C_ccall f_20310(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_20310,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_20314,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* regex.scm: 102  unregexp */
f_20243(t4,t2);}

/* k20312 in string-match-positions in k4869 */
static void C_ccall f_20314(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_20314,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_20317,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* regex.scm: 103  irregex-match */
t3=*((C_word*)lf[246]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,t1,((C_word*)t0)[3]);}

/* k20315 in k20312 in string-match-positions in k4869 */
static void C_ccall f_20317(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_20317,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_20327,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* regex.scm: 104  irregex-match-num-submatches */
t3=*((C_word*)lf[16]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k20325 in k20315 in k20312 in string-match-positions in k4869 */
static void C_ccall f_20327(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_20327,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_20329,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_20329(t5,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* loop in k20325 in k20315 in k20312 in string-match-positions in k4869 */
static void C_fcall f_20329(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
loop:
a=C_alloc(25);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_20329,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_less_or_equal_p(t2,C_fix(0)))){
t4=(C_word)C_fix((C_word)C_header_size(((C_word*)t0)[4]));
t5=(C_word)C_a_i_list(&a,2,C_fix(0),t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,t5,t3));}
else{
t4=(C_word)C_u_fixnum_difference(t2,C_fix(1));
t5=f_5091(C_a_i(&a,8),((C_word*)t0)[3],t2);
t6=f_5105(C_a_i(&a,8),((C_word*)t0)[3],t2);
t7=(C_word)C_a_i_list(&a,2,t5,t6);
t8=(C_word)C_a_i_cons(&a,2,t7,t3);
/* regex.scm: 108  loop */
t12=t1;
t13=t4;
t14=t8;
t1=t12;
t2=t13;
t3=t14;
goto loop;}}

/* string-match in k4869 */
static void C_ccall f_20264(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_20264,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_20268,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* regex.scm: 93   unregexp */
f_20243(t4,t2);}

/* k20266 in string-match in k4869 */
static void C_ccall f_20268(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_20268,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_20271,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* regex.scm: 94   irregex-match */
t3=*((C_word*)lf[246]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,t1,((C_word*)t0)[3]);}

/* k20269 in k20266 in string-match in k4869 */
static void C_ccall f_20271(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_20271,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_20281,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* regex.scm: 95   irregex-match-num-submatches */
t3=*((C_word*)lf[16]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k20279 in k20269 in k20266 in string-match in k4869 */
static void C_ccall f_20281(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_20281,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_20283,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_20283(t5,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* loop in k20279 in k20269 in k20266 in string-match in k4869 */
static void C_fcall f_20283(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_20283,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_less_or_equal_p(t2,C_fix(0)))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t3));}
else{
t4=(C_word)C_u_fixnum_difference(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_20308,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* regex.scm: 99   irregex-match-substring */
t6=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,((C_word*)t0)[2],t2);}}

/* k20306 in loop in k20279 in k20269 in k20266 in string-match in k4869 */
static void C_ccall f_20308(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_20308,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
/* regex.scm: 99   loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_20283(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* unregexp in k4869 */
static void C_fcall f_20243(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_20243,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_20250,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* regex.scm: 85   regexp? */
t4=*((C_word*)lf[304]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k20248 in unregexp in k4869 */
static void C_ccall f_20250(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_20250,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[2];
t4=t2;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t3,C_fix(1)));}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_20259,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* regex.scm: 86   irregex? */
t3=*((C_word*)lf[2]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}}

/* k20257 in k20248 in unregexp in k4869 */
static void C_ccall f_20259(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}
else{
/* regex.scm: 87   irregex */
t2=*((C_word*)lf[179]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* regexp in k4869 */
static void C_ccall f_20140(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr3r,(void*)f_20140r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_20140r(t0,t1,t2,t3);}}

static void C_ccall f_20140r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(12);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_20142,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_20173,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_20178,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_20183,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-caseless42814315 */
t8=t7;
f_20183(t8,t1);}
else{
t8=(C_word)C_u_i_car(t3);
t9=(C_word)C_slot(t3,C_fix(1));
if(C_truep((C_word)C_i_nullp(t9))){
/* def-extended42824311 */
t10=t6;
f_20178(t10,t1,t8);}
else{
t10=(C_word)C_u_i_car(t9);
t11=(C_word)C_slot(t9,C_fix(1));
if(C_truep((C_word)C_i_nullp(t11))){
/* def-utf842834306 */
t12=t5;
f_20173(t12,t1,t8,t10);}
else{
t12=(C_word)C_u_i_car(t11);
t13=(C_word)C_slot(t11,C_fix(1));
/* body42794289 */
t14=t4;
f_20142(t14,t1,t8,t10,t12);}}}}

/* def-caseless4281 in regexp in k4869 */
static void C_fcall f_20183(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_20183,NULL,2,t0,t1);}
/* def-extended42824311 */
t2=((C_word*)t0)[2];
f_20178(t2,t1,C_SCHEME_FALSE);}

/* def-extended4282 in regexp in k4869 */
static void C_fcall f_20178(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_20178,NULL,3,t0,t1,t2);}
/* def-utf842834306 */
t3=((C_word*)t0)[2];
f_20173(t3,t1,t2,C_SCHEME_FALSE);}

/* def-utf84283 in regexp in k4869 */
static void C_fcall f_20173(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_20173,NULL,4,t0,t1,t2,t3);}
/* body42794289 */
t4=((C_word*)t0)[2];
f_20142(t4,t1,t2,t3,C_SCHEME_FALSE);}

/* body4279 in regexp in k4869 */
static void C_fcall f_20142(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_20142,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_20150,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=C_SCHEME_END_OF_LIST;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_20154,a[2]=t3,a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=t5,a[6]=t7,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t2)){
t9=(C_word)C_a_i_cons(&a,2,lf[57],((C_word*)t7)[1]);
t10=C_set_block_item(t7,0,t9);
t11=t8;
f_20154(t11,t10);}
else{
t9=t8;
f_20154(t9,C_SCHEME_UNDEFINED);}}

/* k20152 in body4279 in regexp in k4869 */
static void C_fcall f_20154(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_20154,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_20157,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(C_word)C_a_i_cons(&a,2,lf[62],((C_word*)((C_word*)t0)[6])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t3);
t5=t2;
f_20157(t5,t4);}
else{
t3=t2;
f_20157(t3,C_SCHEME_UNDEFINED);}}

/* k20155 in k20152 in body4279 in regexp in k4869 */
static void C_fcall f_20157(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_20157,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_20160,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(C_word)C_a_i_cons(&a,2,lf[65],((C_word*)((C_word*)t0)[5])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[5])+1,t3);
t5=t2;
f_20160(t5,t4);}
else{
t3=t2;
f_20160(t3,C_SCHEME_UNDEFINED);}}

/* k20158 in k20155 in k20152 in body4279 in regexp in k4869 */
static void C_fcall f_20160(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=((C_word*)((C_word*)t0)[4])[1];
C_apply(5,0,((C_word*)t0)[3],*((C_word*)lf[179]+1),((C_word*)t0)[2],t2);}

/* k20148 in body4279 in regexp in k4869 */
static void C_ccall f_20150(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_20150,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=t2;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,2,lf[305],t1));}

/* regexp? in k4869 */
static void C_ccall f_20122(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_20122,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[305]));}

/* irregex-apply-match in k4869 */
static void C_fcall f_19940(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_19940,NULL,3,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_19946,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_19946(t7,t1,t3,C_SCHEME_END_OF_LIST);}

/* lp in irregex-apply-match in k4869 */
static void C_fcall f_19946(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word *a;
loop:
a=C_alloc(10);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_19946,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_u_i_car(t2);
if(C_truep((C_word)C_i_integerp(t4))){
t5=(C_word)C_slot(t2,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_19974,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_u_i_car(t2);
/* irregex-match-substring */
t8=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,((C_word*)t0)[2],t7);}
else{
t5=(C_word)C_u_i_car(t2);
if(C_truep((C_word)C_i_closurep(t5))){
t6=(C_word)C_slot(t2,C_fix(1));
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_20002,a[2]=t6,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t8=(C_word)C_u_i_car(t2);
t9=t8;
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t7,((C_word*)t0)[2]);}
else{
t6=(C_word)C_u_i_car(t2);
if(C_truep((C_word)C_i_symbolp(t6))){
t7=(C_word)C_u_i_car(t2);
t8=(C_word)C_eqp(t7,lf[301]);
if(C_truep(t8)){
t9=(C_word)C_slot(t2,C_fix(1));
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_20035,a[2]=t9,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_20039,a[2]=((C_word*)t0)[2],a[3]=t10,tmp=(C_word)a,a+=4,tmp);
/* irregex-match-string */
t12=*((C_word*)lf[17]+1);
((C_proc3)(void*)(*((C_word*)t12+1)))(3,t12,t11,((C_word*)t0)[2]);}
else{
t9=(C_word)C_eqp(t7,lf[302]);
if(C_truep(t9)){
t10=(C_word)C_slot(t2,C_fix(1));
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_20064,a[2]=t10,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_20068,a[2]=((C_word*)t0)[2],a[3]=t11,tmp=(C_word)a,a+=4,tmp);
/* irregex-match-string */
t13=*((C_word*)lf[17]+1);
((C_proc3)(void*)(*((C_word*)t13+1)))(3,t13,t12,((C_word*)t0)[2]);}
else{
t10=(C_word)C_u_i_car(t2);
/* error */
t11=*((C_word*)lf[24]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t1,lf[303],t10);}}}
else{
t7=(C_word)C_slot(t2,C_fix(1));
t8=(C_word)C_u_i_car(t2);
t9=(C_word)C_a_i_cons(&a,2,t8,t3);
/* lp4073 */
t27=t1;
t28=t7;
t29=t9;
t1=t27;
t2=t28;
t3=t29;
goto loop;}}}}}

/* k20066 in lp in irregex-apply-match in k4869 */
static void C_ccall f_20068(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_20068,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_20072,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* irregex-match-end */
t3=*((C_word*)lf[30]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_fix(0));}

/* k20070 in k20066 in lp in irregex-apply-match in k4869 */
static void C_ccall f_20072(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_20072,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_20080,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* irregex-match-string */
t3=*((C_word*)lf[17]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k20078 in k20070 in k20066 in lp in irregex-apply-match in k4869 */
static void C_ccall f_20080(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fix((C_word)C_header_size(t1));
/* substring */
t3=*((C_word*)lf[28]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k20062 in lp in irregex-apply-match in k4869 */
static void C_ccall f_20064(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_20064,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
/* lp4073 */
t3=((C_word*)((C_word*)t0)[4])[1];
f_19946(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k20037 in lp in irregex-apply-match in k4869 */
static void C_ccall f_20039(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_20039,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_20043,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* irregex-match-start */
t3=*((C_word*)lf[29]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_fix(0));}

/* k20041 in k20037 in lp in irregex-apply-match in k4869 */
static void C_ccall f_20043(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* substring */
t2=*((C_word*)lf[28]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0),t1);}

/* k20033 in lp in irregex-apply-match in k4869 */
static void C_ccall f_20035(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_20035,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
/* lp4073 */
t3=((C_word*)((C_word*)t0)[4])[1];
f_19946(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k20000 in lp in irregex-apply-match in k4869 */
static void C_ccall f_20002(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_20002,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
/* lp4073 */
t3=((C_word*)((C_word*)t0)[4])[1];
f_19946(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k19972 in lp in irregex-apply-match in k4869 */
static void C_ccall f_19974(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_19974,2,t0,t1);}
t2=(C_truep(t1)?t1:lf[300]);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[5]);
/* lp4073 */
t4=((C_word*)((C_word*)t0)[4])[1];
f_19946(t4,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* irregex-replace/all in k4869 */
static void C_ccall f_19884(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+16)){
C_save_and_reclaim((void*)tr4r,(void*)f_19884r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_19884r(t0,t1,t2,t3,t4);}}

static void C_ccall f_19884r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(16);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_19890,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_19917,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t7=t3;
t8=(C_word)C_a_i_list(&a,1,t6);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_19723,a[2]=t1,a[3]=t5,a[4]=t7,a[5]=t8,tmp=(C_word)a,a+=6,tmp);
/* irregex */
t10=*((C_word*)lf[179]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,t2);}

/* k19721 in irregex-replace/all in k4869 */
static void C_ccall f_19723(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_19723,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_19726,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* irregex-new-matches */
t3=*((C_word*)lf[11]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}

/* k19724 in k19721 in irregex-replace/all in k4869 */
static void C_ccall f_19726(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_19726,2,t0,t1);}
t2=(C_word)C_i_pairp(((C_word*)t0)[6]);
t3=(C_truep(t2)?(C_word)C_u_i_car(((C_word*)t0)[6]):(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_19829,tmp=(C_word)a,a+=2,tmp));
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_19809,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=t1,a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[6]))){
t5=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t6=t4;
f_19809(t6,(C_word)C_i_pairp(t5));}
else{
t5=t4;
f_19809(t5,C_SCHEME_FALSE);}}

/* k19807 in k19724 in k19721 in irregex-replace/all in k4869 */
static void C_fcall f_19809(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_19809,NULL,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_u_i_cadr(((C_word*)t0)[8]):C_fix(0));
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_19780,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[8]))){
t4=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
if(C_truep((C_word)C_i_pairp(t4))){
t5=(C_word)C_u_i_cddr(((C_word*)t0)[8]);
t6=t3;
f_19780(t6,(C_word)C_i_pairp(t5));}
else{
t5=t3;
f_19780(t5,C_SCHEME_FALSE);}}
else{
t4=t3;
f_19780(t4,C_SCHEME_FALSE);}}

/* k19778 in k19807 in k19724 in k19721 in irregex-replace/all in k4869 */
static void C_fcall f_19780(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_19780,NULL,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_u_i_caddr(((C_word*)t0)[9]):(C_word)C_fix((C_word)C_header_size(((C_word*)t0)[8])));
t3=f_5085(((C_word*)t0)[7],((C_word*)t0)[8]);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_19743,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[7],a[6]=t5,a[7]=((C_word*)t0)[6],a[8]=t2,tmp=(C_word)a,a+=9,tmp));
t7=((C_word*)t5)[1];
f_19743(t7,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* lp in k19778 in k19807 in k19724 in k19721 in irregex-replace/all in k4869 */
static void C_fcall f_19743(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_19743,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_greater_or_equalp(t2,((C_word*)t0)[8]))){
/* finish4011 */
t4=((C_word*)t0)[7];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t2,t3);}
else{
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_19756,a[2]=((C_word*)t0)[7],a[3]=t3,a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t1,a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
/* irregex-search/matches */
t5=*((C_word*)lf[242]+1);
((C_proc7)(void*)(*((C_word*)t5+1)))(7,t5,t4,((C_word*)t0)[3],((C_word*)t0)[2],t2,((C_word*)t0)[8],((C_word*)t0)[5]);}}

/* k19754 in lp in k19778 in k19807 in k19724 in k19721 in irregex-replace/all in k4869 */
static void C_ccall f_19756(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_19756,2,t0,t1);}
t2=t1;
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_19768,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* irregex-match-end */
t4=*((C_word*)lf[30]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t1,C_fix(0));}
else{
/* finish4011 */
t3=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[7],((C_word*)t0)[4],((C_word*)t0)[3]);}}

/* k19766 in k19754 in lp in k19778 in k19807 in k19724 in k19721 in irregex-replace/all in k4869 */
static void C_ccall f_19768(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_19768,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_19771,a[2]=((C_word*)t0)[6],a[3]=t1,a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
/* kons4001 */
t3=((C_word*)t0)[5];
f_19890(t3,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k19769 in k19766 in k19754 in lp in k19778 in k19807 in k19724 in k19721 in irregex-replace/all in k4869 */
static void C_ccall f_19771(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_19771,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_19774,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* irregex-reset-matches! */
t3=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k19772 in k19769 in k19766 in k19754 in lp in k19778 in k19807 in k19724 in k19721 in irregex-replace/all in k4869 */
static void C_ccall f_19774(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp4027 */
t2=((C_word*)((C_word*)t0)[5])[1];
f_19743(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* f_19829 in k19724 in k19721 in irregex-replace/all in k4869 */
static void C_ccall f_19829(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_19829,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* a19916 in irregex-replace/all in k4869 */
static void C_ccall f_19917(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_19917,4,t0,t1,t2,t3);}
t4=(C_word)C_fix((C_word)C_header_size(((C_word*)t0)[2]));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_19928,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nequalp(t2,t4))){
t6=t5;
f_19928(t6,t3);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_19938,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* substring */
t7=*((C_word*)lf[28]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t6,((C_word*)t0)[2],t2,t4);}}

/* k19936 in a19916 in irregex-replace/all in k4869 */
static void C_ccall f_19938(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_19938,2,t0,t1);}
t2=((C_word*)t0)[3];
f_19928(t2,(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[2]));}

/* k19926 in a19916 in irregex-replace/all in k4869 */
static void C_fcall f_19928(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* string-cat-reverse */
f_5566(((C_word*)t0)[2],t1);}

/* a19889 in irregex-replace/all in k4869 */
static void C_fcall f_19890(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_19890,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_19894,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=t4,a[6]=t2,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* irregex-match-start */
t6=*((C_word*)lf[29]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t3,C_fix(0));}

/* k19892 in a19889 in irregex-replace/all in k4869 */
static void C_ccall f_19894(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_19894,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_19901,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* irregex-apply-match */
f_19940(t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k19899 in k19892 in a19889 in irregex-replace/all in k4869 */
static void C_ccall f_19901(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_19901,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_19905,a[2]=t1,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nequalp(((C_word*)t0)[5],((C_word*)t0)[4]))){
t3=t2;
f_19905(t3,((C_word*)t0)[3]);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_19915,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* substring */
t4=*((C_word*)lf[28]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)t0)[2],((C_word*)t0)[5],((C_word*)t0)[4]);}}

/* k19913 in k19899 in k19892 in a19889 in irregex-replace/all in k4869 */
static void C_ccall f_19915(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_19915,2,t0,t1);}
t2=((C_word*)t0)[3];
f_19905(t2,(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[2]));}

/* k19903 in k19899 in k19892 in a19889 in irregex-replace/all in k4869 */
static void C_fcall f_19905(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* append */
t2=*((C_word*)lf[125]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* irregex-replace in k4869 */
static void C_ccall f_19832(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr4r,(void*)f_19832r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_19832r(t0,t1,t2,t3,t4);}}

static void C_ccall f_19832r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(9);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_19836,a[2]=t4,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_19882,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* irregex */
t7=*((C_word*)lf[179]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t2);}

/* k19880 in irregex-replace in k4869 */
static void C_ccall f_19882(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* irregex-search */
t2=*((C_word*)lf[241]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k19834 in irregex-replace in k4869 */
static void C_ccall f_19836(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_19836,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_19850,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_19874,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* irregex-match-end */
t4=*((C_word*)lf[30]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t1,C_fix(0));}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k19872 in k19834 in irregex-replace in k4869 */
static void C_ccall f_19874(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fix((C_word)C_header_size(((C_word*)t0)[3]));
/* substring */
t3=*((C_word*)lf[28]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[2],((C_word*)t0)[3],t1,t2);}

/* k19848 in k19834 in irregex-replace in k4869 */
static void C_ccall f_19850(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_19850,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_19854,a[2]=((C_word*)t0)[5],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_19858,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* irregex-apply-match */
f_19940(t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k19856 in k19848 in k19834 in irregex-replace in k4869 */
static void C_ccall f_19858(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_19858,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_19866,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_19870,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* irregex-match-start */
t4=*((C_word*)lf[29]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[2],C_fix(0));}

/* k19868 in k19856 in k19848 in k19834 in irregex-replace in k4869 */
static void C_ccall f_19870(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* substring */
t2=*((C_word*)lf[28]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0),t1);}

/* k19864 in k19856 in k19848 in k19834 in irregex-replace in k4869 */
static void C_ccall f_19866(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_19866,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* append */
t3=*((C_word*)lf[125]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k19852 in k19848 in k19834 in irregex-replace in k4869 */
static void C_ccall f_19854(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_19854,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
/* string-cat-reverse */
f_5566(((C_word*)t0)[2],t2);}

/* cset-case-insensitive in k4869 */
static void C_ccall f_19554(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_19554,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_19560,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_19560(t6,t1,t2,C_SCHEME_END_OF_LIST);}

/* lp in cset-case-insensitive in k4869 */
static void C_fcall f_19560(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_19560,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
/* reverse */
t4=*((C_word*)lf[40]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_19576,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_u_i_car(t2);
if(C_truep((C_word)C_charp(t5))){
t6=(C_word)C_u_i_car(t2);
t7=t4;
f_19576(t7,(C_word)C_u_i_char_alphabeticp(t6));}
else{
t6=t4;
f_19576(t6,C_SCHEME_FALSE);}}}

/* k19574 in lp in cset-case-insensitive in k4869 */
static void C_fcall f_19576(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_19576,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_u_i_car(((C_word*)t0)[5]);
t3=f_9172(t2);
t4=(C_word)C_u_i_car(((C_word*)t0)[5]);
t5=(C_word)C_a_i_cons(&a,2,t4,((C_word*)t0)[4]);
t6=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_19596,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=t5,tmp=(C_word)a,a+=7,tmp);
/* cset-contains? */
f_19023(t7,t5,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_19613,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_u_i_car(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_pairp(t3))){
t4=(C_word)C_u_i_caar(((C_word*)t0)[5]);
if(C_truep((C_word)C_u_i_char_alphabeticp(t4))){
t5=(C_word)C_u_i_cdar(((C_word*)t0)[5]);
t6=t2;
f_19613(t6,(C_word)C_u_i_char_alphabeticp(t5));}
else{
t5=t2;
f_19613(t5,C_SCHEME_FALSE);}}
else{
t4=t2;
f_19613(t4,C_SCHEME_FALSE);}}}

/* k19611 in k19574 in lp in cset-case-insensitive in k4869 */
static void C_fcall f_19613(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_19613,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_19624,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_19628,a[2]=t3,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_u_i_car(((C_word*)t0)[5]);
t6=(C_word)C_a_i_list(&a,1,t5);
/* cset-union */
t7=lf[290];
f_19218(4,t7,t4,((C_word*)t0)[2],t6);}
else{
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_19671,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_u_i_car(((C_word*)t0)[5]);
t5=(C_word)C_a_i_list(&a,1,t4);
/* cset-union */
t6=lf[290];
f_19218(4,t6,t3,((C_word*)t0)[2],t5);}}

/* k19669 in k19611 in k19574 in lp in cset-case-insensitive in k4869 */
static void C_ccall f_19671(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp3976 */
t2=((C_word*)((C_word*)t0)[4])[1];
f_19560(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k19626 in k19611 in k19574 in lp in cset-case-insensitive in k4869 */
static void C_ccall f_19628(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_19628,2,t0,t1);}
t2=(C_word)C_u_i_caar(((C_word*)t0)[3]);
t3=f_9172(t2);
t4=(C_word)C_u_i_cdar(((C_word*)t0)[3]);
t5=f_9172(t4);
t6=(C_word)C_a_i_cons(&a,2,t3,t5);
t7=(C_word)C_a_i_list(&a,1,t6);
/* cset-union */
t8=lf[290];
f_19218(4,t8,((C_word*)t0)[2],t1,t7);}

/* k19622 in k19611 in k19574 in lp in cset-case-insensitive in k4869 */
static void C_ccall f_19624(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp3976 */
t2=((C_word*)((C_word*)t0)[4])[1];
f_19560(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k19594 in k19574 in lp in cset-case-insensitive in k4869 */
static void C_ccall f_19596(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_19596,2,t0,t1);}
t2=(C_truep(t1)?((C_word*)t0)[6]:(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[6]));
/* lp3976 */
t3=((C_word*)((C_word*)t0)[4])[1];
f_19560(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* cset-complement in k4869 */
static void C_fcall f_19544(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_19544,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_19552,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* sre->cset */
f_18742(t3,lf[32],C_SCHEME_END_OF_LIST);}

/* k19550 in cset-complement in k4869 */
static void C_ccall f_19552(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* cset-difference */
f_19305(((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* cset-intersection in k4869 */
static void C_ccall f_19426(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_19426,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_19432,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_19432(t7,t1,t2,t3,C_SCHEME_END_OF_LIST);}

/* intersect in cset-intersection in k4869 */
static void C_fcall f_19432(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_19432,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t3))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_19442,a[2]=t1,a[3]=t2,a[4]=t3,a[5]=t4,a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_19534,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* find-tail */
f_5717(t5,t6,t2);}}

/* a19533 in intersect in cset-intersection in k4869 */
static void C_ccall f_19534(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_19534,3,t0,t1,t2);}
t3=(C_word)C_u_i_car(((C_word*)t0)[2]);
/* char-ranges-overlap? */
f_19073(t1,t2,t3);}

/* k19440 in intersect in cset-intersection in k4869 */
static void C_ccall f_19442(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_19442,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_19450,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_19509,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_u_i_car(t1);
t5=f_19061(C_a_i(&a,3),t4);
t6=(C_word)C_u_i_car(((C_word*)t0)[4]);
t7=f_19061(C_a_i(&a,3),t6);
/* intersect-char-ranges */
f_16064(t3,t5,t7);}
else{
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* intersect3929 */
t3=((C_word*)((C_word*)t0)[6])[1];
f_19432(t3,((C_word*)t0)[2],((C_word*)t0)[3],t2,((C_word*)t0)[5]);}}

/* k19507 in k19440 in intersect in cset-intersection in k4869 */
static void C_ccall f_19509(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a19449 in k19440 in intersect in cset-intersection in k4869 */
static void C_ccall f_19450(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr7,(void*)f_19450,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_19454,a[2]=((C_word*)t0)[4],a[3]=t5,a[4]=t6,a[5]=((C_word*)t0)[5],a[6]=t4,a[7]=t1,a[8]=((C_word*)t0)[6],a[9]=t3,a[10]=t2,tmp=(C_word)a,a+=11,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_19501,a[2]=t7,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* take-up-to */
f_5662(t8,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k19499 in a19449 in k19440 in intersect in cset-intersection in k4869 */
static void C_ccall f_19501(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* append */
t3=*((C_word*)lf[125]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t1,t2);}

/* k19452 in a19449 in k19440 in intersect in cset-intersection in k4869 */
static void C_ccall f_19454(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_19454,2,t0,t1);}
t2=(C_truep(((C_word*)t0)[10])?(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t1):t1);
t3=(C_truep(((C_word*)t0)[9])?(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t2):t2);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_19463,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t3,a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[3])){
t5=(C_word)C_a_i_list(&a,1,((C_word*)t0)[3]);
/* cset-union */
t6=lf[290];
f_19218(4,t6,t4,((C_word*)t0)[2],t5);}
else{
t5=t4;
f_19463(2,t5,((C_word*)t0)[2]);}}

/* k19461 in k19452 in a19449 in k19440 in intersect in cset-intersection in k4869 */
static void C_ccall f_19463(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_19463,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_19466,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
/* cset-union */
t4=lf[290];
f_19218(4,t4,t2,t1,t3);}
else{
t3=t2;
f_19466(2,t3,t1);}}

/* k19464 in k19461 in k19452 in a19449 in k19440 in intersect in cset-intersection in k4869 */
static void C_ccall f_19466(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_19466,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_19473,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_a_i_list(&a,1,((C_word*)t0)[3]);
/* cset-union */
t4=lf[290];
f_19218(4,t4,t2,((C_word*)t0)[2],t3);}

/* k19471 in k19464 in k19461 in k19452 in a19449 in k19440 in intersect in cset-intersection in k4869 */
static void C_ccall f_19473(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* intersect3929 */
t2=((C_word*)((C_word*)t0)[5])[1];
f_19432(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* cset-difference in k4869 */
static void C_fcall f_19305(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(8);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_19305,NULL,3,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}
else{
if(C_truep((C_word)C_u_i_car(t3))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_19328,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_19412,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* find-tail */
f_5717(t4,t5,t2);}
else{
t4=(C_word)C_slot(t3,C_fix(1));
/* cset-difference */
t8=t1;
t9=t2;
t10=t4;
t1=t8;
t2=t9;
t3=t10;
goto loop;}}}

/* a19411 in cset-difference in k4869 */
static void C_ccall f_19412(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_19412,3,t0,t1,t2);}
t3=(C_word)C_u_i_car(((C_word*)t0)[2]);
/* char-ranges-overlap? */
f_19073(t1,t2,t3);}

/* k19326 in cset-difference in k4869 */
static void C_ccall f_19328(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_19328,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_19336,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_19387,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_u_i_car(t1);
t5=f_19061(C_a_i(&a,3),t4);
t6=(C_word)C_u_i_car(((C_word*)t0)[4]);
t7=f_19061(C_a_i(&a,3),t6);
/* intersect-char-ranges */
f_16064(t3,t5,t7);}
else{
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* cset-difference */
f_19305(((C_word*)t0)[2],((C_word*)t0)[3],t2);}}

/* k19385 in k19326 in cset-difference in k4869 */
static void C_ccall f_19387(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a19335 in k19326 in cset-difference in k4869 */
static void C_ccall f_19336(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr7,(void*)f_19336,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_19340,a[2]=((C_word*)t0)[4],a[3]=t5,a[4]=t6,a[5]=t1,a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_19379,a[2]=t7,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* take-up-to */
f_5662(t8,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k19377 in a19335 in k19326 in cset-difference in k4869 */
static void C_ccall f_19379(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* append */
t3=*((C_word*)lf[125]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t1,t2);}

/* k19338 in a19335 in k19326 in cset-difference in k4869 */
static void C_ccall f_19340(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_19340,2,t0,t1);}
t2=(C_truep(((C_word*)t0)[7])?(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t1):t1);
t3=(C_truep(((C_word*)t0)[6])?(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t2):t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_19349,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[3])){
t5=(C_word)C_a_i_list(&a,1,((C_word*)t0)[3]);
/* cset-union */
t6=lf[290];
f_19218(4,t6,t4,((C_word*)t0)[2],t5);}
else{
t5=t4;
f_19349(2,t5,((C_word*)t0)[2]);}}

/* k19347 in k19338 in a19335 in k19326 in cset-difference in k4869 */
static void C_ccall f_19349(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_19349,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_19352,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
/* cset-union */
t4=lf[290];
f_19218(4,t4,t2,t1,t3);}
else{
t3=t2;
f_19352(2,t3,t1);}}

/* k19350 in k19347 in k19338 in a19335 in k19326 in cset-difference in k4869 */
static void C_ccall f_19352(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* cset-difference */
f_19305(((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* cset-union in k4869 */
static void C_ccall f_19218(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_19218,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_19228,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_19295,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* find-tail */
f_5717(t4,t5,t2);}}

/* a19294 in cset-union in k4869 */
static void C_ccall f_19295(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_19295,3,t0,t1,t2);}
t3=(C_word)C_u_i_car(((C_word*)t0)[2]);
/* char-ranges-overlap? */
f_19073(t1,t2,t3);}

/* k19226 in cset-union in k4869 */
static void C_ccall f_19228(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_19228,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_19238,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_19246,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_19274,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* take-up-to */
f_5662(t4,((C_word*)t0)[2],t1);}
else{
t2=(C_word)C_u_i_car(((C_word*)t0)[4]);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[2]);
t4=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* cset-union */
t5=lf[290];
f_19218(4,t5,((C_word*)t0)[3],t3,t4);}}

/* k19272 in k19226 in cset-union in k4869 */
static void C_ccall f_19274(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* append */
t3=*((C_word*)lf[125]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t1,t2);}

/* k19244 in k19226 in cset-union in k4869 */
static void C_ccall f_19246(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_19246,2,t0,t1);}
t2=(C_word)C_u_i_car(((C_word*)t0)[4]);
t3=f_19061(C_a_i(&a,3),t2);
t4=(C_word)C_u_i_car(((C_word*)t0)[3]);
t5=f_19061(C_a_i(&a,3),t4);
t6=(C_word)C_u_i_car(t3);
t7=(C_word)C_u_i_car(t5);
t8=(C_word)C_fixnum_less_or_equal_p(t6,t7);
t9=(C_truep(t8)?(C_word)C_u_i_car(t3):(C_word)C_u_i_car(t5));
t10=(C_word)C_slot(t3,C_fix(1));
t11=(C_word)C_slot(t5,C_fix(1));
t12=(C_word)C_fixnum_greater_or_equal_p(t10,t11);
t13=(C_truep(t12)?(C_word)C_slot(t3,C_fix(1)):(C_word)C_slot(t5,C_fix(1)));
t14=(C_word)C_a_i_cons(&a,2,t9,t13);
t15=(C_word)C_a_i_list(&a,1,t14);
/* cset-union */
t16=lf[290];
f_19218(4,t16,((C_word*)t0)[2],t1,t15);}

/* k19236 in k19226 in cset-union in k4869 */
static void C_ccall f_19238(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* cset-union */
t3=lf[290];
f_19218(4,t3,((C_word*)t0)[2],t1,t2);}

/* char-ranges-overlap? in k4869 */
static void C_fcall f_19073(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
loop:
a=C_alloc(5);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_19073,NULL,3,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t2))){
if(C_truep((C_word)C_i_pairp(t3))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_19089,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_u_i_car(t2);
t6=(C_word)C_slot(t3,C_fix(1));
if(C_truep((C_word)C_fixnum_less_or_equal_p(t5,t6))){
t7=(C_word)C_u_i_car(t3);
t8=(C_word)C_slot(t2,C_fix(1));
t9=t4;
f_19089(t9,(C_word)C_fixnum_less_or_equal_p(t7,t8));}
else{
t7=t4;
f_19089(t7,C_SCHEME_FALSE);}}
else{
t4=(C_word)C_u_i_car(t2);
if(C_truep((C_word)C_fixnum_less_or_equal_p(t4,t3))){
t5=(C_word)C_slot(t2,C_fix(1));
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_fixnum_less_or_equal_p(t3,t5));}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}}
else{
if(C_truep((C_word)C_i_pairp(t3))){
/* char-ranges-overlap? */
t12=t1;
t13=t3;
t14=t2;
t1=t12;
t2=t13;
t3=t14;
goto loop;}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_eqvp(t2,t3));}}}

/* k19087 in char-ranges-overlap? in k4869 */
static void C_fcall f_19089(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
t3=(C_word)C_u_i_car(((C_word*)t0)[2]);
if(C_truep((C_word)C_fixnum_less_or_equal_p(t2,t3))){
t4=(C_word)C_slot(((C_word*)t0)[2],C_fix(1));
t5=(C_word)C_u_i_car(((C_word*)t0)[3]);
t6=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_fixnum_less_or_equal_p(t4,t5));}
else{
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}}

/* cset-range in k4869 */
static C_word C_fcall f_19061(C_word *a,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
t2=(C_word)C_charp(t1);
return((C_truep(t2)?(C_word)C_a_i_cons(&a,2,t1,t1):t1));}

/* cset-contains? in k4869 */
static void C_fcall f_19023(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_19023,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_19029,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* find */
f_5705(t1,t4,t2);}

/* a19028 in cset-contains? in k4869 */
static void C_ccall f_19029(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_19029,3,t0,t1,t2);}
t3=(C_word)C_i_eqvp(t2,((C_word*)t0)[2]);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_u_i_car(t2);
if(C_truep((C_word)C_fixnum_less_or_equal_p(t4,((C_word*)t0)[2]))){
t5=(C_word)C_slot(t2,C_fix(1));
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_fixnum_less_or_equal_p(((C_word*)t0)[2],t5));}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}}

/* sre->cset in k4869 */
static void C_fcall f_18742(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_18742,NULL,3,t1,t2,t3);}
t4=(C_word)C_i_pairp(t3);
t5=(C_truep(t4)?(C_word)C_u_i_car(t3):C_SCHEME_FALSE);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_18752,a[2]=t7,tmp=(C_word)a,a+=3,tmp));
t9=((C_word*)t7)[1];
f_18752(t9,t1,t2,t5);}

/* lp in sre->cset in k4869 */
static void C_fcall f_18752(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word *a;
loop:
a=C_alloc(16);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_18752,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_18755,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t5=(C_word)C_u_i_car(t2);
if(C_truep((C_word)C_i_stringp(t5))){
if(C_truep(t3)){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_18781,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t7=(C_word)C_u_i_car(t2);
/* string->list */
t8=*((C_word*)lf[73]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t6,t7);}
else{
t6=(C_word)C_u_i_car(t2);
/* string->list */
t7=*((C_word*)lf[73]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t1,t6);}}
else{
t6=(C_word)C_u_i_car(t2);
t7=(C_word)C_eqp(t6,lf[124]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_18808,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_18812,a[2]=t4,a[3]=t2,a[4]=t8,tmp=(C_word)a,a+=5,tmp);
t10=(C_word)C_u_i_cadr(t2);
/* rec3807 */
t11=t4;
f_18755(3,t11,t9,t10);}
else{
t8=(C_word)C_eqp(t6,lf[193]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_18837,a[2]=t4,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t10=(C_word)C_u_i_cadr(t2);
/* rec3807 */
t11=t4;
f_18755(3,t11,t9,t10);}
else{
t9=(C_word)C_eqp(t6,lf[204]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_18860,tmp=(C_word)a,a+=2,tmp);
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_18868,a[2]=t4,a[3]=t2,a[4]=t10,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t12=(C_word)C_u_i_cadr(t2);
/* rec3807 */
t13=t4;
f_18755(3,t13,t11,t12);}
else{
t10=(C_word)C_eqp(t6,lf[31]);
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_18889,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t12=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_18899,a[2]=t11,tmp=(C_word)a,a+=3,tmp);
t13=(C_word)C_slot(t2,C_fix(1));
t14=C_SCHEME_UNDEFINED;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_set_block_item(t15,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13500,a[2]=t15,tmp=(C_word)a,a+=3,tmp));
t17=((C_word*)t15)[1];
f_13500(t17,t12,t13,C_SCHEME_END_OF_LIST);}
else{
t11=(C_word)C_eqp(t6,lf[70]);
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_18916,a[2]=t4,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t13=(C_word)C_u_i_cadr(t2);
/* rec3807 */
t14=t4;
f_18755(3,t14,t12,t13);}
else{
t12=(C_word)C_eqp(t6,lf[184]);
if(C_truep(t12)){
t13=(C_word)C_slot(t2,C_fix(1));
t14=f_13416(C_a_i(&a,3),t13);
/* lp3796 */
t43=t1;
t44=t14;
t45=C_SCHEME_FALSE;
t1=t43;
t2=t44;
t3=t45;
goto loop;}
else{
t13=(C_word)C_eqp(t6,lf[185]);
if(C_truep(t13)){
t14=(C_word)C_slot(t2,C_fix(1));
t15=f_13416(C_a_i(&a,3),t14);
/* lp3796 */
t43=t1;
t44=t15;
t45=C_SCHEME_TRUE;
t1=t43;
t2=t44;
t3=t45;
goto loop;}
else{
/* error */
t14=*((C_word*)lf[24]+1);
((C_proc4)(void*)(*((C_word*)t14+1)))(4,t14,t1,lf[293],t2);}}}}}}}}}
else{
if(C_truep((C_word)C_charp(t2))){
t5=(C_word)C_a_i_string(&a,1,t2);
t6=(C_word)C_a_i_list(&a,1,t5);
/* rec3807 */
t7=t4;
f_18755(3,t7,t1,t6);}
else{
if(C_truep((C_word)C_i_stringp(t2))){
t5=(C_word)C_a_i_list(&a,1,t2);
/* rec3807 */
t6=t4;
f_18755(3,t6,t1,t5);}
else{
t5=(C_word)C_u_i_assq(t2,lf[205]);
if(C_truep(t5)){
t6=(C_word)C_slot(t5,C_fix(1));
/* rec3807 */
t7=t4;
f_18755(3,t7,t1,t6);}
else{
/* error */
t6=*((C_word*)lf[24]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t1,lf[294],t2);}}}}}

/* k18914 in lp in sre->cset in k4869 */
static void C_ccall f_18916(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_18916,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_18920,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_u_i_cddr(((C_word*)t0)[3]);
/* map */
t4=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,((C_word*)t0)[2],t3);}

/* k18918 in k18914 in lp in sre->cset in k4869 */
static void C_ccall f_18920(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* fold */
f_5889(((C_word*)t0)[3],lf[290],((C_word*)t0)[2],t1);}

/* lp in lp in sre->cset in k4869 */
static void C_fcall f_13500(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
loop:
a=C_alloc(9);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_13500,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
/* reverse */
t4=*((C_word*)lf[40]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}
else{
t4=(C_word)C_u_i_car(t2);
if(C_truep((C_word)C_i_stringp(t4))){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_13523,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_13527,a[2]=t5,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_u_i_car(t2);
/* string->list */
t8=*((C_word*)lf[73]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t6,t7);}
else{
t5=(C_word)C_slot(t2,C_fix(1));
t6=(C_word)C_u_i_car(t2);
t7=(C_word)C_a_i_cons(&a,2,t6,t3);
/* lp2241 */
t12=t1;
t13=t5;
t14=t7;
t1=t12;
t2=t13;
t3=t14;
goto loop;}}}

/* k13525 in lp in lp in sre->cset in k4869 */
static void C_ccall f_13527(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* append */
t3=*((C_word*)lf[125]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t1,t2);}

/* k13521 in lp in lp in sre->cset in k4869 */
static void C_ccall f_13523(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp2241 */
t2=((C_word*)((C_word*)t0)[4])[1];
f_13500(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k18897 in lp in sre->cset in k4869 */
static void C_ccall f_18899(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_18899,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_18666,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_18666(t5,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* lp in k18897 in lp in sre->cset in k4869 */
static void C_fcall f_18666(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(6);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_18666,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
/* reverse */
t4=*((C_word*)lf[40]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}
else{
t4=(C_word)C_u_i_cddr(t2);
t5=(C_word)C_u_i_car(t2);
t6=(C_word)C_u_i_cadr(t2);
t7=(C_word)C_a_i_cons(&a,2,t5,t6);
t8=(C_word)C_a_i_cons(&a,2,t7,t3);
/* lp3775 */
t10=t1;
t11=t4;
t12=t8;
t1=t10;
t2=t11;
t3=t12;
goto loop;}}

/* k18887 in lp in sre->cset in k4869 */
static void C_ccall f_18889(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(((C_word*)t0)[3])){
/* cset-case-insensitive */
t2=lf[126];
f_19554(3,t2,((C_word*)t0)[2],t1);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}}

/* k18866 in lp in sre->cset in k4869 */
static void C_ccall f_18868(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_18868,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_18872,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_u_i_cddr(((C_word*)t0)[3]);
/* map */
t4=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,((C_word*)t0)[2],t3);}

/* k18870 in k18866 in lp in sre->cset in k4869 */
static void C_ccall f_18872(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* fold */
f_5889(((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a18859 in lp in sre->cset in k4869 */
static void C_ccall f_18860(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_18860,4,t0,t1,t2,t3);}
/* cset-difference */
f_19305(t1,t3,t2);}

/* k18835 in lp in sre->cset in k4869 */
static void C_ccall f_18837(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_18837,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_18841,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_u_i_cddr(((C_word*)t0)[3]);
/* map */
t4=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,((C_word*)t0)[2],t3);}

/* k18839 in k18835 in lp in sre->cset in k4869 */
static void C_ccall f_18841(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* fold */
f_5889(((C_word*)t0)[3],lf[291],((C_word*)t0)[2],t1);}

/* k18810 in lp in sre->cset in k4869 */
static void C_ccall f_18812(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_18812,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_18816,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_u_i_cddr(((C_word*)t0)[3]);
/* map */
t4=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,((C_word*)t0)[2],t3);}

/* k18814 in k18810 in lp in sre->cset in k4869 */
static void C_ccall f_18816(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* fold */
f_5889(((C_word*)t0)[3],lf[290],((C_word*)t0)[2],t1);}

/* k18806 in lp in sre->cset in k4869 */
static void C_ccall f_18808(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* cset-complement */
f_19544(((C_word*)t0)[2],t1);}

/* k18779 in lp in sre->cset in k4869 */
static void C_ccall f_18781(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* cset-case-insensitive */
t2=lf[126];
f_19554(3,t2,((C_word*)t0)[2],t1);}

/* rec in lp in sre->cset in k4869 */
static void C_ccall f_18755(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_18755,3,t0,t1,t2);}
/* lp3796 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_18752(t3,t1,t2,((C_word*)t0)[2]);}

/* sre-cset->procedure in k4869 */
static void C_fcall f_18625(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_18625,NULL,3,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_18627,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp));}

/* f_18627 in sre-cset->procedure in k4869 */
static void C_ccall f_18627(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_18627,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_18634,a[2]=t5,a[3]=t4,a[4]=t2,a[5]=t1,a[6]=((C_word*)t0)[3],a[7]=t3,tmp=(C_word)a,a+=8,tmp);
t7=(C_word)C_fix((C_word)C_header_size(t2));
if(C_truep((C_word)C_i_lessp(t3,t7))){
t8=(C_word)C_subchar(t2,t3);
/* cset-contains? */
f_19023(t6,((C_word*)t0)[2],t8);}
else{
t8=t6;
f_18634(2,t8,C_SCHEME_FALSE);}}

/* k18632 */
static void C_ccall f_18634(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_18634,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[7],C_fix(1));
/* next3763 */
t3=((C_word*)t0)[6];
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,((C_word*)t0)[5],((C_word*)t0)[4],t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* fail3768 */
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[5]);}}

/* insert-sorted in k4869 */
static void C_fcall f_16261(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_16261,NULL,3,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST));}
else{
t4=(C_word)C_u_i_car(t3);
if(C_truep((C_word)C_i_less_or_equalp(t2,t4))){
t5=(C_word)C_u_i_car(t3);
t6=(C_word)C_i_nequalp(t2,t5);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_truep(t6)?t3:(C_word)C_a_i_cons(&a,2,t2,t3)));}
else{
t5=(C_word)C_u_i_car(t3);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_16301,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_slot(t3,C_fix(1));
/* insert-sorted */
t11=t6;
t12=t2;
t13=t7;
t1=t11;
t2=t12;
t3=t13;
goto loop;}}}

/* k16299 in insert-sorted in k4869 */
static void C_ccall f_16301(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_16301,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* nfa-closure in k4869 */
static void C_fcall f_16180(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_16180,NULL,3,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_16186,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_16186(t7,t1,t3,C_SCHEME_END_OF_LIST);}

/* lp in nfa-closure in k4869 */
static void C_fcall f_16186(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
loop:
a=C_alloc(15);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_16186,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_u_i_car(t2);
if(C_truep((C_word)C_i_memv(t4,t3))){
t5=(C_word)C_slot(t2,C_fix(1));
/* lp3051 */
t14=t1;
t15=t5;
t16=t3;
t1=t14;
t2=t15;
t3=t16;
goto loop;}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_16213,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_16225,a[2]=t5,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_16233,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_16235,tmp=(C_word)a,a+=2,tmp);
t9=(C_word)C_u_i_car(t2);
t10=(C_word)C_i_assv(t9,((C_word*)t0)[2]);
t11=(C_word)C_slot(t10,C_fix(1));
/* filter */
f_5919(t7,t8,t11);}}}

/* a16234 in lp in nfa-closure in k4869 */
static void C_ccall f_16235(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_16235,3,t0,t1,t2);}
t3=(C_word)C_u_i_car(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_eqp(lf[83],t3));}

/* k16231 in lp in nfa-closure in k4869 */
static void C_ccall f_16233(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],*((C_word*)lf[282]+1),t1);}

/* k16223 in lp in nfa-closure in k4869 */
static void C_ccall f_16225(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* append */
t3=*((C_word*)lf[125]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t1,t2);}

/* k16211 in lp in nfa-closure in k4869 */
static void C_ccall f_16213(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_16213,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_16217,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_u_i_car(((C_word*)t0)[3]);
/* insert-sorted */
f_16261(t2,t3,((C_word*)t0)[2]);}

/* k16215 in k16211 in lp in nfa-closure in k4869 */
static void C_ccall f_16217(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp3051 */
t2=((C_word*)((C_word*)t0)[4])[1];
f_16186(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* intersect-char-ranges in k4869 */
static void C_fcall f_16064(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word *a;
loop:
a=C_alloc(13);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_16064,NULL,3,t1,t2,t3);}
t4=(C_word)C_u_i_car(t2);
t5=(C_word)C_u_i_car(t3);
if(C_truep((C_word)C_fixnum_greaterp(t4,t5))){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_16078,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* intersect-char-ranges */
t16=t6;
t17=t3;
t18=t2;
t1=t16;
t2=t17;
t3=t18;
goto loop;}
else{
t6=(C_word)C_u_i_car(t2);
t7=(C_word)C_slot(t2,C_fix(1));
t8=(C_word)C_u_i_car(t3);
t9=(C_word)C_slot(t3,C_fix(1));
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_16097,a[2]=t1,a[3]=t8,a[4]=t7,a[5]=t9,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_lessp(t6,t8))){
t11=(C_word)C_fix((C_word)C_character_code(t8));
t12=(C_word)C_a_i_minus(&a,2,t11,C_fix(1));
t13=(C_word)C_make_character((C_word)C_unfix(t12));
/* char-range */
t14=t10;
f_16097(t14,f_15978(C_a_i(&a,3),t6,t13));}
else{
t11=t10;
f_16097(t11,C_SCHEME_FALSE);}}}

/* k16095 in intersect-char-ranges in k4869 */
static void C_fcall f_16097(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_16097,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_16101,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_fixnum_greaterp(((C_word*)t0)[4],((C_word*)t0)[5]))){
t3=(C_word)C_fix((C_word)C_character_code(((C_word*)t0)[5]));
t4=(C_word)C_a_i_plus(&a,2,t3,C_fix(1));
t5=(C_word)C_make_character((C_word)C_unfix(t4));
/* char-range */
t6=t2;
f_16101(t6,f_15978(C_a_i(&a,3),t5,((C_word*)t0)[4]));}
else{
t3=t2;
f_16101(t3,C_SCHEME_FALSE);}}

/* k16099 in k16095 in intersect-char-ranges in k4869 */
static void C_fcall f_16101(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_16101,NULL,2,t0,t1);}
t2=(C_word)C_fixnum_lessp(((C_word*)t0)[6],((C_word*)t0)[5]);
t3=(C_truep(t2)?((C_word*)t0)[6]:((C_word*)t0)[5]);
t4=f_15978(C_a_i(&a,3),((C_word*)t0)[4],t3);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_16109,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_greaterp(((C_word*)t0)[6],((C_word*)t0)[5]))){
t6=(C_word)C_fix((C_word)C_character_code(((C_word*)t0)[5]));
t7=(C_word)C_a_i_plus(&a,2,t6,C_fix(1));
t8=(C_word)C_make_character((C_word)C_unfix(t7));
/* char-range */
t9=t5;
f_16109(t9,f_15978(C_a_i(&a,3),t8,((C_word*)t0)[6]));}
else{
t6=t5;
f_16109(t6,C_SCHEME_FALSE);}}

/* k16107 in k16099 in k16095 in intersect-char-ranges in k4869 */
static void C_fcall f_16109(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_16109,NULL,2,t0,t1);}
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,5,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE,t1));}

/* k16076 in intersect-char-ranges in k4869 */
static void C_ccall f_16078(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* reverse */
t2=*((C_word*)lf[40]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* split-char-range in k4869 */
static void C_fcall f_15990(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_15990,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_15998,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_u_i_car(t2);
if(C_truep((C_word)C_i_eqvp(t3,t5))){
t6=t4;
f_15998(t6,C_SCHEME_FALSE);}
else{
t6=(C_word)C_u_i_car(t2);
t7=(C_word)C_fix((C_word)C_character_code(t3));
t8=(C_word)C_a_i_minus(&a,2,t7,C_fix(1));
t9=(C_word)C_make_character((C_word)C_unfix(t8));
/* char-range */
t10=t4;
f_15998(t10,f_15978(C_a_i(&a,3),t6,t9));}}

/* k15996 in split-char-range in k4869 */
static void C_fcall f_15998(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_15998,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_16002,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
if(C_truep((C_word)C_i_eqvp(((C_word*)t0)[2],t3))){
t4=t2;
f_16002(t4,C_SCHEME_FALSE);}
else{
t4=(C_word)C_fix((C_word)C_character_code(((C_word*)t0)[2]));
t5=(C_word)C_a_i_plus(&a,2,t4,C_fix(1));
t6=(C_word)C_make_character((C_word)C_unfix(t5));
t7=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* char-range */
t8=t2;
f_16002(t8,f_15978(C_a_i(&a,3),t6,t7));}}

/* k16000 in k15996 in split-char-range in k4869 */
static void C_fcall f_16002(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_16002,NULL,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[2],t1));}

/* char-range in k4869 */
static C_word C_fcall f_15978(C_word *a,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
t3=(C_word)C_i_eqvp(t1,t2);
return((C_truep(t3)?t1:(C_word)C_a_i_cons(&a,2,t1,t2)));}

/* nfa-join-transitions! in k4869 */
static void C_fcall f_15516(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_15516,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_15519,tmp=(C_word)a,a+=2,tmp);
t5=(C_word)C_u_i_car(t3);
if(C_truep((C_word)C_charp(t5))){
t6=(C_word)C_u_i_car(t3);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_15547,a[2]=t8,a[3]=t2,a[4]=t6,a[5]=t3,tmp=(C_word)a,a+=6,tmp));
t10=((C_word*)t8)[1];
f_15547(t10,t1,t2,C_SCHEME_END_OF_LIST);}
else{
t6=(C_word)C_u_i_caar(t3);
t7=(C_word)C_u_i_cdar(t3);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_15725,a[2]=t6,a[3]=t7,a[4]=t9,a[5]=t4,a[6]=t2,a[7]=t3,tmp=(C_word)a,a+=8,tmp));
t11=((C_word*)t9)[1];
f_15725(t11,t1,t2,C_SCHEME_END_OF_LIST);}}

/* lp in nfa-join-transitions! in k4869 */
static void C_fcall f_15725(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_15725,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(C_word)C_u_i_car(((C_word*)t0)[7]);
t5=(C_word)C_slot(((C_word*)t0)[7],C_fix(1));
t6=(C_word)C_a_i_list(&a,2,t4,t5);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_cons(&a,2,t6,((C_word*)t0)[6]));}
else{
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_15753,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[7],a[10]=t2,tmp=(C_word)a,a+=11,tmp);
t5=(C_word)C_u_i_caar(t2);
if(C_truep((C_word)C_charp(t5))){
t6=(C_word)C_u_i_caar(t2);
if(C_truep((C_word)C_fixnum_less_or_equal_p(((C_word*)t0)[2],t6))){
t7=(C_word)C_u_i_caar(t2);
t8=t4;
f_15753(t8,(C_word)C_fixnum_less_or_equal_p(t7,((C_word*)t0)[3]));}
else{
t7=t4;
f_15753(t7,C_SCHEME_FALSE);}}
else{
t6=t4;
f_15753(t6,C_SCHEME_FALSE);}}}

/* k15751 in lp in nfa-join-transitions! in k4869 */
static void C_fcall f_15753(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_15753,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_15758,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_15797,a[2]=t2,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_u_i_car(((C_word*)t0)[9]);
t5=(C_word)C_u_i_caar(((C_word*)t0)[10]);
/* split-char-range */
f_15990(t3,t4,t5);}
else{
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_15811,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
t3=(C_word)C_u_i_caar(((C_word*)t0)[10]);
if(C_truep((C_word)C_i_pairp(t3))){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_15910,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[10],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_u_i_caaar(((C_word*)t0)[10]);
if(C_truep((C_word)C_fixnum_less_or_equal_p(t5,((C_word*)t0)[3]))){
t6=(C_word)C_u_i_cdaar(((C_word*)t0)[10]);
t7=t4;
f_15910(t7,(C_word)C_fixnum_less_or_equal_p(((C_word*)t0)[2],t6));}
else{
t6=t4;
f_15910(t6,C_SCHEME_FALSE);}}
else{
t4=t2;
f_15811(t4,C_SCHEME_FALSE);}}}

/* k15908 in k15751 in lp in nfa-join-transitions! in k4869 */
static void C_fcall f_15910(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
f_15811(t2,t1);}
else{
t2=(C_word)C_u_i_caaar(((C_word*)t0)[4]);
if(C_truep((C_word)C_fixnum_less_or_equal_p(((C_word*)t0)[3],t2))){
t3=(C_word)C_u_i_cdaar(((C_word*)t0)[4]);
t4=((C_word*)t0)[5];
f_15811(t4,(C_word)C_fixnum_less_or_equal_p(t3,((C_word*)t0)[2]));}
else{
t3=((C_word*)t0)[5];
f_15811(t3,C_SCHEME_FALSE);}}}

/* k15809 in k15751 in lp in nfa-join-transitions! in k4869 */
static void C_fcall f_15811(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_15811,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_15816,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_15881,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_u_i_car(((C_word*)t0)[7]);
t5=(C_word)C_u_i_caar(((C_word*)t0)[8]);
/* intersect-char-ranges */
f_16064(t3,t4,t5);}
else{
t2=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
t3=(C_word)C_u_i_car(((C_word*)t0)[8]);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[3]);
/* lp2969 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_15725(t5,((C_word*)t0)[4],t2,t4);}}

/* k15879 in k15809 in k15751 in lp in nfa-join-transitions! in k4869 */
static void C_ccall f_15881(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a15815 in k15809 in k15751 in lp in nfa-join-transitions! in k4869 */
static void C_ccall f_15816(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr7,(void*)f_15816,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(C_word)C_u_i_cdar(((C_word*)t0)[5]);
t8=(C_word)C_u_i_car(((C_word*)t0)[5]);
t9=(C_word)C_i_setslot(t8,C_fix(0),t4);
t10=(C_word)C_u_i_car(((C_word*)t0)[5]);
t11=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_15869,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=t7,a[5]=t6,a[6]=t2,a[7]=t3,a[8]=t1,a[9]=((C_word*)t0)[3],a[10]=((C_word*)t0)[4],a[11]=t10,tmp=(C_word)a,a+=12,tmp);
t12=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* insert-sorted */
f_16261(t11,t12,t7);}

/* k15867 in a15815 in k15809 in k15751 in lp in nfa-join-transitions! in k4869 */
static void C_ccall f_15869(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15869,2,t0,t1);}
t2=(C_word)C_i_setslot(((C_word*)t0)[11],C_fix(1),t1);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_15829,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)t0)[3])){
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)t0)[4]);
t5=t3;
f_15829(t5,(C_word)C_a_i_cons(&a,2,t4,((C_word*)t0)[2]));}
else{
t4=t3;
f_15829(t4,((C_word*)t0)[2]);}}

/* k15827 in k15867 in a15815 in k15809 in k15751 in lp in nfa-join-transitions! in k4869 */
static void C_fcall f_15829(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_15829,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_15832,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]);
t4=t2;
f_15832(t4,(C_word)C_a_i_cons(&a,2,t3,t1));}
else{
t3=t2;
f_15832(t3,t1);}}

/* k15830 in k15827 in k15867 in a15815 in k15809 in k15751 in lp in nfa-join-transitions! in k4869 */
static void C_fcall f_15832(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_15832,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_15839,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
/* join2936 */
f_15519(t2,t1,((C_word*)t0)[2],t3);}

/* k15837 in k15830 in k15827 in k15867 in a15815 in k15809 in k15751 in lp in nfa-join-transitions! in k4869 */
static void C_ccall f_15839(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* join2936 */
f_15519(((C_word*)t0)[3],t1,((C_word*)t0)[2],t2);}

/* k15795 in k15751 in lp in nfa-join-transitions! in k4869 */
static void C_ccall f_15797(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a15757 in k15751 in lp in nfa-join-transitions! in k4869 */
static void C_ccall f_15758(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_15758,4,t0,t1,t2,t3);}
t4=(C_word)C_u_i_car(((C_word*)t0)[5]);
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_15785,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=t4,tmp=(C_word)a,a+=9,tmp);
t6=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t7=(C_word)C_u_i_cdar(((C_word*)t0)[5]);
/* insert-sorted */
f_16261(t5,t6,t7);}

/* k15783 in a15757 in k15751 in lp in nfa-join-transitions! in k4869 */
static void C_ccall f_15785(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15785,2,t0,t1);}
t2=(C_word)C_i_setslot(((C_word*)t0)[8],C_fix(1),t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_15769,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_slot(((C_word*)t0)[7],C_fix(1));
/* join2936 */
f_15519(t3,((C_word*)t0)[3],((C_word*)t0)[2],t4);}

/* k15767 in k15783 in a15757 in k15751 in lp in nfa-join-transitions! in k4869 */
static void C_ccall f_15769(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* join2936 */
f_15519(((C_word*)t0)[3],t1,((C_word*)t0)[2],t2);}

/* lp in nfa-join-transitions! in k4869 */
static void C_fcall f_15547(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_15547,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t5=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,t5,((C_word*)t0)[3]));}
else{
t4=(C_word)C_u_i_caar(t2);
if(C_truep((C_word)C_i_eqvp(((C_word*)t0)[4],t4))){
t5=(C_word)C_u_i_car(t2);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_15582,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t8=(C_word)C_u_i_cdar(t2);
/* insert-sorted */
f_16261(t6,t7,t8);}
else{
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_15596,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=t3,a[6]=t2,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
t6=(C_word)C_u_i_caar(t2);
if(C_truep((C_word)C_i_pairp(t6))){
t7=(C_word)C_u_i_caaar(t2);
if(C_truep((C_word)C_fixnum_less_or_equal_p(t7,((C_word*)t0)[4]))){
t8=(C_word)C_u_i_cdaar(t2);
t9=t5;
f_15596(t9,(C_word)C_fixnum_less_or_equal_p(((C_word*)t0)[4],t8));}
else{
t8=t5;
f_15596(t8,C_SCHEME_FALSE);}}
else{
t7=t5;
f_15596(t7,C_SCHEME_FALSE);}}}}

/* k15594 in lp in nfa-join-transitions! in k4869 */
static void C_fcall f_15596(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_15596,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_15601,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_15663,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_u_i_caar(((C_word*)t0)[6]);
t5=(C_word)C_u_i_car(((C_word*)t0)[4]);
/* split-char-range */
f_15990(t3,t4,t5);}
else{
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t3=(C_word)C_u_i_car(((C_word*)t0)[6]);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[5]);
/* lp2944 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_15547(t5,((C_word*)t0)[3],t2,t4);}}

/* k15661 in k15594 in lp in nfa-join-transitions! in k4869 */
static void C_ccall f_15663(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a15600 in k15594 in lp in nfa-join-transitions! in k4869 */
static void C_ccall f_15601(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_15601,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_15651,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t5=(C_word)C_slot(((C_word*)t0)[2],C_fix(1));
t6=(C_word)C_u_i_cdar(((C_word*)t0)[4]);
/* insert-sorted */
f_16261(t4,t5,t6);}

/* k15649 in a15600 in k15594 in lp in nfa-join-transitions! in k4869 */
static void C_ccall f_15651(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15651,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_15613,a[2]=t2,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_15617,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[2])){
t5=(C_word)C_u_i_cdar(((C_word*)t0)[5]);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t5);
t7=t4;
f_15617(t7,(C_word)C_a_i_list(&a,1,t6));}
else{
t5=t4;
f_15617(t5,C_SCHEME_END_OF_LIST);}}

/* k15615 in k15649 in a15600 in k15594 in lp in nfa-join-transitions! in k4869 */
static void C_fcall f_15617(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_15617,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_15621,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(C_word)C_u_i_cdar(((C_word*)t0)[5]);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3);
t5=t2;
f_15621(t5,(C_word)C_a_i_list(&a,1,t4));}
else{
t3=t2;
f_15621(t3,C_SCHEME_END_OF_LIST);}}

/* k15619 in k15615 in k15649 in a15600 in k15594 in lp in nfa-join-transitions! in k4869 */
static void C_fcall f_15621(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* append */
t3=*((C_word*)lf[125]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2],t2);}

/* k15611 in k15649 in a15600 in k15594 in lp in nfa-join-transitions! in k4869 */
static void C_ccall f_15613(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15613,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k15580 in lp in nfa-join-transitions! in k4869 */
static void C_ccall f_15582(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[4],C_fix(1),t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[2]);}

/* join in nfa-join-transitions! in k4869 */
static void C_fcall f_15519(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_15519,NULL,4,t1,t2,t3,t4);}
t5=t3;
if(C_truep(t5)){
t6=(C_word)C_a_i_cons(&a,2,t3,t4);
/* nfa-join-transitions! */
f_15516(t1,t2,t6);}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t2);}}

/* nfa->dfa in k4869 */
static void C_fcall f_15219(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_15219,NULL,3,t1,t2,t3);}
t4=(C_word)C_i_pairp(t3);
t5=(C_truep(t4)?(C_word)C_u_i_car(t3):C_SCHEME_FALSE);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_15334,a[2]=t1,a[3]=t2,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_u_i_caar(t2);
t8=(C_word)C_a_i_list(&a,1,t7);
/* nfa-closure */
f_16180(t6,t2,t8);}

/* k15332 in nfa->dfa in k4869 */
static void C_ccall f_15334(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15334,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_15232,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_15232(t6,((C_word*)t0)[2],t2,C_fix(0),C_SCHEME_END_OF_LIST);}

/* lp in k15332 in nfa->dfa in k4869 */
static void C_fcall f_15232(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word *a;
loop:
a=C_alloc(15);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_15232,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_15246,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* reverse */
t6=*((C_word*)lf[40]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t4);}
else{
t5=(C_word)C_u_i_car(t2);
if(C_truep((C_word)C_i_assoc(t5,t4))){
t6=(C_word)C_slot(t2,C_fix(1));
/* lp2853 */
t15=t1;
t16=t6;
t17=t3;
t18=t4;
t1=t15;
t2=t16;
t3=t17;
t4=t18;
goto loop;}
else{
t6=(C_word)C_u_i_car(t2);
t7=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_15265,a[2]=t2,a[3]=t4,a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=t3,a[7]=((C_word*)t0)[3],a[8]=t6,tmp=(C_word)a,a+=9,tmp);
t8=((C_word*)t0)[2];
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_15427,a[2]=t10,a[3]=t8,tmp=(C_word)a,a+=4,tmp));
t12=((C_word*)t10)[1];
f_15427(t12,t7,C_SCHEME_END_OF_LIST,t6,C_SCHEME_END_OF_LIST);}}}

/* lp in lp in k15332 in nfa->dfa in k4869 */
static void C_fcall f_15427(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word *a;
loop:
a=C_alloc(6);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_15427,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
if(C_truep((C_word)C_i_nullp(t3))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_15445,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* map */
t6=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t1,t5,t4);}
else{
t5=(C_word)C_u_i_car(t3);
t6=(C_word)C_i_assv(t5,((C_word*)t0)[3]);
t7=(C_truep(t6)?(C_word)C_slot(t6,C_fix(1)):C_SCHEME_END_OF_LIST);
t8=(C_word)C_slot(t3,C_fix(1));
/* lp2907 */
t17=t1;
t18=t7;
t19=t8;
t20=t4;
t1=t17;
t2=t18;
t3=t19;
t4=t20;
goto loop;}}
else{
t5=(C_word)C_u_i_caar(t2);
t6=(C_word)C_eqp(lf[83],t5);
if(C_truep(t6)){
t7=(C_word)C_slot(t2,C_fix(1));
/* lp2907 */
t17=t1;
t18=t7;
t19=t3;
t20=t4;
t1=t17;
t2=t18;
t3=t19;
t4=t20;
goto loop;}
else{
t7=(C_word)C_slot(t2,C_fix(1));
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_15506,a[2]=t3,a[3]=t7,a[4]=t1,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
t9=(C_word)C_u_i_car(t2);
/* nfa-join-transitions! */
f_15516(t8,t4,t9);}}}

/* k15504 in lp in lp in k15332 in nfa->dfa in k4869 */
static void C_ccall f_15506(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp2907 */
t2=((C_word*)((C_word*)t0)[5])[1];
f_15427(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a15444 in lp in lp in k15332 in nfa->dfa in k4869 */
static void C_ccall f_15445(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_15445,3,t0,t1,t2);}
t3=(C_word)C_u_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_15457,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_slot(t2,C_fix(1));
/* nfa-closure */
f_16180(t4,((C_word*)t0)[2],t5);}

/* k15455 in a15444 in lp in lp in k15332 in nfa->dfa in k4869 */
static void C_ccall f_15457(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15457,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k15263 in lp in k15332 in nfa->dfa in k4869 */
static void C_ccall f_15265(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15265,2,t0,t1);}
t2=(C_word)C_i_memv(C_fix(0),((C_word*)t0)[8]);
t3=(C_truep(t2)?C_SCHEME_TRUE:C_SCHEME_FALSE);
t4=(C_word)C_i_not(((C_word*)t0)[7]);
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_15277,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[8],a[8]=t3,a[9]=((C_word*)t0)[6],tmp=(C_word)a,a+=10,tmp);
if(C_truep(t4)){
t6=t5;
f_15277(t6,t4);}
else{
t6=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[6],C_fix(1));
t7=t5;
f_15277(t7,(C_word)C_i_lessp(t6,((C_word*)t0)[7]));}}

/* k15275 in k15263 in lp in k15332 in nfa->dfa in k4869 */
static void C_fcall f_15277(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_15277,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_15284,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_15312,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* map */
t4=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,*((C_word*)lf[282]+1),((C_word*)t0)[3]);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k15310 in k15275 in k15263 in lp in k15332 in nfa->dfa in k4869 */
static void C_ccall f_15312(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* append */
t3=*((C_word*)lf[125]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t1,t2);}

/* k15282 in k15275 in k15263 in lp in k15332 in nfa->dfa in k4869 */
static void C_ccall f_15284(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15284,2,t0,t1);}
t2=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[8],C_fix(1));
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_15308,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* ##sys#append */
t4=*((C_word*)lf[84]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k15306 in k15282 in k15275 in k15263 in lp in k15332 in nfa->dfa in k4869 */
static void C_ccall f_15308(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15308,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t2);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_15300,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* ##sys#append */
t5=*((C_word*)lf[84]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k15298 in k15306 in k15282 in k15275 in k15263 in lp in k15332 in nfa->dfa in k4869 */
static void C_ccall f_15300(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15300,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t1);
/* lp2853 */
t3=((C_word*)((C_word*)t0)[5])[1];
f_15232(t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k15244 in lp in k15332 in nfa->dfa in k4869 */
static void C_ccall f_15246(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15246,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_15354,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_15411,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* map */
t5=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,*((C_word*)lf[281]+1),t1);}

/* k15409 in k15244 in lp in k15332 in nfa->dfa in k4869 */
static void C_ccall f_15411(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15411,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_15415,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_length(((C_word*)t0)[2]);
/* zero-to */
f_5623(t2,t3);}

/* k15413 in k15409 in k15244 in lp in k15332 in nfa->dfa in k4869 */
static void C_ccall f_15415(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[280]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],*((C_word*)lf[222]+1),((C_word*)t0)[2],t1);}

/* k15352 in k15244 in lp in k15332 in nfa->dfa in k4869 */
static void C_ccall f_15354(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15354,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_15356,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_15371,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_15373,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* map */
t5=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a15372 in k15352 in k15244 in lp in k15332 in nfa->dfa in k4869 */
static void C_ccall f_15373(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_15373,3,t0,t1,t2);}
t3=(C_word)C_u_i_cadr(t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_15385,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_15387,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t6=(C_word)C_u_i_cddr(t2);
/* map */
t7=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t4,t5,t6);}

/* a15386 in a15372 in k15352 in k15244 in lp in k15332 in nfa->dfa in k4869 */
static void C_ccall f_15387(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_15387,3,t0,t1,t2);}
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_slot(t2,C_fix(1));
t5=f_15356(((C_word*)t0)[2],t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,t3,t5));}

/* k15383 in a15372 in k15352 in k15244 in lp in k15332 in nfa->dfa in k4869 */
static void C_ccall f_15385(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15385,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k15369 in k15352 in k15244 in lp in k15332 in nfa->dfa in k4869 */
static void C_ccall f_15371(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* list->vector */
t2=*((C_word*)lf[279]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* renumber in k15352 in k15244 in lp in k15332 in nfa->dfa in k4869 */
static C_word C_fcall f_15356(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
t2=(C_word)C_i_assoc(t1,((C_word*)t0)[2]);
return((C_word)C_slot(t2,C_fix(1)));}

/* sre->nfa in k4869 */
static void C_fcall f_14429(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_14429,NULL,3,t1,t2,t3);}
t4=(C_word)C_a_i_list(&a,1,t2);
t5=(C_word)C_i_pairp(t3);
t6=(C_truep(t5)?(C_word)C_u_i_car(t3):C_fix(0));
t7=(C_word)C_a_i_list(&a,1,C_fix(0));
t8=(C_word)C_a_i_list(&a,1,t7);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_14447,a[2]=t10,tmp=(C_word)a,a+=3,tmp));
t12=((C_word*)t10)[1];
f_14447(t12,t1,t4,C_fix(1),t6,t8);}

/* lp in sre->nfa in k4869 */
static void C_fcall f_14447(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word *a;
loop:
a=C_alloc(21);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_14447,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_14450,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_14464,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t5);}
else{
t8=(C_word)C_u_i_car(t2);
if(C_truep((C_word)C_i_stringp(t8))){
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_14512,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_14516,a[2]=t9,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t11=(C_word)C_u_i_car(t2);
/* string->list */
t12=*((C_word*)lf[73]+1);
((C_proc3)(void*)(*((C_word*)t12+1)))(3,t12,t10,t11);}
else{
t9=(C_word)C_u_i_car(t2);
t10=(C_word)C_eqp(lf[83],t9);
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_14537,a[2]=t1,a[3]=t7,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t12=(C_word)C_slot(t2,C_fix(1));
/* lp2659 */
t42=t11;
t43=t12;
t44=t3;
t45=t4;
t46=t5;
t1=t42;
t2=t43;
t3=t44;
t4=t45;
t5=t46;
goto loop;}
else{
t11=(C_word)C_u_i_car(t2);
if(C_truep((C_word)C_charp(t11))){
t12=(C_word)C_u_i_car(t2);
t13=f_9172(t12);
t14=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_14560,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=((C_word*)t0)[2],a[6]=t13,a[7]=t1,a[8]=t7,a[9]=t2,tmp=(C_word)a,a+=10,tmp);
t15=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_14593,a[2]=t14,a[3]=t13,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* flag-set? */
f_6125(t15,t4,C_fix(2));}
else{
t12=(C_word)C_u_i_car(t2);
if(C_truep((C_word)C_i_symbolp(t12))){
t13=(C_word)C_u_i_car(t2);
t14=(C_word)C_u_i_assq(t13,lf[205]);
if(C_truep(t14)){
t15=(C_word)C_slot(t14,C_fix(1));
t16=(C_word)C_slot(t2,C_fix(1));
t17=(C_word)C_a_i_cons(&a,2,t15,t16);
/* lp2659 */
t42=t1;
t43=t17;
t44=t3;
t45=t4;
t46=t5;
t1=t42;
t2=t43;
t3=t44;
t4=t45;
t5=t46;
goto loop;}
else{
t15=t1;
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,C_SCHEME_FALSE);}}
else{
t13=(C_word)C_u_i_car(t2);
if(C_truep((C_word)C_i_pairp(t13))){
t14=(C_word)C_u_i_caar(t2);
if(C_truep((C_word)C_i_stringp(t14))){
t15=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_14670,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[2],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t16=(C_word)C_u_i_caar(t2);
/* string->list */
t17=*((C_word*)lf[73]+1);
((C_proc3)(void*)(*((C_word*)t17+1)))(3,t17,t15,t16);}
else{
t15=(C_word)C_u_i_caar(t2);
t16=(C_word)C_eqp(t15,lf[82]);
t17=(C_truep(t16)?t16:(C_word)C_eqp(t15,lf[186]));
if(C_truep(t17)){
t18=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_14693,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
t19=(C_word)C_u_i_cdar(t2);
t20=(C_word)C_slot(t2,C_fix(1));
/* append */
t21=*((C_word*)lf[125]+1);
((C_proc4)(void*)(*((C_word*)t21+1)))(4,t21,t18,t19,t20);}
else{
t18=(C_word)C_eqp(t15,lf[184]);
t19=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_14710,a[2]=t7,a[3]=t15,a[4]=t5,a[5]=t3,a[6]=t4,a[7]=t6,a[8]=t1,a[9]=((C_word*)t0)[2],a[10]=t2,tmp=(C_word)a,a+=11,tmp);
if(C_truep(t18)){
t20=t19;
f_14710(t20,t18);}
else{
t20=(C_word)C_eqp(t15,lf[185]);
if(C_truep(t20)){
t21=t19;
f_14710(t21,t20);}
else{
t21=(C_word)C_eqp(t15,lf[118]);
t22=t19;
f_14710(t22,(C_truep(t21)?t21:(C_word)C_eqp(t15,lf[119])));}}}}}
else{
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,C_SCHEME_FALSE);}}}}}}}

/* k14708 in lp in sre->nfa in k4869 */
static void C_fcall f_14710(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_14710,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_14713,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_slot(((C_word*)t0)[10],C_fix(1));
/* lp2659 */
t4=((C_word*)((C_word*)t0)[9])[1];
f_14447(t4,t2,t3,((C_word*)t0)[5],((C_word*)t0)[6],((C_word*)t0)[4]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[3],lf[31]);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_14764,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[2],tmp=(C_word)a,a+=11,tmp);
if(C_truep(t2)){
t4=t3;
f_14764(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[3],lf[204]);
if(C_truep(t4)){
t5=t3;
f_14764(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[3],lf[193]);
t6=t3;
f_14764(t6,(C_truep(t5)?t5:(C_word)C_eqp(((C_word*)t0)[3],lf[124])));}}}}

/* k14762 in k14708 in lp in sre->nfa in k4869 */
static void C_fcall f_14764(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_14764,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_14767,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
t3=(C_word)C_u_i_car(((C_word*)t0)[8]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_14852,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* flag-set? */
f_6125(t4,((C_word*)t0)[5],C_fix(2));}
else{
t2=(C_word)C_eqp(((C_word*)t0)[2],lf[70]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_14861,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
/* lp2659 */
t5=((C_word*)((C_word*)t0)[7])[1];
f_14447(t5,t3,t4,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[2],lf[95]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_14964,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
/* lp2659 */
t6=((C_word*)((C_word*)t0)[7])[1];
f_14447(t6,t4,t5,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[2],lf[93]);
t5=(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[2],lf[91]));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_15024,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
t7=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
/* lp2659 */
t8=((C_word*)((C_word*)t0)[7])[1];
f_14447(t8,t6,t7,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[2],lf[76]);
t7=(C_truep(t6)?t6:(C_word)C_eqp(((C_word*)t0)[2],lf[85]));
if(C_truep(t7)){
t8=(C_word)C_u_i_cdar(((C_word*)t0)[8]);
t9=f_13391(C_a_i(&a,3),t8);
t10=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
t11=(C_word)C_a_i_cons(&a,2,t9,t10);
/* lp2659 */
t12=((C_word*)((C_word*)t0)[7])[1];
f_14447(t12,((C_word*)t0)[9],t11,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t8=((C_word*)t0)[9];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_FALSE);}}}}}}

/* k15022 in k14762 in k14708 in lp in sre->nfa in k4869 */
static void C_ccall f_15024(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15024,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_15030,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_15112,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* new-state-number2665 */
t4=((C_word*)t0)[2];
f_14450(t4,t3,t1);}
else{
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k15110 in k15022 in k14762 in k14708 in lp in sre->nfa in k4869 */
static void C_ccall f_15112(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp2659 */
t2=((C_word*)((C_word*)t0)[5])[1];
f_14447(t2,((C_word*)t0)[4],lf[278],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k15028 in k15022 in k14762 in k14708 in lp in sre->nfa in k4869 */
static void C_ccall f_15030(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15030,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_15033,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_u_i_cdar(((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_15108,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* new-state-number2665 */
t5=((C_word*)t0)[2];
f_14450(t5,t4,t1);}

/* k15106 in k15028 in k15022 in k14762 in k14708 in lp in sre->nfa in k4869 */
static void C_ccall f_15108(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp2659 */
t2=((C_word*)((C_word*)t0)[6])[1];
f_14447(t2,((C_word*)t0)[5],((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k15031 in k15028 in k15022 in k14762 in k14708 in lp in sre->nfa in k4869 */
static void C_ccall f_15033(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15033,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_15039,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_u_i_caar(((C_word*)t0)[2]);
t4=(C_word)C_eqp(lf[91],t3);
if(C_truep(t4)){
t5=(C_word)C_u_i_car(t1);
t6=(C_word)C_u_i_caar(((C_word*)t0)[4]);
t7=(C_word)C_a_i_cons(&a,2,lf[83],t6);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_15088,a[2]=t5,a[3]=t2,a[4]=t7,tmp=(C_word)a,a+=5,tmp);
t9=(C_word)C_u_i_cdar(t1);
/* ##sys#append */
t10=*((C_word*)lf[84]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t8,t9,C_SCHEME_END_OF_LIST);}
else{
t5=t2;
f_15039(t5,C_SCHEME_UNDEFINED);}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k15086 in k15031 in k15028 in k15022 in k14762 in k14708 in lp in sre->nfa in k4869 */
static void C_ccall f_15088(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15088,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
f_15039(t3,(C_word)C_i_setslot(((C_word*)t0)[2],C_fix(1),t2));}

/* k15037 in k15031 in k15028 in k15022 in k14762 in k14708 in lp in sre->nfa in k4869 */
static void C_fcall f_15039(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_15039,NULL,2,t0,t1);}
t2=(C_word)C_u_i_car(((C_word*)t0)[4]);
t3=(C_word)C_u_i_caar(((C_word*)t0)[3]);
t4=(C_word)C_a_i_cons(&a,2,lf[83],t3);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_15058,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_u_i_cdar(((C_word*)t0)[4]);
/* ##sys#append */
t7=*((C_word*)lf[84]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,C_SCHEME_END_OF_LIST);}

/* k15056 in k15037 in k15031 in k15028 in k15022 in k14762 in k14708 in lp in sre->nfa in k4869 */
static void C_ccall f_15058(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15058,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_i_setslot(((C_word*)t0)[4],C_fix(1),t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[2]);}

/* k14962 in k14762 in k14708 in lp in sre->nfa in k4869 */
static void C_ccall f_14964(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14964,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_14970,a[2]=((C_word*)t0)[6],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_u_i_cdar(((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_15008,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* new-state-number2665 */
t5=((C_word*)t0)[2];
f_14450(t5,t4,t1);}
else{
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k15006 in k14962 in k14762 in k14708 in lp in sre->nfa in k4869 */
static void C_ccall f_15008(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp2659 */
t2=((C_word*)((C_word*)t0)[6])[1];
f_14447(t2,((C_word*)t0)[5],((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k14968 in k14962 in k14762 in k14708 in lp in sre->nfa in k4869 */
static void C_ccall f_14970(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14970,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_u_i_car(t1);
t3=(C_word)C_u_i_caar(((C_word*)t0)[3]);
t4=(C_word)C_a_i_cons(&a,2,lf[83],t3);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_14992,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_u_i_cdar(t1);
/* ##sys#append */
t7=*((C_word*)lf[84]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,C_SCHEME_END_OF_LIST);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k14990 in k14968 in k14962 in k14762 in k14708 in lp in sre->nfa in k4869 */
static void C_ccall f_14992(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14992,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_i_setslot(((C_word*)t0)[4],C_fix(1),t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[2]);}

/* k14859 in k14762 in k14708 in lp in sre->nfa in k4869 */
static void C_ccall f_14861(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14861,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_14864,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t1)){
t3=(C_word)C_u_i_cddar(((C_word*)t0)[4]);
t4=f_13416(C_a_i(&a,3),t3);
t5=(C_word)C_a_i_list(&a,1,t4);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_14943,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t5,a[5]=t2,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* new-state-number2665 */
t7=((C_word*)t0)[5];
f_14450(t7,t6,t1);}
else{
t3=t2;
f_14864(2,t3,C_SCHEME_FALSE);}}

/* k14941 in k14859 in k14762 in k14708 in lp in sre->nfa in k4869 */
static void C_ccall f_14943(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp2659 */
t2=((C_word*)((C_word*)t0)[6])[1];
f_14447(t2,((C_word*)t0)[5],((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k14862 in k14859 in k14762 in k14708 in lp in sre->nfa in k4869 */
static void C_ccall f_14864(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14864,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_14867,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t1)){
t3=(C_word)C_u_i_cadar(((C_word*)t0)[4]);
t4=(C_word)C_a_i_list(&a,1,t3);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_14928,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[2],a[4]=t4,a[5]=t2,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* new-state-number2665 */
t6=((C_word*)t0)[5];
f_14450(t6,t5,t1);}
else{
t3=t2;
f_14867(2,t3,C_SCHEME_FALSE);}}

/* k14926 in k14862 in k14859 in k14762 in k14708 in lp in sre->nfa in k4869 */
static void C_ccall f_14928(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp2659 */
t2=((C_word*)((C_word*)t0)[6])[1];
f_14447(t2,((C_word*)t0)[5],((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k14865 in k14862 in k14859 in k14762 in k14708 in lp in sre->nfa in k4869 */
static void C_ccall f_14867(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14867,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_14893,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* new-state-number2665 */
t3=((C_word*)t0)[2];
f_14450(t3,t2,t1);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k14891 in k14865 in k14862 in k14859 in k14762 in k14708 in lp in sre->nfa in k4869 */
static void C_ccall f_14893(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14893,2,t0,t1);}
t2=(C_word)C_u_i_caar(((C_word*)t0)[5]);
t3=(C_word)C_a_i_cons(&a,2,lf[83],t2);
t4=(C_word)C_u_i_caar(((C_word*)t0)[4]);
t5=(C_word)C_a_i_cons(&a,2,lf[83],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,t3,t6);
t8=(C_word)C_a_i_cons(&a,2,t1,t7);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_14881,a[2]=t8,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_14885,a[2]=((C_word*)t0)[4],a[3]=t9,tmp=(C_word)a,a+=4,tmp);
/* take-up-to */
f_5662(t10,((C_word*)t0)[5],((C_word*)t0)[2]);}

/* k14883 in k14891 in k14865 in k14862 in k14859 in k14762 in k14708 in lp in sre->nfa in k4869 */
static void C_ccall f_14885(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14885,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_14889,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* ##sys#append */
t3=*((C_word*)lf[84]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k14887 in k14883 in k14891 in k14865 in k14862 in k14859 in k14762 in k14708 in lp in sre->nfa in k4869 */
static void C_ccall f_14889(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[84]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k14879 in k14891 in k14865 in k14862 in k14859 in k14762 in k14708 in lp in sre->nfa in k4869 */
static void C_ccall f_14881(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14881,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k14850 in k14762 in k14708 in lp in sre->nfa in k4869 */
static void C_ccall f_14852(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14852,2,t0,t1);}
/* sre->cset */
f_18742(((C_word*)t0)[3],((C_word*)t0)[2],(C_word)C_a_i_list(&a,1,t1));}

/* k14765 in k14762 in k14708 in lp in sre->nfa in k4869 */
static void C_ccall f_14767(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14767,2,t0,t1);}
t2=(C_word)C_i_length(t1);
t3=(C_word)C_eqp(t2,C_fix(1));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_14783,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_slot(((C_word*)t0)[7],C_fix(1));
/* lp2659 */
t6=((C_word*)((C_word*)t0)[6])[1];
f_14447(t6,t4,t5,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_14794,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_slot(((C_word*)t0)[7],C_fix(1));
/* lp2659 */
t6=((C_word*)((C_word*)t0)[6])[1];
f_14447(t6,t4,t5,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);}}

/* k14792 in k14765 in k14762 in k14708 in lp in sre->nfa in k4869 */
static void C_ccall f_14794(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14794,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_14820,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_14822,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a14821 in k14792 in k14765 in k14762 in k14708 in lp in sre->nfa in k4869 */
static void C_ccall f_14822(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_14822,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_slot(t2,C_fix(1));
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,3,lf[31],t3,t4));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k14818 in k14792 in k14765 in k14762 in k14708 in lp in sre->nfa in k4869 */
static void C_ccall f_14820(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14820,2,t0,t1);}
t2=f_13416(C_a_i(&a,3),t1);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_14808,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* new-state-number2665 */
t5=((C_word*)t0)[2];
f_14450(t5,t4,((C_word*)t0)[4]);}

/* k14806 in k14818 in k14792 in k14765 in k14762 in k14708 in lp in sre->nfa in k4869 */
static void C_ccall f_14808(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14808,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_14812,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* flag-clear */
t3=lf[55];
f_6144(4,t3,t2,((C_word*)t0)[2],C_fix(2));}

/* k14810 in k14806 in k14818 in k14792 in k14765 in k14762 in k14708 in lp in sre->nfa in k4869 */
static void C_ccall f_14812(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp2659 */
t2=((C_word*)((C_word*)t0)[6])[1];
f_14447(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k14781 in k14765 in k14762 in k14708 in lp in sre->nfa in k4869 */
static void C_ccall f_14783(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14783,2,t0,t1);}
t2=(C_word)C_u_i_car(((C_word*)t0)[4]);
/* extend-state2666 */
t3=((C_word*)t0)[3];
f_14464(t3,((C_word*)t0)[2],t1,(C_word)C_a_i_list(&a,1,t2));}

/* k14711 in k14708 in lp in sre->nfa in k4869 */
static void C_ccall f_14713(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14713,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_14716,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_u_i_caar(((C_word*)t0)[6]);
t4=(C_word)C_u_i_memq(t3,lf[276]);
t5=(C_truep(t4)?C_fix(2):C_fix(32));
t6=(C_word)C_u_i_caar(((C_word*)t0)[6]);
t7=(C_word)C_u_i_memq(t6,lf[277]);
t8=(C_truep(t7)?lf[55]:lf[54]);
t9=t8;
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t2,((C_word*)t0)[2],t5);}

/* k14714 in k14711 in k14708 in lp in sre->nfa in k4869 */
static void C_ccall f_14716(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14716,2,t0,t1);}
if(C_truep(((C_word*)t0)[6])){
t2=(C_word)C_u_i_cdar(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_14730,a[2]=((C_word*)t0)[6],a[3]=t1,a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* new-state-number2665 */
t4=((C_word*)t0)[2];
f_14450(t4,t3,((C_word*)t0)[6]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k14728 in k14714 in k14711 in k14708 in lp in sre->nfa in k4869 */
static void C_ccall f_14730(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp2659 */
t2=((C_word*)((C_word*)t0)[6])[1];
f_14447(t2,((C_word*)t0)[5],((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k14691 in lp in sre->nfa in k4869 */
static void C_ccall f_14693(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp2659 */
t2=((C_word*)((C_word*)t0)[6])[1];
f_14447(t2,((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k14668 in lp in sre->nfa in k4869 */
static void C_ccall f_14670(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14670,2,t0,t1);}
t2=f_13416(C_a_i(&a,3),t1);
t3=(C_word)C_slot(((C_word*)t0)[7],C_fix(1));
t4=(C_word)C_a_i_cons(&a,2,t2,t3);
/* lp2659 */
t5=((C_word*)((C_word*)t0)[6])[1];
f_14447(t5,((C_word*)t0)[5],t4,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k14591 in lp in sre->nfa in k4869 */
static void C_ccall f_14593(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_u_i_car(((C_word*)t0)[4]);
t3=(C_word)C_i_eqvp(t2,((C_word*)t0)[3]);
t4=((C_word*)t0)[2];
f_14560(t4,(C_word)C_i_not(t3));}
else{
t2=((C_word*)t0)[2];
f_14560(t2,C_SCHEME_FALSE);}}

/* k14558 in lp in sre->nfa in k4869 */
static void C_fcall f_14560(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_14560,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_14567,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_slot(((C_word*)t0)[9],C_fix(1));
/* lp2659 */
t4=((C_word*)((C_word*)t0)[5])[1];
f_14447(t4,t2,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_14582,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_slot(((C_word*)t0)[9],C_fix(1));
/* lp2659 */
t4=((C_word*)((C_word*)t0)[5])[1];
f_14447(t4,t2,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k14580 in k14558 in lp in sre->nfa in k4869 */
static void C_ccall f_14582(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14582,2,t0,t1);}
t2=(C_word)C_u_i_car(((C_word*)t0)[4]);
/* extend-state2666 */
t3=((C_word*)t0)[3];
f_14464(t3,((C_word*)t0)[2],t1,(C_word)C_a_i_list(&a,1,t2));}

/* k14565 in k14558 in lp in sre->nfa in k4869 */
static void C_ccall f_14567(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14567,2,t0,t1);}
t2=(C_word)C_u_i_car(((C_word*)t0)[5]);
/* extend-state2666 */
t3=((C_word*)t0)[4];
f_14464(t3,((C_word*)t0)[3],t1,(C_word)C_a_i_list(&a,2,t2,((C_word*)t0)[2]));}

/* k14535 in lp in sre->nfa in k4869 */
static void C_ccall f_14537(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14537,2,t0,t1);}
t2=(C_word)C_u_i_car(((C_word*)t0)[4]);
/* extend-state2666 */
t3=((C_word*)t0)[3];
f_14464(t3,((C_word*)t0)[2],t1,(C_word)C_a_i_list(&a,1,t2));}

/* k14514 in lp in sre->nfa in k4869 */
static void C_ccall f_14516(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* append */
t3=*((C_word*)lf[125]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t1,t2);}

/* k14510 in lp in sre->nfa in k4869 */
static void C_ccall f_14512(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp2659 */
t2=((C_word*)((C_word*)t0)[6])[1];
f_14447(t2,((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* extend-state in lp in sre->nfa in k4869 */
static void C_fcall f_14464(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_14464,NULL,4,t0,t1,t2,t3);}
if(C_truep(t2)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_14479,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* new-state-number2665 */
t5=((C_word*)t0)[2];
f_14450(t5,t4,t2);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k14477 in extend-state in lp in sre->nfa in k4869 */
static void C_ccall f_14479(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14479,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_14483,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_14485,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* map */
t4=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a14484 in k14477 in extend-state in lp in sre->nfa in k4869 */
static void C_ccall f_14485(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_14485,3,t0,t1,t2);}
t3=(C_word)C_u_i_caar(((C_word*)t0)[2]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,t2,t3));}

/* k14481 in k14477 in extend-state in lp in sre->nfa in k4869 */
static void C_ccall f_14483(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14483,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[2]));}

/* new-state-number in lp in sre->nfa in k4869 */
static void C_fcall f_14450(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_14450,NULL,3,t0,t1,t2);}
t3=(C_word)C_u_i_caar(t2);
t4=(C_word)C_a_i_plus(&a,2,C_fix(1),t3);
/* max */
t5=*((C_word*)lf[211]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,((C_word*)t0)[2],t4);}

/* dfa-match/longest in k4869 */
static void C_fcall f_14322(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_14322,NULL,5,t1,t2,t3,t4,t5);}
t6=f_14211(t2);
t7=f_14211(t2);
t8=f_14227(t7);
t9=(C_truep(t8)?t4:C_SCHEME_FALSE);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_14336,a[2]=t11,a[3]=t2,a[4]=t3,a[5]=t5,tmp=(C_word)a,a+=6,tmp));
t13=((C_word*)t11)[1];
f_14336(t13,t1,t4,t6,t9);}

/* lp in dfa-match/longest in k4869 */
static void C_fcall f_14336(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_14336,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_greater_or_equalp(t2,((C_word*)t0)[5]))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(C_word)C_subchar(((C_word*)t0)[4],t2);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_14349,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t4,a[5]=t2,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_14374,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_slot(t3,C_fix(1));
/* find */
f_5705(t6,t7,t8);}}

/* a14373 in lp in dfa-match/longest in k4869 */
static void C_ccall f_14374(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_14374,3,t0,t1,t2);}
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_i_eqvp(((C_word*)t0)[2],t3);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(C_word)C_u_i_car(t2);
if(C_truep((C_word)C_i_pairp(t5))){
t6=(C_word)C_u_i_caar(t2);
if(C_truep((C_word)C_fixnum_less_or_equal_p(t6,((C_word*)t0)[2]))){
t7=(C_word)C_u_i_cdar(t2);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_fixnum_less_or_equal_p(((C_word*)t0)[2],t7));}
else{
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_SCHEME_FALSE);}}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}}

/* k14347 in lp in dfa-match/longest in k4869 */
static void C_ccall f_14349(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14349,2,t0,t1);}
if(C_truep(t1)){
t2=f_14217(((C_word*)t0)[6],t1);
t3=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[5],C_fix(1));
t4=f_14227(t2);
t5=(C_truep(t4)?(C_word)C_a_i_plus(&a,2,((C_word*)t0)[5],C_fix(1)):((C_word*)t0)[4]);
/* lp2621 */
t6=((C_word*)((C_word*)t0)[3])[1];
f_14336(t6,((C_word*)t0)[2],t3,t2,t5);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[4]);}}

/* dfa-final-state? in k4869 */
static C_word C_fcall f_14227(C_word t1){
C_word tmp;
C_word t2;
return((C_word)C_u_i_car(t1));}

/* dfa-next-state in k4869 */
static C_word C_fcall f_14217(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
t3=(C_word)C_slot(t2,C_fix(1));
return((C_word)C_slot(t1,t3));}

/* dfa-init-state in k4869 */
static C_word C_fcall f_14211(C_word t1){
C_word tmp;
C_word t2;
return((C_word)C_slot(t1,C_fix(0)));}

/* irregex-match in k4869 */
static void C_ccall f_14144(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_14144,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_14148,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* irregex */
t5=*((C_word*)lf[179]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k14146 in irregex-match in k4869 */
static void C_ccall f_14148(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14148,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_14151,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* irregex-new-matches */
t3=*((C_word*)lf[11]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}

/* k14149 in k14146 in irregex-match in k4869 */
static void C_ccall f_14151(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14151,2,t0,t1);}
t2=(C_word)C_fix((C_word)C_header_size(((C_word*)t0)[4]));
t3=f_5085(t1,((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_14163,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* irregex-dfa */
t5=*((C_word*)lf[3]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[2]);}

/* k14161 in k14149 in k14146 in irregex-match in k4869 */
static void C_ccall f_14163(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14163,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_14166,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_14188,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* irregex-dfa */
t4=*((C_word*)lf[3]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_14191,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* irregex-nfa */
t3=*((C_word*)lf[6]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}}

/* k14189 in k14161 in k14149 in k14146 in irregex-match in k4869 */
static void C_ccall f_14191(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14191,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_14194,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_14208,tmp=(C_word)a,a+=2,tmp);
/* matcher2553 */
t4=t1;
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t2,((C_word*)t0)[2],C_fix(0),((C_word*)t0)[4],t3);}

/* a14207 in k14189 in k14161 in k14149 in k14146 in irregex-match in k4869 */
static void C_ccall f_14208(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14208,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* k14192 in k14189 in k14161 in k14149 in k14146 in irregex-match in k4869 */
static void C_ccall f_14194(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14194,2,t0,t1);}
if(C_truep((C_word)C_i_equalp(t1,((C_word*)t0)[4]))){
t2=f_5119(C_a_i(&a,8),((C_word*)t0)[3],C_fix(0),C_fix(0));
t3=f_5133(C_a_i(&a,8),((C_word*)t0)[3],C_fix(0),t1);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[3]);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k14186 in k14161 in k14149 in k14146 in irregex-match in k4869 */
static void C_ccall f_14188(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* dfa-match/longest */
f_14322(((C_word*)t0)[4],t1,((C_word*)t0)[3],C_fix(0),((C_word*)t0)[2]);}

/* k14164 in k14161 in k14149 in k14146 in irregex-match in k4869 */
static void C_ccall f_14166(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14166,2,t0,t1);}
if(C_truep((C_word)C_i_equalp(t1,((C_word*)t0)[6]))){
t2=f_5119(C_a_i(&a,8),((C_word*)t0)[5],C_fix(0),C_fix(0));
t3=f_5133(C_a_i(&a,8),((C_word*)t0)[5],C_fix(0),t1);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_14181,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_14184,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* irregex-dfa/extract */
t6=*((C_word*)lf[5]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k14182 in k14164 in k14161 in k14149 in k14146 in irregex-match in k4869 */
static void C_ccall f_14184(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[5],((C_word*)t0)[4],C_fix(0),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k14179 in k14164 in k14161 in k14149 in k14146 in irregex-match in k4869 */
static void C_ccall f_14181(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* irregex-search/matches in k4869 */
static void C_ccall f_13985(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr7,(void*)f_13985,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_13992,a[2]=t5,a[3]=t2,a[4]=t3,a[5]=t1,a[6]=t4,a[7]=t6,tmp=(C_word)a,a+=8,tmp);
/* irregex-dfa */
t8=*((C_word*)lf[3]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}

/* k13990 in irregex-search/matches in k4869 */
static void C_ccall f_13992(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13992,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_13998,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_14105,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* irregex-flags */
t4=*((C_word*)lf[7]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_14108,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
/* irregex-nfa */
t3=*((C_word*)lf[6]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}}

/* k14106 in k13990 in irregex-search/matches in k4869 */
static void C_ccall f_14108(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14108,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_14113,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_14113(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* lp in k14106 in k13990 in irregex-search/matches in k4869 */
static void C_fcall f_14113(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_14113,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_less_or_equalp(t2,((C_word*)t0)[6]))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_14123,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=t2,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_14141,tmp=(C_word)a,a+=2,tmp);
/* matcher2497 */
t5=((C_word*)t0)[3];
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t3,((C_word*)t0)[2],t2,((C_word*)t0)[5],t4);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* a14140 in lp in k14106 in k13990 in irregex-search/matches in k4869 */
static void C_ccall f_14141(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14141,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* k14121 in lp in k14106 in k13990 in irregex-search/matches in k4869 */
static void C_ccall f_14123(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14123,2,t0,t1);}
if(C_truep(t1)){
t2=f_5119(C_a_i(&a,8),((C_word*)t0)[5],C_fix(0),((C_word*)t0)[4]);
t3=f_5133(C_a_i(&a,8),((C_word*)t0)[5],C_fix(0),t1);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[5]);}
else{
t2=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[4],C_fix(1));
/* lp2499 */
t3=((C_word*)((C_word*)t0)[2])[1];
f_14113(t3,((C_word*)t0)[3],t2);}}

/* k14103 in k13990 in irregex-search/matches in k4869 */
static void C_ccall f_14105(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* flag-set? */
f_6125(((C_word*)t0)[2],t1,C_fix(1));}

/* k13996 in k13990 in irregex-search/matches in k4869 */
static void C_ccall f_13998(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13998,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_14001,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_14020,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* irregex-dfa */
t4=*((C_word*)lf[3]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_14023,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_14101,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* irregex-dfa/search */
t4=*((C_word*)lf[4]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[3]);}}

/* k14099 in k13996 in k13990 in irregex-search/matches in k4869 */
static void C_ccall f_14101(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14101,2,t0,t1);}
t2=((C_word*)t0)[5];
t3=((C_word*)t0)[4];
t4=((C_word*)t0)[3];
t5=f_14211(t1);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_14243,a[2]=t7,a[3]=t1,a[4]=t2,a[5]=t4,tmp=(C_word)a,a+=6,tmp));
t9=((C_word*)t7)[1];
f_14243(t9,((C_word*)t0)[2],t3,t5);}

/* lp in k14099 in k13996 in k13990 in irregex-search/matches in k4869 */
static void C_fcall f_14243(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_14243,NULL,4,t0,t1,t2,t3);}
t4=f_14227(t3);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t2);}
else{
if(C_truep((C_word)C_i_lessp(t2,((C_word*)t0)[5]))){
t5=(C_word)C_subchar(((C_word*)t0)[4],t2);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_14262,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_14278,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_slot(t3,C_fix(1));
/* find */
f_5705(t6,t7,t8);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}}

/* a14277 in lp in k14099 in k13996 in k13990 in irregex-search/matches in k4869 */
static void C_ccall f_14278(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_14278,3,t0,t1,t2);}
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_i_eqvp(((C_word*)t0)[2],t3);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(C_word)C_u_i_car(t2);
if(C_truep((C_word)C_i_pairp(t5))){
t6=(C_word)C_u_i_caar(t2);
if(C_truep((C_word)C_fixnum_less_or_equal_p(t6,((C_word*)t0)[2]))){
t7=(C_word)C_u_i_cdar(t2);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_fixnum_less_or_equal_p(((C_word*)t0)[2],t7));}
else{
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_SCHEME_FALSE);}}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}}

/* k14260 in lp in k14099 in k13996 in k13990 in irregex-search/matches in k4869 */
static void C_ccall f_14262(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14262,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[5],C_fix(1));
t3=f_14217(((C_word*)t0)[4],t1);
/* lp2586 */
t4=((C_word*)((C_word*)t0)[3])[1];
f_14243(t4,((C_word*)t0)[2],t2,t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k14021 in k13996 in k13990 in irregex-search/matches in k4869 */
static void C_ccall f_14023(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14023,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_14097,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
/* irregex-lengths */
t3=*((C_word*)lf[9]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k14095 in k14021 in k13996 in k13990 in irregex-search/matches in k4869 */
static void C_ccall f_14097(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14097,2,t0,t1);}
t2=(C_word)C_slot(t1,C_fix(0));
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_14032,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_slot(t2,C_fix(1)))){
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_a_i_minus(&a,2,((C_word*)t0)[8],t4);
/* max */
t6=*((C_word*)lf[211]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,((C_word*)t0)[2],t5);}
else{
t4=t3;
f_14032(2,t4,((C_word*)t0)[2]);}}

/* k14030 in k14095 in k14021 in k13996 in k13990 in irregex-search/matches in k4869 */
static void C_ccall f_14032(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14032,2,t0,t1);}
t2=(C_word)C_u_i_car(((C_word*)t0)[8]);
t3=(C_word)C_a_i_minus(&a,2,((C_word*)t0)[7],t2);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_14038,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t3,tmp=(C_word)a,a+=9,tmp);
/* irregex-dfa */
t5=*((C_word*)lf[3]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[4]);}

/* k14036 in k14030 in k14095 in k14021 in k13996 in k13990 in irregex-search/matches in k4869 */
static void C_ccall f_14038(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14038,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_14043,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp));
t5=((C_word*)t3)[1];
f_14043(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* lp in k14036 in k14030 in k14095 in k14021 in k13996 in k13990 in irregex-search/matches in k4869 */
static void C_fcall f_14043(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_14043,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_less_or_equalp(t2,((C_word*)t0)[8]))){
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_14053,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t1,a[6]=t2,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* dfa-match/longest */
f_14322(t3,((C_word*)t0)[3],((C_word*)t0)[6],t2,((C_word*)t0)[2]);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k14051 in lp in k14036 in k14030 in k14095 in k14021 in k13996 in k13990 in irregex-search/matches in k4869 */
static void C_ccall f_14053(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14053,2,t0,t1);}
if(C_truep(t1)){
t2=f_5119(C_a_i(&a,8),((C_word*)t0)[7],C_fix(0),((C_word*)t0)[6]);
t3=f_5133(C_a_i(&a,8),((C_word*)t0)[7],C_fix(0),t1);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_14065,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_14068,a[2]=((C_word*)t0)[7],a[3]=t1,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],a[6]=t4,tmp=(C_word)a,a+=7,tmp);
/* irregex-dfa/extract */
t6=*((C_word*)lf[5]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[3]);}
else{
t2=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[6],C_fix(1));
/* lp2477 */
t3=((C_word*)((C_word*)t0)[2])[1];
f_14043(t3,((C_word*)t0)[5],t2);}}

/* k14066 in k14051 in lp in k14036 in k14030 in k14095 in k14021 in k13996 in k13990 in irregex-search/matches in k4869 */
static void C_ccall f_14068(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k14063 in k14051 in lp in k14036 in k14030 in k14095 in k14021 in k13996 in k13990 in irregex-search/matches in k4869 */
static void C_ccall f_14065(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k14018 in k13996 in k13990 in irregex-search/matches in k4869 */
static void C_ccall f_14020(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* dfa-match/longest */
f_14322(((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k13999 in k13996 in k13990 in irregex-search/matches in k4869 */
static void C_ccall f_14001(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14001,2,t0,t1);}
if(C_truep(t1)){
t2=f_5119(C_a_i(&a,8),((C_word*)t0)[6],C_fix(0),((C_word*)t0)[5]);
t3=f_5133(C_a_i(&a,8),((C_word*)t0)[6],C_fix(0),t1);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_14013,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_14016,a[2]=((C_word*)t0)[6],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],a[6]=t4,tmp=(C_word)a,a+=7,tmp);
/* irregex-dfa/extract */
t6=*((C_word*)lf[5]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k14014 in k13999 in k13996 in k13990 in irregex-search/matches in k4869 */
static void C_ccall f_14016(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k14011 in k13999 in k13996 in k13990 in irregex-search/matches in k4869 */
static void C_ccall f_14013(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* irregex-search in k4869 */
static void C_ccall f_13939(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_13939r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_13939r(t0,t1,t2,t3,t4);}}

static void C_ccall f_13939r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_13943,a[2]=t1,a[3]=t3,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* irregex */
t6=*((C_word*)lf[179]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k13941 in irregex-search in k4869 */
static void C_ccall f_13943(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13943,2,t0,t1);}
t2=(C_word)C_i_pairp(((C_word*)t0)[4]);
t3=(C_truep(t2)?(C_word)C_u_i_car(((C_word*)t0)[4]):C_fix(0));
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_13961,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
t5=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t6=t4;
f_13961(t6,(C_word)C_i_pairp(t5));}
else{
t5=t4;
f_13961(t5,C_SCHEME_FALSE);}}

/* k13959 in k13941 in irregex-search in k4869 */
static void C_fcall f_13961(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_13961,NULL,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_u_i_cadr(((C_word*)t0)[6]):(C_word)C_fix((C_word)C_header_size(((C_word*)t0)[5])));
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_13952,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* irregex-new-matches */
t4=*((C_word*)lf[11]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[3]);}

/* k13950 in k13959 in k13941 in irregex-search in k4869 */
static void C_ccall f_13952(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=f_5085(t1,((C_word*)t0)[6]);
/* irregex-search/matches */
t3=*((C_word*)lf[242]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[6],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* sre-remove-initial-bos in k4869 */
static void C_ccall f_13822(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_13822,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_eqp(t3,lf[82]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_13841,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t4)){
t6=t5;
f_13841(t6,t4);}
else{
t6=(C_word)C_eqp(t3,lf[186]);
if(C_truep(t6)){
t7=t5;
f_13841(t7,t6);}
else{
t7=(C_word)C_eqp(t3,lf[76]);
if(C_truep(t7)){
t8=t5;
f_13841(t8,t7);}
else{
t8=(C_word)C_eqp(t3,lf[91]);
t9=t5;
f_13841(t9,(C_truep(t8)?t8:(C_word)C_eqp(t3,lf[93])));}}}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k13839 in sre-remove-initial-bos in k4869 */
static void C_fcall f_13841(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_13841,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_u_i_cadr(((C_word*)t0)[4]);
t4=(C_word)C_eqp(lf[151],t3);
if(C_truep(t4)){
t5=(C_word)C_u_i_car(((C_word*)t0)[4]);
t6=(C_word)C_u_i_cddr(((C_word*)t0)[4]);
t7=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_cons(&a,2,t5,t6));}
else{
t5=(C_word)C_u_i_car(((C_word*)t0)[4]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_13879,a[2]=t5,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_u_i_cadr(((C_word*)t0)[4]);
/* sre-remove-initial-bos */
t8=lf[231];
f_13822(3,t8,t6,t7);}}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[4]);}}
else{
t2=(C_word)C_eqp(((C_word*)t0)[2],lf[70]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13912,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* map */
t5=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,lf[231],t4);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[4]);}}}

/* k13910 in k13839 in sre-remove-initial-bos in k4869 */
static void C_ccall f_13912(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13912,2,t0,t1);}
/* sre-alternate */
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,f_13416(C_a_i(&a,3),t1));}

/* k13877 in k13839 in sre-remove-initial-bos in k4869 */
static void C_ccall f_13879(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13879,2,t0,t1);}
t2=(C_word)C_u_i_cddr(((C_word*)t0)[4]);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* sre-sequence-names in k4869 */
static void C_fcall f_13786(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_13786,NULL,4,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(C_word)C_slot(t2,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_13816,a[2]=t4,a[3]=t2,a[4]=t5,a[5]=t1,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
t7=(C_word)C_u_i_car(t2);
/* sre-count-submatches */
f_12296(t6,t7);}}

/* k13814 in sre-sequence-names in k4869 */
static void C_ccall f_13816(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13816,2,t0,t1);}
t2=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[6],t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_13808,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_u_i_car(((C_word*)t0)[3]);
/* sre-names */
f_13556(t3,t4,((C_word*)t0)[6],((C_word*)t0)[2]);}

/* k13806 in k13814 in sre-sequence-names in k4869 */
static void C_ccall f_13808(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* sre-sequence-names */
f_13786(((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* sre-names in k4869 */
static void C_fcall f_13556(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word *a;
loop:
a=C_alloc(13);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_13556,NULL,4,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_pairp(t2))){
t5=(C_word)C_u_i_car(t2);
t6=(C_word)C_eqp(t5,lf[76]);
if(C_truep(t6)){
t7=(C_word)C_slot(t2,C_fix(1));
t8=f_13391(C_a_i(&a,3),t7);
t9=(C_word)C_a_i_plus(&a,2,t3,C_fix(1));
/* sre-names */
t38=t1;
t39=t8;
t40=t9;
t41=t4;
t1=t38;
t2=t39;
t3=t40;
t4=t41;
goto loop;}
else{
t7=(C_word)C_eqp(t5,lf[85]);
if(C_truep(t7)){
t8=(C_word)C_u_i_cddr(t2);
t9=f_13391(C_a_i(&a,3),t8);
t10=(C_word)C_a_i_plus(&a,2,t3,C_fix(1));
t11=(C_word)C_u_i_cadr(t2);
t12=(C_word)C_a_i_cons(&a,2,t11,t3);
t13=(C_word)C_a_i_cons(&a,2,t12,t4);
/* sre-names */
t38=t1;
t39=t9;
t40=t10;
t41=t13;
t1=t38;
t2=t39;
t3=t40;
t4=t41;
goto loop;}
else{
t8=(C_word)C_eqp(t5,lf[202]);
if(C_truep(t8)){
t9=(C_word)C_u_i_cdddr(t2);
t10=f_13391(C_a_i(&a,3),t9);
t11=(C_word)C_u_i_cadr(t2);
t12=(C_word)C_a_i_plus(&a,2,t3,t11);
/* sre-names */
t38=t1;
t39=t10;
t40=t12;
t41=t4;
t1=t38;
t2=t39;
t3=t40;
t4=t41;
goto loop;}
else{
t9=(C_word)C_eqp(t5,lf[82]);
t10=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_13654,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t1,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t9)){
t11=t10;
f_13654(t11,t9);}
else{
t11=(C_word)C_eqp(t5,lf[186]);
if(C_truep(t11)){
t12=t10;
f_13654(t12,t11);}
else{
t12=(C_word)C_eqp(t5,lf[70]);
if(C_truep(t12)){
t13=t10;
f_13654(t13,t12);}
else{
t13=(C_word)C_eqp(t5,lf[91]);
if(C_truep(t13)){
t14=t10;
f_13654(t14,t13);}
else{
t14=(C_word)C_eqp(t5,lf[93]);
if(C_truep(t14)){
t15=t10;
f_13654(t15,t14);}
else{
t15=(C_word)C_eqp(t5,lf[95]);
if(C_truep(t15)){
t16=t10;
f_13654(t16,t15);}
else{
t16=(C_word)C_eqp(t5,lf[92]);
if(C_truep(t16)){
t17=t10;
f_13654(t17,t16);}
else{
t17=(C_word)C_eqp(t5,lf[96]);
if(C_truep(t17)){
t18=t10;
f_13654(t18,t17);}
else{
t18=(C_word)C_eqp(t5,lf[184]);
if(C_truep(t18)){
t19=t10;
f_13654(t19,t18);}
else{
t19=(C_word)C_eqp(t5,lf[185]);
if(C_truep(t19)){
t20=t10;
f_13654(t20,t19);}
else{
t20=(C_word)C_eqp(t5,lf[197]);
if(C_truep(t20)){
t21=t10;
f_13654(t21,t20);}
else{
t21=(C_word)C_eqp(t5,lf[78]);
if(C_truep(t21)){
t22=t10;
f_13654(t22,t21);}
else{
t22=(C_word)C_eqp(t5,lf[80]);
if(C_truep(t22)){
t23=t10;
f_13654(t23,t22);}
else{
t23=(C_word)C_eqp(t5,lf[79]);
t24=t10;
f_13654(t24,(C_truep(t23)?t23:(C_word)C_eqp(t5,lf[81])));}}}}}}}}}}}}}}}}}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k13652 in sre-names in k4869 */
static void C_fcall f_13654(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
/* sre-sequence-names */
f_13786(((C_word*)t0)[5],t2,((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[2],lf[98]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(((C_word*)t0)[2],lf[99]));
if(C_truep(t3)){
t4=(C_word)C_u_i_cddr(((C_word*)t0)[6]);
/* sre-sequence-names */
f_13786(((C_word*)t0)[5],t4,((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[2],lf[97]);
t5=(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[2],lf[94]));
if(C_truep(t5)){
t6=(C_word)C_u_i_cdddr(((C_word*)t0)[6]);
/* sre-sequence-names */
f_13786(((C_word*)t0)[5],t6,((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t6=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,((C_word*)t0)[3]);}}}}

/* sre-strip-submatches in k4869 */
static void C_ccall f_13441(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(3);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)tr3,(void*)f_13441,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_eqp(t3,lf[76]);
if(C_truep(t4)){
t5=(C_word)C_slot(t2,C_fix(1));
t6=f_13391(C_a_i(&a,3),t5);
/* sre-strip-submatches */
t11=t1;
t12=t6;
t1=t11;
t2=t12;
c=3;
goto loop;}
else{
t5=(C_word)C_eqp(t3,lf[202]);
if(C_truep(t5)){
t6=(C_word)C_u_i_cdddr(t2);
t7=f_13391(C_a_i(&a,3),t6);
/* sre-strip-submatches */
t11=t1;
t12=t7;
t1=t11;
t2=t12;
c=3;
goto loop;}
else{
/* map */
t6=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t1,lf[189],t2);}}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* sre-alternate in k4869 */
static C_word C_fcall f_13416(C_word *a,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
if(C_truep((C_word)C_i_nullp(t1))){
return(lf[83]);}
else{
t2=(C_word)C_slot(t1,C_fix(1));
t3=(C_word)C_i_nullp(t2);
return((C_truep(t3)?(C_word)C_u_i_car(t1):(C_word)C_a_i_cons(&a,2,lf[70],t1)));}}

/* sre-sequence in k4869 */
static C_word C_fcall f_13391(C_word *a,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
if(C_truep((C_word)C_i_nullp(t1))){
return(lf[83]);}
else{
t2=(C_word)C_slot(t1,C_fix(1));
t3=(C_word)C_i_nullp(t2);
return((C_truep(t3)?(C_word)C_u_i_car(t1):(C_word)C_a_i_cons(&a,2,lf[82],t1)));}}

/* sre-count-submatches in k4869 */
static void C_fcall f_12296(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12296,NULL,2,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12302,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_12302(4,t6,t1,t2,C_fix(0));}

/* count in sre-count-submatches in k4869 */
static void C_ccall f_12302(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_12302,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_u_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_12327,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t2,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_eqp(t4,lf[76]);
t7=(C_truep(t6)?t6:(C_word)C_eqp(t4,lf[85]));
if(C_truep(t7)){
t8=t5;
f_12327(t8,C_fix(1));}
else{
t8=(C_word)C_eqp(t4,lf[202]);
if(C_truep(t8)){
t9=(C_word)C_u_i_cadr(t2);
t10=(C_word)C_u_i_caddr(t2);
t11=t5;
f_12327(t11,(C_word)C_a_i_plus(&a,2,t9,t10));}
else{
t9=t5;
f_12327(t9,C_fix(0));}}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k12325 in count in sre-count-submatches in k4869 */
static void C_fcall f_12327(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12327,NULL,2,t0,t1);}
t2=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* fold */
f_5889(((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t2,t3);}

/* sre-has-submatchs? in k4869 */
static void C_ccall f_12270(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_12270,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_eqp(lf[76],t3);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(C_word)C_slot(t2,C_fix(1));
/* any */
f_5791(t1,lf[228],t5);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* sre-consumer? in k4869 */
static void C_ccall f_12184(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_12184,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_eqp(t3,lf[91]);
t5=(C_truep(t4)?t4:(C_word)C_eqp(t3,lf[93]));
if(C_truep(t5)){
t6=(C_word)C_slot(t2,C_fix(1));
t7=f_13391(C_a_i(&a,3),t6);
/* sre-any? */
t8=lf[238];
f_11966(3,t8,t1,t7);}
else{
t6=(C_word)C_eqp(t3,lf[82]);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12223,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t6)){
t8=t7;
f_12223(t8,t6);}
else{
t8=(C_word)C_eqp(t3,lf[186]);
t9=t7;
f_12223(t9,(C_truep(t8)?t8:(C_word)C_eqp(t3,lf[76])));}}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_eqp(lf[152],t2));}}

/* k12221 in sre-consumer? in k4869 */
static void C_fcall f_12223(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12223,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12236,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* last */
f_5749(t3,((C_word*)t0)[4]);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}
else{
t2=(C_word)C_eqp(((C_word*)t0)[2],lf[70]);
if(C_truep(t2)){
t3=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* every */
f_5840(((C_word*)t0)[3],lf[210],t3);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}}

/* k12234 in k12221 in sre-consumer? in k4869 */
static void C_ccall f_12236(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* sre-consumer? */
t2=lf[210];
f_12184(3,t2,((C_word*)t0)[2],t1);}

/* sre-searcher? in k4869 */
static void C_ccall f_12098(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_12098,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_eqp(t3,lf[91]);
t5=(C_truep(t4)?t4:(C_word)C_eqp(t3,lf[93]));
if(C_truep(t5)){
t6=(C_word)C_slot(t2,C_fix(1));
t7=f_13391(C_a_i(&a,3),t6);
/* sre-any? */
t8=lf[238];
f_11966(3,t8,t1,t7);}
else{
t6=(C_word)C_eqp(t3,lf[82]);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12137,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t6)){
t8=t7;
f_12137(t8,t6);}
else{
t8=(C_word)C_eqp(t3,lf[186]);
t9=t7;
f_12137(t9,(C_truep(t8)?t8:(C_word)C_eqp(t3,lf[76])));}}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_eqp(lf[151],t2));}}

/* k12135 in sre-searcher? in k4869 */
static void C_fcall f_12137(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_u_i_cadr(((C_word*)t0)[4]);
/* sre-searcher? */
t4=lf[232];
f_12098(3,t4,((C_word*)t0)[3],t3);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}
else{
t2=(C_word)C_eqp(((C_word*)t0)[2],lf[70]);
if(C_truep(t2)){
t3=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* every */
f_5840(((C_word*)t0)[3],lf[232],t3);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}}

/* sre-repeater? in k4869 */
static C_word C_fcall f_12042(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
loop:
if(C_truep((C_word)C_i_pairp(t1))){
t2=(C_word)C_u_i_car(t1);
t3=(C_word)C_u_i_memq(t2,lf[239]);
if(C_truep(t3)){
return(t3);}
else{
t4=(C_word)C_u_i_car(t1);
if(C_truep((C_truep((C_word)C_eqp(t4,lf[76]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t4,lf[82]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t4,lf[186]))?C_SCHEME_TRUE:C_SCHEME_FALSE))))){
t5=(C_word)C_slot(t1,C_fix(1));
if(C_truep((C_word)C_i_pairp(t5))){
t6=(C_word)C_u_i_cddr(t1);
if(C_truep((C_word)C_i_nullp(t6))){
t7=(C_word)C_u_i_cadr(t1);
t9=t7;
t1=t9;
goto loop;}
else{
return(C_SCHEME_FALSE);}}
else{
return(C_SCHEME_FALSE);}}
else{
return(C_SCHEME_FALSE);}}}
else{
return(C_SCHEME_FALSE);}}

/* sre-any? in k4869 */
static void C_ccall f_11966(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11966,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,lf[88]);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_u_i_car(t2);
t5=(C_word)C_eqp(t4,lf[82]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11991,a[2]=t4,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t5)){
t7=t6;
f_11991(t7,t5);}
else{
t7=(C_word)C_eqp(t4,lf[186]);
t8=t6;
f_11991(t8,(C_truep(t7)?t7:(C_word)C_eqp(t4,lf[76])));}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}}

/* k11989 in sre-any? in k4869 */
static void C_fcall f_11991(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_u_i_cddr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_nullp(t3))){
t4=(C_word)C_u_i_cadr(((C_word*)t0)[4]);
/* sre-any? */
t5=lf[238];
f_11966(3,t5,((C_word*)t0)[3],t4);}
else{
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}
else{
t2=(C_word)C_eqp(((C_word*)t0)[2],lf[70]);
if(C_truep(t2)){
t3=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* every */
f_5840(((C_word*)t0)[3],lf[238],t3);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}}

/* sre-empty? in k4869 */
static void C_ccall f_11838(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11838,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_eqp(t3,lf[91]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11857,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t4)){
t6=t5;
f_11857(t6,t4);}
else{
t6=(C_word)C_eqp(t3,lf[95]);
if(C_truep(t6)){
t7=t5;
f_11857(t7,t6);}
else{
t7=(C_word)C_eqp(t3,lf[78]);
if(C_truep(t7)){
t8=t5;
f_11857(t8,t7);}
else{
t8=(C_word)C_eqp(t3,lf[80]);
if(C_truep(t8)){
t9=t5;
f_11857(t9,t8);}
else{
t9=(C_word)C_eqp(t3,lf[79]);
t10=t5;
f_11857(t10,(C_truep(t9)?t9:(C_word)C_eqp(t3,lf[81])));}}}}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_u_i_memq(t2,lf[237]));}}

/* k11855 in sre-empty? in k4869 */
static void C_fcall f_11857(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11857,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[3],lf[97]);
if(C_truep(t2)){
t3=(C_word)C_u_i_cadr(((C_word*)t0)[2]);
t4=(C_word)C_i_numberp(t3);
t5=(C_word)C_i_not(t4);
if(C_truep(t5)){
t6=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t6=(C_word)C_u_i_cadr(((C_word*)t0)[2]);
t7=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_i_zerop(t6));}}
else{
t3=(C_word)C_eqp(((C_word*)t0)[3],lf[70]);
if(C_truep(t3)){
t4=(C_word)C_slot(((C_word*)t0)[2],C_fix(1));
/* any */
f_5791(((C_word*)t0)[4],lf[103],t4);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[3],lf[186]);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11906,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t4)){
t6=t5;
f_11906(t6,t4);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[3],lf[82]);
if(C_truep(t6)){
t7=t5;
f_11906(t7,t6);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[3],lf[76]);
if(C_truep(t7)){
t8=t5;
f_11906(t8,t7);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[3],lf[93]);
t9=t5;
f_11906(t9,(C_truep(t8)?t8:(C_word)C_eqp(((C_word*)t0)[3],lf[197])));}}}}}}}

/* k11904 in k11855 in sre-empty? in k4869 */
static void C_fcall f_11906(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* every */
f_5840(((C_word*)t0)[2],lf[103],t2);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* sre->irregex in k4869 */
static void C_ccall f_11697(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_11697r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_11697r(t0,t1,t2,t3);}}

static void C_ccall f_11697r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11701,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* symbol-list->flags */
f_6163(t4,t3);}

/* k11699 in sre->irregex in k4869 */
static void C_ccall f_11701(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11701,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11704,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[2];
t4=t1;
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11384,a[2]=t4,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* flag-set? */
f_6125(t5,t4,C_fix(32));}

/* k11382 in k11699 in sre->irregex in k4869 */
static void C_ccall f_11384(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11384,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11388,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* flag-set? */
f_6125(t2,((C_word*)t0)[2],C_fix(2));}

/* k11386 in k11382 in k11699 in sre->irregex in k4869 */
static void C_ccall f_11388(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11388,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11390,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_11390(t5,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* adjust in k11386 in k11382 in k11699 in sre->irregex in k4869 */
static void C_fcall f_11390(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word *a;
loop:
a=C_alloc(13);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_11390,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11393,a[2]=t4,a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t6=(C_word)C_u_i_car(t2);
t7=(C_word)C_eqp(t6,lf[118]);
if(C_truep(t7)){
t8=(C_word)C_slot(t2,C_fix(1));
t9=f_13391(C_a_i(&a,3),t8);
/* adjust1508 */
t32=t1;
t33=t9;
t34=C_SCHEME_TRUE;
t35=t4;
t1=t32;
t2=t33;
t3=t34;
t4=t35;
goto loop;}
else{
t8=(C_word)C_eqp(t6,lf[119]);
if(C_truep(t8)){
t9=(C_word)C_slot(t2,C_fix(1));
t10=f_13391(C_a_i(&a,3),t9);
/* adjust1508 */
t32=t1;
t33=t10;
t34=C_SCHEME_FALSE;
t35=t4;
t1=t32;
t2=t33;
t3=t34;
t4=t35;
goto loop;}
else{
t9=(C_word)C_eqp(t6,lf[184]);
if(C_truep(t9)){
t10=(C_word)C_u_i_car(t2);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11457,a[2]=t10,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11459,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t13=(C_word)C_slot(t2,C_fix(1));
/* map */
t14=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t14+1)))(4,t14,t11,t12,t13);}
else{
t10=(C_word)C_eqp(t6,lf[185]);
if(C_truep(t10)){
t11=(C_word)C_u_i_car(t2);
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11484,a[2]=t11,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t13=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11486,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t14=(C_word)C_slot(t2,C_fix(1));
/* map */
t15=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t12,t13,t14);}
else{
t11=(C_word)C_eqp(t6,lf[31]);
t12=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11503,a[2]=t5,a[3]=t6,a[4]=t2,a[5]=t1,a[6]=t4,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
if(C_truep(t11)){
t13=t12;
f_11503(t13,t11);}
else{
t13=(C_word)C_eqp(t6,lf[124]);
if(C_truep(t13)){
t14=t12;
f_11503(t14,t13);}
else{
t14=(C_word)C_eqp(t6,lf[193]);
t15=t12;
f_11503(t15,(C_truep(t14)?t14:(C_word)C_eqp(t6,lf[204])));}}}}}}}
else{
t6=t2;
t7=(C_word)C_eqp(t6,lf[88]);
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,lf[235]);}
else{
t8=(C_word)C_eqp(t6,lf[89]);
if(C_truep(t8)){
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,lf[236]);}
else{
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11644,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t3)){
if(C_truep((C_word)C_charp(t2))){
/* high-char? */
t10=lf[128];
f_9937(3,t10,t9,t2);}
else{
t10=t9;
f_11644(2,t10,C_SCHEME_FALSE);}}
else{
t10=t9;
f_11644(2,t10,C_SCHEME_FALSE);}}}}}

/* k11642 in adjust in k11386 in k11382 in k11699 in sre->irregex in k4869 */
static void C_ccall f_11644(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11644,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11651,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11655,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* char->utf8-list */
f_10242(t3,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* k11653 in k11642 in adjust in k11386 in k11382 in k11699 in sre->irregex in k4869 */
static void C_ccall f_11655(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],*((C_word*)lf[174]+1),t1);}

/* k11649 in k11642 in adjust in k11386 in k11382 in k11699 in sre->irregex in k4869 */
static void C_ccall f_11651(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11651,2,t0,t1);}
/* sre-sequence */
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,f_13391(C_a_i(&a,3),t1));}

/* k11501 in adjust in k11386 in k11382 in k11699 in sre->irregex in k4869 */
static void C_fcall f_11503(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11503,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[7];
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11512,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* sre->cset */
f_18742(t3,((C_word*)t0)[4],(C_word)C_a_i_list(&a,1,((C_word*)t0)[6]));}
else{
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[4]);}}
else{
t2=(C_word)C_eqp(((C_word*)t0)[3],lf[91]);
if(C_truep(t2)){
t3=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t4=f_13391(C_a_i(&a,3),t3);
t5=(C_word)C_eqp(t4,lf[88]);
if(C_truep(t5)){
t6=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,lf[233]);}
else{
t6=(C_word)C_eqp(t4,lf[89]);
if(C_truep(t6)){
t7=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,lf[234]);}
else{
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11588,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* map */
t9=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t7,((C_word*)t0)[2],t8);}}}
else{
t3=(C_word)C_u_i_car(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11607,a[2]=t3,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* map */
t6=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,((C_word*)t0)[2],t5);}}}

/* k11605 in k11501 in adjust in k11386 in k11382 in k11699 in sre->irregex in k4869 */
static void C_ccall f_11607(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11607,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k11586 in k11501 in adjust in k11386 in k11382 in k11699 in sre->irregex in k4869 */
static void C_ccall f_11588(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11588,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[91],t1));}

/* k11510 in k11501 in adjust in k11386 in k11382 in k11699 in sre->irregex in k4869 */
static void C_ccall f_11512(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11512,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11518,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11533,tmp=(C_word)a,a+=2,tmp);
/* any */
f_5791(t2,t3,t1);}

/* a11532 in k11510 in k11501 in adjust in k11386 in k11382 in k11699 in sre->irregex in k4869 */
static void C_ccall f_11533(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11533,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11543,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_u_i_car(t2);
/* high-char? */
t5=lf[128];
f_9937(3,t5,t3,t4);}
else{
/* high-char? */
t3=lf[128];
f_9937(3,t3,t1,t2);}}

/* k11541 in a11532 in k11510 in k11501 in adjust in k11386 in k11382 in k11699 in sre->irregex in k4869 */
static void C_ccall f_11543(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_slot(((C_word*)t0)[2],C_fix(1));
/* high-char? */
t3=lf[128];
f_9937(3,t3,((C_word*)t0)[3],t2);}}

/* k11516 in k11510 in k11501 in adjust in k11386 in k11382 in k11699 in sre->irregex in k4869 */
static void C_ccall f_11518(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11518,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(((C_word*)t0)[5])){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11528,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* cset->utf8-pattern */
f_11216(t2,((C_word*)t0)[3]);}
else{
/* cset->utf8-pattern */
f_11216(((C_word*)t0)[4],((C_word*)t0)[3]);}}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* k11526 in k11516 in k11510 in k11501 in adjust in k11386 in k11382 in k11699 in sre->irregex in k4869 */
static void C_ccall f_11528(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11528,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,lf[184],t1));}

/* a11485 in adjust in k11386 in k11382 in k11699 in sre->irregex in k4869 */
static void C_ccall f_11486(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11486,3,t0,t1,t2);}
/* adjust1508 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_11390(t3,t1,t2,((C_word*)t0)[2],C_SCHEME_TRUE);}

/* k11482 in adjust in k11386 in k11382 in k11699 in sre->irregex in k4869 */
static void C_ccall f_11484(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11484,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* a11458 in adjust in k11386 in k11382 in k11699 in sre->irregex in k4869 */
static void C_ccall f_11459(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11459,3,t0,t1,t2);}
/* adjust1508 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_11390(t3,t1,t2,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k11455 in adjust in k11386 in k11382 in k11699 in sre->irregex in k4869 */
static void C_ccall f_11457(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11457,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* rec in adjust in k11386 in k11382 in k11699 in sre->irregex in k4869 */
static void C_ccall f_11393(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11393,3,t0,t1,t2);}
/* adjust1508 */
t3=((C_word*)((C_word*)t0)[4])[1];
f_11390(t3,t1,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_11704(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11704,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11707,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* sre-searcher? */
t3=lf[232];
f_12098(3,t3,t2,t1);}

/* k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_11707(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11707,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11710,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t1)){
/* sre-remove-initial-bos */
t3=lf[231];
f_13822(3,t3,t2,((C_word*)t0)[4]);}
else{
t3=t2;
f_11710(2,t3,((C_word*)t0)[4]);}}

/* k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_11710(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11710,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11713,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_u_i_memq(lf[229],((C_word*)t0)[2]))){
t3=t2;
f_11713(t3,C_fix(1));}
else{
t3=(C_word)C_u_i_memq(lf[230],((C_word*)t0)[2]);
t4=t2;
f_11713(t4,(C_truep(t3)?C_fix(50):C_fix(10)));}}

/* k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_fcall f_11713(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11713,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11716,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=t2;
f_11716(2,t3,C_SCHEME_TRUE);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11787,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_a_i_cons(&a,2,lf[88],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[91],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,t5,t6);
t8=(C_word)C_a_i_cons(&a,2,lf[82],t7);
/* sre->nfa */
f_14429(t3,t8,(C_word)C_a_i_list(&a,1,((C_word*)t0)[3]));}}

/* k11785 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_11787(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11787,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_length(t1);
t3=(C_word)C_a_i_times(&a,2,((C_word*)t0)[3],t2);
/* nfa->dfa */
f_15219(((C_word*)t0)[2],t1,(C_word)C_a_i_list(&a,1,t3));}
else{
t2=((C_word*)t0)[2];
f_11716(2,t2,C_SCHEME_FALSE);}}

/* k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_11716(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11716,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_11719,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t1)){
/* sre->nfa */
f_14429(t2,((C_word*)t0)[7],(C_word)C_a_i_list(&a,1,((C_word*)t0)[4]));}
else{
t3=t2;
f_11719(2,t3,C_SCHEME_FALSE);}}

/* k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_11719(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11719,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11722,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t1)){
t3=(C_word)C_i_length(t1);
t4=(C_word)C_a_i_times(&a,2,((C_word*)t0)[2],t3);
/* nfa->dfa */
f_15219(t2,t1,(C_word)C_a_i_list(&a,1,t4));}
else{
t3=t2;
f_11722(2,t3,C_SCHEME_FALSE);}}

/* k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_11722(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11722,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_11725,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t1)){
if(C_truep(((C_word*)t0)[5])){
t3=((C_word*)t0)[7];
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_16317,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_16317(t7,t2,t3,C_fix(1),C_SCHEME_FALSE);}
else{
t3=t2;
f_11725(2,t3,C_SCHEME_FALSE);}}
else{
t3=t2;
f_11725(2,t3,C_SCHEME_FALSE);}}

/* lp in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_fcall f_16317(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_16317,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_16641,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t1,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* sre-has-submatchs? */
t6=lf[228];
f_12270(3,t6,t5,t2);}

/* k16639 in lp in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_16641(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_16641,2,t0,t1);}
if(C_truep(t1)){
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[6]))){
t2=(C_word)C_u_i_car(((C_word*)t0)[6]);
t3=(C_word)C_eqp(t2,lf[186]);
t4=(C_truep(t3)?t3:(C_word)C_eqp(t2,lf[82]));
if(C_truep(t4)){
t5=(C_word)C_u_i_cddr(((C_word*)t0)[6]);
t6=f_13391(C_a_i(&a,3),t5);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_16368,a[2]=((C_word*)t0)[6],a[3]=t6,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t8=(C_word)C_u_i_cadr(((C_word*)t0)[6]);
/* lp3081 */
t9=((C_word*)((C_word*)t0)[3])[1];
f_16317(t9,t7,t8,((C_word*)t0)[4],C_SCHEME_TRUE);}
else{
t5=(C_word)C_eqp(t2,lf[70]);
if(C_truep(t5)){
t6=(C_word)C_u_i_cddr(((C_word*)t0)[6]);
t7=f_13416(C_a_i(&a,3),t6);
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_16461,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[2],a[4]=t7,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t9=(C_word)C_u_i_cadr(((C_word*)t0)[6]);
/* lp3081 */
t10=((C_word*)((C_word*)t0)[3])[1];
f_16317(t10,t8,t9,((C_word*)t0)[4],C_SCHEME_TRUE);}
else{
t6=(C_word)C_eqp(t2,lf[91]);
t7=(C_truep(t6)?t6:(C_word)C_eqp(t2,lf[93]));
if(C_truep(t7)){
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_16511,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t11,a[5]=t9,tmp=(C_word)a,a+=6,tmp);
t13=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t14=f_13391(C_a_i(&a,3),t13);
/* lp3081 */
t15=((C_word*)((C_word*)t0)[3])[1];
f_16317(t15,t12,t14,((C_word*)t0)[4],C_SCHEME_TRUE);}
else{
t8=(C_word)C_eqp(t2,lf[95]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_16567,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t10=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t11=f_13391(C_a_i(&a,3),t10);
/* lp3081 */
t12=((C_word*)((C_word*)t0)[3])[1];
f_16317(t12,t9,t11,((C_word*)t0)[4],C_SCHEME_TRUE);}
else{
t9=(C_word)C_eqp(t2,lf[76]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_16592,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t11=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t12=f_13391(C_a_i(&a,3),t11);
t13=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[4],C_fix(1));
/* lp3081 */
t14=((C_word*)((C_word*)t0)[3])[1];
f_16317(t14,t10,t12,t13,C_SCHEME_TRUE);}
else{
t10=(C_word)C_u_i_car(((C_word*)t0)[6]);
/* error */
t11=*((C_word*)lf[24]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,((C_word*)t0)[5],lf[223],t10);}}}}}}
else{
/* error */
t2=*((C_word*)lf[24]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[5],lf[224],((C_word*)t0)[6]);}}
else{
t2=((C_word*)t0)[2];
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_16335,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_16344,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* sre->nfa */
f_14429(t4,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);}
else{
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_16331,tmp=(C_word)a,a+=2,tmp));}}}

/* f_16331 in k16639 in lp in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_16331(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_16331,6,t0,t1,t2,t3,t4,t5);}
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t4);}

/* k16342 in k16639 in lp in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_16344(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* nfa->dfa */
f_15219(((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k16333 in k16639 in lp in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_16335(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_16335,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_16336,a[2]=t1,tmp=(C_word)a,a+=3,tmp));}

/* f_16336 in k16333 in k16639 in lp in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_16336(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_16336,6,t0,t1,t2,t3,t4,t5);}
/* dfa-match/longest */
f_14322(t1,((C_word*)t0)[2],t2,t3,t4);}

/* k16590 in k16639 in lp in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_16592(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_16592,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_16593,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp));}

/* f_16593 in k16590 in k16639 in lp in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_16593(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_16593,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_16597,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* match-one3217 */
t7=((C_word*)t0)[2];
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t6,t2,t3,t4,t5);}

/* k16595 */
static void C_ccall f_16597(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_16597,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_16600,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_numberp(t1))){
t3=f_5119(C_a_i(&a,8),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);
/* irregex-match-end-index-set! */
t4=t2;
f_16600(t4,f_5133(C_a_i(&a,8),((C_word*)t0)[4],((C_word*)t0)[3],t1));}
else{
t3=t2;
f_16600(t3,C_SCHEME_UNDEFINED);}}

/* k16598 in k16595 */
static void C_fcall f_16600(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k16565 in k16639 in lp in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_16567(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_16567,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_16568,a[2]=t1,tmp=(C_word)a,a+=3,tmp));}

/* f_16568 in k16565 in k16639 in lp in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_16568(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_16568,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_16572,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* match-once3202 */
t7=((C_word*)t0)[2];
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t6,t2,t3,t4,t5);}

/* k16570 */
static void C_ccall f_16572(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?t1:((C_word*)t0)[2]));}

/* k16509 in k16639 in lp in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_16511(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_16511,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=C_mutate(((C_word *)((C_word*)t0)[4])+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_16513,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp));
t4=(C_word)C_u_i_car(((C_word*)t0)[3]);
t5=(C_word)C_eqp(lf[91],t4);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_truep(t5)?((C_word*)((C_word*)t0)[4])[1]:(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_16536,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp)));}

/* f_16536 in k16509 in k16639 in lp in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_16536(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_16536,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_16540,a[2]=t5,a[3]=t4,a[4]=t2,a[5]=t1,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* match-once3178 */
t7=((C_word*)((C_word*)t0)[2])[1];
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t6,t2,t3,t4,t5);}

/* k16538 */
static void C_ccall f_16540(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* match-all3179 */
t2=((C_word*)((C_word*)t0)[6])[1];
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[5],((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* f_16513 in k16509 in k16639 in lp in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_16513(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_16513,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_16517,a[2]=t5,a[3]=t4,a[4]=t2,a[5]=t1,a[6]=((C_word*)t0)[3],a[7]=t3,tmp=(C_word)a,a+=8,tmp);
/* match-once3178 */
t7=((C_word*)((C_word*)t0)[2])[1];
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t6,t2,t3,t4,t5);}

/* k16515 */
static void C_ccall f_16517(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?(C_word)C_i_lessp(((C_word*)t0)[7],t1):C_SCHEME_FALSE);
if(C_truep(t2)){
/* match-all3179 */
t3=((C_word*)((C_word*)t0)[6])[1];
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,((C_word*)t0)[5],((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[7]);}}

/* k16459 in k16639 in lp in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_16461(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_16461,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_16464,a[2]=t1,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_16486,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_u_i_cadr(((C_word*)t0)[2]);
/* sre-count-submatches */
f_12296(t3,t4);}

/* k16484 in k16459 in k16639 in lp in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_16486(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_16486,2,t0,t1);}
t2=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[6],t1);
/* lp3081 */
t3=((C_word*)((C_word*)t0)[5])[1];
f_16317(t3,((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k16462 in k16459 in k16639 in lp in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_16464(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_16464,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_16465,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp));}

/* f_16465 in k16462 in k16459 in k16639 in lp in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_16465(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_16465,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_16469,a[2]=t5,a[3]=t3,a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=t1,a[7]=t4,tmp=(C_word)a,a+=8,tmp);
/* match-first3160 */
t7=((C_word*)t0)[2];
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t6,t2,t3,t4,t5);}

/* k16467 */
static void C_ccall f_16469(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_eqvp(t1,((C_word*)t0)[7]))){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
/* match-rest3162 */
t2=((C_word*)t0)[5];
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[6],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[7],((C_word*)t0)[2]);}}

/* k16366 in k16639 in lp in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_16368(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_16368,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_16371,a[2]=t1,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_16437,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_u_i_cadr(((C_word*)t0)[2]);
/* sre-count-submatches */
f_12296(t3,t4);}

/* k16435 in k16366 in k16639 in lp in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_16437(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_16437,2,t0,t1);}
t2=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[5],t1);
/* lp3081 */
t3=((C_word*)((C_word*)t0)[4])[1];
f_16317(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2,C_SCHEME_TRUE);}

/* k16369 in k16366 in k16639 in lp in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_16371(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_16371,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_16372,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp));}

/* f_16372 in k16369 in k16366 in k16639 in lp in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_16372(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_16372,6,t0,t1,t2,t3,t4,t5);}
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_16378,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=t7,a[7]=t4,a[8]=t3,tmp=(C_word)a,a+=9,tmp));
t9=((C_word*)t7)[1];
f_16378(t9,t1,t4,C_SCHEME_FALSE);}

/* lp */
static void C_fcall f_16378(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_16378,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_lessp(t2,((C_word*)t0)[8]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_16388,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t3,a[7]=t2,a[8]=t1,a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp);
/* match-left3122 */
t5=((C_word*)t0)[2];
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t4,((C_word*)t0)[4],((C_word*)t0)[8],t2,((C_word*)t0)[3]);}}

/* k16386 in lp */
static void C_ccall f_16388(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_16388,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_16391,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t1)){
if(C_truep((C_word)C_i_eqvp(t1,((C_word*)t0)[7]))){
/* match-right3124 */
t3=((C_word*)t0)[4];
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,((C_word*)t0)[3],t1,((C_word*)t0)[9],((C_word*)t0)[2]);}
else{
t3=t2;
f_16391(2,t3,C_SCHEME_FALSE);}}
else{
t3=t2;
f_16391(2,t3,C_SCHEME_FALSE);}}

/* k16389 in k16386 in lp */
static void C_ccall f_16391(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_16391,2,t0,t1);}
if(C_truep((C_word)C_i_eqvp(t1,((C_word*)t0)[6]))){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_a_i_minus(&a,2,((C_word*)t0)[4],C_fix(1));
t3=(C_word)C_i_not(((C_word*)t0)[3]);
t4=(C_truep(t3)?t3:(C_truep(t1)?(C_word)C_i_greaterp(t1,((C_word*)t0)[3]):C_SCHEME_FALSE));
t5=(C_truep(t4)?t1:((C_word*)t0)[3]);
/* lp3132 */
t6=((C_word*)((C_word*)t0)[2])[1];
f_16378(t6,((C_word*)t0)[5],t2,t5);}}

/* k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_11725(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11725,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_11728,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* sre-count-submatches */
f_12296(t2,((C_word*)t0)[8]);}

/* k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_11728(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11728,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_11731,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* sre-names */
f_13556(t2,((C_word*)t0)[9],C_fix(1),C_SCHEME_END_OF_LIST);}

/* k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_11731(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11731,2,t0,t1);}
t2=((C_word*)t0)[10];
t3=(C_word)C_a_i_list(&a,1,t1);
t4=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_12359,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],tmp=(C_word)a,a+=12,tmp);
if(C_truep((C_word)C_i_pairp(t3))){
t5=t4;
f_12359(2,t5,(C_word)C_u_i_car(t3));}
else{
/* sre-names */
f_13556(t4,t2,C_fix(1),C_SCHEME_END_OF_LIST);}}

/* k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_12359(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12359,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_12362,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13380,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* sre-count-submatches */
f_12296(t3,((C_word*)t0)[2]);}

/* k13378 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_13380(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13380,2,t0,t1);}
t2=(C_word)C_a_i_plus(&a,2,C_fix(1),t1);
/* make-vector */
t3=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t2,C_SCHEME_FALSE);}

/* k12360 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_12362(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12362,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_12369,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=t1,tmp=(C_word)a,a+=12,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12371,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_12371(t6,t2,((C_word*)t0)[2],C_fix(1),C_fix(0),C_fix(0),*((C_word*)lf[222]+1));}

/* lp in k12360 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_fcall f_12371(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word *a;
loop:
a=C_alloc(18);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_12371,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12374,a[2]=t6,a[3]=t5,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t8=(C_word)C_u_i_car(t2);
if(C_truep((C_word)C_i_stringp(t8))){
/* grow1921 */
t9=t7;
f_12374(t9,t1,C_fix(1));}
else{
t9=(C_word)C_u_i_car(t2);
t10=(C_word)C_eqp(t9,lf[31]);
t11=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_12416,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t6,a[6]=t5,a[7]=t4,a[8]=t3,a[9]=((C_word*)t0)[4],a[10]=t9,a[11]=t1,a[12]=t7,tmp=(C_word)a,a+=13,tmp);
if(C_truep(t10)){
t12=t11;
f_12416(t12,t10);}
else{
t12=(C_word)C_eqp(t9,lf[124]);
if(C_truep(t12)){
t13=t11;
f_12416(t13,t12);}
else{
t13=(C_word)C_eqp(t9,lf[193]);
t14=t11;
f_12416(t14,(C_truep(t13)?t13:(C_word)C_eqp(t9,lf[204])));}}}}
else{
if(C_truep((C_word)C_charp(t2))){
/* grow1921 */
t8=t7;
f_12374(t8,t1,C_fix(1));}
else{
if(C_truep((C_word)C_i_stringp(t2))){
t8=(C_word)C_fix((C_word)C_header_size(t2));
/* grow1921 */
t9=t7;
f_12374(t9,t1,t8);}
else{
t8=t2;
if(C_truep((C_truep((C_word)C_eqp(t8,lf[88]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t8,lf[89]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
/* grow1921 */
t9=t7;
f_12374(t9,t1,C_fix(1));}
else{
t9=t2;
if(C_truep((C_truep((C_word)C_eqp(t9,lf[83]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t9,lf[151]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t9,lf[152]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t9,lf[160]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t9,lf[161]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t9,lf[149]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t9,lf[148]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t9,lf[150]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t9,lf[220]))?C_SCHEME_TRUE:C_SCHEME_FALSE))))))))))){
/* return1913 */
t10=t6;
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t1,t4,t5);}
else{
t10=(C_word)C_u_i_assq(t2,lf[205]);
if(C_truep(t10)){
t11=(C_word)C_slot(t10,C_fix(1));
/* lp1907 */
t20=t1;
t21=t11;
t22=t3;
t23=t4;
t24=t5;
t25=t6;
t1=t20;
t2=t21;
t3=t22;
t4=t23;
t5=t24;
t6=t25;
goto loop;}
else{
/* error */
t11=*((C_word*)lf[24]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t1,lf[221],t2);}}}}}}}

/* k12414 in lp in k12360 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_fcall f_12416(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12416,NULL,2,t0,t1);}
if(C_truep(t1)){
/* grow1921 */
t2=((C_word*)t0)[12];
f_12374(t2,((C_word*)t0)[11],C_fix(1));}
else{
t2=(C_word)C_eqp(((C_word*)t0)[10],lf[194]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_12432,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
t4=(C_word)C_u_i_cadr(((C_word*)t0)[4]);
/* string->sre */
t5=*((C_word*)lf[68]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[10],lf[82]);
t4=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_12445,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[7],a[11]=((C_word*)t0)[4],tmp=(C_word)a,a+=12,tmp);
if(C_truep(t3)){
t5=t4;
f_12445(t5,t3);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[10],lf[186]);
if(C_truep(t5)){
t6=t4;
f_12445(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[10],lf[184]);
if(C_truep(t6)){
t7=t4;
f_12445(t7,t6);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[10],lf[185]);
t8=t4;
f_12445(t8,(C_truep(t7)?t7:(C_word)C_eqp(((C_word*)t0)[10],lf[197])));}}}}}}

/* k12443 in k12414 in lp in k12360 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_fcall f_12445(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12445,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[11],C_fix(1));
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_12454,a[2]=((C_word*)t0)[7],a[3]=t4,a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp));
t6=((C_word*)t4)[1];
f_12454(t6,((C_word*)t0)[6],t2,((C_word*)t0)[5],C_fix(0),C_fix(0));}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[70]);
if(C_truep(t2)){
t3=(C_word)C_slot(((C_word*)t0)[11],C_fix(1));
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_12536,a[2]=((C_word*)t0)[7],a[3]=t5,a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp));
t7=((C_word*)t5)[1];
f_12536(t7,((C_word*)t0)[6],t3,((C_word*)t0)[5],C_SCHEME_FALSE,C_fix(0));}
else{
t3=(C_word)C_eqp(((C_word*)t0)[4],lf[77]);
if(C_truep(t3)){
t4=(C_word)C_slot(((C_word*)t0)[11],C_fix(1));
t5=(C_word)C_i_nullp(t4);
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_12621,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t5)){
t7=t6;
f_12621(t7,t5);}
else{
t7=(C_word)C_u_i_cddr(((C_word*)t0)[11]);
t8=t6;
f_12621(t8,(C_word)C_i_nullp(t7));}}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[202]);
if(C_truep(t4)){
t5=(C_word)C_u_i_cdddr(((C_word*)t0)[11]);
t6=f_13391(C_a_i(&a,3),t5);
t7=(C_word)C_u_i_cadr(((C_word*)t0)[11]);
t8=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[5],t7);
/* lp1907 */
t9=((C_word*)((C_word*)t0)[7])[1];
f_12371(t9,((C_word*)t0)[6],t6,t8,((C_word*)t0)[10],((C_word*)t0)[9],((C_word*)t0)[8]);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[76]);
t6=(C_truep(t5)?t5:(C_word)C_eqp(((C_word*)t0)[4],lf[85]));
if(C_truep(t6)){
t7=(C_word)C_u_i_car(((C_word*)t0)[11]);
t8=(C_word)C_eqp(lf[76],t7);
t9=(C_truep(t8)?(C_word)C_slot(((C_word*)t0)[11],C_fix(1)):(C_word)C_u_i_cddr(((C_word*)t0)[11]));
t10=f_13391(C_a_i(&a,3),t9);
t11=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[5],C_fix(1));
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12792,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* lp1907 */
t13=((C_word*)((C_word*)t0)[7])[1];
f_12371(t13,((C_word*)t0)[6],t10,t11,((C_word*)t0)[10],((C_word*)t0)[9],t12);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[4],lf[156]);
t8=(C_truep(t7)?t7:(C_word)C_eqp(((C_word*)t0)[4],lf[155]));
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_12832,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t10=(C_word)C_u_i_cadr(((C_word*)t0)[11]);
if(C_truep((C_word)C_i_numberp(t10))){
t11=t9;
f_12832(2,t11,(C_word)C_u_i_cadr(((C_word*)t0)[11]));}
else{
t11=(C_word)C_u_i_cadr(((C_word*)t0)[11]);
t12=(C_word)C_u_i_assq(t11,((C_word*)t0)[2]);
if(C_truep(t12)){
t13=t9;
f_12832(2,t13,(C_word)C_slot(t12,C_fix(1)));}
else{
t13=(C_word)C_u_i_cadr(((C_word*)t0)[11]);
/* error */
t14=*((C_word*)lf[24]+1);
((C_proc4)(void*)(*((C_word*)t14+1)))(4,t14,t9,lf[215],t13);}}}
else{
t9=(C_word)C_eqp(((C_word*)t0)[4],lf[91]);
t10=(C_truep(t9)?t9:(C_word)C_eqp(((C_word*)t0)[4],lf[92]));
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12945,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
t12=(C_word)C_slot(((C_word*)t0)[11],C_fix(1));
t13=f_13391(C_a_i(&a,3),t12);
t14=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12954,tmp=(C_word)a,a+=2,tmp);
/* lp1907 */
t15=((C_word*)((C_word*)t0)[7])[1];
f_12371(t15,t11,t13,((C_word*)t0)[5],((C_word*)t0)[10],((C_word*)t0)[9],t14);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[4],lf[97]);
t12=(C_truep(t11)?t11:(C_word)C_eqp(((C_word*)t0)[4],lf[94]));
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_12974,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t14=(C_word)C_u_i_cadr(((C_word*)t0)[11]);
if(C_truep((C_word)C_i_numberp(t14))){
t15=(C_word)C_u_i_caddr(((C_word*)t0)[11]);
if(C_truep((C_word)C_i_numberp(t15))){
t16=(C_word)C_u_i_cadr(((C_word*)t0)[11]);
t17=(C_word)C_u_i_caddr(((C_word*)t0)[11]);
t18=t13;
f_12974(t18,(C_word)C_i_greaterp(t16,t17));}
else{
t16=t13;
f_12974(t16,C_SCHEME_FALSE);}}
else{
t15=t13;
f_12974(t15,C_SCHEME_FALSE);}}
else{
t13=(C_word)C_eqp(((C_word*)t0)[4],lf[93]);
if(C_truep(t13)){
t14=(C_word)C_slot(((C_word*)t0)[11],C_fix(1));
t15=f_13391(C_a_i(&a,3),t14);
t16=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_13118,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
/* lp1907 */
t17=((C_word*)((C_word*)t0)[7])[1];
f_12371(t17,((C_word*)t0)[6],t15,((C_word*)t0)[5],((C_word*)t0)[10],((C_word*)t0)[9],t16);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[4],lf[95]);
t15=(C_truep(t14)?t14:(C_word)C_eqp(((C_word*)t0)[4],lf[96]));
if(C_truep(t15)){
t16=(C_word)C_slot(((C_word*)t0)[11],C_fix(1));
t17=f_13391(C_a_i(&a,3),t16);
t18=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_13148,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
/* lp1907 */
t19=((C_word*)((C_word*)t0)[7])[1];
f_12371(t19,((C_word*)t0)[6],t17,((C_word*)t0)[5],((C_word*)t0)[10],((C_word*)t0)[9],t18);}
else{
t16=(C_word)C_eqp(((C_word*)t0)[4],lf[98]);
t17=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_13175,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
if(C_truep(t16)){
t18=t17;
f_13175(t18,t16);}
else{
t18=(C_word)C_eqp(((C_word*)t0)[4],lf[218]);
if(C_truep(t18)){
t19=t17;
f_13175(t19,t18);}
else{
t19=(C_word)C_eqp(((C_word*)t0)[4],lf[99]);
t20=t17;
f_13175(t20,(C_truep(t19)?t19:(C_word)C_eqp(((C_word*)t0)[4],lf[219])));}}}}}}}}}}}}}

/* k13173 in k12443 in k12414 in lp in k12360 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_fcall f_13175(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_13175,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_u_i_cadr(((C_word*)t0)[9]);
t3=(C_word)C_u_i_car(((C_word*)t0)[9]);
t4=(C_word)C_u_i_memq(t3,lf[216]);
t5=(C_truep(t4)?C_SCHEME_FALSE:(C_word)C_u_i_cadr(((C_word*)t0)[9]));
t6=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_13202,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t2,a[9]=t5,tmp=(C_word)a,a+=10,tmp);
t7=(C_word)C_u_i_cddr(((C_word*)t0)[9]);
/* ##sys#append */
t8=*((C_word*)lf[84]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,t7,C_SCHEME_END_OF_LIST);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[2],lf[78]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_13225,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t2)){
t4=t3;
f_13225(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[2],lf[79]);
if(C_truep(t4)){
t5=t3;
f_13225(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[2],lf[80]);
t6=t3;
f_13225(t6,(C_truep(t5)?t5:(C_word)C_eqp(((C_word*)t0)[2],lf[81])));}}}}

/* k13223 in k13173 in k12443 in k12414 in lp in k12360 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_fcall f_13225(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* return1913 */
t2=((C_word*)t0)[6];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
/* error */
t2=*((C_word*)lf[24]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[5],lf[217],((C_word*)t0)[2]);}}

/* k13200 in k13173 in k12443 in k12414 in lp in k12360 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_13202(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13202,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t2);
t4=(C_word)C_a_i_cons(&a,2,lf[97],t3);
/* lp1907 */
t5=((C_word*)((C_word*)t0)[7])[1];
f_12371(t5,((C_word*)t0)[6],t4,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a13147 in k12443 in k12414 in lp in k12360 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_13148(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_13148,4,t0,t1,t2,t3);}
t4=(C_truep(((C_word*)t0)[4])?(C_truep(t3)?(C_word)C_a_i_plus(&a,2,((C_word*)t0)[4],t3):C_SCHEME_FALSE):C_SCHEME_FALSE);
/* return1913 */
t5=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,((C_word*)t0)[2],t4);}

/* a13117 in k12443 in k12414 in lp in k12360 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_13118(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_13118,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[3],t2);
/* return1913 */
t5=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t4,C_SCHEME_FALSE);}

/* k12972 in k12443 in k12414 in lp in k12360 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_fcall f_12974(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12974,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_12977,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t1)){
t3=t2;
f_12977(t3,t1);}
else{
t3=(C_word)C_u_i_cadr(((C_word*)t0)[4]);
t4=t2;
f_12977(t4,(C_truep(t3)?C_SCHEME_FALSE:(C_word)C_u_i_caddr(((C_word*)t0)[4])));}}

/* k12975 in k12972 in k12443 in k12414 in lp in k12360 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_fcall f_12977(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12977,NULL,2,t0,t1);}
if(C_truep(t1)){
/* return1913 */
t2=((C_word*)t0)[8];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5]);}
else{
if(C_truep((C_word)C_u_i_caddr(((C_word*)t0)[4]))){
t2=(C_word)C_u_i_cdddr(((C_word*)t0)[4]);
t3=f_13391(C_a_i(&a,3),t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_12995,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* lp1907 */
t5=((C_word*)((C_word*)t0)[3])[1];
f_12371(t5,((C_word*)t0)[7],t3,((C_word*)t0)[2],C_fix(0),C_fix(0),t4);}
else{
t2=(C_word)C_u_i_cdddr(((C_word*)t0)[4]);
t3=f_13391(C_a_i(&a,3),t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_13042,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* lp1907 */
t5=((C_word*)((C_word*)t0)[3])[1];
f_12371(t5,((C_word*)t0)[7],t3,((C_word*)t0)[2],C_fix(0),C_fix(0),t4);}}}

/* a13041 in k12975 in k12972 in k12443 in k12414 in lp in k12360 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_13042(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_13042,4,t0,t1,t2,t3);}
t4=(C_word)C_u_i_cadr(((C_word*)t0)[4]);
t5=(C_word)C_a_i_times(&a,2,t4,t2);
t6=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[3],t5);
/* return1913 */
t7=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t1,t6,C_SCHEME_FALSE);}

/* a12994 in k12975 in k12972 in k12443 in k12414 in lp in k12360 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_12995(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_12995,4,t0,t1,t2,t3);}
t4=(C_word)C_u_i_cadr(((C_word*)t0)[5]);
t5=(C_word)C_a_i_times(&a,2,t4,t2);
t6=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[4],t5);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_13007,a[2]=t6,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
if(C_truep(t3)){
t8=(C_word)C_u_i_caddr(((C_word*)t0)[5]);
t9=(C_word)C_a_i_times(&a,2,t8,t3);
t10=t7;
f_13007(t10,(C_word)C_a_i_plus(&a,2,((C_word*)t0)[2],t9));}
else{
t8=t7;
f_13007(t8,C_SCHEME_FALSE);}}
else{
t8=t7;
f_13007(t8,C_SCHEME_FALSE);}}

/* k13005 in a12994 in k12975 in k12972 in k12443 in k12414 in lp in k12360 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_fcall f_13007(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* return1913 */
t2=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a12953 in k12443 in k12414 in lp in k12360 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_12954(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_12954,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}

/* k12943 in k12443 in k12414 in lp in k12360 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_12945(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* return1913 */
t2=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k12830 in k12443 in k12414 in lp in k12360 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_12832(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12832,2,t0,t1);}
t2=(C_word)C_i_integerp(t1);
t3=(C_word)C_i_not(t2);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_12841,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t3)){
t5=t4;
f_12841(t5,t3);}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12895,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(C_word)C_fix((C_word)C_header_size(((C_word*)t0)[5]));
/* < */
C_lessp(5,0,t5,C_fix(0),t1,t6);}}

/* k12893 in k12830 in k12443 in k12414 in lp in k12360 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_12895(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_12841(t2,(C_word)C_i_not(t1));}

/* k12839 in k12830 in k12443 in k12414 in lp in k12360 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_fcall f_12841(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12841,NULL,2,t0,t1);}
if(C_truep(t1)){
/* error */
t2=*((C_word*)lf[24]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[8],lf[213],((C_word*)t0)[7]);}
else{
if(C_truep((C_word)C_slot(((C_word*)t0)[6],((C_word*)t0)[5]))){
t2=(C_word)C_slot(((C_word*)t0)[6],((C_word*)t0)[5]);
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_slot(((C_word*)t0)[6],((C_word*)t0)[5]);
t5=(C_word)C_slot(t4,C_fix(1));
t6=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[4],t3);
t7=(C_truep(((C_word*)t0)[3])?(C_truep(t5)?(C_word)C_a_i_plus(&a,2,((C_word*)t0)[3],t5):C_SCHEME_FALSE):C_SCHEME_FALSE);
/* return1913 */
t8=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,((C_word*)t0)[8],t6,t7);}
else{
/* error */
t2=*((C_word*)lf[24]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[8],lf[214],((C_word*)t0)[7]);}}}

/* a12791 in k12443 in k12414 in lp in k12360 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_12792(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_12792,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_cons(&a,2,t2,t3);
t5=(C_word)C_i_setslot(((C_word*)t0)[4],((C_word*)t0)[3],t4);
/* return1913 */
t6=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t1,t2,t3);}

/* k12619 in k12443 in k12414 in lp in k12360 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_fcall f_12621(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12621,NULL,2,t0,t1);}
if(C_truep(t1)){
/* return1913 */
t2=((C_word*)t0)[8];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5]);}
else{
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_12627,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[4],tmp=(C_word)a,a+=9,tmp);
t3=(C_word)C_u_i_car(((C_word*)t0)[4]);
/* sre-count-submatches */
f_12296(t2,t3);}}

/* k12625 in k12619 in k12443 in k12414 in lp in k12360 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_12627(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12627,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_12630,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=(C_word)C_u_i_cadr(((C_word*)t0)[8]);
/* sre-count-submatches */
f_12296(t2,t3);}

/* k12628 in k12625 in k12619 in k12443 in k12414 in lp in k12360 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_12630(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12630,2,t0,t1);}
t2=(C_word)C_u_i_cadr(((C_word*)t0)[9]);
t3=(C_word)C_i_numberp(t2);
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_12712,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
if(C_truep(t3)){
t5=t4;
f_12712(t5,t3);}
else{
t5=(C_word)C_u_i_cadr(((C_word*)t0)[9]);
t6=t4;
f_12712(t6,(C_word)C_i_symbolp(t5));}}

/* k12710 in k12628 in k12625 in k12619 in k12443 in k12414 in lp in k12360 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_fcall f_12712(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12712,NULL,2,t0,t1);}
t2=(C_truep(t1)?lf[83]:(C_word)C_u_i_cadr(((C_word*)t0)[10]));
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_12639,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
/* lp1907 */
t4=((C_word*)((C_word*)t0)[6])[1];
f_12371(t4,((C_word*)t0)[4],t2,((C_word*)t0)[9],((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* a12638 in k12710 in k12628 in k12625 in k12619 in k12443 in k12414 in lp in k12360 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_12639(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_12639,4,t0,t1,t2,t3);}
t4=(C_word)C_u_i_caddr(((C_word*)t0)[7]);
t5=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[6],((C_word*)t0)[5]);
t6=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_12653,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[3],a[6]=t3,a[7]=((C_word*)t0)[4],a[8]=t2,a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp);
/* lp1907 */
t7=((C_word*)((C_word*)t0)[3])[1];
f_12371(t7,t1,t4,t5,C_fix(0),C_fix(0),t6);}

/* a12652 in a12638 in k12710 in k12628 in k12625 in k12619 in k12443 in k12414 in lp in k12360 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_12653(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_12653,4,t0,t1,t2,t3);}
t4=(C_word)C_u_i_cdddr(((C_word*)t0)[9]);
t5=(C_word)C_i_pairp(t4);
t6=(C_truep(t5)?(C_word)C_u_i_cadddr(((C_word*)t0)[9]):lf[83]);
t7=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_12665,a[2]=t6,a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=t3,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* + */
C_plus(5,0,t7,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k12663 in a12652 in a12638 in k12710 in k12628 in k12625 in k12619 in k12443 in k12414 in lp in k12360 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_12665(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12665,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_12667,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
/* lp1907 */
t3=((C_word*)((C_word*)t0)[4])[1];
f_12371(t3,((C_word*)t0)[3],((C_word*)t0)[2],t1,C_fix(0),C_fix(0),t2);}

/* a12666 in k12663 in a12652 in a12638 in k12710 in k12628 in k12625 in k12619 in k12443 in k12414 in lp in k12360 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_12667(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_12667,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_12696,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* min */
t5=*((C_word*)lf[212]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[2],t2);}

/* k12694 in a12666 in k12663 in a12652 in a12638 in k12710 in k12628 in k12625 in k12619 in k12443 in k12414 in lp in k12360 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_12696(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12696,2,t0,t1);}
t2=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[7],t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12679,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[4])){
if(C_truep(((C_word*)t0)[3])){
if(C_truep(((C_word*)t0)[2])){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12692,a[2]=((C_word*)t0)[4],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* max */
t5=*((C_word*)lf[211]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t4=t3;
f_12679(t4,C_SCHEME_FALSE);}}
else{
t4=t3;
f_12679(t4,C_SCHEME_FALSE);}}
else{
t4=t3;
f_12679(t4,C_SCHEME_FALSE);}}

/* k12690 in k12694 in a12666 in k12663 in a12652 in a12638 in k12710 in k12628 in k12625 in k12619 in k12443 in k12414 in lp in k12360 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_12692(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12692,2,t0,t1);}
t2=((C_word*)t0)[3];
f_12679(t2,(C_word)C_a_i_plus(&a,2,((C_word*)t0)[2],t1));}

/* k12677 in k12694 in a12666 in k12663 in a12652 in a12638 in k12710 in k12628 in k12625 in k12619 in k12443 in k12414 in lp in k12360 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_fcall f_12679(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* return1913 */
t2=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* lp2 in k12443 in k12414 in lp in k12360 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_fcall f_12536(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12536,NULL,6,t0,t1,t2,t3,t4,t5);}
if(C_truep((C_word)C_i_nullp(t2))){
t6=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[6],t4);
t7=(C_truep(((C_word*)t0)[5])?(C_truep(t5)?(C_word)C_a_i_plus(&a,2,((C_word*)t0)[5],t5):C_SCHEME_FALSE):C_SCHEME_FALSE);
/* return1913 */
t8=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t1,t6,t7);}
else{
t6=(C_word)C_u_i_car(t2);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_12569,a[2]=t4,a[3]=t5,a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* lp1907 */
t8=((C_word*)((C_word*)t0)[2])[1];
f_12371(t8,t1,t6,t3,C_fix(0),C_fix(0),t7);}}

/* a12568 in lp2 in k12443 in k12414 in lp in k12360 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_12569(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_12569,4,t0,t1,t2,t3);}
t4=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_12602,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=((C_word*)t0)[3],a[6]=t4,a[7]=t1,a[8]=((C_word*)t0)[4],a[9]=((C_word*)t0)[5],tmp=(C_word)a,a+=10,tmp);
t6=(C_word)C_u_i_car(((C_word*)t0)[6]);
/* sre-count-submatches */
f_12296(t5,t6);}

/* k12600 in a12568 in lp2 in k12443 in k12414 in lp in k12360 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_12602(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12602,2,t0,t1);}
t2=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[9],t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_12585,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t2,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[3])){
/* min */
t4=*((C_word*)lf[212]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t4=t3;
f_12585(2,t4,((C_word*)t0)[2]);}}

/* k12583 in k12600 in a12568 in lp2 in k12443 in k12414 in lp in k12360 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_12585(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12585,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_12589,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[3])){
if(C_truep(((C_word*)t0)[2])){
/* max */
t3=*((C_word*)lf[211]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t3=t2;
f_12589(2,t3,C_SCHEME_FALSE);}}
else{
t3=t2;
f_12589(2,t3,C_SCHEME_FALSE);}}

/* k12587 in k12583 in k12600 in a12568 in lp2 in k12443 in k12414 in lp in k12360 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_12589(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp21996 */
t2=((C_word*)((C_word*)t0)[6])[1];
f_12536(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* lp2 in k12443 in k12414 in lp in k12360 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_fcall f_12454(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12454,NULL,6,t0,t1,t2,t3,t4,t5);}
if(C_truep((C_word)C_i_nullp(t2))){
t6=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[6],t4);
t7=(C_truep(((C_word*)t0)[5])?(C_truep(t5)?(C_word)C_a_i_plus(&a,2,((C_word*)t0)[5],t5):C_SCHEME_FALSE):C_SCHEME_FALSE);
/* return1913 */
t8=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t1,t6,t7);}
else{
t6=(C_word)C_u_i_car(t2);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_12487,a[2]=((C_word*)t0)[3],a[3]=t5,a[4]=t4,a[5]=t3,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* lp1907 */
t8=((C_word*)((C_word*)t0)[2])[1];
f_12371(t8,t1,t6,t3,C_fix(0),C_fix(0),t7);}}

/* a12486 in lp2 in k12443 in k12414 in lp in k12360 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_12487(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_12487,4,t0,t1,t2,t3);}
t4=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_12517,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t3,a[6]=((C_word*)t0)[3],a[7]=t2,a[8]=((C_word*)t0)[4],a[9]=((C_word*)t0)[5],tmp=(C_word)a,a+=10,tmp);
t6=(C_word)C_u_i_car(((C_word*)t0)[6]);
/* sre-count-submatches */
f_12296(t5,t6);}

/* k12515 in a12486 in lp2 in k12443 in k12414 in lp in k12360 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_12517(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12517,2,t0,t1);}
t2=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[9],t1);
t3=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[8],((C_word*)t0)[7]);
t4=(C_truep(((C_word*)t0)[6])?(C_truep(((C_word*)t0)[5])?(C_word)C_a_i_plus(&a,2,((C_word*)t0)[6],((C_word*)t0)[5]):C_SCHEME_FALSE):C_SCHEME_FALSE);
/* lp21976 */
t5=((C_word*)((C_word*)t0)[4])[1];
f_12454(t5,((C_word*)t0)[3],((C_word*)t0)[2],t2,t3,t4);}

/* k12430 in k12414 in lp in k12360 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_12432(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp1907 */
t2=((C_word*)((C_word*)t0)[7])[1];
f_12371(t2,((C_word*)t0)[6],t1,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* grow in lp in k12360 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_fcall f_12374(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12374,NULL,3,t0,t1,t2);}
t3=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[4],t2);
t4=(C_truep(((C_word*)t0)[3])?(C_word)C_a_i_plus(&a,2,((C_word*)t0)[3],t2):C_SCHEME_FALSE);
/* return1913 */
t5=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t3,t4);}

/* k12367 in k12360 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_12369(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12369,2,t0,t1);}
t2=(C_word)C_i_setslot(((C_word*)t0)[11],C_fix(0),t1);
t3=((C_word*)t0)[11];
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_11737,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t3,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11753,a[2]=((C_word*)t0)[4],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(C_truep(((C_word*)t0)[2])?C_fix(1):C_SCHEME_FALSE);
/* flag-join */
t7=lf[54];
f_6135(4,t7,t5,C_fix(0),t6);}

/* k11751 in k12367 in k12360 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_11753(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11753,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11760,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* sre-consumer? */
t3=lf[210];
f_12184(3,t3,t2,((C_word*)t0)[2]);}

/* k11758 in k11751 in k12367 in k12360 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_11760(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?C_fix(2):C_SCHEME_FALSE);
/* flag-join */
t3=lf[54];
f_6135(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k11735 in k12367 in k12360 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_11737(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11737,2,t0,t1);}
if(C_truep(((C_word*)t0)[10])){
/* make-irregex */
t2=((C_word*)t0)[9];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,f_4874(C_a_i(&a,10),((C_word*)t0)[10],((C_word*)t0)[8],((C_word*)t0)[7],C_SCHEME_FALSE,t1,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]));}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11746,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t1,a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
t3=((C_word*)t0)[3];
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[2],((C_word*)t0)[4]);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_16648,a[2]=t3,a[3]=t2,a[4]=t4,a[5]=t6,tmp=(C_word)a,a+=6,tmp);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_18607,a[2]=t3,a[3]=t4,a[4]=t7,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(t4))){
t9=(C_word)C_slot(t4,C_fix(1));
t10=t8;
f_18607(t10,(C_word)C_i_pairp(t9));}
else{
t9=t8;
f_18607(t9,C_SCHEME_FALSE);}}}

/* k18605 in k11735 in k12367 in k12360 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_fcall f_18607(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_16648(2,t2,(C_word)C_u_i_cadr(((C_word*)t0)[3]));}
else{
/* sre-names */
f_13556(((C_word*)t0)[4],((C_word*)t0)[2],C_fix(1),C_SCHEME_END_OF_LIST);}}

/* k16646 in k11735 in k12367 in k12360 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_16648(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_16648,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=(C_word)C_i_pairp(((C_word*)t0)[4]);
t4=(C_truep(t3)?(C_word)C_u_i_car(((C_word*)t0)[4]):C_fix(0));
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_16657,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_16660,a[2]=((C_word*)t0)[5],a[3]=t7,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_16660(t9,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(1),t4,t5);}

/* lp in k16646 in k11735 in k12367 in k12360 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_fcall f_16660(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_16660,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_16663,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t7=(C_word)C_u_i_car(t2);
if(C_truep((C_word)C_i_stringp(t7))){
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_16686,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t9=(C_word)C_u_i_car(t2);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_16694,a[2]=t9,a[3]=t8,tmp=(C_word)a,a+=4,tmp);
/* flag-set? */
f_6125(t10,t4,C_fix(2));}
else{
t8=(C_word)C_u_i_car(t2);
t9=(C_word)C_eqp(t8,lf[124]);
t10=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_16706,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t6,a[6]=t8,a[7]=t4,a[8]=t2,a[9]=t5,a[10]=t1,tmp=(C_word)a,a+=11,tmp);
if(C_truep(t9)){
t11=t10;
f_16706(t11,t9);}
else{
t11=(C_word)C_eqp(t8,lf[204]);
if(C_truep(t11)){
t12=t10;
f_16706(t12,t11);}
else{
t12=(C_word)C_eqp(t8,lf[193]);
t13=t10;
f_16706(t13,(C_truep(t12)?t12:(C_word)C_eqp(t8,lf[31])));}}}}
else{
if(C_truep((C_word)C_i_symbolp(t2))){
t7=t2;
t8=(C_word)C_eqp(t7,lf[88]);
if(C_truep(t8)){
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_18120,a[2]=t5,tmp=(C_word)a,a+=3,tmp));}
else{
t9=(C_word)C_eqp(t7,lf[89]);
if(C_truep(t9)){
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_18148,a[2]=t5,tmp=(C_word)a,a+=3,tmp));}
else{
t10=(C_word)C_eqp(t7,lf[151]);
if(C_truep(t10)){
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_18190,a[2]=t5,tmp=(C_word)a,a+=3,tmp));}
else{
t11=(C_word)C_eqp(t7,lf[160]);
if(C_truep(t11)){
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_18210,a[2]=t5,tmp=(C_word)a,a+=3,tmp));}
else{
t12=(C_word)C_eqp(t7,lf[149]);
if(C_truep(t12)){
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_18244,a[2]=t5,tmp=(C_word)a,a+=3,tmp));}
else{
t13=(C_word)C_eqp(t7,lf[152]);
if(C_truep(t13)){
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_18302,a[2]=t5,tmp=(C_word)a,a+=3,tmp));}
else{
t14=(C_word)C_eqp(t7,lf[161]);
if(C_truep(t14)){
t15=t1;
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_18326,a[2]=t5,tmp=(C_word)a,a+=3,tmp));}
else{
t15=(C_word)C_eqp(t7,lf[148]);
if(C_truep(t15)){
t16=t1;
((C_proc2)(void*)(*((C_word*)t16+1)))(2,t16,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_18360,a[2]=t5,tmp=(C_word)a,a+=3,tmp));}
else{
t16=(C_word)C_eqp(t7,lf[150]);
if(C_truep(t16)){
t17=t1;
((C_proc2)(void*)(*((C_word*)t17+1)))(2,t17,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_18418,a[2]=t5,tmp=(C_word)a,a+=3,tmp));}
else{
t17=(C_word)C_eqp(t7,lf[83]);
if(C_truep(t17)){
t18=t1;
((C_proc2)(void*)(*((C_word*)t18+1)))(2,t18,t5);}
else{
t18=(C_word)C_u_i_assq(t2,lf[205]);
if(C_truep(t18)){
t19=(C_word)C_slot(t18,C_fix(1));
/* rec3257 */
t20=t6;
f_16663(t20,t1,t19);}
else{
/* error */
t19=*((C_word*)lf[24]+1);
((C_proc4)(void*)(*((C_word*)t19+1)))(4,t19,t1,lf[206],t2);}}}}}}}}}}}}
else{
if(C_truep((C_word)C_charp(t2))){
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_18514,a[2]=t2,a[3]=t5,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* flag-set? */
f_6125(t7,t4,C_fix(2));}
else{
if(C_truep((C_word)C_i_stringp(t2))){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_18595,a[2]=t1,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* string->list */
t8=*((C_word*)lf[73]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}
else{
/* error */
t7=*((C_word*)lf[24]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t1,lf[208],t2);}}}}}

/* k18593 in lp in k16646 in k11735 in k12367 in k12360 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_18595(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_18595,2,t0,t1);}
t2=f_13391(C_a_i(&a,3),t1);
/* rec3257 */
t3=((C_word*)t0)[3];
f_16663(t3,((C_word*)t0)[2],t2);}

/* k18512 in lp in k16646 in k11735 in k12367 in k12360 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_18514(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_18514,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_18515,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp):(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_18547,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp)));}

/* f_18547 in k18512 in lp in k16646 in k11735 in k12367 in k12360 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_18547(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_18547,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_18554,a[2]=t5,a[3]=t4,a[4]=t2,a[5]=t1,a[6]=((C_word*)t0)[3],a[7]=t3,tmp=(C_word)a,a+=8,tmp);
t7=(C_word)C_fix((C_word)C_header_size(t2));
if(C_truep((C_word)C_i_lessp(t3,t7))){
t8=(C_word)C_subchar(t2,t3);
t9=t6;
f_18554(t9,(C_word)C_i_eqvp(((C_word*)t0)[2],t8));}
else{
t8=t6;
f_18554(t8,C_SCHEME_FALSE);}}

/* k18552 */
static void C_fcall f_18554(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_18554,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[7],C_fix(1));
/* next3249 */
t3=((C_word*)t0)[6];
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,((C_word*)t0)[5],((C_word*)t0)[4],t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* fail3748 */
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[5]);}}

/* f_18515 in k18512 in lp in k16646 in k11735 in k12367 in k12360 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_18515(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_18515,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_18522,a[2]=t5,a[3]=t4,a[4]=t2,a[5]=t1,a[6]=((C_word*)t0)[3],a[7]=t3,tmp=(C_word)a,a+=8,tmp);
t7=(C_word)C_fix((C_word)C_header_size(t2));
if(C_truep((C_word)C_i_lessp(t3,t7))){
t8=(C_word)C_subchar(t2,t3);
/* char-ci=? */
t9=*((C_word*)lf[207]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t6,((C_word*)t0)[2],t8);}
else{
t8=t6;
f_18522(2,t8,C_SCHEME_FALSE);}}

/* k18520 */
static void C_ccall f_18522(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_18522,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[7],C_fix(1));
/* next3249 */
t3=((C_word*)t0)[6];
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,((C_word*)t0)[5],((C_word*)t0)[4],t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* fail3741 */
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[5]);}}

/* f_18418 in lp in k16646 in k11735 in k12367 in k12360 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_18418(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_18418,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_18425,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t2,a[6]=t1,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_i_zerop(t3))){
t7=t6;
f_18425(t7,C_SCHEME_FALSE);}
else{
t7=(C_word)C_fix((C_word)C_header_size(t2));
if(C_truep((C_word)C_i_lessp(t3,t7))){
t8=(C_word)C_a_i_minus(&a,2,t3,C_fix(1));
t9=(C_word)C_subchar(t2,t8);
t10=f_5521(t9);
if(C_truep(t10)){
t11=(C_word)C_subchar(t2,t3);
/* char-alphanumeric? */
t12=t6;
f_18425(t12,f_5521(t11));}
else{
t11=(C_word)C_subchar(t2,t3);
t12=f_5521(t11);
t13=t6;
f_18425(t13,(C_word)C_i_not(t12));}}
else{
t8=t6;
f_18425(t8,C_SCHEME_FALSE);}}}

/* k18423 */
static void C_fcall f_18425(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* next3249 */
t2=((C_word*)t0)[7];
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* fail3730 */
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[6]);}}

/* f_18360 in lp in k16646 in k11735 in k12367 in k12360 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_18360(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_18360,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_18367,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t2,a[6]=t1,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
t7=(C_word)C_fix((C_word)C_header_size(t2));
t8=(C_word)C_i_greater_or_equalp(t3,t7);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_18379,a[2]=t6,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t8)){
t10=t9;
f_18379(t10,t8);}
else{
t10=(C_word)C_subchar(t2,t3);
t11=f_5521(t10);
t12=t9;
f_18379(t12,(C_word)C_i_not(t11));}}

/* k18377 */
static void C_fcall f_18379(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_18379,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep((C_word)C_i_greaterp(((C_word*)t0)[4],C_fix(0)))){
t2=(C_word)C_a_i_minus(&a,2,((C_word*)t0)[4],C_fix(1));
t3=(C_word)C_subchar(((C_word*)t0)[3],t2);
/* char-alphanumeric? */
t4=((C_word*)t0)[2];
f_18367(t4,f_5521(t3));}
else{
t2=((C_word*)t0)[2];
f_18367(t2,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[2];
f_18367(t2,C_SCHEME_FALSE);}}

/* k18365 */
static void C_fcall f_18367(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* next3249 */
t2=((C_word*)t0)[7];
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* fail3715 */
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[6]);}}

/* f_18326 in lp in k16646 in k11735 in k12367 in k12360 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_18326(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_18326,6,t0,t1,t2,t3,t4,t5);}
t6=(C_word)C_fix((C_word)C_header_size(t2));
t7=(C_word)C_i_greater_or_equalp(t3,t6);
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_18336,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t2,a[6]=t1,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t7)){
t9=t8;
f_18336(t9,t7);}
else{
t9=(C_word)C_subchar(t2,t3);
t10=t8;
f_18336(t10,(C_word)C_eqp(C_make_character(10),t9));}}

/* k18334 */
static void C_fcall f_18336(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* next3249 */
t2=((C_word*)t0)[7];
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* fail3704 */
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[6]);}}

/* f_18302 in lp in k16646 in k11735 in k12367 in k12360 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_18302(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_18302,6,t0,t1,t2,t3,t4,t5);}
t6=(C_word)C_fix((C_word)C_header_size(t2));
if(C_truep((C_word)C_i_greater_or_equalp(t3,t6))){
/* next3249 */
t7=((C_word*)t0)[2];
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t1,t2,t3,t4,t5);}
else{
/* fail3699 */
t7=t5;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t1);}}

/* f_18244 in lp in k16646 in k11735 in k12367 in k12360 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_18244(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_18244,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_18251,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t2,a[6]=t1,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
t7=(C_word)C_i_zerop(t3);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_18263,a[2]=t6,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t7)){
t9=t8;
f_18263(t9,t7);}
else{
t9=(C_word)C_a_i_minus(&a,2,t3,C_fix(1));
t10=(C_word)C_subchar(t2,t9);
t11=f_5521(t10);
t12=t8;
f_18263(t12,(C_word)C_i_not(t11));}}

/* k18261 */
static void C_fcall f_18263(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_fix((C_word)C_header_size(((C_word*)t0)[4]));
if(C_truep((C_word)C_i_lessp(((C_word*)t0)[3],t2))){
t3=(C_word)C_subchar(((C_word*)t0)[4],((C_word*)t0)[3]);
/* char-alphanumeric? */
t4=((C_word*)t0)[2];
f_18251(t4,f_5521(t3));}
else{
t3=((C_word*)t0)[2];
f_18251(t3,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[2];
f_18251(t2,C_SCHEME_FALSE);}}

/* k18249 */
static void C_fcall f_18251(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* next3249 */
t2=((C_word*)t0)[7];
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* fail3684 */
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[6]);}}

/* f_18210 in lp in k16646 in k11735 in k12367 in k12360 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_18210(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_18210,6,t0,t1,t2,t3,t4,t5);}
t6=(C_word)C_i_zerop(t3);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_18220,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t2,a[6]=t1,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t6)){
t8=t7;
f_18220(t8,t6);}
else{
t8=(C_word)C_a_i_minus(&a,2,t3,C_fix(1));
t9=(C_word)C_subchar(t2,t8);
t10=t7;
f_18220(t10,(C_word)C_eqp(C_make_character(10),t9));}}

/* k18218 */
static void C_fcall f_18220(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* next3249 */
t2=((C_word*)t0)[7];
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* fail3673 */
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[6]);}}

/* f_18190 in lp in k16646 in k11735 in k12367 in k12360 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_18190(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_18190,6,t0,t1,t2,t3,t4,t5);}
if(C_truep((C_word)C_i_zerop(t3))){
/* next3249 */
t6=((C_word*)t0)[2];
((C_proc6)(void*)(*((C_word*)t6+1)))(6,t6,t1,t2,t3,t4,t5);}
else{
/* fail3668 */
t6=t5;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t1);}}

/* f_18148 in lp in k16646 in k11735 in k12367 in k12360 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_18148(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_18148,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_18155,a[2]=t5,a[3]=t4,a[4]=t2,a[5]=t1,a[6]=((C_word*)t0)[2],a[7]=t3,tmp=(C_word)a,a+=8,tmp);
t7=(C_word)C_fix((C_word)C_header_size(t2));
if(C_truep((C_word)C_i_lessp(t3,t7))){
t8=(C_word)C_subchar(t2,t3);
t9=(C_word)C_eqp(C_make_character(10),t8);
t10=t6;
f_18155(t10,(C_word)C_i_not(t9));}
else{
t8=t6;
f_18155(t8,C_SCHEME_FALSE);}}

/* k18153 */
static void C_fcall f_18155(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_18155,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[7],C_fix(1));
/* next3249 */
t3=((C_word*)t0)[6];
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,((C_word*)t0)[5],((C_word*)t0)[4],t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* fail3661 */
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[5]);}}

/* f_18120 in lp in k16646 in k11735 in k12367 in k12360 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_18120(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_18120,6,t0,t1,t2,t3,t4,t5);}
t6=(C_word)C_fix((C_word)C_header_size(t2));
if(C_truep((C_word)C_i_lessp(t3,t6))){
t7=(C_word)C_a_i_plus(&a,2,t3,C_fix(1));
/* next3249 */
t8=((C_word*)t0)[2];
((C_proc6)(void*)(*((C_word*)t8+1)))(6,t8,t1,t2,t7,t4,t5);}
else{
/* fail3656 */
t7=t5;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t1);}}

/* k16704 in lp in k16646 in k11735 in k12367 in k12360 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_fcall f_16706(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word t98;
C_word t99;
C_word t100;
C_word t101;
C_word t102;
C_word t103;
C_word t104;
C_word t105;
C_word t106;
C_word t107;
C_word t108;
C_word t109;
C_word t110;
C_word t111;
C_word t112;
C_word t113;
C_word t114;
C_word t115;
C_word t116;
C_word t117;
C_word t118;
C_word t119;
C_word t120;
C_word t121;
C_word t122;
C_word t123;
C_word t124;
C_word t125;
C_word t126;
C_word t127;
C_word t128;
C_word t129;
C_word t130;
C_word t131;
C_word t132;
C_word t133;
C_word t134;
C_word t135;
C_word t136;
C_word t137;
C_word t138;
C_word t139;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_16706,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_16713,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_16717,a[2]=((C_word*)t0)[8],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* flag-set? */
f_6125(t3,((C_word*)t0)[7],C_fix(2));}
else{
t2=(C_word)C_eqp(((C_word*)t0)[6],lf[70]);
if(C_truep(t2)){
t3=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
t4=(C_word)C_i_length(t3);
switch(t4){
case C_fix(0):
t5=((C_word*)t0)[10];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_16733,tmp=(C_word)a,a+=2,tmp));
case C_fix(1):
t5=(C_word)C_u_i_cadr(((C_word*)t0)[8]);
/* rec3257 */
t6=((C_word*)t0)[5];
f_16663(t6,((C_word*)t0)[10],t5);
default:
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_16753,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
t6=(C_word)C_u_i_cadr(((C_word*)t0)[8]);
/* rec3257 */
t7=((C_word*)t0)[5];
f_16663(t7,t5,t6);}}
else{
t3=(C_word)C_eqp(((C_word*)t0)[6],lf[184]);
if(C_truep(t3)){
t4=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
t5=f_13391(C_a_i(&a,3),t4);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_16812,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[4],a[4]=t5,a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* flag-clear */
t7=lf[55];
f_6144(4,t7,t6,((C_word*)t0)[7],C_fix(2));}
else{
t4=(C_word)C_eqp(((C_word*)t0)[6],lf[185]);
if(C_truep(t4)){
t5=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
t6=f_13391(C_a_i(&a,3),t5);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_16833,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[4],a[4]=t6,a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* flag-join */
t8=lf[54];
f_6135(4,t8,t7,((C_word*)t0)[7],C_fix(2));}
else{
t5=(C_word)C_eqp(((C_word*)t0)[6],lf[118]);
if(C_truep(t5)){
t6=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
t7=f_13391(C_a_i(&a,3),t6);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_16854,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[4],a[4]=t7,a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* flag-join */
t9=lf[54];
f_6135(4,t9,t8,((C_word*)t0)[7],C_fix(32));}
else{
t6=(C_word)C_eqp(((C_word*)t0)[6],lf[119]);
if(C_truep(t6)){
t7=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
t8=f_13391(C_a_i(&a,3),t7);
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_16875,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[4],a[4]=t8,a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* flag-clear */
t10=lf[55];
f_6144(4,t10,t9,((C_word*)t0)[7],C_fix(32));}
else{
t7=(C_word)C_eqp(((C_word*)t0)[6],lf[82]);
t8=(C_truep(t7)?t7:(C_word)C_eqp(((C_word*)t0)[6],lf[186]));
if(C_truep(t8)){
t9=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
t10=(C_word)C_i_length(t9);
switch(t10){
case C_fix(0):
t11=((C_word*)t0)[10];
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,((C_word*)t0)[9]);
case C_fix(1):
t11=(C_word)C_u_i_cadr(((C_word*)t0)[8]);
/* rec3257 */
t12=((C_word*)t0)[5];
f_16663(t12,((C_word*)t0)[10],t11);
default:
t11=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_16913,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t12=(C_word)C_u_i_cddr(((C_word*)t0)[8]);
t13=f_13391(C_a_i(&a,3),t12);
t14=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_16932,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[7],a[4]=t13,a[5]=t11,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
t15=(C_word)C_u_i_cadr(((C_word*)t0)[8]);
/* sre-count-submatches */
f_12296(t14,t15);}}
else{
t9=(C_word)C_eqp(((C_word*)t0)[6],lf[95]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_16953,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
t11=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
t12=f_13391(C_a_i(&a,3),t11);
/* rec3257 */
t13=((C_word*)t0)[5];
f_16663(t13,t10,t12);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[6],lf[96]);
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_16981,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
t12=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
t13=f_13391(C_a_i(&a,3),t12);
/* rec3257 */
t14=((C_word*)t0)[5];
f_16663(t14,t11,t13);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[6],lf[91]);
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_17012,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
t13=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
t14=f_13391(C_a_i(&a,3),t13);
/* sre-empty? */
t15=lf[103];
f_11838(3,t15,t12,t14);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[6],lf[92]);
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_17070,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
t14=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
t15=f_13391(C_a_i(&a,3),t14);
/* sre-empty? */
t16=lf[103];
f_11838(3,t16,t13,t15);}
else{
t13=(C_word)C_eqp(((C_word*)t0)[6],lf[93]);
if(C_truep(t13)){
t14=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
t15=f_13391(C_a_i(&a,3),t14);
t16=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_17133,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[4],a[4]=t15,a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
t17=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
t18=f_13391(C_a_i(&a,3),t17);
t19=(C_word)C_a_i_list(&a,2,lf[91],t18);
/* rec3257 */
t20=((C_word*)t0)[5];
f_16663(t20,t16,t19);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[6],lf[98]);
if(C_truep(t14)){
t15=(C_word)C_u_i_cadr(((C_word*)t0)[8]);
t16=(C_word)C_u_i_cadr(((C_word*)t0)[8]);
t17=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_17182,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[5],a[4]=t15,a[5]=t16,tmp=(C_word)a,a+=6,tmp);
t18=(C_word)C_u_i_cddr(((C_word*)t0)[8]);
/* ##sys#append */
t19=*((C_word*)lf[84]+1);
((C_proc4)(void*)(*((C_word*)t19+1)))(4,t19,t17,t18,C_SCHEME_END_OF_LIST);}
else{
t15=(C_word)C_eqp(((C_word*)t0)[6],lf[99]);
if(C_truep(t15)){
t16=(C_word)C_u_i_cadr(((C_word*)t0)[8]);
t17=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_17215,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[5],a[4]=t16,tmp=(C_word)a,a+=5,tmp);
t18=(C_word)C_u_i_cddr(((C_word*)t0)[8]);
/* ##sys#append */
t19=*((C_word*)lf[84]+1);
((C_proc4)(void*)(*((C_word*)t19+1)))(4,t19,t17,t18,C_SCHEME_END_OF_LIST);}
else{
t16=(C_word)C_eqp(((C_word*)t0)[6],lf[97]);
t17=(C_truep(t16)?t16:(C_word)C_eqp(((C_word*)t0)[6],lf[94]));
if(C_truep(t17)){
t18=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_17234,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
t19=(C_word)C_u_i_cadr(((C_word*)t0)[8]);
if(C_truep((C_word)C_i_numberp(t19))){
t20=(C_word)C_u_i_caddr(((C_word*)t0)[8]);
if(C_truep((C_word)C_i_numberp(t20))){
t21=(C_word)C_u_i_cadr(((C_word*)t0)[8]);
t22=(C_word)C_u_i_caddr(((C_word*)t0)[8]);
t23=t18;
f_17234(t23,(C_word)C_i_greaterp(t21,t22));}
else{
t21=t18;
f_17234(t21,C_SCHEME_FALSE);}}
else{
t20=t18;
f_17234(t20,C_SCHEME_FALSE);}}
else{
t18=(C_word)C_eqp(((C_word*)t0)[6],lf[190]);
if(C_truep(t18)){
t19=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_17421,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t20=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
t21=(C_word)C_a_i_cons(&a,2,lf[148],C_SCHEME_END_OF_LIST);
/* ##sys#append */
t22=*((C_word*)lf[84]+1);
((C_proc4)(void*)(*((C_word*)t22+1)))(4,t22,t19,t20,t21);}
else{
t19=(C_word)C_eqp(((C_word*)t0)[6],lf[191]);
if(C_truep(t19)){
t20=(C_word)C_a_i_cons(&a,2,lf[192],C_SCHEME_END_OF_LIST);
t21=(C_word)C_a_i_cons(&a,2,lf[146],t20);
t22=(C_word)C_a_i_cons(&a,2,lf[70],t21);
t23=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_17486,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[5],a[4]=t22,tmp=(C_word)a,a+=5,tmp);
t24=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
/* ##sys#append */
t25=*((C_word*)lf[84]+1);
((C_proc4)(void*)(*((C_word*)t25+1)))(4,t25,t23,t24,C_SCHEME_END_OF_LIST);}
else{
t20=(C_word)C_eqp(((C_word*)t0)[6],lf[194]);
if(C_truep(t20)){
t21=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_17511,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t22=(C_word)C_u_i_cadr(((C_word*)t0)[8]);
/* string->sre */
t23=*((C_word*)lf[68]+1);
((C_proc3)(void*)(*((C_word*)t23+1)))(3,t23,t21,t22);}
else{
t21=(C_word)C_eqp(((C_word*)t0)[6],lf[78]);
if(C_truep(t21)){
t22=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_17524,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
t23=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
t24=f_13391(C_a_i(&a,3),t23);
t25=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_17547,tmp=(C_word)a,a+=2,tmp);
/* lp3244 */
t26=((C_word*)((C_word*)t0)[3])[1];
f_16660(t26,t22,t24,((C_word*)t0)[4],((C_word*)t0)[7],t25);}
else{
t22=(C_word)C_eqp(((C_word*)t0)[6],lf[79]);
if(C_truep(t22)){
t23=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_17561,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
t24=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
t25=f_13391(C_a_i(&a,3),t24);
t26=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_17584,tmp=(C_word)a,a+=2,tmp);
/* lp3244 */
t27=((C_word*)((C_word*)t0)[3])[1];
f_16660(t27,t23,t25,((C_word*)t0)[4],((C_word*)t0)[7],t26);}
else{
t23=(C_word)C_eqp(((C_word*)t0)[6],lf[80]);
if(C_truep(t23)){
t24=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_17598,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
t25=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
t26=(C_word)C_a_i_cons(&a,2,lf[195],t25);
t27=f_13391(C_a_i(&a,3),t26);
t28=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_17629,tmp=(C_word)a,a+=2,tmp);
/* lp3244 */
t29=((C_word*)((C_word*)t0)[3])[1];
f_16660(t29,t24,t27,((C_word*)t0)[4],((C_word*)t0)[7],t28);}
else{
t24=(C_word)C_eqp(((C_word*)t0)[6],lf[81]);
if(C_truep(t24)){
t25=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_17647,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
t26=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
t27=(C_word)C_a_i_cons(&a,2,lf[196],t26);
t28=f_13391(C_a_i(&a,3),t27);
t29=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_17678,tmp=(C_word)a,a+=2,tmp);
/* lp3244 */
t30=((C_word*)((C_word*)t0)[3])[1];
f_16660(t30,t25,t28,((C_word*)t0)[4],((C_word*)t0)[7],t29);}
else{
t25=(C_word)C_eqp(((C_word*)t0)[6],lf[197]);
if(C_truep(t25)){
t26=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_17696,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
t27=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
t28=f_13391(C_a_i(&a,3),t27);
t29=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_17719,tmp=(C_word)a,a+=2,tmp);
/* lp3244 */
t30=((C_word*)((C_word*)t0)[3])[1];
f_16660(t30,t26,t28,((C_word*)t0)[4],((C_word*)t0)[7],t29);}
else{
t26=(C_word)C_eqp(((C_word*)t0)[6],lf[77]);
if(C_truep(t26)){
t27=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_17733,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[2],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t28=(C_word)C_u_i_cadr(((C_word*)t0)[8]);
/* sre-count-submatches */
f_12296(t27,t28);}
else{
t27=(C_word)C_eqp(((C_word*)t0)[6],lf[156]);
t28=(C_truep(t27)?t27:(C_word)C_eqp(((C_word*)t0)[6],lf[155]));
if(C_truep(t28)){
t29=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_17875,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
t30=(C_word)C_u_i_cadr(((C_word*)t0)[8]);
if(C_truep((C_word)C_i_numberp(t30))){
t31=t29;
f_17875(2,t31,(C_word)C_u_i_cadr(((C_word*)t0)[8]));}
else{
t31=(C_word)C_u_i_cadr(((C_word*)t0)[8]);
t32=(C_word)C_u_i_assq(t31,((C_word*)((C_word*)t0)[2])[1]);
if(C_truep(t32)){
t33=t29;
f_17875(2,t33,(C_word)C_slot(t32,C_fix(1)));}
else{
t33=(C_word)C_u_i_cadr(((C_word*)t0)[8]);
/* error */
t34=*((C_word*)lf[24]+1);
((C_proc4)(void*)(*((C_word*)t34+1)))(4,t34,t29,lf[201],t33);}}}
else{
t29=(C_word)C_eqp(((C_word*)t0)[6],lf[202]);
if(C_truep(t29)){
t30=(C_word)C_u_i_cdddr(((C_word*)t0)[8]);
t31=f_13391(C_a_i(&a,3),t30);
t32=(C_word)C_u_i_cadr(((C_word*)t0)[8]);
t33=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[4],t32);
/* lp3244 */
t34=((C_word*)((C_word*)t0)[3])[1];
f_16660(t34,((C_word*)t0)[10],t31,t33,((C_word*)t0)[7],((C_word*)t0)[9]);}
else{
t30=(C_word)C_eqp(((C_word*)t0)[6],lf[76]);
if(C_truep(t30)){
t31=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_18002,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
t32=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
t33=f_13391(C_a_i(&a,3),t32);
t34=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[4],C_fix(1));
t35=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_18032,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* lp3244 */
t36=((C_word*)((C_word*)t0)[3])[1];
f_16660(t36,t31,t33,t34,((C_word*)t0)[7],t35);}
else{
t31=(C_word)C_eqp(((C_word*)t0)[6],lf[85]);
if(C_truep(t31)){
t32=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_18072,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t33=(C_word)C_u_i_cddr(((C_word*)t0)[8]);
/* ##sys#append */
t34=*((C_word*)lf[84]+1);
((C_proc4)(void*)(*((C_word*)t34+1)))(4,t34,t32,t33,C_SCHEME_END_OF_LIST);}
else{
/* error */
t32=*((C_word*)lf[24]+1);
((C_proc4)(void*)(*((C_word*)t32+1)))(4,t32,((C_word*)t0)[10],lf[203],((C_word*)t0)[8]);}}}}}}}}}}}}}}}}}}}}}}}}}}}}}

/* k18070 in k16704 in lp in k16646 in k11735 in k12367 in k12360 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_18072(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_18072,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[76],t1);
/* rec3257 */
t3=((C_word*)t0)[3];
f_16663(t3,((C_word*)t0)[2],t2);}

/* a18031 in k16704 in lp in k16646 in k11735 in k12367 in k12360 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_18032(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_18032,6,t0,t1,t2,t3,t4,t5);}
t6=f_5105(C_a_i(&a,8),t4,((C_word*)t0)[3]);
t7=f_5133(C_a_i(&a,8),t4,((C_word*)t0)[3],t3);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_18044,a[2]=t5,a[3]=t6,a[4]=((C_word*)t0)[3],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* next3249 */
t9=((C_word*)t0)[2];
((C_proc6)(void*)(*((C_word*)t9+1)))(6,t9,t1,t2,t3,t4,t8);}

/* a18043 in a18031 in k16704 in lp in k16646 in k11735 in k12367 in k12360 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_18044(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_18044,2,t0,t1);}
t2=f_5133(C_a_i(&a,8),((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);
/* fail3624 */
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* k18000 in k16704 in lp in k16646 in k11735 in k12367 in k12360 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_18002(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_18002,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_18003,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp));}

/* f_18003 in k18000 in k16704 in lp in k16646 in k11735 in k12367 in k12360 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_18003(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_18003,6,t0,t1,t2,t3,t4,t5);}
t6=f_5091(C_a_i(&a,8),t4,((C_word*)t0)[3]);
t7=f_5119(C_a_i(&a,8),t4,((C_word*)t0)[3],t3);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_18015,a[2]=t5,a[3]=t6,a[4]=((C_word*)t0)[3],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* body3620 */
t9=((C_word*)t0)[2];
((C_proc6)(void*)(*((C_word*)t9+1)))(6,t9,t1,t2,t3,t4,t8);}

/* a18014 */
static void C_ccall f_18015(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_18015,2,t0,t1);}
t2=f_5119(C_a_i(&a,8),((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);
/* fail3635 */
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* k17873 in k16704 in lp in k16646 in k11735 in k12367 in k12360 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_17875(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_17875,2,t0,t1);}
t2=(C_word)C_u_i_car(((C_word*)t0)[5]);
t3=(C_word)C_eqp(t2,lf[155]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_17931,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t3)){
t5=t4;
f_17931(2,t5,t3);}
else{
/* flag-set? */
f_6125(t4,((C_word*)t0)[2],C_fix(2));}}

/* k17929 in k17873 in k16704 in lp in k16646 in k11735 in k12367 in k12360 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_17931(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_17931,2,t0,t1);}
t2=(C_truep(t1)?*((C_word*)lf[199]+1):*((C_word*)lf[200]+1));
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_17879,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp));}

/* f_17879 in k17929 in k17873 in k16704 in lp in k16646 in k11735 in k12367 in k12360 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_17879(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_17879,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_17883,a[2]=((C_word*)t0)[3],a[3]=t5,a[4]=t4,a[5]=t2,a[6]=t1,a[7]=((C_word*)t0)[4],a[8]=t3,tmp=(C_word)a,a+=9,tmp);
/* irregex-match-substring */
t7=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,t4,((C_word*)t0)[2]);}

/* k17881 */
static void C_ccall f_17883(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_17883,2,t0,t1);}
t2=t1;
if(C_truep(t2)){
t3=(C_word)C_fix((C_word)C_header_size(t1));
t4=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[8],t3);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_17901,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t6=(C_word)C_fix((C_word)C_header_size(((C_word*)t0)[5]));
if(C_truep((C_word)C_i_less_or_equalp(t4,t6))){
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_17917,a[2]=t1,a[3]=t5,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* substring */
t8=*((C_word*)lf[28]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t7,((C_word*)t0)[5],((C_word*)t0)[8],t4);}
else{
t7=t5;
f_17901(2,t7,C_SCHEME_FALSE);}}
else{
/* fail3612 */
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[6]);}}

/* k17915 in k17881 */
static void C_ccall f_17917(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compare3591 */
t2=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k17899 in k17881 */
static void C_ccall f_17901(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* next3249 */
t2=((C_word*)t0)[7];
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* fail3612 */
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[6]);}}

/* k17731 in k16704 in lp in k16646 in k11735 in k12367 in k12360 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_17733(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_17733,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_17736,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=(C_word)C_u_i_caddr(((C_word*)t0)[8]);
t4=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[4],t1);
/* lp3244 */
t5=((C_word*)((C_word*)t0)[5])[1];
f_16660(t5,t2,t3,((C_word*)t0)[3],t4,((C_word*)t0)[2]);}

/* k17734 in k17731 in k16704 in lp in k16646 in k11735 in k12367 in k12360 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_17736(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_17736,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_17739,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=t1,a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
t3=(C_word)C_u_i_cdddr(((C_word*)t0)[9]);
if(C_truep((C_word)C_i_pairp(t3))){
t4=(C_word)C_u_i_cadddr(((C_word*)t0)[9]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_17834,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=t2,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_17838,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_u_i_caddr(((C_word*)t0)[9]);
/* sre-count-submatches */
f_12296(t6,t7);}
else{
t4=t2;
f_17739(2,t4,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_17843,tmp=(C_word)a,a+=2,tmp));}}

/* f_17843 in k17734 in k17731 in k16704 in lp in k16646 in k11735 in k12367 in k12360 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_17843(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_17843,6,t0,t1,t2,t3,t4,t5);}
/* fail3542 */
t6=t5;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t1);}

/* k17836 in k17734 in k17731 in k16704 in lp in k16646 in k11735 in k12367 in k12360 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_17838(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* + */
C_plus(5,0,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k17832 in k17734 in k17731 in k16704 in lp in k16646 in k11735 in k12367 in k12360 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_17834(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp3244 */
t2=((C_word*)((C_word*)t0)[6])[1];
f_16660(t2,((C_word*)t0)[5],((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k17737 in k17734 in k17731 in k16704 in lp in k16646 in k11735 in k12367 in k12360 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_17739(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_17739,2,t0,t1);}
t2=(C_word)C_u_i_cadr(((C_word*)t0)[8]);
t3=(C_word)C_i_numberp(t2);
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_17748,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[8],a[7]=t1,a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp);
if(C_truep(t3)){
t5=t4;
f_17748(t5,t3);}
else{
t5=(C_word)C_u_i_cadr(((C_word*)t0)[8]);
t6=t4;
f_17748(t6,(C_word)C_i_symbolp(t5));}}

/* k17746 in k17737 in k17734 in k17731 in k16704 in lp in k16646 in k11735 in k12367 in k12360 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_fcall f_17748(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_17748,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_17751,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_u_i_cadr(((C_word*)t0)[6]);
if(C_truep((C_word)C_i_symbolp(t3))){
t4=(C_word)C_u_i_cadr(((C_word*)t0)[6]);
t5=(C_word)C_u_i_assq(t4,((C_word*)((C_word*)t0)[5])[1]);
if(C_truep(t5)){
t6=t2;
f_17751(2,t6,(C_word)C_slot(t5,C_fix(1)));}
else{
/* error */
t6=*((C_word*)lf[24]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t2,lf[198],((C_word*)t0)[6]);}}
else{
t4=t2;
f_17751(2,t4,(C_word)C_u_i_cadr(((C_word*)t0)[6]));}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_17794,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_u_i_cadr(((C_word*)t0)[6]);
/* lp3244 */
t4=((C_word*)((C_word*)t0)[4])[1];
f_16660(t4,t2,t3,((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[8]);}}

/* k17792 in k17746 in k17737 in k17734 in k17731 in k16704 in lp in k16646 in k11735 in k12367 in k12360 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_17794(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_17794,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_17795,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp));}

/* f_17795 in k17792 in k17746 in k17737 in k17734 in k17731 in k16704 in lp in k16646 in k11735 in k12367 in k12360 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_17795(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_17795,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_17801,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t2,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* test3576 */
t7=((C_word*)t0)[2];
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t1,t2,t3,t4,t6);}

/* a17800 */
static void C_ccall f_17801(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_17801,2,t0,t1);}
/* fail3538 */
t2=((C_word*)t0)[6];
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,t1,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k17749 in k17746 in k17737 in k17734 in k17731 in k16704 in lp in k16646 in k11735 in k12367 in k12360 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_17751(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_17751,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_17752,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp));}

/* f_17752 in k17749 in k17746 in k17737 in k17734 in k17731 in k16704 in lp in k16646 in k11735 in k12367 in k12360 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_17752(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_17752,6,t0,t1,t2,t3,t4,t5);}
t6=f_5105(C_a_i(&a,8),t4,((C_word*)t0)[4]);
if(C_truep(t6)){
/* pass3536 */
t7=((C_word*)t0)[3];
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t1,t2,t3,t4,t5);}
else{
/* fail3538 */
t7=((C_word*)t0)[2];
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t1,t2,t3,t4,t5);}}

/* a17718 in k16704 in lp in k16646 in k11735 in k12367 in k12360 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_17719(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_17719,6,t0,t1,t2,t3,t4,t5);}
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t3);}

/* k17694 in k16704 in lp in k16646 in k11735 in k12367 in k12360 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_17696(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_17696,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_17697,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp));}

/* f_17697 in k17694 in k16704 in lp in k16646 in k11735 in k12367 in k12360 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_17697(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_17697,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_17701,a[2]=t5,a[3]=t4,a[4]=t2,a[5]=t1,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
t7=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_17712,tmp=(C_word)a,a+=2,tmp);
/* once3518 */
t8=((C_word*)t0)[2];
((C_proc6)(void*)(*((C_word*)t8+1)))(6,t8,t6,t2,t3,t4,t7);}

/* a17711 */
static void C_ccall f_17712(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_17712,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* k17699 */
static void C_ccall f_17701(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* next3249 */
t2=((C_word*)t0)[6];
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[5],((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* fail3528 */
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[5]);}}

/* a17677 in k16704 in lp in k16646 in k11735 in k12367 in k12360 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_17678(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_17678,6,t0,t1,t2,t3,t4,t5);}
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t3);}

/* k17645 in k16704 in lp in k16646 in k11735 in k12367 in k12360 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_17647(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_17647,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_17648,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp));}

/* f_17648 in k17645 in k16704 in lp in k16646 in k11735 in k12367 in k12360 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_17648(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_17648,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_17665,a[2]=t4,a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t5,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_17669,a[2]=t4,a[3]=t6,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* substring */
t8=*((C_word*)lf[28]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t7,t2,C_fix(0),t3);}

/* k17667 */
static void C_ccall f_17669(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_17669,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_17671,tmp=(C_word)a,a+=2,tmp);
/* check3505 */
t3=((C_word*)t0)[4];
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,((C_word*)t0)[3],t1,C_fix(0),((C_word*)t0)[2],t2);}

/* a17670 in k17667 */
static void C_ccall f_17671(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_17671,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* k17663 */
static void C_ccall f_17665(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_eqvp(((C_word*)t0)[7],t1))){
/* fail3515 */
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[5]);}
else{
/* next3249 */
t2=((C_word*)t0)[4];
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[5],((C_word*)t0)[3],((C_word*)t0)[7],((C_word*)t0)[2],((C_word*)t0)[6]);}}

/* a17628 in k16704 in lp in k16646 in k11735 in k12367 in k12360 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_17629(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_17629,6,t0,t1,t2,t3,t4,t5);}
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t3);}

/* k17596 in k16704 in lp in k16646 in k11735 in k12367 in k12360 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_17598(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_17598,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_17599,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp));}

/* f_17599 in k17596 in k16704 in lp in k16646 in k11735 in k12367 in k12360 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_17599(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_17599,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_17616,a[2]=t5,a[3]=t4,a[4]=t2,a[5]=t1,a[6]=((C_word*)t0)[3],a[7]=t3,tmp=(C_word)a,a+=8,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_17620,a[2]=t4,a[3]=t6,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* substring */
t8=*((C_word*)lf[28]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t7,t2,C_fix(0),t3);}

/* k17618 */
static void C_ccall f_17620(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_17620,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_17622,tmp=(C_word)a,a+=2,tmp);
/* check3492 */
t3=((C_word*)t0)[4];
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,((C_word*)t0)[3],t1,C_fix(0),((C_word*)t0)[2],t2);}

/* a17621 in k17618 */
static void C_ccall f_17622(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_17622,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* k17614 */
static void C_ccall f_17616(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_eqvp(((C_word*)t0)[7],t1))){
/* next3249 */
t2=((C_word*)t0)[6];
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[7],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* fail3502 */
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[5]);}}

/* a17583 in k16704 in lp in k16646 in k11735 in k12367 in k12360 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_17584(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_17584,6,t0,t1,t2,t3,t4,t5);}
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t3);}

/* k17559 in k16704 in lp in k16646 in k11735 in k12367 in k12360 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_17561(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_17561,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_17562,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp));}

/* f_17562 in k17559 in k16704 in lp in k16646 in k11735 in k12367 in k12360 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_17562(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_17562,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_17569,a[2]=t4,a[3]=t3,a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=t1,a[7]=t5,tmp=(C_word)a,a+=8,tmp);
t7=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_17577,tmp=(C_word)a,a+=2,tmp);
/* check3479 */
t8=((C_word*)t0)[2];
((C_proc6)(void*)(*((C_word*)t8+1)))(6,t8,t6,t2,t3,t4,t7);}

/* a17576 */
static void C_ccall f_17577(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_17577,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* k17567 */
static void C_ccall f_17569(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* fail3489 */
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[6]);}
else{
/* next3249 */
t2=((C_word*)t0)[5];
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[6],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[7]);}}

/* a17546 in k16704 in lp in k16646 in k11735 in k12367 in k12360 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_17547(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_17547,6,t0,t1,t2,t3,t4,t5);}
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t3);}

/* k17522 in k16704 in lp in k16646 in k11735 in k12367 in k12360 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_17524(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_17524,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_17525,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp));}

/* f_17525 in k17522 in k16704 in lp in k16646 in k11735 in k12367 in k12360 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_17525(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_17525,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_17532,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t2,a[6]=t1,a[7]=((C_word*)t0)[3],tmp=(C_word)a,a+=8,tmp);
t7=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_17540,tmp=(C_word)a,a+=2,tmp);
/* check3466 */
t8=((C_word*)t0)[2];
((C_proc6)(void*)(*((C_word*)t8+1)))(6,t8,t6,t2,t3,t4,t7);}

/* a17539 */
static void C_ccall f_17540(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_17540,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* k17530 */
static void C_ccall f_17532(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* next3249 */
t2=((C_word*)t0)[7];
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* fail3476 */
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[6]);}}

/* k17509 in k16704 in lp in k16646 in k11735 in k12367 in k12360 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_17511(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* rec3257 */
t2=((C_word*)t0)[3];
f_16663(t2,((C_word*)t0)[2],t1);}

/* k17484 in k16704 in lp in k16646 in k11735 in k12367 in k12360 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_17486(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_17486,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[70],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t3);
t5=(C_word)C_a_i_cons(&a,2,lf[193],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,lf[93],t6);
t8=(C_word)C_a_i_cons(&a,2,lf[148],C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,t7,t8);
t10=(C_word)C_a_i_cons(&a,2,lf[149],t9);
t11=(C_word)C_a_i_cons(&a,2,lf[82],t10);
/* rec3257 */
t12=((C_word*)t0)[3];
f_16663(t12,((C_word*)t0)[2],t11);}

/* k17419 in k16704 in lp in k16646 in k11735 in k12367 in k12360 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_17421(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_17421,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[149],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[82],t2);
/* rec3257 */
t4=((C_word*)t0)[3];
f_16663(t4,((C_word*)t0)[2],t3);}

/* k17232 in k16704 in lp in k16646 in k11735 in k12367 in k12360 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_fcall f_17234(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_17234,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_17237,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t1)){
t3=t2;
f_17237(t3,t1);}
else{
t3=(C_word)C_u_i_cadr(((C_word*)t0)[7]);
t4=t2;
f_17237(t4,(C_truep(t3)?C_SCHEME_FALSE:(C_word)C_u_i_caddr(((C_word*)t0)[7])));}}

/* k17235 in k17232 in k16704 in lp in k16646 in k11735 in k12367 in k12360 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_fcall f_17237(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_17237,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_17238,tmp=(C_word)a,a+=2,tmp));}
else{
t2=(C_word)C_u_i_cadr(((C_word*)t0)[7]);
t3=(C_word)C_u_i_caddr(((C_word*)t0)[7]);
t4=(C_word)C_u_i_car(((C_word*)t0)[7]);
t5=(C_word)C_eqp(lf[97],t4);
t6=(C_truep(t5)?lf[95]:lf[96]);
t7=(C_word)C_u_i_car(((C_word*)t0)[7]);
t8=(C_word)C_eqp(lf[97],t7);
t9=(C_truep(t8)?lf[91]:lf[92]);
t10=(C_word)C_u_i_cdddr(((C_word*)t0)[7]);
t11=f_13391(C_a_i(&a,3),t10);
t12=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_17260,a[2]=((C_word*)t0)[2],a[3]=t9,a[4]=t6,a[5]=((C_word*)t0)[3],a[6]=t3,a[7]=t11,a[8]=((C_word*)t0)[4],a[9]=((C_word*)t0)[5],a[10]=((C_word*)t0)[6],a[11]=((C_word*)t0)[8],a[12]=t2,tmp=(C_word)a,a+=13,tmp);
/* sre-strip-submatches */
t13=lf[189];
f_13441(3,t13,t12,t11);}}

/* k17258 in k17235 in k17232 in k16704 in lp in k16646 in k11735 in k12367 in k12360 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_17260(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_17260,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_17263,a[2]=t1,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[12],tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)t0)[6])){
if(C_truep((C_word)C_i_nequalp(((C_word*)t0)[12],((C_word*)t0)[6]))){
t3=t2;
f_17263(2,t3,((C_word*)t0)[5]);}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_17310,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_17326,a[2]=((C_word*)t0)[5],a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_a_i_minus(&a,2,((C_word*)t0)[6],((C_word*)t0)[12]);
/* zero-to */
f_5623(t4,t5);}}
else{
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t3);
/* rec3257 */
t5=((C_word*)t0)[2];
f_16663(t5,t2,t4);}}

/* k17324 in k17258 in k17235 in k17232 in k16704 in lp in k16646 in k11735 in k12367 in k12360 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_17326(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* fold */
f_5889(((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a17309 in k17258 in k17235 in k17232 in k16704 in lp in k16646 in k11735 in k12367 in k12360 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_17310(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_17310,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t4);
/* lp3244 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_16660(t6,t1,t5,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* k17261 in k17258 in k17235 in k17232 in k16704 in lp in k16646 in k11735 in k12367 in k12360 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_17263(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_17263,2,t0,t1);}
if(C_truep((C_word)C_i_zerop(((C_word*)t0)[8]))){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_17280,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_17284,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_17290,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_17295,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_a_i_minus(&a,2,((C_word*)t0)[8],C_fix(1));
/* zero-to */
f_5623(t5,t6);}}

/* k17293 in k17261 in k17258 in k17235 in k17232 in k16704 in lp in k16646 in k11735 in k12367 in k12360 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_17295(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a17289 in k17261 in k17258 in k17235 in k17232 in k16704 in lp in k16646 in k11735 in k12367 in k12360 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_17290(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_17290,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[2]);}

/* k17282 in k17261 in k17258 in k17235 in k17232 in k16704 in lp in k16646 in k11735 in k12367 in k12360 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_17284(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_17284,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
/* ##sys#append */
t3=*((C_word*)lf[84]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t1,t2);}

/* k17278 in k17261 in k17258 in k17235 in k17232 in k16704 in lp in k16646 in k11735 in k12367 in k12360 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_17280(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_17280,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[82],t1);
/* lp3244 */
t3=((C_word*)((C_word*)t0)[6])[1];
f_16660(t3,((C_word*)t0)[5],t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* f_17238 in k17235 in k17232 in k16704 in lp in k16646 in k11735 in k12367 in k12360 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_17238(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_17238,6,t0,t1,t2,t3,t4,t5);}
/* fail3423 */
t6=t5;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t1);}

/* k17213 in k16704 in lp in k16646 in k11735 in k12367 in k12360 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_17215(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_17215,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=(C_word)C_a_i_cons(&a,2,lf[97],t3);
/* rec3257 */
t5=((C_word*)t0)[3];
f_16663(t5,((C_word*)t0)[2],t4);}

/* k17180 in k16704 in lp in k16646 in k11735 in k12367 in k12360 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_17182(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_17182,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=(C_word)C_a_i_cons(&a,2,lf[97],t3);
/* rec3257 */
t5=((C_word*)t0)[3];
f_16663(t5,((C_word*)t0)[2],t4);}

/* k17131 in k16704 in lp in k16646 in k11735 in k12367 in k12360 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_17133(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp3244 */
t2=((C_word*)((C_word*)t0)[6])[1];
f_16660(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k17068 in k16704 in lp in k16646 in k11735 in k12367 in k12360 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_17070(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_17070,2,t0,t1);}
if(C_truep(t1)){
/* error */
t2=*((C_word*)lf[24]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[7],lf[188],((C_word*)t0)[6]);}
else{
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_17077,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[7],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t6=f_13391(C_a_i(&a,3),t5);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_17094,a[2]=((C_word*)t0)[5],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* lp3244 */
t8=((C_word*)((C_word*)t0)[4])[1];
f_16660(t8,t4,t6,((C_word*)t0)[3],((C_word*)t0)[2],t7);}}

/* a17093 in k17068 in k16704 in lp in k16646 in k11735 in k12367 in k12360 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_17094(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_17094,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_17100,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t2,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* next3249 */
t7=((C_word*)t0)[2];
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t1,t2,t3,t4,t6);}

/* a17099 in a17093 in k17068 in k16704 in lp in k16646 in k11735 in k12367 in k12360 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_17100(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_17100,2,t0,t1);}
/* body3371 */
t2=((C_word*)((C_word*)t0)[6])[1];
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,t1,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k17075 in k17068 in k16704 in lp in k16646 in k11735 in k12367 in k12360 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_17077(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_17077,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_17078,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp));}

/* f_17078 in k17075 in k17068 in k16704 in lp in k16646 in k11735 in k12367 in k12360 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_17078(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_17078,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_17084,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t2,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* next3249 */
t7=((C_word*)t0)[2];
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t1,t2,t3,t4,t6);}

/* a17083 */
static void C_ccall f_17084(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_17084,2,t0,t1);}
/* body3371 */
t2=((C_word*)((C_word*)t0)[6])[1];
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,t1,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k17010 in k16704 in lp in k16646 in k11735 in k12367 in k12360 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_17012(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_17012,2,t0,t1);}
if(C_truep(t1)){
/* error */
t2=*((C_word*)lf[24]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[7],lf[187],((C_word*)t0)[6]);}
else{
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_17019,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[7],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t6=f_13391(C_a_i(&a,3),t5);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_17036,a[2]=t3,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* lp3244 */
t8=((C_word*)((C_word*)t0)[4])[1];
f_16660(t8,t4,t6,((C_word*)t0)[3],((C_word*)t0)[2],t7);}}

/* a17035 in k17010 in k16704 in lp in k16646 in k11735 in k12367 in k12360 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_17036(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_17036,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_17042,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t2,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* body3348 */
t7=((C_word*)((C_word*)t0)[2])[1];
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t1,t2,t3,t4,t6);}

/* a17041 in a17035 in k17010 in k16704 in lp in k16646 in k11735 in k12367 in k12360 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_17042(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_17042,2,t0,t1);}
/* next3249 */
t2=((C_word*)t0)[6];
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,t1,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k17017 in k17010 in k16704 in lp in k16646 in k11735 in k12367 in k12360 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_17019(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_17019,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_17020,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp));}

/* f_17020 in k17017 in k17010 in k16704 in lp in k16646 in k11735 in k12367 in k12360 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_17020(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_17020,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_17026,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t2,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* body3348 */
t7=((C_word*)((C_word*)t0)[2])[1];
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t1,t2,t3,t4,t6);}

/* a17025 */
static void C_ccall f_17026(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_17026,2,t0,t1);}
/* next3249 */
t2=((C_word*)t0)[6];
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,t1,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k16979 in k16704 in lp in k16646 in k11735 in k12367 in k12360 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_16981(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_16981,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_16982,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp));}

/* f_16982 in k16979 in k16704 in lp in k16646 in k11735 in k12367 in k12360 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_16982(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_16982,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_16988,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t2,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* next3249 */
t7=((C_word*)t0)[2];
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t1,t2,t3,t4,t6);}

/* a16987 */
static void C_ccall f_16988(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_16988,2,t0,t1);}
/* body3333 */
t2=((C_word*)t0)[6];
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,t1,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k16951 in k16704 in lp in k16646 in k11735 in k12367 in k12360 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_16953(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_16953,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_16954,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp));}

/* f_16954 in k16951 in k16704 in lp in k16646 in k11735 in k12367 in k12360 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_16954(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_16954,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_16960,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t2,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* body3325 */
t7=((C_word*)t0)[2];
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t1,t2,t3,t4,t6);}

/* a16959 */
static void C_ccall f_16960(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_16960,2,t0,t1);}
/* next3249 */
t2=((C_word*)t0)[6];
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,t1,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k16930 in k16704 in lp in k16646 in k11735 in k12367 in k12360 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_16932(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_16932,2,t0,t1);}
t2=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[7],t1);
/* lp3244 */
t3=((C_word*)((C_word*)t0)[6])[1];
f_16660(t3,((C_word*)t0)[5],((C_word*)t0)[4],t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k16911 in k16704 in lp in k16646 in k11735 in k12367 in k12360 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_16913(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_i_cadr(((C_word*)t0)[6]);
/* lp3244 */
t3=((C_word*)((C_word*)t0)[5])[1];
f_16660(t3,((C_word*)t0)[4],t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k16873 in k16704 in lp in k16646 in k11735 in k12367 in k12360 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_16875(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp3244 */
t2=((C_word*)((C_word*)t0)[6])[1];
f_16660(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k16852 in k16704 in lp in k16646 in k11735 in k12367 in k12360 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_16854(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp3244 */
t2=((C_word*)((C_word*)t0)[6])[1];
f_16660(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k16831 in k16704 in lp in k16646 in k11735 in k12367 in k12360 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_16833(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp3244 */
t2=((C_word*)((C_word*)t0)[6])[1];
f_16660(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k16810 in k16704 in lp in k16646 in k11735 in k12367 in k12360 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_16812(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp3244 */
t2=((C_word*)((C_word*)t0)[6])[1];
f_16660(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k16751 in k16704 in lp in k16646 in k11735 in k12367 in k12360 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_16753(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_16753,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_16756,a[2]=t1,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_u_i_cddr(((C_word*)t0)[6]);
t4=f_13416(C_a_i(&a,3),t3);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_16779,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=t2,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t6=(C_word)C_u_i_cadr(((C_word*)t0)[6]);
/* sre-count-submatches */
f_12296(t5,t6);}

/* k16777 in k16751 in k16704 in lp in k16646 in k11735 in k12367 in k12360 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_16779(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_16779,2,t0,t1);}
t2=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[7],t1);
/* lp3244 */
t3=((C_word*)((C_word*)t0)[6])[1];
f_16660(t3,((C_word*)t0)[5],((C_word*)t0)[4],t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k16754 in k16751 in k16704 in lp in k16646 in k11735 in k12367 in k12360 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_16756(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_16756,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_16757,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp));}

/* f_16757 in k16754 in k16751 in k16704 in lp in k16646 in k11735 in k12367 in k12360 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_16757(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_16757,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_16763,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t2,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* first3299 */
t7=((C_word*)t0)[2];
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t1,t2,t3,t4,t6);}

/* a16762 */
static void C_ccall f_16763(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_16763,2,t0,t1);}
/* rest3301 */
t2=((C_word*)t0)[6];
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,t1,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* f_16733 in k16704 in lp in k16646 in k11735 in k12367 in k12360 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_16733(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_16733,6,t0,t1,t2,t3,t4,t5);}
/* fail3296 */
t6=t5;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t1);}

/* k16715 in k16704 in lp in k16646 in k11735 in k12367 in k12360 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_16717(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_16717,2,t0,t1);}
/* sre->cset */
f_18742(((C_word*)t0)[3],((C_word*)t0)[2],(C_word)C_a_i_list(&a,1,t1));}

/* k16711 in k16704 in lp in k16646 in k11735 in k12367 in k12360 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_16713(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* sre-cset->procedure */
f_18625(((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k16692 in lp in k16646 in k11735 in k12367 in k12360 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_16694(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_16694,2,t0,t1);}
/* sre->cset */
f_18742(((C_word*)t0)[3],((C_word*)t0)[2],(C_word)C_a_i_list(&a,1,t1));}

/* k16684 in lp in k16646 in k11735 in k12367 in k12360 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_16686(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* sre-cset->procedure */
f_18625(((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* rec in lp in k16646 in k11735 in k12367 in k12360 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_fcall f_16663(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_16663,NULL,3,t0,t1,t2);}
/* lp3244 */
t3=((C_word*)((C_word*)t0)[5])[1];
f_16660(t3,t1,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a16656 in k16646 in k11735 in k12367 in k12360 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_16657(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_16657,6,t0,t1,t2,t3,t4,t5);}
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t3);}

/* k11744 in k11735 in k12367 in k12360 in k12357 in k11729 in k11726 in k11723 in k11720 in k11717 in k11714 in k11711 in k11708 in k11705 in k11702 in k11699 in sre->irregex in k4869 */
static void C_ccall f_11746(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11746,2,t0,t1);}
/* make-irregex */
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,f_4874(C_a_i(&a,10),C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE,t1,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]));}

/* string->irregex in k4869 */
static void C_ccall f_11687(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_11687r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_11687r(t0,t1,t2,t3);}}

static void C_ccall f_11687r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11695,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_apply(5,0,t4,*((C_word*)lf[68]+1),t2,t3);}

/* k11693 in string->irregex in k4869 */
static void C_ccall f_11695(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(5,0,((C_word*)t0)[3],*((C_word*)lf[181]+1),t1,((C_word*)t0)[2]);}

/* irregex in k4869 */
static void C_ccall f_11666(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_11666r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_11666r(t0,t1,t2,t3);}}

static void C_ccall f_11666r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11673,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* irregex? */
t5=*((C_word*)lf[2]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k11671 in irregex in k4869 */
static void C_ccall f_11673(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}
else{
if(C_truep((C_word)C_i_stringp(((C_word*)t0)[3]))){
C_apply(5,0,((C_word*)t0)[4],*((C_word*)lf[180]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
C_apply(5,0,((C_word*)t0)[4],*((C_word*)lf[181]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}}}

/* cset->utf8-pattern in k4869 */
static void C_fcall f_11216(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11216,NULL,2,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11222,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_11222(t6,t1,t2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}

/* lp in cset->utf8-pattern in k4869 */
static void C_fcall f_11222(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11222,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11236,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11240,a[2]=t4,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* reverse */
t7=*((C_word*)lf[40]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t3);}
else{
t5=(C_word)C_u_i_car(t2);
if(C_truep((C_word)C_charp(t5))){
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11270,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t3,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t7=(C_word)C_u_i_car(t2);
/* high-char? */
t8=lf[128];
f_9937(3,t8,t6,t7);}
else{
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11310,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t3,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t7=(C_word)C_u_i_caar(t2);
/* high-char? */
t8=lf[128];
f_9937(3,t8,t6,t7);}}}

/* k11308 in lp in cset->utf8-pattern in k4869 */
static void C_ccall f_11310(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11310,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11313,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t1)){
t3=t2;
f_11313(2,t3,t1);}
else{
t3=(C_word)C_u_i_cdar(((C_word*)t0)[6]);
/* high-char? */
t4=lf[128];
f_9937(3,t4,t2,t3);}}

/* k11311 in k11308 in lp in cset->utf8-pattern in k4869 */
static void C_ccall f_11313(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11313,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11328,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_u_i_caar(((C_word*)t0)[6]);
t5=(C_word)C_u_i_cdar(((C_word*)t0)[6]);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10375,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* char->utf8-list */
f_10242(t6,t4);}
else{
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t3=(C_word)C_u_i_cdar(((C_word*)t0)[6]);
t4=(C_word)C_u_i_caar(((C_word*)t0)[6]);
t5=(C_word)C_a_i_cons(&a,2,t4,((C_word*)t0)[2]);
t6=(C_word)C_a_i_cons(&a,2,t3,t5);
/* lp1483 */
t7=((C_word*)((C_word*)t0)[4])[1];
f_11222(t7,((C_word*)t0)[3],t2,((C_word*)t0)[5],t6);}}

/* k10373 in k11311 in k11308 in lp in cset->utf8-pattern in k4869 */
static void C_ccall f_10375(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10375,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10378,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* char->utf8-list */
f_10242(t2,((C_word*)t0)[2]);}

/* k10376 in k10373 in k11311 in k11308 in lp in cset->utf8-pattern in k4869 */
static void C_ccall f_10378(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10378,2,t0,t1);}
t2=(C_word)C_i_length(((C_word*)t0)[3]);
t3=(C_word)C_i_length(t1);
if(C_truep((C_word)C_i_nequalp(t2,t3))){
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10404,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_10404(t7,((C_word*)t0)[2],((C_word*)t0)[3],t1);}
else{
t4=((C_word*)t0)[3];
t5=t1;
t6=(C_word)C_i_length(t4);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10871,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t8=(C_word)C_u_i_car(t4);
t9=(C_word)C_make_character((C_word)C_unfix(t8));
t10=(C_word)C_u_i_car(t4);
t11=(C_word)C_i_less_or_equalp(t10,C_fix(127));
t12=(C_truep(t11)?C_fix(127):C_fix(255));
t13=(C_word)C_make_character((C_word)C_unfix(t12));
t14=(C_word)C_a_i_cons(&a,2,t13,C_SCHEME_END_OF_LIST);
t15=(C_word)C_a_i_cons(&a,2,t9,t14);
t16=(C_word)C_a_i_cons(&a,2,lf[31],t15);
t17=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11077,a[2]=t6,a[3]=t7,a[4]=t5,a[5]=t16,tmp=(C_word)a,a+=6,tmp);
t18=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11079,tmp=(C_word)a,a+=2,tmp);
t19=(C_word)C_slot(t4,C_fix(1));
/* map */
t20=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t20+1)))(4,t20,t17,t18,t19);}}

/* a11078 in k10376 in k10373 in k11311 in k11308 in lp in cset->utf8-pattern in k4869 */
static void C_ccall f_11079(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11079,3,t0,t1,t2);}
t3=(C_word)C_a_i_cons(&a,2,C_make_character(255),C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,C_make_character(128),t3);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,lf[31],t4));}

/* k11075 in k10376 in k10373 in k11311 in k11308 in lp in cset->utf8-pattern in k4869 */
static void C_ccall f_11077(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11077,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=f_13391(C_a_i(&a,3),t2);
t4=(C_word)C_a_i_list(&a,1,t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10879,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10971,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11053,a[2]=t6,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11057,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
t9=(C_word)C_i_length(((C_word*)t0)[4]);
/* - */
C_minus(5,0,t8,t9,((C_word*)t0)[2],C_fix(1));}

/* k11055 in k11075 in k10376 in k10373 in k11311 in k11308 in lp in cset->utf8-pattern in k4869 */
static void C_ccall f_11057(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* zero-to */
f_5623(((C_word*)t0)[2],t1);}

/* k11051 in k11075 in k10376 in k10373 in k11311 in k11308 in lp in cset->utf8-pattern in k4869 */
static void C_ccall f_11053(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a10970 in k11075 in k10376 in k10373 in k11311 in k11308 in lp in cset->utf8-pattern in k4869 */
static void C_ccall f_10971(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10971,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11045,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11049,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* + */
C_plus(5,0,t4,t2,((C_word*)t0)[2],C_fix(1));}

/* k11047 in a10970 in k11075 in k10376 in k10373 in k11311 in k11308 in lp in cset->utf8-pattern in k4869 */
static void C_ccall f_11049(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utf8-lowest-digit-of-length */
f_10182(((C_word*)t0)[2],t1);}

/* k11043 in a10970 in k11075 in k10376 in k10373 in k11311 in k11308 in lp in cset->utf8-pattern in k4869 */
static void C_ccall f_11045(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11045,2,t0,t1);}
t2=(C_word)C_make_character((C_word)C_unfix(t1));
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11037,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11041,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* + */
C_plus(5,0,t4,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(1));}

/* k11039 in k11043 in a10970 in k11075 in k10376 in k10373 in k11311 in k11308 in lp in cset->utf8-pattern in k4869 */
static void C_ccall f_11041(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
switch(t1){
case C_fix(1):
t2=((C_word*)t0)[2];
f_11037(2,t2,C_fix(127));
case C_fix(2):
t2=((C_word*)t0)[2];
f_11037(2,t2,C_fix(223));
case C_fix(3):
t2=((C_word*)t0)[2];
f_11037(2,t2,C_fix(239));
case C_fix(4):
t2=((C_word*)t0)[2];
f_11037(2,t2,C_fix(247));
default:
/* error */
t2=*((C_word*)lf[24]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[178],t1);}}

/* k11035 in k11043 in a10970 in k11075 in k10376 in k10373 in k11311 in k11308 in lp in cset->utf8-pattern in k4869 */
static void C_ccall f_11037(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11037,2,t0,t1);}
t2=(C_word)C_make_character((C_word)C_unfix(t1));
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t3);
t5=(C_word)C_a_i_cons(&a,2,lf[31],t4);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10987,a[2]=((C_word*)t0)[4],a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10989,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11013,a[2]=t7,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t9=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]);
/* zero-to */
f_5623(t8,t9);}

/* k11011 in k11035 in k11043 in a10970 in k11075 in k10376 in k10373 in k11311 in k11308 in lp in cset->utf8-pattern in k4869 */
static void C_ccall f_11013(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a10988 in k11035 in k11043 in a10970 in k11075 in k10376 in k10373 in k11311 in k11308 in lp in cset->utf8-pattern in k4869 */
static void C_ccall f_10989(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10989,3,t0,t1,t2);}
t3=(C_word)C_a_i_cons(&a,2,C_make_character(255),C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,C_make_character(128),t3);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,lf[31],t4));}

/* k10985 in k11035 in k11043 in a10970 in k11075 in k10376 in k10373 in k11311 in k11308 in lp in cset->utf8-pattern in k4869 */
static void C_ccall f_10987(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10987,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
/* sre-sequence */
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,f_13391(C_a_i(&a,3),t2));}

/* k10877 in k11075 in k10376 in k10373 in k11311 in k11308 in lp in cset->utf8-pattern in k4869 */
static void C_ccall f_10879(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10879,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10953,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_u_i_car(((C_word*)t0)[4]);
t4=(C_word)C_a_i_minus(&a,2,t3,C_fix(1));
t5=(C_word)C_make_character((C_word)C_unfix(t4));
t6=f_9947(t5);
/* utf8-lowest-digit-of-length */
f_10182(t2,t6);}

/* k10951 in k10877 in k11075 in k10376 in k10373 in k11311 in k11308 in lp in cset->utf8-pattern in k4869 */
static void C_ccall f_10953(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10953,2,t0,t1);}
t2=(C_word)C_make_character((C_word)C_unfix(t1));
t3=(C_word)C_u_i_car(((C_word*)t0)[5]);
t4=(C_word)C_a_i_minus(&a,2,t3,C_fix(1));
t5=(C_word)C_make_character((C_word)C_unfix(t4));
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,t2,t6);
t8=(C_word)C_a_i_cons(&a,2,lf[31],t7);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10899,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t8,tmp=(C_word)a,a+=6,tmp);
t10=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10901,tmp=(C_word)a,a+=2,tmp);
t11=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* map */
t12=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t9,t10,t11);}

/* a10900 in k10951 in k10877 in k11075 in k10376 in k10373 in k11311 in k11308 in lp in cset->utf8-pattern in k4869 */
static void C_ccall f_10901(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10901,3,t0,t1,t2);}
t3=(C_word)C_a_i_cons(&a,2,C_make_character(255),C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,C_make_character(128),t3);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,lf[31],t4));}

/* k10897 in k10951 in k10877 in k11075 in k10376 in k10373 in k11311 in k11308 in lp in cset->utf8-pattern in k4869 */
static void C_ccall f_10899(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10899,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=f_13391(C_a_i(&a,3),t2);
t4=(C_word)C_a_i_list(&a,1,t3);
/* append */
t5=*((C_word*)lf[125]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t4);}

/* k10869 in k10376 in k10373 in k11311 in k11308 in lp in cset->utf8-pattern in k4869 */
static void C_ccall f_10871(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10871,2,t0,t1);}
t2=f_13416(C_a_i(&a,3),t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10399,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* unicode-range-up-to */
f_10732(t3,((C_word*)t0)[2]);}

/* k10397 in k10869 in k10376 in k10373 in k11311 in k11308 in lp in cset->utf8-pattern in k4869 */
static void C_ccall f_10399(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10399,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
/* sre-alternate */
t3=((C_word*)t0)[2];
f_11328(2,t3,f_13416(C_a_i(&a,3),t2));}

/* lp in k10376 in k10373 in k11311 in k11308 in lp in cset->utf8-pattern in k4869 */
static void C_fcall f_10404(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word *a;
loop:
a=C_alloc(9);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_10404,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t4=(C_word)C_u_i_car(t2);
t5=(C_word)C_u_i_car(t3);
if(C_truep((C_word)C_i_nequalp(t4,t5))){
t6=(C_word)C_u_i_car(t2);
t7=(C_word)C_make_character((C_word)C_unfix(t6));
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10432,a[2]=t1,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
t9=(C_word)C_slot(t2,C_fix(1));
t10=(C_word)C_slot(t3,C_fix(1));
/* lp1369 */
t17=t8;
t18=t9;
t19=t10;
t1=t17;
t2=t18;
t3=t19;
goto loop;}
else{
t6=(C_word)C_u_i_car(t2);
t7=(C_word)C_a_i_plus(&a,2,t6,C_fix(1));
t8=(C_word)C_u_i_car(t3);
if(C_truep((C_word)C_i_nequalp(t7,t8))){
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10461,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* unicode-range-up-from */
f_10604(t9,t2);}
else{
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10476,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* unicode-range-up-from */
f_10604(t9,t2);}}}}

/* k10474 in lp in k10376 in k10373 in k11311 in k11308 in lp in cset->utf8-pattern in k4869 */
static void C_ccall f_10476(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10476,2,t0,t1);}
t2=((C_word*)t0)[4];
t3=((C_word*)t0)[3];
t4=(C_word)C_u_i_car(t2);
t5=(C_word)C_a_i_plus(&a,2,t4,C_fix(1));
t6=(C_word)C_make_character((C_word)C_unfix(t5));
t7=(C_word)C_u_i_car(t3);
t8=(C_word)C_a_i_minus(&a,2,t7,C_fix(1));
t9=(C_word)C_make_character((C_word)C_unfix(t8));
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11154,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[2],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t11=(C_word)C_eqp(t6,t9);
if(C_truep(t11)){
t12=t10;
f_11154(t12,t6);}
else{
t12=(C_word)C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST);
t13=(C_word)C_a_i_cons(&a,2,t6,t12);
t14=t10;
f_11154(t14,(C_word)C_a_i_cons(&a,2,lf[31],t13));}}

/* k11152 in k10474 in lp in k10376 in k10373 in k11311 in k11308 in lp in cset->utf8-pattern in k4869 */
static void C_fcall f_11154(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11154,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11158,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11160,tmp=(C_word)a,a+=2,tmp);
t4=(C_word)C_slot(((C_word*)t0)[2],C_fix(1));
/* map */
t5=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,t3,t4);}

/* a11159 in k11152 in k10474 in lp in k10376 in k10373 in k11311 in k11308 in lp in cset->utf8-pattern in k4869 */
static void C_ccall f_11160(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11160,3,t0,t1,t2);}
t3=(C_word)C_a_i_cons(&a,2,C_make_character(255),C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,C_make_character(128),t3);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,lf[31],t4));}

/* k11156 in k11152 in k10474 in lp in k10376 in k10373 in k11311 in k11308 in lp in cset->utf8-pattern in k4869 */
static void C_ccall f_11158(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11158,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=f_13391(C_a_i(&a,3),t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10484,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* unicode-range-up-to */
f_10732(t4,((C_word*)t0)[2]);}

/* k10482 in k11156 in k11152 in k10474 in lp in k10376 in k10373 in k11311 in k11308 in lp in cset->utf8-pattern in k4869 */
static void C_ccall f_10484(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10484,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,((C_word*)t0)[4],((C_word*)t0)[3],t1);
/* sre-alternate */
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,f_13416(C_a_i(&a,3),t2));}

/* k10459 in lp in k10376 in k10373 in k11311 in k11308 in lp in cset->utf8-pattern in k4869 */
static void C_ccall f_10461(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10461,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10465,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* unicode-range-up-to */
f_10732(t2,((C_word*)t0)[2]);}

/* k10463 in k10459 in lp in k10376 in k10373 in k11311 in k11308 in lp in cset->utf8-pattern in k4869 */
static void C_ccall f_10465(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10465,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
/* sre-alternate */
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,f_13416(C_a_i(&a,3),t2));}

/* k10430 in lp in k10376 in k10373 in k11311 in k11308 in lp in cset->utf8-pattern in k4869 */
static void C_ccall f_10432(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10432,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
/* sre-sequence */
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,f_13391(C_a_i(&a,3),t2));}

/* k11326 in k11311 in k11308 in lp in cset->utf8-pattern in k4869 */
static void C_ccall f_11328(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11328,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[6]);
/* lp1483 */
t3=((C_word*)((C_word*)t0)[5])[1];
f_11222(t3,((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k11268 in lp in cset->utf8-pattern in k4869 */
static void C_ccall f_11270(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11270,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t3=(C_word)C_u_i_car(((C_word*)t0)[6]);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[5]);
/* lp1483 */
t5=((C_word*)((C_word*)t0)[4])[1];
f_11222(t5,((C_word*)t0)[3],t2,t4,((C_word*)t0)[2]);}
else{
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t3=(C_word)C_u_i_car(((C_word*)t0)[6]);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[2]);
/* lp1483 */
t5=((C_word*)((C_word*)t0)[4])[1];
f_11222(t5,((C_word*)t0)[3],t2,((C_word*)t0)[5],t4);}}

/* k11238 in lp in cset->utf8-pattern in k4869 */
static void C_ccall f_11240(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11240,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11244,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[2]))){
t3=t2;
f_11244(t3,C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11258,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* reverse */
t4=*((C_word*)lf[40]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}}

/* k11256 in k11238 in lp in cset->utf8-pattern in k4869 */
static void C_ccall f_11258(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11258,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[31],t1);
t3=((C_word*)t0)[2];
f_11244(t3,(C_word)C_a_i_list(&a,1,t2));}

/* k11242 in k11238 in lp in cset->utf8-pattern in k4869 */
static void C_fcall f_11244(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* append */
t2=*((C_word*)lf[125]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k11234 in lp in cset->utf8-pattern in k4869 */
static void C_ccall f_11236(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11236,2,t0,t1);}
/* sre-alternate */
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,f_13416(C_a_i(&a,3),t1));}

/* unicode-range-up-to in k4869 */
static void C_fcall f_10732(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10732,NULL,2,t1,t2);}
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_make_character((C_word)C_unfix(t3));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10752,a[2]=t1,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10754,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10850,a[2]=t2,a[3]=t6,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t8=(C_word)C_slot(t2,C_fix(1));
/* reverse */
t9=*((C_word*)lf[40]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t7,t8);}

/* k10848 in unicode-range-up-to in k4869 */
static void C_ccall f_10850(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10850,2,t0,t1);}
t2=(C_word)C_slot(t1,C_fix(1));
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10798,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10802,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10834,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10842,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(C_word)C_slot(((C_word*)t0)[2],C_fix(1));
/* reverse */
t8=*((C_word*)lf[40]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t6,t7);}

/* k10840 in k10848 in unicode-range-up-to in k4869 */
static void C_ccall f_10842(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(t1,C_fix(1));
/* reverse */
t3=*((C_word*)lf[40]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t2);}

/* k10832 in k10848 in unicode-range-up-to in k4869 */
static void C_ccall f_10834(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],*((C_word*)lf[174]+1),t1);}

/* k10800 in k10848 in unicode-range-up-to in k4869 */
static void C_ccall f_10802(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10802,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10830,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* last */
f_5749(t2,((C_word*)t0)[2]);}

/* k10828 in k10800 in k10848 in unicode-range-up-to in k4869 */
static void C_ccall f_10830(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10830,2,t0,t1);}
t2=(C_word)C_make_character((C_word)C_unfix(t1));
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,C_make_character(128),t3);
t5=(C_word)C_a_i_cons(&a,2,lf[31],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
/* append */
t7=*((C_word*)lf[125]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,((C_word*)t0)[3],((C_word*)t0)[2],t6);}

/* k10796 in k10848 in unicode-range-up-to in k4869 */
static void C_ccall f_10798(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10798,2,t0,t1);}
t2=f_13391(C_a_i(&a,3),t1);
t3=(C_word)C_a_i_list(&a,1,t2);
/* unicode-range-helper */
f_10518(((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_END_OF_LIST,t3);}

/* a10753 in unicode-range-up-to in k4869 */
static void C_ccall f_10754(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10754,3,t0,t1,t2);}
t3=(C_word)C_u_i_car(((C_word*)t0)[2]);
t4=(C_word)C_a_i_minus(&a,2,t3,C_fix(1));
t5=(C_word)C_make_character((C_word)C_unfix(t4));
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,C_make_character(128),t6);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,lf[31],t7));}

/* k10750 in unicode-range-up-to in k4869 */
static void C_ccall f_10752(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10752,2,t0,t1);}
t2=f_13416(C_a_i(&a,3),t1);
t3=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t2);
/* sre-sequence */
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,f_13391(C_a_i(&a,3),t3));}

/* unicode-range-up-from in k4869 */
static void C_fcall f_10604(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10604,NULL,2,t1,t2);}
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_make_character((C_word)C_unfix(t3));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10624,a[2]=t1,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10626,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10722,a[2]=t2,a[3]=t6,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t8=(C_word)C_slot(t2,C_fix(1));
/* reverse */
t9=*((C_word*)lf[40]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t7,t8);}

/* k10720 in unicode-range-up-from in k4869 */
static void C_ccall f_10722(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10722,2,t0,t1);}
t2=(C_word)C_slot(t1,C_fix(1));
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10670,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10674,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10706,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10714,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(C_word)C_slot(((C_word*)t0)[2],C_fix(1));
/* reverse */
t8=*((C_word*)lf[40]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t6,t7);}

/* k10712 in k10720 in unicode-range-up-from in k4869 */
static void C_ccall f_10714(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(t1,C_fix(1));
/* reverse */
t3=*((C_word*)lf[40]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t2);}

/* k10704 in k10720 in unicode-range-up-from in k4869 */
static void C_ccall f_10706(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],*((C_word*)lf[174]+1),t1);}

/* k10672 in k10720 in unicode-range-up-from in k4869 */
static void C_ccall f_10674(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10674,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10702,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* last */
f_5749(t2,((C_word*)t0)[2]);}

/* k10700 in k10672 in k10720 in unicode-range-up-from in k4869 */
static void C_ccall f_10702(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10702,2,t0,t1);}
t2=(C_word)C_make_character((C_word)C_unfix(t1));
t3=(C_word)C_a_i_cons(&a,2,C_make_character(255),C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,t2,t3);
t5=(C_word)C_a_i_cons(&a,2,lf[31],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
/* append */
t7=*((C_word*)lf[125]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,((C_word*)t0)[3],((C_word*)t0)[2],t6);}

/* k10668 in k10720 in unicode-range-up-from in k4869 */
static void C_ccall f_10670(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10670,2,t0,t1);}
t2=f_13391(C_a_i(&a,3),t1);
t3=(C_word)C_a_i_list(&a,1,t2);
/* unicode-range-helper */
f_10518(((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_END_OF_LIST,t3);}

/* a10625 in unicode-range-up-from in k4869 */
static void C_ccall f_10626(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10626,3,t0,t1,t2);}
t3=(C_word)C_u_i_car(((C_word*)t0)[2]);
t4=(C_word)C_a_i_plus(&a,2,t3,C_fix(1));
t5=(C_word)C_make_character((C_word)C_unfix(t4));
t6=(C_word)C_a_i_cons(&a,2,C_make_character(255),C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,t5,t6);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,lf[31],t7));}

/* k10622 in unicode-range-up-from in k4869 */
static void C_ccall f_10624(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10624,2,t0,t1);}
t2=f_13416(C_a_i(&a,3),t1);
t3=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t2);
/* sre-sequence */
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,f_13391(C_a_i(&a,3),t3));}

/* unicode-range-helper in k4869 */
static void C_fcall f_10518(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10518,NULL,5,t1,t2,t3,t4,t5);}
if(C_truep((C_word)C_i_nullp(t3))){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t6=(C_word)C_slot(t3,C_fix(1));
t7=(C_word)C_u_i_car(t3);
t8=(C_word)C_a_i_cons(&a,2,t7,t4);
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10548,a[2]=t8,a[3]=t6,a[4]=t2,a[5]=t1,a[6]=t5,tmp=(C_word)a,a+=7,tmp);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10552,a[2]=t2,a[3]=t3,a[4]=t9,tmp=(C_word)a,a+=5,tmp);
/* map */
t11=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t10,*((C_word*)lf[174]+1),t4);}}

/* k10550 in unicode-range-helper in k4869 */
static void C_ccall f_10552(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10552,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10560,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_u_i_car(((C_word*)t0)[3]);
/* one1384 */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}

/* k10558 in k10550 in unicode-range-helper in k4869 */
static void C_ccall f_10560(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10560,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10564,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10568,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10570,tmp=(C_word)a,a+=2,tmp);
t5=(C_word)C_slot(((C_word*)t0)[2],C_fix(1));
/* map */
t6=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}

/* a10569 in k10558 in k10550 in unicode-range-helper in k4869 */
static void C_ccall f_10570(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10570,3,t0,t1,t2);}
t3=(C_word)C_a_i_cons(&a,2,C_make_character(255),C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,C_make_character(128),t3);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,lf[31],t4));}

/* k10566 in k10558 in k10550 in unicode-range-helper in k4869 */
static void C_ccall f_10568(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[84]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k10562 in k10558 in k10550 in unicode-range-helper in k4869 */
static void C_ccall f_10564(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10564,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
/* ##sys#append */
t3=*((C_word*)lf[84]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k10546 in unicode-range-helper in k4869 */
static void C_ccall f_10548(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10548,2,t0,t1);}
t2=f_13391(C_a_i(&a,3),t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[6]);
/* unicode-range-helper */
f_10518(((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* char->utf8-list in k4869 */
static void C_fcall f_10242(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10242,NULL,2,t1,t2);}
t3=(C_word)C_fix((C_word)C_character_code(t2));
if(C_truep((C_word)C_i_less_or_equalp(t3,C_fix(127)))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,1,t3));}
else{
if(C_truep((C_word)C_i_less_or_equalp(t3,C_fix(2047)))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10268,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10280,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* bit-shr */
f_6005(t5,t3,C_fix(6));}
else{
if(C_truep((C_word)C_i_less_or_equalp(t3,C_fix(65535)))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10293,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10317,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* bit-shr */
f_6005(t5,t3,C_fix(12));}
else{
if(C_truep((C_word)C_i_less_or_equalp(t3,C_fix(2097151)))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10330,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10366,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* bit-shr */
f_6005(t5,t3,C_fix(18));}
else{
/* error */
t4=*((C_word*)lf[24]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,lf[172],t3);}}}}}

/* k10364 in char->utf8-list in k4869 */
static void C_ccall f_10366(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* bit-ior */
f_6031(((C_word*)t0)[2],C_fix(240),t1);}

/* k10328 in char->utf8-list in k4869 */
static void C_ccall f_10330(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10330,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10334,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10358,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10362,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* bit-shr */
f_6005(t4,((C_word*)t0)[2],C_fix(12));}

/* k10360 in k10328 in char->utf8-list in k4869 */
static void C_ccall f_10362(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* bit-and */
f_6078(((C_word*)t0)[2],t1,C_fix(63));}

/* k10356 in k10328 in char->utf8-list in k4869 */
static void C_ccall f_10358(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* bit-ior */
f_6031(((C_word*)t0)[2],C_fix(128),t1);}

/* k10332 in k10328 in char->utf8-list in k4869 */
static void C_ccall f_10334(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10334,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10338,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10350,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10354,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* bit-shr */
f_6005(t4,((C_word*)t0)[2],C_fix(6));}

/* k10352 in k10332 in k10328 in char->utf8-list in k4869 */
static void C_ccall f_10354(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* bit-and */
f_6078(((C_word*)t0)[2],t1,C_fix(63));}

/* k10348 in k10332 in k10328 in char->utf8-list in k4869 */
static void C_ccall f_10350(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* bit-ior */
f_6031(((C_word*)t0)[2],C_fix(128),t1);}

/* k10336 in k10332 in k10328 in char->utf8-list in k4869 */
static void C_ccall f_10338(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10338,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10342,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10346,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* bit-and */
f_6078(t3,((C_word*)t0)[2],C_fix(63));}

/* k10344 in k10336 in k10332 in k10328 in char->utf8-list in k4869 */
static void C_ccall f_10346(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* bit-ior */
f_6031(((C_word*)t0)[2],C_fix(128),t1);}

/* k10340 in k10336 in k10332 in k10328 in char->utf8-list in k4869 */
static void C_ccall f_10342(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10342,2,t0,t1);}
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,4,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k10315 in char->utf8-list in k4869 */
static void C_ccall f_10317(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* bit-ior */
f_6031(((C_word*)t0)[2],C_fix(224),t1);}

/* k10291 in char->utf8-list in k4869 */
static void C_ccall f_10293(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10293,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10297,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10309,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10313,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* bit-shr */
f_6005(t4,((C_word*)t0)[2],C_fix(6));}

/* k10311 in k10291 in char->utf8-list in k4869 */
static void C_ccall f_10313(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* bit-and */
f_6078(((C_word*)t0)[2],t1,C_fix(63));}

/* k10307 in k10291 in char->utf8-list in k4869 */
static void C_ccall f_10309(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* bit-ior */
f_6031(((C_word*)t0)[2],C_fix(128),t1);}

/* k10295 in k10291 in char->utf8-list in k4869 */
static void C_ccall f_10297(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10297,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10301,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10305,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* bit-and */
f_6078(t3,((C_word*)t0)[2],C_fix(63));}

/* k10303 in k10295 in k10291 in char->utf8-list in k4869 */
static void C_ccall f_10305(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* bit-ior */
f_6031(((C_word*)t0)[2],C_fix(128),t1);}

/* k10299 in k10295 in k10291 in char->utf8-list in k4869 */
static void C_ccall f_10301(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10301,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k10278 in char->utf8-list in k4869 */
static void C_ccall f_10280(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* bit-ior */
f_6031(((C_word*)t0)[2],C_fix(192),t1);}

/* k10266 in char->utf8-list in k4869 */
static void C_ccall f_10268(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10268,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10272,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10276,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* bit-and */
f_6078(t3,((C_word*)t0)[2],C_fix(63));}

/* k10274 in k10266 in char->utf8-list in k4869 */
static void C_ccall f_10276(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* bit-ior */
f_6031(((C_word*)t0)[2],C_fix(128),t1);}

/* k10270 in k10266 in char->utf8-list in k4869 */
static void C_ccall f_10272(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10272,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[2],t1));}

/* utf8-lowest-digit-of-length in k4869 */
static void C_fcall f_10182(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10182,NULL,2,t1,t2);}
t3=t2;
switch(t3){
case C_fix(1):
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_fix(0));
case C_fix(2):
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_fix(192));
case C_fix(3):
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_fix(224));
case C_fix(4):
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_fix(240));
default:
/* error */
t4=*((C_word*)lf[24]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,lf[170],t2);}}

/* utf8-string-ref in k4869 */
static void C_fcall f_9957(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9957,NULL,4,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9960,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t6=t4;
switch(t6){
case C_fix(1):
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_subchar(t2,t3));
case C_fix(2):
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9994,a[2]=t5,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10010,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
t9=f_9960(t5,t3);
/* bit-and */
f_6078(t8,t9,C_fix(31));
case C_fix(3):
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10027,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10031,a[2]=t5,a[3]=t3,a[4]=t7,tmp=(C_word)a,a+=5,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10063,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
t10=f_9960(t5,t3);
/* bit-and */
f_6078(t9,t10,C_fix(15));
case C_fix(4):
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10080,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10084,a[2]=t5,a[3]=t3,a[4]=t7,tmp=(C_word)a,a+=5,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10132,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
t10=f_9960(t5,t3);
/* bit-and */
f_6078(t9,t10,C_fix(7));
default:
/* error */
t7=*((C_word*)lf[24]+1);
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t1,lf[168],t2,t4,t3);}}

/* k10130 in utf8-string-ref in k4869 */
static void C_ccall f_10132(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* bit-shl */
f_6015(((C_word*)t0)[2],t1,C_fix(18));}

/* k10082 in utf8-string-ref in k4869 */
static void C_ccall f_10084(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10084,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10088,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10120,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[3],C_fix(1));
t5=f_9960(((C_word*)t0)[2],t4);
/* bit-and */
f_6078(t3,t5,C_fix(63));}

/* k10118 in k10082 in utf8-string-ref in k4869 */
static void C_ccall f_10120(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* bit-shl */
f_6015(((C_word*)t0)[2],t1,C_fix(12));}

/* k10086 in k10082 in utf8-string-ref in k4869 */
static void C_ccall f_10088(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10088,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10092,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10108,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[3],C_fix(2));
t5=f_9960(((C_word*)t0)[2],t4);
/* bit-and */
f_6078(t3,t5,C_fix(63));}

/* k10106 in k10086 in k10082 in utf8-string-ref in k4869 */
static void C_ccall f_10108(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* bit-shl */
f_6015(((C_word*)t0)[2],t1,C_fix(6));}

/* k10090 in k10086 in k10082 in utf8-string-ref in k4869 */
static void C_ccall f_10092(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10092,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10096,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[3],C_fix(3));
t4=f_9960(((C_word*)t0)[2],t3);
/* bit-and */
f_6078(t2,t4,C_fix(63));}

/* k10094 in k10090 in k10086 in k10082 in utf8-string-ref in k4869 */
static void C_ccall f_10096(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* + */
C_plus(6,0,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k10078 in utf8-string-ref in k4869 */
static void C_ccall f_10080(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_make_character((C_word)C_unfix(t1)));}

/* k10061 in utf8-string-ref in k4869 */
static void C_ccall f_10063(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* bit-shl */
f_6015(((C_word*)t0)[2],t1,C_fix(12));}

/* k10029 in utf8-string-ref in k4869 */
static void C_ccall f_10031(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10031,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10035,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10051,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[3],C_fix(1));
t5=f_9960(((C_word*)t0)[2],t4);
/* bit-and */
f_6078(t3,t5,C_fix(63));}

/* k10049 in k10029 in utf8-string-ref in k4869 */
static void C_ccall f_10051(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* bit-shl */
f_6015(((C_word*)t0)[2],t1,C_fix(6));}

/* k10033 in k10029 in utf8-string-ref in k4869 */
static void C_ccall f_10035(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10035,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10039,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[3],C_fix(2));
t4=f_9960(((C_word*)t0)[2],t3);
/* bit-and */
f_6078(t2,t4,C_fix(63));}

/* k10037 in k10033 in k10029 in utf8-string-ref in k4869 */
static void C_ccall f_10039(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* + */
C_plus(5,0,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k10025 in utf8-string-ref in k4869 */
static void C_ccall f_10027(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_make_character((C_word)C_unfix(t1)));}

/* k10008 in utf8-string-ref in k4869 */
static void C_ccall f_10010(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* bit-shl */
f_6015(((C_word*)t0)[2],t1,C_fix(6));}

/* k9992 in utf8-string-ref in k4869 */
static void C_ccall f_9994(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9994,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9998,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[3],C_fix(1));
t4=f_9960(((C_word*)t0)[2],t3);
/* bit-and */
f_6078(t2,t4,C_fix(63));}

/* k9996 in k9992 in utf8-string-ref in k4869 */
static void C_ccall f_9998(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9998,2,t0,t1);}
t2=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_make_character((C_word)C_unfix(t2)));}

/* byte in utf8-string-ref in k4869 */
static C_word C_fcall f_9960(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
t2=(C_word)C_subchar(((C_word*)t0)[2],t1);
return((C_word)C_fix((C_word)C_character_code(t2)));}

/* utf8-start-char->length in k4869 */
static C_word C_fcall f_9947(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
t2=(C_word)C_fix((C_word)C_character_code(t1));
return((C_word)C_slot(lf[167],t2));}

/* high-char? in k4869 */
static void C_ccall f_9937(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9937,3,t0,t1,t2);}
t3=(C_word)C_fix((C_word)C_character_code(t2));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_less_or_equalp(C_fix(128),t3));}

/* string-parse-hex-escape in k4869 */
static void C_fcall f_9214(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9214,NULL,4,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_greater_or_equalp(t3,t4))){
/* error */
t5=*((C_word*)lf[24]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,lf[162],t2,t3);}
else{
t5=(C_word)C_subchar(t2,t3);
t6=(C_word)C_eqp(C_make_character(123),t5);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9233,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t8=(C_word)C_a_i_plus(&a,2,t3,C_fix(1));
t9=t2;
t10=(C_word)C_a_i_list(&a,1,t8);
t11=(C_word)C_fix((C_word)C_header_size(t9));
t12=(C_word)C_i_pairp(t10);
t13=(C_truep(t12)?(C_word)C_u_i_car(t10):C_fix(0));
t14=C_SCHEME_UNDEFINED;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_set_block_item(t15,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5364,a[2]=t15,a[3]=t9,a[4]=t11,tmp=(C_word)a,a+=5,tmp));
t17=((C_word*)t15)[1];
f_5364(t17,t7,t13);}
else{
t7=(C_word)C_a_i_plus(&a,2,t3,C_fix(1));
if(C_truep((C_word)C_i_greater_or_equalp(t7,t4))){
/* error */
t8=*((C_word*)lf[24]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t1,lf[165],t2,t3);}
else{
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9281,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t9=(C_word)C_a_i_plus(&a,2,t3,C_fix(2));
/* substring */
t10=*((C_word*)lf[28]+1);
((C_proc5)(void*)(*((C_word*)t10+1)))(5,t10,t8,t2,t3,t9);}}}}

/* k9279 in string-parse-hex-escape in k4869 */
static void C_ccall f_9281(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9281,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9284,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* string->number */
C_string_to_number(4,0,t2,t1,C_fix(16));}

/* k9282 in k9279 in string-parse-hex-escape in k4869 */
static void C_ccall f_9284(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9284,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_make_character((C_word)C_unfix(t1));
t3=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[4],C_fix(2));
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,2,t2,t3));}
else{
/* error */
t2=*((C_word*)lf[24]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],lf[166],((C_word*)t0)[2]);}}

/* scan in string-parse-hex-escape in k4869 */
static void C_fcall f_5364(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5364,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nequalp(t2,((C_word*)t0)[4]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=(C_word)C_subchar(((C_word*)t0)[3],t2);
t4=(C_word)C_eqp(C_make_character(125),t3);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t2);}
else{
t5=(C_word)C_a_i_plus(&a,2,t2,C_fix(1));
/* scan206 */
t7=t1;
t8=t5;
t1=t7;
t2=t8;
goto loop;}}}

/* k9231 in string-parse-hex-escape in k4869 */
static void C_ccall f_9233(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9233,2,t0,t1);}
t2=t1;
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9245,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[3],C_fix(1));
/* substring */
t5=*((C_word*)lf[28]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t3,((C_word*)t0)[2],t4,t1);}
else{
/* error */
t3=*((C_word*)lf[24]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[4],lf[164],((C_word*)t0)[2],((C_word*)t0)[3]);}}

/* k9243 in k9231 in string-parse-hex-escape in k4869 */
static void C_ccall f_9245(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9245,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9248,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* string->number */
C_string_to_number(4,0,t2,t1,C_fix(16));}

/* k9246 in k9243 in k9231 in string-parse-hex-escape in k4869 */
static void C_ccall f_9248(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9248,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_make_character((C_word)C_unfix(t1));
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,t2,((C_word*)t0)[3]));}
else{
/* error */
t2=*((C_word*)lf[24]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[4],lf[163],((C_word*)t0)[2]);}}

/* char-altcase in k4869 */
static C_word C_fcall f_9172(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
t2=(C_word)C_u_i_char_upper_casep(t1);
return((C_truep(t2)?(C_word)C_u_i_char_downcase(t1):(C_word)C_u_i_char_upcase(t1)));}

/* string->sre in k4869 */
static void C_ccall f_6263(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_6263r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6263r(t0,t1,t2,t3);}}

static void C_ccall f_6263r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t4=(C_word)C_fix((C_word)C_header_size(t2));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6270,a[2]=t1,a[3]=t4,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* symbol-list->flags */
f_6163(t5,t3);}

/* k6268 in string->sre in k4869 */
static void C_ccall f_6270(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6270,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6275,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_6275(t5,((C_word*)t0)[2],C_fix(0),C_fix(0),t1,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}

/* lp in k6268 in string->sre in k4869 */
static void C_fcall f_6275(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word t98;
C_word t99;
C_word t100;
C_word t101;
C_word t102;
C_word t103;
C_word t104;
C_word t105;
C_word t106;
C_word t107;
C_word t108;
C_word t109;
C_word t110;
C_word t111;
C_word t112;
C_word t113;
C_word t114;
C_word t115;
C_word t116;
C_word t117;
C_word t118;
C_word t119;
C_word t120;
C_word t121;
C_word t122;
C_word t123;
C_word t124;
C_word t125;
C_word t126;
C_word t127;
C_word t128;
C_word t129;
C_word t130;
C_word t131;
C_word t132;
C_word t133;
C_word t134;
C_word t135;
C_word t136;
C_word t137;
C_word t138;
C_word t139;
C_word t140;
C_word t141;
C_word t142;
C_word t143;
C_word t144;
C_word t145;
C_word t146;
C_word t147;
C_word t148;
C_word t149;
C_word t150;
C_word t151;
C_word t152;
C_word t153;
C_word t154;
C_word t155;
C_word t156;
C_word t157;
C_word t158;
C_word t159;
C_word t160;
C_word t161;
C_word t162;
C_word t163;
C_word t164;
C_word t165;
C_word t166;
C_word t167;
C_word t168;
C_word t169;
C_word t170;
C_word t171;
C_word t172;
C_word t173;
C_word t174;
C_word t175;
C_word t176;
C_word t177;
C_word t178;
C_word t179;
C_word t180;
C_word t181;
C_word t182;
C_word t183;
C_word t184;
C_word t185;
C_word t186;
C_word t187;
C_word t188;
C_word t189;
C_word t190;
C_word t191;
C_word t192;
C_word t193;
C_word t194;
C_word t195;
C_word t196;
C_word t197;
C_word t198;
C_word t199;
C_word t200;
C_word t201;
C_word t202;
C_word t203;
C_word t204;
C_word t205;
C_word t206;
C_word t207;
C_word t208;
C_word t209;
C_word t210;
C_word t211;
C_word t212;
C_word t213;
C_word t214;
C_word t215;
C_word t216;
C_word t217;
C_word t218;
C_word t219;
C_word *a;
loop:
a=C_alloc(78);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_6275,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6278,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6308,a[2]=t4,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6328,a[2]=((C_word*)t0)[4],a[3]=t8,a[4]=t5,a[5]=t3,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t10=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6348,a[2]=t4,a[3]=t2,a[4]=t7,a[5]=((C_word*)t0)[4],a[6]=t8,a[7]=t5,a[8]=t3,tmp=(C_word)a,a+=9,tmp);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6420,a[2]=t9,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6720,a[2]=t9,a[3]=t6,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_greater_or_equalp(t2,((C_word*)t0)[3]))){
if(C_truep((C_word)C_i_pairp(t6))){
/* error */
t13=*((C_word*)lf[24]+1);
((C_proc4)(void*)(*((C_word*)t13+1)))(4,t13,t1,lf[87],((C_word*)t0)[4]);}
else{
/* collect/terms580 */
t13=t11;
f_6420(t13,t1);}}
else{
t13=(C_word)C_subchar(((C_word*)t0)[4],t2);
switch(t13){
case C_make_character(46):
t14=(C_word)C_a_i_plus(&a,2,t2,C_fix(1));
t15=(C_word)C_a_i_plus(&a,2,t2,C_fix(1));
t16=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6785,a[2]=t9,a[3]=t6,a[4]=t4,a[5]=t15,a[6]=t14,a[7]=t1,a[8]=((C_word*)t0)[2],tmp=(C_word)a,a+=9,tmp);
/* flag-set? */
f_6125(t16,t4,C_fix(8));
case C_make_character(63):
t14=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6794,a[2]=t6,a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=t2,a[6]=((C_word*)t0)[4],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* collect/single579 */
t15=t10;
f_6348(t15,t14);
default:
t14=(C_word)C_eqp(t13,C_make_character(43));
t15=(C_truep(t14)?t14:(C_word)C_eqp(t13,C_make_character(42)));
if(C_truep(t15)){
t16=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6991,a[2]=t13,a[3]=t6,a[4]=t4,a[5]=((C_word*)t0)[2],a[6]=t2,a[7]=((C_word*)t0)[4],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
/* collect/single579 */
t17=t10;
f_6348(t17,t16);}
else{
switch(t13){
case C_make_character(40):
t16=(C_word)C_a_i_plus(&a,2,t2,C_fix(1));
if(C_truep((C_word)C_i_greater_or_equalp(t16,((C_word*)t0)[3]))){
/* error */
t17=*((C_word*)lf[24]+1);
((C_proc4)(void*)(*((C_word*)t17+1)))(4,t17,t1,lf[105],((C_word*)t0)[4]);}
else{
t17=(C_word)C_a_i_plus(&a,2,t2,C_fix(1));
t18=(C_word)C_subchar(((C_word*)t0)[4],t17);
t19=(C_word)C_eqp(C_make_character(63),t18);
if(C_truep(t19)){
t20=(C_word)C_a_i_plus(&a,2,t2,C_fix(2));
if(C_truep((C_word)C_i_greater_or_equalp(t20,((C_word*)t0)[3]))){
/* error */
t21=*((C_word*)lf[24]+1);
((C_proc4)(void*)(*((C_word*)t21+1)))(4,t21,t1,lf[106],((C_word*)t0)[4]);}
else{
t21=(C_word)C_a_i_plus(&a,2,t2,C_fix(2));
t22=(C_word)C_subchar(((C_word*)t0)[4],t21);
switch(t22){
case C_make_character(35):
t23=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7103,a[2]=t9,a[3]=t6,a[4]=t4,a[5]=t1,a[6]=((C_word*)t0)[2],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t24=(C_word)C_a_i_plus(&a,2,t2,C_fix(3));
/* string-scan-char */
f_5306(t23,((C_word*)t0)[4],C_make_character(41),(C_word)C_a_i_list(&a,1,t24));
case C_make_character(58):
t23=(C_word)C_a_i_plus(&a,2,t2,C_fix(3));
t24=(C_word)C_a_i_plus(&a,2,t2,C_fix(3));
t25=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7143,a[2]=t12,a[3]=t24,a[4]=t23,a[5]=t1,a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
/* flag-clear */
t26=lf[55];
f_6144(4,t26,t25,t4,C_fix(1));
case C_make_character(61):
t23=(C_word)C_a_i_plus(&a,2,t2,C_fix(3));
t24=(C_word)C_a_i_plus(&a,2,t2,C_fix(3));
t25=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7168,a[2]=t12,a[3]=t24,a[4]=t23,a[5]=t1,a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
/* flag-clear */
t26=lf[55];
f_6144(4,t26,t25,t4,C_fix(1));
case C_make_character(33):
t23=(C_word)C_a_i_plus(&a,2,t2,C_fix(3));
t24=(C_word)C_a_i_plus(&a,2,t2,C_fix(3));
t25=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7193,a[2]=t12,a[3]=t24,a[4]=t23,a[5]=t1,a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
/* flag-clear */
t26=lf[55];
f_6144(4,t26,t25,t4,C_fix(1));
case C_make_character(60):
t23=(C_word)C_a_i_plus(&a,2,t2,C_fix(3));
if(C_truep((C_word)C_i_greater_or_equalp(t23,((C_word*)t0)[3]))){
/* error */
t24=*((C_word*)lf[24]+1);
((C_proc4)(void*)(*((C_word*)t24+1)))(4,t24,t1,lf[109],((C_word*)t0)[4]);}
else{
t24=(C_word)C_a_i_plus(&a,2,t2,C_fix(3));
t25=(C_word)C_subchar(((C_word*)t0)[4],t24);
switch(t25){
case C_make_character(61):
t26=(C_word)C_a_i_plus(&a,2,t2,C_fix(4));
t27=(C_word)C_a_i_plus(&a,2,t2,C_fix(4));
t28=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7236,a[2]=t12,a[3]=t27,a[4]=t26,a[5]=t1,a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
/* flag-clear */
t29=lf[55];
f_6144(4,t29,t28,t4,C_fix(1));
case C_make_character(33):
t26=(C_word)C_a_i_plus(&a,2,t2,C_fix(4));
t27=(C_word)C_a_i_plus(&a,2,t2,C_fix(4));
t28=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7261,a[2]=t12,a[3]=t27,a[4]=t26,a[5]=t1,a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
/* flag-clear */
t29=lf[55];
f_6144(4,t29,t28,t4,C_fix(1));
default:
t26=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7268,a[2]=t4,a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=t12,a[6]=t1,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
t27=(C_word)C_a_i_plus(&a,2,t2,C_fix(3));
t28=(C_word)C_subchar(((C_word*)t0)[4],t27);
if(C_truep((C_word)C_u_i_char_alphabeticp(t28))){
t29=(C_word)C_a_i_plus(&a,2,t2,C_fix(4));
/* string-scan-char */
f_5306(t26,((C_word*)t0)[4],C_make_character(62),(C_word)C_a_i_list(&a,1,t29));}
else{
t29=t26;
f_7268(2,t29,C_SCHEME_FALSE);}}}
case C_make_character(62):
t23=(C_word)C_a_i_plus(&a,2,t2,C_fix(3));
t24=(C_word)C_a_i_plus(&a,2,t2,C_fix(3));
t25=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7360,a[2]=t12,a[3]=t24,a[4]=t23,a[5]=t1,a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
/* flag-clear */
t26=lf[55];
f_6144(4,t26,t25,t4,C_fix(1));
case C_make_character(40):
t23=(C_word)C_a_i_plus(&a,2,t2,C_fix(3));
if(C_truep((C_word)C_i_greater_or_equalp(t23,((C_word*)t0)[3]))){
/* error */
t24=*((C_word*)lf[24]+1);
((C_proc4)(void*)(*((C_word*)t24+1)))(4,t24,t1,lf[114],((C_word*)t0)[4]);}
else{
t24=(C_word)C_a_i_plus(&a,2,t2,C_fix(3));
t25=(C_word)C_subchar(((C_word*)t0)[4],t24);
if(C_truep((C_word)C_u_i_char_numericp(t25))){
t26=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7388,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=t12,a[6]=t1,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
t27=(C_word)C_a_i_plus(&a,2,t2,C_fix(3));
/* string-scan-char */
f_5306(t26,((C_word*)t0)[4],C_make_character(41),(C_word)C_a_i_list(&a,1,t27));}
else{
t26=(C_word)C_a_i_plus(&a,2,t2,C_fix(3));
t27=(C_word)C_subchar(((C_word*)t0)[4],t26);
if(C_truep((C_word)C_u_i_char_alphabeticp(t27))){
t28=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7448,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t4,a[5]=t12,a[6]=t1,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
t29=(C_word)C_a_i_plus(&a,2,t2,C_fix(3));
/* string-scan-char */
f_5306(t28,((C_word*)t0)[4],C_make_character(41),(C_word)C_a_i_list(&a,1,t29));}
else{
t28=(C_word)C_a_i_plus(&a,2,t2,C_fix(2));
t29=(C_word)C_a_i_plus(&a,2,t2,C_fix(2));
t30=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7505,a[2]=t12,a[3]=t29,a[4]=t28,a[5]=t1,a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
/* flag-clear */
t31=lf[55];
f_6144(4,t31,t30,t4,C_fix(1));}}}
case C_make_character(123):
/* error */
t23=*((C_word*)lf[24]+1);
((C_proc4)(void*)(*((C_word*)t23+1)))(4,t23,t1,lf[117],((C_word*)t0)[4]);
default:
t23=t4;
t24=(C_word)C_a_i_plus(&a,2,t2,C_fix(2));
t25=C_SCHEME_UNDEFINED;
t26=(*a=C_VECTOR_TYPE|1,a[1]=t25,tmp=(C_word)a,a+=2,tmp);
t27=C_set_block_item(t26,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7547,a[2]=t9,a[3]=t6,a[4]=((C_word*)t0)[2],a[5]=t26,a[6]=t2,a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[3],a[9]=t23,tmp=(C_word)a,a+=10,tmp));
t28=((C_word*)t26)[1];
f_7547(t28,t1,t24,t4,C_SCHEME_FALSE);}}}
else{
t20=(C_word)C_a_i_plus(&a,2,t2,C_fix(1));
t21=(C_word)C_a_i_plus(&a,2,t2,C_fix(1));
t22=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7078,a[2]=t12,a[3]=t21,a[4]=t20,a[5]=t1,a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
/* flag-join */
t23=lf[54];
f_6135(4,t23,t22,t4,C_fix(1));}}
case C_make_character(41):
if(C_truep((C_word)C_i_nullp(t6))){
/* error */
t16=*((C_word*)lf[24]+1);
((C_proc4)(void*)(*((C_word*)t16+1)))(4,t16,t1,lf[122],((C_word*)t0)[4]);}
else{
t16=(C_word)C_a_i_plus(&a,2,t2,C_fix(1));
t17=(C_word)C_a_i_plus(&a,2,t2,C_fix(1));
t18=(C_word)C_u_i_caar(t6);
t19=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7813,a[2]=t18,a[3]=t17,a[4]=t16,a[5]=t1,a[6]=((C_word*)t0)[2],a[7]=t6,tmp=(C_word)a,a+=8,tmp);
/* collect/terms580 */
t20=t11;
f_6420(t20,t19);}
case C_make_character(91):
t16=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7828,a[2]=t9,a[3]=t6,a[4]=t4,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
t17=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7852,a[2]=t16,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t18=(C_word)C_a_i_plus(&a,2,t2,C_fix(1));
t19=((C_word*)t0)[4];
t20=t4;
t21=(C_word)C_fix((C_word)C_header_size(t19));
t22=(C_word)C_subchar(t19,t18);
t23=(C_word)C_eqp(C_make_character(94),t22);
t24=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9325,a[2]=t17,a[3]=t18,a[4]=t20,a[5]=t23,a[6]=t19,a[7]=t21,tmp=(C_word)a,a+=8,tmp);
/* flag-set? */
f_6125(t24,t20,C_fix(32));
case C_make_character(123):
t16=(C_word)C_a_i_plus(&a,2,t2,C_fix(1));
t17=(C_word)C_i_greater_or_equalp(t16,((C_word*)t0)[3]);
t18=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7871,a[2]=t10,a[3]=((C_word*)t0)[4],a[4]=t6,a[5]=t5,a[6]=t4,a[7]=t3,a[8]=t1,a[9]=((C_word*)t0)[2],a[10]=t2,tmp=(C_word)a,a+=11,tmp);
if(C_truep(t17)){
t19=t18;
f_7871(t19,t17);}
else{
t19=(C_word)C_a_i_plus(&a,2,t2,C_fix(1));
t20=(C_word)C_subchar(((C_word*)t0)[4],t19);
t21=(C_word)C_u_i_char_numericp(t20);
t22=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8052,a[2]=t18,tmp=(C_word)a,a+=3,tmp);
if(C_truep(t21)){
t23=t22;
f_8052(t23,t21);}
else{
t23=(C_word)C_a_i_plus(&a,2,t2,C_fix(1));
t24=(C_word)C_subchar(((C_word*)t0)[4],t23);
t25=t22;
f_8052(t25,(C_word)C_eqp(C_make_character(44),t24));}}
case C_make_character(92):
t16=(C_word)C_a_i_plus(&a,2,t2,C_fix(1));
if(C_truep((C_word)C_i_greater_or_equalp(t16,((C_word*)t0)[3]))){
/* error */
t17=*((C_word*)lf[24]+1);
((C_proc4)(void*)(*((C_word*)t17+1)))(4,t17,t1,lf[142],((C_word*)t0)[4]);}
else{
t17=(C_word)C_a_i_plus(&a,2,t2,C_fix(1));
t18=(C_word)C_subchar(((C_word*)t0)[4],t17);
switch(t18){
case C_make_character(100):
t19=(C_word)C_a_i_plus(&a,2,t2,C_fix(2));
t20=(C_word)C_a_i_plus(&a,2,t2,C_fix(2));
t21=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8118,a[2]=t6,a[3]=t4,a[4]=t20,a[5]=t19,a[6]=t1,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
t22=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8122,a[2]=t21,tmp=(C_word)a,a+=3,tmp);
/* collect578 */
t23=t9;
f_6328(t23,t22);
case C_make_character(68):
t19=(C_word)C_a_i_plus(&a,2,t2,C_fix(2));
t20=(C_word)C_a_i_plus(&a,2,t2,C_fix(2));
t21=(C_word)C_a_i_cons(&a,2,lf[143],C_SCHEME_END_OF_LIST);
t22=(C_word)C_a_i_cons(&a,2,lf[124],t21);
t23=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8151,a[2]=t6,a[3]=t4,a[4]=t20,a[5]=t19,a[6]=t1,a[7]=((C_word*)t0)[2],a[8]=t22,tmp=(C_word)a,a+=9,tmp);
t24=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8155,a[2]=t23,tmp=(C_word)a,a+=3,tmp);
/* collect578 */
t25=t9;
f_6328(t25,t24);
case C_make_character(115):
t19=(C_word)C_a_i_plus(&a,2,t2,C_fix(2));
t20=(C_word)C_a_i_plus(&a,2,t2,C_fix(2));
t21=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8184,a[2]=t6,a[3]=t4,a[4]=t20,a[5]=t19,a[6]=t1,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
t22=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8188,a[2]=t21,tmp=(C_word)a,a+=3,tmp);
/* collect578 */
t23=t9;
f_6328(t23,t22);
case C_make_character(83):
t19=(C_word)C_a_i_plus(&a,2,t2,C_fix(2));
t20=(C_word)C_a_i_plus(&a,2,t2,C_fix(2));
t21=(C_word)C_a_i_cons(&a,2,lf[144],C_SCHEME_END_OF_LIST);
t22=(C_word)C_a_i_cons(&a,2,lf[124],t21);
t23=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8217,a[2]=t6,a[3]=t4,a[4]=t20,a[5]=t19,a[6]=t1,a[7]=((C_word*)t0)[2],a[8]=t22,tmp=(C_word)a,a+=9,tmp);
t24=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8221,a[2]=t23,tmp=(C_word)a,a+=3,tmp);
/* collect578 */
t25=t9;
f_6328(t25,t24);
case C_make_character(119):
t19=(C_word)C_a_i_plus(&a,2,t2,C_fix(2));
t20=(C_word)C_a_i_plus(&a,2,t2,C_fix(2));
t21=(C_word)C_a_i_cons(&a,2,lf[145],C_SCHEME_END_OF_LIST);
t22=(C_word)C_a_i_cons(&a,2,t21,C_SCHEME_END_OF_LIST);
t23=(C_word)C_a_i_cons(&a,2,lf[146],t22);
t24=(C_word)C_a_i_cons(&a,2,lf[70],t23);
t25=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8254,a[2]=t6,a[3]=t4,a[4]=t20,a[5]=t19,a[6]=t1,a[7]=((C_word*)t0)[2],a[8]=t24,tmp=(C_word)a,a+=9,tmp);
t26=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8258,a[2]=t25,tmp=(C_word)a,a+=3,tmp);
/* collect578 */
t27=t9;
f_6328(t27,t26);
case C_make_character(87):
t19=(C_word)C_a_i_plus(&a,2,t2,C_fix(2));
t20=(C_word)C_a_i_plus(&a,2,t2,C_fix(2));
t21=(C_word)C_a_i_cons(&a,2,lf[147],C_SCHEME_END_OF_LIST);
t22=(C_word)C_a_i_cons(&a,2,t21,C_SCHEME_END_OF_LIST);
t23=(C_word)C_a_i_cons(&a,2,lf[146],t22);
t24=(C_word)C_a_i_cons(&a,2,lf[70],t23);
t25=(C_word)C_a_i_cons(&a,2,t24,C_SCHEME_END_OF_LIST);
t26=(C_word)C_a_i_cons(&a,2,lf[124],t25);
t27=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8299,a[2]=t6,a[3]=t4,a[4]=t20,a[5]=t19,a[6]=t1,a[7]=((C_word*)t0)[2],a[8]=t26,tmp=(C_word)a,a+=9,tmp);
t28=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8303,a[2]=t27,tmp=(C_word)a,a+=3,tmp);
/* collect578 */
t29=t9;
f_6328(t29,t28);
case C_make_character(98):
t19=(C_word)C_a_i_plus(&a,2,t2,C_fix(2));
t20=(C_word)C_a_i_plus(&a,2,t2,C_fix(2));
t21=(C_word)C_a_i_cons(&a,2,lf[148],C_SCHEME_END_OF_LIST);
t22=(C_word)C_a_i_cons(&a,2,lf[149],t21);
t23=(C_word)C_a_i_cons(&a,2,lf[70],t22);
t24=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8352,a[2]=t6,a[3]=t4,a[4]=t20,a[5]=t19,a[6]=t1,a[7]=((C_word*)t0)[2],a[8]=t23,tmp=(C_word)a,a+=9,tmp);
t25=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8356,a[2]=t24,tmp=(C_word)a,a+=3,tmp);
/* collect578 */
t26=t9;
f_6328(t26,t25);
case C_make_character(66):
t19=(C_word)C_a_i_plus(&a,2,t2,C_fix(2));
t20=(C_word)C_a_i_plus(&a,2,t2,C_fix(2));
t21=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8389,a[2]=t6,a[3]=t4,a[4]=t20,a[5]=t19,a[6]=t1,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
t22=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8393,a[2]=t21,tmp=(C_word)a,a+=3,tmp);
/* collect578 */
t23=t9;
f_6328(t23,t22);
case C_make_character(65):
t19=(C_word)C_a_i_plus(&a,2,t2,C_fix(2));
t20=(C_word)C_a_i_plus(&a,2,t2,C_fix(2));
t21=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8418,a[2]=t6,a[3]=t4,a[4]=t20,a[5]=t19,a[6]=t1,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
t22=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8422,a[2]=t21,tmp=(C_word)a,a+=3,tmp);
/* collect578 */
t23=t9;
f_6328(t23,t22);
case C_make_character(90):
t19=(C_word)C_a_i_plus(&a,2,t2,C_fix(2));
t20=(C_word)C_a_i_plus(&a,2,t2,C_fix(2));
t21=(C_word)C_a_i_cons(&a,2,C_make_character(10),C_SCHEME_END_OF_LIST);
t22=(C_word)C_a_i_cons(&a,2,lf[95],t21);
t23=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8455,a[2]=t6,a[3]=t4,a[4]=t20,a[5]=t19,a[6]=t1,a[7]=((C_word*)t0)[2],a[8]=t22,tmp=(C_word)a,a+=9,tmp);
t24=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8459,a[2]=t23,tmp=(C_word)a,a+=3,tmp);
/* collect578 */
t25=t9;
f_6328(t25,t24);
case C_make_character(122):
t19=(C_word)C_a_i_plus(&a,2,t2,C_fix(2));
t20=(C_word)C_a_i_plus(&a,2,t2,C_fix(2));
t21=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8488,a[2]=t6,a[3]=t4,a[4]=t20,a[5]=t19,a[6]=t1,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
t22=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8492,a[2]=t21,tmp=(C_word)a,a+=3,tmp);
/* collect578 */
t23=t9;
f_6328(t23,t22);
case C_make_character(82):
t19=(C_word)C_a_i_plus(&a,2,t2,C_fix(2));
t20=(C_word)C_a_i_plus(&a,2,t2,C_fix(2));
t21=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8517,a[2]=t6,a[3]=t4,a[4]=t20,a[5]=t19,a[6]=t1,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
t22=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8521,a[2]=t21,tmp=(C_word)a,a+=3,tmp);
/* collect578 */
t23=t9;
f_6328(t23,t22);
case C_make_character(75):
t19=(C_word)C_a_i_plus(&a,2,t2,C_fix(2));
t20=(C_word)C_a_i_plus(&a,2,t2,C_fix(2));
t21=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8546,a[2]=t6,a[3]=t4,a[4]=t20,a[5]=t19,a[6]=t1,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
t22=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8550,a[2]=t21,tmp=(C_word)a,a+=3,tmp);
/* collect578 */
t23=t9;
f_6328(t23,t22);
case C_make_character(60):
t19=(C_word)C_a_i_plus(&a,2,t2,C_fix(2));
t20=(C_word)C_a_i_plus(&a,2,t2,C_fix(2));
t21=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8575,a[2]=t6,a[3]=t4,a[4]=t20,a[5]=t19,a[6]=t1,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
t22=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8579,a[2]=t21,tmp=(C_word)a,a+=3,tmp);
/* collect578 */
t23=t9;
f_6328(t23,t22);
case C_make_character(62):
t19=(C_word)C_a_i_plus(&a,2,t2,C_fix(2));
t20=(C_word)C_a_i_plus(&a,2,t2,C_fix(2));
t21=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8604,a[2]=t6,a[3]=t4,a[4]=t20,a[5]=t19,a[6]=t1,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
t22=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8608,a[2]=t21,tmp=(C_word)a,a+=3,tmp);
/* collect578 */
t23=t9;
f_6328(t23,t22);
case C_make_character(120):
t19=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8619,a[2]=t9,a[3]=t6,a[4]=t4,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
t20=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8647,a[2]=t19,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t21=(C_word)C_a_i_plus(&a,2,t2,C_fix(2));
/* string-parse-hex-escape */
f_9214(t20,((C_word*)t0)[4],t21,((C_word*)t0)[3]);
case C_make_character(107):
t19=(C_word)C_a_i_plus(&a,2,t2,C_fix(2));
t20=(C_word)C_subchar(((C_word*)t0)[4],t19);
if(C_truep((C_truep((C_word)C_i_eqvp(t20,C_make_character(60)))?C_SCHEME_TRUE:(C_truep((C_word)C_i_eqvp(t20,C_make_character(123)))?C_SCHEME_TRUE:(C_truep((C_word)C_i_eqvp(t20,C_make_character(39)))?C_SCHEME_TRUE:C_SCHEME_FALSE))))){
t21=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8672,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=t9,a[5]=t6,a[6]=t4,a[7]=t1,a[8]=((C_word*)t0)[2],tmp=(C_word)a,a+=9,tmp);
switch(t20){
case C_make_character(60):
t22=t21;
f_8672(t22,C_make_character(62));
case C_make_character(123):
t22=t21;
f_8672(t22,C_make_character(125));
case C_make_character(40):
t22=t21;
f_8672(t22,C_make_character(41));
default:
t22=(C_word)C_eqp(t20,C_make_character(91));
t23=t21;
f_8672(t23,(C_truep(t22)?C_make_character(93):t20));}}
else{
/* error */
t21=*((C_word*)lf[24]+1);
((C_proc4)(void*)(*((C_word*)t21+1)))(4,t21,t1,lf[158],((C_word*)t0)[4]);}
case C_make_character(81):
t19=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8756,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t6,a[5]=t4,a[6]=((C_word*)t0)[2],a[7]=((C_word*)t0)[3],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
/* collect578 */
t20=t9;
f_6328(t20,t19);
default:
if(C_truep((C_word)C_u_i_char_numericp(t18))){
t19=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8870,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t9,a[5]=t6,a[6]=t4,a[7]=t1,a[8]=((C_word*)t0)[2],a[9]=((C_word*)t0)[3],tmp=(C_word)a,a+=10,tmp);
t20=(C_word)C_a_i_plus(&a,2,t2,C_fix(2));
t21=((C_word*)t0)[4];
t22=(C_word)C_a_i_list(&a,1,t20);
t23=(C_word)C_fix((C_word)C_header_size(t21));
t24=(C_word)C_i_pairp(t22);
t25=(C_truep(t24)?(C_word)C_u_i_car(t22):C_fix(0));
t26=C_SCHEME_UNDEFINED;
t27=(*a=C_VECTOR_TYPE|1,a[1]=t26,tmp=(C_word)a,a+=2,tmp);
t28=C_set_block_item(t27,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5422,a[2]=t27,a[3]=t21,a[4]=t23,tmp=(C_word)a,a+=5,tmp));
t29=((C_word*)t27)[1];
f_5422(t29,t19,t25);}
else{
if(C_truep((C_word)C_u_i_char_alphabeticp(t18))){
t19=(C_word)C_i_assv(t18,lf[140]);
if(C_truep(t19)){
t20=(C_word)C_a_i_plus(&a,2,t2,C_fix(2));
t21=(C_word)C_a_i_plus(&a,2,t2,C_fix(2));
t22=(C_word)C_slot(t19,C_fix(1));
t23=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8962,a[2]=t6,a[3]=t4,a[4]=t21,a[5]=t20,a[6]=t1,a[7]=((C_word*)t0)[2],a[8]=t22,tmp=(C_word)a,a+=9,tmp);
/* collect578 */
t24=t9;
f_6328(t24,t23);}
else{
/* error */
t20=*((C_word*)lf[24]+1);
((C_proc5)(void*)(*((C_word*)t20+1)))(5,t20,t1,lf[159],((C_word*)t0)[4],t18);}}
else{
t19=(C_word)C_a_i_plus(&a,2,t2,C_fix(2));
t20=(C_word)C_a_i_plus(&a,2,t2,C_fix(1));
t21=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8980,a[2]=t6,a[3]=t4,a[4]=t20,a[5]=t19,a[6]=t1,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
/* collect578 */
t22=t9;
f_6328(t22,t21);}}}}
case C_make_character(124):
t16=(C_word)C_a_i_plus(&a,2,t2,C_fix(1));
t17=(C_word)C_a_i_plus(&a,2,t2,C_fix(1));
t18=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9013,a[2]=t6,a[3]=t4,a[4]=t17,a[5]=t16,a[6]=t1,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
/* collect578 */
t19=t9;
f_6328(t19,t18);
case C_make_character(94):
t16=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9044,a[2]=t9,a[3]=t6,a[4]=t4,a[5]=t1,a[6]=((C_word*)t0)[2],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* flag-set? */
f_6125(t16,t4,C_fix(4));
case C_make_character(36):
t16=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9075,a[2]=t9,a[3]=t6,a[4]=t4,a[5]=t1,a[6]=((C_word*)t0)[2],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* flag-set? */
f_6125(t16,t4,C_fix(4));
case C_make_character(32):
t16=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_9087,a[2]=t5,a[3]=t3,a[4]=t9,a[5]=t6,a[6]=t4,a[7]=t1,a[8]=((C_word*)t0)[2],a[9]=t2,tmp=(C_word)a,a+=10,tmp);
/* flag-set? */
f_6125(t16,t4,C_fix(16));
case C_make_character(35):
t16=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_9121,a[2]=t5,a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=t9,a[7]=t6,a[8]=t4,a[9]=t1,a[10]=((C_word*)t0)[2],a[11]=((C_word*)t0)[3],tmp=(C_word)a,a+=12,tmp);
/* flag-set? */
f_6125(t16,t4,C_fix(16));
default:
t16=(C_word)C_a_i_plus(&a,2,t2,C_fix(1));
/* lp569 */
t214=t1;
t215=t16;
t216=t3;
t217=t4;
t218=t5;
t219=t6;
t1=t214;
t2=t215;
t3=t216;
t4=t217;
t5=t218;
t6=t219;
goto loop;}}}}}

/* k9119 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_9121(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9121,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9124,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[5],C_fix(1));
/* string-scan-char */
f_5306(t2,((C_word*)t0)[4],C_make_character(10),(C_word)C_a_i_list(&a,1,t3));}
else{
t2=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[5],C_fix(1));
/* lp569 */
t3=((C_word*)((C_word*)t0)[10])[1];
f_6275(t3,((C_word*)t0)[9],t2,((C_word*)t0)[3],((C_word*)t0)[8],((C_word*)t0)[2],((C_word*)t0)[7]);}}

/* k9122 in k9119 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_9124(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9124,2,t0,t1);}
t2=(C_truep(t1)?t1:(C_word)C_a_i_minus(&a,2,((C_word*)t0)[7],C_fix(1)));
t3=(C_word)C_a_i_plus(&a,2,t2,C_fix(1));
t4=(C_word)C_a_i_plus(&a,2,t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9142,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=t3,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* collect578 */
t6=((C_word*)t0)[2];
f_6328(t6,t5);}

/* k9140 in k9122 in k9119 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_9142(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp569 */
t2=((C_word*)((C_word*)t0)[7])[1];
f_6275(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k9085 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_9087(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9087,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[9],C_fix(1));
t3=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[9],C_fix(1));
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9102,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t3,a[5]=t2,a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* collect578 */
t5=((C_word*)t0)[4];
f_6328(t5,t4);}
else{
t2=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[9],C_fix(1));
/* lp569 */
t3=((C_word*)((C_word*)t0)[8])[1];
f_6275(t3,((C_word*)t0)[7],t2,((C_word*)t0)[3],((C_word*)t0)[6],((C_word*)t0)[2],((C_word*)t0)[5]);}}

/* k9100 in k9085 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_9102(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp569 */
t2=((C_word*)((C_word*)t0)[7])[1];
f_6275(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k9073 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_9075(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9075,2,t0,t1);}
t2=(C_truep(t1)?lf[161]:lf[152]);
t3=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[7],C_fix(1));
t4=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[7],C_fix(1));
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9072,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=t3,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
/* collect578 */
t6=((C_word*)t0)[2];
f_6328(t6,t5);}

/* k9070 in k9073 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_9072(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9072,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
/* lp569 */
t3=((C_word*)((C_word*)t0)[7])[1];
f_6275(t3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k9042 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_9044(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9044,2,t0,t1);}
t2=(C_truep(t1)?lf[160]:lf[151]);
t3=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[7],C_fix(1));
t4=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[7],C_fix(1));
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9041,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=t3,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
/* collect578 */
t6=((C_word*)t0)[2];
f_6328(t6,t5);}

/* k9039 in k9042 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_9041(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9041,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
/* lp569 */
t3=((C_word*)((C_word*)t0)[7])[1];
f_6275(t3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k9011 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_9013(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9013,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[70],t1);
/* lp569 */
t3=((C_word*)((C_word*)t0)[7])[1];
f_6275(t3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k8978 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_8980(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp569 */
t2=((C_word*)((C_word*)t0)[7])[1];
f_6275(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k8960 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_8962(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8962,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
/* lp569 */
t3=((C_word*)((C_word*)t0)[7])[1];
f_6275(t3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* scan in lp in k6268 in string->sre in k4869 */
static void C_fcall f_5422(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5422,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nequalp(t2,((C_word*)t0)[4]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=(C_word)C_subchar(((C_word*)t0)[3],t2);
if(C_truep((C_word)C_u_i_char_numericp(t3))){
t4=(C_word)C_a_i_plus(&a,2,t2,C_fix(1));
/* scan226 */
t6=t1;
t7=t4;
t1=t6;
t2=t7;
goto loop;}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}}}

/* k8868 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_8870(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8870,2,t0,t1);}
t2=(C_truep(t1)?t1:((C_word*)t0)[9]);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8913,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t2,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* flag-set? */
f_6125(t3,((C_word*)t0)[6],C_fix(2));}

/* k8911 in k8868 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_8913(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8913,2,t0,t1);}
t2=(C_truep(t1)?lf[155]:lf[156]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8902,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8906,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[3],C_fix(1));
/* substring */
t6=*((C_word*)lf[28]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t4,((C_word*)t0)[2],t5,((C_word*)t0)[7]);}

/* k8904 in k8911 in k8868 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_8906(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* string->number */
C_string_to_number(3,0,((C_word*)t0)[2],t1);}

/* k8900 in k8911 in k8868 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_8902(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8902,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t2);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8890,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t3,tmp=(C_word)a,a+=8,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8894,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* collect578 */
t6=((C_word*)t0)[2];
f_6328(t6,t5);}

/* k8892 in k8900 in k8911 in k8868 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_8894(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[84]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k8888 in k8900 in k8911 in k8868 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_8890(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8890,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t1);
/* lp569 */
t3=((C_word*)((C_word*)t0)[6])[1];
f_6275(t3,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k8754 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_8756(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8756,2,t0,t1);}
t2=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[8],C_fix(2));
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8765,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp));
t6=((C_word*)t4)[1];
f_8765(t6,((C_word*)t0)[2],t2);}

/* lp2 in k8754 in lp in k6268 in string->sre in k4869 */
static void C_fcall f_8765(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word *a;
loop:
a=C_alloc(29);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_8765,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_greater_or_equalp(t2,((C_word*)t0)[9]))){
t3=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[8],C_fix(2));
/* lp569 */
t4=((C_word*)((C_word*)t0)[7])[1];
f_6275(t4,t1,t2,t3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t3=(C_word)C_subchar(((C_word*)t0)[3],t2);
t4=(C_word)C_eqp(C_make_character(92),t3);
if(C_truep(t4)){
t5=(C_word)C_a_i_plus(&a,2,t2,C_fix(1));
if(C_truep((C_word)C_i_greater_or_equalp(t5,((C_word*)t0)[9]))){
t6=(C_word)C_a_i_plus(&a,2,t2,C_fix(1));
t7=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[8],C_fix(2));
/* lp569 */
t8=((C_word*)((C_word*)t0)[7])[1];
f_6275(t8,t1,t6,t7,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t6=(C_word)C_a_i_plus(&a,2,t2,C_fix(1));
t7=(C_word)C_subchar(((C_word*)t0)[3],t6);
t8=(C_word)C_eqp(C_make_character(69),t7);
if(C_truep(t8)){
t9=(C_word)C_a_i_plus(&a,2,t2,C_fix(2));
t10=(C_word)C_a_i_plus(&a,2,t2,C_fix(2));
t11=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8827,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[6],a[4]=t10,a[5]=t9,a[6]=t1,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
t12=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[8],C_fix(2));
/* substring */
t13=*((C_word*)lf[28]+1);
((C_proc5)(void*)(*((C_word*)t13+1)))(5,t13,t11,((C_word*)t0)[3],t12,t2);}
else{
t9=(C_word)C_a_i_plus(&a,2,t2,C_fix(2));
/* lp21014 */
t19=t1;
t20=t9;
t1=t19;
t2=t20;
goto loop;}}}
else{
t5=(C_word)C_a_i_plus(&a,2,t2,C_fix(1));
/* lp21014 */
t19=t1;
t20=t5;
t1=t19;
t2=t20;
goto loop;}}}

/* k8825 in lp2 in k8754 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_8827(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8827,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[8]);
/* lp569 */
t3=((C_word*)((C_word*)t0)[7])[1];
f_6275(t3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k8670 in lp in k6268 in string->sre in k4869 */
static void C_fcall f_8672(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8672,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8675,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[2],C_fix(2));
/* string-scan-char */
f_5306(t2,((C_word*)t0)[3],t1,(C_word)C_a_i_list(&a,1,t3));}

/* k8673 in k8670 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_8675(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8675,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8678,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
if(C_truep(t1)){
t3=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[2],C_fix(3));
/* substring */
t4=*((C_word*)lf[28]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,((C_word*)t0)[3],t3,t1);}
else{
t3=t2;
f_8678(2,t3,C_SCHEME_FALSE);}}

/* k8676 in k8673 in k8670 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_8678(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8678,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8728,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* flag-set? */
f_6125(t2,((C_word*)t0)[5],C_fix(2));}

/* k8726 in k8676 in k8673 in k8670 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_8728(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8728,2,t0,t1);}
t2=(C_truep(t1)?lf[155]:lf[156]);
t3=((C_word*)t0)[9];
if(C_truep(t3)){
t4=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[9],C_fix(1));
t5=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[9],C_fix(1));
t6=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8725,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t5,a[6]=t4,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t2,tmp=(C_word)a,a+=10,tmp);
/* string->symbol */
t7=*((C_word*)lf[104]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,((C_word*)t0)[3]);}
else{
/* error */
t4=*((C_word*)lf[24]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[7],lf[157],((C_word*)t0)[2]);}}

/* k8723 in k8726 in k8676 in k8673 in k8670 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_8725(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8725,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t2);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8713,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t3,tmp=(C_word)a,a+=9,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8717,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* collect578 */
t6=((C_word*)t0)[2];
f_6328(t6,t5);}

/* k8715 in k8723 in k8726 in k8676 in k8673 in k8670 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_8717(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[84]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k8711 in k8723 in k8726 in k8676 in k8673 in k8670 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_8713(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8713,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
/* lp569 */
t3=((C_word*)((C_word*)t0)[7])[1];
f_6275(t3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k8645 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_8647(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a8618 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_8619(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8619,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_plus(&a,2,t3,C_fix(1));
t5=(C_word)C_a_i_plus(&a,2,t3,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8639,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t5,a[5]=t4,a[6]=t1,a[7]=((C_word*)t0)[5],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8643,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* collect578 */
t8=((C_word*)t0)[2];
f_6328(t8,t7);}

/* k8641 in a8618 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_8643(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[84]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k8637 in a8618 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_8639(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8639,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
/* lp569 */
t3=((C_word*)((C_word*)t0)[7])[1];
f_6275(t3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k8606 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_8608(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[84]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k8602 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_8604(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8604,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[148],t1);
/* lp569 */
t3=((C_word*)((C_word*)t0)[7])[1];
f_6275(t3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k8577 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_8579(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[84]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k8573 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_8575(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8575,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[149],t1);
/* lp569 */
t3=((C_word*)((C_word*)t0)[7])[1];
f_6275(t3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k8548 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_8550(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[84]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k8544 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_8546(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8546,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[154],t1);
/* lp569 */
t3=((C_word*)((C_word*)t0)[7])[1];
f_6275(t3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k8519 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_8521(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[84]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k8515 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_8517(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8517,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[153],t1);
/* lp569 */
t3=((C_word*)((C_word*)t0)[7])[1];
f_6275(t3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k8490 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_8492(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[84]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k8486 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_8488(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8488,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[152],t1);
/* lp569 */
t3=((C_word*)((C_word*)t0)[7])[1];
f_6275(t3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k8457 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_8459(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[84]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k8453 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_8455(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8455,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[152],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t2);
/* lp569 */
t4=((C_word*)((C_word*)t0)[7])[1];
f_6275(t4,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t3,((C_word*)t0)[2]);}

/* k8420 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_8422(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[84]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k8416 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_8418(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8418,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[151],t1);
/* lp569 */
t3=((C_word*)((C_word*)t0)[7])[1];
f_6275(t3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k8391 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_8393(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[84]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k8387 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_8389(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8389,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[150],t1);
/* lp569 */
t3=((C_word*)((C_word*)t0)[7])[1];
f_6275(t3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k8354 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_8356(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[84]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k8350 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_8352(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8352,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
/* lp569 */
t3=((C_word*)((C_word*)t0)[7])[1];
f_6275(t3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k8301 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_8303(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[84]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k8297 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_8299(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8299,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
/* lp569 */
t3=((C_word*)((C_word*)t0)[7])[1];
f_6275(t3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k8256 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_8258(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[84]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k8252 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_8254(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8254,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
/* lp569 */
t3=((C_word*)((C_word*)t0)[7])[1];
f_6275(t3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k8219 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_8221(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[84]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k8215 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_8217(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8217,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
/* lp569 */
t3=((C_word*)((C_word*)t0)[7])[1];
f_6275(t3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k8186 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_8188(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[84]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k8182 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_8184(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8184,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[144],t1);
/* lp569 */
t3=((C_word*)((C_word*)t0)[7])[1];
f_6275(t3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k8153 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_8155(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[84]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k8149 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_8151(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8151,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
/* lp569 */
t3=((C_word*)((C_word*)t0)[7])[1];
f_6275(t3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k8120 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_8122(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[84]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k8116 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_8118(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8118,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[143],t1);
/* lp569 */
t3=((C_word*)((C_word*)t0)[7])[1];
f_6275(t3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k8050 in lp in k6268 in string->sre in k4869 */
static void C_fcall f_8052(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_7871(t2,(C_word)C_i_not(t1));}

/* k7869 in lp in k6268 in string->sre in k4869 */
static void C_fcall f_7871(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7871,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[10],C_fix(1));
/* lp569 */
t3=((C_word*)((C_word*)t0)[9])[1];
f_6275(t3,((C_word*)t0)[8],t2,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7881,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
/* collect/single579 */
t3=((C_word*)t0)[2];
f_6348(t3,t2);}}

/* k7879 in k7869 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_7881(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7881,2,t0,t1);}
t2=(C_word)C_u_i_car(t1);
t3=(C_word)C_slot(t1,C_fix(1));
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7890,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=t2,tmp=(C_word)a,a+=10,tmp);
t5=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[3],C_fix(1));
/* string-scan-char */
f_5306(t4,((C_word*)t0)[2],C_make_character(125),(C_word)C_a_i_list(&a,1,t5));}

/* k7888 in k7879 in k7869 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_7890(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7890,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7893,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8034,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[3],C_fix(1));
/* substring */
t5=*((C_word*)lf[28]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t3,((C_word*)t0)[2],t4,t1);}

/* k8032 in k7888 in k7879 in k7869 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_8034(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8034,2,t0,t1);}
t2=(C_word)C_fix((C_word)C_header_size(t1));
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5463,a[2]=t4,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_5463(t6,((C_word*)t0)[2],C_fix(0),C_fix(0),C_SCHEME_END_OF_LIST);}

/* lp in k8032 in k7888 in k7879 in k7869 in lp in k6268 in string->sre in k4869 */
static void C_fcall f_5463(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a;
loop:
a=C_alloc(20);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5463,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5466,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_greater_or_equalp(t2,((C_word*)t0)[3]))){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5487,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* collect257 */
t7=t5;
f_5466(t7,t6);}
else{
t6=(C_word)C_subchar(((C_word*)t0)[4],t2);
t7=(C_word)C_eqp(C_make_character(44),t6);
if(C_truep(t7)){
t8=(C_word)C_a_i_plus(&a,2,t2,C_fix(1));
t9=(C_word)C_a_i_plus(&a,2,t2,C_fix(1));
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5508,a[2]=t9,a[3]=t8,a[4]=t1,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* collect257 */
t11=t5;
f_5466(t11,t10);}
else{
t8=(C_word)C_a_i_plus(&a,2,t2,C_fix(1));
/* lp245 */
t14=t1;
t15=t8;
t16=t3;
t17=t4;
t1=t14;
t2=t15;
t3=t16;
t4=t17;
goto loop;}}}

/* k5506 in lp in k8032 in k7888 in k7879 in k7869 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_5508(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp245 */
t2=((C_word*)((C_word*)t0)[5])[1];
f_5463(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k5485 in lp in k8032 in k7888 in k7879 in k7869 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_5487(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* reverse */
t2=*((C_word*)lf[40]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* collect in lp in k8032 in k7888 in k7879 in k7869 in lp in k6268 in string->sre in k4869 */
static void C_fcall f_5466(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5466,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5474,a[2]=((C_word*)t0)[5],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* substring */
t3=*((C_word*)lf[28]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5472 in collect in lp in k8032 in k7888 in k7879 in k7869 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_5474(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5474,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[2]));}

/* k7891 in k7888 in k7879 in k7869 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_7893(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7893,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7896,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
t3=(C_word)C_u_i_car(t1);
/* string->number */
C_string_to_number(3,0,t2,t3);}

/* k7894 in k7891 in k7888 in k7879 in k7869 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_7896(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7896,2,t0,t1);}
t2=(C_truep(t1)?t1:C_fix(0));
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7902,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t2,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t4=(C_word)C_slot(((C_word*)t0)[9],C_fix(1));
if(C_truep((C_word)C_i_pairp(t4))){
t5=(C_word)C_u_i_cadr(((C_word*)t0)[9]);
/* string->number */
C_string_to_number(3,0,t3,t5);}
else{
t5=t3;
f_7902(2,t5,C_SCHEME_FALSE);}}

/* k7900 in k7894 in k7891 in k7888 in k7879 in k7869 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_7902(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word ab[29],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7902,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[10],C_fix(1));
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[9],C_fix(1));
t4=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[9],C_fix(1));
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t5);
t7=(C_word)C_a_i_cons(&a,2,lf[98],t6);
t8=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7931,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=t3,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t7,tmp=(C_word)a,a+=9,tmp);
/* ##sys#append */
t9=*((C_word*)lf[84]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t8,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}
else{
if(C_truep(t1)){
t3=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[9],C_fix(1));
t4=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[9],C_fix(1));
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,t1,t5);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t6);
t8=(C_word)C_a_i_cons(&a,2,lf[97],t7);
t9=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7965,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=t3,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t8,tmp=(C_word)a,a+=9,tmp);
/* ##sys#append */
t10=*((C_word*)lf[84]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t9,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[9],C_fix(1));
t4=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[9],C_fix(1));
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t5);
t7=(C_word)C_a_i_cons(&a,2,lf[99],t6);
t8=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8000,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=t3,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t7,tmp=(C_word)a,a+=9,tmp);
/* ##sys#append */
t9=*((C_word*)lf[84]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t8,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}}}

/* k7998 in k7900 in k7894 in k7891 in k7888 in k7879 in k7869 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_8000(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8000,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
/* lp569 */
t3=((C_word*)((C_word*)t0)[7])[1];
f_6275(t3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k7963 in k7900 in k7894 in k7891 in k7888 in k7879 in k7869 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_7965(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7965,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
/* lp569 */
t3=((C_word*)((C_word*)t0)[7])[1];
f_6275(t3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k7929 in k7900 in k7894 in k7891 in k7888 in k7879 in k7869 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_7931(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7931,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
/* lp569 */
t3=((C_word*)((C_word*)t0)[7])[1];
f_6275(t3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k9323 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_9325(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9325,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9327,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=t3,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp));
if(C_truep(((C_word*)t0)[5])){
t5=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[3],C_fix(1));
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9928,a[2]=t5,a[3]=((C_word*)t0)[2],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* flag-set? */
f_6125(t6,((C_word*)t0)[4],C_fix(4));}
else{
/* go1134 */
t5=((C_word*)t3)[1];
f_9327(t5,((C_word*)t0)[2],((C_word*)t0)[3],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}}

/* k9926 in k9323 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_9928(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?lf[141]:C_SCHEME_END_OF_LIST);
/* go1134 */
t3=((C_word*)((C_word*)t0)[4])[1];
f_9327(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2,C_SCHEME_END_OF_LIST);}

/* go in k9323 in lp in k6268 in string->sre in k4869 */
static void C_fcall f_9327(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word *a;
loop:
a=C_alloc(24);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_9327,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_greater_or_equalp(t2,((C_word*)t0)[8]))){
/* error */
t5=*((C_word*)lf[24]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t1,lf[123]);}
else{
t5=(C_word)C_subchar(((C_word*)t0)[7],t2);
switch(t5){
case C_make_character(93):
t6=(C_word)C_i_nullp(t3);
t7=(C_truep(t6)?(C_word)C_i_nullp(t4):C_SCHEME_FALSE);
if(C_truep(t7)){
t8=(C_word)C_a_i_plus(&a,2,t2,C_fix(1));
t9=(C_word)C_a_i_cons(&a,2,C_make_character(93),t3);
/* go1134 */
t37=t1;
t38=t8;
t39=t9;
t40=t4;
t1=t37;
t2=t38;
t3=t39;
t4=t40;
goto loop;}
else{
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9366,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=t2,a[6]=t1,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
/* flag-set? */
f_6125(t8,((C_word*)t0)[3],C_fix(2));}
case C_make_character(45):
t6=(C_word)C_i_nequalp(t2,((C_word*)t0)[2]);
t7=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_9477,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[7],a[4]=t4,a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=t3,a[8]=t5,a[9]=t2,tmp=(C_word)a,a+=10,tmp);
if(C_truep(t6)){
t8=t7;
f_9477(t8,t6);}
else{
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9564,a[2]=((C_word*)t0)[7],a[3]=t2,a[4]=t7,tmp=(C_word)a,a+=5,tmp);
t9=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[2],C_fix(1));
if(C_truep((C_word)C_i_nequalp(t2,t9))){
t10=(C_word)C_subchar(((C_word*)t0)[7],((C_word*)t0)[2]);
t11=t8;
f_9564(t11,(C_word)C_eqp(C_make_character(94),t10));}
else{
t10=t8;
f_9564(t10,C_SCHEME_FALSE);}}
case C_make_character(91):
t6=(C_word)C_a_i_plus(&a,2,t2,C_fix(1));
t7=(C_word)C_subchar(((C_word*)t0)[7],t6);
t8=(C_word)C_eqp(C_make_character(94),t7);
t9=(C_truep(t8)?(C_word)C_a_i_plus(&a,2,t2,C_fix(2)):(C_word)C_a_i_plus(&a,2,t2,C_fix(1)));
t10=(C_word)C_subchar(((C_word*)t0)[7],t9);
t11=(C_word)C_eqp(t10,C_make_character(58));
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9616,a[2]=t9,a[3]=t8,a[4]=t3,a[5]=t4,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t13=(C_word)C_a_i_plus(&a,2,t9,C_fix(1));
/* string-scan-char */
f_5306(t12,((C_word*)t0)[7],C_make_character(58),(C_word)C_a_i_list(&a,1,t13));}
else{
t12=(C_word)C_eqp(t10,C_make_character(61));
t13=(C_truep(t12)?t12:(C_word)C_eqp(t10,C_make_character(46)));
if(C_truep(t13)){
/* error */
t14=*((C_word*)lf[24]+1);
((C_proc4)(void*)(*((C_word*)t14+1)))(4,t14,t1,lf[137],((C_word*)t0)[7]);}
else{
/* error */
t14=*((C_word*)lf[24]+1);
((C_proc4)(void*)(*((C_word*)t14+1)))(4,t14,t1,lf[138],((C_word*)t0)[7]);}}
case C_make_character(92):
t6=(C_word)C_a_i_plus(&a,2,t2,C_fix(1));
t7=(C_word)C_subchar(((C_word*)t0)[7],t6);
t8=(C_word)C_eqp(t7,C_make_character(100));
t9=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_9741,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[7],a[4]=t7,a[5]=t3,a[6]=t4,a[7]=t1,a[8]=((C_word*)t0)[6],a[9]=t2,tmp=(C_word)a,a+=10,tmp);
if(C_truep(t8)){
t10=t9;
f_9741(t10,t8);}
else{
t10=(C_word)C_eqp(t7,C_make_character(68));
if(C_truep(t10)){
t11=t9;
f_9741(t11,t10);}
else{
t11=(C_word)C_eqp(t7,C_make_character(115));
if(C_truep(t11)){
t12=t9;
f_9741(t12,t11);}
else{
t12=(C_word)C_eqp(t7,C_make_character(83));
if(C_truep(t12)){
t13=t9;
f_9741(t13,t12);}
else{
t13=(C_word)C_eqp(t7,C_make_character(119));
t14=t9;
f_9741(t14,(C_truep(t13)?t13:(C_word)C_eqp(t7,C_make_character(87))));}}}}
default:
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9875,a[2]=((C_word*)t0)[7],a[3]=t4,a[4]=t1,a[5]=((C_word*)t0)[6],a[6]=t3,a[7]=t2,a[8]=t5,tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)t0)[4])){
t7=(C_word)C_fix((C_word)C_character_code(t5));
/* <= */
C_less_or_equal_p(5,0,t6,C_fix(128),t7,C_fix(255));}
else{
t7=t6;
f_9875(2,t7,C_SCHEME_FALSE);}}}}

/* k9873 in go in k9323 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_9875(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9875,2,t0,t1);}
if(C_truep(t1)){
t2=f_9947(((C_word*)t0)[8]);
t3=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[7],t2);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9893,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* utf8-string-ref */
f_9957(t4,((C_word*)t0)[2],((C_word*)t0)[7],t2);}
else{
t2=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[7],C_fix(1));
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],((C_word*)t0)[6]);
/* go1134 */
t4=((C_word*)((C_word*)t0)[5])[1];
f_9327(t4,((C_word*)t0)[4],t2,t3,((C_word*)t0)[3]);}}

/* k9891 in k9873 in go in k9323 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_9893(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9893,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[6]);
/* go1134 */
t3=((C_word*)((C_word*)t0)[5])[1];
f_9327(t3,((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k9739 in go in k9323 in lp in k6268 in string->sre in k4869 */
static void C_fcall f_9741(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9741,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9744,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9771,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_a_i_string(&a,2,C_make_character(92),((C_word*)t0)[4]);
/* string->sre */
t5=*((C_word*)lf[68]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],C_make_character(120));
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9786,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9802,a[2]=t3,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[9],C_fix(2));
/* string-parse-hex-escape */
f_9214(t4,((C_word*)t0)[3],t5,((C_word*)t0)[2]);}
else{
t3=(C_word)C_i_assv(((C_word*)t0)[4],lf[140]);
t4=(C_truep(t3)?(C_word)C_slot(t3,C_fix(1)):((C_word*)t0)[4]);
t5=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[9],C_fix(2));
t6=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[9],C_fix(1));
t7=(C_word)C_subchar(((C_word*)t0)[3],t6);
t8=(C_word)C_a_i_cons(&a,2,t4,((C_word*)t0)[5]);
t9=(C_word)C_a_i_cons(&a,2,t7,t8);
/* go1134 */
t10=((C_word*)((C_word*)t0)[8])[1];
f_9327(t10,((C_word*)t0)[7],t5,t9,((C_word*)t0)[6]);}}}

/* k9800 in k9739 in go in k9323 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_9802(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a9785 in k9739 in go in k9323 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_9786(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9786,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_plus(&a,2,t3,C_fix(1));
t5=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[4]);
/* go1134 */
t6=((C_word*)((C_word*)t0)[3])[1];
f_9327(t6,t1,t4,t5,((C_word*)t0)[2]);}

/* k9769 in k9739 in go in k9323 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_9771(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* sre->cset */
f_18742(((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k9742 in k9739 in go in k9323 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_9744(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9744,2,t0,t1);}
t2=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[6],C_fix(2));
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9755,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9767,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* filter */
f_5919(t4,*((C_word*)lf[134]+1),t1);}

/* k9765 in k9742 in k9739 in go in k9323 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_9767(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* append */
t2=*((C_word*)lf[125]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k9753 in k9742 in k9739 in go in k9323 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_9755(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9755,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9759,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9763,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* filter */
f_5919(t3,*((C_word*)lf[133]+1),((C_word*)t0)[2]);}

/* k9761 in k9753 in k9742 in k9739 in go in k9323 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_9763(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* append */
t2=*((C_word*)lf[125]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k9757 in k9753 in k9742 in k9739 in go in k9323 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_9759(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* go1134 */
t2=((C_word*)((C_word*)t0)[5])[1];
f_9327(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k9614 in go in k9323 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_9616(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9616,2,t0,t1);}
t2=(C_word)C_i_not(t1);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_9625,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
if(C_truep(t2)){
t4=t3;
f_9625(t4,t2);}
else{
t4=(C_word)C_a_i_plus(&a,2,t1,C_fix(1));
t5=(C_word)C_subchar(((C_word*)t0)[7],t4);
t6=(C_word)C_eqp(C_make_character(93),t5);
t7=t3;
f_9625(t7,(C_word)C_i_not(t6));}}

/* k9623 in k9614 in go in k9323 in lp in k6268 in string->sre in k4869 */
static void C_fcall f_9625(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9625,NULL,2,t0,t1);}
if(C_truep(t1)){
/* error */
t2=*((C_word*)lf[24]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[9],lf[132],((C_word*)t0)[8]);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9631,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9664,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9668,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[2],C_fix(1));
/* substring */
t6=*((C_word*)lf[28]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t4,((C_word*)t0)[8],t5,((C_word*)t0)[7]);}}

/* k9666 in k9623 in k9614 in go in k9323 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_9668(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* string->symbol */
t2=*((C_word*)lf[104]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k9662 in k9623 in k9614 in go in k9323 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_9664(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* sre->cset */
f_18742(((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k9629 in k9623 in k9614 in go in k9323 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_9631(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9631,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9634,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[2])){
/* cset-complement */
f_19544(t2,t1);}
else{
t3=t2;
f_9634(2,t3,t1);}}

/* k9632 in k9629 in k9623 in k9614 in go in k9323 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_9634(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9634,2,t0,t1);}
t2=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[6],C_fix(2));
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9645,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9657,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* filter */
f_5919(t4,*((C_word*)lf[134]+1),t1);}

/* k9655 in k9632 in k9629 in k9623 in k9614 in go in k9323 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_9657(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* append */
t2=*((C_word*)lf[125]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k9643 in k9632 in k9629 in k9623 in k9614 in go in k9323 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_9645(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9645,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9649,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9653,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* filter */
f_5919(t3,*((C_word*)lf[133]+1),((C_word*)t0)[2]);}

/* k9651 in k9643 in k9632 in k9629 in k9623 in k9614 in go in k9323 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_9653(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* append */
t2=*((C_word*)lf[125]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k9647 in k9643 in k9632 in k9629 in k9623 in k9614 in go in k9323 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_9649(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* go1134 */
t2=((C_word*)((C_word*)t0)[5])[1];
f_9327(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k9562 in go in k9323 in lp in k6268 in string->sre in k4869 */
static void C_fcall f_9564(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9564,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_9477(t2,t1);}
else{
t2=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[3],C_fix(1));
t3=(C_word)C_subchar(((C_word*)t0)[2],t2);
t4=((C_word*)t0)[4];
f_9477(t4,(C_word)C_eqp(C_make_character(93),t3));}}

/* k9475 in go in k9323 in lp in k6268 in string->sre in k4869 */
static void C_fcall f_9477(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9477,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[9],C_fix(1));
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],((C_word*)t0)[7]);
/* go1134 */
t4=((C_word*)((C_word*)t0)[6])[1];
f_9327(t4,((C_word*)t0)[5],t2,t3,((C_word*)t0)[4]);}
else{
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[7]))){
/* error */
t2=*((C_word*)lf[24]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[5],lf[129]);}
else{
t2=(C_word)C_u_i_car(((C_word*)t0)[7]);
t3=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[9],C_fix(1));
t4=(C_word)C_subchar(((C_word*)t0)[3],t3);
t5=(C_truep(((C_word*)t0)[2])?f_9947(t4):C_fix(1));
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9509,a[2]=t5,a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[5],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9540,a[2]=t4,a[3]=t5,a[4]=((C_word*)t0)[3],a[5]=t6,a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[2])){
t8=(C_word)C_fix((C_word)C_character_code(t4));
/* <= */
C_less_or_equal_p(5,0,t7,C_fix(128),t8,C_fix(255));}
else{
t8=t7;
f_9540(2,t8,C_SCHEME_FALSE);}}}}

/* k9538 in k9475 in go in k9323 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_9540(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9540,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[6],C_fix(1));
/* utf8-string-ref */
f_9957(((C_word*)t0)[5],((C_word*)t0)[4],t2,((C_word*)t0)[3]);}
else{
t2=((C_word*)t0)[5];
f_9509(2,t2,((C_word*)t0)[2]);}}

/* k9507 in k9475 in go in k9323 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_9509(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9509,2,t0,t1);}
if(C_truep((C_word)C_fixnum_lessp(t1,((C_word*)t0)[8]))){
/* error */
t2=*((C_word*)lf[24]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[7],lf[131],((C_word*)t0)[8],t1);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9525,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* + */
C_plus(5,0,t2,((C_word*)t0)[3],C_fix(1),((C_word*)t0)[2]);}}

/* k9523 in k9507 in k9475 in go in k9323 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_9525(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9525,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[7],C_fix(1));
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],((C_word*)t0)[5]);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[4]);
/* go1134 */
t5=((C_word*)((C_word*)t0)[3])[1];
f_9327(t5,((C_word*)t0)[2],t1,t2,t4);}

/* k9364 in go in k9323 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_9366(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9366,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9369,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)t0)[3])){
/* filter */
f_5919(t2,lf[128],((C_word*)t0)[2]);}
else{
t3=t2;
f_9369(2,t3,C_SCHEME_END_OF_LIST);}}

/* k9367 in k9364 in go in k9323 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_9369(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9369,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9372,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=((C_word*)t0)[2];
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5968,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_5968(t7,t2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=t2;
f_9372(2,t3,((C_word*)t0)[2]);}}

/* lp in k9367 in k9364 in go in k9323 in lp in k6268 in string->sre in k4869 */
static void C_fcall f_5968(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5968,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
/* reverse */
t4=*((C_word*)lf[40]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}
else{
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5989,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5992,a[2]=t2,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_u_i_car(t2);
/* pred446 */
t8=lf[128];
f_9937(3,t8,t6,t7);}}

/* k5990 in lp in k9367 in k9364 in go in k9323 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_5992(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5992,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_5989(t2,((C_word*)t0)[3]);}
else{
t2=(C_word)C_u_i_car(((C_word*)t0)[2]);
t3=((C_word*)t0)[4];
f_5989(t3,(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[3]));}}

/* k5987 in lp in k9367 in k9364 in go in k9323 in lp in k6268 in string->sre in k4869 */
static void C_fcall f_5989(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp449 */
t2=((C_word*)((C_word*)t0)[4])[1];
f_5968(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k9370 in k9367 in k9364 in go in k9323 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_9372(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9372,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9379,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9392,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_pairp(t1))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9437,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9441,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9445,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* reverse */
t7=*((C_word*)lf[40]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t1);}
else{
t4=t3;
f_9392(t4,C_SCHEME_END_OF_LIST);}}

/* k9443 in k9370 in k9367 in k9364 in go in k9323 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_9445(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9445,2,t0,t1);}
t2=(C_truep(((C_word*)t0)[3])?lf[126]:(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9449,tmp=(C_word)a,a+=2,tmp));
t3=t2;
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t1);}

/* f_9449 in k9443 in k9370 in k9367 in k9364 in go in k9323 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_9449(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9449,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k9439 in k9370 in k9367 in k9364 in go in k9323 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_9441(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* list->string */
t2=*((C_word*)lf[127]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k9435 in k9370 in k9367 in k9364 in go in k9323 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_9437(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9437,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[2];
f_9392(t3,(C_word)C_a_i_list(&a,1,t2));}

/* k9390 in k9370 in k9367 in k9364 in go in k9323 in lp in k6268 in string->sre in k4869 */
static void C_fcall f_9392(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9392,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9396,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9402,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[2])){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9420,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* reverse */
t5=*((C_word*)lf[40]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[3]);}
else{
/* reverse */
t4=*((C_word*)lf[40]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[3]);}}
else{
t3=t2;
f_9396(t3,C_SCHEME_END_OF_LIST);}}

/* k9418 in k9390 in k9370 in k9367 in k9364 in go in k9323 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_9420(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* cset-case-insensitive */
t2=lf[126];
f_19554(3,t2,((C_word*)t0)[2],t1);}

/* k9400 in k9390 in k9370 in k9367 in k9364 in go in k9323 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_9402(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9402,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9413,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_18707,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_18707(t6,t2,t1,C_SCHEME_END_OF_LIST);}

/* lp in k9400 in k9390 in k9370 in k9367 in k9364 in go in k9323 in lp in k6268 in string->sre in k4869 */
static void C_fcall f_18707(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(6);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_18707,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
/* reverse */
t4=*((C_word*)lf[40]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}
else{
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_u_i_cdar(t2);
t6=(C_word)C_u_i_caar(t2);
t7=(C_word)C_a_i_cons(&a,2,t6,t3);
t8=(C_word)C_a_i_cons(&a,2,t5,t7);
/* lp3785 */
t10=t1;
t11=t4;
t12=t8;
t1=t10;
t2=t11;
t3=t12;
goto loop;}}

/* k9411 in k9400 in k9390 in k9370 in k9367 in k9364 in go in k9323 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_9413(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9413,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[31],t1);
t3=((C_word*)t0)[2];
f_9396(t3,(C_word)C_a_i_list(&a,1,t2));}

/* k9394 in k9390 in k9370 in k9367 in k9364 in go in k9323 in lp in k6268 in string->sre in k4869 */
static void C_fcall f_9396(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* append */
t2=*((C_word*)lf[125]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k9377 in k9370 in k9367 in k9364 in go in k9323 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_9379(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9379,2,t0,t1);}
t2=(C_truep(((C_word*)t0)[4])?(C_word)C_a_i_cons(&a,2,lf[124],t1):f_13416(C_a_i(&a,3),t1));
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,t2,((C_word*)t0)[2]));}

/* k7850 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_7852(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a7827 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_7828(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7828,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_plus(&a,2,t3,C_fix(1));
t5=(C_word)C_a_i_plus(&a,2,t3,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7848,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t5,a[5]=t4,a[6]=t1,a[7]=((C_word*)t0)[5],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
/* collect578 */
t7=((C_word*)t0)[2];
f_6328(t7,t6);}

/* k7846 in a7827 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_7848(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7848,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
/* lp569 */
t3=((C_word*)((C_word*)t0)[7])[1];
f_6275(t3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k7811 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_7813(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7813,2,t0,t1);}
t2=(C_word)C_u_i_cdar(((C_word*)t0)[7]);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_slot(((C_word*)t0)[7],C_fix(1));
/* lp569 */
t5=((C_word*)((C_word*)t0)[6])[1];
f_6275(t5,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t3,t4);}

/* k7076 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_7078(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7078,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7082,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* save581 */
t3=((C_word*)t0)[2];
f_6720(t3,t2);}

/* k7080 in k7076 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_7082(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp569 */
t2=((C_word*)((C_word*)t0)[6])[1];
f_6275(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_END_OF_LIST,t1);}

/* lp2 in lp in k6268 in string->sre in k4869 */
static void C_fcall f_7547(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word *a;
loop:
a=C_alloc(28);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_7547,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7550,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7559,a[2]=((C_word*)t0)[9],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_greater_or_equalp(t2,((C_word*)t0)[8]))){
/* error */
t7=*((C_word*)lf[24]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t1,lf[120],((C_word*)t0)[7],((C_word*)t0)[6]);}
else{
t7=(C_word)C_subchar(((C_word*)t0)[7],t2);
switch(t7){
case C_make_character(105):
t8=(C_word)C_a_i_plus(&a,2,t2,C_fix(1));
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7608,a[2]=t4,a[3]=t8,a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* join832 */
t10=t5;
f_7550(t10,t9,C_fix(2));
case C_make_character(109):
t8=(C_word)C_a_i_plus(&a,2,t2,C_fix(1));
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7625,a[2]=t4,a[3]=t8,a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* join832 */
t10=t5;
f_7550(t10,t9,C_fix(4));
case C_make_character(120):
t8=(C_word)C_a_i_plus(&a,2,t2,C_fix(1));
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7642,a[2]=t4,a[3]=t8,a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* join832 */
t10=t5;
f_7550(t10,t9,C_fix(16));
case C_make_character(117):
t8=(C_word)C_a_i_plus(&a,2,t2,C_fix(1));
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7662,a[2]=t4,a[3]=t8,a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* join832 */
t10=t5;
f_7550(t10,t9,C_fix(32));
case C_make_character(45):
t8=(C_word)C_a_i_plus(&a,2,t2,C_fix(1));
t9=(C_word)C_i_not(t4);
/* lp2820 */
t26=t1;
t27=t8;
t28=t3;
t29=t9;
t1=t26;
t2=t27;
t3=t28;
t4=t29;
goto loop;
case C_make_character(41):
t8=(C_word)C_a_i_plus(&a,2,t2,C_fix(1));
t9=(C_word)C_a_i_plus(&a,2,t2,C_fix(1));
t10=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7707,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t9,a[5]=t8,a[6]=t1,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7711,a[2]=t10,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* collect578 */
t12=((C_word*)t0)[2];
f_6328(t12,t11);
case C_make_character(58):
t8=(C_word)C_a_i_plus(&a,2,t2,C_fix(1));
t9=(C_word)C_a_i_plus(&a,2,t2,C_fix(1));
t10=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7732,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t9,a[5]=t8,a[6]=t1,a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[3],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* new-res833 */
t11=t6;
f_7559(t11,t10,C_SCHEME_END_OF_LIST);
default:
/* error */
t8=*((C_word*)lf[24]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t1,lf[121],((C_word*)t0)[7]);}}}

/* k7730 in lp2 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_7732(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7732,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7744,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* collect578 */
t3=((C_word*)t0)[2];
f_6328(t3,t2);}

/* k7742 in k7730 in lp2 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_7744(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7744,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[8]);
/* lp569 */
t4=((C_word*)((C_word*)t0)[7])[1];
f_6275(t4,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* k7709 in lp2 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_7711(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* new-res833 */
t2=((C_word*)t0)[3];
f_7559(t2,((C_word*)t0)[2],t1);}

/* k7705 in lp2 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_7707(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp569 */
t2=((C_word*)((C_word*)t0)[7])[1];
f_6275(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k7660 in lp2 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_7662(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp2820 */
t2=((C_word*)((C_word*)t0)[5])[1];
f_7547(t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k7640 in lp2 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_7642(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp2820 */
t2=((C_word*)((C_word*)t0)[5])[1];
f_7547(t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k7623 in lp2 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_7625(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp2820 */
t2=((C_word*)((C_word*)t0)[5])[1];
f_7547(t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k7606 in lp2 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_7608(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp2820 */
t2=((C_word*)((C_word*)t0)[5])[1];
f_7547(t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* new-res in lp2 in lp in k6268 in string->sre in k4869 */
static void C_fcall f_7559(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7559,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7563,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* flag-set? */
f_6125(t3,((C_word*)t0)[2],C_fix(32));}

/* k7561 in new-res in lp2 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_7563(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7563,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7566,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* flag-set? */
f_6125(t2,((C_word*)t0)[2],C_fix(32));}

/* k7564 in k7561 in new-res in lp2 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_7566(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7566,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[4],t1);
if(C_truep(t2)){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[2]);}
else{
t3=(C_truep(t1)?lf[118]:lf[119]);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[2]));}}

/* join in lp2 in lp in k6268 in string->sre in k4869 */
static void C_fcall f_7550(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7550,NULL,3,t0,t1,t2);}
t3=(C_truep(((C_word*)t0)[3])?lf[55]:lf[54]);
t4=t3;
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,((C_word*)t0)[2],t2);}

/* k7503 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_7505(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7505,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7509,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* save581 */
t3=((C_word*)t0)[2];
f_6720(t3,t2);}

/* k7507 in k7503 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_7509(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp569 */
t2=((C_word*)((C_word*)t0)[6])[1];
f_6275(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[116],t1);}

/* k7446 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_7448(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7448,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7451,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7482,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[3],C_fix(3));
/* substring */
t5=*((C_word*)lf[28]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t3,((C_word*)t0)[2],t4,t1);}

/* k7480 in k7446 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_7482(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* string->symbol */
t2=*((C_word*)lf[104]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k7449 in k7446 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_7451(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7451,2,t0,t1);}
t2=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[6],C_fix(1));
t3=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[6],C_fix(1));
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7466,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* flag-clear */
t5=lf[55];
f_6144(4,t5,t4,((C_word*)t0)[2],C_fix(1));}

/* k7464 in k7449 in k7446 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_7466(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7466,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[77],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t2);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7474,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* save581 */
t5=((C_word*)t0)[2];
f_6720(t5,t4);}

/* k7472 in k7464 in k7449 in k7446 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_7474(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp569 */
t2=((C_word*)((C_word*)t0)[7])[1];
f_6275(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7386 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_7388(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7388,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7391,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7431,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[2],C_fix(3));
/* substring */
t5=*((C_word*)lf[28]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t3,((C_word*)t0)[3],t4,t1);}

/* k7429 in k7386 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_7431(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* string->number */
C_string_to_number(3,0,((C_word*)t0)[2],t1);}

/* k7389 in k7386 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_7391(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7391,2,t0,t1);}
t2=t1;
if(C_truep(t2)){
t3=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[7],C_fix(1));
t4=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[7],C_fix(1));
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7415,a[2]=((C_word*)t0)[4],a[3]=t4,a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* flag-clear */
t6=lf[55];
f_6144(4,t6,t5,((C_word*)t0)[3],C_fix(1));}
else{
/* error */
t3=*((C_word*)lf[24]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[5],lf[115],((C_word*)t0)[2]);}}

/* k7413 in k7389 in k7386 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_7415(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7415,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[77],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t2);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7423,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* save581 */
t5=((C_word*)t0)[2];
f_6720(t5,t4);}

/* k7421 in k7413 in k7389 in k7386 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_7423(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp569 */
t2=((C_word*)((C_word*)t0)[7])[1];
f_6275(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7358 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_7360(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7360,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7364,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* save581 */
t3=((C_word*)t0)[2];
f_6720(t3,t2);}

/* k7362 in k7358 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_7364(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp569 */
t2=((C_word*)((C_word*)t0)[6])[1];
f_6275(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[113],t1);}

/* k7266 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_7268(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7268,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_plus(&a,2,t1,C_fix(1));
t3=(C_word)C_a_i_plus(&a,2,t1,C_fix(1));
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7286,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t3,a[7]=t2,a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp);
/* flag-clear */
t5=lf[55];
f_6144(4,t5,t4,((C_word*)t0)[2],C_fix(1));}
else{
/* error */
t2=*((C_word*)lf[24]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[6],lf[112],((C_word*)t0)[3]);}}

/* k7284 in k7266 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_7286(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7286,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7298,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7306,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[4],C_fix(3));
/* substring */
t5=*((C_word*)lf[28]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t3,((C_word*)t0)[3],t4,((C_word*)t0)[2]);}

/* k7304 in k7284 in k7266 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_7306(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* string->symbol */
t2=*((C_word*)lf[104]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k7296 in k7284 in k7266 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_7298(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7298,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[85],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7294,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* save581 */
t5=((C_word*)t0)[2];
f_6720(t5,t4);}

/* k7292 in k7296 in k7284 in k7266 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_7294(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp569 */
t2=((C_word*)((C_word*)t0)[7])[1];
f_6275(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7259 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_7261(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7261,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7265,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* save581 */
t3=((C_word*)t0)[2];
f_6720(t3,t2);}

/* k7263 in k7259 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_7265(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp569 */
t2=((C_word*)((C_word*)t0)[6])[1];
f_6275(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[111],t1);}

/* k7234 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_7236(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7236,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7240,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* save581 */
t3=((C_word*)t0)[2];
f_6720(t3,t2);}

/* k7238 in k7234 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_7240(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp569 */
t2=((C_word*)((C_word*)t0)[6])[1];
f_6275(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[110],t1);}

/* k7191 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_7193(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7193,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7197,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* save581 */
t3=((C_word*)t0)[2];
f_6720(t3,t2);}

/* k7195 in k7191 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_7197(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp569 */
t2=((C_word*)((C_word*)t0)[6])[1];
f_6275(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[108],t1);}

/* k7166 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_7168(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7168,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7172,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* save581 */
t3=((C_word*)t0)[2];
f_6720(t3,t2);}

/* k7170 in k7166 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_7172(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp569 */
t2=((C_word*)((C_word*)t0)[6])[1];
f_6275(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[107],t1);}

/* k7141 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_7143(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7143,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7147,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* save581 */
t3=((C_word*)t0)[2];
f_6720(t3,t2);}

/* k7145 in k7141 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_7147(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp569 */
t2=((C_word*)((C_word*)t0)[6])[1];
f_6275(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_END_OF_LIST,t1);}

/* k7101 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_7103(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7103,2,t0,t1);}
t2=(C_word)C_a_i_plus(&a,2,t1,((C_word*)t0)[7]);
t3=(C_word)C_a_i_plus(&a,2,t1,C_fix(1));
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7118,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t2,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* collect578 */
t5=((C_word*)t0)[2];
f_6328(t5,t4);}

/* k7116 in k7101 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_7118(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp569 */
t2=((C_word*)((C_word*)t0)[7])[1];
f_6275(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k6989 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_6991(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6991,2,t0,t1);}
t2=(C_word)C_u_i_car(t1);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6997,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t2,tmp=(C_word)a,a+=10,tmp);
t4=(C_word)C_a_i_string(&a,1,((C_word*)t0)[2]);
/* string->symbol */
t5=*((C_word*)lf[104]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k6995 in k6989 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_6997(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6997,2,t0,t1);}
t2=f_12042(((C_word*)t0)[9]);
if(C_truep(t2)){
/* error */
t3=*((C_word*)lf[24]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[8],lf[101],((C_word*)t0)[7],((C_word*)t0)[6]);}
else{
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7012,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[9],a[6]=t1,a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp);
/* sre-empty? */
t4=lf[103];
f_11838(3,t4,t3,((C_word*)t0)[9]);}}

/* k7010 in k6995 in k6989 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_7012(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7012,2,t0,t1);}
if(C_truep(t1)){
/* error */
t2=*((C_word*)lf[24]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[10],lf[102],((C_word*)t0)[9],((C_word*)t0)[8]);}
else{
t2=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[7],C_fix(1));
t3=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[7],C_fix(1));
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[6],((C_word*)t0)[5]);
t5=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
t6=(C_word)C_a_i_cons(&a,2,t4,t5);
/* lp569 */
t7=((C_word*)((C_word*)t0)[4])[1];
f_6275(t7,((C_word*)t0)[10],t2,t3,((C_word*)t0)[3],t6,((C_word*)t0)[2]);}}

/* k6792 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_6794(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6794,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
/* error */
t2=*((C_word*)lf[24]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[7],lf[90],((C_word*)t0)[6],t1);}
else{
t2=(C_word)C_u_i_car(t1);
t3=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[5],C_fix(1));
t4=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[5],C_fix(1));
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6825,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=t3,a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[4],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t6=(C_word)C_u_i_car(t2);
t7=(C_word)C_eqp(t6,lf[91]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6848,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t9=(C_word)C_slot(t2,C_fix(1));
/* ##sys#append */
t10=*((C_word*)lf[84]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t8,t9,C_SCHEME_END_OF_LIST);}
else{
t8=(C_word)C_eqp(t6,lf[93]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6873,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t10=(C_word)C_slot(t2,C_fix(1));
/* ##sys#append */
t11=*((C_word*)lf[84]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t9,t10,C_SCHEME_END_OF_LIST);}
else{
t9=(C_word)C_eqp(t6,lf[95]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6890,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t11=(C_word)C_slot(t2,C_fix(1));
/* ##sys#append */
t12=*((C_word*)lf[84]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t10,t11,C_SCHEME_END_OF_LIST);}
else{
t10=(C_word)C_eqp(t6,lf[97]);
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6907,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t12=(C_word)C_slot(t2,C_fix(1));
/* ##sys#append */
t13=*((C_word*)lf[84]+1);
((C_proc4)(void*)(*((C_word*)t13+1)))(4,t13,t11,t12,C_SCHEME_END_OF_LIST);}
else{
t11=(C_word)C_eqp(t6,lf[98]);
if(C_truep(t11)){
t12=(C_word)C_u_i_cadr(t2);
t13=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6932,a[2]=t5,a[3]=t12,tmp=(C_word)a,a+=4,tmp);
t14=(C_word)C_slot(t2,C_fix(1));
/* ##sys#append */
t15=*((C_word*)lf[84]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t13,t14,C_SCHEME_END_OF_LIST);}
else{
t12=(C_word)C_eqp(t6,lf[99]);
if(C_truep(t12)){
t13=(C_word)C_u_i_cadr(t2);
t14=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6961,a[2]=t5,a[3]=t13,tmp=(C_word)a,a+=4,tmp);
t15=(C_word)C_u_i_cddr(t2);
/* ##sys#append */
t16=*((C_word*)lf[84]+1);
((C_proc4)(void*)(*((C_word*)t16+1)))(4,t16,t14,t15,C_SCHEME_END_OF_LIST);}
else{
t13=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t14=t5;
f_6825(t14,(C_word)C_a_i_cons(&a,2,lf[95],t13));}}}}}}}
else{
t6=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t7=t5;
f_6825(t7,(C_word)C_a_i_cons(&a,2,lf[95],t6));}}}

/* k6959 in k6792 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_6961(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6961,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
f_6825(t4,(C_word)C_a_i_cons(&a,2,lf[94],t3));}

/* k6930 in k6792 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_6932(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6932,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
f_6825(t3,(C_word)C_a_i_cons(&a,2,lf[94],t2));}

/* k6905 in k6792 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_6907(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6907,2,t0,t1);}
t2=((C_word*)t0)[2];
f_6825(t2,(C_word)C_a_i_cons(&a,2,lf[94],t1));}

/* k6888 in k6792 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_6890(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6890,2,t0,t1);}
t2=((C_word*)t0)[2];
f_6825(t2,(C_word)C_a_i_cons(&a,2,lf[96],t1));}

/* k6871 in k6792 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_6873(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6873,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,t1);
t3=(C_word)C_a_i_cons(&a,2,C_fix(1),t2);
t4=((C_word*)t0)[2];
f_6825(t4,(C_word)C_a_i_cons(&a,2,lf[94],t3));}

/* k6846 in k6792 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_6848(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6848,2,t0,t1);}
t2=((C_word*)t0)[2];
f_6825(t2,(C_word)C_a_i_cons(&a,2,lf[92],t1));}

/* k6823 in k6792 in lp in k6268 in string->sre in k4869 */
static void C_fcall f_6825(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6825,NULL,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
/* lp569 */
t4=((C_word*)((C_word*)t0)[7])[1];
f_6275(t4,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t3,((C_word*)t0)[2]);}

/* k6783 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_6785(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6785,2,t0,t1);}
t2=(C_truep(t1)?lf[88]:lf[89]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6782,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
/* collect578 */
t4=((C_word*)t0)[2];
f_6328(t4,t3);}

/* k6780 in k6783 in lp in k6268 in string->sre in k4869 */
static void C_ccall f_6782(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6782,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
/* lp569 */
t3=((C_word*)((C_word*)t0)[7])[1];
f_6275(t3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* save in lp in k6268 in string->sre in k4869 */
static void C_fcall f_6720(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6720,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6732,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* collect578 */
t3=((C_word*)t0)[2];
f_6328(t3,t2);}

/* k6730 in save in lp in k6268 in string->sre in k4869 */
static void C_ccall f_6732(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6732,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[2]));}

/* collect/terms in lp in k6268 in string->sre in k4869 */
static void C_fcall f_6420(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6420,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6424,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* collect578 */
t3=((C_word*)t0)[2];
f_6328(t3,t2);}

/* k6422 in collect/terms in lp in k6268 in string->sre in k4869 */
static void C_ccall f_6424(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6424,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6427,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(t1))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6718,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* last */
f_5749(t3,t1);}
else{
t3=t2;
f_6427(t3,C_SCHEME_FALSE);}}

/* k6716 in k6422 in collect/terms in lp in k6268 in string->sre in k4869 */
static void C_ccall f_6718(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_6427(t2,(C_word)C_u_i_memq(t1,lf[86]));}

/* k6425 in k6422 in collect/terms in lp in k6268 in string->sre in k4869 */
static void C_fcall f_6427(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6427,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6430,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6680,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t4=(C_word)C_u_i_car(t1);
t5=t3;
f_6680(t5,(C_word)C_eqp(lf[85],t4));}
else{
t4=t3;
f_6680(t4,C_SCHEME_FALSE);}}

/* k6678 in k6425 in k6422 in collect/terms in lp in k6268 in string->sre in k4869 */
static void C_fcall f_6680(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6680,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6691,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* reverse */
t3=*((C_word*)lf[40]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}
else{
if(C_truep(((C_word*)t0)[2])){
t2=(C_word)C_u_i_car(((C_word*)t0)[2]);
t3=((C_word*)t0)[4];
f_6430(t3,(C_word)C_a_i_list(&a,1,t2));}
else{
t2=((C_word*)t0)[4];
f_6430(t2,C_SCHEME_FALSE);}}}

/* k6689 in k6678 in k6425 in k6422 in collect/terms in lp in k6268 in string->sre in k4869 */
static void C_ccall f_6691(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6691,2,t0,t1);}
t2=(C_word)C_u_i_cadr(t1);
t3=((C_word*)t0)[2];
f_6430(t3,(C_word)C_a_i_list(&a,2,lf[85],t2));}

/* k6428 in k6425 in k6422 in collect/terms in lp in k6268 in string->sre in k4869 */
static void C_fcall f_6430(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6430,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6433,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=(C_word)C_u_i_car(((C_word*)t0)[3]);
t4=(C_word)C_eqp(lf[85],t3);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6662,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* reverse */
t6=*((C_word*)lf[40]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[2]);}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6673,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* reverse */
t6=*((C_word*)lf[40]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[2]);}}
else{
t3=t2;
f_6433(2,t3,((C_word*)t0)[2]);}}

/* k6671 in k6428 in k6425 in k6422 in collect/terms in lp in k6268 in string->sre in k4869 */
static void C_ccall f_6673(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(t1,C_fix(1));
/* reverse */
t3=*((C_word*)lf[40]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t2);}

/* k6660 in k6428 in k6425 in k6422 in collect/terms in lp in k6268 in string->sre in k4869 */
static void C_ccall f_6662(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_i_cddr(t1);
/* reverse */
t3=*((C_word*)lf[40]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t2);}

/* k6431 in k6428 in k6425 in k6422 in collect/terms in lp in k6268 in string->sre in k4869 */
static void C_ccall f_6433(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6433,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6438,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_6438(t5,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}

/* lp in k6431 in k6428 in k6425 in k6422 in collect/terms in lp in k6268 in string->sre in k4869 */
static void C_fcall f_6438(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word *a;
loop:
a=C_alloc(18);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_6438,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6441,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
t6=f_6441(C_a_i(&a,6),t5);
t7=f_13416(C_a_i(&a,3),t6);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6602,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t7,tmp=(C_word)a,a+=5,tmp);
/* flag-set? */
f_6125(t8,((C_word*)t0)[3],C_fix(1));}
else{
t6=(C_word)C_u_i_car(t2);
t7=(C_word)C_eqp(lf[70],t6);
if(C_truep(t7)){
t8=(C_word)C_slot(t2,C_fix(1));
t9=f_6441(C_a_i(&a,6),t5);
/* lp636 */
t17=t1;
t18=t8;
t19=C_SCHEME_END_OF_LIST;
t20=t9;
t1=t17;
t2=t18;
t3=t19;
t4=t20;
goto loop;}
else{
t8=(C_word)C_slot(t2,C_fix(1));
t9=(C_word)C_u_i_car(t2);
t10=(C_word)C_a_i_cons(&a,2,t9,t3);
/* lp636 */
t17=t1;
t18=t8;
t19=t10;
t20=t4;
t1=t17;
t2=t18;
t3=t19;
t4=t20;
goto loop;}}}

/* k6600 in lp in k6431 in k6428 in k6425 in k6422 in collect/terms in lp in k6268 in string->sre in k4869 */
static void C_ccall f_6602(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6602,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_a_i_list(&a,2,lf[76],((C_word*)t0)[4]):((C_word*)t0)[4]);
if(C_truep(((C_word*)t0)[3])){
t3=(C_word)C_u_i_car(((C_word*)t0)[3]);
t4=(C_word)C_eqp(lf[77],t3);
if(C_truep(t4)){
if(C_truep((C_word)C_i_pairp(t2))){
t5=(C_word)C_u_i_car(t2);
if(C_truep((C_truep((C_word)C_eqp(t5,lf[78]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t5,lf[79]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t5,lf[80]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t5,lf[81]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))))){
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t2);}
else{
t6=(C_word)C_u_i_car(t2);
t7=(C_word)C_eqp(lf[82],t6);
if(C_truep(t7)){
t8=(C_word)C_u_i_cadr(t2);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6507,a[2]=((C_word*)t0)[2],a[3]=t8,tmp=(C_word)a,a+=4,tmp);
t10=(C_word)C_slot(t2,C_fix(1));
if(C_truep((C_word)C_i_pairp(t10))){
t11=(C_word)C_u_i_cddr(t2);
/* sre-sequence */
t12=t9;
f_6507(t12,f_13391(C_a_i(&a,3),t11));}
else{
t11=t9;
f_6507(t11,lf[83]);}}
else{
t8=(C_word)C_u_i_cadadr(t2);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6540,a[2]=((C_word*)t0)[2],a[3]=t8,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t10=(C_word)C_slot(t2,C_fix(1));
if(C_truep((C_word)C_i_pairp(t10))){
t11=(C_word)C_u_i_cddadr(t2);
/* sre-sequence */
t12=t9;
f_6540(t12,f_13391(C_a_i(&a,3),t11));}
else{
t11=t9;
f_6540(t11,lf[83]);}}}}
else{
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,lf[83]);}}
else{
t5=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
/* ##sys#append */
t6=*((C_word*)lf[84]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,((C_word*)t0)[2],((C_word*)t0)[3],t5);}}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k6538 in k6600 in lp in k6431 in k6428 in k6425 in k6422 in collect/terms in lp in k6268 in string->sre in k4869 */
static void C_fcall f_6540(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6540,NULL,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=(C_word)C_i_pairp(t2);
t4=(C_truep(t3)?(C_word)C_u_i_cddr(((C_word*)t0)[4]):C_SCHEME_END_OF_LIST);
t5=f_13416(C_a_i(&a,3),t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,t1,t6);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t7);
t9=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_a_i_cons(&a,2,lf[77],t8));}

/* k6505 in k6600 in lp in k6431 in k6428 in k6425 in k6422 in collect/terms in lp in k6268 in string->sre in k4869 */
static void C_fcall f_6507(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6507,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[77],t3));}

/* shift in lp in k6431 in k6428 in k6425 in k6422 in collect/terms in lp in k6268 in string->sre in k4869 */
static C_word C_fcall f_6441(C_word *a,C_word t0){
C_word tmp;
C_word t1;
C_word t2;
t1=f_13391(C_a_i(&a,3),((C_word*)t0)[3]);
return((C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[2]));}

/* collect/single in lp in k6268 in string->sre in k4869 */
static void C_fcall f_6348(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6348,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6352,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* flag-set? */
f_6125(t2,((C_word*)t0)[2],C_fix(32));}

/* k6350 in collect/single in lp in k6268 in string->sre in k4869 */
static void C_ccall f_6352(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6352,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6355,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=(C_truep(t1)?(C_word)C_i_greaterp(((C_word*)t0)[2],C_fix(1)):C_SCHEME_FALSE);
if(C_truep(t3)){
t4=(C_word)C_a_i_minus(&a,2,((C_word*)t0)[2],C_fix(1));
t5=((C_word*)t0)[4];
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10147,a[2]=t7,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_10147(t9,t2,t4);}
else{
t4=t2;
f_6355(2,t4,(C_word)C_a_i_minus(&a,2,((C_word*)t0)[2],C_fix(1)));}}

/* lp in k6350 in collect/single in lp in k6268 in string->sre in k4869 */
static void C_fcall f_10147(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_10147,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nequalp(t2,C_fix(0)))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_fix(0));}
else{
t3=(C_word)C_subchar(((C_word*)t0)[3],t2);
t4=(C_word)C_fix((C_word)C_character_code(t3));
t5=(C_word)C_i_lessp(t4,C_fix(128));
t6=(C_truep(t5)?t5:(C_word)C_i_greater_or_equalp(t4,C_fix(192)));
if(C_truep(t6)){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t2);}
else{
t7=(C_word)C_a_i_minus(&a,2,t2,C_fix(1));
/* lp1316 */
t9=t1;
t10=t7;
t1=t9;
t2=t10;
goto loop;}}}

/* k6353 in k6350 in collect/single in lp in k6268 in string->sre in k4869 */
static void C_ccall f_6355(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6355,2,t0,t1);}
if(C_truep((C_word)C_i_lessp(t1,((C_word*)t0)[9]))){
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[7]);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6364,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6392,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[3])){
t4=(C_word)C_a_i_minus(&a,2,((C_word*)t0)[2],t1);
/* utf8-string-ref */
f_9957(t3,((C_word*)t0)[5],t1,t4);}
else{
t4=t3;
f_6392(2,t4,(C_word)C_subchar(((C_word*)t0)[5],t1));}}}

/* k6390 in k6353 in k6350 in collect/single in lp in k6268 in string->sre in k4869 */
static void C_ccall f_6392(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* cased-char576 */
t2=((C_word*)t0)[3];
f_6278(3,t2,((C_word*)t0)[2],t1);}

/* k6362 in k6353 in k6350 in collect/single in lp in k6268 in string->sre in k4869 */
static void C_ccall f_6364(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6364,2,t0,t1);}
if(C_truep((C_word)C_i_nequalp(((C_word*)t0)[7],((C_word*)t0)[6]))){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[4]));}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6384,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6388,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* substring */
t4=*((C_word*)lf[28]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)t0)[2],((C_word*)t0)[6],((C_word*)t0)[7]);}}

/* k6386 in k6362 in k6353 in k6350 in collect/single in lp in k6268 in string->sre in k4869 */
static void C_ccall f_6388(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* cased-string577 */
t2=((C_word*)t0)[3];
f_6308(t2,((C_word*)t0)[2],t1);}

/* k6382 in k6362 in k6353 in k6350 in collect/single in lp in k6268 in string->sre in k4869 */
static void C_ccall f_6384(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6384,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* collect in lp in k6268 in string->sre in k4869 */
static void C_fcall f_6328(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6328,NULL,2,t0,t1);}
if(C_truep((C_word)C_i_nequalp(((C_word*)t0)[6],((C_word*)t0)[5]))){
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6342,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6346,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* substring */
t4=*((C_word*)lf[28]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)t0)[2],((C_word*)t0)[5],((C_word*)t0)[6]);}}

/* k6344 in collect in lp in k6268 in string->sre in k4869 */
static void C_ccall f_6346(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* cased-string577 */
t2=((C_word*)t0)[3];
f_6308(t2,((C_word*)t0)[2],t1);}

/* k6340 in collect in lp in k6268 in string->sre in k4869 */
static void C_ccall f_6342(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6342,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[2]));}

/* cased-string in lp in k6268 in string->sre in k4869 */
static void C_fcall f_6308(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6308,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6315,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* flag-set? */
f_6125(t3,((C_word*)t0)[2],C_fix(2));}

/* k6313 in cased-string in lp in k6268 in string->sre in k4869 */
static void C_ccall f_6315(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6315,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6322,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6326,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* string->list */
t4=*((C_word*)lf[73]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* k6324 in k6313 in cased-string in lp in k6268 in string->sre in k4869 */
static void C_ccall f_6326(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k6320 in k6313 in cased-string in lp in k6268 in string->sre in k4869 */
static void C_ccall f_6322(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6322,2,t0,t1);}
/* sre-sequence */
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,f_13391(C_a_i(&a,3),t1));}

/* cased-char in lp in k6268 in string->sre in k4869 */
static void C_ccall f_6278(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6278,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6303,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* flag-set? */
f_6125(t3,((C_word*)t0)[2],C_fix(2));}

/* k6301 in cased-char in lp in k6268 in string->sre in k4869 */
static void C_ccall f_6303(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6303,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_u_i_char_alphabeticp(((C_word*)t0)[3]):C_SCHEME_FALSE);
if(C_truep(t2)){
t3=f_9172(((C_word*)t0)[3]);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t4);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[70],t5));}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}}

/* symbol-list->flags in k4869 */
static void C_fcall f_6163(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6163,NULL,2,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6169,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_6169(t6,t1,t2,C_fix(0));}

/* lp in symbol-list->flags in k4869 */
static void C_fcall f_6169(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6169,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6187,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_u_i_car(t2);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6194,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t8=(C_word)C_eqp(t6,lf[57]);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6200,a[2]=t6,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t8)){
t10=t9;
f_6200(t10,t8);}
else{
t10=(C_word)C_eqp(t6,lf[66]);
t11=t9;
f_6200(t11,(C_truep(t10)?t10:(C_word)C_eqp(t6,lf[67])));}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k6198 in lp in symbol-list->flags in k4869 */
static void C_fcall f_6200(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_6194(t2,C_fix(2));}
else{
t2=(C_word)C_eqp(((C_word*)t0)[2],lf[58]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(((C_word*)t0)[2],lf[59]));
if(C_truep(t3)){
t4=((C_word*)t0)[3];
f_6194(t4,C_fix(4));}
else{
t4=(C_word)C_eqp(((C_word*)t0)[2],lf[60]);
t5=(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[2],lf[61]));
if(C_truep(t5)){
t6=((C_word*)t0)[3];
f_6194(t6,C_fix(8));}
else{
t6=(C_word)C_eqp(((C_word*)t0)[2],lf[62]);
t7=(C_truep(t6)?t6:(C_word)C_eqp(((C_word*)t0)[2],lf[63]));
if(C_truep(t7)){
t8=((C_word*)t0)[3];
f_6194(t8,C_fix(16));}
else{
t8=(C_word)C_eqp(((C_word*)t0)[2],lf[64]);
t9=(C_truep(t8)?t8:(C_word)C_eqp(((C_word*)t0)[2],lf[65]));
t10=((C_word*)t0)[3];
f_6194(t10,(C_truep(t9)?C_fix(32):C_SCHEME_FALSE));}}}}}

/* k6192 in lp in symbol-list->flags in k4869 */
static void C_fcall f_6194(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* flag-join */
t2=lf[54];
f_6135(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k6185 in lp in symbol-list->flags in k4869 */
static void C_ccall f_6187(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp512 */
t2=((C_word*)((C_word*)t0)[4])[1];
f_6169(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* flag-clear in k4869 */
static void C_ccall f_6144(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6144,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_minus(&a,2,C_fix(65535),t3);
/* bit-and */
f_6078(t1,t2,t4);}

/* flag-join in k4869 */
static void C_ccall f_6135(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6135,4,t0,t1,t2,t3);}
if(C_truep(t3)){
/* bit-ior */
f_6031(t1,t2,t3);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}}

/* flag-set? in k4869 */
static void C_fcall f_6125(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6125,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6133,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* bit-and */
f_6078(t4,t2,t3);}

/* k6131 in flag-set? in k4869 */
static void C_ccall f_6133(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_nequalp(((C_word*)t0)[2],t1));}

/* bit-and in k4869 */
static void C_fcall f_6078(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6078,NULL,3,t1,t2,t3);}
if(C_truep((C_word)C_i_zerop(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_fix(0));}
else{
if(C_truep((C_word)C_i_zerop(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_fix(0));}
else{
t4=(C_word)C_i_oddp(t2);
t5=(C_truep(t4)?(C_word)C_i_oddp(t3):C_SCHEME_FALSE);
t6=(C_truep(t5)?C_fix(1):C_fix(0));
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6106,a[2]=t6,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6110,a[2]=t3,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
C_quotient(4,0,t8,t2,C_fix(2));}}}

/* k6108 in bit-and in k4869 */
static void C_ccall f_6110(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6110,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6114,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_quotient(4,0,t2,((C_word*)t0)[2],C_fix(2));}

/* k6112 in k6108 in bit-and in k4869 */
static void C_ccall f_6114(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* bit-and */
f_6078(((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k6104 in bit-and in k4869 */
static void C_ccall f_6106(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6106,2,t0,t1);}
t2=(C_word)C_a_i_times(&a,2,C_fix(2),t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_plus(&a,2,((C_word*)t0)[2],t2));}

/* bit-ior in k4869 */
static void C_fcall f_6031(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6031,NULL,3,t1,t2,t3);}
if(C_truep((C_word)C_i_zerop(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
if(C_truep((C_word)C_i_zerop(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}
else{
t4=(C_word)C_i_oddp(t2);
t5=(C_truep(t4)?t4:(C_word)C_i_oddp(t3));
t6=(C_truep(t5)?C_fix(1):C_fix(0));
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6059,a[2]=t6,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6063,a[2]=t3,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
C_quotient(4,0,t8,t2,C_fix(2));}}}

/* k6061 in bit-ior in k4869 */
static void C_ccall f_6063(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6063,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6067,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_quotient(4,0,t2,((C_word*)t0)[2],C_fix(2));}

/* k6065 in k6061 in bit-ior in k4869 */
static void C_ccall f_6067(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* bit-ior */
f_6031(((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k6057 in bit-ior in k4869 */
static void C_ccall f_6059(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6059,2,t0,t1);}
t2=(C_word)C_a_i_times(&a,2,C_fix(2),t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_plus(&a,2,((C_word*)t0)[2],t2));}

/* bit-shl in k4869 */
static void C_fcall f_6015(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6015,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6023,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* expt */
t5=*((C_word*)lf[49]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_fix(2),t3);}

/* k6021 in bit-shl in k4869 */
static void C_ccall f_6023(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6023,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_times(&a,2,((C_word*)t0)[2],t1));}

/* bit-shr in k4869 */
static void C_fcall f_6005(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6005,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6013,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* expt */
t5=*((C_word*)lf[49]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_fix(2),t3);}

/* k6011 in bit-shr in k4869 */
static void C_ccall f_6013(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_quotient(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* filter in k4869 */
static void C_fcall f_5919(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5919,NULL,3,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5925,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_5925(t7,t1,t3,C_SCHEME_END_OF_LIST);}

/* lp in filter in k4869 */
static void C_fcall f_5925(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5925,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
/* reverse */
t4=*((C_word*)lf[40]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}
else{
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5946,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5949,a[2]=t3,a[3]=t5,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_u_i_car(t2);
/* pred435 */
t8=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t6,t7);}}

/* k5947 in lp in filter in k4869 */
static void C_ccall f_5949(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5949,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_u_i_car(((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
f_5946(t3,(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[2]));}
else{
t2=((C_word*)t0)[3];
f_5946(t2,((C_word*)t0)[2]);}}

/* k5944 in lp in filter in k4869 */
static void C_fcall f_5946(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp438 */
t2=((C_word*)((C_word*)t0)[4])[1];
f_5925(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* fold in k4869 */
static void C_fcall f_5889(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5889,NULL,4,t1,t2,t3,t4);}
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5895,a[2]=t2,a[3]=t6,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_5895(t8,t1,t4,t3);}

/* lp in fold in k4869 */
static void C_fcall f_5895(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5895,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5913,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_u_i_car(t2);
/* kons423 */
t7=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,t3);}}

/* k5911 in lp in fold in k4869 */
static void C_ccall f_5913(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp427 */
t2=((C_word*)((C_word*)t0)[4])[1];
f_5895(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* every in k4869 */
static void C_fcall f_5840(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5840,NULL,3,t1,t2,t3);}
t4=(C_word)C_i_nullp(t3);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(C_word)C_u_i_car(t3);
t6=(C_word)C_slot(t3,C_fix(1));
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5860,a[2]=t8,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t10=((C_word*)t8)[1];
f_5860(t10,t1,t5,t6);}}

/* lp in every in k4869 */
static void C_fcall f_5860(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5860,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
/* pred404 */
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t2);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5876,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* pred404 */
t5=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}}

/* k5874 in lp in every in k4869 */
static void C_ccall f_5876(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_u_i_car(((C_word*)t0)[4]);
t3=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* lp413 */
t4=((C_word*)((C_word*)t0)[3])[1];
f_5860(t4,((C_word*)t0)[2],t2,t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* any in k4869 */
static void C_fcall f_5791(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5791,NULL,3,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t3))){
t4=(C_word)C_u_i_car(t3);
t5=(C_word)C_slot(t3,C_fix(1));
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5811,a[2]=t7,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_5811(t9,t1,t4,t5);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* lp in any in k4869 */
static void C_fcall f_5811(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5811,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
/* pred385 */
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t2);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5824,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* pred385 */
t5=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}}

/* k5822 in lp in any in k4869 */
static void C_ccall f_5824(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_u_i_car(((C_word*)t0)[3]);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* lp390 */
t4=((C_word*)((C_word*)t0)[2])[1];
f_5811(t4,((C_word*)t0)[4],t2,t3);}}

/* last in k4869 */
static void C_fcall f_5749(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5749,NULL,2,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5764,tmp=(C_word)a,a+=2,tmp);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,f_5764(t2));}
else{
/* error */
t3=*((C_word*)lf[24]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,lf[44],t2);}}

/* lp in last in k4869 */
static C_word C_fcall f_5764(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
loop:
t2=(C_word)C_slot(t1,C_fix(1));
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t1,C_fix(1));
t5=t3;
t1=t5;
goto loop;}
else{
return((C_word)C_u_i_car(t1));}}

/* find-tail in k4869 */
static void C_fcall f_5717(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5717,NULL,3,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5723,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_5723(t7,t1,t3);}

/* lp in find-tail in k4869 */
static void C_fcall f_5723(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5723,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5736,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_u_i_car(t2);
/* pred359 */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}}

/* k5734 in lp in find-tail in k4869 */
static void C_ccall f_5736(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* lp362 */
t3=((C_word*)((C_word*)t0)[2])[1];
f_5723(t3,((C_word*)t0)[4],t2);}}

/* find in k4869 */
static void C_fcall f_5705(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5705,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5709,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* find-tail */
f_5717(t4,t2,t3);}

/* k5707 in find in k4869 */
static void C_ccall f_5709(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?(C_word)C_u_i_car(t1):C_SCHEME_FALSE));}

/* take-up-to in k4869 */
static void C_fcall f_5662(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5662,NULL,3,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5668,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_5668(t7,t1,t2,C_SCHEME_END_OF_LIST);}

/* lp in take-up-to in k4869 */
static void C_fcall f_5668(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5668,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5675,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t5=(C_word)C_eqp(t2,((C_word*)t0)[2]);
t6=t4;
f_5675(t6,(C_word)C_i_not(t5));}
else{
t5=t4;
f_5675(t5,C_SCHEME_FALSE);}}

/* k5673 in lp in take-up-to in k4869 */
static void C_fcall f_5675(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5675,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_u_i_car(((C_word*)t0)[5]);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[4]);
/* lp335 */
t5=((C_word*)((C_word*)t0)[3])[1];
f_5668(t5,((C_word*)t0)[2],t2,t4);}
else{
/* reverse */
t2=*((C_word*)lf[40]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],((C_word*)t0)[4]);}}

/* zero-to in k4869 */
static void C_fcall f_5623(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5623,NULL,2,t1,t2);}
if(C_truep((C_word)C_i_less_or_equalp(t2,C_fix(0)))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_a_i_minus(&a,2,t2,C_fix(1));
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5639,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_5639(t7,t1,t3,C_SCHEME_END_OF_LIST);}}

/* lp in zero-to in k4869 */
static void C_fcall f_5639(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
loop:
a=C_alloc(7);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5639,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_zerop(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,C_fix(0),t3));}
else{
t4=(C_word)C_a_i_minus(&a,2,t2,C_fix(1));
t5=(C_word)C_a_i_cons(&a,2,t2,t3);
/* lp324 */
t7=t1;
t8=t4;
t9=t5;
t1=t7;
t2=t8;
t3=t9;
goto loop;}}

/* string-cat-reverse in k4869 */
static void C_fcall f_5566(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5566,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5574,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5576,tmp=(C_word)a,a+=2,tmp);
/* fold */
f_5889(t3,t4,C_fix(0),t2);}

/* a5575 in string-cat-reverse in k4869 */
static void C_ccall f_5576(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5576,4,t0,t1,t2,t3);}
t4=(C_word)C_fix((C_word)C_header_size(t2));
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_plus(&a,2,t4,t3));}

/* k5572 in string-cat-reverse in k4869 */
static void C_ccall f_5574(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5574,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[2];
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5590,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* make-string */
t5=*((C_word*)lf[36]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t1);}

/* k5588 in k5572 in string-cat-reverse in k4869 */
static void C_ccall f_5590(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5590,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5593,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5595,a[2]=t1,a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_5595(t6,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* lp in k5588 in k5572 in string-cat-reverse in k4869 */
static void C_fcall f_5595(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5595,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t3))){
t4=(C_word)C_u_i_car(t3);
t5=(C_word)C_fix((C_word)C_header_size(t4));
t6=(C_word)C_a_i_minus(&a,2,t2,t5);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5614,a[2]=t6,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t8=((C_word*)t0)[2];
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5539,a[2]=t10,a[3]=t8,a[4]=t4,a[5]=t5,tmp=(C_word)a,a+=6,tmp));
t12=((C_word*)t10)[1];
f_5539(t12,t7,C_fix(0),t6);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* doloop278 in lp in k5588 in k5572 in string-cat-reverse in k4869 */
static void C_fcall f_5539(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
a=C_alloc(8);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5539,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_greater_or_equalp(t2,((C_word*)t0)[5]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(C_word)C_subchar(((C_word*)t0)[4],t2);
t5=(C_word)C_setsubchar(((C_word*)t0)[3],t3,t4);
t6=(C_word)C_a_i_plus(&a,2,t2,C_fix(1));
t7=(C_word)C_a_i_plus(&a,2,t3,C_fix(1));
t9=t1;
t10=t6;
t11=t7;
t1=t9;
t2=t10;
t3=t11;
goto loop;}}

/* k5612 in lp in k5588 in k5572 in string-cat-reverse in k4869 */
static void C_ccall f_5614(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* lp304 */
t3=((C_word*)((C_word*)t0)[4])[1];
f_5595(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k5591 in k5588 in k5572 in string-cat-reverse in k4869 */
static void C_ccall f_5593(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* char-alphanumeric? in k4869 */
static C_word C_fcall f_5521(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
t2=(C_word)C_u_i_char_alphabeticp(t1);
return((C_truep(t2)?t2:(C_word)C_u_i_char_numericp(t1)));}

/* string-scan-char in k4869 */
static void C_fcall f_5306(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5306,NULL,4,t1,t2,t3,t4);}
t5=(C_word)C_fix((C_word)C_header_size(t2));
t6=(C_word)C_i_pairp(t4);
t7=(C_truep(t6)?(C_word)C_u_i_car(t4):C_fix(0));
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5319,a[2]=t9,a[3]=t3,a[4]=t2,a[5]=t5,tmp=(C_word)a,a+=6,tmp));
t11=((C_word*)t9)[1];
f_5319(t11,t1,t7);}

/* scan in string-scan-char in k4869 */
static void C_fcall f_5319(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5319,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nequalp(t2,((C_word*)t0)[5]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=(C_word)C_subchar(((C_word*)t0)[4],t2);
if(C_truep((C_word)C_i_eqvp(((C_word*)t0)[3],t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}
else{
t4=(C_word)C_a_i_plus(&a,2,t2,C_fix(1));
/* scan186 */
t6=t1;
t7=t4;
t1=t6;
t2=t7;
goto loop;}}}

/* irregex-match-end in k4869 */
static void C_ccall f_5291(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_5291r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5291r(t0,t1,t2,t3);}}

static void C_ccall f_5291r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5299,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* irregex-match-index */
f_5147(t4,t2,t3);}

/* k5297 in irregex-match-end in k4869 */
static void C_ccall f_5299(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5299,2,t0,t1);}
/* irregex-match-valid-index? */
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,f_5193(C_a_i(&a,16),((C_word*)t0)[2],t1));}

/* irregex-match-start in k4869 */
static void C_ccall f_5268(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_5268r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5268r(t0,t1,t2,t3);}}

static void C_ccall f_5268r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5272,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* irregex-match-index */
f_5147(t4,t2,t3);}

/* k5270 in irregex-match-start in k4869 */
static void C_ccall f_5272(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5272,2,t0,t1);}
t2=f_5193(C_a_i(&a,16),((C_word*)t0)[3],t1);
if(C_truep(t2)){
t3=(C_word)C_a_i_times(&a,2,t1,C_fix(2));
t4=(C_word)C_a_i_plus(&a,2,C_fix(3),t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_slot(((C_word*)t0)[3],t4));}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* irregex-match-substring in k4869 */
static void C_ccall f_5225(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_5225r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5225r(t0,t1,t2,t3);}}

static void C_ccall f_5225r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5229,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* irregex-match-index */
f_5147(t4,t2,t3);}

/* k5227 in irregex-match-substring in k4869 */
static void C_ccall f_5229(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5229,2,t0,t1);}
t2=f_5193(C_a_i(&a,16),((C_word*)t0)[3],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5242,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* irregex-match-string */
t4=*((C_word*)lf[17]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[3]);}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k5240 in k5227 in irregex-match-substring in k4869 */
static void C_ccall f_5242(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5242,2,t0,t1);}
t2=(C_word)C_a_i_times(&a,2,((C_word*)t0)[4],C_fix(2));
t3=(C_word)C_a_i_plus(&a,2,C_fix(3),t2);
t4=(C_word)C_slot(((C_word*)t0)[3],t3);
t5=(C_word)C_a_i_times(&a,2,((C_word*)t0)[4],C_fix(2));
t6=(C_word)C_a_i_plus(&a,2,C_fix(4),t5);
t7=(C_word)C_slot(((C_word*)t0)[3],t6);
/* substring */
t8=*((C_word*)lf[28]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,((C_word*)t0)[2],t1,t4,t7);}

/* irregex-match-valid-index? in k4869 */
static C_word C_fcall f_5193(C_word *a,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
t3=(C_word)C_a_i_times(&a,2,t2,C_fix(2));
t4=(C_word)C_a_i_plus(&a,2,C_fix(3),t3);
t5=(C_word)C_fix((C_word)C_header_size(t1));
if(C_truep((C_word)C_i_lessp(t4,t5))){
t6=(C_word)C_a_i_times(&a,2,t2,C_fix(2));
t7=(C_word)C_a_i_plus(&a,2,C_fix(4),t6);
return((C_word)C_slot(t1,t7));}
else{
return(C_SCHEME_FALSE);}}

/* irregex-match-index in k4869 */
static void C_fcall f_5147(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5147,NULL,3,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t3))){
t4=(C_word)C_u_i_car(t3);
if(C_truep((C_word)C_i_numberp(t4))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_u_i_car(t3));}
else{
t5=(C_word)C_u_i_car(t3);
t6=(C_word)C_slot(t2,C_fix(2));
t7=(C_word)C_u_i_assq(t5,t6);
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_slot(t7,C_fix(1)));}
else{
t8=(C_word)C_u_i_car(t3);
/* error */
t9=*((C_word*)lf[24]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t1,lf[25],t8);}}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_fix(0));}}

/* irregex-match-end-index-set! in k4869 */
static C_word C_fcall f_5133(C_word *a,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
t4=(C_word)C_a_i_times(&a,2,t2,C_fix(2));
t5=(C_word)C_a_i_plus(&a,2,C_fix(4),t4);
return((C_word)C_i_setslot(t1,t5,t3));}

/* irregex-match-start-index-set! in k4869 */
static C_word C_fcall f_5119(C_word *a,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
t4=(C_word)C_a_i_times(&a,2,t2,C_fix(2));
t5=(C_word)C_a_i_plus(&a,2,C_fix(3),t4);
return((C_word)C_i_setslot(t1,t5,t3));}

/* irregex-match-end-index in k4869 */
static C_word C_fcall f_5105(C_word *a,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
t3=(C_word)C_a_i_times(&a,2,t2,C_fix(2));
t4=(C_word)C_a_i_plus(&a,2,C_fix(4),t3);
return((C_word)C_slot(t1,t4));}

/* irregex-match-start-index in k4869 */
static C_word C_fcall f_5091(C_word *a,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
t3=(C_word)C_a_i_times(&a,2,t2,C_fix(2));
t4=(C_word)C_a_i_plus(&a,2,C_fix(3),t3);
return((C_word)C_slot(t1,t4));}

/* irregex-match-string-set! in k4869 */
static C_word C_fcall f_5085(C_word t1,C_word t2){
C_word tmp;
C_word t3;
return((C_word)C_i_setslot(t1,C_fix(1),t2));}

/* irregex-match-string in k4869 */
static void C_ccall f_5073(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5073,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* irregex-match-num-submatches in k4869 */
static void C_ccall f_5055(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5055,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5063,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_fix((C_word)C_header_size(t2));
t5=(C_word)C_a_i_minus(&a,2,t4,C_fix(3));
C_quotient(4,0,t3,t5,C_fix(2));}

/* k5061 in irregex-match-num-submatches in k4869 */
static void C_ccall f_5063(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5063,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_minus(&a,2,t1,C_fix(1)));}

/* irregex-match-data? in k4869 */
static void C_ccall f_5002(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5002,3,t0,t1,t2);}
if(C_truep((C_word)C_i_vectorp(t2))){
t3=(C_word)C_fix((C_word)C_header_size(t2));
if(C_truep((C_word)C_i_greater_or_equalp(C_fix(5),t3))){
t4=(C_word)C_slot(t2,C_fix(0));
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_eqp(lf[12],t4));}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* irregex-reset-matches! in k4869 */
static void C_ccall f_4968(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4968,3,t0,t1,t2);}
t3=(C_word)C_fix((C_word)C_header_size(t2));
t4=(C_word)C_a_i_minus(&a,2,t3,C_fix(1));
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4978,a[2]=t6,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_4978(t8,t1,t4);}

/* doloop74 in irregex-reset-matches! in k4869 */
static void C_fcall f_4978(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4978,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_less_or_equalp(t2,C_fix(3)))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}
else{
t3=(C_word)C_i_set_i_slot(((C_word*)t0)[3],t2,C_SCHEME_FALSE);
t4=(C_word)C_a_i_minus(&a,2,t2,C_fix(1));
t6=t1;
t7=t4;
t1=t6;
t2=t7;
goto loop;}}

/* irregex-new-matches in k4869 */
static void C_ccall f_4954(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4954,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4962,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* irregex-submatches */
t4=*((C_word*)lf[8]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k4960 in irregex-new-matches in k4869 */
static void C_ccall f_4962(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4962,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4966,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* irregex-names */
t3=*((C_word*)lf[10]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k4964 in k4960 in irregex-new-matches in k4869 */
static void C_ccall f_4966(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4966,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[2];
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5032,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_a_i_plus(&a,2,C_fix(1),t3);
t6=(C_word)C_a_i_times(&a,2,C_fix(2),t5);
t7=(C_word)C_a_i_plus(&a,2,t6,C_fix(3));
/* make-vector */
t8=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t4,t7,C_SCHEME_FALSE);}

/* k5030 in k4964 in k4960 in irregex-new-matches in k4869 */
static void C_ccall f_5032(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_i_setslot(t1,C_fix(0),lf[12]);
t3=(C_word)C_i_set_i_slot(t1,C_fix(1),C_SCHEME_FALSE);
t4=(C_word)C_i_setslot(t1,C_fix(2),((C_word*)t0)[3]);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t1);}

/* irregex-names in k4869 */
static void C_ccall f_4948(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4948,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(8)));}

/* irregex-lengths in k4869 */
static void C_ccall f_4942(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4942,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(7)));}

/* irregex-submatches in k4869 */
static void C_ccall f_4936(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4936,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(6)));}

/* irregex-flags in k4869 */
static void C_ccall f_4930(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4930,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(5)));}

/* irregex-nfa in k4869 */
static void C_ccall f_4924(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4924,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(4)));}

/* irregex-dfa/extract in k4869 */
static void C_ccall f_4918(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4918,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* irregex-dfa/search in k4869 */
static void C_ccall f_4912(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4912,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* irregex-dfa in k4869 */
static void C_ccall f_4906(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4906,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* irregex? in k4869 */
static void C_ccall f_4880(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4880,3,t0,t1,t2);}
if(C_truep((C_word)C_i_vectorp(t2))){
t3=(C_word)C_fix((C_word)C_header_size(t2));
if(C_truep((C_word)C_i_nequalp(C_fix(9),t3))){
t4=(C_word)C_slot(t2,C_fix(0));
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_eqp(lf[1],t4));}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* make-irregex in k4869 */
static C_word C_fcall f_4874(C_word *a,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
return((C_word)C_a_i_vector(&a,9,lf[1],t1,t2,t3,t4,t5,t6,t7,t8));}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[1076] = {
{"toplevel:regex_scm",(void*)C_regex_toplevel},
{"f_4871:regex_scm",(void*)f_4871},
{"f_21492:regex_scm",(void*)f_21492},
{"f_21499:regex_scm",(void*)f_21499},
{"f_21507:regex_scm",(void*)f_21507},
{"f_21539:regex_scm",(void*)f_21539},
{"f_21526:regex_scm",(void*)f_21526},
{"f_21529:regex_scm",(void*)f_21529},
{"f_21452:regex_scm",(void*)f_21452},
{"f_21461:regex_scm",(void*)f_21461},
{"f_21480:regex_scm",(void*)f_21480},
{"f_21487:regex_scm",(void*)f_21487},
{"f_21175:regex_scm",(void*)f_21175},
{"f_21190:regex_scm",(void*)f_21190},
{"f_21192:regex_scm",(void*)f_21192},
{"f_21447:regex_scm",(void*)f_21447},
{"f_21443:regex_scm",(void*)f_21443},
{"f_21432:regex_scm",(void*)f_21432},
{"f_21254:regex_scm",(void*)f_21254},
{"f_21284:regex_scm",(void*)f_21284},
{"f_21313:regex_scm",(void*)f_21313},
{"f_21361:regex_scm",(void*)f_21361},
{"f_21340:regex_scm",(void*)f_21340},
{"f_21336:regex_scm",(void*)f_21336},
{"f_21303:regex_scm",(void*)f_21303},
{"f_21299:regex_scm",(void*)f_21299},
{"f_21274:regex_scm",(void*)f_21274},
{"f_21252:regex_scm",(void*)f_21252},
{"f_21239:regex_scm",(void*)f_21239},
{"f_21226:regex_scm",(void*)f_21226},
{"f_21222:regex_scm",(void*)f_21222},
{"f_21186:regex_scm",(void*)f_21186},
{"f_21090:regex_scm",(void*)f_21090},
{"f_21103:regex_scm",(void*)f_21103},
{"f_21122:regex_scm",(void*)f_21122},
{"f_21038:regex_scm",(void*)f_21038},
{"f_21053:regex_scm",(void*)f_21053},
{"f_21070:regex_scm",(void*)f_21070},
{"f_20786:regex_scm",(void*)f_20786},
{"f_20925:regex_scm",(void*)f_20925},
{"f_20929:regex_scm",(void*)f_20929},
{"f_21020:regex_scm",(void*)f_21020},
{"f_21016:regex_scm",(void*)f_21016},
{"f_20987:regex_scm",(void*)f_20987},
{"f_20969:regex_scm",(void*)f_20969},
{"f_20962:regex_scm",(void*)f_20962},
{"f_20819:regex_scm",(void*)f_20819},
{"f_20825:regex_scm",(void*)f_20825},
{"f_20892:regex_scm",(void*)f_20892},
{"f_20880:regex_scm",(void*)f_20880},
{"f_20839:regex_scm",(void*)f_20839},
{"f_20804:regex_scm",(void*)f_20804},
{"f_20604:regex_scm",(void*)f_20604},
{"f_20768:regex_scm",(void*)f_20768},
{"f_20742:regex_scm",(void*)f_20742},
{"f_20767:regex_scm",(void*)f_20767},
{"f_20722:regex_scm",(void*)f_20722},
{"f_20623:regex_scm",(void*)f_20623},
{"f_20631:regex_scm",(void*)f_20631},
{"f_20635:regex_scm",(void*)f_20635},
{"f_20696:regex_scm",(void*)f_20696},
{"f_20677:regex_scm",(void*)f_20677},
{"f_20711:regex_scm",(void*)f_20711},
{"f_20706:regex_scm",(void*)f_20706},
{"f_20484:regex_scm",(void*)f_20484},
{"f_20559:regex_scm",(void*)f_20559},
{"f_20550:regex_scm",(void*)f_20550},
{"f_20486:regex_scm",(void*)f_20486},
{"f_20490:regex_scm",(void*)f_20490},
{"f_20545:regex_scm",(void*)f_20545},
{"f_20499:regex_scm",(void*)f_20499},
{"f_20509:regex_scm",(void*)f_20509},
{"f_20511:regex_scm",(void*)f_20511},
{"f_20372:regex_scm",(void*)f_20372},
{"f_20439:regex_scm",(void*)f_20439},
{"f_20430:regex_scm",(void*)f_20430},
{"f_20374:regex_scm",(void*)f_20374},
{"f_20378:regex_scm",(void*)f_20378},
{"f_20425:regex_scm",(void*)f_20425},
{"f_20387:regex_scm",(void*)f_20387},
{"f_20397:regex_scm",(void*)f_20397},
{"f_20399:regex_scm",(void*)f_20399},
{"f_20421:regex_scm",(void*)f_20421},
{"f_20310:regex_scm",(void*)f_20310},
{"f_20314:regex_scm",(void*)f_20314},
{"f_20317:regex_scm",(void*)f_20317},
{"f_20327:regex_scm",(void*)f_20327},
{"f_20329:regex_scm",(void*)f_20329},
{"f_20264:regex_scm",(void*)f_20264},
{"f_20268:regex_scm",(void*)f_20268},
{"f_20271:regex_scm",(void*)f_20271},
{"f_20281:regex_scm",(void*)f_20281},
{"f_20283:regex_scm",(void*)f_20283},
{"f_20308:regex_scm",(void*)f_20308},
{"f_20243:regex_scm",(void*)f_20243},
{"f_20250:regex_scm",(void*)f_20250},
{"f_20259:regex_scm",(void*)f_20259},
{"f_20140:regex_scm",(void*)f_20140},
{"f_20183:regex_scm",(void*)f_20183},
{"f_20178:regex_scm",(void*)f_20178},
{"f_20173:regex_scm",(void*)f_20173},
{"f_20142:regex_scm",(void*)f_20142},
{"f_20154:regex_scm",(void*)f_20154},
{"f_20157:regex_scm",(void*)f_20157},
{"f_20160:regex_scm",(void*)f_20160},
{"f_20150:regex_scm",(void*)f_20150},
{"f_20122:regex_scm",(void*)f_20122},
{"f_19940:regex_scm",(void*)f_19940},
{"f_19946:regex_scm",(void*)f_19946},
{"f_20068:regex_scm",(void*)f_20068},
{"f_20072:regex_scm",(void*)f_20072},
{"f_20080:regex_scm",(void*)f_20080},
{"f_20064:regex_scm",(void*)f_20064},
{"f_20039:regex_scm",(void*)f_20039},
{"f_20043:regex_scm",(void*)f_20043},
{"f_20035:regex_scm",(void*)f_20035},
{"f_20002:regex_scm",(void*)f_20002},
{"f_19974:regex_scm",(void*)f_19974},
{"f_19884:regex_scm",(void*)f_19884},
{"f_19723:regex_scm",(void*)f_19723},
{"f_19726:regex_scm",(void*)f_19726},
{"f_19809:regex_scm",(void*)f_19809},
{"f_19780:regex_scm",(void*)f_19780},
{"f_19743:regex_scm",(void*)f_19743},
{"f_19756:regex_scm",(void*)f_19756},
{"f_19768:regex_scm",(void*)f_19768},
{"f_19771:regex_scm",(void*)f_19771},
{"f_19774:regex_scm",(void*)f_19774},
{"f_19829:regex_scm",(void*)f_19829},
{"f_19917:regex_scm",(void*)f_19917},
{"f_19938:regex_scm",(void*)f_19938},
{"f_19928:regex_scm",(void*)f_19928},
{"f_19890:regex_scm",(void*)f_19890},
{"f_19894:regex_scm",(void*)f_19894},
{"f_19901:regex_scm",(void*)f_19901},
{"f_19915:regex_scm",(void*)f_19915},
{"f_19905:regex_scm",(void*)f_19905},
{"f_19832:regex_scm",(void*)f_19832},
{"f_19882:regex_scm",(void*)f_19882},
{"f_19836:regex_scm",(void*)f_19836},
{"f_19874:regex_scm",(void*)f_19874},
{"f_19850:regex_scm",(void*)f_19850},
{"f_19858:regex_scm",(void*)f_19858},
{"f_19870:regex_scm",(void*)f_19870},
{"f_19866:regex_scm",(void*)f_19866},
{"f_19854:regex_scm",(void*)f_19854},
{"f_19554:regex_scm",(void*)f_19554},
{"f_19560:regex_scm",(void*)f_19560},
{"f_19576:regex_scm",(void*)f_19576},
{"f_19613:regex_scm",(void*)f_19613},
{"f_19671:regex_scm",(void*)f_19671},
{"f_19628:regex_scm",(void*)f_19628},
{"f_19624:regex_scm",(void*)f_19624},
{"f_19596:regex_scm",(void*)f_19596},
{"f_19544:regex_scm",(void*)f_19544},
{"f_19552:regex_scm",(void*)f_19552},
{"f_19426:regex_scm",(void*)f_19426},
{"f_19432:regex_scm",(void*)f_19432},
{"f_19534:regex_scm",(void*)f_19534},
{"f_19442:regex_scm",(void*)f_19442},
{"f_19509:regex_scm",(void*)f_19509},
{"f_19450:regex_scm",(void*)f_19450},
{"f_19501:regex_scm",(void*)f_19501},
{"f_19454:regex_scm",(void*)f_19454},
{"f_19463:regex_scm",(void*)f_19463},
{"f_19466:regex_scm",(void*)f_19466},
{"f_19473:regex_scm",(void*)f_19473},
{"f_19305:regex_scm",(void*)f_19305},
{"f_19412:regex_scm",(void*)f_19412},
{"f_19328:regex_scm",(void*)f_19328},
{"f_19387:regex_scm",(void*)f_19387},
{"f_19336:regex_scm",(void*)f_19336},
{"f_19379:regex_scm",(void*)f_19379},
{"f_19340:regex_scm",(void*)f_19340},
{"f_19349:regex_scm",(void*)f_19349},
{"f_19352:regex_scm",(void*)f_19352},
{"f_19218:regex_scm",(void*)f_19218},
{"f_19295:regex_scm",(void*)f_19295},
{"f_19228:regex_scm",(void*)f_19228},
{"f_19274:regex_scm",(void*)f_19274},
{"f_19246:regex_scm",(void*)f_19246},
{"f_19238:regex_scm",(void*)f_19238},
{"f_19073:regex_scm",(void*)f_19073},
{"f_19089:regex_scm",(void*)f_19089},
{"f_19061:regex_scm",(void*)f_19061},
{"f_19023:regex_scm",(void*)f_19023},
{"f_19029:regex_scm",(void*)f_19029},
{"f_18742:regex_scm",(void*)f_18742},
{"f_18752:regex_scm",(void*)f_18752},
{"f_18916:regex_scm",(void*)f_18916},
{"f_18920:regex_scm",(void*)f_18920},
{"f_13500:regex_scm",(void*)f_13500},
{"f_13527:regex_scm",(void*)f_13527},
{"f_13523:regex_scm",(void*)f_13523},
{"f_18899:regex_scm",(void*)f_18899},
{"f_18666:regex_scm",(void*)f_18666},
{"f_18889:regex_scm",(void*)f_18889},
{"f_18868:regex_scm",(void*)f_18868},
{"f_18872:regex_scm",(void*)f_18872},
{"f_18860:regex_scm",(void*)f_18860},
{"f_18837:regex_scm",(void*)f_18837},
{"f_18841:regex_scm",(void*)f_18841},
{"f_18812:regex_scm",(void*)f_18812},
{"f_18816:regex_scm",(void*)f_18816},
{"f_18808:regex_scm",(void*)f_18808},
{"f_18781:regex_scm",(void*)f_18781},
{"f_18755:regex_scm",(void*)f_18755},
{"f_18625:regex_scm",(void*)f_18625},
{"f_18627:regex_scm",(void*)f_18627},
{"f_18634:regex_scm",(void*)f_18634},
{"f_16261:regex_scm",(void*)f_16261},
{"f_16301:regex_scm",(void*)f_16301},
{"f_16180:regex_scm",(void*)f_16180},
{"f_16186:regex_scm",(void*)f_16186},
{"f_16235:regex_scm",(void*)f_16235},
{"f_16233:regex_scm",(void*)f_16233},
{"f_16225:regex_scm",(void*)f_16225},
{"f_16213:regex_scm",(void*)f_16213},
{"f_16217:regex_scm",(void*)f_16217},
{"f_16064:regex_scm",(void*)f_16064},
{"f_16097:regex_scm",(void*)f_16097},
{"f_16101:regex_scm",(void*)f_16101},
{"f_16109:regex_scm",(void*)f_16109},
{"f_16078:regex_scm",(void*)f_16078},
{"f_15990:regex_scm",(void*)f_15990},
{"f_15998:regex_scm",(void*)f_15998},
{"f_16002:regex_scm",(void*)f_16002},
{"f_15978:regex_scm",(void*)f_15978},
{"f_15516:regex_scm",(void*)f_15516},
{"f_15725:regex_scm",(void*)f_15725},
{"f_15753:regex_scm",(void*)f_15753},
{"f_15910:regex_scm",(void*)f_15910},
{"f_15811:regex_scm",(void*)f_15811},
{"f_15881:regex_scm",(void*)f_15881},
{"f_15816:regex_scm",(void*)f_15816},
{"f_15869:regex_scm",(void*)f_15869},
{"f_15829:regex_scm",(void*)f_15829},
{"f_15832:regex_scm",(void*)f_15832},
{"f_15839:regex_scm",(void*)f_15839},
{"f_15797:regex_scm",(void*)f_15797},
{"f_15758:regex_scm",(void*)f_15758},
{"f_15785:regex_scm",(void*)f_15785},
{"f_15769:regex_scm",(void*)f_15769},
{"f_15547:regex_scm",(void*)f_15547},
{"f_15596:regex_scm",(void*)f_15596},
{"f_15663:regex_scm",(void*)f_15663},
{"f_15601:regex_scm",(void*)f_15601},
{"f_15651:regex_scm",(void*)f_15651},
{"f_15617:regex_scm",(void*)f_15617},
{"f_15621:regex_scm",(void*)f_15621},
{"f_15613:regex_scm",(void*)f_15613},
{"f_15582:regex_scm",(void*)f_15582},
{"f_15519:regex_scm",(void*)f_15519},
{"f_15219:regex_scm",(void*)f_15219},
{"f_15334:regex_scm",(void*)f_15334},
{"f_15232:regex_scm",(void*)f_15232},
{"f_15427:regex_scm",(void*)f_15427},
{"f_15506:regex_scm",(void*)f_15506},
{"f_15445:regex_scm",(void*)f_15445},
{"f_15457:regex_scm",(void*)f_15457},
{"f_15265:regex_scm",(void*)f_15265},
{"f_15277:regex_scm",(void*)f_15277},
{"f_15312:regex_scm",(void*)f_15312},
{"f_15284:regex_scm",(void*)f_15284},
{"f_15308:regex_scm",(void*)f_15308},
{"f_15300:regex_scm",(void*)f_15300},
{"f_15246:regex_scm",(void*)f_15246},
{"f_15411:regex_scm",(void*)f_15411},
{"f_15415:regex_scm",(void*)f_15415},
{"f_15354:regex_scm",(void*)f_15354},
{"f_15373:regex_scm",(void*)f_15373},
{"f_15387:regex_scm",(void*)f_15387},
{"f_15385:regex_scm",(void*)f_15385},
{"f_15371:regex_scm",(void*)f_15371},
{"f_15356:regex_scm",(void*)f_15356},
{"f_14429:regex_scm",(void*)f_14429},
{"f_14447:regex_scm",(void*)f_14447},
{"f_14710:regex_scm",(void*)f_14710},
{"f_14764:regex_scm",(void*)f_14764},
{"f_15024:regex_scm",(void*)f_15024},
{"f_15112:regex_scm",(void*)f_15112},
{"f_15030:regex_scm",(void*)f_15030},
{"f_15108:regex_scm",(void*)f_15108},
{"f_15033:regex_scm",(void*)f_15033},
{"f_15088:regex_scm",(void*)f_15088},
{"f_15039:regex_scm",(void*)f_15039},
{"f_15058:regex_scm",(void*)f_15058},
{"f_14964:regex_scm",(void*)f_14964},
{"f_15008:regex_scm",(void*)f_15008},
{"f_14970:regex_scm",(void*)f_14970},
{"f_14992:regex_scm",(void*)f_14992},
{"f_14861:regex_scm",(void*)f_14861},
{"f_14943:regex_scm",(void*)f_14943},
{"f_14864:regex_scm",(void*)f_14864},
{"f_14928:regex_scm",(void*)f_14928},
{"f_14867:regex_scm",(void*)f_14867},
{"f_14893:regex_scm",(void*)f_14893},
{"f_14885:regex_scm",(void*)f_14885},
{"f_14889:regex_scm",(void*)f_14889},
{"f_14881:regex_scm",(void*)f_14881},
{"f_14852:regex_scm",(void*)f_14852},
{"f_14767:regex_scm",(void*)f_14767},
{"f_14794:regex_scm",(void*)f_14794},
{"f_14822:regex_scm",(void*)f_14822},
{"f_14820:regex_scm",(void*)f_14820},
{"f_14808:regex_scm",(void*)f_14808},
{"f_14812:regex_scm",(void*)f_14812},
{"f_14783:regex_scm",(void*)f_14783},
{"f_14713:regex_scm",(void*)f_14713},
{"f_14716:regex_scm",(void*)f_14716},
{"f_14730:regex_scm",(void*)f_14730},
{"f_14693:regex_scm",(void*)f_14693},
{"f_14670:regex_scm",(void*)f_14670},
{"f_14593:regex_scm",(void*)f_14593},
{"f_14560:regex_scm",(void*)f_14560},
{"f_14582:regex_scm",(void*)f_14582},
{"f_14567:regex_scm",(void*)f_14567},
{"f_14537:regex_scm",(void*)f_14537},
{"f_14516:regex_scm",(void*)f_14516},
{"f_14512:regex_scm",(void*)f_14512},
{"f_14464:regex_scm",(void*)f_14464},
{"f_14479:regex_scm",(void*)f_14479},
{"f_14485:regex_scm",(void*)f_14485},
{"f_14483:regex_scm",(void*)f_14483},
{"f_14450:regex_scm",(void*)f_14450},
{"f_14322:regex_scm",(void*)f_14322},
{"f_14336:regex_scm",(void*)f_14336},
{"f_14374:regex_scm",(void*)f_14374},
{"f_14349:regex_scm",(void*)f_14349},
{"f_14227:regex_scm",(void*)f_14227},
{"f_14217:regex_scm",(void*)f_14217},
{"f_14211:regex_scm",(void*)f_14211},
{"f_14144:regex_scm",(void*)f_14144},
{"f_14148:regex_scm",(void*)f_14148},
{"f_14151:regex_scm",(void*)f_14151},
{"f_14163:regex_scm",(void*)f_14163},
{"f_14191:regex_scm",(void*)f_14191},
{"f_14208:regex_scm",(void*)f_14208},
{"f_14194:regex_scm",(void*)f_14194},
{"f_14188:regex_scm",(void*)f_14188},
{"f_14166:regex_scm",(void*)f_14166},
{"f_14184:regex_scm",(void*)f_14184},
{"f_14181:regex_scm",(void*)f_14181},
{"f_13985:regex_scm",(void*)f_13985},
{"f_13992:regex_scm",(void*)f_13992},
{"f_14108:regex_scm",(void*)f_14108},
{"f_14113:regex_scm",(void*)f_14113},
{"f_14141:regex_scm",(void*)f_14141},
{"f_14123:regex_scm",(void*)f_14123},
{"f_14105:regex_scm",(void*)f_14105},
{"f_13998:regex_scm",(void*)f_13998},
{"f_14101:regex_scm",(void*)f_14101},
{"f_14243:regex_scm",(void*)f_14243},
{"f_14278:regex_scm",(void*)f_14278},
{"f_14262:regex_scm",(void*)f_14262},
{"f_14023:regex_scm",(void*)f_14023},
{"f_14097:regex_scm",(void*)f_14097},
{"f_14032:regex_scm",(void*)f_14032},
{"f_14038:regex_scm",(void*)f_14038},
{"f_14043:regex_scm",(void*)f_14043},
{"f_14053:regex_scm",(void*)f_14053},
{"f_14068:regex_scm",(void*)f_14068},
{"f_14065:regex_scm",(void*)f_14065},
{"f_14020:regex_scm",(void*)f_14020},
{"f_14001:regex_scm",(void*)f_14001},
{"f_14016:regex_scm",(void*)f_14016},
{"f_14013:regex_scm",(void*)f_14013},
{"f_13939:regex_scm",(void*)f_13939},
{"f_13943:regex_scm",(void*)f_13943},
{"f_13961:regex_scm",(void*)f_13961},
{"f_13952:regex_scm",(void*)f_13952},
{"f_13822:regex_scm",(void*)f_13822},
{"f_13841:regex_scm",(void*)f_13841},
{"f_13912:regex_scm",(void*)f_13912},
{"f_13879:regex_scm",(void*)f_13879},
{"f_13786:regex_scm",(void*)f_13786},
{"f_13816:regex_scm",(void*)f_13816},
{"f_13808:regex_scm",(void*)f_13808},
{"f_13556:regex_scm",(void*)f_13556},
{"f_13654:regex_scm",(void*)f_13654},
{"f_13441:regex_scm",(void*)f_13441},
{"f_13416:regex_scm",(void*)f_13416},
{"f_13391:regex_scm",(void*)f_13391},
{"f_12296:regex_scm",(void*)f_12296},
{"f_12302:regex_scm",(void*)f_12302},
{"f_12327:regex_scm",(void*)f_12327},
{"f_12270:regex_scm",(void*)f_12270},
{"f_12184:regex_scm",(void*)f_12184},
{"f_12223:regex_scm",(void*)f_12223},
{"f_12236:regex_scm",(void*)f_12236},
{"f_12098:regex_scm",(void*)f_12098},
{"f_12137:regex_scm",(void*)f_12137},
{"f_12042:regex_scm",(void*)f_12042},
{"f_11966:regex_scm",(void*)f_11966},
{"f_11991:regex_scm",(void*)f_11991},
{"f_11838:regex_scm",(void*)f_11838},
{"f_11857:regex_scm",(void*)f_11857},
{"f_11906:regex_scm",(void*)f_11906},
{"f_11697:regex_scm",(void*)f_11697},
{"f_11701:regex_scm",(void*)f_11701},
{"f_11384:regex_scm",(void*)f_11384},
{"f_11388:regex_scm",(void*)f_11388},
{"f_11390:regex_scm",(void*)f_11390},
{"f_11644:regex_scm",(void*)f_11644},
{"f_11655:regex_scm",(void*)f_11655},
{"f_11651:regex_scm",(void*)f_11651},
{"f_11503:regex_scm",(void*)f_11503},
{"f_11607:regex_scm",(void*)f_11607},
{"f_11588:regex_scm",(void*)f_11588},
{"f_11512:regex_scm",(void*)f_11512},
{"f_11533:regex_scm",(void*)f_11533},
{"f_11543:regex_scm",(void*)f_11543},
{"f_11518:regex_scm",(void*)f_11518},
{"f_11528:regex_scm",(void*)f_11528},
{"f_11486:regex_scm",(void*)f_11486},
{"f_11484:regex_scm",(void*)f_11484},
{"f_11459:regex_scm",(void*)f_11459},
{"f_11457:regex_scm",(void*)f_11457},
{"f_11393:regex_scm",(void*)f_11393},
{"f_11704:regex_scm",(void*)f_11704},
{"f_11707:regex_scm",(void*)f_11707},
{"f_11710:regex_scm",(void*)f_11710},
{"f_11713:regex_scm",(void*)f_11713},
{"f_11787:regex_scm",(void*)f_11787},
{"f_11716:regex_scm",(void*)f_11716},
{"f_11719:regex_scm",(void*)f_11719},
{"f_11722:regex_scm",(void*)f_11722},
{"f_16317:regex_scm",(void*)f_16317},
{"f_16641:regex_scm",(void*)f_16641},
{"f_16331:regex_scm",(void*)f_16331},
{"f_16344:regex_scm",(void*)f_16344},
{"f_16335:regex_scm",(void*)f_16335},
{"f_16336:regex_scm",(void*)f_16336},
{"f_16592:regex_scm",(void*)f_16592},
{"f_16593:regex_scm",(void*)f_16593},
{"f_16597:regex_scm",(void*)f_16597},
{"f_16600:regex_scm",(void*)f_16600},
{"f_16567:regex_scm",(void*)f_16567},
{"f_16568:regex_scm",(void*)f_16568},
{"f_16572:regex_scm",(void*)f_16572},
{"f_16511:regex_scm",(void*)f_16511},
{"f_16536:regex_scm",(void*)f_16536},
{"f_16540:regex_scm",(void*)f_16540},
{"f_16513:regex_scm",(void*)f_16513},
{"f_16517:regex_scm",(void*)f_16517},
{"f_16461:regex_scm",(void*)f_16461},
{"f_16486:regex_scm",(void*)f_16486},
{"f_16464:regex_scm",(void*)f_16464},
{"f_16465:regex_scm",(void*)f_16465},
{"f_16469:regex_scm",(void*)f_16469},
{"f_16368:regex_scm",(void*)f_16368},
{"f_16437:regex_scm",(void*)f_16437},
{"f_16371:regex_scm",(void*)f_16371},
{"f_16372:regex_scm",(void*)f_16372},
{"f_16378:regex_scm",(void*)f_16378},
{"f_16388:regex_scm",(void*)f_16388},
{"f_16391:regex_scm",(void*)f_16391},
{"f_11725:regex_scm",(void*)f_11725},
{"f_11728:regex_scm",(void*)f_11728},
{"f_11731:regex_scm",(void*)f_11731},
{"f_12359:regex_scm",(void*)f_12359},
{"f_13380:regex_scm",(void*)f_13380},
{"f_12362:regex_scm",(void*)f_12362},
{"f_12371:regex_scm",(void*)f_12371},
{"f_12416:regex_scm",(void*)f_12416},
{"f_12445:regex_scm",(void*)f_12445},
{"f_13175:regex_scm",(void*)f_13175},
{"f_13225:regex_scm",(void*)f_13225},
{"f_13202:regex_scm",(void*)f_13202},
{"f_13148:regex_scm",(void*)f_13148},
{"f_13118:regex_scm",(void*)f_13118},
{"f_12974:regex_scm",(void*)f_12974},
{"f_12977:regex_scm",(void*)f_12977},
{"f_13042:regex_scm",(void*)f_13042},
{"f_12995:regex_scm",(void*)f_12995},
{"f_13007:regex_scm",(void*)f_13007},
{"f_12954:regex_scm",(void*)f_12954},
{"f_12945:regex_scm",(void*)f_12945},
{"f_12832:regex_scm",(void*)f_12832},
{"f_12895:regex_scm",(void*)f_12895},
{"f_12841:regex_scm",(void*)f_12841},
{"f_12792:regex_scm",(void*)f_12792},
{"f_12621:regex_scm",(void*)f_12621},
{"f_12627:regex_scm",(void*)f_12627},
{"f_12630:regex_scm",(void*)f_12630},
{"f_12712:regex_scm",(void*)f_12712},
{"f_12639:regex_scm",(void*)f_12639},
{"f_12653:regex_scm",(void*)f_12653},
{"f_12665:regex_scm",(void*)f_12665},
{"f_12667:regex_scm",(void*)f_12667},
{"f_12696:regex_scm",(void*)f_12696},
{"f_12692:regex_scm",(void*)f_12692},
{"f_12679:regex_scm",(void*)f_12679},
{"f_12536:regex_scm",(void*)f_12536},
{"f_12569:regex_scm",(void*)f_12569},
{"f_12602:regex_scm",(void*)f_12602},
{"f_12585:regex_scm",(void*)f_12585},
{"f_12589:regex_scm",(void*)f_12589},
{"f_12454:regex_scm",(void*)f_12454},
{"f_12487:regex_scm",(void*)f_12487},
{"f_12517:regex_scm",(void*)f_12517},
{"f_12432:regex_scm",(void*)f_12432},
{"f_12374:regex_scm",(void*)f_12374},
{"f_12369:regex_scm",(void*)f_12369},
{"f_11753:regex_scm",(void*)f_11753},
{"f_11760:regex_scm",(void*)f_11760},
{"f_11737:regex_scm",(void*)f_11737},
{"f_18607:regex_scm",(void*)f_18607},
{"f_16648:regex_scm",(void*)f_16648},
{"f_16660:regex_scm",(void*)f_16660},
{"f_18595:regex_scm",(void*)f_18595},
{"f_18514:regex_scm",(void*)f_18514},
{"f_18547:regex_scm",(void*)f_18547},
{"f_18554:regex_scm",(void*)f_18554},
{"f_18515:regex_scm",(void*)f_18515},
{"f_18522:regex_scm",(void*)f_18522},
{"f_18418:regex_scm",(void*)f_18418},
{"f_18425:regex_scm",(void*)f_18425},
{"f_18360:regex_scm",(void*)f_18360},
{"f_18379:regex_scm",(void*)f_18379},
{"f_18367:regex_scm",(void*)f_18367},
{"f_18326:regex_scm",(void*)f_18326},
{"f_18336:regex_scm",(void*)f_18336},
{"f_18302:regex_scm",(void*)f_18302},
{"f_18244:regex_scm",(void*)f_18244},
{"f_18263:regex_scm",(void*)f_18263},
{"f_18251:regex_scm",(void*)f_18251},
{"f_18210:regex_scm",(void*)f_18210},
{"f_18220:regex_scm",(void*)f_18220},
{"f_18190:regex_scm",(void*)f_18190},
{"f_18148:regex_scm",(void*)f_18148},
{"f_18155:regex_scm",(void*)f_18155},
{"f_18120:regex_scm",(void*)f_18120},
{"f_16706:regex_scm",(void*)f_16706},
{"f_18072:regex_scm",(void*)f_18072},
{"f_18032:regex_scm",(void*)f_18032},
{"f_18044:regex_scm",(void*)f_18044},
{"f_18002:regex_scm",(void*)f_18002},
{"f_18003:regex_scm",(void*)f_18003},
{"f_18015:regex_scm",(void*)f_18015},
{"f_17875:regex_scm",(void*)f_17875},
{"f_17931:regex_scm",(void*)f_17931},
{"f_17879:regex_scm",(void*)f_17879},
{"f_17883:regex_scm",(void*)f_17883},
{"f_17917:regex_scm",(void*)f_17917},
{"f_17901:regex_scm",(void*)f_17901},
{"f_17733:regex_scm",(void*)f_17733},
{"f_17736:regex_scm",(void*)f_17736},
{"f_17843:regex_scm",(void*)f_17843},
{"f_17838:regex_scm",(void*)f_17838},
{"f_17834:regex_scm",(void*)f_17834},
{"f_17739:regex_scm",(void*)f_17739},
{"f_17748:regex_scm",(void*)f_17748},
{"f_17794:regex_scm",(void*)f_17794},
{"f_17795:regex_scm",(void*)f_17795},
{"f_17801:regex_scm",(void*)f_17801},
{"f_17751:regex_scm",(void*)f_17751},
{"f_17752:regex_scm",(void*)f_17752},
{"f_17719:regex_scm",(void*)f_17719},
{"f_17696:regex_scm",(void*)f_17696},
{"f_17697:regex_scm",(void*)f_17697},
{"f_17712:regex_scm",(void*)f_17712},
{"f_17701:regex_scm",(void*)f_17701},
{"f_17678:regex_scm",(void*)f_17678},
{"f_17647:regex_scm",(void*)f_17647},
{"f_17648:regex_scm",(void*)f_17648},
{"f_17669:regex_scm",(void*)f_17669},
{"f_17671:regex_scm",(void*)f_17671},
{"f_17665:regex_scm",(void*)f_17665},
{"f_17629:regex_scm",(void*)f_17629},
{"f_17598:regex_scm",(void*)f_17598},
{"f_17599:regex_scm",(void*)f_17599},
{"f_17620:regex_scm",(void*)f_17620},
{"f_17622:regex_scm",(void*)f_17622},
{"f_17616:regex_scm",(void*)f_17616},
{"f_17584:regex_scm",(void*)f_17584},
{"f_17561:regex_scm",(void*)f_17561},
{"f_17562:regex_scm",(void*)f_17562},
{"f_17577:regex_scm",(void*)f_17577},
{"f_17569:regex_scm",(void*)f_17569},
{"f_17547:regex_scm",(void*)f_17547},
{"f_17524:regex_scm",(void*)f_17524},
{"f_17525:regex_scm",(void*)f_17525},
{"f_17540:regex_scm",(void*)f_17540},
{"f_17532:regex_scm",(void*)f_17532},
{"f_17511:regex_scm",(void*)f_17511},
{"f_17486:regex_scm",(void*)f_17486},
{"f_17421:regex_scm",(void*)f_17421},
{"f_17234:regex_scm",(void*)f_17234},
{"f_17237:regex_scm",(void*)f_17237},
{"f_17260:regex_scm",(void*)f_17260},
{"f_17326:regex_scm",(void*)f_17326},
{"f_17310:regex_scm",(void*)f_17310},
{"f_17263:regex_scm",(void*)f_17263},
{"f_17295:regex_scm",(void*)f_17295},
{"f_17290:regex_scm",(void*)f_17290},
{"f_17284:regex_scm",(void*)f_17284},
{"f_17280:regex_scm",(void*)f_17280},
{"f_17238:regex_scm",(void*)f_17238},
{"f_17215:regex_scm",(void*)f_17215},
{"f_17182:regex_scm",(void*)f_17182},
{"f_17133:regex_scm",(void*)f_17133},
{"f_17070:regex_scm",(void*)f_17070},
{"f_17094:regex_scm",(void*)f_17094},
{"f_17100:regex_scm",(void*)f_17100},
{"f_17077:regex_scm",(void*)f_17077},
{"f_17078:regex_scm",(void*)f_17078},
{"f_17084:regex_scm",(void*)f_17084},
{"f_17012:regex_scm",(void*)f_17012},
{"f_17036:regex_scm",(void*)f_17036},
{"f_17042:regex_scm",(void*)f_17042},
{"f_17019:regex_scm",(void*)f_17019},
{"f_17020:regex_scm",(void*)f_17020},
{"f_17026:regex_scm",(void*)f_17026},
{"f_16981:regex_scm",(void*)f_16981},
{"f_16982:regex_scm",(void*)f_16982},
{"f_16988:regex_scm",(void*)f_16988},
{"f_16953:regex_scm",(void*)f_16953},
{"f_16954:regex_scm",(void*)f_16954},
{"f_16960:regex_scm",(void*)f_16960},
{"f_16932:regex_scm",(void*)f_16932},
{"f_16913:regex_scm",(void*)f_16913},
{"f_16875:regex_scm",(void*)f_16875},
{"f_16854:regex_scm",(void*)f_16854},
{"f_16833:regex_scm",(void*)f_16833},
{"f_16812:regex_scm",(void*)f_16812},
{"f_16753:regex_scm",(void*)f_16753},
{"f_16779:regex_scm",(void*)f_16779},
{"f_16756:regex_scm",(void*)f_16756},
{"f_16757:regex_scm",(void*)f_16757},
{"f_16763:regex_scm",(void*)f_16763},
{"f_16733:regex_scm",(void*)f_16733},
{"f_16717:regex_scm",(void*)f_16717},
{"f_16713:regex_scm",(void*)f_16713},
{"f_16694:regex_scm",(void*)f_16694},
{"f_16686:regex_scm",(void*)f_16686},
{"f_16663:regex_scm",(void*)f_16663},
{"f_16657:regex_scm",(void*)f_16657},
{"f_11746:regex_scm",(void*)f_11746},
{"f_11687:regex_scm",(void*)f_11687},
{"f_11695:regex_scm",(void*)f_11695},
{"f_11666:regex_scm",(void*)f_11666},
{"f_11673:regex_scm",(void*)f_11673},
{"f_11216:regex_scm",(void*)f_11216},
{"f_11222:regex_scm",(void*)f_11222},
{"f_11310:regex_scm",(void*)f_11310},
{"f_11313:regex_scm",(void*)f_11313},
{"f_10375:regex_scm",(void*)f_10375},
{"f_10378:regex_scm",(void*)f_10378},
{"f_11079:regex_scm",(void*)f_11079},
{"f_11077:regex_scm",(void*)f_11077},
{"f_11057:regex_scm",(void*)f_11057},
{"f_11053:regex_scm",(void*)f_11053},
{"f_10971:regex_scm",(void*)f_10971},
{"f_11049:regex_scm",(void*)f_11049},
{"f_11045:regex_scm",(void*)f_11045},
{"f_11041:regex_scm",(void*)f_11041},
{"f_11037:regex_scm",(void*)f_11037},
{"f_11013:regex_scm",(void*)f_11013},
{"f_10989:regex_scm",(void*)f_10989},
{"f_10987:regex_scm",(void*)f_10987},
{"f_10879:regex_scm",(void*)f_10879},
{"f_10953:regex_scm",(void*)f_10953},
{"f_10901:regex_scm",(void*)f_10901},
{"f_10899:regex_scm",(void*)f_10899},
{"f_10871:regex_scm",(void*)f_10871},
{"f_10399:regex_scm",(void*)f_10399},
{"f_10404:regex_scm",(void*)f_10404},
{"f_10476:regex_scm",(void*)f_10476},
{"f_11154:regex_scm",(void*)f_11154},
{"f_11160:regex_scm",(void*)f_11160},
{"f_11158:regex_scm",(void*)f_11158},
{"f_10484:regex_scm",(void*)f_10484},
{"f_10461:regex_scm",(void*)f_10461},
{"f_10465:regex_scm",(void*)f_10465},
{"f_10432:regex_scm",(void*)f_10432},
{"f_11328:regex_scm",(void*)f_11328},
{"f_11270:regex_scm",(void*)f_11270},
{"f_11240:regex_scm",(void*)f_11240},
{"f_11258:regex_scm",(void*)f_11258},
{"f_11244:regex_scm",(void*)f_11244},
{"f_11236:regex_scm",(void*)f_11236},
{"f_10732:regex_scm",(void*)f_10732},
{"f_10850:regex_scm",(void*)f_10850},
{"f_10842:regex_scm",(void*)f_10842},
{"f_10834:regex_scm",(void*)f_10834},
{"f_10802:regex_scm",(void*)f_10802},
{"f_10830:regex_scm",(void*)f_10830},
{"f_10798:regex_scm",(void*)f_10798},
{"f_10754:regex_scm",(void*)f_10754},
{"f_10752:regex_scm",(void*)f_10752},
{"f_10604:regex_scm",(void*)f_10604},
{"f_10722:regex_scm",(void*)f_10722},
{"f_10714:regex_scm",(void*)f_10714},
{"f_10706:regex_scm",(void*)f_10706},
{"f_10674:regex_scm",(void*)f_10674},
{"f_10702:regex_scm",(void*)f_10702},
{"f_10670:regex_scm",(void*)f_10670},
{"f_10626:regex_scm",(void*)f_10626},
{"f_10624:regex_scm",(void*)f_10624},
{"f_10518:regex_scm",(void*)f_10518},
{"f_10552:regex_scm",(void*)f_10552},
{"f_10560:regex_scm",(void*)f_10560},
{"f_10570:regex_scm",(void*)f_10570},
{"f_10568:regex_scm",(void*)f_10568},
{"f_10564:regex_scm",(void*)f_10564},
{"f_10548:regex_scm",(void*)f_10548},
{"f_10242:regex_scm",(void*)f_10242},
{"f_10366:regex_scm",(void*)f_10366},
{"f_10330:regex_scm",(void*)f_10330},
{"f_10362:regex_scm",(void*)f_10362},
{"f_10358:regex_scm",(void*)f_10358},
{"f_10334:regex_scm",(void*)f_10334},
{"f_10354:regex_scm",(void*)f_10354},
{"f_10350:regex_scm",(void*)f_10350},
{"f_10338:regex_scm",(void*)f_10338},
{"f_10346:regex_scm",(void*)f_10346},
{"f_10342:regex_scm",(void*)f_10342},
{"f_10317:regex_scm",(void*)f_10317},
{"f_10293:regex_scm",(void*)f_10293},
{"f_10313:regex_scm",(void*)f_10313},
{"f_10309:regex_scm",(void*)f_10309},
{"f_10297:regex_scm",(void*)f_10297},
{"f_10305:regex_scm",(void*)f_10305},
{"f_10301:regex_scm",(void*)f_10301},
{"f_10280:regex_scm",(void*)f_10280},
{"f_10268:regex_scm",(void*)f_10268},
{"f_10276:regex_scm",(void*)f_10276},
{"f_10272:regex_scm",(void*)f_10272},
{"f_10182:regex_scm",(void*)f_10182},
{"f_9957:regex_scm",(void*)f_9957},
{"f_10132:regex_scm",(void*)f_10132},
{"f_10084:regex_scm",(void*)f_10084},
{"f_10120:regex_scm",(void*)f_10120},
{"f_10088:regex_scm",(void*)f_10088},
{"f_10108:regex_scm",(void*)f_10108},
{"f_10092:regex_scm",(void*)f_10092},
{"f_10096:regex_scm",(void*)f_10096},
{"f_10080:regex_scm",(void*)f_10080},
{"f_10063:regex_scm",(void*)f_10063},
{"f_10031:regex_scm",(void*)f_10031},
{"f_10051:regex_scm",(void*)f_10051},
{"f_10035:regex_scm",(void*)f_10035},
{"f_10039:regex_scm",(void*)f_10039},
{"f_10027:regex_scm",(void*)f_10027},
{"f_10010:regex_scm",(void*)f_10010},
{"f_9994:regex_scm",(void*)f_9994},
{"f_9998:regex_scm",(void*)f_9998},
{"f_9960:regex_scm",(void*)f_9960},
{"f_9947:regex_scm",(void*)f_9947},
{"f_9937:regex_scm",(void*)f_9937},
{"f_9214:regex_scm",(void*)f_9214},
{"f_9281:regex_scm",(void*)f_9281},
{"f_9284:regex_scm",(void*)f_9284},
{"f_5364:regex_scm",(void*)f_5364},
{"f_9233:regex_scm",(void*)f_9233},
{"f_9245:regex_scm",(void*)f_9245},
{"f_9248:regex_scm",(void*)f_9248},
{"f_9172:regex_scm",(void*)f_9172},
{"f_6263:regex_scm",(void*)f_6263},
{"f_6270:regex_scm",(void*)f_6270},
{"f_6275:regex_scm",(void*)f_6275},
{"f_9121:regex_scm",(void*)f_9121},
{"f_9124:regex_scm",(void*)f_9124},
{"f_9142:regex_scm",(void*)f_9142},
{"f_9087:regex_scm",(void*)f_9087},
{"f_9102:regex_scm",(void*)f_9102},
{"f_9075:regex_scm",(void*)f_9075},
{"f_9072:regex_scm",(void*)f_9072},
{"f_9044:regex_scm",(void*)f_9044},
{"f_9041:regex_scm",(void*)f_9041},
{"f_9013:regex_scm",(void*)f_9013},
{"f_8980:regex_scm",(void*)f_8980},
{"f_8962:regex_scm",(void*)f_8962},
{"f_5422:regex_scm",(void*)f_5422},
{"f_8870:regex_scm",(void*)f_8870},
{"f_8913:regex_scm",(void*)f_8913},
{"f_8906:regex_scm",(void*)f_8906},
{"f_8902:regex_scm",(void*)f_8902},
{"f_8894:regex_scm",(void*)f_8894},
{"f_8890:regex_scm",(void*)f_8890},
{"f_8756:regex_scm",(void*)f_8756},
{"f_8765:regex_scm",(void*)f_8765},
{"f_8827:regex_scm",(void*)f_8827},
{"f_8672:regex_scm",(void*)f_8672},
{"f_8675:regex_scm",(void*)f_8675},
{"f_8678:regex_scm",(void*)f_8678},
{"f_8728:regex_scm",(void*)f_8728},
{"f_8725:regex_scm",(void*)f_8725},
{"f_8717:regex_scm",(void*)f_8717},
{"f_8713:regex_scm",(void*)f_8713},
{"f_8647:regex_scm",(void*)f_8647},
{"f_8619:regex_scm",(void*)f_8619},
{"f_8643:regex_scm",(void*)f_8643},
{"f_8639:regex_scm",(void*)f_8639},
{"f_8608:regex_scm",(void*)f_8608},
{"f_8604:regex_scm",(void*)f_8604},
{"f_8579:regex_scm",(void*)f_8579},
{"f_8575:regex_scm",(void*)f_8575},
{"f_8550:regex_scm",(void*)f_8550},
{"f_8546:regex_scm",(void*)f_8546},
{"f_8521:regex_scm",(void*)f_8521},
{"f_8517:regex_scm",(void*)f_8517},
{"f_8492:regex_scm",(void*)f_8492},
{"f_8488:regex_scm",(void*)f_8488},
{"f_8459:regex_scm",(void*)f_8459},
{"f_8455:regex_scm",(void*)f_8455},
{"f_8422:regex_scm",(void*)f_8422},
{"f_8418:regex_scm",(void*)f_8418},
{"f_8393:regex_scm",(void*)f_8393},
{"f_8389:regex_scm",(void*)f_8389},
{"f_8356:regex_scm",(void*)f_8356},
{"f_8352:regex_scm",(void*)f_8352},
{"f_8303:regex_scm",(void*)f_8303},
{"f_8299:regex_scm",(void*)f_8299},
{"f_8258:regex_scm",(void*)f_8258},
{"f_8254:regex_scm",(void*)f_8254},
{"f_8221:regex_scm",(void*)f_8221},
{"f_8217:regex_scm",(void*)f_8217},
{"f_8188:regex_scm",(void*)f_8188},
{"f_8184:regex_scm",(void*)f_8184},
{"f_8155:regex_scm",(void*)f_8155},
{"f_8151:regex_scm",(void*)f_8151},
{"f_8122:regex_scm",(void*)f_8122},
{"f_8118:regex_scm",(void*)f_8118},
{"f_8052:regex_scm",(void*)f_8052},
{"f_7871:regex_scm",(void*)f_7871},
{"f_7881:regex_scm",(void*)f_7881},
{"f_7890:regex_scm",(void*)f_7890},
{"f_8034:regex_scm",(void*)f_8034},
{"f_5463:regex_scm",(void*)f_5463},
{"f_5508:regex_scm",(void*)f_5508},
{"f_5487:regex_scm",(void*)f_5487},
{"f_5466:regex_scm",(void*)f_5466},
{"f_5474:regex_scm",(void*)f_5474},
{"f_7893:regex_scm",(void*)f_7893},
{"f_7896:regex_scm",(void*)f_7896},
{"f_7902:regex_scm",(void*)f_7902},
{"f_8000:regex_scm",(void*)f_8000},
{"f_7965:regex_scm",(void*)f_7965},
{"f_7931:regex_scm",(void*)f_7931},
{"f_9325:regex_scm",(void*)f_9325},
{"f_9928:regex_scm",(void*)f_9928},
{"f_9327:regex_scm",(void*)f_9327},
{"f_9875:regex_scm",(void*)f_9875},
{"f_9893:regex_scm",(void*)f_9893},
{"f_9741:regex_scm",(void*)f_9741},
{"f_9802:regex_scm",(void*)f_9802},
{"f_9786:regex_scm",(void*)f_9786},
{"f_9771:regex_scm",(void*)f_9771},
{"f_9744:regex_scm",(void*)f_9744},
{"f_9767:regex_scm",(void*)f_9767},
{"f_9755:regex_scm",(void*)f_9755},
{"f_9763:regex_scm",(void*)f_9763},
{"f_9759:regex_scm",(void*)f_9759},
{"f_9616:regex_scm",(void*)f_9616},
{"f_9625:regex_scm",(void*)f_9625},
{"f_9668:regex_scm",(void*)f_9668},
{"f_9664:regex_scm",(void*)f_9664},
{"f_9631:regex_scm",(void*)f_9631},
{"f_9634:regex_scm",(void*)f_9634},
{"f_9657:regex_scm",(void*)f_9657},
{"f_9645:regex_scm",(void*)f_9645},
{"f_9653:regex_scm",(void*)f_9653},
{"f_9649:regex_scm",(void*)f_9649},
{"f_9564:regex_scm",(void*)f_9564},
{"f_9477:regex_scm",(void*)f_9477},
{"f_9540:regex_scm",(void*)f_9540},
{"f_9509:regex_scm",(void*)f_9509},
{"f_9525:regex_scm",(void*)f_9525},
{"f_9366:regex_scm",(void*)f_9366},
{"f_9369:regex_scm",(void*)f_9369},
{"f_5968:regex_scm",(void*)f_5968},
{"f_5992:regex_scm",(void*)f_5992},
{"f_5989:regex_scm",(void*)f_5989},
{"f_9372:regex_scm",(void*)f_9372},
{"f_9445:regex_scm",(void*)f_9445},
{"f_9449:regex_scm",(void*)f_9449},
{"f_9441:regex_scm",(void*)f_9441},
{"f_9437:regex_scm",(void*)f_9437},
{"f_9392:regex_scm",(void*)f_9392},
{"f_9420:regex_scm",(void*)f_9420},
{"f_9402:regex_scm",(void*)f_9402},
{"f_18707:regex_scm",(void*)f_18707},
{"f_9413:regex_scm",(void*)f_9413},
{"f_9396:regex_scm",(void*)f_9396},
{"f_9379:regex_scm",(void*)f_9379},
{"f_7852:regex_scm",(void*)f_7852},
{"f_7828:regex_scm",(void*)f_7828},
{"f_7848:regex_scm",(void*)f_7848},
{"f_7813:regex_scm",(void*)f_7813},
{"f_7078:regex_scm",(void*)f_7078},
{"f_7082:regex_scm",(void*)f_7082},
{"f_7547:regex_scm",(void*)f_7547},
{"f_7732:regex_scm",(void*)f_7732},
{"f_7744:regex_scm",(void*)f_7744},
{"f_7711:regex_scm",(void*)f_7711},
{"f_7707:regex_scm",(void*)f_7707},
{"f_7662:regex_scm",(void*)f_7662},
{"f_7642:regex_scm",(void*)f_7642},
{"f_7625:regex_scm",(void*)f_7625},
{"f_7608:regex_scm",(void*)f_7608},
{"f_7559:regex_scm",(void*)f_7559},
{"f_7563:regex_scm",(void*)f_7563},
{"f_7566:regex_scm",(void*)f_7566},
{"f_7550:regex_scm",(void*)f_7550},
{"f_7505:regex_scm",(void*)f_7505},
{"f_7509:regex_scm",(void*)f_7509},
{"f_7448:regex_scm",(void*)f_7448},
{"f_7482:regex_scm",(void*)f_7482},
{"f_7451:regex_scm",(void*)f_7451},
{"f_7466:regex_scm",(void*)f_7466},
{"f_7474:regex_scm",(void*)f_7474},
{"f_7388:regex_scm",(void*)f_7388},
{"f_7431:regex_scm",(void*)f_7431},
{"f_7391:regex_scm",(void*)f_7391},
{"f_7415:regex_scm",(void*)f_7415},
{"f_7423:regex_scm",(void*)f_7423},
{"f_7360:regex_scm",(void*)f_7360},
{"f_7364:regex_scm",(void*)f_7364},
{"f_7268:regex_scm",(void*)f_7268},
{"f_7286:regex_scm",(void*)f_7286},
{"f_7306:regex_scm",(void*)f_7306},
{"f_7298:regex_scm",(void*)f_7298},
{"f_7294:regex_scm",(void*)f_7294},
{"f_7261:regex_scm",(void*)f_7261},
{"f_7265:regex_scm",(void*)f_7265},
{"f_7236:regex_scm",(void*)f_7236},
{"f_7240:regex_scm",(void*)f_7240},
{"f_7193:regex_scm",(void*)f_7193},
{"f_7197:regex_scm",(void*)f_7197},
{"f_7168:regex_scm",(void*)f_7168},
{"f_7172:regex_scm",(void*)f_7172},
{"f_7143:regex_scm",(void*)f_7143},
{"f_7147:regex_scm",(void*)f_7147},
{"f_7103:regex_scm",(void*)f_7103},
{"f_7118:regex_scm",(void*)f_7118},
{"f_6991:regex_scm",(void*)f_6991},
{"f_6997:regex_scm",(void*)f_6997},
{"f_7012:regex_scm",(void*)f_7012},
{"f_6794:regex_scm",(void*)f_6794},
{"f_6961:regex_scm",(void*)f_6961},
{"f_6932:regex_scm",(void*)f_6932},
{"f_6907:regex_scm",(void*)f_6907},
{"f_6890:regex_scm",(void*)f_6890},
{"f_6873:regex_scm",(void*)f_6873},
{"f_6848:regex_scm",(void*)f_6848},
{"f_6825:regex_scm",(void*)f_6825},
{"f_6785:regex_scm",(void*)f_6785},
{"f_6782:regex_scm",(void*)f_6782},
{"f_6720:regex_scm",(void*)f_6720},
{"f_6732:regex_scm",(void*)f_6732},
{"f_6420:regex_scm",(void*)f_6420},
{"f_6424:regex_scm",(void*)f_6424},
{"f_6718:regex_scm",(void*)f_6718},
{"f_6427:regex_scm",(void*)f_6427},
{"f_6680:regex_scm",(void*)f_6680},
{"f_6691:regex_scm",(void*)f_6691},
{"f_6430:regex_scm",(void*)f_6430},
{"f_6673:regex_scm",(void*)f_6673},
{"f_6662:regex_scm",(void*)f_6662},
{"f_6433:regex_scm",(void*)f_6433},
{"f_6438:regex_scm",(void*)f_6438},
{"f_6602:regex_scm",(void*)f_6602},
{"f_6540:regex_scm",(void*)f_6540},
{"f_6507:regex_scm",(void*)f_6507},
{"f_6441:regex_scm",(void*)f_6441},
{"f_6348:regex_scm",(void*)f_6348},
{"f_6352:regex_scm",(void*)f_6352},
{"f_10147:regex_scm",(void*)f_10147},
{"f_6355:regex_scm",(void*)f_6355},
{"f_6392:regex_scm",(void*)f_6392},
{"f_6364:regex_scm",(void*)f_6364},
{"f_6388:regex_scm",(void*)f_6388},
{"f_6384:regex_scm",(void*)f_6384},
{"f_6328:regex_scm",(void*)f_6328},
{"f_6346:regex_scm",(void*)f_6346},
{"f_6342:regex_scm",(void*)f_6342},
{"f_6308:regex_scm",(void*)f_6308},
{"f_6315:regex_scm",(void*)f_6315},
{"f_6326:regex_scm",(void*)f_6326},
{"f_6322:regex_scm",(void*)f_6322},
{"f_6278:regex_scm",(void*)f_6278},
{"f_6303:regex_scm",(void*)f_6303},
{"f_6163:regex_scm",(void*)f_6163},
{"f_6169:regex_scm",(void*)f_6169},
{"f_6200:regex_scm",(void*)f_6200},
{"f_6194:regex_scm",(void*)f_6194},
{"f_6187:regex_scm",(void*)f_6187},
{"f_6144:regex_scm",(void*)f_6144},
{"f_6135:regex_scm",(void*)f_6135},
{"f_6125:regex_scm",(void*)f_6125},
{"f_6133:regex_scm",(void*)f_6133},
{"f_6078:regex_scm",(void*)f_6078},
{"f_6110:regex_scm",(void*)f_6110},
{"f_6114:regex_scm",(void*)f_6114},
{"f_6106:regex_scm",(void*)f_6106},
{"f_6031:regex_scm",(void*)f_6031},
{"f_6063:regex_scm",(void*)f_6063},
{"f_6067:regex_scm",(void*)f_6067},
{"f_6059:regex_scm",(void*)f_6059},
{"f_6015:regex_scm",(void*)f_6015},
{"f_6023:regex_scm",(void*)f_6023},
{"f_6005:regex_scm",(void*)f_6005},
{"f_6013:regex_scm",(void*)f_6013},
{"f_5919:regex_scm",(void*)f_5919},
{"f_5925:regex_scm",(void*)f_5925},
{"f_5949:regex_scm",(void*)f_5949},
{"f_5946:regex_scm",(void*)f_5946},
{"f_5889:regex_scm",(void*)f_5889},
{"f_5895:regex_scm",(void*)f_5895},
{"f_5913:regex_scm",(void*)f_5913},
{"f_5840:regex_scm",(void*)f_5840},
{"f_5860:regex_scm",(void*)f_5860},
{"f_5876:regex_scm",(void*)f_5876},
{"f_5791:regex_scm",(void*)f_5791},
{"f_5811:regex_scm",(void*)f_5811},
{"f_5824:regex_scm",(void*)f_5824},
{"f_5749:regex_scm",(void*)f_5749},
{"f_5764:regex_scm",(void*)f_5764},
{"f_5717:regex_scm",(void*)f_5717},
{"f_5723:regex_scm",(void*)f_5723},
{"f_5736:regex_scm",(void*)f_5736},
{"f_5705:regex_scm",(void*)f_5705},
{"f_5709:regex_scm",(void*)f_5709},
{"f_5662:regex_scm",(void*)f_5662},
{"f_5668:regex_scm",(void*)f_5668},
{"f_5675:regex_scm",(void*)f_5675},
{"f_5623:regex_scm",(void*)f_5623},
{"f_5639:regex_scm",(void*)f_5639},
{"f_5566:regex_scm",(void*)f_5566},
{"f_5576:regex_scm",(void*)f_5576},
{"f_5574:regex_scm",(void*)f_5574},
{"f_5590:regex_scm",(void*)f_5590},
{"f_5595:regex_scm",(void*)f_5595},
{"f_5539:regex_scm",(void*)f_5539},
{"f_5614:regex_scm",(void*)f_5614},
{"f_5593:regex_scm",(void*)f_5593},
{"f_5521:regex_scm",(void*)f_5521},
{"f_5306:regex_scm",(void*)f_5306},
{"f_5319:regex_scm",(void*)f_5319},
{"f_5291:regex_scm",(void*)f_5291},
{"f_5299:regex_scm",(void*)f_5299},
{"f_5268:regex_scm",(void*)f_5268},
{"f_5272:regex_scm",(void*)f_5272},
{"f_5225:regex_scm",(void*)f_5225},
{"f_5229:regex_scm",(void*)f_5229},
{"f_5242:regex_scm",(void*)f_5242},
{"f_5193:regex_scm",(void*)f_5193},
{"f_5147:regex_scm",(void*)f_5147},
{"f_5133:regex_scm",(void*)f_5133},
{"f_5119:regex_scm",(void*)f_5119},
{"f_5105:regex_scm",(void*)f_5105},
{"f_5091:regex_scm",(void*)f_5091},
{"f_5085:regex_scm",(void*)f_5085},
{"f_5073:regex_scm",(void*)f_5073},
{"f_5055:regex_scm",(void*)f_5055},
{"f_5063:regex_scm",(void*)f_5063},
{"f_5002:regex_scm",(void*)f_5002},
{"f_4968:regex_scm",(void*)f_4968},
{"f_4978:regex_scm",(void*)f_4978},
{"f_4954:regex_scm",(void*)f_4954},
{"f_4962:regex_scm",(void*)f_4962},
{"f_4966:regex_scm",(void*)f_4966},
{"f_5032:regex_scm",(void*)f_5032},
{"f_4948:regex_scm",(void*)f_4948},
{"f_4942:regex_scm",(void*)f_4942},
{"f_4936:regex_scm",(void*)f_4936},
{"f_4930:regex_scm",(void*)f_4930},
{"f_4924:regex_scm",(void*)f_4924},
{"f_4918:regex_scm",(void*)f_4918},
{"f_4912:regex_scm",(void*)f_4912},
{"f_4906:regex_scm",(void*)f_4906},
{"f_4880:regex_scm",(void*)f_4880},
{"f_4874:regex_scm",(void*)f_4874},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
