/* Generated from srfi-69.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2009-03-24 10:47
   Version 4.0.0 - SVN rev. 13887
   windows-mingw32-x86 [ manyargs dload ptables applyhook ]
   compiled 2009-03-24 on LENOVO-1 (MINGW32_NT-6.0)
   command line: srfi-69.scm -no-trace -optimize-level 2 -include-path . -include-path ./ -feature debugbuild -explicit-use -unsafe -no-lambda-info -output-file usrfi-69.c -extend ./private-namespace.scm
   unit: srfi_69
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);

static C_TLS C_word lf[110];
static double C_possibly_force_alignment;


C_noret_decl(C_srfi_69_toplevel)
C_externexport void C_ccall C_srfi_69_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1947)
static void C_ccall f_1947(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5380)
static void C_ccall f_5380(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5380)
static void C_ccall f_5380r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5390)
static void C_ccall f_5390(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5402)
static void C_ccall f_5402(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5459)
static void C_fcall f_5459(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5478)
static void C_ccall f_5478(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5417)
static void C_fcall f_5417(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5500)
static void C_ccall f_5500(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4423)
static void C_ccall f_4423(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5358)
static void C_ccall f_5358(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5365)
static void C_ccall f_5365(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5370)
static void C_ccall f_5370(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5378)
static void C_ccall f_5378(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5346)
static void C_ccall f_5346(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5353)
static void C_ccall f_5353(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5334)
static void C_ccall f_5334(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5341)
static void C_ccall f_5341(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5322)
static void C_ccall f_5322(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5329)
static void C_ccall f_5329(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5256)
static void C_fcall f_5256(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5268)
static void C_fcall f_5268(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5284)
static void C_fcall f_5284(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5312)
static void C_ccall f_5312(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5207)
static void C_fcall f_5207(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5219)
static void C_fcall f_5219(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5238)
static void C_ccall f_5238(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5229)
static void C_ccall f_5229(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5142)
static void C_ccall f_5142(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5157)
static void C_fcall f_5157(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5173)
static void C_fcall f_5173(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5077)
static void C_ccall f_5077(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5092)
static void C_fcall f_5092(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5108)
static void C_fcall f_5108(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5048)
static void C_ccall f_5048(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5048)
static void C_ccall f_5048r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5055)
static void C_ccall f_5055(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5060)
static void C_ccall f_5060(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5058)
static void C_ccall f_5058(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4975)
static void C_ccall f_4975(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4990)
static void C_fcall f_4990(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5006)
static void C_fcall f_5006(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4959)
static void C_ccall f_4959(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4973)
static void C_ccall f_4973(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4947)
static void C_ccall f_4947(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4882)
static void C_fcall f_4882(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4894)
static void C_fcall f_4894(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4917)
static void C_fcall f_4917(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4930)
static void C_ccall f_4930(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4904)
static void C_ccall f_4904(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4866)
static void C_ccall f_4866(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4873)
static void C_ccall f_4873(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4770)
static void C_ccall f_4770(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4777)
static void C_ccall f_4777(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4791)
static void C_fcall f_4791(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4817)
static void C_fcall f_4817(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4836)
static void C_ccall f_4836(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4804)
static void C_ccall f_4804(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4639)
static void C_ccall f_4639(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4655)
static void C_ccall f_4655(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4722)
static void C_fcall f_4722(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4741)
static void C_ccall f_4741(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4675)
static C_word C_fcall f_4675(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_4531)
static void C_ccall f_4531(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4547)
static void C_ccall f_4547(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4602)
static void C_fcall f_4602(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4615)
static void C_ccall f_4615(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4562)
static C_word C_fcall f_4562(C_word t0,C_word t1);
C_noret_decl(f_4425)
static void C_ccall f_4425(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4441)
static void C_ccall f_4441(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4495)
static void C_fcall f_4495(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4511)
static void C_ccall f_4511(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4456)
static C_word C_fcall f_4456(C_word t0,C_word t1);
C_noret_decl(f_4228)
static void C_ccall f_4228(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4411)
static void C_ccall f_4411(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4403)
static void C_ccall f_4403(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4384)
static void C_fcall f_4384(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4256)
static void C_ccall f_4256(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4271)
static void C_ccall f_4271(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4337)
static void C_fcall f_4337(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4367)
static void C_ccall f_4367(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4288)
static void C_fcall f_4288(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4277)
static void C_ccall f_4277(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4216)
static void C_ccall f_4216(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_4223)
static void C_ccall f_4223(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4009)
static void C_fcall f_4009(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_4206)
static void C_ccall f_4206(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4198)
static void C_ccall f_4198(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4179)
static void C_fcall f_4179(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4034)
static void C_ccall f_4034(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4049)
static void C_ccall f_4049(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4122)
static void C_fcall f_4122(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4155)
static void C_ccall f_4155(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4158)
static void C_ccall f_4158(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4132)
static void C_ccall f_4132(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4063)
static void C_fcall f_4063(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4099)
static void C_ccall f_4099(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4073)
static void C_ccall f_4073(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3722)
static void C_ccall f_3722(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3722)
static void C_ccall f_3722r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3964)
static void C_fcall f_3964(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3947)
static void C_fcall f_3947(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3959)
static void C_ccall f_3959(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3724)
static void C_fcall f_3724(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3731)
static void C_ccall f_3731(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3734)
static void C_ccall f_3734(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3938)
static void C_ccall f_3938(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3930)
static void C_ccall f_3930(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3911)
static void C_fcall f_3911(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3758)
static void C_ccall f_3758(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3773)
static void C_ccall f_3773(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3850)
static void C_fcall f_3850(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3887)
static void C_ccall f_3887(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3890)
static void C_ccall f_3890(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3878)
static void C_ccall f_3878(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3860)
static void C_ccall f_3860(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3787)
static void C_fcall f_3787(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3827)
static void C_ccall f_3827(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3815)
static void C_ccall f_3815(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3797)
static void C_ccall f_3797(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3713)
static void C_ccall f_3713(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3601)
static void C_fcall f_3601(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3611)
static void C_ccall f_3611(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3616)
static void C_fcall f_3616(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3678)
static void C_fcall f_3678(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3699)
static void C_ccall f_3699(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3672)
static void C_ccall f_3672(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3575)
static void C_ccall f_3575(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3582)
static void C_ccall f_3582(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3585)
static void C_ccall f_3585(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3508)
static void C_fcall f_3508(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3531)
static void C_fcall f_3531(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3547)
static void C_ccall f_3547(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3518)
static void C_ccall f_3518(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3588)
static void C_ccall f_3588(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3481)
static void C_ccall f_3481(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3469)
static void C_ccall f_3469(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3460)
static void C_ccall f_3460(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3451)
static void C_ccall f_3451(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3442)
static void C_ccall f_3442(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3433)
static void C_ccall f_3433(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3424)
static void C_ccall f_3424(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3415)
static void C_ccall f_3415(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3406)
static void C_ccall f_3406(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3400)
static void C_ccall f_3400(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3037)
static void C_ccall f_3037(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3037)
static void C_ccall f_3037r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3390)
static void C_ccall f_3390(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3393)
static void C_ccall f_3393(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3115)
static void C_fcall f_3115(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3370)
static void C_ccall f_3370(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3373)
static void C_ccall f_3373(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3118)
static void C_fcall f_3118(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3338)
static void C_ccall f_3338(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3344)
static void C_ccall f_3344(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3121)
static void C_fcall f_3121(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3156)
static void C_fcall f_3156(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3177)
static void C_ccall f_3177(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3183)
static void C_ccall f_3183(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3275)
static void C_ccall f_3275(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3278)
static void C_ccall f_3278(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3250)
static void C_ccall f_3250(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3253)
static void C_ccall f_3253(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3240)
static void C_ccall f_3240(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3222)
static void C_ccall f_3222(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3209)
static void C_ccall f_3209(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3199)
static void C_ccall f_3199(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3186)
static void C_ccall f_3186(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3167)
static void C_fcall f_3167(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3124)
static void C_ccall f_3124(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3127)
static void C_ccall f_3127(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3131)
static void C_ccall f_3131(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3147)
static void C_ccall f_3147(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3134)
static void C_fcall f_3134(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3039)
static C_word C_fcall f_3039(C_word t0);
C_noret_decl(f_3013)
static void C_fcall f_3013(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8) C_noret;
C_noret_decl(f_3017)
static void C_ccall f_3017(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2983)
static void C_fcall f_2983(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2989)
static C_word C_fcall f_2989(C_word t0,C_word t1);
C_noret_decl(f_2941)
static void C_ccall f_2941(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2941)
static void C_ccall f_2941r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2900)
static void C_ccall f_2900(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2900)
static void C_ccall f_2900r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2858)
static void C_ccall f_2858(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2858)
static void C_ccall f_2858r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2868)
static void C_ccall f_2868(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2524)
static void C_fcall f_2524(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2623)
static void C_fcall f_2623(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2836)
static void C_ccall f_2836(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2815)
static void C_ccall f_2815(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2807)
static void C_ccall f_2807(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2786)
static void C_ccall f_2786(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2760)
static void C_ccall f_2760(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2592)
static void C_fcall f_2592(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2608)
static void C_fcall f_2608(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2527)
static void C_fcall f_2527(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_2544)
static void C_fcall f_2544(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2578)
static void C_ccall f_2578(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2483)
static void C_ccall f_2483(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2483)
static void C_ccall f_2483r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2472)
static void C_ccall f_2472(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2493)
static void C_ccall f_2493(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2299)
static void C_ccall f_2299(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2299)
static void C_ccall f_2299r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2309)
static void C_ccall f_2309(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2195)
static void C_ccall f_2195(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2195)
static void C_ccall f_2195r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2202)
static void C_ccall f_2202(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2169)
static void C_ccall f_2169(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2169)
static void C_ccall f_2169r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2176)
static void C_ccall f_2176(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2125)
static void C_ccall f_2125(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2125)
static void C_ccall f_2125r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2084)
static void C_ccall f_2084(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2084)
static void C_ccall f_2084r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2094)
static void C_ccall f_2094(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1955)
static void C_ccall f_1955(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1955)
static void C_ccall f_1955r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1962)
static void C_ccall f_1962(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2064)
static void C_ccall f_2064(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1968)
static void C_fcall f_1968(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1949)
static void C_ccall f_1949(C_word c,C_word t0,C_word t1,C_word t2) C_noret;

C_noret_decl(trf_5459)
static void C_fcall trf_5459(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5459(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5459(t0,t1,t2);}

C_noret_decl(trf_5417)
static void C_fcall trf_5417(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5417(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5417(t0,t1,t2);}

C_noret_decl(trf_5256)
static void C_fcall trf_5256(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5256(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5256(t0,t1,t2,t3);}

C_noret_decl(trf_5268)
static void C_fcall trf_5268(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5268(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5268(t0,t1,t2,t3);}

C_noret_decl(trf_5284)
static void C_fcall trf_5284(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5284(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5284(t0,t1,t2,t3);}

C_noret_decl(trf_5207)
static void C_fcall trf_5207(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5207(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5207(t0,t1,t2);}

C_noret_decl(trf_5219)
static void C_fcall trf_5219(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5219(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5219(t0,t1,t2);}

C_noret_decl(trf_5157)
static void C_fcall trf_5157(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5157(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5157(t0,t1,t2,t3);}

C_noret_decl(trf_5173)
static void C_fcall trf_5173(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5173(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5173(t0,t1,t2,t3);}

C_noret_decl(trf_5092)
static void C_fcall trf_5092(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5092(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5092(t0,t1,t2,t3);}

C_noret_decl(trf_5108)
static void C_fcall trf_5108(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5108(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5108(t0,t1,t2,t3);}

C_noret_decl(trf_4990)
static void C_fcall trf_4990(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4990(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4990(t0,t1,t2,t3);}

C_noret_decl(trf_5006)
static void C_fcall trf_5006(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5006(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5006(t0,t1,t2,t3);}

C_noret_decl(trf_4882)
static void C_fcall trf_4882(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4882(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4882(t0,t1,t2);}

C_noret_decl(trf_4894)
static void C_fcall trf_4894(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4894(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4894(t0,t1,t2);}

C_noret_decl(trf_4917)
static void C_fcall trf_4917(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4917(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4917(t0,t1,t2);}

C_noret_decl(trf_4791)
static void C_fcall trf_4791(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4791(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4791(t0,t1,t2);}

C_noret_decl(trf_4817)
static void C_fcall trf_4817(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4817(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4817(t0,t1,t2,t3);}

C_noret_decl(trf_4722)
static void C_fcall trf_4722(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4722(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4722(t0,t1,t2,t3);}

C_noret_decl(trf_4602)
static void C_fcall trf_4602(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4602(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4602(t0,t1,t2);}

C_noret_decl(trf_4495)
static void C_fcall trf_4495(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4495(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4495(t0,t1,t2);}

C_noret_decl(trf_4384)
static void C_fcall trf_4384(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4384(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4384(t0,t1);}

C_noret_decl(trf_4337)
static void C_fcall trf_4337(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4337(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4337(t0,t1,t2);}

C_noret_decl(trf_4288)
static void C_fcall trf_4288(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4288(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4288(t0,t1,t2);}

C_noret_decl(trf_4009)
static void C_fcall trf_4009(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4009(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_4009(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_4179)
static void C_fcall trf_4179(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4179(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4179(t0,t1);}

C_noret_decl(trf_4122)
static void C_fcall trf_4122(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4122(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4122(t0,t1,t2);}

C_noret_decl(trf_4063)
static void C_fcall trf_4063(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4063(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4063(t0,t1,t2);}

C_noret_decl(trf_3964)
static void C_fcall trf_3964(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3964(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3964(t0,t1);}

C_noret_decl(trf_3947)
static void C_fcall trf_3947(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3947(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3947(t0,t1,t2);}

C_noret_decl(trf_3724)
static void C_fcall trf_3724(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3724(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3724(t0,t1,t2,t3);}

C_noret_decl(trf_3911)
static void C_fcall trf_3911(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3911(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3911(t0,t1);}

C_noret_decl(trf_3850)
static void C_fcall trf_3850(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3850(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3850(t0,t1,t2);}

C_noret_decl(trf_3787)
static void C_fcall trf_3787(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3787(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3787(t0,t1,t2);}

C_noret_decl(trf_3601)
static void C_fcall trf_3601(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3601(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3601(t0,t1,t2);}

C_noret_decl(trf_3616)
static void C_fcall trf_3616(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3616(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3616(t0,t1,t2);}

C_noret_decl(trf_3678)
static void C_fcall trf_3678(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3678(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3678(t0,t1,t2);}

C_noret_decl(trf_3508)
static void C_fcall trf_3508(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3508(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3508(t0,t1,t2);}

C_noret_decl(trf_3531)
static void C_fcall trf_3531(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3531(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3531(t0,t1,t2);}

C_noret_decl(trf_3115)
static void C_fcall trf_3115(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3115(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3115(t0,t1);}

C_noret_decl(trf_3118)
static void C_fcall trf_3118(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3118(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3118(t0,t1);}

C_noret_decl(trf_3121)
static void C_fcall trf_3121(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3121(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3121(t0,t1);}

C_noret_decl(trf_3156)
static void C_fcall trf_3156(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3156(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3156(t0,t1,t2);}

C_noret_decl(trf_3167)
static void C_fcall trf_3167(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3167(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3167(t0,t1,t2);}

C_noret_decl(trf_3134)
static void C_fcall trf_3134(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3134(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3134(t0,t1);}

C_noret_decl(trf_3013)
static void C_fcall trf_3013(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3013(void *dummy){
C_word t8=C_pick(0);
C_word t7=C_pick(1);
C_word t6=C_pick(2);
C_word t5=C_pick(3);
C_word t4=C_pick(4);
C_word t3=C_pick(5);
C_word t2=C_pick(6);
C_word t1=C_pick(7);
C_word t0=C_pick(8);
C_adjust_stack(-9);
f_3013(t0,t1,t2,t3,t4,t5,t6,t7,t8);}

C_noret_decl(trf_2983)
static void C_fcall trf_2983(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2983(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2983(t0,t1,t2);}

C_noret_decl(trf_2524)
static void C_fcall trf_2524(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2524(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2524(t0,t1);}

C_noret_decl(trf_2623)
static void C_fcall trf_2623(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2623(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2623(t0,t1,t2,t3);}

C_noret_decl(trf_2592)
static void C_fcall trf_2592(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2592(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2592(t0,t1,t2,t3);}

C_noret_decl(trf_2608)
static void C_fcall trf_2608(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2608(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2608(t0,t1);}

C_noret_decl(trf_2527)
static void C_fcall trf_2527(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2527(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_2527(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_2544)
static void C_fcall trf_2544(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2544(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_2544(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1968)
static void C_fcall trf_1968(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1968(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1968(t0,t1);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr3rv)
static void C_fcall tr3rv(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3rv(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n+1);
t3=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr4rv)
static void C_fcall tr4rv(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4rv(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n+1);
t4=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_srfi_69_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("srfi_69_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(903)){
C_save(t1);
C_rereclaim2(903*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,110);
lf[0]=C_h_intern(&lf[0],20,"\003sysnumber-hash-hook");
lf[2]=C_h_intern(&lf[2],11,"number-hash");
lf[3]=C_h_intern(&lf[3],4,"\077obj");
lf[4]=C_h_intern(&lf[4],15,"\003syssignal-hook");
lf[5]=C_h_intern(&lf[5],5,"\000type");
lf[6]=C_decode_literal(C_heaptop,"\376B\000\000\016invalid number");
lf[7]=C_h_intern(&lf[7],15,"object-uid-hash");
lf[8]=C_h_intern(&lf[8],11,"symbol-hash");
lf[9]=C_h_intern(&lf[9],17,"\003syscheck-keyword");
lf[10]=C_h_intern(&lf[10],11,"\000type-error");
lf[11]=C_decode_literal(C_heaptop,"\376B\000\000!bad argument type - not a keyword");
lf[12]=C_h_intern(&lf[12],8,"keyword\077");
lf[13]=C_h_intern(&lf[13],12,"keyword-hash");
lf[14]=C_h_intern(&lf[14],8,"eq\077-hash");
lf[15]=C_h_intern(&lf[15],16,"hash-by-identity");
lf[16]=C_h_intern(&lf[16],9,"eqv\077-hash");
lf[17]=C_h_intern(&lf[17],11,"input-port\077");
lf[18]=C_h_intern(&lf[18],11,"equal\077-hash");
lf[19]=C_h_intern(&lf[19],4,"hash");
lf[20]=C_h_intern(&lf[20],11,"string-hash");
lf[21]=C_h_intern(&lf[21],14,"string-ci-hash");
lf[23]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\001\000\000\0013\376\003\000\000\002\376\377\001\000\000\002i\376\003\000\000\002\376\377\001\000\000\004\325\376\003\000\000\002\376\377\001\000\000\011\255\376\003\000\000\002\376\377\001\000\000\023]\376\003\000\000\002\376\377\001\000\000&\303\376\003\000\000\002\376\377\001"
"\000\000M\215\376\003\000\000\002\376\377\001\000\000\233\035\376\003\000\000\002\376\377\001\000\0016\077\376\003\000\000\002\376\377\001\000\002l\201\376\003\000\000\002\376\377\001\000\004\331\005\376\003\000\000\002\376\377\001\000\011\262\025\376\003\000\000\002\376\377\001\000\023dA\376\003\000\000"
"\002\376\377\001\000&\310\205\376\003\000\000\002\376\377\001\000M\221\037\376\003\000\000\002\376\377\001\000\233\042I\376\003\000\000\002\376\377\001\0016D\277\376\003\000\000\002\376\377\001\002l\211\207\376\003\000\000\002\376\377\001\004\331\023\027\376\003\000\000\002\376\377\001\011\262&1"
"\376\003\000\000\002\376\377\001\023dLq\376\003\000\000\002\376\377\001&\310\230\373\376\003\000\000\002\376\377\001\077\377\377\377\376\377\016");
lf[25]=C_h_intern(&lf[25],11,"make-vector");
lf[27]=C_h_intern(&lf[27],10,"hash-table");
lf[28]=C_h_intern(&lf[28],3,"eq\077");
lf[29]=C_h_intern(&lf[29],4,"eqv\077");
lf[30]=C_h_intern(&lf[30],6,"equal\077");
lf[31]=C_h_intern(&lf[31],8,"string=\077");
lf[32]=C_h_intern(&lf[32],11,"string-ci=\077");
lf[33]=C_h_intern(&lf[33],1,"=");
lf[34]=C_h_intern(&lf[34],15,"make-hash-table");
lf[35]=C_decode_literal(C_heaptop,"\376U0.5\000");
lf[36]=C_decode_literal(C_heaptop,"\376U0.8\000");
lf[37]=C_h_intern(&lf[37],7,"warning");
lf[38]=C_decode_literal(C_heaptop,"\376B\000\000\033user test without user hash");
lf[39]=C_h_intern(&lf[39],5,"error");
lf[40]=C_decode_literal(C_heaptop,"\376B\000\000\036min-load greater than max-load");
lf[41]=C_h_intern(&lf[41],5,"\000test");
lf[42]=C_h_intern(&lf[42],17,"\003syscheck-closure");
lf[43]=C_h_intern(&lf[43],5,"\000hash");
lf[44]=C_h_intern(&lf[44],5,"\000size");
lf[45]=C_h_intern(&lf[45],19,"hash-table-max-size");
lf[46]=C_decode_literal(C_heaptop,"\376B\000\000\014invalid size");
lf[47]=C_h_intern(&lf[47],8,"\000initial");
lf[48]=C_h_intern(&lf[48],9,"\000min-load");
lf[49]=C_decode_literal(C_heaptop,"\376U0.\000");
lf[50]=C_decode_literal(C_heaptop,"\376U1.\000");
lf[51]=C_decode_literal(C_heaptop,"\376B\000\000\020invalid min-load");
lf[52]=C_h_intern(&lf[52],17,"\003syscheck-inexact");
lf[53]=C_h_intern(&lf[53],9,"\000max-load");
lf[54]=C_decode_literal(C_heaptop,"\376U0.\000");
lf[55]=C_decode_literal(C_heaptop,"\376U1.\000");
lf[56]=C_decode_literal(C_heaptop,"\376B\000\000\020invalid max-load");
lf[57]=C_h_intern(&lf[57],10,"\000weak-keys");
lf[58]=C_h_intern(&lf[58],12,"\000weak-values");
lf[59]=C_decode_literal(C_heaptop,"\376B\000\000\017unknown keyword");
lf[60]=C_decode_literal(C_heaptop,"\376B\000\000\025missing keyword value");
lf[61]=C_decode_literal(C_heaptop,"\376B\000\000\017missing keyword");
lf[62]=C_decode_literal(C_heaptop,"\376B\000\000\014invalid size");
lf[63]=C_h_intern(&lf[63],11,"hash-table\077");
lf[64]=C_h_intern(&lf[64],15,"hash-table-size");
lf[65]=C_h_intern(&lf[65],31,"hash-table-equivalence-function");
lf[66]=C_h_intern(&lf[66],24,"hash-table-hash-function");
lf[67]=C_h_intern(&lf[67],19,"hash-table-min-load");
lf[68]=C_h_intern(&lf[68],19,"hash-table-max-load");
lf[69]=C_h_intern(&lf[69],20,"hash-table-weak-keys");
lf[70]=C_h_intern(&lf[70],22,"hash-table-weak-values");
lf[71]=C_h_intern(&lf[71],23,"hash-table-has-initial\077");
lf[72]=C_h_intern(&lf[72],18,"hash-table-initial");
lf[73]=C_h_intern(&lf[73],18,"hash-table-resize!");
lf[75]=C_h_intern(&lf[75],15,"hash-table-copy");
lf[76]=C_h_intern(&lf[76],18,"hash-table-update!");
lf[77]=C_h_intern(&lf[77],5,"floor");
lf[78]=C_h_intern(&lf[78],13,"\000access-error");
lf[79]=C_decode_literal(C_heaptop,"\376B\000\000\037hash-table does not contain key");
lf[80]=C_h_intern(&lf[80],8,"identity");
lf[82]=C_h_intern(&lf[82],26,"hash-table-update!/default");
lf[83]=C_h_intern(&lf[83],15,"hash-table-set!");
lf[84]=C_h_intern(&lf[84],19,"\003sysundefined-value");
lf[85]=C_h_intern(&lf[85],14,"hash-table-ref");
lf[86]=C_h_intern(&lf[86],22,"hash-table-ref/default");
lf[87]=C_h_intern(&lf[87],18,"hash-table-exists\077");
lf[88]=C_h_intern(&lf[88],18,"hash-table-delete!");
lf[89]=C_h_intern(&lf[89],18,"hash-table-remove!");
lf[90]=C_h_intern(&lf[90],17,"hash-table-clear!");
lf[91]=C_h_intern(&lf[91],12,"vector-fill!");
lf[93]=C_h_intern(&lf[93],17,"hash-table-merge!");
lf[94]=C_h_intern(&lf[94],16,"hash-table-merge");
lf[95]=C_h_intern(&lf[95],17,"hash-table->alist");
lf[96]=C_h_intern(&lf[96],17,"alist->hash-table");
lf[97]=C_h_intern(&lf[97],12,"\003sysfor-each");
lf[98]=C_h_intern(&lf[98],15,"hash-table-keys");
lf[99]=C_h_intern(&lf[99],17,"hash-table-values");
lf[102]=C_h_intern(&lf[102],15,"hash-table-fold");
lf[103]=C_h_intern(&lf[103],19,"hash-table-for-each");
lf[104]=C_h_intern(&lf[104],15,"hash-table-walk");
lf[105]=C_h_intern(&lf[105],14,"hash-table-map");
lf[106]=C_decode_literal(C_heaptop,"\376B\000\000\037hash-table does not contain key");
lf[107]=C_h_intern(&lf[107],18,"getter-with-setter");
lf[108]=C_h_intern(&lf[108],17,"register-feature!");
lf[109]=C_h_intern(&lf[109],7,"srfi-69");
C_register_lf2(lf,110,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1947,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* srfi-69.scm: 66   register-feature! */
t3=*((C_word*)lf[108]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[109]);}

/* k1945 */
static void C_ccall f_1947(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word ab[81],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1947,2,t0,t1);}
t2=C_mutate((C_word*)lf[0]+1 /* (set! number-hash-hook ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1949,tmp=(C_word)a,a+=2,tmp));
t3=C_mutate((C_word*)lf[2]+1 /* (set! number-hash ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1955,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate((C_word*)lf[7]+1 /* (set! object-uid-hash ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2084,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[8]+1 /* (set! symbol-hash ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2125,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[9]+1 /* (set! check-keyword ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2169,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate((C_word*)lf[13]+1 /* (set! keyword-hash ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2195,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate((C_word*)lf[14]+1 /* (set! eq?-hash ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2299,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate((C_word*)lf[15]+1 /* (set! hash-by-identity ...) */,*((C_word*)lf[14]+1));
t10=C_mutate((C_word*)lf[16]+1 /* (set! eqv?-hash ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2483,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate(&lf[1] /* (set! *equal?-hash ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2524,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate((C_word*)lf[18]+1 /* (set! equal?-hash ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2858,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate((C_word*)lf[19]+1 /* (set! hash ...) */,*((C_word*)lf[18]+1));
t14=C_mutate((C_word*)lf[20]+1 /* (set! string-hash ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2900,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate((C_word*)lf[21]+1 /* (set! string-ci-hash ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2941,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate(&lf[22] /* (set! constant801 ...) */,lf[23]);
t17=C_mutate(&lf[24] /* (set! hash-table-canonical-length ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2983,tmp=(C_word)a,a+=2,tmp));
t18=*((C_word*)lf[25]+1);
t19=C_mutate(&lf[26] /* (set! *make-hash-table ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3013,a[2]=t18,tmp=(C_word)a,a+=3,tmp));
t20=*((C_word*)lf[28]+1);
t21=*((C_word*)lf[29]+1);
t22=*((C_word*)lf[30]+1);
t23=*((C_word*)lf[31]+1);
t24=*((C_word*)lf[32]+1);
t25=*((C_word*)lf[33]+1);
t26=C_mutate((C_word*)lf[34]+1 /* (set! make-hash-table ...) */,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3037,a[2]=t25,a[3]=t24,a[4]=t23,a[5]=t22,a[6]=t21,a[7]=t20,tmp=(C_word)a,a+=8,tmp));
t27=C_mutate((C_word*)lf[63]+1 /* (set! hash-table? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3400,tmp=(C_word)a,a+=2,tmp));
t28=C_mutate((C_word*)lf[64]+1 /* (set! hash-table-size ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3406,tmp=(C_word)a,a+=2,tmp));
t29=C_mutate((C_word*)lf[65]+1 /* (set! hash-table-equivalence-function ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3415,tmp=(C_word)a,a+=2,tmp));
t30=C_mutate((C_word*)lf[66]+1 /* (set! hash-table-hash-function ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3424,tmp=(C_word)a,a+=2,tmp));
t31=C_mutate((C_word*)lf[67]+1 /* (set! hash-table-min-load ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3433,tmp=(C_word)a,a+=2,tmp));
t32=C_mutate((C_word*)lf[68]+1 /* (set! hash-table-max-load ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3442,tmp=(C_word)a,a+=2,tmp));
t33=C_mutate((C_word*)lf[69]+1 /* (set! hash-table-weak-keys ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3451,tmp=(C_word)a,a+=2,tmp));
t34=C_mutate((C_word*)lf[70]+1 /* (set! hash-table-weak-values ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3460,tmp=(C_word)a,a+=2,tmp));
t35=C_mutate((C_word*)lf[71]+1 /* (set! hash-table-has-initial? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3469,tmp=(C_word)a,a+=2,tmp));
t36=C_mutate((C_word*)lf[72]+1 /* (set! hash-table-initial ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3481,tmp=(C_word)a,a+=2,tmp));
t37=C_mutate((C_word*)lf[73]+1 /* (set! hash-table-resize! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3575,tmp=(C_word)a,a+=2,tmp));
t38=*((C_word*)lf[25]+1);
t39=C_mutate(&lf[74] /* (set! *hash-table-copy ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3601,a[2]=t38,tmp=(C_word)a,a+=3,tmp));
t40=C_mutate((C_word*)lf[75]+1 /* (set! hash-table-copy ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3713,tmp=(C_word)a,a+=2,tmp));
t41=*((C_word*)lf[28]+1);
t42=C_mutate((C_word*)lf[76]+1 /* (set! hash-table-update! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3722,a[2]=t41,tmp=(C_word)a,a+=3,tmp));
t43=*((C_word*)lf[28]+1);
t44=C_mutate(&lf[81] /* (set! *hash-table-update!/default ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4009,a[2]=t43,tmp=(C_word)a,a+=3,tmp));
t45=C_mutate((C_word*)lf[82]+1 /* (set! hash-table-update!/default ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4216,tmp=(C_word)a,a+=2,tmp));
t46=*((C_word*)lf[28]+1);
t47=C_mutate((C_word*)lf[83]+1 /* (set! hash-table-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4228,a[2]=t46,tmp=(C_word)a,a+=3,tmp));
t48=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4423,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t49=*((C_word*)lf[28]+1);
t50=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5380,a[2]=t49,tmp=(C_word)a,a+=3,tmp);
/* srfi-69.scm: 793  getter-with-setter */
t51=*((C_word*)lf[107]+1);
((C_proc4)(void*)(*((C_word*)t51+1)))(4,t51,t48,t50,*((C_word*)lf[83]+1));}

/* a5379 in k1945 */
static void C_ccall f_5380(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+11)){
C_save_and_reclaim((void*)tr4rv,(void*)f_5380r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_5380r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5380r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a=C_alloc(11);
t5=(C_word)C_vemptyp(t4);
t6=(C_truep(t5)?(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5500,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp):(C_word)C_slot(t4,C_fix(0)));
t7=(C_word)C_i_check_structure_2(t2,lf[27],lf[85]);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5390,a[2]=t1,a[3]=t3,a[4]=t6,a[5]=((C_word*)t0)[2],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* srfi-69.scm: 800  ##sys#check-closure */
t9=*((C_word*)lf[42]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t8,t6,lf[85]);}

/* k5388 in a5379 in k1945 */
static void C_ccall f_5390(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5390,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t3=(C_word)C_slot(((C_word*)t0)[6],C_fix(3));
t4=(C_word)C_slot(((C_word*)t0)[6],C_fix(4));
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5402,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=t3,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t6=(C_word)C_block_size(t2);
/* srfi-69.scm: 804  hash */
t7=t4;
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,((C_word*)t0)[3],t6);}

/* k5400 in k5388 in a5379 in k1945 */
static void C_ccall f_5402(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5402,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[7],((C_word*)t0)[6]);
if(C_truep(t2)){
t3=(C_word)C_slot(((C_word*)t0)[5],t1);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5417,a[2]=t5,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_5417(t7,((C_word*)t0)[2],t3);}
else{
t3=(C_word)C_slot(((C_word*)t0)[5],t1);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5459,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[6],a[4]=t5,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_5459(t7,((C_word*)t0)[2],t3);}}

/* loop in k5400 in k5388 in a5379 in k1945 */
static void C_fcall f_5459(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5459,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
/* srfi-69.scm: 817  def */
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5478,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_slot(t3,C_fix(0));
/* srfi-69.scm: 819  test */
t6=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,((C_word*)t0)[2],t5);}}

/* k5476 in loop in k5400 in k5388 in a5379 in k1945 */
static void C_ccall f_5478(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_slot(((C_word*)t0)[4],C_fix(1)));}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* srfi-69.scm: 821  loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_5459(t3,((C_word*)t0)[5],t2);}}

/* loop in k5400 in k5388 in a5379 in k1945 */
static void C_fcall f_5417(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
loop:
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5417,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
/* srfi-69.scm: 809  def */
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t3,C_fix(0));
t5=(C_word)C_eqp(((C_word*)t0)[3],t4);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_slot(t3,C_fix(1)));}
else{
t6=(C_word)C_slot(t2,C_fix(1));
/* srfi-69.scm: 813  loop */
t8=t1;
t9=t6;
t1=t8;
t2=t9;
goto loop;}}}

/* f_5500 in a5379 in k1945 */
static void C_ccall f_5500(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5500,2,t0,t1);}
/* srfi-69.scm: 796  ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,t1,lf[78],lf[85],lf[106],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4421 in k1945 */
static void C_ccall f_4423(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word ab[40],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4423,2,t0,t1);}
t2=C_mutate((C_word*)lf[85]+1 /* (set! hash-table-ref ...) */,t1);
t3=*((C_word*)lf[28]+1);
t4=C_mutate((C_word*)lf[86]+1 /* (set! hash-table-ref/default ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4425,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=*((C_word*)lf[28]+1);
t6=C_mutate((C_word*)lf[87]+1 /* (set! hash-table-exists? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4531,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=*((C_word*)lf[28]+1);
t8=C_mutate((C_word*)lf[88]+1 /* (set! hash-table-delete! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4639,a[2]=t7,tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[89]+1 /* (set! hash-table-remove! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4770,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate((C_word*)lf[90]+1 /* (set! hash-table-clear! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4866,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate(&lf[92] /* (set! *hash-table-merge! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4882,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate((C_word*)lf[93]+1 /* (set! hash-table-merge! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4947,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate((C_word*)lf[94]+1 /* (set! hash-table-merge ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4959,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate((C_word*)lf[95]+1 /* (set! hash-table->alist ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4975,tmp=(C_word)a,a+=2,tmp));
t15=*((C_word*)lf[34]+1);
t16=C_mutate((C_word*)lf[96]+1 /* (set! alist->hash-table ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5048,a[2]=t15,tmp=(C_word)a,a+=3,tmp));
t17=C_mutate((C_word*)lf[98]+1 /* (set! hash-table-keys ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5077,tmp=(C_word)a,a+=2,tmp));
t18=C_mutate((C_word*)lf[99]+1 /* (set! hash-table-values ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5142,tmp=(C_word)a,a+=2,tmp));
t19=C_mutate(&lf[100] /* (set! *hash-table-for-each ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5207,tmp=(C_word)a,a+=2,tmp));
t20=C_mutate(&lf[101] /* (set! *hash-table-fold ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5256,tmp=(C_word)a,a+=2,tmp));
t21=C_mutate((C_word*)lf[102]+1 /* (set! hash-table-fold ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5322,tmp=(C_word)a,a+=2,tmp));
t22=C_mutate((C_word*)lf[103]+1 /* (set! hash-table-for-each ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5334,tmp=(C_word)a,a+=2,tmp));
t23=C_mutate((C_word*)lf[104]+1 /* (set! hash-table-walk ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5346,tmp=(C_word)a,a+=2,tmp));
t24=C_mutate((C_word*)lf[105]+1 /* (set! hash-table-map ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5358,tmp=(C_word)a,a+=2,tmp));
t25=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t25+1)))(2,t25,C_SCHEME_UNDEFINED);}

/* hash-table-map in k4421 in k1945 */
static void C_ccall f_5358(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5358,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure_2(t2,lf[27],lf[105]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5365,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm: 1073 ##sys#check-closure */
t6=*((C_word*)lf[42]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t3,lf[105]);}

/* k5363 in hash-table-map in k4421 in k1945 */
static void C_ccall f_5365(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5365,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5370,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* srfi-69.scm: 1074 *hash-table-fold */
f_5256(((C_word*)t0)[3],((C_word*)t0)[2],t2,C_SCHEME_END_OF_LIST);}

/* a5369 in k5363 in hash-table-map in k4421 in k1945 */
static void C_ccall f_5370(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5370,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5378,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-69.scm: 1074 func */
t6=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t2,t3);}

/* k5376 in a5369 in k5363 in hash-table-map in k4421 in k1945 */
static void C_ccall f_5378(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5378,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[2]));}

/* hash-table-walk in k4421 in k1945 */
static void C_ccall f_5346(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5346,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure_2(t2,lf[27],lf[104]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5353,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm: 1068 ##sys#check-closure */
t6=*((C_word*)lf[42]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t3,lf[104]);}

/* k5351 in hash-table-walk in k4421 in k1945 */
static void C_ccall f_5353(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-69.scm: 1069 *hash-table-for-each */
f_5207(((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* hash-table-for-each in k4421 in k1945 */
static void C_ccall f_5334(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5334,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure_2(t2,lf[27],lf[103]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5341,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm: 1063 ##sys#check-closure */
t6=*((C_word*)lf[42]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t3,lf[103]);}

/* k5339 in hash-table-for-each in k4421 in k1945 */
static void C_ccall f_5341(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-69.scm: 1064 *hash-table-for-each */
f_5207(((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* hash-table-fold in k4421 in k1945 */
static void C_ccall f_5322(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5322,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_check_structure_2(t2,lf[27],lf[102]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5329,a[2]=t4,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* srfi-69.scm: 1058 ##sys#check-closure */
t7=*((C_word*)lf[42]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,t3,lf[102]);}

/* k5327 in hash-table-fold in k4421 in k1945 */
static void C_ccall f_5329(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-69.scm: 1059 *hash-table-fold */
f_5256(((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* *hash-table-fold in k4421 in k1945 */
static void C_fcall f_5256(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5256,NULL,4,t1,t2,t3,t4);}
t5=(C_word)C_slot(t2,C_fix(1));
t6=(C_word)C_block_size(t5);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5268,a[2]=t3,a[3]=t8,a[4]=t5,a[5]=t6,tmp=(C_word)a,a+=6,tmp));
t10=((C_word*)t8)[1];
f_5268(t10,t1,C_fix(0),t4);}

/* loop in *hash-table-fold in k4421 in k1945 */
static void C_fcall f_5268(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5268,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_slot(((C_word*)t0)[4],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5284,a[2]=((C_word*)t0)[2],a[3]=t6,a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_5284(t8,t1,t4,t3);}}

/* fold2 in loop in *hash-table-fold in k4421 in k1945 */
static void C_fcall f_5284(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5284,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(C_word)C_u_fixnum_plus(((C_word*)t0)[5],C_fix(1));
/* srfi-69.scm: 1051 loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_5268(t5,t1,t4,t3);}
else{
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_slot(t2,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5312,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_slot(t4,C_fix(0));
t8=(C_word)C_slot(t4,C_fix(1));
/* srfi-69.scm: 1054 func */
t9=((C_word*)t0)[2];
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,t6,t7,t8,t3);}}

/* k5310 in fold2 in loop in *hash-table-fold in k4421 in k1945 */
static void C_ccall f_5312(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-69.scm: 1053 fold2 */
t2=((C_word*)((C_word*)t0)[4])[1];
f_5284(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* *hash-table-for-each in k4421 in k1945 */
static void C_fcall f_5207(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5207,NULL,3,t1,t2,t3);}
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_block_size(t4);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5219,a[2]=t4,a[3]=t3,a[4]=t7,a[5]=t5,tmp=(C_word)a,a+=6,tmp));
t9=((C_word*)t7)[1];
f_5219(t9,t1,C_fix(0));}

/* doloop1806 in *hash-table-for-each in k4421 in k1945 */
static void C_fcall f_5219(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5219,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5229,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5238,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_slot(((C_word*)t0)[2],t2);
/* srfi-69.scm: 1038 ##sys#for-each */
t6=*((C_word*)lf[97]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}}

/* a5237 in doloop1806 in *hash-table-for-each in k4421 in k1945 */
static void C_ccall f_5238(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5238,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t2,C_fix(1));
/* srfi-69.scm: 1039 proc */
t5=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t3,t4);}

/* k5227 in doloop1806 in *hash-table-for-each in k4421 in k1945 */
static void C_ccall f_5229(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_5219(t3,((C_word*)t0)[2],t2);}

/* hash-table-values in k4421 in k1945 */
static void C_ccall f_5142(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5142,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[27],lf[99]);
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_block_size(t4);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5157,a[2]=t7,a[3]=t4,a[4]=t5,tmp=(C_word)a,a+=5,tmp));
t9=((C_word*)t7)[1];
f_5157(t9,t1,C_fix(0),C_SCHEME_END_OF_LIST);}

/* loop in hash-table-values in k4421 in k1945 */
static void C_fcall f_5157(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5157,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[4]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_slot(((C_word*)t0)[3],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5173,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_5173(t8,t1,t4,t3);}}

/* loop2 in loop in hash-table-values in k4421 in k1945 */
static void C_fcall f_5173(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(3);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5173,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* srfi-69.scm: 1021 loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_5157(t5,t1,t4,t3);}
else{
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_slot(t2,C_fix(0));
t6=(C_word)C_slot(t5,C_fix(1));
t7=(C_word)C_a_i_cons(&a,2,t6,t3);
/* srfi-69.scm: 1022 loop2 */
t10=t1;
t11=t4;
t12=t7;
t1=t10;
t2=t11;
t3=t12;
goto loop;}}

/* hash-table-keys in k4421 in k1945 */
static void C_ccall f_5077(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5077,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[27],lf[98]);
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_block_size(t4);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5092,a[2]=t7,a[3]=t4,a[4]=t5,tmp=(C_word)a,a+=5,tmp));
t9=((C_word*)t7)[1];
f_5092(t9,t1,C_fix(0),C_SCHEME_END_OF_LIST);}

/* loop in hash-table-keys in k4421 in k1945 */
static void C_fcall f_5092(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5092,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[4]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_slot(((C_word*)t0)[3],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5108,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_5108(t8,t1,t4,t3);}}

/* loop2 in loop in hash-table-keys in k4421 in k1945 */
static void C_fcall f_5108(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(3);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5108,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* srfi-69.scm: 1006 loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_5092(t5,t1,t4,t3);}
else{
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_slot(t2,C_fix(0));
t6=(C_word)C_slot(t5,C_fix(0));
t7=(C_word)C_a_i_cons(&a,2,t6,t3);
/* srfi-69.scm: 1007 loop2 */
t10=t1;
t11=t4;
t12=t7;
t1=t10;
t2=t11;
t3=t12;
goto loop;}}

/* alist->hash-table in k4421 in k1945 */
static void C_ccall f_5048(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_5048r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5048r(t0,t1,t2,t3);}}

static void C_ccall f_5048r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(C_word)C_i_check_list_2(t2,lf[96]);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5055,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_apply(4,0,t5,((C_word*)t0)[2],t3);}

/* k5053 in alist->hash-table in k4421 in k1945 */
static void C_ccall f_5055(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5055,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5058,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5060,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* for-each */
t4=*((C_word*)lf[97]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a5059 in k5053 in alist->hash-table in k4421 in k1945 */
static void C_ccall f_5060(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5060,3,t0,t1,t2);}
t3=(C_word)C_i_check_pair_2(t2,lf[96]);
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_slot(t2,C_fix(1));
/* srfi-69.scm: 990  *hash-table-update!/default */
t6=lf[81];
f_4009(t6,t1,((C_word*)t0)[2],t4,*((C_word*)lf[80]+1),t5);}

/* k5056 in k5053 in alist->hash-table in k4421 in k1945 */
static void C_ccall f_5058(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* hash-table->alist in k4421 in k1945 */
static void C_ccall f_4975(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4975,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[27],lf[95]);
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_block_size(t4);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4990,a[2]=t7,a[3]=t4,a[4]=t5,tmp=(C_word)a,a+=5,tmp));
t9=((C_word*)t7)[1];
f_4990(t9,t1,C_fix(0),C_SCHEME_END_OF_LIST);}

/* loop in hash-table->alist in k4421 in k1945 */
static void C_fcall f_4990(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4990,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[4]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_slot(((C_word*)t0)[3],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5006,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_5006(t8,t1,t4,t3);}}

/* loop2 in loop in hash-table->alist in k4421 in k1945 */
static void C_fcall f_5006(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
loop:
a=C_alloc(6);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5006,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* srfi-69.scm: 977  loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_4990(t5,t1,t4,t3);}
else{
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_slot(t2,C_fix(0));
t6=(C_word)C_slot(t5,C_fix(0));
t7=(C_word)C_slot(t5,C_fix(1));
t8=(C_word)C_a_i_cons(&a,2,t6,t7);
t9=(C_word)C_a_i_cons(&a,2,t8,t3);
/* srfi-69.scm: 978  loop2 */
t12=t1;
t13=t4;
t14=t9;
t1=t12;
t2=t13;
t3=t14;
goto loop;}}

/* hash-table-merge in k4421 in k1945 */
static void C_ccall f_4959(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4959,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure_2(t2,lf[27],lf[94]);
t5=(C_word)C_i_check_structure_2(t3,lf[27],lf[94]);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4973,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-69.scm: 963  *hash-table-copy */
t7=lf[74];
f_3601(t7,t6,t2);}

/* k4971 in hash-table-merge in k4421 in k1945 */
static void C_ccall f_4973(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-69.scm: 963  *hash-table-merge! */
f_4882(((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* hash-table-merge! in k4421 in k1945 */
static void C_ccall f_4947(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4947,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure_2(t2,lf[27],lf[93]);
t5=(C_word)C_i_check_structure_2(t3,lf[27],lf[93]);
/* srfi-69.scm: 958  *hash-table-merge! */
f_4882(t1,t2,t3);}

/* *hash-table-merge! in k4421 in k1945 */
static void C_fcall f_4882(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4882,NULL,3,t1,t2,t3);}
t4=(C_word)C_slot(t3,C_fix(1));
t5=(C_word)C_block_size(t4);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4894,a[2]=t4,a[3]=t7,a[4]=t2,a[5]=t5,tmp=(C_word)a,a+=6,tmp));
t9=((C_word*)t7)[1];
f_4894(t9,t1,C_fix(0));}

/* doloop1661 in *hash-table-merge! in k4421 in k1945 */
static void C_fcall f_4894(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4894,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[4]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4904,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(((C_word*)t0)[2],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4917,a[2]=((C_word*)t0)[4],a[3]=t6,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_4917(t8,t3,t4);}}

/* doloop1670 in doloop1661 in *hash-table-merge! in k4421 in k1945 */
static void C_fcall f_4917(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4917,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4930,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_slot(t3,C_fix(0));
t6=(C_word)C_slot(t3,C_fix(1));
/* srfi-69.scm: 953  *hash-table-update!/default */
t7=lf[81];
f_4009(t7,t4,((C_word*)t0)[2],t5,*((C_word*)lf[80]+1),t6);}}

/* k4928 in doloop1670 in doloop1661 in *hash-table-merge! in k4421 in k1945 */
static void C_ccall f_4930(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4917(t3,((C_word*)t0)[2],t2);}

/* k4902 in doloop1661 in *hash-table-merge! in k4421 in k1945 */
static void C_ccall f_4904(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4894(t3,((C_word*)t0)[2],t2);}

/* hash-table-clear! in k4421 in k1945 */
static void C_ccall f_4866(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4866,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[27],lf[90]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4873,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_slot(t2,C_fix(1));
/* srfi-69.scm: 940  vector-fill! */
t6=*((C_word*)lf[91]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,C_SCHEME_END_OF_LIST);}

/* k4871 in hash-table-clear! in k4421 in k1945 */
static void C_ccall f_4873(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_set_i_slot(((C_word*)t0)[2],C_fix(2),C_fix(0)));}

/* hash-table-remove! in k4421 in k1945 */
static void C_ccall f_4770(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4770,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure_2(t2,lf[27],lf[89]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4777,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm: 917  ##sys#check-closure */
t6=*((C_word*)lf[42]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t3,lf[89]);}

/* k4775 in hash-table-remove! in k4421 in k1945 */
static void C_ccall f_4777(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4777,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=(C_word)C_block_size(t2);
t4=(C_word)C_slot(((C_word*)t0)[4],C_fix(2));
t5=t4;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4791,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t8,a[5]=t6,a[6]=((C_word*)t0)[4],a[7]=t3,tmp=(C_word)a,a+=8,tmp));
t10=((C_word*)t8)[1];
f_4791(t10,((C_word*)t0)[2],C_fix(0));}

/* doloop1616 in k4775 in hash-table-remove! in k4421 in k1945 */
static void C_fcall f_4791(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4791,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[7]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_set_i_slot(((C_word*)t0)[6],C_fix(2),((C_word*)((C_word*)t0)[5])[1]));}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4804,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(((C_word*)t0)[3],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4817,a[2]=((C_word*)t0)[2],a[3]=t6,a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp));
t8=((C_word*)t6)[1];
f_4817(t8,t3,C_SCHEME_FALSE,t4);}}

/* loop in doloop1616 in k4775 in hash-table-remove! in k4421 in k1945 */
static void C_fcall f_4817(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4817,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(C_word)C_slot(t3,C_fix(0));
t5=(C_word)C_slot(t3,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4836,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t5,a[9]=t2,tmp=(C_word)a,a+=10,tmp);
t7=(C_word)C_slot(t4,C_fix(0));
t8=(C_word)C_slot(t4,C_fix(1));
/* srfi-69.scm: 927  func */
t9=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t6,t7,t8);}}

/* k4834 in loop in doloop1616 in k4775 in hash-table-remove! in k4421 in k1945 */
static void C_ccall f_4836(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_truep(t1)){
t2=(C_truep(((C_word*)t0)[9])?(C_word)C_i_setslot(((C_word*)t0)[9],C_fix(1),((C_word*)t0)[8]):(C_word)C_i_setslot(((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[8]));
t3=(C_word)C_u_fixnum_difference(((C_word*)((C_word*)t0)[5])[1],C_fix(1));
t4=C_mutate(((C_word *)((C_word*)t0)[5])+1,t3);
t5=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_TRUE);}
else{
/* srfi-69.scm: 934  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_4817(t2,((C_word*)t0)[4],((C_word*)t0)[2],((C_word*)t0)[8]);}}

/* k4802 in doloop1616 in k4775 in hash-table-remove! in k4421 in k1945 */
static void C_ccall f_4804(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4791(t3,((C_word*)t0)[2],t2);}

/* hash-table-delete! in k4421 in k1945 */
static void C_ccall f_4639(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4639,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure_2(t2,lf[27],lf[88]);
t5=(C_word)C_slot(t2,C_fix(1));
t6=(C_word)C_block_size(t5);
t7=(C_word)C_slot(t2,C_fix(4));
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4655,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t5,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* srfi-69.scm: 881  hash */
t9=t7;
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t8,t3,t6);}

/* k4653 in hash-table-delete! in k4421 in k1945 */
static void C_ccall f_4655(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4655,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(3));
t3=(C_word)C_slot(((C_word*)t0)[6],C_fix(2));
t4=(C_word)C_u_fixnum_difference(t3,C_fix(1));
t5=(C_word)C_slot(((C_word*)t0)[5],t1);
t6=(C_word)C_eqp(((C_word*)t0)[4],t2);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4675,a[2]=t4,a[3]=((C_word*)t0)[6],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
t8=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,f_4675(t7,C_SCHEME_FALSE,t5));}
else{
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4722,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t8,a[5]=t4,a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp));
t10=((C_word*)t8)[1];
f_4722(t10,((C_word*)t0)[2],C_SCHEME_FALSE,t5);}}

/* loop in k4653 in hash-table-delete! in k4421 in k1945 */
static void C_fcall f_4722(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4722,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(C_word)C_slot(t3,C_fix(0));
t5=(C_word)C_slot(t3,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4741,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t5,a[10]=t2,tmp=(C_word)a,a+=11,tmp);
t7=(C_word)C_slot(t4,C_fix(0));
/* srfi-69.scm: 904  test */
t8=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,((C_word*)t0)[2],t7);}}

/* k4739 in loop in k4653 in hash-table-delete! in k4421 in k1945 */
static void C_ccall f_4741(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_truep(((C_word*)t0)[10])?(C_word)C_i_setslot(((C_word*)t0)[10],C_fix(1),((C_word*)t0)[9]):(C_word)C_i_setslot(((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[9]));
t3=(C_word)C_i_set_i_slot(((C_word*)t0)[6],C_fix(2),((C_word*)t0)[5]);
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_TRUE);}
else{
/* srfi-69.scm: 911  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_4722(t2,((C_word*)t0)[4],((C_word*)t0)[2],((C_word*)t0)[9]);}}

/* loop in k4653 in hash-table-delete! in k4421 in k1945 */
static C_word C_fcall f_4675(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
loop:
if(C_truep((C_word)C_i_nullp(t2))){
return(C_SCHEME_FALSE);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_slot(t3,C_fix(0));
t6=(C_word)C_eqp(((C_word*)t0)[6],t5);
if(C_truep(t6)){
t7=(C_truep(t1)?(C_word)C_i_setslot(t1,C_fix(1),t4):(C_word)C_i_setslot(((C_word*)t0)[5],((C_word*)t0)[4],t4));
t8=(C_word)C_i_set_i_slot(((C_word*)t0)[3],C_fix(2),((C_word*)t0)[2]);
return(C_SCHEME_TRUE);}
else{
t10=t2;
t11=t4;
t1=t10;
t2=t11;
goto loop;}}}

/* hash-table-exists? in k4421 in k1945 */
static void C_ccall f_4531(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4531,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure_2(t2,lf[27],lf[87]);
t5=(C_word)C_slot(t2,C_fix(1));
t6=(C_word)C_slot(t2,C_fix(3));
t7=(C_word)C_slot(t2,C_fix(4));
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4547,a[2]=t1,a[3]=t3,a[4]=t5,a[5]=t6,a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
t9=(C_word)C_block_size(t5);
/* srfi-69.scm: 857  hash */
t10=t7;
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t8,t3,t9);}

/* k4545 in hash-table-exists? in k4421 in k1945 */
static void C_ccall f_4547(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4547,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[6],((C_word*)t0)[5]);
if(C_truep(t2)){
t3=(C_word)C_slot(((C_word*)t0)[4],t1);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4562,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,f_4562(t4,t3));}
else{
t3=(C_word)C_slot(((C_word*)t0)[4],t1);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4602,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=t5,tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_4602(t7,((C_word*)t0)[2],t3);}}

/* loop in k4545 in hash-table-exists? in k4421 in k1945 */
static void C_fcall f_4602(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4602,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4615,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_slot(t3,C_fix(0));
/* srfi-69.scm: 869  test */
t6=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,((C_word*)t0)[2],t5);}}

/* k4613 in loop in k4545 in hash-table-exists? in k4421 in k1945 */
static void C_ccall f_4615(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* srfi-69.scm: 870  loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_4602(t3,((C_word*)t0)[4],t2);}}

/* loop in k4545 in hash-table-exists? in k4421 in k1945 */
static C_word C_fcall f_4562(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
loop:
if(C_truep((C_word)C_i_nullp(t1))){
return(C_SCHEME_FALSE);}
else{
t2=(C_word)C_slot(t1,C_fix(0));
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_eqp(((C_word*)t0)[2],t3);
if(C_truep(t4)){
return(t4);}
else{
t5=(C_word)C_slot(t1,C_fix(1));
t7=t5;
t1=t7;
goto loop;}}}

/* hash-table-ref/default in k4421 in k1945 */
static void C_ccall f_4425(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4425,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_check_structure_2(t2,lf[27],lf[86]);
t6=(C_word)C_slot(t2,C_fix(1));
t7=(C_word)C_slot(t2,C_fix(3));
t8=(C_word)C_slot(t2,C_fix(4));
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4441,a[2]=t1,a[3]=t3,a[4]=t4,a[5]=t6,a[6]=t7,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
t10=(C_word)C_block_size(t6);
/* srfi-69.scm: 831  hash */
t11=t8;
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t9,t3,t10);}

/* k4439 in hash-table-ref/default in k4421 in k1945 */
static void C_ccall f_4441(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4441,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[7],((C_word*)t0)[6]);
if(C_truep(t2)){
t3=(C_word)C_slot(((C_word*)t0)[5],t1);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4456,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,f_4456(t4,t3));}
else{
t3=(C_word)C_slot(((C_word*)t0)[5],t1);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4495,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[6],a[4]=t5,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_4495(t7,((C_word*)t0)[2],t3);}}

/* loop in k4439 in hash-table-ref/default in k4421 in k1945 */
static void C_fcall f_4495(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4495,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[5]);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4511,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_slot(t3,C_fix(0));
/* srfi-69.scm: 846  test */
t6=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,((C_word*)t0)[2],t5);}}

/* k4509 in loop in k4439 in hash-table-ref/default in k4421 in k1945 */
static void C_ccall f_4511(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_slot(((C_word*)t0)[4],C_fix(1)));}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* srfi-69.scm: 848  loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_4495(t3,((C_word*)t0)[5],t2);}}

/* loop in k4439 in hash-table-ref/default in k4421 in k1945 */
static C_word C_fcall f_4456(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
loop:
if(C_truep((C_word)C_i_nullp(t1))){
return(((C_word*)t0)[3]);}
else{
t2=(C_word)C_slot(t1,C_fix(0));
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_eqp(((C_word*)t0)[2],t3);
if(C_truep(t4)){
return((C_word)C_slot(t2,C_fix(1)));}
else{
t5=(C_word)C_slot(t1,C_fix(1));
t7=t5;
t1=t7;
goto loop;}}}

/* hash-table-set! in k1945 */
static void C_ccall f_4228(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4228,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_check_structure_2(t2,lf[27],lf[83]);
t6=(C_word)C_slot(t2,C_fix(2));
t7=(C_word)C_u_fixnum_plus(t6,C_fix(1));
t8=t2;
t9=(C_word)C_slot(t8,C_fix(1));
t10=(C_word)C_slot(t8,C_fix(5));
t11=(C_word)C_slot(t8,C_fix(6));
t12=(C_word)C_block_size(t9);
t13=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4411,a[2]=t11,a[3]=t12,a[4]=t9,a[5]=t8,a[6]=t7,a[7]=t4,a[8]=t3,a[9]=((C_word*)t0)[2],a[10]=t1,a[11]=t2,tmp=(C_word)a,a+=12,tmp);
t14=(C_word)C_a_i_times(&a,2,t12,t10);
/* srfi-69.scm: 621  floor */
t15=*((C_word*)lf[77]+1);
((C_proc3)(void*)(*((C_word*)t15+1)))(3,t15,t13,t14);}

/* k4409 in hash-table-set! in k1945 */
static void C_ccall f_4411(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4411,2,t0,t1);}
t2=(C_word)C_i_inexact_to_exact(t1);
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4403,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
t4=(C_word)C_a_i_times(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]);
/* srfi-69.scm: 622  floor */
t5=*((C_word*)lf[77]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k4401 in k4409 in hash-table-set! in k1945 */
static void C_ccall f_4403(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4403,2,t0,t1);}
t2=(C_word)C_i_inexact_to_exact(t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4256,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4384,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_lessp(((C_word*)t0)[3],C_fix(1073741823)))){
t5=(C_word)C_fixnum_less_or_equal_p(((C_word*)t0)[2],((C_word*)t0)[6]);
t6=t4;
f_4384(t6,(C_truep(t5)?(C_word)C_fixnum_less_or_equal_p(((C_word*)t0)[6],t2):C_SCHEME_FALSE));}
else{
t5=t4;
f_4384(t5,C_SCHEME_FALSE);}}

/* k4382 in k4401 in k4409 in hash-table-set! in k1945 */
static void C_fcall f_4384(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* srfi-69.scm: 625  hash-table-resize! */
t2=*((C_word*)lf[73]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
f_4256(2,t2,C_SCHEME_UNDEFINED);}}

/* k4254 in k4401 in k4409 in hash-table-set! in k1945 */
static void C_ccall f_4256(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4256,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[7],C_fix(4));
t3=(C_word)C_slot(((C_word*)t0)[7],C_fix(3));
t4=(C_word)C_slot(((C_word*)t0)[7],C_fix(1));
t5=(C_word)C_block_size(t4);
t6=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4271,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t3,a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=t4,tmp=(C_word)a,a+=10,tmp);
/* srfi-69.scm: 765  hash */
t7=t2;
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,((C_word*)t0)[4],t5);}

/* k4269 in k4254 in k4401 in k4409 in hash-table-set! in k1945 */
static void C_ccall f_4271(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4271,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[9],t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4277,a[2]=((C_word*)t0)[8],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_eqp(((C_word*)t0)[7],((C_word*)t0)[6]);
if(C_truep(t4)){
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4288,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[9],a[7]=t2,a[8]=((C_word*)t0)[4],a[9]=((C_word*)t0)[5],tmp=(C_word)a,a+=10,tmp));
t8=((C_word*)t6)[1];
f_4288(t8,t3,t2);}
else{
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4337,a[2]=((C_word*)t0)[6],a[3]=t6,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=t1,a[7]=((C_word*)t0)[9],a[8]=t2,a[9]=((C_word*)t0)[4],a[10]=((C_word*)t0)[5],tmp=(C_word)a,a+=11,tmp));
t8=((C_word*)t6)[1];
f_4337(t8,t3,t2);}}

/* loop in k4269 in k4254 in k4401 in k4409 in hash-table-set! in k1945 */
static void C_fcall f_4337(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4337,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],((C_word*)t0)[9]);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[8]);
t5=(C_word)C_i_setslot(((C_word*)t0)[7],((C_word*)t0)[6],t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_i_set_i_slot(((C_word*)t0)[5],C_fix(2),((C_word*)t0)[4]));}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4367,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[9],a[5]=t3,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_slot(t3,C_fix(0));
/* srfi-69.scm: 785  test */
t6=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,((C_word*)t0)[10],t5);}}

/* k4365 in loop in k4269 in k4254 in k4401 in k4409 in hash-table-set! in k1945 */
static void C_ccall f_4367(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_setslot(((C_word*)t0)[5],C_fix(1),((C_word*)t0)[4]));}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* srfi-69.scm: 787  loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_4337(t3,((C_word*)t0)[6],t2);}}

/* loop in k4269 in k4254 in k4401 in k4409 in hash-table-set! in k1945 */
static void C_fcall f_4288(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(6);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4288,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],((C_word*)t0)[8]);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[7]);
t5=(C_word)C_i_setslot(((C_word*)t0)[6],((C_word*)t0)[5],t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_i_set_i_slot(((C_word*)t0)[4],C_fix(2),((C_word*)t0)[3]));}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t3,C_fix(0));
t5=(C_word)C_eqp(((C_word*)t0)[9],t4);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_i_setslot(t3,C_fix(1),((C_word*)t0)[8]));}
else{
t6=(C_word)C_slot(t2,C_fix(1));
/* srfi-69.scm: 777  loop */
t11=t1;
t12=t6;
t1=t11;
t2=t12;
goto loop;}}}

/* k4275 in k4269 in k4254 in k4401 in k4409 in hash-table-set! in k1945 */
static void C_ccall f_4277(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,*((C_word*)lf[84]+1));}

/* hash-table-update!/default in k1945 */
static void C_ccall f_4216(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_4216,6,t0,t1,t2,t3,t4,t5);}
t6=(C_word)C_i_check_structure_2(t2,lf[27],lf[82]);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4223,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* srfi-69.scm: 752  ##sys#check-closure */
t8=*((C_word*)lf[42]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,t4,lf[82]);}

/* k4221 in hash-table-update!/default in k1945 */
static void C_ccall f_4223(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-69.scm: 753  *hash-table-update!/default */
t2=lf[81];
f_4009(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* *hash-table-update!/default in k1945 */
static void C_fcall f_4009(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4009,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(C_word)C_slot(t2,C_fix(2));
t7=(C_word)C_u_fixnum_plus(t6,C_fix(1));
t8=t2;
t9=(C_word)C_slot(t8,C_fix(1));
t10=(C_word)C_slot(t8,C_fix(5));
t11=(C_word)C_slot(t8,C_fix(6));
t12=(C_word)C_block_size(t9);
t13=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4206,a[2]=t11,a[3]=t12,a[4]=t9,a[5]=t8,a[6]=t1,a[7]=t5,a[8]=t4,a[9]=t7,a[10]=t3,a[11]=((C_word*)t0)[2],a[12]=t2,tmp=(C_word)a,a+=13,tmp);
t14=(C_word)C_a_i_times(&a,2,t12,t10);
/* srfi-69.scm: 621  floor */
t15=*((C_word*)lf[77]+1);
((C_proc3)(void*)(*((C_word*)t15+1)))(3,t15,t13,t14);}

/* k4204 in *hash-table-update!/default in k1945 */
static void C_ccall f_4206(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4206,2,t0,t1);}
t2=(C_word)C_i_inexact_to_exact(t1);
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4198,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
t4=(C_word)C_a_i_times(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]);
/* srfi-69.scm: 622  floor */
t5=*((C_word*)lf[77]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k4196 in k4204 in *hash-table-update!/default in k1945 */
static void C_ccall f_4198(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4198,2,t0,t1);}
t2=(C_word)C_i_inexact_to_exact(t1);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4034,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[12],tmp=(C_word)a,a+=9,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4179,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_lessp(((C_word*)t0)[3],C_fix(1073741823)))){
t5=(C_word)C_fixnum_less_or_equal_p(((C_word*)t0)[2],((C_word*)t0)[9]);
t6=t4;
f_4179(t6,(C_truep(t5)?(C_word)C_fixnum_less_or_equal_p(((C_word*)t0)[9],t2):C_SCHEME_FALSE));}
else{
t5=t4;
f_4179(t5,C_SCHEME_FALSE);}}

/* k4177 in k4196 in k4204 in *hash-table-update!/default in k1945 */
static void C_fcall f_4179(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* srfi-69.scm: 625  hash-table-resize! */
t2=*((C_word*)lf[73]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
f_4034(2,t2,C_SCHEME_UNDEFINED);}}

/* k4032 in k4196 in k4204 in *hash-table-update!/default in k1945 */
static void C_ccall f_4034(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4034,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[8],C_fix(4));
t3=(C_word)C_slot(((C_word*)t0)[8],C_fix(3));
t4=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
t5=(C_word)C_block_size(t4);
t6=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4049,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[6],a[8]=t3,a[9]=((C_word*)t0)[7],a[10]=t4,tmp=(C_word)a,a+=11,tmp);
/* srfi-69.scm: 720  hash */
t7=t2;
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,((C_word*)t0)[6],t5);}

/* k4047 in k4032 in k4196 in k4204 in *hash-table-update!/default in k1945 */
static void C_ccall f_4049(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4049,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[10],t1);
t3=(C_word)C_eqp(((C_word*)t0)[9],((C_word*)t0)[8]);
if(C_truep(t3)){
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4063,a[2]=t5,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[10],a[9]=t2,a[10]=((C_word*)t0)[7],tmp=(C_word)a,a+=11,tmp));
t7=((C_word*)t5)[1];
f_4063(t7,((C_word*)t0)[2],t2);}
else{
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4122,a[2]=((C_word*)t0)[8],a[3]=t5,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t1,a[9]=((C_word*)t0)[10],a[10]=t2,a[11]=((C_word*)t0)[7],tmp=(C_word)a,a+=12,tmp));
t7=((C_word*)t5)[1];
f_4122(t7,((C_word*)t0)[2],t2);}}

/* loop in k4047 in k4032 in k4196 in k4204 in *hash-table-update!/default in k1945 */
static void C_fcall f_4122(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4122,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4132,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],tmp=(C_word)a,a+=9,tmp);
/* srfi-69.scm: 739  func */
t4=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[4]);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4155,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_slot(t3,C_fix(0));
/* srfi-69.scm: 744  test */
t6=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,((C_word*)t0)[11],t5);}}

/* k4153 in loop in k4047 in k4032 in k4196 in k4204 in *hash-table-update!/default in k1945 */
static void C_ccall f_4155(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4155,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4158,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
/* srfi-69.scm: 745  func */
t4=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* srfi-69.scm: 748  loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_4122(t3,((C_word*)t0)[5],t2);}}

/* k4156 in k4153 in loop in k4047 in k4032 in k4196 in k4204 in *hash-table-update!/default in k1945 */
static void C_ccall f_4158(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[3],C_fix(1),t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* k4130 in loop in k4047 in k4032 in k4196 in k4204 in *hash-table-update!/default in k1945 */
static void C_ccall f_4132(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4132,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[7]);
t4=(C_word)C_i_setslot(((C_word*)t0)[6],((C_word*)t0)[5],t3);
t5=(C_word)C_i_set_i_slot(((C_word*)t0)[4],C_fix(2),((C_word*)t0)[3]);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t1);}

/* loop in k4047 in k4032 in k4196 in k4204 in *hash-table-update!/default in k1945 */
static void C_fcall f_4063(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(9);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4063,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4073,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
/* srfi-69.scm: 726  func */
t4=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[3]);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t3,C_fix(0));
t5=(C_word)C_eqp(((C_word*)t0)[10],t4);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4099,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_slot(t3,C_fix(1));
/* srfi-69.scm: 732  func */
t8=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t6,t7);}
else{
t6=(C_word)C_slot(t2,C_fix(1));
/* srfi-69.scm: 735  loop */
t11=t1;
t12=t6;
t1=t11;
t2=t12;
goto loop;}}}

/* k4097 in loop in k4047 in k4032 in k4196 in k4204 in *hash-table-update!/default in k1945 */
static void C_ccall f_4099(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[3],C_fix(1),t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* k4071 in loop in k4047 in k4032 in k4196 in k4204 in *hash-table-update!/default in k1945 */
static void C_ccall f_4073(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4073,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[7]);
t4=(C_word)C_i_setslot(((C_word*)t0)[6],((C_word*)t0)[5],t3);
t5=(C_word)C_i_set_i_slot(((C_word*)t0)[4],C_fix(2),((C_word*)t0)[3]);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t1);}

/* hash-table-update! in k1945 */
static void C_ccall f_3722(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+13)){
C_save_and_reclaim((void*)tr4r,(void*)f_3722r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3722r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3722r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(13);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3724,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3947,a[2]=t5,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3964,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-func11851275 */
t8=t7;
f_3964(t8,t1);}
else{
t8=(C_word)C_u_i_car(t4);
t9=(C_word)C_slot(t4,C_fix(1));
if(C_truep((C_word)C_i_nullp(t9))){
/* def-thunk11861262 */
t10=t6;
f_3947(t10,t1,t8);}
else{
t10=(C_word)C_u_i_car(t9);
t11=(C_word)C_slot(t9,C_fix(1));
/* body11831192 */
t12=t5;
f_3724(t12,t1,t8,t10);}}}

/* def-func1185 in hash-table-update! in k1945 */
static void C_fcall f_3964(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3964,NULL,2,t0,t1);}
/* def-thunk11861262 */
t2=((C_word*)t0)[2];
f_3947(t2,t1,*((C_word*)lf[80]+1));}

/* def-thunk1186 in hash-table-update! in k1945 */
static void C_fcall f_3947(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3947,NULL,3,t0,t1,t2);}
t3=(C_word)C_slot(((C_word*)t0)[4],C_fix(9));
t4=(C_truep(t3)?t3:(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3959,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp));
/* body11831192 */
t5=((C_word*)t0)[2];
f_3724(t5,t1,t2,t4);}

/* f_3959 in def-thunk1186 in hash-table-update! in k1945 */
static void C_ccall f_3959(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3959,2,t0,t1);}
/* srfi-69.scm: 669  ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,t1,lf[78],lf[76],lf[79],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* body1183 in hash-table-update! in k1945 */
static void C_fcall f_3724(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3724,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure_2(((C_word*)t0)[4],lf[27],lf[76]);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3731,a[2]=t1,a[3]=t3,a[4]=t2,a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
/* srfi-69.scm: 673  ##sys#check-closure */
t6=*((C_word*)lf[42]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t2,lf[76]);}

/* k3729 in body1183 in hash-table-update! in k1945 */
static void C_ccall f_3731(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3731,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3734,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* srfi-69.scm: 674  ##sys#check-closure */
t3=*((C_word*)lf[42]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],lf[76]);}

/* k3732 in k3729 in body1183 in hash-table-update! in k1945 */
static void C_ccall f_3734(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3734,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[7],C_fix(2));
t3=(C_word)C_u_fixnum_plus(t2,C_fix(1));
t4=((C_word*)t0)[7];
t5=(C_word)C_slot(t4,C_fix(1));
t6=(C_word)C_slot(t4,C_fix(5));
t7=(C_word)C_slot(t4,C_fix(6));
t8=(C_word)C_block_size(t5);
t9=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3938,a[2]=t7,a[3]=t8,a[4]=t5,a[5]=t4,a[6]=((C_word*)t0)[2],a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[4],a[9]=t3,a[10]=((C_word*)t0)[5],a[11]=((C_word*)t0)[6],a[12]=((C_word*)t0)[7],tmp=(C_word)a,a+=13,tmp);
t10=(C_word)C_a_i_times(&a,2,t8,t6);
/* srfi-69.scm: 621  floor */
t11=*((C_word*)lf[77]+1);
((C_proc3)(void*)(*((C_word*)t11+1)))(3,t11,t9,t10);}

/* k3936 in k3732 in k3729 in body1183 in hash-table-update! in k1945 */
static void C_ccall f_3938(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3938,2,t0,t1);}
t2=(C_word)C_i_inexact_to_exact(t1);
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3930,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
t4=(C_word)C_a_i_times(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]);
/* srfi-69.scm: 622  floor */
t5=*((C_word*)lf[77]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k3928 in k3936 in k3732 in k3729 in body1183 in hash-table-update! in k1945 */
static void C_ccall f_3930(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3930,2,t0,t1);}
t2=(C_word)C_i_inexact_to_exact(t1);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3758,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[12],tmp=(C_word)a,a+=9,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3911,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_lessp(((C_word*)t0)[3],C_fix(1073741823)))){
t5=(C_word)C_fixnum_less_or_equal_p(((C_word*)t0)[2],((C_word*)t0)[9]);
t6=t4;
f_3911(t6,(C_truep(t5)?(C_word)C_fixnum_less_or_equal_p(((C_word*)t0)[9],t2):C_SCHEME_FALSE));}
else{
t5=t4;
f_3911(t5,C_SCHEME_FALSE);}}

/* k3909 in k3928 in k3936 in k3732 in k3729 in body1183 in hash-table-update! in k1945 */
static void C_fcall f_3911(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* srfi-69.scm: 625  hash-table-resize! */
t2=*((C_word*)lf[73]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
f_3758(2,t2,C_SCHEME_UNDEFINED);}}

/* k3756 in k3928 in k3936 in k3732 in k3729 in body1183 in hash-table-update! in k1945 */
static void C_ccall f_3758(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3758,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[8],C_fix(4));
t3=(C_word)C_slot(((C_word*)t0)[8],C_fix(3));
t4=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
t5=(C_word)C_block_size(t4);
t6=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3773,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[6],a[8]=t3,a[9]=((C_word*)t0)[7],a[10]=t4,tmp=(C_word)a,a+=11,tmp);
/* srfi-69.scm: 681  hash */
t7=t2;
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,((C_word*)t0)[6],t5);}

/* k3771 in k3756 in k3928 in k3936 in k3732 in k3729 in body1183 in hash-table-update! in k1945 */
static void C_ccall f_3773(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3773,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[10],t1);
t3=(C_word)C_eqp(((C_word*)t0)[9],((C_word*)t0)[8]);
if(C_truep(t3)){
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3787,a[2]=t5,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[10],a[9]=t2,a[10]=((C_word*)t0)[7],tmp=(C_word)a,a+=11,tmp));
t7=((C_word*)t5)[1];
f_3787(t7,((C_word*)t0)[2],t2);}
else{
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3850,a[2]=((C_word*)t0)[8],a[3]=t5,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t1,a[9]=((C_word*)t0)[10],a[10]=t2,a[11]=((C_word*)t0)[7],tmp=(C_word)a,a+=12,tmp));
t7=((C_word*)t5)[1];
f_3850(t7,((C_word*)t0)[2],t2);}}

/* loop in k3771 in k3756 in k3928 in k3936 in k3732 in k3729 in body1183 in hash-table-update! in k1945 */
static void C_fcall f_3850(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3850,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3860,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],tmp=(C_word)a,a+=9,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3878,a[2]=t3,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* srfi-69.scm: 700  thunk */
t5=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3887,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_slot(t3,C_fix(0));
/* srfi-69.scm: 705  test */
t6=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,((C_word*)t0)[11],t5);}}

/* k3885 in loop in k3771 in k3756 in k3928 in k3936 in k3732 in k3729 in body1183 in hash-table-update! in k1945 */
static void C_ccall f_3887(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3887,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3890,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
/* srfi-69.scm: 706  func */
t4=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* srfi-69.scm: 709  loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_3850(t3,((C_word*)t0)[5],t2);}}

/* k3888 in k3885 in loop in k3771 in k3756 in k3928 in k3936 in k3732 in k3729 in body1183 in hash-table-update! in k1945 */
static void C_ccall f_3890(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[3],C_fix(1),t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* k3876 in loop in k3771 in k3756 in k3928 in k3936 in k3732 in k3729 in body1183 in hash-table-update! in k1945 */
static void C_ccall f_3878(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-69.scm: 700  func */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3858 in loop in k3771 in k3756 in k3928 in k3936 in k3732 in k3729 in body1183 in hash-table-update! in k1945 */
static void C_ccall f_3860(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3860,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[7]);
t4=(C_word)C_i_setslot(((C_word*)t0)[6],((C_word*)t0)[5],t3);
t5=(C_word)C_i_set_i_slot(((C_word*)t0)[4],C_fix(2),((C_word*)t0)[3]);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t1);}

/* loop in k3771 in k3756 in k3928 in k3936 in k3732 in k3729 in body1183 in hash-table-update! in k1945 */
static void C_fcall f_3787(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
loop:
a=C_alloc(13);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3787,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3797,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3815,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* srfi-69.scm: 687  thunk */
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t3,C_fix(0));
t5=(C_word)C_eqp(((C_word*)t0)[10],t4);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3827,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_slot(t3,C_fix(1));
/* srfi-69.scm: 693  func */
t8=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t6,t7);}
else{
t6=(C_word)C_slot(t2,C_fix(1));
/* srfi-69.scm: 696  loop */
t12=t1;
t13=t6;
t1=t12;
t2=t13;
goto loop;}}}

/* k3825 in loop in k3771 in k3756 in k3928 in k3936 in k3732 in k3729 in body1183 in hash-table-update! in k1945 */
static void C_ccall f_3827(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[3],C_fix(1),t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* k3813 in loop in k3771 in k3756 in k3928 in k3936 in k3732 in k3729 in body1183 in hash-table-update! in k1945 */
static void C_ccall f_3815(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-69.scm: 687  func */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3795 in loop in k3771 in k3756 in k3928 in k3936 in k3732 in k3729 in body1183 in hash-table-update! in k1945 */
static void C_ccall f_3797(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3797,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[7]);
t4=(C_word)C_i_setslot(((C_word*)t0)[6],((C_word*)t0)[5],t3);
t5=(C_word)C_i_set_i_slot(((C_word*)t0)[4],C_fix(2),((C_word*)t0)[3]);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t1);}

/* hash-table-copy in k1945 */
static void C_ccall f_3713(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3713,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[27],lf[75]);
/* srfi-69.scm: 654  *hash-table-copy */
t4=lf[74];
f_3601(t4,t1,t2);}

/* *hash-table-copy in k1945 */
static void C_fcall f_3601(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3601,NULL,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(1));
t4=(C_word)C_block_size(t3);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3611,a[2]=t1,a[3]=t3,a[4]=t2,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* srfi-69.scm: 634  make-vector */
t6=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t4,C_SCHEME_END_OF_LIST);}

/* k3609 in *hash-table-copy in k1945 */
static void C_ccall f_3611(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3611,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3616,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_3616(t5,((C_word*)t0)[2],C_fix(0));}

/* doloop1137 in k3609 in *hash-table-copy in k1945 */
static void C_fcall f_3616(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3616,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[6]))){
t3=(C_word)C_slot(((C_word*)t0)[5],C_fix(3));
t4=(C_word)C_slot(((C_word*)t0)[5],C_fix(4));
t5=(C_word)C_slot(((C_word*)t0)[5],C_fix(2));
t6=(C_word)C_slot(((C_word*)t0)[5],C_fix(5));
t7=(C_word)C_slot(((C_word*)t0)[5],C_fix(6));
t8=(C_word)C_slot(((C_word*)t0)[5],C_fix(7));
t9=(C_word)C_slot(((C_word*)t0)[5],C_fix(8));
t10=(C_word)C_slot(((C_word*)t0)[5],C_fix(9));
/* srfi-69.scm: 637  *make-hash-table */
t11=lf[26];
f_3013(t11,t1,t3,t4,t5,t6,t7,t10,(C_word)C_a_i_list(&a,1,((C_word*)t0)[4]));}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3672,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_slot(((C_word*)t0)[2],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3678,a[2]=t6,tmp=(C_word)a,a+=3,tmp));
t8=((C_word*)t6)[1];
f_3678(t8,t3,t4);}}

/* copy-loop in doloop1137 in k3609 in *hash-table-copy in k1945 */
static void C_fcall f_3678(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
a=C_alloc(7);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3678,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t3,C_fix(0));
t5=(C_word)C_slot(t3,C_fix(1));
t6=(C_word)C_a_i_cons(&a,2,t4,t5);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3699,a[2]=t6,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t8=(C_word)C_slot(t2,C_fix(1));
/* srfi-69.scm: 650  copy-loop */
t10=t7;
t11=t8;
t1=t10;
t2=t11;
goto loop;}}

/* k3697 in copy-loop in doloop1137 in k3609 in *hash-table-copy in k1945 */
static void C_ccall f_3699(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3699,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k3670 in doloop1137 in k3609 in *hash-table-copy in k1945 */
static void C_ccall f_3672(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[5],((C_word*)t0)[4],t1);
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_3616(t4,((C_word*)t0)[2],t3);}

/* hash-table-resize! in k1945 */
static void C_ccall f_3575(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3575,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_fixnum_times(t4,C_fix(2));
t6=(C_word)C_i_fixnum_min(C_fix(1073741823),t5);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3582,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm: 609  hash-table-canonical-length */
f_2983(t7,lf[22],t6);}

/* k3580 in hash-table-resize! in k1945 */
static void C_ccall f_3582(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3582,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3585,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm: 610  make-vector */
t3=*((C_word*)lf[25]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,t1,C_SCHEME_END_OF_LIST);}

/* k3583 in k3580 in hash-table-resize! in k1945 */
static void C_ccall f_3585(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3585,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3588,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(4));
t4=((C_word*)t0)[2];
t5=t1;
t6=(C_word)C_block_size(t4);
t7=(C_word)C_block_size(t5);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3508,a[2]=t7,a[3]=t3,a[4]=t5,a[5]=t4,a[6]=t9,a[7]=t6,tmp=(C_word)a,a+=8,tmp));
t11=((C_word*)t9)[1];
f_3508(t11,t2,C_fix(0));}

/* doloop1078 in k3583 in k3580 in hash-table-resize! in k1945 */
static void C_fcall f_3508(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3508,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[7]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3518,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(((C_word*)t0)[5],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3531,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t6,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_3531(t8,t3,t4);}}

/* loop in doloop1078 in k3583 in k3580 in hash-table-resize! in k1945 */
static void C_fcall f_3531(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3531,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t3,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3547,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=t4,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
/* srfi-69.scm: 600  hash */
t6=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t4,((C_word*)t0)[2]);}}

/* k3545 in loop in doloop1078 in k3583 in k3580 in hash-table-resize! in k1945 */
static void C_ccall f_3547(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3547,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[7],C_fix(1));
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t2);
t4=(C_word)C_slot(((C_word*)t0)[5],t1);
t5=(C_word)C_a_i_cons(&a,2,t3,t4);
t6=(C_word)C_i_setslot(((C_word*)t0)[5],t1,t5);
t7=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* srfi-69.scm: 603  loop */
t8=((C_word*)((C_word*)t0)[3])[1];
f_3531(t8,((C_word*)t0)[2],t7);}

/* k3516 in doloop1078 in k3583 in k3580 in hash-table-resize! in k1945 */
static void C_ccall f_3518(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_3508(t3,((C_word*)t0)[2],t2);}

/* k3586 in k3583 in k3580 in hash-table-resize! in k1945 */
static void C_ccall f_3588(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_setslot(((C_word*)t0)[3],C_fix(1),((C_word*)t0)[2]));}

/* hash-table-initial in k1945 */
static void C_ccall f_3481(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3481,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[27],lf[72]);
t4=(C_word)C_slot(t2,C_fix(9));
if(C_truep(t4)){
/* srfi-69.scm: 587  thunk */
t5=t4;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t1);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}

/* hash-table-has-initial? in k1945 */
static void C_ccall f_3469(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3469,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[27],lf[71]);
t4=(C_word)C_slot(t2,C_fix(9));
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_truep(t4)?C_SCHEME_TRUE:C_SCHEME_FALSE));}

/* hash-table-weak-values in k1945 */
static void C_ccall f_3460(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3460,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[27],lf[70]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(8)));}

/* hash-table-weak-keys in k1945 */
static void C_ccall f_3451(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3451,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[27],lf[69]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(7)));}

/* hash-table-max-load in k1945 */
static void C_ccall f_3442(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3442,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[27],lf[68]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(6)));}

/* hash-table-min-load in k1945 */
static void C_ccall f_3433(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3433,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[27],lf[67]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(5)));}

/* hash-table-hash-function in k1945 */
static void C_ccall f_3424(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3424,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[27],lf[66]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(4)));}

/* hash-table-equivalence-function in k1945 */
static void C_ccall f_3415(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3415,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[27],lf[65]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(3)));}

/* hash-table-size in k1945 */
static void C_ccall f_3406(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3406,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[27],lf[64]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(2)));}

/* hash-table? in k1945 */
static void C_ccall f_3400(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3400,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[27]));}

/* make-hash-table in k1945 */
static void C_ccall f_3037(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+41)){
C_save_and_reclaim((void*)tr2r,(void*)f_3037r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3037r(t0,t1,t2);}}

static void C_ccall f_3037r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word *a=C_alloc(41);
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=*((C_word*)lf[30]+1);
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_FALSE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_fix(307);
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_SCHEME_FALSE;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=lf[35];
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=lf[36];
t16=(*a=C_VECTOR_TYPE|1,a[1]=t15,tmp=(C_word)a,a+=2,tmp);
t17=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3039,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t6,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t18=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3115,a[2]=t4,a[3]=t2,a[4]=t17,a[5]=t12,a[6]=t16,a[7]=t14,a[8]=t8,a[9]=t6,a[10]=t1,a[11]=t10,tmp=(C_word)a,a+=12,tmp);
if(C_truep((C_word)C_i_nullp(((C_word*)t4)[1]))){
t19=t18;
f_3115(t19,C_SCHEME_UNDEFINED);}
else{
t19=(C_word)C_u_i_car(((C_word*)t4)[1]);
t20=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3390,a[2]=t4,a[3]=t19,a[4]=t6,a[5]=t18,tmp=(C_word)a,a+=6,tmp);
/* srfi-69.scm: 466  keyword? */
t21=*((C_word*)lf[12]+1);
((C_proc3)(void*)(*((C_word*)t21+1)))(3,t21,t20,t19);}}

/* k3388 in make-hash-table in k1945 */
static void C_ccall f_3390(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3390,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
f_3115(t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3393,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* srfi-69.scm: 467  ##sys#check-closure */
t3=*((C_word*)lf[42]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],lf[34]);}}

/* k3391 in k3388 in make-hash-table in k1945 */
static void C_ccall f_3393(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,((C_word*)t0)[4]);
t3=(C_word)C_slot(((C_word*)((C_word*)t0)[3])[1],C_fix(1));
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=((C_word*)t0)[2];
f_3115(t5,t4);}

/* k3113 in make-hash-table in k1945 */
static void C_fcall f_3115(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3115,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3118,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
if(C_truep((C_word)C_i_nullp(((C_word*)((C_word*)t0)[2])[1]))){
t3=t2;
f_3118(t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_u_i_car(((C_word*)((C_word*)t0)[2])[1]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3370,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[8],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* srfi-69.scm: 472  keyword? */
t5=*((C_word*)lf[12]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t3);}}

/* k3368 in k3113 in make-hash-table in k1945 */
static void C_ccall f_3370(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3370,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
f_3118(t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3373,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* srfi-69.scm: 473  ##sys#check-closure */
t3=*((C_word*)lf[42]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],lf[34]);}}

/* k3371 in k3368 in k3113 in make-hash-table in k1945 */
static void C_ccall f_3373(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,((C_word*)t0)[4]);
t3=(C_word)C_slot(((C_word*)((C_word*)t0)[3])[1],C_fix(1));
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=((C_word*)t0)[2];
f_3118(t5,t4);}

/* k3116 in k3113 in make-hash-table in k1945 */
static void C_fcall f_3118(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3118,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3121,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
if(C_truep((C_word)C_i_nullp(((C_word*)((C_word*)t0)[2])[1]))){
t3=t2;
f_3121(t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_u_i_car(((C_word*)((C_word*)t0)[2])[1]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3338,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[11],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* srfi-69.scm: 478  keyword? */
t5=*((C_word*)lf[12]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t3);}}

/* k3336 in k3116 in k3113 in make-hash-table in k1945 */
static void C_ccall f_3338(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3338,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
f_3121(t2,C_SCHEME_UNDEFINED);}
else{
t2=(C_word)C_i_check_exact_2(((C_word*)t0)[4],lf[34]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3344,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_lessp(C_fix(0),((C_word*)t0)[4]))){
t4=t3;
f_3344(2,t4,C_SCHEME_UNDEFINED);}
else{
/* srfi-69.scm: 481  error */
t4=*((C_word*)lf[39]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,lf[34],lf[62],((C_word*)t0)[4]);}}}

/* k3342 in k3336 in k3116 in k3113 in make-hash-table in k1945 */
static void C_ccall f_3344(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_word)C_i_fixnum_min(*((C_word*)lf[45]+1),((C_word*)t0)[5]);
t3=C_mutate(((C_word *)((C_word*)t0)[4])+1,t2);
t4=(C_word)C_slot(((C_word*)((C_word*)t0)[3])[1],C_fix(1));
t5=C_mutate(((C_word *)((C_word*)t0)[3])+1,t4);
t6=((C_word*)t0)[2];
f_3121(t6,t5);}

/* k3119 in k3116 in k3113 in make-hash-table in k1945 */
static void C_fcall f_3121(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[22],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3121,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3124,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3156,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=t4,a[9]=((C_word*)t0)[3],tmp=(C_word)a,a+=10,tmp));
t6=((C_word*)t4)[1];
f_3156(t6,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* loop in k3119 in k3116 in k3113 in make-hash-table in k1945 */
static void C_fcall f_3156(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3156,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_u_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3167,a[2]=((C_word*)t0)[9],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3177,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=t3,a[10]=t1,a[11]=((C_word*)t0)[8],a[12]=t2,tmp=(C_word)a,a+=13,tmp);
/* srfi-69.scm: 491  keyword? */
t6=*((C_word*)lf[12]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t3);}}

/* k3175 in loop in k3119 in k3116 in k3113 in make-hash-table in k1945 */
static void C_ccall f_3177(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3177,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[12],C_fix(1));
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3183,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=t2,tmp=(C_word)a,a+=13,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t4=t3;
f_3183(2,t4,(C_word)C_u_i_car(t2));}
else{
/* srfi-69.scm: 495  invarg-err */
t4=((C_word*)t0)[2];
f_3167(t4,t3,lf[60]);}}
else{
/* srfi-69.scm: 527  invarg-err */
t2=((C_word*)t0)[2];
f_3167(t2,((C_word*)t0)[10],lf[61]);}}

/* k3181 in k3175 in loop in k3119 in k3116 in k3113 in make-hash-table in k1945 */
static void C_ccall f_3183(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3183,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3186,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[12],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[9],lf[41]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3199,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm: 498  ##sys#check-closure */
t5=*((C_word*)lf[42]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t1,lf[34]);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[9],lf[43]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3209,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm: 501  ##sys#check-closure */
t6=*((C_word*)lf[42]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t1,lf[34]);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[9],lf[44]);
if(C_truep(t5)){
t6=(C_word)C_i_check_exact_2(t1,lf[34]);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3222,a[2]=t2,a[3]=((C_word*)t0)[6],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_fixnum_lessp(C_fix(0),t1))){
t8=t7;
f_3222(2,t8,C_SCHEME_UNDEFINED);}
else{
/* srfi-69.scm: 506  error */
t8=*((C_word*)lf[39]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t7,lf[34],lf[46],t1);}}
else{
t6=(C_word)C_eqp(((C_word*)t0)[9],lf[47]);
if(C_truep(t6)){
t7=C_mutate(((C_word *)((C_word*)t0)[5])+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3240,a[2]=t1,tmp=(C_word)a,a+=3,tmp));
t8=t2;
f_3186(2,t8,t7);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[9],lf[48]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3250,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm: 511  ##sys#check-inexact */
t9=*((C_word*)lf[52]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t8,t1,lf[34]);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[9],lf[53]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3275,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm: 516  ##sys#check-inexact */
t10=*((C_word*)lf[52]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t9,t1,lf[34]);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[9],lf[57]);
if(C_truep(t9)){
t10=(C_truep(t1)?C_SCHEME_TRUE:C_SCHEME_FALSE);
t11=C_SCHEME_UNDEFINED;
t12=t2;
f_3186(2,t12,t11);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[9],lf[58]);
if(C_truep(t10)){
t11=(C_truep(t1)?C_SCHEME_TRUE:C_SCHEME_FALSE);
t12=C_SCHEME_UNDEFINED;
t13=t2;
f_3186(2,t13,t12);}
else{
/* srfi-69.scm: 525  invarg-err */
t11=((C_word*)t0)[2];
f_3167(t11,t2,lf[59]);}}}}}}}}}

/* k3273 in k3181 in k3175 in loop in k3119 in k3116 in k3113 in make-hash-table in k1945 */
static void C_ccall f_3275(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3275,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3278,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_flonum_lessp(lf[54],((C_word*)t0)[3]);
t4=(C_truep(t3)?(C_word)C_flonum_lessp(((C_word*)t0)[3],lf[55]):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=t2;
f_3278(2,t5,C_SCHEME_UNDEFINED);}
else{
/* srfi-69.scm: 518  error */
t5=*((C_word*)lf[39]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t2,lf[34],lf[56],((C_word*)t0)[3]);}}

/* k3276 in k3273 in k3181 in k3175 in loop in k3119 in k3116 in k3113 in make-hash-table in k1945 */
static void C_ccall f_3278(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
f_3186(2,t3,t2);}

/* k3248 in k3181 in k3175 in loop in k3119 in k3116 in k3113 in make-hash-table in k1945 */
static void C_ccall f_3250(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3250,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3253,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_flonum_lessp(lf[49],((C_word*)t0)[3]);
t4=(C_truep(t3)?(C_word)C_flonum_lessp(((C_word*)t0)[3],lf[50]):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=t2;
f_3253(2,t5,C_SCHEME_UNDEFINED);}
else{
/* srfi-69.scm: 513  error */
t5=*((C_word*)lf[39]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t2,lf[34],lf[51],((C_word*)t0)[3]);}}

/* k3251 in k3248 in k3181 in k3175 in loop in k3119 in k3116 in k3113 in make-hash-table in k1945 */
static void C_ccall f_3253(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
f_3186(2,t3,t2);}

/* f_3240 in k3181 in k3175 in loop in k3119 in k3116 in k3113 in make-hash-table in k1945 */
static void C_ccall f_3240(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3240,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k3220 in k3181 in k3175 in loop in k3119 in k3116 in k3113 in make-hash-table in k1945 */
static void C_ccall f_3222(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_fixnum_min(*((C_word*)lf[45]+1),((C_word*)t0)[4]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
f_3186(2,t4,t3);}

/* k3207 in k3181 in k3175 in loop in k3119 in k3116 in k3113 in make-hash-table in k1945 */
static void C_ccall f_3209(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
f_3186(2,t3,t2);}

/* k3197 in k3181 in k3175 in loop in k3119 in k3116 in k3113 in make-hash-table in k1945 */
static void C_ccall f_3199(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
f_3186(2,t3,t2);}

/* k3184 in k3181 in k3175 in loop in k3119 in k3116 in k3113 in make-hash-table in k1945 */
static void C_ccall f_3186(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* srfi-69.scm: 526  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_3156(t3,((C_word*)t0)[2],t2);}

/* invarg-err in loop in k3119 in k3116 in k3113 in make-hash-table in k1945 */
static void C_fcall f_3167(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3167,NULL,3,t0,t1,t2);}
/* srfi-69.scm: 490  error */
t3=*((C_word*)lf[39]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t1,lf[34],t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3122 in k3119 in k3116 in k3113 in make-hash-table in k1945 */
static void C_ccall f_3124(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3124,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3127,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
if(C_truep((C_word)C_flonum_lessp(((C_word*)((C_word*)t0)[4])[1],((C_word*)((C_word*)t0)[5])[1]))){
/* srfi-69.scm: 530  error */
t3=*((C_word*)lf[39]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,lf[34],lf[40],((C_word*)((C_word*)t0)[5])[1],((C_word*)((C_word*)t0)[4])[1]);}
else{
t3=t2;
f_3127(2,t3,C_SCHEME_UNDEFINED);}}

/* k3125 in k3122 in k3119 in k3116 in k3113 in make-hash-table in k1945 */
static void C_ccall f_3127(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3127,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3131,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* srfi-69.scm: 532  hash-table-canonical-length */
f_2983(t2,lf[22],((C_word*)((C_word*)t0)[9])[1]);}

/* k3129 in k3125 in k3122 in k3119 in k3116 in k3113 in make-hash-table in k1945 */
static void C_ccall f_3131(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3131,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[9])+1,t1);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3134,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t4=t3;
f_3134(t4,C_SCHEME_UNDEFINED);}
else{
t4=f_3039(((C_word*)t0)[2]);
if(C_truep(t4)){
t5=C_mutate(((C_word *)((C_word*)t0)[6])+1,t4);
t6=t3;
f_3134(t6,t5);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3147,a[2]=t3,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* srfi-69.scm: 539  warning */
t6=*((C_word*)lf[37]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,lf[34],lf[38]);}}}

/* k3145 in k3129 in k3125 in k3122 in k3119 in k3116 in k3113 in make-hash-table in k1945 */
static void C_ccall f_3147(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,*((C_word*)lf[18]+1));
t3=((C_word*)t0)[2];
f_3134(t3,t2);}

/* k3132 in k3129 in k3125 in k3122 in k3119 in k3116 in k3113 in make-hash-table in k1945 */
static void C_fcall f_3134(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-69.scm: 542  *make-hash-table */
t2=lf[26];
f_3013(t2,((C_word*)t0)[8],((C_word*)((C_word*)t0)[7])[1],((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[5])[1],((C_word*)((C_word*)t0)[4])[1],((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1],C_SCHEME_END_OF_LIST);}

/* hash-for-test in make-hash-table in k1945 */
static C_word C_fcall f_3039(C_word t0){
C_word tmp;
C_word t1;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
t1=(C_word)C_eqp(((C_word*)t0)[8],((C_word*)((C_word*)t0)[7])[1]);
t2=(C_truep(t1)?t1:(C_word)C_eqp(*((C_word*)lf[28]+1),((C_word*)((C_word*)t0)[7])[1]));
if(C_truep(t2)){
return(*((C_word*)lf[14]+1));}
else{
t3=(C_word)C_eqp(((C_word*)t0)[6],((C_word*)((C_word*)t0)[7])[1]);
t4=(C_truep(t3)?t3:(C_word)C_eqp(*((C_word*)lf[29]+1),((C_word*)((C_word*)t0)[7])[1]));
if(C_truep(t4)){
return(*((C_word*)lf[16]+1));}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],((C_word*)((C_word*)t0)[7])[1]);
t6=(C_truep(t5)?t5:(C_word)C_eqp(*((C_word*)lf[30]+1),((C_word*)((C_word*)t0)[7])[1]));
if(C_truep(t6)){
return(*((C_word*)lf[18]+1));}
else{
t7=(C_word)C_eqp(((C_word*)t0)[4],((C_word*)((C_word*)t0)[7])[1]);
t8=(C_truep(t7)?t7:(C_word)C_eqp(*((C_word*)lf[31]+1),((C_word*)((C_word*)t0)[7])[1]));
if(C_truep(t8)){
return(*((C_word*)lf[20]+1));}
else{
t9=(C_word)C_eqp(((C_word*)t0)[3],((C_word*)((C_word*)t0)[7])[1]);
t10=(C_truep(t9)?t9:(C_word)C_eqp(*((C_word*)lf[32]+1),((C_word*)((C_word*)t0)[7])[1]));
if(C_truep(t10)){
return(*((C_word*)lf[21]+1));}
else{
t11=(C_word)C_eqp(((C_word*)t0)[2],((C_word*)((C_word*)t0)[7])[1]);
t12=(C_truep(t11)?t11:(C_word)C_eqp(*((C_word*)lf[33]+1),((C_word*)((C_word*)t0)[7])[1]));
return((C_truep(t12)?*((C_word*)lf[2]+1):C_SCHEME_FALSE));}}}}}}

/* *make-hash-table in k1945 */
static void C_fcall f_3013(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3013,NULL,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3017,a[2]=t7,a[3]=t6,a[4]=t5,a[5]=t3,a[6]=t2,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_i_nullp(t8))){
/* srfi-69.scm: 414  make-vector */
t10=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t9,t4,C_SCHEME_END_OF_LIST);}
else{
t10=t9;
f_3017(2,t10,(C_word)C_u_i_car(t8));}}

/* k3015 in *make-hash-table in k1945 */
static void C_ccall f_3017(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3017,2,t0,t1);}
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,10,lf[27],t1,C_fix(0),((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],C_SCHEME_FALSE,C_SCHEME_FALSE,((C_word*)t0)[2]));}

/* hash-table-canonical-length in k1945 */
static void C_fcall f_2983(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2983,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2989,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,f_2989(t4,t2));}

/* loop in hash-table-canonical-length in k1945 */
static C_word C_fcall f_2989(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
loop:
t2=(C_word)C_slot(t1,C_fix(0));
t3=(C_word)C_slot(t1,C_fix(1));
t4=(C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[2]);
t5=(C_truep(t4)?t4:(C_word)C_i_nullp(t3));
if(C_truep(t5)){
return(t2);}
else{
t7=t3;
t1=t7;
goto loop;}}

/* string-ci-hash in k1945 */
static void C_ccall f_2941(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3rv,(void*)f_2941r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_2941r(t0,t1,t2,t3);}}

static void C_ccall f_2941r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
t4=(C_word)C_vemptyp(t3);
t5=(C_truep(t4)?C_fix(536870912):(C_word)C_slot(t3,C_fix(0)));
t6=(C_word)C_i_check_string_2(t2,lf[21]);
t7=(C_word)C_i_check_exact_2(t5,lf[21]);
t8=t2;
t9=(C_word)C_hash_string_ci(t8);
t10=(C_word)C_fixnum_lessp(t9,C_fix(0));
t11=(C_truep(t10)?(C_word)C_u_fixnum_negate(t9):t9);
t12=(C_word)C_u_fixnum_and(C_fix((C_word)C_MOST_POSITIVE_FIXNUM),t11);
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,(C_word)C_fixnum_modulo(t12,t5));}

/* string-hash in k1945 */
static void C_ccall f_2900(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3rv,(void*)f_2900r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_2900r(t0,t1,t2,t3);}}

static void C_ccall f_2900r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
t4=(C_word)C_vemptyp(t3);
t5=(C_truep(t4)?C_fix(536870912):(C_word)C_slot(t3,C_fix(0)));
t6=(C_word)C_i_check_string_2(t2,lf[20]);
t7=(C_word)C_i_check_exact_2(t5,lf[20]);
t8=t2;
t9=(C_word)C_hash_string(t8);
t10=(C_word)C_fixnum_lessp(t9,C_fix(0));
t11=(C_truep(t10)?(C_word)C_u_fixnum_negate(t9):t9);
t12=(C_word)C_u_fixnum_and(C_fix((C_word)C_MOST_POSITIVE_FIXNUM),t11);
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,(C_word)C_fixnum_modulo(t12,t5));}

/* equal?-hash in k1945 */
static void C_ccall f_2858(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3rv,(void*)f_2858r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_2858r(t0,t1,t2,t3);}}

static void C_ccall f_2858r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(4);
t4=(C_word)C_vemptyp(t3);
t5=(C_truep(t4)?C_fix(536870912):(C_word)C_slot(t3,C_fix(0)));
t6=(C_word)C_i_check_exact_2(t5,lf[19]);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2868,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-69.scm: 354  *equal?-hash */
f_2524(t7,t2);}

/* k2866 in equal?-hash in k1945 */
static void C_ccall f_2868(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_fixnum_lessp(t1,C_fix(0));
t3=(C_truep(t2)?(C_word)C_u_fixnum_negate(t1):t1);
t4=(C_word)C_u_fixnum_and(C_fix((C_word)C_MOST_POSITIVE_FIXNUM),t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_fixnum_modulo(t4,((C_word*)t0)[2]));}

/* *equal?-hash in k1945 */
static void C_fcall f_2524(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2524,NULL,2,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2527,a[2]=t8,tmp=(C_word)a,a+=3,tmp));
t10=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2592,a[2]=t8,tmp=(C_word)a,a+=3,tmp));
t11=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2623,a[2]=t4,a[3]=t6,tmp=(C_word)a,a+=4,tmp));
/* srfi-69.scm: 350  recursive-hash */
t12=((C_word*)t8)[1];
f_2623(t12,t1,t2,C_fix(0));}

/* recursive-hash in *equal?-hash in k1945 */
static void C_fcall f_2623(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2623,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,C_fix(4)))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_fix(99));}
else{
if(C_truep((C_word)C_fixnump(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}
else{
if(C_truep((C_word)C_charp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_fix((C_word)C_character_code(t2)));}
else{
switch(t2){
case C_SCHEME_TRUE:
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_fix(256));
case C_SCHEME_FALSE:
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_fix(257));
default:
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_fix(258));}
else{
if(C_truep((C_word)C_eofp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_fix(259));}
else{
if(C_truep((C_word)C_i_symbolp(t2))){
t4=t2;
t5=(C_word)C_slot(t4,C_fix(1));
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_hash_string(t5));}
else{
if(C_truep((C_word)C_i_numberp(t2))){
t4=t2;
if(C_truep((C_word)C_i_flonump(t4))){
t5=(C_word)C_subbyte(t4,C_fix(7));
t6=(C_word)C_subbyte(t4,C_fix(6));
t7=(C_word)C_subbyte(t4,C_fix(5));
t8=(C_word)C_subbyte(t4,C_fix(4));
t9=(C_word)C_subbyte(t4,C_fix(3));
t10=(C_word)C_subbyte(t4,C_fix(2));
t11=(C_word)C_subbyte(t4,C_fix(1));
t12=(C_word)C_subbyte(t4,C_fix(0));
t13=(C_word)C_fixnum_shift_left(t12,C_fix(1));
t14=(C_word)C_u_fixnum_plus(t11,t13);
t15=(C_word)C_fixnum_shift_left(t14,C_fix(1));
t16=(C_word)C_u_fixnum_plus(t10,t15);
t17=(C_word)C_fixnum_shift_left(t16,C_fix(1));
t18=(C_word)C_u_fixnum_plus(t9,t17);
t19=(C_word)C_fixnum_shift_left(t18,C_fix(1));
t20=(C_word)C_u_fixnum_plus(t8,t19);
t21=(C_word)C_fixnum_shift_left(t20,C_fix(1));
t22=(C_word)C_u_fixnum_plus(t7,t21);
t23=(C_word)C_fixnum_shift_left(t22,C_fix(1));
t24=(C_word)C_u_fixnum_plus(t6,t23);
t25=(C_word)C_fixnum_shift_left(t24,C_fix(1));
t26=(C_word)C_u_fixnum_plus(t5,t25);
t27=t1;
((C_proc2)(void*)(*((C_word*)t27+1)))(2,t27,(C_word)C_fixnum_times(C_fix(331804471),t26));}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2760,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* srfi-69.scm: 166  ##sys#number-hash-hook */
t6=*((C_word*)lf[0]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t4);}}
else{
t4=t2;
if(C_truep((C_word)C_blockp(t4))){
t5=t2;
if(C_truep((C_word)C_byteblockp(t5))){
t6=t2;
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_hash_string(t6));}
else{
if(C_truep((C_word)C_i_listp(t2))){
t6=t2;
t7=(C_word)C_i_length(t6);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2786,a[2]=t7,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t9=(C_word)C_slot(t6,C_fix(0));
/* srfi-69.scm: 286  recursive-atomic-hash */
t10=((C_word*)((C_word*)t0)[3])[1];
f_2592(t10,t8,t9,t3);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t6=t2;
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2815,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t6,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t8=(C_word)C_slot(t6,C_fix(0));
/* srfi-69.scm: 289  recursive-atomic-hash */
t9=((C_word*)((C_word*)t0)[3])[1];
f_2592(t9,t7,t8,t3);}
else{
t6=t2;
if(C_truep((C_word)C_portp(t6))){
t7=t2;
t8=(C_word)C_peek_fixnum(t7,C_fix(0));
t9=(C_word)C_fixnum_shift_left(t8,C_fix(4));
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2836,a[2]=t9,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-69.scm: 294  input-port? */
t11=*((C_word*)lf[17]+1);
((C_proc3)(void*)(*((C_word*)t11+1)))(3,t11,t10,t7);}
else{
t7=t2;
if(C_truep((C_word)C_specialp(t7))){
t8=t2;
t9=(C_word)C_peek_fixnum(t8,C_fix(0));
/* srfi-69.scm: 299  vector-hash */
t10=((C_word*)((C_word*)t0)[2])[1];
f_2527(t10,t1,t8,t9,t3,C_fix(1));}
else{
t8=t2;
/* srfi-69.scm: 302  vector-hash */
t9=((C_word*)((C_word*)t0)[2])[1];
f_2527(t9,t1,t8,C_fix(0),t3,C_fix(0));}}}}}}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_fix(262));}}}}}}}}}}

/* k2834 in recursive-hash in *equal?-hash in k1945 */
static void C_ccall f_2836(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?C_fix(260):C_fix(261));
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_u_fixnum_plus(((C_word*)t0)[2],t2));}

/* k2813 in recursive-hash in *equal?-hash in k1945 */
static void C_ccall f_2815(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2815,2,t0,t1);}
t2=(C_word)C_fixnum_shift_left(t1,C_fix(16));
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2807,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* srfi-69.scm: 290  recursive-atomic-hash */
t5=((C_word*)((C_word*)t0)[3])[1];
f_2592(t5,t3,t4,((C_word*)t0)[2]);}

/* k2805 in k2813 in recursive-hash in *equal?-hash in k1945 */
static void C_ccall f_2807(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_u_fixnum_plus(((C_word*)t0)[2],t1));}

/* k2784 in recursive-hash in *equal?-hash in k1945 */
static void C_ccall f_2786(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_u_fixnum_plus(((C_word*)t0)[2],t1));}

/* k2758 in recursive-hash in *equal?-hash in k1945 */
static void C_ccall f_2760(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_fix(t1));}

/* recursive-atomic-hash in *equal?-hash in k1945 */
static void C_fcall f_2592(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2592,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_i_not((C_word)C_blockp(t4));
t6=(C_truep(t5)?t5:(C_word)C_i_symbolp(t4));
t7=(C_truep(t6)?t6:(C_word)C_i_numberp(t4));
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2608,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t7)){
t9=t8;
f_2608(t9,t7);}
else{
t9=t2;
t10=t8;
f_2608(t10,(C_word)C_byteblockp(t9));}}

/* k2606 in recursive-atomic-hash in *equal?-hash in k1945 */
static void C_fcall f_2608(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[5],C_fix(1));
/* srfi-69.scm: 324  recursive-hash */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2623(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(99));}}

/* vector-hash in *equal?-hash in k1945 */
static void C_fcall f_2527(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2527,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(C_word)C_block_size(t2);
t7=(C_word)C_u_fixnum_plus(t6,t3);
t8=(C_word)C_i_fixnum_min(C_fix(4),t6);
t9=(C_word)C_u_fixnum_difference(t8,t5);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2544,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t2,a[5]=t11,tmp=(C_word)a,a+=6,tmp));
t13=((C_word*)t11)[1];
f_2544(t13,t1,t7,t5,t9);}

/* loop in vector-hash in *equal?-hash in k1945 */
static void C_fcall f_2544(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2544,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t4,C_fix(0));
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t2);}
else{
t6=(C_word)C_fixnum_shift_left(t2,C_fix(4));
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2578,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=t4,a[5]=t3,a[6]=t2,a[7]=t6,tmp=(C_word)a,a+=8,tmp);
t8=(C_word)C_slot(((C_word*)t0)[4],t3);
t9=(C_word)C_u_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* srfi-69.scm: 316  recursive-hash */
t10=((C_word*)((C_word*)t0)[2])[1];
f_2623(t10,t7,t8,t9);}}

/* k2576 in loop in vector-hash in *equal?-hash in k1945 */
static void C_ccall f_2578(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[7],t1);
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[6],t2);
t4=(C_word)C_u_fixnum_plus(((C_word*)t0)[5],C_fix(1));
t5=(C_word)C_u_fixnum_difference(((C_word*)t0)[4],C_fix(1));
/* srfi-69.scm: 314  loop */
t6=((C_word*)((C_word*)t0)[3])[1];
f_2544(t6,((C_word*)t0)[2],t3,t4,t5);}

/* eqv?-hash in k1945 */
static void C_ccall f_2483(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3rv,(void*)f_2483r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_2483r(t0,t1,t2,t3);}}

static void C_ccall f_2483r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word *a=C_alloc(7);
t4=(C_word)C_vemptyp(t3);
t5=(C_truep(t4)?C_fix(536870912):(C_word)C_slot(t3,C_fix(0)));
t6=(C_word)C_i_check_exact_2(t5,lf[16]);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2493,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnump(t2))){
t8=t7;
f_2493(2,t8,t2);}
else{
if(C_truep((C_word)C_charp(t2))){
t8=t7;
f_2493(2,t8,(C_word)C_fix((C_word)C_character_code(t2)));}
else{
switch(t2){
case C_SCHEME_TRUE:
t8=t7;
f_2493(2,t8,C_fix(256));
case C_SCHEME_FALSE:
t8=t7;
f_2493(2,t8,C_fix(257));
default:
if(C_truep((C_word)C_i_nullp(t2))){
t8=t7;
f_2493(2,t8,C_fix(258));}
else{
if(C_truep((C_word)C_eofp(t2))){
t8=t7;
f_2493(2,t8,C_fix(259));}
else{
if(C_truep((C_word)C_i_symbolp(t2))){
t8=(C_word)C_slot(t2,C_fix(1));
t9=t7;
f_2493(2,t9,(C_word)C_hash_string(t8));}
else{
if(C_truep((C_word)C_i_numberp(t2))){
if(C_truep((C_word)C_i_flonump(t2))){
t8=(C_word)C_subbyte(t2,C_fix(7));
t9=(C_word)C_subbyte(t2,C_fix(6));
t10=(C_word)C_subbyte(t2,C_fix(5));
t11=(C_word)C_subbyte(t2,C_fix(4));
t12=(C_word)C_subbyte(t2,C_fix(3));
t13=(C_word)C_subbyte(t2,C_fix(2));
t14=(C_word)C_subbyte(t2,C_fix(1));
t15=(C_word)C_subbyte(t2,C_fix(0));
t16=(C_word)C_fixnum_shift_left(t15,C_fix(1));
t17=(C_word)C_u_fixnum_plus(t14,t16);
t18=(C_word)C_fixnum_shift_left(t17,C_fix(1));
t19=(C_word)C_u_fixnum_plus(t13,t18);
t20=(C_word)C_fixnum_shift_left(t19,C_fix(1));
t21=(C_word)C_u_fixnum_plus(t12,t20);
t22=(C_word)C_fixnum_shift_left(t21,C_fix(1));
t23=(C_word)C_u_fixnum_plus(t11,t22);
t24=(C_word)C_fixnum_shift_left(t23,C_fix(1));
t25=(C_word)C_u_fixnum_plus(t10,t24);
t26=(C_word)C_fixnum_shift_left(t25,C_fix(1));
t27=(C_word)C_u_fixnum_plus(t9,t26);
t28=(C_word)C_fixnum_shift_left(t27,C_fix(1));
t29=(C_word)C_u_fixnum_plus(t8,t28);
t30=t7;
f_2493(2,t30,(C_word)C_fixnum_times(C_fix(331804471),t29));}
else{
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2472,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
/* srfi-69.scm: 166  ##sys#number-hash-hook */
t9=*((C_word*)lf[0]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t2);}}
else{
if(C_truep((C_word)C_blockp(t2))){
/* srfi-69.scm: 185  *equal?-hash */
f_2524(t7,t2);}
else{
t8=t7;
f_2493(2,t8,C_fix(262));}}}}}}}}}

/* k2470 in eqv?-hash in k1945 */
static void C_ccall f_2472(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_2493(2,t2,(C_word)C_fix(t1));}

/* k2491 in eqv?-hash in k1945 */
static void C_ccall f_2493(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_fixnum_lessp(t1,C_fix(0));
t3=(C_truep(t2)?(C_word)C_u_fixnum_negate(t1):t1);
t4=(C_word)C_u_fixnum_and(C_fix((C_word)C_MOST_POSITIVE_FIXNUM),t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_fixnum_modulo(t4,((C_word*)t0)[2]));}

/* eq?-hash in k1945 */
static void C_ccall f_2299(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3rv,(void*)f_2299r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_2299r(t0,t1,t2,t3);}}

static void C_ccall f_2299r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a=C_alloc(4);
t4=(C_word)C_vemptyp(t3);
t5=(C_truep(t4)?C_fix(536870912):(C_word)C_slot(t3,C_fix(0)));
t6=(C_word)C_i_check_exact_2(t5,lf[14]);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2309,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnump(t2))){
t8=t7;
f_2309(2,t8,t2);}
else{
if(C_truep((C_word)C_charp(t2))){
t8=t7;
f_2309(2,t8,(C_word)C_fix((C_word)C_character_code(t2)));}
else{
switch(t2){
case C_SCHEME_TRUE:
t8=t7;
f_2309(2,t8,C_fix(256));
case C_SCHEME_FALSE:
t8=t7;
f_2309(2,t8,C_fix(257));
default:
if(C_truep((C_word)C_i_nullp(t2))){
t8=t7;
f_2309(2,t8,C_fix(258));}
else{
if(C_truep((C_word)C_eofp(t2))){
t8=t7;
f_2309(2,t8,C_fix(259));}
else{
if(C_truep((C_word)C_i_symbolp(t2))){
t8=(C_word)C_slot(t2,C_fix(1));
t9=t7;
f_2309(2,t9,(C_word)C_hash_string(t8));}
else{
if(C_truep((C_word)C_blockp(t2))){
/* srfi-69.scm: 185  *equal?-hash */
f_2524(t7,t2);}
else{
t8=t7;
f_2309(2,t8,C_fix(262));}}}}}}}}

/* k2307 in eq?-hash in k1945 */
static void C_ccall f_2309(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_fixnum_lessp(t1,C_fix(0));
t3=(C_truep(t2)?(C_word)C_u_fixnum_negate(t1):t1);
t4=(C_word)C_u_fixnum_and(C_fix((C_word)C_MOST_POSITIVE_FIXNUM),t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_fixnum_modulo(t4,((C_word*)t0)[2]));}

/* keyword-hash in k1945 */
static void C_ccall f_2195(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3rv,(void*)f_2195r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_2195r(t0,t1,t2,t3);}}

static void C_ccall f_2195r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t4=(C_word)C_vemptyp(t3);
t5=(C_truep(t4)?C_fix(536870912):(C_word)C_slot(t3,C_fix(0)));
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2202,a[2]=t1,a[3]=t2,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm: 221  ##sys#check-keyword */
t7=*((C_word*)lf[9]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,t2,lf[13]);}

/* k2200 in keyword-hash in k1945 */
static void C_ccall f_2202(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
t2=(C_word)C_i_check_exact_2(((C_word*)t0)[4],lf[13]);
t3=((C_word*)t0)[3];
t4=(C_word)C_slot(t3,C_fix(1));
t5=(C_word)C_hash_string(t4);
t6=(C_word)C_fixnum_lessp(t5,C_fix(0));
t7=(C_truep(t6)?(C_word)C_u_fixnum_negate(t5):t5);
t8=(C_word)C_u_fixnum_and(C_fix((C_word)C_MOST_POSITIVE_FIXNUM),t7);
t9=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_fixnum_modulo(t8,((C_word*)t0)[4]));}

/* ##sys#check-keyword in k1945 */
static void C_ccall f_2169(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3rv,(void*)f_2169r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_2169r(t0,t1,t2,t3);}}

static void C_ccall f_2169r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2176,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm: 208  keyword? */
t5=*((C_word*)lf[12]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k2174 in ##sys#check-keyword in k1945 */
static void C_ccall f_2176(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(C_word)C_vemptyp(((C_word*)t0)[3]);
t3=(C_truep(t2)?C_SCHEME_FALSE:(C_word)C_slot(((C_word*)t0)[3],C_fix(0)));
/* srfi-69.scm: 209  ##sys#signal-hook */
t4=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,((C_word*)t0)[4],lf[10],t3,lf[11],((C_word*)t0)[2]);}}

/* symbol-hash in k1945 */
static void C_ccall f_2125(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3rv,(void*)f_2125r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_2125r(t0,t1,t2,t3);}}

static void C_ccall f_2125r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
t4=(C_word)C_vemptyp(t3);
t5=(C_truep(t4)?C_fix(536870912):(C_word)C_slot(t3,C_fix(0)));
t6=(C_word)C_i_check_symbol_2(t2,lf[8]);
t7=(C_word)C_i_check_exact_2(t5,lf[8]);
t8=t2;
t9=(C_word)C_slot(t8,C_fix(1));
t10=(C_word)C_hash_string(t9);
t11=(C_word)C_fixnum_lessp(t10,C_fix(0));
t12=(C_truep(t11)?(C_word)C_u_fixnum_negate(t10):t10);
t13=(C_word)C_u_fixnum_and(C_fix((C_word)C_MOST_POSITIVE_FIXNUM),t12);
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,(C_word)C_fixnum_modulo(t13,t5));}

/* object-uid-hash in k1945 */
static void C_ccall f_2084(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3rv,(void*)f_2084r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_2084r(t0,t1,t2,t3);}}

static void C_ccall f_2084r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(4);
t4=(C_word)C_vemptyp(t3);
t5=(C_truep(t4)?C_fix(536870912):(C_word)C_slot(t3,C_fix(0)));
t6=(C_word)C_i_check_exact_2(t5,lf[7]);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2094,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-69.scm: 185  *equal?-hash */
f_2524(t7,t2);}

/* k2092 in object-uid-hash in k1945 */
static void C_ccall f_2094(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_fixnum_lessp(t1,C_fix(0));
t3=(C_truep(t2)?(C_word)C_u_fixnum_negate(t1):t1);
t4=(C_word)C_u_fixnum_and(C_fix((C_word)C_MOST_POSITIVE_FIXNUM),t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_fixnum_modulo(t4,((C_word*)t0)[2]));}

/* number-hash in k1945 */
static void C_ccall f_1955(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3rv,(void*)f_1955r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_1955r(t0,t1,t2,t3);}}

static void C_ccall f_1955r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t4=(C_word)C_vemptyp(t3);
t5=(C_truep(t4)?C_fix(536870912):(C_word)C_slot(t3,C_fix(0)));
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1962,a[2]=t1,a[3]=t2,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_numberp(t2))){
t7=t6;
f_1962(2,t7,C_SCHEME_UNDEFINED);}
else{
/* srfi-69.scm: 174  ##sys#signal-hook */
t7=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t6,lf[5],lf[2],lf[6],t2);}}

/* k1960 in number-hash in k1945 */
static void C_ccall f_1962(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1962,2,t0,t1);}
t2=(C_word)C_i_check_exact_2(((C_word*)t0)[4],lf[2]);
t3=((C_word*)t0)[3];
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1968,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnump(t3))){
t5=t4;
f_1968(t5,*((C_word*)lf[3]+1));}
else{
if(C_truep((C_word)C_i_flonump(t3))){
t5=(C_word)C_subbyte(t3,C_fix(7));
t6=(C_word)C_subbyte(t3,C_fix(6));
t7=(C_word)C_subbyte(t3,C_fix(5));
t8=(C_word)C_subbyte(t3,C_fix(4));
t9=(C_word)C_subbyte(t3,C_fix(3));
t10=(C_word)C_subbyte(t3,C_fix(2));
t11=(C_word)C_subbyte(t3,C_fix(1));
t12=(C_word)C_subbyte(t3,C_fix(0));
t13=(C_word)C_fixnum_shift_left(t12,C_fix(1));
t14=(C_word)C_u_fixnum_plus(t11,t13);
t15=(C_word)C_fixnum_shift_left(t14,C_fix(1));
t16=(C_word)C_u_fixnum_plus(t10,t15);
t17=(C_word)C_fixnum_shift_left(t16,C_fix(1));
t18=(C_word)C_u_fixnum_plus(t9,t17);
t19=(C_word)C_fixnum_shift_left(t18,C_fix(1));
t20=(C_word)C_u_fixnum_plus(t8,t19);
t21=(C_word)C_fixnum_shift_left(t20,C_fix(1));
t22=(C_word)C_u_fixnum_plus(t7,t21);
t23=(C_word)C_fixnum_shift_left(t22,C_fix(1));
t24=(C_word)C_u_fixnum_plus(t6,t23);
t25=(C_word)C_fixnum_shift_left(t24,C_fix(1));
t26=(C_word)C_u_fixnum_plus(t5,t25);
t27=t4;
f_1968(t27,(C_word)C_fixnum_times(C_fix(331804471),t26));}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2064,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* srfi-69.scm: 166  ##sys#number-hash-hook */
t6=*((C_word*)lf[0]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t3);}}}

/* k2062 in k1960 in number-hash in k1945 */
static void C_ccall f_2064(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_1968(t2,(C_word)C_fix(t1));}

/* k1966 in k1960 in number-hash in k1945 */
static void C_fcall f_1968(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_fixnum_lessp(t1,C_fix(0));
t3=(C_truep(t2)?(C_word)C_u_fixnum_negate(t1):t1);
t4=(C_word)C_u_fixnum_and(C_fix((C_word)C_MOST_POSITIVE_FIXNUM),t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_fixnum_modulo(t4,((C_word*)t0)[2]));}

/* ##sys#number-hash-hook in k1945 */
static void C_ccall f_1949(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1949,3,t0,t1,t2);}
/* srfi-69.scm: 162  *equal?-hash */
f_2524(t1,t2);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[210] = {
{"toplevel:srfi_69_scm",(void*)C_srfi_69_toplevel},
{"f_1947:srfi_69_scm",(void*)f_1947},
{"f_5380:srfi_69_scm",(void*)f_5380},
{"f_5390:srfi_69_scm",(void*)f_5390},
{"f_5402:srfi_69_scm",(void*)f_5402},
{"f_5459:srfi_69_scm",(void*)f_5459},
{"f_5478:srfi_69_scm",(void*)f_5478},
{"f_5417:srfi_69_scm",(void*)f_5417},
{"f_5500:srfi_69_scm",(void*)f_5500},
{"f_4423:srfi_69_scm",(void*)f_4423},
{"f_5358:srfi_69_scm",(void*)f_5358},
{"f_5365:srfi_69_scm",(void*)f_5365},
{"f_5370:srfi_69_scm",(void*)f_5370},
{"f_5378:srfi_69_scm",(void*)f_5378},
{"f_5346:srfi_69_scm",(void*)f_5346},
{"f_5353:srfi_69_scm",(void*)f_5353},
{"f_5334:srfi_69_scm",(void*)f_5334},
{"f_5341:srfi_69_scm",(void*)f_5341},
{"f_5322:srfi_69_scm",(void*)f_5322},
{"f_5329:srfi_69_scm",(void*)f_5329},
{"f_5256:srfi_69_scm",(void*)f_5256},
{"f_5268:srfi_69_scm",(void*)f_5268},
{"f_5284:srfi_69_scm",(void*)f_5284},
{"f_5312:srfi_69_scm",(void*)f_5312},
{"f_5207:srfi_69_scm",(void*)f_5207},
{"f_5219:srfi_69_scm",(void*)f_5219},
{"f_5238:srfi_69_scm",(void*)f_5238},
{"f_5229:srfi_69_scm",(void*)f_5229},
{"f_5142:srfi_69_scm",(void*)f_5142},
{"f_5157:srfi_69_scm",(void*)f_5157},
{"f_5173:srfi_69_scm",(void*)f_5173},
{"f_5077:srfi_69_scm",(void*)f_5077},
{"f_5092:srfi_69_scm",(void*)f_5092},
{"f_5108:srfi_69_scm",(void*)f_5108},
{"f_5048:srfi_69_scm",(void*)f_5048},
{"f_5055:srfi_69_scm",(void*)f_5055},
{"f_5060:srfi_69_scm",(void*)f_5060},
{"f_5058:srfi_69_scm",(void*)f_5058},
{"f_4975:srfi_69_scm",(void*)f_4975},
{"f_4990:srfi_69_scm",(void*)f_4990},
{"f_5006:srfi_69_scm",(void*)f_5006},
{"f_4959:srfi_69_scm",(void*)f_4959},
{"f_4973:srfi_69_scm",(void*)f_4973},
{"f_4947:srfi_69_scm",(void*)f_4947},
{"f_4882:srfi_69_scm",(void*)f_4882},
{"f_4894:srfi_69_scm",(void*)f_4894},
{"f_4917:srfi_69_scm",(void*)f_4917},
{"f_4930:srfi_69_scm",(void*)f_4930},
{"f_4904:srfi_69_scm",(void*)f_4904},
{"f_4866:srfi_69_scm",(void*)f_4866},
{"f_4873:srfi_69_scm",(void*)f_4873},
{"f_4770:srfi_69_scm",(void*)f_4770},
{"f_4777:srfi_69_scm",(void*)f_4777},
{"f_4791:srfi_69_scm",(void*)f_4791},
{"f_4817:srfi_69_scm",(void*)f_4817},
{"f_4836:srfi_69_scm",(void*)f_4836},
{"f_4804:srfi_69_scm",(void*)f_4804},
{"f_4639:srfi_69_scm",(void*)f_4639},
{"f_4655:srfi_69_scm",(void*)f_4655},
{"f_4722:srfi_69_scm",(void*)f_4722},
{"f_4741:srfi_69_scm",(void*)f_4741},
{"f_4675:srfi_69_scm",(void*)f_4675},
{"f_4531:srfi_69_scm",(void*)f_4531},
{"f_4547:srfi_69_scm",(void*)f_4547},
{"f_4602:srfi_69_scm",(void*)f_4602},
{"f_4615:srfi_69_scm",(void*)f_4615},
{"f_4562:srfi_69_scm",(void*)f_4562},
{"f_4425:srfi_69_scm",(void*)f_4425},
{"f_4441:srfi_69_scm",(void*)f_4441},
{"f_4495:srfi_69_scm",(void*)f_4495},
{"f_4511:srfi_69_scm",(void*)f_4511},
{"f_4456:srfi_69_scm",(void*)f_4456},
{"f_4228:srfi_69_scm",(void*)f_4228},
{"f_4411:srfi_69_scm",(void*)f_4411},
{"f_4403:srfi_69_scm",(void*)f_4403},
{"f_4384:srfi_69_scm",(void*)f_4384},
{"f_4256:srfi_69_scm",(void*)f_4256},
{"f_4271:srfi_69_scm",(void*)f_4271},
{"f_4337:srfi_69_scm",(void*)f_4337},
{"f_4367:srfi_69_scm",(void*)f_4367},
{"f_4288:srfi_69_scm",(void*)f_4288},
{"f_4277:srfi_69_scm",(void*)f_4277},
{"f_4216:srfi_69_scm",(void*)f_4216},
{"f_4223:srfi_69_scm",(void*)f_4223},
{"f_4009:srfi_69_scm",(void*)f_4009},
{"f_4206:srfi_69_scm",(void*)f_4206},
{"f_4198:srfi_69_scm",(void*)f_4198},
{"f_4179:srfi_69_scm",(void*)f_4179},
{"f_4034:srfi_69_scm",(void*)f_4034},
{"f_4049:srfi_69_scm",(void*)f_4049},
{"f_4122:srfi_69_scm",(void*)f_4122},
{"f_4155:srfi_69_scm",(void*)f_4155},
{"f_4158:srfi_69_scm",(void*)f_4158},
{"f_4132:srfi_69_scm",(void*)f_4132},
{"f_4063:srfi_69_scm",(void*)f_4063},
{"f_4099:srfi_69_scm",(void*)f_4099},
{"f_4073:srfi_69_scm",(void*)f_4073},
{"f_3722:srfi_69_scm",(void*)f_3722},
{"f_3964:srfi_69_scm",(void*)f_3964},
{"f_3947:srfi_69_scm",(void*)f_3947},
{"f_3959:srfi_69_scm",(void*)f_3959},
{"f_3724:srfi_69_scm",(void*)f_3724},
{"f_3731:srfi_69_scm",(void*)f_3731},
{"f_3734:srfi_69_scm",(void*)f_3734},
{"f_3938:srfi_69_scm",(void*)f_3938},
{"f_3930:srfi_69_scm",(void*)f_3930},
{"f_3911:srfi_69_scm",(void*)f_3911},
{"f_3758:srfi_69_scm",(void*)f_3758},
{"f_3773:srfi_69_scm",(void*)f_3773},
{"f_3850:srfi_69_scm",(void*)f_3850},
{"f_3887:srfi_69_scm",(void*)f_3887},
{"f_3890:srfi_69_scm",(void*)f_3890},
{"f_3878:srfi_69_scm",(void*)f_3878},
{"f_3860:srfi_69_scm",(void*)f_3860},
{"f_3787:srfi_69_scm",(void*)f_3787},
{"f_3827:srfi_69_scm",(void*)f_3827},
{"f_3815:srfi_69_scm",(void*)f_3815},
{"f_3797:srfi_69_scm",(void*)f_3797},
{"f_3713:srfi_69_scm",(void*)f_3713},
{"f_3601:srfi_69_scm",(void*)f_3601},
{"f_3611:srfi_69_scm",(void*)f_3611},
{"f_3616:srfi_69_scm",(void*)f_3616},
{"f_3678:srfi_69_scm",(void*)f_3678},
{"f_3699:srfi_69_scm",(void*)f_3699},
{"f_3672:srfi_69_scm",(void*)f_3672},
{"f_3575:srfi_69_scm",(void*)f_3575},
{"f_3582:srfi_69_scm",(void*)f_3582},
{"f_3585:srfi_69_scm",(void*)f_3585},
{"f_3508:srfi_69_scm",(void*)f_3508},
{"f_3531:srfi_69_scm",(void*)f_3531},
{"f_3547:srfi_69_scm",(void*)f_3547},
{"f_3518:srfi_69_scm",(void*)f_3518},
{"f_3588:srfi_69_scm",(void*)f_3588},
{"f_3481:srfi_69_scm",(void*)f_3481},
{"f_3469:srfi_69_scm",(void*)f_3469},
{"f_3460:srfi_69_scm",(void*)f_3460},
{"f_3451:srfi_69_scm",(void*)f_3451},
{"f_3442:srfi_69_scm",(void*)f_3442},
{"f_3433:srfi_69_scm",(void*)f_3433},
{"f_3424:srfi_69_scm",(void*)f_3424},
{"f_3415:srfi_69_scm",(void*)f_3415},
{"f_3406:srfi_69_scm",(void*)f_3406},
{"f_3400:srfi_69_scm",(void*)f_3400},
{"f_3037:srfi_69_scm",(void*)f_3037},
{"f_3390:srfi_69_scm",(void*)f_3390},
{"f_3393:srfi_69_scm",(void*)f_3393},
{"f_3115:srfi_69_scm",(void*)f_3115},
{"f_3370:srfi_69_scm",(void*)f_3370},
{"f_3373:srfi_69_scm",(void*)f_3373},
{"f_3118:srfi_69_scm",(void*)f_3118},
{"f_3338:srfi_69_scm",(void*)f_3338},
{"f_3344:srfi_69_scm",(void*)f_3344},
{"f_3121:srfi_69_scm",(void*)f_3121},
{"f_3156:srfi_69_scm",(void*)f_3156},
{"f_3177:srfi_69_scm",(void*)f_3177},
{"f_3183:srfi_69_scm",(void*)f_3183},
{"f_3275:srfi_69_scm",(void*)f_3275},
{"f_3278:srfi_69_scm",(void*)f_3278},
{"f_3250:srfi_69_scm",(void*)f_3250},
{"f_3253:srfi_69_scm",(void*)f_3253},
{"f_3240:srfi_69_scm",(void*)f_3240},
{"f_3222:srfi_69_scm",(void*)f_3222},
{"f_3209:srfi_69_scm",(void*)f_3209},
{"f_3199:srfi_69_scm",(void*)f_3199},
{"f_3186:srfi_69_scm",(void*)f_3186},
{"f_3167:srfi_69_scm",(void*)f_3167},
{"f_3124:srfi_69_scm",(void*)f_3124},
{"f_3127:srfi_69_scm",(void*)f_3127},
{"f_3131:srfi_69_scm",(void*)f_3131},
{"f_3147:srfi_69_scm",(void*)f_3147},
{"f_3134:srfi_69_scm",(void*)f_3134},
{"f_3039:srfi_69_scm",(void*)f_3039},
{"f_3013:srfi_69_scm",(void*)f_3013},
{"f_3017:srfi_69_scm",(void*)f_3017},
{"f_2983:srfi_69_scm",(void*)f_2983},
{"f_2989:srfi_69_scm",(void*)f_2989},
{"f_2941:srfi_69_scm",(void*)f_2941},
{"f_2900:srfi_69_scm",(void*)f_2900},
{"f_2858:srfi_69_scm",(void*)f_2858},
{"f_2868:srfi_69_scm",(void*)f_2868},
{"f_2524:srfi_69_scm",(void*)f_2524},
{"f_2623:srfi_69_scm",(void*)f_2623},
{"f_2836:srfi_69_scm",(void*)f_2836},
{"f_2815:srfi_69_scm",(void*)f_2815},
{"f_2807:srfi_69_scm",(void*)f_2807},
{"f_2786:srfi_69_scm",(void*)f_2786},
{"f_2760:srfi_69_scm",(void*)f_2760},
{"f_2592:srfi_69_scm",(void*)f_2592},
{"f_2608:srfi_69_scm",(void*)f_2608},
{"f_2527:srfi_69_scm",(void*)f_2527},
{"f_2544:srfi_69_scm",(void*)f_2544},
{"f_2578:srfi_69_scm",(void*)f_2578},
{"f_2483:srfi_69_scm",(void*)f_2483},
{"f_2472:srfi_69_scm",(void*)f_2472},
{"f_2493:srfi_69_scm",(void*)f_2493},
{"f_2299:srfi_69_scm",(void*)f_2299},
{"f_2309:srfi_69_scm",(void*)f_2309},
{"f_2195:srfi_69_scm",(void*)f_2195},
{"f_2202:srfi_69_scm",(void*)f_2202},
{"f_2169:srfi_69_scm",(void*)f_2169},
{"f_2176:srfi_69_scm",(void*)f_2176},
{"f_2125:srfi_69_scm",(void*)f_2125},
{"f_2084:srfi_69_scm",(void*)f_2084},
{"f_2094:srfi_69_scm",(void*)f_2094},
{"f_1955:srfi_69_scm",(void*)f_1955},
{"f_1962:srfi_69_scm",(void*)f_1962},
{"f_2064:srfi_69_scm",(void*)f_2064},
{"f_1968:srfi_69_scm",(void*)f_1968},
{"f_1949:srfi_69_scm",(void*)f_1949},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
