# Related Resources

#[https://github.com/yuriy-chumak/ol, Otus Lisp] is a related language. It adds features such as FFI to be able to write 
graphical programs and interface with other external libraries.

#[https://small.r7rs.org/attachment/r7rs.pdf, R7RS Scheme (pdf)]
