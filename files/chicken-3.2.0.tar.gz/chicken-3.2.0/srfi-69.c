/* Generated from srfi-69.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-04-30 11:19
   Version 3.1.10 - linux-unix-gnu-x86	[ manyargs dload ptables applyhook ]
   SVN rev. 10602	compiled 2008-04-30 on galinha (Linux)
   command line: srfi-69.scm -quiet -no-trace -optimize-level 2 -include-path . -explicit-use -output-file srfi-69.c -extend private-namespace.scm
   unit: srfi_69
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);

static C_TLS C_word lf[120];
static double C_possibly_force_alignment;
static C_char C_TLS li0[] C_aligned={C_lihdr(0,0,31),40,35,35,115,114,102,105,45,54,57,35,117,110,98,111,117,110,100,45,118,97,108,117,101,45,116,104,117,110,107,41,0};
static C_char C_TLS li1[] C_aligned={C_lihdr(0,0,29),40,35,35,115,121,115,35,110,117,109,98,101,114,45,104,97,115,104,45,104,111,111,107,32,111,98,106,49,41,0,0,0};
static C_char C_TLS li2[] C_aligned={C_lihdr(0,0,24),40,110,117,109,98,101,114,45,104,97,115,104,32,111,98,106,51,32,46,32,103,50,52,41};
static C_char C_TLS li3[] C_aligned={C_lihdr(0,0,34),40,35,35,115,114,102,105,45,54,57,35,37,111,98,106,101,99,116,45,117,105,100,45,104,97,115,104,32,111,98,106,49,51,41,0,0,0,0,0,0};
static C_char C_TLS li4[] C_aligned={C_lihdr(0,0,31),40,111,98,106,101,99,116,45,117,105,100,45,104,97,115,104,32,111,98,106,49,53,32,46,32,103,49,52,49,54,41,0};
static C_char C_TLS li5[] C_aligned={C_lihdr(0,0,27),40,115,121,109,98,111,108,45,104,97,115,104,32,111,98,106,50,52,32,46,32,103,50,51,50,53,41,0,0,0,0,0};
static C_char C_TLS li6[] C_aligned={C_lihdr(0,0,31),40,35,35,115,121,115,35,99,104,101,99,107,45,107,101,121,119,111,114,100,32,120,51,51,32,46,32,121,51,52,41,0};
static C_char C_TLS li7[] C_aligned={C_lihdr(0,0,28),40,107,101,121,119,111,114,100,45,104,97,115,104,32,111,98,106,51,54,32,46,32,103,51,53,51,55,41,0,0,0,0};
static C_char C_TLS li8[] C_aligned={C_lihdr(0,0,27),40,35,35,115,114,102,105,45,54,57,35,37,101,113,63,45,104,97,115,104,32,111,98,106,52,53,41,0,0,0,0,0};
static C_char C_TLS li9[] C_aligned={C_lihdr(0,0,24),40,101,113,63,45,104,97,115,104,32,111,98,106,52,55,32,46,32,103,52,54,52,56,41};
static C_char C_TLS li10[] C_aligned={C_lihdr(0,0,28),40,35,35,115,114,102,105,45,54,57,35,37,101,113,118,63,45,104,97,115,104,32,111,98,106,53,53,41,0,0,0,0};
static C_char C_TLS li11[] C_aligned={C_lihdr(0,0,25),40,101,113,118,63,45,104,97,115,104,32,111,98,106,53,55,32,46,32,103,53,54,53,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li12[] C_aligned={C_lihdr(0,0,22),40,108,111,111,112,32,104,115,104,55,53,32,105,55,54,32,108,101,110,55,55,41,0,0};
static C_char C_TLS li13[] C_aligned={C_lihdr(0,0,42),40,118,101,99,116,111,114,45,104,97,115,104,32,111,98,106,54,57,32,115,101,101,100,55,48,32,100,101,112,116,104,55,49,32,115,116,97,114,116,55,50,41,0,0,0,0,0,0};
static C_char C_TLS li14[] C_aligned={C_lihdr(0,0,37),40,114,101,99,117,114,115,105,118,101,45,97,116,111,109,105,99,45,104,97,115,104,32,111,98,106,55,57,32,100,101,112,116,104,56,48,41,0,0,0};
static C_char C_TLS li15[] C_aligned={C_lihdr(0,0,30),40,114,101,99,117,114,115,105,118,101,45,104,97,115,104,32,111,98,106,56,55,32,100,101,112,116,104,56,56,41,0,0};
static C_char C_TLS li16[] C_aligned={C_lihdr(0,0,30),40,35,35,115,114,102,105,45,54,57,35,37,101,113,117,97,108,63,45,104,97,115,104,32,111,98,106,54,53,41,0,0};
static C_char C_TLS li17[] C_aligned={C_lihdr(0,0,27),40,101,113,117,97,108,63,45,104,97,115,104,32,111,98,106,57,51,32,46,32,103,57,50,57,52,41,0,0,0,0,0};
static C_char C_TLS li18[] C_aligned={C_lihdr(0,0,30),40,115,116,114,105,110,103,45,104,97,115,104,32,115,116,114,49,48,50,32,46,32,103,49,48,49,49,48,51,41,0,0};
static C_char C_TLS li19[] C_aligned={C_lihdr(0,0,33),40,115,116,114,105,110,103,45,99,105,45,104,97,115,104,32,115,116,114,49,49,50,32,46,32,103,49,49,49,49,49,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li20[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li21[] C_aligned={C_lihdr(0,0,53),40,35,35,115,114,102,105,45,54,57,35,104,97,115,104,45,116,97,98,108,101,45,99,97,110,111,110,105,99,97,108,45,108,101,110,103,116,104,32,116,97,98,49,50,50,32,114,101,113,49,50,51,41,0,0,0};
static C_char C_TLS li22[] C_aligned={C_lihdr(0,0,114),40,37,109,97,107,101,45,104,97,115,104,45,116,97,98,108,101,32,116,101,115,116,49,51,51,32,104,97,115,104,49,51,52,32,108,101,110,49,51,53,32,109,105,110,45,108,111,97,100,49,51,54,32,109,97,120,45,108,111,97,100,49,51,55,32,119,101,97,107,45,107,101,121,115,49,51,56,32,119,101,97,107,45,118,97,108,117,101,115,49,51,57,32,105,110,105,116,105,97,108,49,52,48,32,46,32,103,49,51,50,49,52,49,41,0,0,0,0,0,0};
static C_char C_TLS li23[] C_aligned={C_lihdr(0,0,19),40,105,110,118,97,114,103,45,101,114,114,32,109,115,103,49,56,56,41,0,0,0,0,0};
static C_char C_TLS li24[] C_aligned={C_lihdr(0,0,8),40,102,95,49,56,48,50,41};
static C_char C_TLS li25[] C_aligned={C_lihdr(0,0,14),40,108,111,111,112,32,97,114,103,115,49,56,53,41,0,0};
static C_char C_TLS li26[] C_aligned={C_lihdr(0,0,33),40,109,97,107,101,45,104,97,115,104,45,116,97,98,108,101,32,46,32,97,114,103,117,109,101,110,116,115,48,49,53,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li27[] C_aligned={C_lihdr(0,0,20),40,104,97,115,104,45,116,97,98,108,101,63,32,111,98,106,50,49,50,41,0,0,0,0};
static C_char C_TLS li28[] C_aligned={C_lihdr(0,0,23),40,104,97,115,104,45,116,97,98,108,101,45,115,105,122,101,32,104,116,50,49,51,41,0};
static C_char C_TLS li29[] C_aligned={C_lihdr(0,0,39),40,104,97,115,104,45,116,97,98,108,101,45,101,113,117,105,118,97,108,101,110,99,101,45,102,117,110,99,116,105,111,110,32,104,116,50,49,53,41,0};
static C_char C_TLS li30[] C_aligned={C_lihdr(0,0,32),40,104,97,115,104,45,116,97,98,108,101,45,104,97,115,104,45,102,117,110,99,116,105,111,110,32,104,116,50,49,55,41};
static C_char C_TLS li31[] C_aligned={C_lihdr(0,0,27),40,104,97,115,104,45,116,97,98,108,101,45,109,105,110,45,108,111,97,100,32,104,116,50,49,57,41,0,0,0,0,0};
static C_char C_TLS li32[] C_aligned={C_lihdr(0,0,27),40,104,97,115,104,45,116,97,98,108,101,45,109,97,120,45,108,111,97,100,32,104,116,50,50,49,41,0,0,0,0,0};
static C_char C_TLS li33[] C_aligned={C_lihdr(0,0,28),40,104,97,115,104,45,116,97,98,108,101,45,119,101,97,107,45,107,101,121,115,32,104,116,50,50,51,41,0,0,0,0};
static C_char C_TLS li34[] C_aligned={C_lihdr(0,0,30),40,104,97,115,104,45,116,97,98,108,101,45,119,101,97,107,45,118,97,108,117,101,115,32,104,116,50,50,53,41,0,0};
static C_char C_TLS li35[] C_aligned={C_lihdr(0,0,31),40,104,97,115,104,45,116,97,98,108,101,45,104,97,115,45,105,110,105,116,105,97,108,63,32,104,116,50,50,55,41,0};
static C_char C_TLS li36[] C_aligned={C_lihdr(0,0,26),40,104,97,115,104,45,116,97,98,108,101,45,105,110,105,116,105,97,108,32,104,116,50,50,57,41,0,0,0,0,0,0};
static C_char C_TLS li37[] C_aligned={C_lihdr(0,0,21),40,99,111,112,121,45,108,111,111,112,32,98,117,99,107,101,116,50,52,49,41,0,0,0};
static C_char C_TLS li38[] C_aligned={C_lihdr(0,0,12),40,100,111,50,51,55,32,105,50,51,57,41,0,0,0,0};
static C_char C_TLS li39[] C_aligned={C_lihdr(0,0,34),40,35,35,115,114,102,105,45,54,57,35,37,104,97,115,104,45,116,97,98,108,101,45,99,111,112,121,32,104,116,50,51,51,41,0,0,0,0,0,0};
static C_char C_TLS li40[] C_aligned={C_lihdr(0,0,23),40,104,97,115,104,45,116,97,98,108,101,45,99,111,112,121,32,104,116,50,52,54,41,0};
static C_char C_TLS li41[] C_aligned={C_lihdr(0,0,16),40,108,111,111,112,32,98,117,99,107,101,116,50,53,55,41};
static C_char C_TLS li42[] C_aligned={C_lihdr(0,0,12),40,100,111,50,53,51,32,105,50,53,53,41,0,0,0,0};
static C_char C_TLS li43[] C_aligned={C_lihdr(0,0,53),40,35,35,115,114,102,105,45,54,57,35,104,97,115,104,45,116,97,98,108,101,45,114,101,104,97,115,104,32,118,101,99,49,50,52,56,32,118,101,99,50,50,52,57,32,104,97,115,104,50,53,48,41,0,0,0};
static C_char C_TLS li44[] C_aligned={C_lihdr(0,0,16),40,108,111,111,112,32,98,117,99,107,101,116,50,56,55,41};
static C_char C_TLS li45[] C_aligned={C_lihdr(0,0,16),40,108,111,111,112,32,98,117,99,107,101,116,50,57,54,41};
static C_char C_TLS li46[] C_aligned={C_lihdr(0,0,10),40,114,101,45,101,110,116,101,114,41,0,0,0,0,0,0};
static C_char C_TLS li47[] C_aligned={C_lihdr(0,0,61),40,35,35,115,114,102,105,45,54,57,35,37,104,97,115,104,45,116,97,98,108,101,45,117,112,100,97,116,101,33,32,104,116,50,54,55,32,107,101,121,50,54,56,32,102,117,110,99,50,54,57,32,116,104,117,110,107,50,55,48,41,0,0,0};
static C_char C_TLS li48[] C_aligned={C_lihdr(0,0,26),40,98,111,100,121,51,49,49,32,102,117,110,99,51,49,55,32,116,104,117,110,107,51,49,56,41,0,0,0,0,0,0};
static C_char C_TLS li49[] C_aligned={C_lihdr(0,0,8),40,102,95,50,53,50,50,41};
static C_char C_TLS li50[] C_aligned={C_lihdr(0,0,26),40,100,101,102,45,116,104,117,110,107,51,49,52,32,37,102,117,110,99,51,48,57,51,50,51,41,0,0,0,0,0,0};
static C_char C_TLS li51[] C_aligned={C_lihdr(0,0,13),40,100,101,102,45,102,117,110,99,51,49,51,41,0,0,0};
static C_char C_TLS li52[] C_aligned={C_lihdr(0,0,43),40,104,97,115,104,45,116,97,98,108,101,45,117,112,100,97,116,101,33,32,104,116,51,48,54,32,107,101,121,51,48,55,32,46,32,103,51,48,53,51,48,56,41,0,0,0,0,0};
static C_char C_TLS li53[] C_aligned={C_lihdr(0,0,7),40,97,50,53,56,54,41,0};
static C_char C_TLS li54[] C_aligned={C_lihdr(0,0,56),40,104,97,115,104,45,116,97,98,108,101,45,117,112,100,97,116,101,33,47,100,101,102,97,117,108,116,32,104,116,51,51,50,32,107,101,121,51,51,51,32,102,117,110,99,51,51,52,32,100,101,102,51,51,53,41};
static C_char C_TLS li55[] C_aligned={C_lihdr(0,0,14),40,116,104,117,110,107,32,46,32,95,51,52,50,41,0,0};
static C_char C_TLS li56[] C_aligned={C_lihdr(0,0,37),40,104,97,115,104,45,116,97,98,108,101,45,115,101,116,33,32,104,116,51,51,56,32,107,101,121,51,51,57,32,118,97,108,51,52,48,41,0,0,0};
static C_char C_TLS li57[] C_aligned={C_lihdr(0,0,16),40,108,111,111,112,32,98,117,99,107,101,116,51,53,52,41};
static C_char C_TLS li58[] C_aligned={C_lihdr(0,0,16),40,108,111,111,112,32,98,117,99,107,101,116,51,53,56,41};
static C_char C_TLS li59[] C_aligned={C_lihdr(0,0,47),40,35,35,115,114,102,105,45,54,57,35,37,104,97,115,104,45,116,97,98,108,101,45,114,101,102,32,104,116,51,52,54,32,107,101,121,51,52,55,32,100,101,102,51,52,56,41,0};
static C_char C_TLS li60[] C_aligned={C_lihdr(0,0,7),40,97,50,55,50,53,41,0};
static C_char C_TLS li61[] C_aligned={C_lihdr(0,0,48),40,104,97,115,104,45,116,97,98,108,101,45,114,101,102,47,100,101,102,97,117,108,116,32,104,116,51,55,48,32,107,101,121,51,55,49,32,100,101,102,97,117,108,116,51,55,50,41};
static C_char C_TLS li62[] C_aligned={C_lihdr(0,0,33),40,104,97,115,104,45,116,97,98,108,101,45,101,120,105,115,116,115,63,32,104,116,51,55,52,32,107,101,121,51,55,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li63[] C_aligned={C_lihdr(0,0,16),40,108,111,111,112,32,98,117,99,107,101,116,51,56,57,41};
static C_char C_TLS li64[] C_aligned={C_lihdr(0,0,24),40,108,111,111,112,32,112,114,101,118,51,57,54,32,98,117,99,107,101,116,51,57,55,41};
static C_char C_TLS li65[] C_aligned={C_lihdr(0,0,33),40,104,97,115,104,45,116,97,98,108,101,45,100,101,108,101,116,101,33,32,104,116,51,55,56,32,107,101,121,51,55,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li66[] C_aligned={C_lihdr(0,0,24),40,108,111,111,112,32,112,114,101,118,52,49,51,32,98,117,99,107,101,116,52,49,52,41};
static C_char C_TLS li67[] C_aligned={C_lihdr(0,0,12),40,100,111,52,48,57,32,105,52,49,49,41,0,0,0,0};
static C_char C_TLS li68[] C_aligned={C_lihdr(0,0,34),40,104,97,115,104,45,116,97,98,108,101,45,114,101,109,111,118,101,33,32,104,116,52,48,52,32,102,117,110,99,52,48,53,41,0,0,0,0,0,0};
static C_char C_TLS li69[] C_aligned={C_lihdr(0,0,25),40,104,97,115,104,45,116,97,98,108,101,45,99,108,101,97,114,33,32,104,116,52,50,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li70[] C_aligned={C_lihdr(0,0,7),40,97,51,48,53,51,41,0};
static C_char C_TLS li71[] C_aligned={C_lihdr(0,0,14),40,100,111,52,51,52,32,108,115,116,52,51,54,41,0,0};
static C_char C_TLS li72[] C_aligned={C_lihdr(0,0,12),40,100,111,52,51,49,32,105,52,51,51,41,0,0,0,0};
static C_char C_TLS li73[] C_aligned={C_lihdr(0,0,44),40,35,35,115,114,102,105,45,54,57,35,37,104,97,115,104,45,116,97,98,108,101,45,109,101,114,103,101,33,32,104,116,49,52,50,55,32,104,116,50,52,50,56,41,0,0,0,0};
static C_char C_TLS li74[] C_aligned={C_lihdr(0,0,33),40,104,97,115,104,45,116,97,98,108,101,45,109,101,114,103,101,33,32,104,116,49,52,52,50,32,104,116,50,52,52,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li75[] C_aligned={C_lihdr(0,0,32),40,104,97,115,104,45,116,97,98,108,101,45,109,101,114,103,101,32,104,116,49,52,52,54,32,104,116,50,52,52,55,41};
static C_char C_TLS li76[] C_aligned={C_lihdr(0,0,24),40,108,111,111,112,50,32,98,117,99,107,101,116,52,53,55,32,108,115,116,52,53,56,41};
static C_char C_TLS li77[] C_aligned={C_lihdr(0,0,18),40,108,111,111,112,32,105,52,53,52,32,108,115,116,52,53,53,41,0,0,0,0,0,0};
static C_char C_TLS li78[] C_aligned={C_lihdr(0,0,25),40,104,97,115,104,45,116,97,98,108,101,45,62,97,108,105,115,116,32,104,116,52,53,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li79[] C_aligned={C_lihdr(0,0,7),40,97,51,49,56,50,41,0};
static C_char C_TLS li80[] C_aligned={C_lihdr(0,0,12),40,97,51,49,55,50,32,120,52,54,55,41,0,0,0,0};
static C_char C_TLS li81[] C_aligned={C_lihdr(0,0,38),40,97,108,105,115,116,45,62,104,97,115,104,45,116,97,98,108,101,32,97,108,105,115,116,52,54,52,32,46,32,114,101,115,116,52,54,53,41,0,0};
static C_char C_TLS li82[] C_aligned={C_lihdr(0,0,24),40,108,111,111,112,50,32,98,117,99,107,101,116,52,55,55,32,108,115,116,52,55,56,41};
static C_char C_TLS li83[] C_aligned={C_lihdr(0,0,18),40,108,111,111,112,32,105,52,55,52,32,108,115,116,52,55,53,41,0,0,0,0,0,0};
static C_char C_TLS li84[] C_aligned={C_lihdr(0,0,23),40,104,97,115,104,45,116,97,98,108,101,45,107,101,121,115,32,104,116,52,55,48,41,0};
static C_char C_TLS li85[] C_aligned={C_lihdr(0,0,24),40,108,111,111,112,50,32,98,117,99,107,101,116,52,57,48,32,108,115,116,52,57,49,41};
static C_char C_TLS li86[] C_aligned={C_lihdr(0,0,18),40,108,111,111,112,32,105,52,56,55,32,108,115,116,52,56,56,41,0,0,0,0,0,0};
static C_char C_TLS li87[] C_aligned={C_lihdr(0,0,25),40,104,97,115,104,45,116,97,98,108,101,45,118,97,108,117,101,115,32,104,116,52,56,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li88[] C_aligned={C_lihdr(0,0,17),40,97,51,51,52,57,32,98,117,99,107,101,116,53,48,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li89[] C_aligned={C_lihdr(0,0,12),40,100,111,53,48,48,32,105,53,48,50,41,0,0,0,0};
static C_char C_TLS li90[] C_aligned={C_lihdr(0,0,46),40,35,35,115,114,102,105,45,54,57,35,37,104,97,115,104,45,116,97,98,108,101,45,102,111,114,45,101,97,99,104,32,104,116,52,57,54,32,112,114,111,99,52,57,55,41,0,0};
static C_char C_TLS li91[] C_aligned={C_lihdr(0,0,24),40,102,111,108,100,50,32,98,117,99,107,101,116,53,49,53,32,97,99,99,53,49,54,41};
static C_char C_TLS li92[] C_aligned={C_lihdr(0,0,18),40,108,111,111,112,32,105,53,49,50,32,97,99,99,53,49,51,41,0,0,0,0,0,0};
static C_char C_TLS li93[] C_aligned={C_lihdr(0,0,50),40,35,35,115,114,102,105,45,54,57,35,37,104,97,115,104,45,116,97,98,108,101,45,102,111,108,100,32,104,116,53,48,54,32,102,117,110,99,53,48,55,32,105,110,105,116,53,48,56,41,0,0,0,0,0,0};
static C_char C_TLS li94[] C_aligned={C_lihdr(0,0,39),40,104,97,115,104,45,116,97,98,108,101,45,102,111,108,100,32,104,116,53,50,48,32,102,117,110,99,53,50,49,32,105,110,105,116,53,50,50,41,0};
static C_char C_TLS li95[] C_aligned={C_lihdr(0,0,35),40,104,97,115,104,45,116,97,98,108,101,45,102,111,114,45,101,97,99,104,32,104,116,53,50,53,32,112,114,111,99,53,50,54,41,0,0,0,0,0};
static C_char C_TLS li96[] C_aligned={C_lihdr(0,0,31),40,104,97,115,104,45,116,97,98,108,101,45,119,97,108,107,32,104,116,53,50,57,32,112,114,111,99,53,51,48,41,0};
static C_char C_TLS li97[] C_aligned={C_lihdr(0,0,22),40,97,51,52,56,49,32,107,53,51,53,32,118,53,51,54,32,97,53,51,55,41,0,0};
static C_char C_TLS li98[] C_aligned={C_lihdr(0,0,30),40,104,97,115,104,45,116,97,98,108,101,45,109,97,112,32,104,116,53,51,51,32,102,117,110,99,53,51,52,41,0,0};
static C_char C_TLS li99[] C_aligned={C_lihdr(0,0,8),40,102,95,51,53,48,57,41};
static C_char C_TLS li100[] C_aligned={C_lihdr(0,0,30),40,97,51,52,57,49,32,104,116,51,54,50,32,107,101,121,51,54,51,32,46,32,103,51,54,49,51,54,52,41,0,0};
static C_char C_TLS li101[] C_aligned={C_lihdr(0,0,10),40,116,111,112,108,101,118,101,108,41,0,0,0,0,0,0};


C_noret_decl(C_srfi_69_toplevel)
C_externexport void C_ccall C_srfi_69_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_611)
static void C_ccall f_611(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3492)
static void C_ccall f_3492(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3492)
static void C_ccall f_3492r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3509)
static void C_ccall f_3509(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3496)
static void C_ccall f_3496(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3502)
static void C_ccall f_3502(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2715)
static void C_ccall f_2715(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3470)
static void C_ccall f_3470(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3477)
static void C_ccall f_3477(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3482)
static void C_ccall f_3482(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3490)
static void C_ccall f_3490(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3458)
static void C_ccall f_3458(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3465)
static void C_ccall f_3465(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3446)
static void C_ccall f_3446(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3453)
static void C_ccall f_3453(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3434)
static void C_ccall f_3434(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3441)
static void C_ccall f_3441(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3368)
static void C_ccall f_3368(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3380)
static void C_fcall f_3380(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3396)
static void C_fcall f_3396(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3424)
static void C_ccall f_3424(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3319)
static void C_ccall f_3319(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3331)
static void C_fcall f_3331(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3350)
static void C_ccall f_3350(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3341)
static void C_ccall f_3341(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3254)
static void C_ccall f_3254(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3269)
static void C_fcall f_3269(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3285)
static void C_fcall f_3285(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3189)
static void C_ccall f_3189(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3204)
static void C_fcall f_3204(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3220)
static void C_fcall f_3220(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3161)
static void C_ccall f_3161(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3161)
static void C_ccall f_3161r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3168)
static void C_ccall f_3168(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3173)
static void C_ccall f_3173(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3183)
static void C_ccall f_3183(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3171)
static void C_ccall f_3171(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3088)
static void C_ccall f_3088(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3103)
static void C_fcall f_3103(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3119)
static void C_fcall f_3119(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3072)
static void C_ccall f_3072(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3086)
static void C_ccall f_3086(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3060)
static void C_ccall f_3060(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2993)
static void C_ccall f_2993(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3005)
static void C_fcall f_3005(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3028)
static void C_fcall f_3028(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3054)
static void C_ccall f_3054(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3041)
static void C_ccall f_3041(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3015)
static void C_ccall f_3015(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2977)
static void C_ccall f_2977(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2984)
static void C_ccall f_2984(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2881)
static void C_ccall f_2881(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2888)
static void C_ccall f_2888(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2902)
static void C_fcall f_2902(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2928)
static void C_fcall f_2928(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2947)
static void C_ccall f_2947(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2915)
static void C_ccall f_2915(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2750)
static void C_ccall f_2750(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2766)
static void C_ccall f_2766(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2833)
static void C_fcall f_2833(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2852)
static void C_ccall f_2852(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2786)
static C_word C_fcall f_2786(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_2729)
static void C_ccall f_2729(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2748)
static void C_ccall f_2748(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2717)
static void C_ccall f_2717(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2726)
static void C_ccall f_2726(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2604)
static void C_ccall f_2604(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2617)
static void C_ccall f_2617(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2674)
static void C_fcall f_2674(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2693)
static void C_ccall f_2693(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2632)
static void C_fcall f_2632(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2590)
static void C_ccall f_2590(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2599)
static void C_ccall f_2599(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2595)
static void C_ccall f_2595(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2575)
static void C_ccall f_2575(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_2582)
static void C_ccall f_2582(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2587)
static void C_ccall f_2587(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2494)
static void C_ccall f_2494(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2494)
static void C_ccall f_2494r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2527)
static void C_fcall f_2527(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2510)
static void C_fcall f_2510(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2522)
static void C_ccall f_2522(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2496)
static void C_fcall f_2496(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2503)
static void C_ccall f_2503(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2506)
static void C_ccall f_2506(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2258)
static void C_ccall f_2258(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_2279)
static void C_fcall f_2279(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2484)
static void C_ccall f_2484(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2476)
static void C_ccall f_2476(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2295)
static void C_ccall f_2295(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2301)
static void C_fcall f_2301(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2402)
static void C_fcall f_2402(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2439)
static void C_ccall f_2439(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2442)
static void C_ccall f_2442(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2430)
static void C_ccall f_2430(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2412)
static void C_ccall f_2412(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2339)
static void C_fcall f_2339(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2379)
static void C_ccall f_2379(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2367)
static void C_ccall f_2367(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2349)
static void C_ccall f_2349(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2317)
static void C_ccall f_2317(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2304)
static void C_ccall f_2304(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2307)
static void C_ccall f_2307(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2179)
static void C_ccall f_2179(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2191)
static void C_fcall f_2191(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2214)
static void C_fcall f_2214(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2230)
static void C_ccall f_2230(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2201)
static void C_ccall f_2201(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2170)
static void C_ccall f_2170(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2058)
static void C_ccall f_2058(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2068)
static void C_ccall f_2068(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2073)
static void C_fcall f_2073(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2135)
static void C_fcall f_2135(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2156)
static void C_ccall f_2156(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2129)
static void C_ccall f_2129(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2043)
static void C_ccall f_2043(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2031)
static void C_ccall f_2031(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2022)
static void C_ccall f_2022(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2013)
static void C_ccall f_2013(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2004)
static void C_ccall f_2004(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1995)
static void C_ccall f_1995(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1986)
static void C_ccall f_1986(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1977)
static void C_ccall f_1977(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1968)
static void C_ccall f_1968(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1962)
static void C_ccall f_1962(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1599)
static void C_ccall f_1599(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1599)
static void C_ccall f_1599r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1952)
static void C_ccall f_1952(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1955)
static void C_ccall f_1955(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1677)
static void C_fcall f_1677(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1932)
static void C_ccall f_1932(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1935)
static void C_ccall f_1935(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1680)
static void C_fcall f_1680(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1900)
static void C_ccall f_1900(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1906)
static void C_ccall f_1906(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1683)
static void C_fcall f_1683(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1718)
static void C_fcall f_1718(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1739)
static void C_ccall f_1739(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1745)
static void C_ccall f_1745(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1837)
static void C_ccall f_1837(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1840)
static void C_ccall f_1840(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1812)
static void C_ccall f_1812(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1815)
static void C_ccall f_1815(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1802)
static void C_ccall f_1802(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1784)
static void C_ccall f_1784(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1771)
static void C_ccall f_1771(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1761)
static void C_ccall f_1761(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1748)
static void C_ccall f_1748(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1729)
static void C_fcall f_1729(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1686)
static void C_ccall f_1686(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1689)
static void C_ccall f_1689(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1693)
static void C_ccall f_1693(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1709)
static void C_ccall f_1709(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1696)
static void C_fcall f_1696(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1601)
static C_word C_fcall f_1601(C_word t0);
C_noret_decl(f_1568)
static void C_ccall f_1568(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9,...) C_noret;
C_noret_decl(f_1568)
static void C_ccall f_1568r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9,C_word t11) C_noret;
C_noret_decl(f_1572)
static void C_ccall f_1572(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1538)
static void C_ccall f_1538(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1544)
static C_word C_fcall f_1544(C_word t0,C_word t1);
C_noret_decl(f_1489)
static void C_ccall f_1489(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1489)
static void C_ccall f_1489r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1493)
static void C_ccall f_1493(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1441)
static void C_ccall f_1441(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1441)
static void C_ccall f_1441r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1445)
static void C_ccall f_1445(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1392)
static void C_ccall f_1392(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1392)
static void C_ccall f_1392r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1396)
static void C_ccall f_1396(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1410)
static void C_ccall f_1410(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1120)
static void C_ccall f_1120(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1219)
static void C_fcall f_1219(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1370)
static void C_ccall f_1370(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1349)
static void C_ccall f_1349(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1341)
static void C_ccall f_1341(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1320)
static void C_ccall f_1320(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1294)
static void C_ccall f_1294(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1188)
static void C_fcall f_1188(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1123)
static void C_fcall f_1123(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_1140)
static void C_fcall f_1140(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1174)
static void C_ccall f_1174(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1072)
static void C_ccall f_1072(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1072)
static void C_ccall f_1072r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1076)
static void C_ccall f_1076(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1090)
static void C_ccall f_1090(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_992)
static void C_ccall f_992(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1061)
static void C_ccall f_1061(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_943)
static void C_ccall f_943(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_943)
static void C_ccall f_943r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_947)
static void C_ccall f_947(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_961)
static void C_ccall f_961(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_882)
static void C_ccall f_882(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_830)
static void C_ccall f_830(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_830)
static void C_ccall f_830r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_834)
static void C_ccall f_834(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_837)
static void C_ccall f_837(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_804)
static void C_ccall f_804(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_804)
static void C_ccall f_804r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_811)
static void C_ccall f_811(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_752)
static void C_ccall f_752(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_752)
static void C_ccall f_752r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_756)
static void C_ccall f_756(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_704)
static void C_ccall f_704(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_704)
static void C_ccall f_704r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_708)
static void C_ccall f_708(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_722)
static void C_ccall f_722(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_698)
static void C_ccall f_698(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_625)
static void C_ccall f_625(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_625)
static void C_ccall f_625r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_629)
static void C_ccall f_629(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_632)
static void C_ccall f_632(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_671)
static void C_ccall f_671(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_646)
static void C_fcall f_646(C_word t0,C_word t1) C_noret;
C_noret_decl(f_619)
static void C_ccall f_619(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_613)
static void C_ccall f_613(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_3380)
static void C_fcall trf_3380(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3380(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3380(t0,t1,t2,t3);}

C_noret_decl(trf_3396)
static void C_fcall trf_3396(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3396(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3396(t0,t1,t2,t3);}

C_noret_decl(trf_3331)
static void C_fcall trf_3331(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3331(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3331(t0,t1,t2);}

C_noret_decl(trf_3269)
static void C_fcall trf_3269(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3269(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3269(t0,t1,t2,t3);}

C_noret_decl(trf_3285)
static void C_fcall trf_3285(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3285(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3285(t0,t1,t2,t3);}

C_noret_decl(trf_3204)
static void C_fcall trf_3204(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3204(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3204(t0,t1,t2,t3);}

C_noret_decl(trf_3220)
static void C_fcall trf_3220(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3220(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3220(t0,t1,t2,t3);}

C_noret_decl(trf_3103)
static void C_fcall trf_3103(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3103(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3103(t0,t1,t2,t3);}

C_noret_decl(trf_3119)
static void C_fcall trf_3119(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3119(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3119(t0,t1,t2,t3);}

C_noret_decl(trf_3005)
static void C_fcall trf_3005(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3005(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3005(t0,t1,t2);}

C_noret_decl(trf_3028)
static void C_fcall trf_3028(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3028(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3028(t0,t1,t2);}

C_noret_decl(trf_2902)
static void C_fcall trf_2902(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2902(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2902(t0,t1,t2);}

C_noret_decl(trf_2928)
static void C_fcall trf_2928(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2928(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2928(t0,t1,t2,t3);}

C_noret_decl(trf_2833)
static void C_fcall trf_2833(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2833(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2833(t0,t1,t2,t3);}

C_noret_decl(trf_2674)
static void C_fcall trf_2674(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2674(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2674(t0,t1,t2);}

C_noret_decl(trf_2632)
static void C_fcall trf_2632(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2632(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2632(t0,t1,t2);}

C_noret_decl(trf_2527)
static void C_fcall trf_2527(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2527(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2527(t0,t1);}

C_noret_decl(trf_2510)
static void C_fcall trf_2510(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2510(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2510(t0,t1,t2);}

C_noret_decl(trf_2496)
static void C_fcall trf_2496(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2496(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2496(t0,t1,t2,t3);}

C_noret_decl(trf_2279)
static void C_fcall trf_2279(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2279(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2279(t0,t1);}

C_noret_decl(trf_2301)
static void C_fcall trf_2301(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2301(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2301(t0,t1);}

C_noret_decl(trf_2402)
static void C_fcall trf_2402(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2402(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2402(t0,t1,t2);}

C_noret_decl(trf_2339)
static void C_fcall trf_2339(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2339(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2339(t0,t1,t2);}

C_noret_decl(trf_2191)
static void C_fcall trf_2191(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2191(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2191(t0,t1,t2);}

C_noret_decl(trf_2214)
static void C_fcall trf_2214(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2214(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2214(t0,t1,t2);}

C_noret_decl(trf_2073)
static void C_fcall trf_2073(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2073(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2073(t0,t1,t2);}

C_noret_decl(trf_2135)
static void C_fcall trf_2135(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2135(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2135(t0,t1,t2);}

C_noret_decl(trf_1677)
static void C_fcall trf_1677(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1677(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1677(t0,t1);}

C_noret_decl(trf_1680)
static void C_fcall trf_1680(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1680(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1680(t0,t1);}

C_noret_decl(trf_1683)
static void C_fcall trf_1683(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1683(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1683(t0,t1);}

C_noret_decl(trf_1718)
static void C_fcall trf_1718(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1718(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1718(t0,t1,t2);}

C_noret_decl(trf_1729)
static void C_fcall trf_1729(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1729(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1729(t0,t1,t2);}

C_noret_decl(trf_1696)
static void C_fcall trf_1696(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1696(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1696(t0,t1);}

C_noret_decl(trf_1219)
static void C_fcall trf_1219(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1219(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1219(t0,t1,t2,t3);}

C_noret_decl(trf_1188)
static void C_fcall trf_1188(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1188(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1188(t0,t1,t2,t3);}

C_noret_decl(trf_1123)
static void C_fcall trf_1123(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1123(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_1123(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_1140)
static void C_fcall trf_1140(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1140(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1140(t0,t1,t2,t3,t4);}

C_noret_decl(trf_646)
static void C_fcall trf_646(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_646(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_646(t0,t1);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr10r)
static void C_fcall tr10r(C_proc10 k) C_regparm C_noret;
C_regparm static void C_fcall tr10r(C_proc10 k){
int n;
C_word *a,t10;
C_word t9=C_pick(0);
C_word t8=C_pick(1);
C_word t7=C_pick(2);
C_word t6=C_pick(3);
C_word t5=C_pick(4);
C_word t4=C_pick(5);
C_word t3=C_pick(6);
C_word t2=C_pick(7);
C_word t1=C_pick(8);
C_word t0=C_pick(9);
C_adjust_stack(-10);
n=C_rest_count(0);
a=C_alloc(n*3);
t10=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5,t6,t7,t8,t9,t10);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr3rv)
static void C_fcall tr3rv(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3rv(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n+1);
t3=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_srfi_69_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("srfi_69_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(1063)){
C_save(t1);
C_rereclaim2(1063*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,120);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[2]=C_h_intern(&lf[2],19,"\003sysundefined-value");
lf[3]=C_h_intern(&lf[3],27,"\007srfi-69unbound-value-thunk");
lf[4]=C_h_intern(&lf[4],28,"\003sysarbitrary-unbound-symbol");
lf[5]=C_h_intern(&lf[5],20,"\003sysnumber-hash-hook");
lf[6]=C_h_intern(&lf[6],20,"\007srfi-69%equal\077-hash");
lf[7]=C_h_intern(&lf[7],11,"number-hash");
lf[8]=C_h_intern(&lf[8],5,"fxmod");
lf[9]=C_h_intern(&lf[9],4,"\077obj");
lf[10]=C_h_intern(&lf[10],15,"\003syssignal-hook");
lf[11]=C_h_intern(&lf[11],5,"\000type");
lf[12]=C_decode_literal(C_heaptop,"\376B\000\000\016invalid number");
lf[13]=C_h_intern(&lf[13],9,"\003syserror");
lf[14]=C_h_intern(&lf[14],24,"\007srfi-69%object-uid-hash");
lf[15]=C_h_intern(&lf[15],15,"object-uid-hash");
lf[16]=C_h_intern(&lf[16],11,"symbol-hash");
lf[17]=C_h_intern(&lf[17],11,"string-hash");
lf[18]=C_h_intern(&lf[18],17,"\003syscheck-keyword");
lf[19]=C_h_intern(&lf[19],11,"\000type-error");
lf[20]=C_decode_literal(C_heaptop,"\376B\000\000!bad argument type - not a keyword");
lf[21]=C_h_intern(&lf[21],8,"keyword\077");
lf[22]=C_h_intern(&lf[22],12,"keyword-hash");
lf[23]=C_h_intern(&lf[23],17,"\007srfi-69%eq\077-hash");
lf[24]=C_h_intern(&lf[24],8,"eq\077-hash");
lf[25]=C_h_intern(&lf[25],16,"hash-by-identity");
lf[26]=C_h_intern(&lf[26],18,"\007srfi-69%eqv\077-hash");
lf[27]=C_h_intern(&lf[27],9,"eqv\077-hash");
lf[28]=C_h_intern(&lf[28],11,"input-port\077");
lf[29]=C_h_intern(&lf[29],11,"equal\077-hash");
lf[30]=C_h_intern(&lf[30],4,"hash");
lf[31]=C_h_intern(&lf[31],14,"string-ci-hash");
lf[33]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\001\000\000\0013\376\003\000\000\002\376\377\001\000\000\002i\376\003\000\000\002\376\377\001\000\000\004\325\376\003\000\000\002\376\377\001\000\000\011\255\376\003\000\000\002\376\377\001\000\000\023]\376\003\000\000\002\376\377\001\000\000&\303\376\003\000\000\002\376\377\001"
"\000\000M\215\376\003\000\000\002\376\377\001\000\000\233\035\376\003\000\000\002\376\377\001\000\0016\077\376\003\000\000\002\376\377\001\000\002l\201\376\003\000\000\002\376\377\001\000\004\331\005\376\003\000\000\002\376\377\001\000\011\262\025\376\003\000\000\002\376\377\001\000\023dA\376\003\000\000"
"\002\376\377\001\000&\310\205\376\003\000\000\002\376\377\001\000M\221\037\376\003\000\000\002\376\377\001\000\233\042I\376\003\000\000\002\376\377\001\0016D\277\376\003\000\000\002\376\377\001\002l\211\207\376\003\000\000\002\376\377\001\004\331\023\027\376\003\000\000\002\376\377\001\011\262&1"
"\376\003\000\000\002\376\377\001\023dLq\376\003\000\000\002\376\377\001&\310\230\373\376\003\000\000\002\376\377\001\077\377\377\377\376\377\016");
lf[34]=C_h_intern(&lf[34],35,"\007srfi-69hash-table-canonical-length");
lf[35]=C_h_intern(&lf[35],11,"make-vector");
lf[36]=C_h_intern(&lf[36],16,"%make-hash-table");
lf[37]=C_h_intern(&lf[37],10,"hash-table");
lf[38]=C_h_intern(&lf[38],3,"eq\077");
lf[39]=C_h_intern(&lf[39],4,"eqv\077");
lf[40]=C_h_intern(&lf[40],6,"equal\077");
lf[41]=C_h_intern(&lf[41],8,"string=\077");
lf[42]=C_h_intern(&lf[42],11,"string-ci=\077");
lf[43]=C_h_intern(&lf[43],1,"=");
lf[44]=C_h_intern(&lf[44],15,"make-hash-table");
lf[45]=C_decode_literal(C_heaptop,"\376U0.5\000");
lf[46]=C_decode_literal(C_heaptop,"\376U0.8\000");
lf[47]=C_h_intern(&lf[47],7,"warning");
lf[48]=C_decode_literal(C_heaptop,"\376B\000\000\033user test without user hash");
lf[49]=C_h_intern(&lf[49],5,"error");
lf[50]=C_decode_literal(C_heaptop,"\376B\000\000\036min-load greater than max-load");
lf[51]=C_h_intern(&lf[51],5,"\000test");
lf[52]=C_h_intern(&lf[52],17,"\003syscheck-closure");
lf[53]=C_h_intern(&lf[53],5,"\000hash");
lf[54]=C_h_intern(&lf[54],5,"\000size");
lf[55]=C_h_intern(&lf[55],19,"hash-table-max-size");
lf[56]=C_decode_literal(C_heaptop,"\376B\000\000\014invalid size");
lf[57]=C_h_intern(&lf[57],8,"\000initial");
lf[58]=C_h_intern(&lf[58],9,"\000min-load");
lf[59]=C_decode_literal(C_heaptop,"\376U0.0\000");
lf[60]=C_decode_literal(C_heaptop,"\376U1.0\000");
lf[61]=C_decode_literal(C_heaptop,"\376B\000\000\020invalid min-load");
lf[62]=C_h_intern(&lf[62],17,"\003syscheck-inexact");
lf[63]=C_h_intern(&lf[63],9,"\000max-load");
lf[64]=C_decode_literal(C_heaptop,"\376U0.0\000");
lf[65]=C_decode_literal(C_heaptop,"\376U1.0\000");
lf[66]=C_decode_literal(C_heaptop,"\376B\000\000\020invalid max-load");
lf[67]=C_h_intern(&lf[67],10,"\000weak-keys");
lf[68]=C_h_intern(&lf[68],12,"\000weak-values");
lf[69]=C_decode_literal(C_heaptop,"\376B\000\000\017unknown keyword");
lf[70]=C_decode_literal(C_heaptop,"\376B\000\000\025missing keyword value");
lf[71]=C_decode_literal(C_heaptop,"\376B\000\000\017missing keyword");
lf[72]=C_decode_literal(C_heaptop,"\376B\000\000\014invalid size");
lf[73]=C_h_intern(&lf[73],11,"hash-table\077");
lf[74]=C_h_intern(&lf[74],15,"hash-table-size");
lf[75]=C_h_intern(&lf[75],31,"hash-table-equivalence-function");
lf[76]=C_h_intern(&lf[76],24,"hash-table-hash-function");
lf[77]=C_h_intern(&lf[77],19,"hash-table-min-load");
lf[78]=C_h_intern(&lf[78],19,"hash-table-max-load");
lf[79]=C_h_intern(&lf[79],20,"hash-table-weak-keys");
lf[80]=C_h_intern(&lf[80],22,"hash-table-weak-values");
lf[81]=C_h_intern(&lf[81],23,"hash-table-has-initial\077");
lf[82]=C_h_intern(&lf[82],18,"hash-table-initial");
lf[83]=C_h_intern(&lf[83],24,"\007srfi-69%hash-table-copy");
lf[84]=C_h_intern(&lf[84],15,"hash-table-copy");
lf[85]=C_h_intern(&lf[85],25,"\007srfi-69hash-table-rehash");
lf[86]=C_h_intern(&lf[86],5,"floor");
lf[87]=C_h_intern(&lf[87],27,"\007srfi-69%hash-table-update!");
lf[88]=C_h_intern(&lf[88],18,"hash-table-update!");
lf[89]=C_h_intern(&lf[89],13,"\000access-error");
lf[90]=C_decode_literal(C_heaptop,"\376B\000\000\037hash-table does not contain key");
lf[91]=C_h_intern(&lf[91],8,"identity");
lf[92]=C_h_intern(&lf[92],26,"hash-table-update!/default");
lf[93]=C_h_intern(&lf[93],15,"hash-table-set!");
lf[94]=C_h_intern(&lf[94],23,"\007srfi-69%hash-table-ref");
lf[95]=C_h_intern(&lf[95],14,"hash-table-ref");
lf[96]=C_h_intern(&lf[96],22,"hash-table-ref/default");
lf[97]=C_h_intern(&lf[97],18,"hash-table-exists\077");
lf[98]=C_h_intern(&lf[98],18,"hash-table-delete!");
lf[99]=C_h_intern(&lf[99],18,"hash-table-remove!");
lf[100]=C_h_intern(&lf[100],17,"hash-table-clear!");
lf[101]=C_h_intern(&lf[101],12,"vector-fill!");
lf[102]=C_h_intern(&lf[102],26,"\007srfi-69%hash-table-merge!");
lf[103]=C_h_intern(&lf[103],17,"hash-table-merge!");
lf[104]=C_h_intern(&lf[104],16,"hash-table-merge");
lf[105]=C_h_intern(&lf[105],17,"hash-table->alist");
lf[106]=C_h_intern(&lf[106],17,"alist->hash-table");
lf[107]=C_h_intern(&lf[107],12,"\003sysfor-each");
lf[108]=C_h_intern(&lf[108],15,"hash-table-keys");
lf[109]=C_h_intern(&lf[109],17,"hash-table-values");
lf[110]=C_h_intern(&lf[110],28,"\007srfi-69%hash-table-for-each");
lf[111]=C_h_intern(&lf[111],24,"\007srfi-69%hash-table-fold");
lf[112]=C_h_intern(&lf[112],15,"hash-table-fold");
lf[113]=C_h_intern(&lf[113],19,"hash-table-for-each");
lf[114]=C_h_intern(&lf[114],15,"hash-table-walk");
lf[115]=C_h_intern(&lf[115],14,"hash-table-map");
lf[116]=C_decode_literal(C_heaptop,"\376B\000\000\037hash-table does not contain key");
lf[117]=C_h_intern(&lf[117],18,"getter-with-setter");
lf[118]=C_h_intern(&lf[118],17,"register-feature!");
lf[119]=C_h_intern(&lf[119],7,"srfi-69");
C_register_lf2(lf,120,create_ptable());
t2=C_mutate(&lf[0],lf[1]);
t3=*((C_word*)lf[2]+1);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_611,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* srfi-69.scm: 76   register-feature! */
t5=*((C_word*)lf[118]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[119]);}

/* k609 */
static void C_ccall f_611(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word ab[128],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_611,2,t0,t1);}
t2=C_mutate((C_word*)lf[3]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_613,a[2]=((C_word)li0),tmp=(C_word)a,a+=3,tmp));
t3=C_mutate((C_word*)lf[5]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_619,a[2]=((C_word)li1),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[7]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_625,a[2]=((C_word)li2),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[14]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_698,a[2]=((C_word)li3),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[15]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_704,a[2]=((C_word)li4),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[16]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_752,a[2]=((C_word)li5),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[18]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_804,a[2]=((C_word)li6),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[22]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_830,a[2]=((C_word)li7),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[23]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_882,a[2]=((C_word)li8),tmp=(C_word)a,a+=3,tmp));
t11=C_mutate((C_word*)lf[24]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_943,a[2]=((C_word)li9),tmp=(C_word)a,a+=3,tmp));
t12=C_mutate((C_word*)lf[25]+1,*((C_word*)lf[24]+1));
t13=C_mutate((C_word*)lf[26]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_992,a[2]=((C_word)li10),tmp=(C_word)a,a+=3,tmp));
t14=C_mutate((C_word*)lf[27]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1072,a[2]=((C_word)li11),tmp=(C_word)a,a+=3,tmp));
t15=C_mutate((C_word*)lf[6]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1120,a[2]=((C_word)li16),tmp=(C_word)a,a+=3,tmp));
t16=C_mutate((C_word*)lf[29]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1392,a[2]=((C_word)li17),tmp=(C_word)a,a+=3,tmp));
t17=C_mutate((C_word*)lf[30]+1,*((C_word*)lf[29]+1));
t18=C_mutate((C_word*)lf[17]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1441,a[2]=((C_word)li18),tmp=(C_word)a,a+=3,tmp));
t19=C_mutate((C_word*)lf[31]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1489,a[2]=((C_word)li19),tmp=(C_word)a,a+=3,tmp));
t20=C_mutate(&lf[32],lf[33]);
t21=C_mutate((C_word*)lf[34]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1538,a[2]=((C_word)li21),tmp=(C_word)a,a+=3,tmp));
t22=*((C_word*)lf[35]+1);
t23=C_mutate((C_word*)lf[36]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1568,a[2]=t22,a[3]=((C_word)li22),tmp=(C_word)a,a+=4,tmp));
t24=*((C_word*)lf[38]+1);
t25=*((C_word*)lf[39]+1);
t26=*((C_word*)lf[40]+1);
t27=*((C_word*)lf[41]+1);
t28=*((C_word*)lf[42]+1);
t29=*((C_word*)lf[43]+1);
t30=C_mutate((C_word*)lf[44]+1,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1599,a[2]=t29,a[3]=t28,a[4]=t27,a[5]=t26,a[6]=t25,a[7]=t24,a[8]=((C_word)li26),tmp=(C_word)a,a+=9,tmp));
t31=C_mutate((C_word*)lf[73]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1962,a[2]=((C_word)li27),tmp=(C_word)a,a+=3,tmp));
t32=C_mutate((C_word*)lf[74]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1968,a[2]=((C_word)li28),tmp=(C_word)a,a+=3,tmp));
t33=C_mutate((C_word*)lf[75]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1977,a[2]=((C_word)li29),tmp=(C_word)a,a+=3,tmp));
t34=C_mutate((C_word*)lf[76]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1986,a[2]=((C_word)li30),tmp=(C_word)a,a+=3,tmp));
t35=C_mutate((C_word*)lf[77]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1995,a[2]=((C_word)li31),tmp=(C_word)a,a+=3,tmp));
t36=C_mutate((C_word*)lf[78]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2004,a[2]=((C_word)li32),tmp=(C_word)a,a+=3,tmp));
t37=C_mutate((C_word*)lf[79]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2013,a[2]=((C_word)li33),tmp=(C_word)a,a+=3,tmp));
t38=C_mutate((C_word*)lf[80]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2022,a[2]=((C_word)li34),tmp=(C_word)a,a+=3,tmp));
t39=C_mutate((C_word*)lf[81]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2031,a[2]=((C_word)li35),tmp=(C_word)a,a+=3,tmp));
t40=C_mutate((C_word*)lf[82]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2043,a[2]=((C_word)li36),tmp=(C_word)a,a+=3,tmp));
t41=*((C_word*)lf[35]+1);
t42=C_mutate((C_word*)lf[83]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2058,a[2]=t41,a[3]=((C_word)li39),tmp=(C_word)a,a+=4,tmp));
t43=C_mutate((C_word*)lf[84]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2170,a[2]=((C_word)li40),tmp=(C_word)a,a+=3,tmp));
t44=C_mutate((C_word*)lf[85]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2179,a[2]=((C_word)li43),tmp=(C_word)a,a+=3,tmp));
t45=*((C_word*)lf[38]+1);
t46=*((C_word*)lf[86]+1);
t47=C_mutate((C_word*)lf[87]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2258,a[2]=t46,a[3]=t45,a[4]=((C_word)li47),tmp=(C_word)a,a+=5,tmp));
t48=C_mutate((C_word*)lf[88]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2494,a[2]=((C_word)li52),tmp=(C_word)a,a+=3,tmp));
t49=C_mutate((C_word*)lf[92]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2575,a[2]=((C_word)li54),tmp=(C_word)a,a+=3,tmp));
t50=C_mutate((C_word*)lf[93]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2590,a[2]=((C_word)li56),tmp=(C_word)a,a+=3,tmp));
t51=*((C_word*)lf[38]+1);
t52=C_mutate((C_word*)lf[94]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2604,a[2]=t51,a[3]=((C_word)li59),tmp=(C_word)a,a+=4,tmp));
t53=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2715,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t54=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3492,a[2]=((C_word)li100),tmp=(C_word)a,a+=3,tmp);
/* srfi-69.scm: 773  getter-with-setter */
t55=*((C_word*)lf[117]+1);
((C_proc4)C_retrieve_proc(t55))(4,t55,t53,t54,*((C_word*)lf[93]+1));}

/* a3491 in k609 */
static void C_ccall f_3492(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr4r,(void*)f_3492r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3492r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3492r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(10);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3496,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_3496(2,t6,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3509,a[2]=t2,a[3]=t3,a[4]=((C_word)li99),tmp=(C_word)a,a+=5,tmp));}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_3496(2,t7,(C_word)C_i_car(t4));}
else{
/* ##sys#error */
t7=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* f_3509 in a3491 in k609 */
static void C_ccall f_3509(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3509,2,t0,t1);}
/* srfi-69.scm: 775  ##sys#signal-hook */
t2=*((C_word*)lf[10]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,t1,lf[89],lf[95],lf[116],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3494 in a3491 in k609 */
static void C_ccall f_3496(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3496,2,t0,t1);}
t2=(C_word)C_i_check_structure_2(((C_word*)t0)[4],lf[37],lf[95]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3502,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* srfi-69.scm: 779  ##sys#check-closure */
t4=*((C_word*)lf[52]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t1,lf[95]);}

/* k3500 in k3494 in a3491 in k609 */
static void C_ccall f_3502(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-69.scm: 780  %hash-table-ref */
t2=*((C_word*)lf[94]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2713 in k609 */
static void C_ccall f_2715(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word ab[56],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2715,2,t0,t1);}
t2=C_mutate((C_word*)lf[95]+1,t1);
t3=C_mutate((C_word*)lf[96]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2717,a[2]=((C_word)li61),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[97]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2729,a[2]=((C_word)li62),tmp=(C_word)a,a+=3,tmp));
t5=*((C_word*)lf[38]+1);
t6=C_mutate((C_word*)lf[98]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2750,a[2]=t5,a[3]=((C_word)li65),tmp=(C_word)a,a+=4,tmp));
t7=C_mutate((C_word*)lf[99]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2881,a[2]=((C_word)li68),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[100]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2977,a[2]=((C_word)li69),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[102]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2993,a[2]=((C_word)li73),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[103]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3060,a[2]=((C_word)li74),tmp=(C_word)a,a+=3,tmp));
t11=C_mutate((C_word*)lf[104]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3072,a[2]=((C_word)li75),tmp=(C_word)a,a+=3,tmp));
t12=C_mutate((C_word*)lf[105]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3088,a[2]=((C_word)li78),tmp=(C_word)a,a+=3,tmp));
t13=*((C_word*)lf[44]+1);
t14=C_mutate((C_word*)lf[106]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3161,a[2]=t13,a[3]=((C_word)li81),tmp=(C_word)a,a+=4,tmp));
t15=C_mutate((C_word*)lf[108]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3189,a[2]=((C_word)li84),tmp=(C_word)a,a+=3,tmp));
t16=C_mutate((C_word*)lf[109]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3254,a[2]=((C_word)li87),tmp=(C_word)a,a+=3,tmp));
t17=C_mutate((C_word*)lf[110]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3319,a[2]=((C_word)li90),tmp=(C_word)a,a+=3,tmp));
t18=C_mutate((C_word*)lf[111]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3368,a[2]=((C_word)li93),tmp=(C_word)a,a+=3,tmp));
t19=C_mutate((C_word*)lf[112]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3434,a[2]=((C_word)li94),tmp=(C_word)a,a+=3,tmp));
t20=C_mutate((C_word*)lf[113]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3446,a[2]=((C_word)li95),tmp=(C_word)a,a+=3,tmp));
t21=C_mutate((C_word*)lf[114]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3458,a[2]=((C_word)li96),tmp=(C_word)a,a+=3,tmp));
t22=C_mutate((C_word*)lf[115]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3470,a[2]=((C_word)li98),tmp=(C_word)a,a+=3,tmp));
t23=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t23+1)))(2,t23,C_SCHEME_UNDEFINED);}

/* hash-table-map in k2713 in k609 */
static void C_ccall f_3470(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3470,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure_2(t2,lf[37],lf[115]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3477,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm: 992  ##sys#check-closure */
t6=*((C_word*)lf[52]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t3,lf[115]);}

/* k3475 in hash-table-map in k2713 in k609 */
static void C_ccall f_3477(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3477,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3482,a[2]=((C_word*)t0)[4],a[3]=((C_word)li97),tmp=(C_word)a,a+=4,tmp);
/* srfi-69.scm: 993  %hash-table-fold */
t3=*((C_word*)lf[111]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2,C_SCHEME_END_OF_LIST);}

/* a3481 in k3475 in hash-table-map in k2713 in k609 */
static void C_ccall f_3482(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3482,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3490,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-69.scm: 993  func */
t6=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,t2,t3);}

/* k3488 in a3481 in k3475 in hash-table-map in k2713 in k609 */
static void C_ccall f_3490(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3490,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[2]));}

/* hash-table-walk in k2713 in k609 */
static void C_ccall f_3458(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3458,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure_2(t2,lf[37],lf[114]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3465,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm: 987  ##sys#check-closure */
t6=*((C_word*)lf[52]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t3,lf[114]);}

/* k3463 in hash-table-walk in k2713 in k609 */
static void C_ccall f_3465(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-69.scm: 988  %hash-table-for-each */
t2=*((C_word*)lf[110]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* hash-table-for-each in k2713 in k609 */
static void C_ccall f_3446(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3446,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure_2(t2,lf[37],lf[113]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3453,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm: 982  ##sys#check-closure */
t6=*((C_word*)lf[52]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t3,lf[113]);}

/* k3451 in hash-table-for-each in k2713 in k609 */
static void C_ccall f_3453(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-69.scm: 983  %hash-table-for-each */
t2=*((C_word*)lf[110]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* hash-table-fold in k2713 in k609 */
static void C_ccall f_3434(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3434,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_check_structure_2(t2,lf[37],lf[112]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3441,a[2]=t4,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* srfi-69.scm: 977  ##sys#check-closure */
t7=*((C_word*)lf[52]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,t3,lf[112]);}

/* k3439 in hash-table-fold in k2713 in k609 */
static void C_ccall f_3441(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-69.scm: 978  %hash-table-fold */
t2=*((C_word*)lf[111]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##srfi-69#%hash-table-fold in k2713 in k609 */
static void C_ccall f_3368(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[9],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3368,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_slot(t2,C_fix(1));
t6=(C_word)C_block_size(t5);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3380,a[2]=t3,a[3]=t8,a[4]=t5,a[5]=t6,a[6]=((C_word)li92),tmp=(C_word)a,a+=7,tmp));
t10=((C_word*)t8)[1];
f_3380(t10,t1,C_fix(0),t4);}

/* loop in ##srfi-69#%hash-table-fold in k2713 in k609 */
static void C_fcall f_3380(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3380,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_slot(((C_word*)t0)[4],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3396,a[2]=((C_word*)t0)[2],a[3]=t6,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word)li91),tmp=(C_word)a,a+=7,tmp));
t8=((C_word*)t6)[1];
f_3396(t8,t1,t4,t3);}}

/* fold2 in loop in ##srfi-69#%hash-table-fold in k2713 in k609 */
static void C_fcall f_3396(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3396,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(C_word)C_fixnum_plus(((C_word*)t0)[5],C_fix(1));
/* srfi-69.scm: 970  loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_3380(t5,t1,t4,t3);}
else{
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_slot(t2,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3424,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_slot(t4,C_fix(0));
t8=(C_word)C_slot(t4,C_fix(1));
/* srfi-69.scm: 973  func */
t9=((C_word*)t0)[2];
((C_proc5)C_retrieve_proc(t9))(5,t9,t6,t7,t8,t3);}}

/* k3422 in fold2 in loop in ##srfi-69#%hash-table-fold in k2713 in k609 */
static void C_ccall f_3424(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-69.scm: 972  fold2 */
t2=((C_word*)((C_word*)t0)[4])[1];
f_3396(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* ##srfi-69#%hash-table-for-each in k2713 in k609 */
static void C_ccall f_3319(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3319,4,t0,t1,t2,t3);}
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_block_size(t4);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3331,a[2]=t4,a[3]=t3,a[4]=t7,a[5]=t5,a[6]=((C_word)li89),tmp=(C_word)a,a+=7,tmp));
t9=((C_word*)t7)[1];
f_3331(t9,t1,C_fix(0));}

/* do500 in ##srfi-69#%hash-table-for-each in k2713 in k609 */
static void C_fcall f_3331(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3331,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3341,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3350,a[2]=((C_word*)t0)[3],a[3]=((C_word)li88),tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_slot(((C_word*)t0)[2],t2);
/* srfi-69.scm: 957  ##sys#for-each */
t6=*((C_word*)lf[107]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}}

/* a3349 in do500 in ##srfi-69#%hash-table-for-each in k2713 in k609 */
static void C_ccall f_3350(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3350,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t2,C_fix(1));
/* srfi-69.scm: 958  proc */
t5=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t3,t4);}

/* k3339 in do500 in ##srfi-69#%hash-table-for-each in k2713 in k609 */
static void C_ccall f_3341(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_3331(t3,((C_word*)t0)[2],t2);}

/* hash-table-values in k2713 in k609 */
static void C_ccall f_3254(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3254,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[37],lf[109]);
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_block_size(t4);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3269,a[2]=t7,a[3]=t4,a[4]=t5,a[5]=((C_word)li86),tmp=(C_word)a,a+=6,tmp));
t9=((C_word*)t7)[1];
f_3269(t9,t1,C_fix(0),C_SCHEME_END_OF_LIST);}

/* loop in hash-table-values in k2713 in k609 */
static void C_fcall f_3269(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3269,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[4]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_slot(((C_word*)t0)[3],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3285,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word)li85),tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_3285(t8,t1,t4,t3);}}

/* loop2 in loop in hash-table-values in k2713 in k609 */
static void C_fcall f_3285(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(3);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3285,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* srfi-69.scm: 940  loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_3269(t5,t1,t4,t3);}
else{
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_slot(t2,C_fix(0));
t6=(C_word)C_slot(t5,C_fix(1));
t7=(C_word)C_a_i_cons(&a,2,t6,t3);
/* srfi-69.scm: 941  loop2 */
t10=t1;
t11=t4;
t12=t7;
t1=t10;
t2=t11;
t3=t12;
goto loop;}}

/* hash-table-keys in k2713 in k609 */
static void C_ccall f_3189(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3189,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[37],lf[108]);
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_block_size(t4);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3204,a[2]=t7,a[3]=t4,a[4]=t5,a[5]=((C_word)li83),tmp=(C_word)a,a+=6,tmp));
t9=((C_word*)t7)[1];
f_3204(t9,t1,C_fix(0),C_SCHEME_END_OF_LIST);}

/* loop in hash-table-keys in k2713 in k609 */
static void C_fcall f_3204(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3204,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[4]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_slot(((C_word*)t0)[3],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3220,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word)li82),tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_3220(t8,t1,t4,t3);}}

/* loop2 in loop in hash-table-keys in k2713 in k609 */
static void C_fcall f_3220(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(3);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3220,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* srfi-69.scm: 925  loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_3204(t5,t1,t4,t3);}
else{
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_slot(t2,C_fix(0));
t6=(C_word)C_slot(t5,C_fix(0));
t7=(C_word)C_a_i_cons(&a,2,t6,t3);
/* srfi-69.scm: 926  loop2 */
t10=t1;
t11=t4;
t12=t7;
t1=t10;
t2=t11;
t3=t12;
goto loop;}}

/* alist->hash-table in k2713 in k609 */
static void C_ccall f_3161(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_3161r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3161r(t0,t1,t2,t3);}}

static void C_ccall f_3161r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(C_word)C_i_check_list_2(t2,lf[106]);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3168,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_apply(4,0,t5,((C_word*)t0)[2],t3);}

/* k3166 in alist->hash-table in k2713 in k609 */
static void C_ccall f_3168(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3168,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3171,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3173,a[2]=t1,a[3]=((C_word)li80),tmp=(C_word)a,a+=4,tmp);
/* for-each */
t4=*((C_word*)lf[107]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a3172 in k3166 in alist->hash-table in k2713 in k609 */
static void C_ccall f_3173(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3173,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3183,a[2]=t2,a[3]=((C_word)li79),tmp=(C_word)a,a+=4,tmp);
/* srfi-69.scm: 908  %hash-table-update! */
t5=*((C_word*)lf[87]+1);
((C_proc6)C_retrieve_proc(t5))(6,t5,t1,((C_word*)t0)[2],t3,*((C_word*)lf[91]+1),t4);}

/* a3182 in a3172 in k3166 in alist->hash-table in k2713 in k609 */
static void C_ccall f_3183(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3183,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_slot(((C_word*)t0)[2],C_fix(1)));}

/* k3169 in k3166 in alist->hash-table in k2713 in k609 */
static void C_ccall f_3171(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* hash-table->alist in k2713 in k609 */
static void C_ccall f_3088(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3088,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[37],lf[105]);
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_block_size(t4);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3103,a[2]=t7,a[3]=t4,a[4]=t5,a[5]=((C_word)li77),tmp=(C_word)a,a+=6,tmp));
t9=((C_word*)t7)[1];
f_3103(t9,t1,C_fix(0),C_SCHEME_END_OF_LIST);}

/* loop in hash-table->alist in k2713 in k609 */
static void C_fcall f_3103(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3103,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[4]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_slot(((C_word*)t0)[3],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3119,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word)li76),tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_3119(t8,t1,t4,t3);}}

/* loop2 in loop in hash-table->alist in k2713 in k609 */
static void C_fcall f_3119(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
loop:
a=C_alloc(6);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3119,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* srfi-69.scm: 897  loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_3103(t5,t1,t4,t3);}
else{
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_slot(t2,C_fix(0));
t6=(C_word)C_slot(t5,C_fix(0));
t7=(C_word)C_slot(t5,C_fix(1));
t8=(C_word)C_a_i_cons(&a,2,t6,t7);
t9=(C_word)C_a_i_cons(&a,2,t8,t3);
/* srfi-69.scm: 898  loop2 */
t12=t1;
t13=t4;
t14=t9;
t1=t12;
t2=t13;
t3=t14;
goto loop;}}

/* hash-table-merge in k2713 in k609 */
static void C_ccall f_3072(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3072,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure_2(t2,lf[37],lf[104]);
t5=(C_word)C_i_check_structure_2(t3,lf[37],lf[104]);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3086,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-69.scm: 883  %hash-table-copy */
t7=*((C_word*)lf[83]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t2);}

/* k3084 in hash-table-merge in k2713 in k609 */
static void C_ccall f_3086(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-69.scm: 883  %hash-table-merge! */
t2=*((C_word*)lf[102]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* hash-table-merge! in k2713 in k609 */
static void C_ccall f_3060(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3060,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure_2(t2,lf[37],lf[103]);
t5=(C_word)C_i_check_structure_2(t3,lf[37],lf[103]);
/* srfi-69.scm: 878  %hash-table-merge! */
t6=*((C_word*)lf[102]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t1,t2,t3);}

/* ##srfi-69#%hash-table-merge! in k2713 in k609 */
static void C_ccall f_2993(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2993,4,t0,t1,t2,t3);}
t4=(C_word)C_slot(t3,C_fix(1));
t5=(C_word)C_block_size(t4);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3005,a[2]=t4,a[3]=t7,a[4]=t2,a[5]=t5,a[6]=((C_word)li72),tmp=(C_word)a,a+=7,tmp));
t9=((C_word*)t7)[1];
f_3005(t9,t1,C_fix(0));}

/* do431 in ##srfi-69#%hash-table-merge! in k2713 in k609 */
static void C_fcall f_3005(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3005,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[4]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3015,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(((C_word*)t0)[2],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3028,a[2]=((C_word*)t0)[4],a[3]=t6,a[4]=((C_word)li71),tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_3028(t8,t3,t4);}}

/* do434 in do431 in ##srfi-69#%hash-table-merge! in k2713 in k609 */
static void C_fcall f_3028(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3028,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3041,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_slot(t3,C_fix(0));
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3054,a[2]=t3,a[3]=((C_word)li70),tmp=(C_word)a,a+=4,tmp);
/* srfi-69.scm: 872  %hash-table-update! */
t7=*((C_word*)lf[87]+1);
((C_proc6)C_retrieve_proc(t7))(6,t7,t4,((C_word*)t0)[2],t5,*((C_word*)lf[91]+1),t6);}}

/* a3053 in do434 in do431 in ##srfi-69#%hash-table-merge! in k2713 in k609 */
static void C_ccall f_3054(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3054,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_slot(((C_word*)t0)[2],C_fix(1)));}

/* k3039 in do434 in do431 in ##srfi-69#%hash-table-merge! in k2713 in k609 */
static void C_ccall f_3041(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_3028(t3,((C_word*)t0)[2],t2);}

/* k3013 in do431 in ##srfi-69#%hash-table-merge! in k2713 in k609 */
static void C_ccall f_3015(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_3005(t3,((C_word*)t0)[2],t2);}

/* hash-table-clear! in k2713 in k609 */
static void C_ccall f_2977(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2977,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[37],lf[100]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2984,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_slot(t2,C_fix(1));
/* srfi-69.scm: 859  vector-fill! */
t6=*((C_word*)lf[101]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,C_SCHEME_END_OF_LIST);}

/* k2982 in hash-table-clear! in k2713 in k609 */
static void C_ccall f_2984(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_set_i_slot(((C_word*)t0)[2],C_fix(2),C_fix(0)));}

/* hash-table-remove! in k2713 in k609 */
static void C_ccall f_2881(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2881,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure_2(t2,lf[37],lf[99]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2888,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm: 836  ##sys#check-closure */
t6=*((C_word*)lf[52]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t3,lf[99]);}

/* k2886 in hash-table-remove! in k2713 in k609 */
static void C_ccall f_2888(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2888,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=(C_word)C_block_size(t2);
t4=(C_word)C_slot(((C_word*)t0)[4],C_fix(2));
t5=t4;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2902,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t8,a[5]=t6,a[6]=((C_word*)t0)[4],a[7]=t3,a[8]=((C_word)li67),tmp=(C_word)a,a+=9,tmp));
t10=((C_word*)t8)[1];
f_2902(t10,((C_word*)t0)[2],C_fix(0));}

/* do409 in k2886 in hash-table-remove! in k2713 in k609 */
static void C_fcall f_2902(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2902,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[7]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_set_i_slot(((C_word*)t0)[6],C_fix(2),((C_word*)((C_word*)t0)[5])[1]));}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2915,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(((C_word*)t0)[3],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2928,a[2]=((C_word*)t0)[2],a[3]=t6,a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=((C_word*)t0)[3],a[7]=((C_word)li66),tmp=(C_word)a,a+=8,tmp));
t8=((C_word*)t6)[1];
f_2928(t8,t3,C_SCHEME_FALSE,t4);}}

/* loop in do409 in k2886 in hash-table-remove! in k2713 in k609 */
static void C_fcall f_2928(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2928,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(C_word)C_slot(t3,C_fix(0));
t5=(C_word)C_slot(t3,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2947,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t5,a[9]=t2,tmp=(C_word)a,a+=10,tmp);
t7=(C_word)C_slot(t4,C_fix(0));
t8=(C_word)C_slot(t4,C_fix(1));
/* srfi-69.scm: 846  func */
t9=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t9))(4,t9,t6,t7,t8);}}

/* k2945 in loop in do409 in k2886 in hash-table-remove! in k2713 in k609 */
static void C_ccall f_2947(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_truep(t1)){
t2=(C_truep(((C_word*)t0)[9])?(C_word)C_i_setslot(((C_word*)t0)[9],C_fix(1),((C_word*)t0)[8]):(C_word)C_i_setslot(((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[8]));
t3=(C_word)C_fixnum_difference(((C_word*)((C_word*)t0)[5])[1],C_fix(1));
t4=C_mutate(((C_word *)((C_word*)t0)[5])+1,t3);
t5=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_TRUE);}
else{
/* srfi-69.scm: 853  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_2928(t2,((C_word*)t0)[4],((C_word*)t0)[2],((C_word*)t0)[8]);}}

/* k2913 in do409 in k2886 in hash-table-remove! in k2713 in k609 */
static void C_ccall f_2915(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_2902(t3,((C_word*)t0)[2],t2);}

/* hash-table-delete! in k2713 in k609 */
static void C_ccall f_2750(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2750,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure_2(t2,lf[37],lf[98]);
t5=(C_word)C_slot(t2,C_fix(1));
t6=(C_word)C_block_size(t5);
t7=(C_word)C_slot(t2,C_fix(4));
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2766,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t5,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* srfi-69.scm: 800  hash */
t9=t7;
((C_proc4)C_retrieve_proc(t9))(4,t9,t8,t3,t6);}

/* k2764 in hash-table-delete! in k2713 in k609 */
static void C_ccall f_2766(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[20],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2766,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(3));
t3=(C_word)C_slot(((C_word*)t0)[6],C_fix(2));
t4=(C_word)C_fixnum_difference(t3,C_fix(1));
t5=(C_word)C_slot(((C_word*)t0)[5],t1);
t6=(C_word)C_eqp(((C_word*)t0)[4],t2);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2786,a[2]=t4,a[3]=((C_word*)t0)[6],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[3],a[7]=((C_word)li63),tmp=(C_word)a,a+=8,tmp);
t8=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,f_2786(t7,C_SCHEME_FALSE,t5));}
else{
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2833,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t8,a[5]=t4,a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[5],a[9]=((C_word)li64),tmp=(C_word)a,a+=10,tmp));
t10=((C_word*)t8)[1];
f_2833(t10,((C_word*)t0)[2],C_SCHEME_FALSE,t5);}}

/* loop in k2764 in hash-table-delete! in k2713 in k609 */
static void C_fcall f_2833(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2833,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(C_word)C_slot(t3,C_fix(0));
t5=(C_word)C_slot(t3,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2852,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t5,a[10]=t2,tmp=(C_word)a,a+=11,tmp);
t7=(C_word)C_slot(t4,C_fix(0));
/* srfi-69.scm: 823  test */
t8=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t8))(4,t8,t6,((C_word*)t0)[2],t7);}}

/* k2850 in loop in k2764 in hash-table-delete! in k2713 in k609 */
static void C_ccall f_2852(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_truep(((C_word*)t0)[10])?(C_word)C_i_setslot(((C_word*)t0)[10],C_fix(1),((C_word*)t0)[9]):(C_word)C_i_setslot(((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[9]));
t3=(C_word)C_i_set_i_slot(((C_word*)t0)[6],C_fix(2),((C_word*)t0)[5]);
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_TRUE);}
else{
/* srfi-69.scm: 830  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_2833(t2,((C_word*)t0)[4],((C_word*)t0)[2],((C_word*)t0)[9]);}}

/* loop in k2764 in hash-table-delete! in k2713 in k609 */
static C_word C_fcall f_2786(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
loop:
C_stack_check;
if(C_truep((C_word)C_i_nullp(t2))){
return(C_SCHEME_FALSE);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_slot(t3,C_fix(0));
t6=(C_word)C_eqp(((C_word*)t0)[6],t5);
if(C_truep(t6)){
t7=(C_truep(t1)?(C_word)C_i_setslot(t1,C_fix(1),t4):(C_word)C_i_setslot(((C_word*)t0)[5],((C_word*)t0)[4],t4));
t8=(C_word)C_i_set_i_slot(((C_word*)t0)[3],C_fix(2),((C_word*)t0)[2]);
return(C_SCHEME_TRUE);}
else{
t10=t2;
t11=t4;
t1=t10;
t2=t11;
goto loop;}}}

/* hash-table-exists? in k2713 in k609 */
static void C_ccall f_2729(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2729,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure_2(t2,lf[37],lf[97]);
t5=(C_word)C_slot(lf[4],C_fix(0));
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2748,a[2]=t1,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* srfi-69.scm: 789  %hash-table-ref */
t7=*((C_word*)lf[94]+1);
((C_proc5)C_retrieve_proc(t7))(5,t7,t6,t2,t3,*((C_word*)lf[3]+1));}

/* k2746 in hash-table-exists? in k2713 in k609 */
static void C_ccall f_2748(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_not(t2));}

/* hash-table-ref/default in k2713 in k609 */
static void C_ccall f_2717(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2717,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_check_structure_2(t2,lf[37],lf[96]);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2726,a[2]=t4,a[3]=((C_word)li60),tmp=(C_word)a,a+=4,tmp);
/* srfi-69.scm: 785  %hash-table-ref */
t7=*((C_word*)lf[94]+1);
((C_proc5)C_retrieve_proc(t7))(5,t7,t1,t2,t3,t6);}

/* a2725 in hash-table-ref/default in k2713 in k609 */
static void C_ccall f_2726(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2726,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* ##srfi-69#%hash-table-ref in k609 */
static void C_ccall f_2604(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2604,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_slot(t2,C_fix(1));
t6=(C_word)C_slot(t2,C_fix(3));
t7=(C_word)C_slot(t2,C_fix(4));
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2617,a[2]=t1,a[3]=t3,a[4]=t4,a[5]=t5,a[6]=t6,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
t9=(C_word)C_block_size(t5);
/* srfi-69.scm: 753  hash */
t10=t7;
((C_proc4)C_retrieve_proc(t10))(4,t10,t8,t3,t9);}

/* k2615 in ##srfi-69#%hash-table-ref in k609 */
static void C_ccall f_2617(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2617,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[7],((C_word*)t0)[6]);
if(C_truep(t2)){
t3=(C_word)C_slot(((C_word*)t0)[5],t1);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2632,a[2]=t5,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word)li57),tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_2632(t7,((C_word*)t0)[2],t3);}
else{
t3=(C_word)C_slot(((C_word*)t0)[5],t1);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2674,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[6],a[4]=t5,a[5]=((C_word*)t0)[4],a[6]=((C_word)li58),tmp=(C_word)a,a+=7,tmp));
t7=((C_word*)t5)[1];
f_2674(t7,((C_word*)t0)[2],t3);}}

/* loop in k2615 in ##srfi-69#%hash-table-ref in k609 */
static void C_fcall f_2674(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2674,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
/* srfi-69.scm: 766  def */
t3=((C_word*)t0)[5];
((C_proc2)C_retrieve_proc(t3))(2,t3,t1);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2693,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_slot(t3,C_fix(0));
/* srfi-69.scm: 768  test */
t6=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,((C_word*)t0)[2],t5);}}

/* k2691 in loop in k2615 in ##srfi-69#%hash-table-ref in k609 */
static void C_ccall f_2693(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_slot(((C_word*)t0)[4],C_fix(1)));}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* srfi-69.scm: 770  loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_2674(t3,((C_word*)t0)[5],t2);}}

/* loop in k2615 in ##srfi-69#%hash-table-ref in k609 */
static void C_fcall f_2632(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
loop:
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2632,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
/* srfi-69.scm: 758  def */
t3=((C_word*)t0)[4];
((C_proc2)C_retrieve_proc(t3))(2,t3,t1);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t3,C_fix(0));
t5=(C_word)C_eqp(((C_word*)t0)[3],t4);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_slot(t3,C_fix(1)));}
else{
t6=(C_word)C_slot(t2,C_fix(1));
/* srfi-69.scm: 762  loop */
t8=t1;
t9=t6;
t1=t8;
t2=t9;
goto loop;}}}

/* hash-table-set! in k609 */
static void C_ccall f_2590(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2590,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_check_structure_2(t2,lf[37],lf[93]);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2595,a[2]=t4,a[3]=((C_word)li55),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2599,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* srfi-69.scm: 742  %hash-table-update! */
t8=*((C_word*)lf[87]+1);
((C_proc6)C_retrieve_proc(t8))(6,t8,t7,t2,t3,t6,t6);}

/* k2597 in hash-table-set! in k609 */
static void C_ccall f_2599(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,*((C_word*)lf[2]+1));}

/* thunk in hash-table-set! in k609 */
static void C_ccall f_2595(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2595,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* hash-table-update!/default in k609 */
static void C_ccall f_2575(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_2575,6,t0,t1,t2,t3,t4,t5);}
t6=(C_word)C_i_check_structure_2(t2,lf[37],lf[92]);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2582,a[2]=t4,a[3]=t3,a[4]=t2,a[5]=t1,a[6]=t5,tmp=(C_word)a,a+=7,tmp);
/* srfi-69.scm: 736  ##sys#check-closure */
t8=*((C_word*)lf[52]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,t4,lf[92]);}

/* k2580 in hash-table-update!/default in k609 */
static void C_ccall f_2582(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2582,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2587,a[2]=((C_word*)t0)[6],a[3]=((C_word)li53),tmp=(C_word)a,a+=4,tmp);
/* srfi-69.scm: 737  %hash-table-update! */
t3=*((C_word*)lf[87]+1);
((C_proc6)C_retrieve_proc(t3))(6,t3,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* a2586 in k2580 in hash-table-update!/default in k609 */
static void C_ccall f_2587(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2587,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* hash-table-update! in k609 */
static void C_ccall f_2494(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+15)){
C_save_and_reclaim((void*)tr4r,(void*)f_2494r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_2494r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2494r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(15);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2496,a[2]=t3,a[3]=t2,a[4]=((C_word)li48),tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2510,a[2]=t5,a[3]=t3,a[4]=t2,a[5]=((C_word)li50),tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2527,a[2]=t6,a[3]=((C_word)li51),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-func313327 */
t8=t7;
f_2527(t8,t1);}
else{
t8=(C_word)C_i_car(t4);
t9=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t9))){
/* def-thunk314322 */
t10=t6;
f_2510(t10,t1,t8);}
else{
t10=(C_word)C_i_car(t9);
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
/* body311316 */
t12=t5;
f_2496(t12,t1,t8,t10);}
else{
/* ##sys#error */
t12=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t1,lf[0],t11);}}}}

/* def-func313 in hash-table-update! in k609 */
static void C_fcall f_2527(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2527,NULL,2,t0,t1);}
/* def-thunk314322 */
t2=((C_word*)t0)[2];
f_2510(t2,t1,*((C_word*)lf[91]+1));}

/* def-thunk314 in hash-table-update! in k609 */
static void C_fcall f_2510(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2510,NULL,3,t0,t1,t2);}
t3=(C_word)C_slot(((C_word*)t0)[4],C_fix(9));
t4=(C_truep(t3)?t3:(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2522,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=((C_word)li49),tmp=(C_word)a,a+=5,tmp));
/* body311316 */
t5=((C_word*)t0)[2];
f_2496(t5,t1,t2,t4);}

/* f_2522 in def-thunk314 in hash-table-update! in k609 */
static void C_ccall f_2522(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2522,2,t0,t1);}
/* srfi-69.scm: 726  ##sys#signal-hook */
t2=*((C_word*)lf[10]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,t1,lf[89],lf[88],lf[90],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* body311 in hash-table-update! in k609 */
static void C_fcall f_2496(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2496,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure_2(((C_word*)t0)[3],lf[37],lf[88]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2503,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* srfi-69.scm: 730  ##sys#check-closure */
t6=*((C_word*)lf[52]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t2,lf[88]);}

/* k2501 in body311 in hash-table-update! in k609 */
static void C_ccall f_2503(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2503,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2506,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* srfi-69.scm: 731  ##sys#check-closure */
t3=*((C_word*)lf[52]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],lf[88]);}

/* k2504 in k2501 in body311 in hash-table-update! in k609 */
static void C_ccall f_2506(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-69.scm: 732  %hash-table-update! */
t2=*((C_word*)lf[87]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##srfi-69#%hash-table-update! in k609 */
static void C_ccall f_2258(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[17],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_2258,6,t0,t1,t2,t3,t4,t5);}
t6=(C_word)C_slot(t2,C_fix(4));
t7=(C_word)C_slot(t2,C_fix(3));
t8=(C_word)C_slot(t2,C_fix(2));
t9=(C_word)C_fixnum_plus(t8,C_fix(1));
t10=(C_word)C_slot(t2,C_fix(5));
t11=(C_word)C_slot(t2,C_fix(6));
t12=C_SCHEME_UNDEFINED;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_set_block_item(t13,0,(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_2279,a[2]=t10,a[3]=((C_word*)t0)[2],a[4]=t11,a[5]=t5,a[6]=t4,a[7]=t9,a[8]=t3,a[9]=t7,a[10]=((C_word*)t0)[3],a[11]=t6,a[12]=t13,a[13]=t2,a[14]=((C_word)li46),tmp=(C_word)a,a+=15,tmp));
t15=((C_word*)t13)[1];
f_2279(t15,t1);}

/* re-enter in ##srfi-69#%hash-table-update! in k609 */
static void C_fcall f_2279(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[20],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2279,NULL,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[13],C_fix(1));
t3=(C_word)C_block_size(t2);
t4=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_2484,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=t3,a[11]=((C_word*)t0)[11],a[12]=t2,a[13]=t1,a[14]=((C_word*)t0)[12],a[15]=((C_word*)t0)[13],tmp=(C_word)a,a+=16,tmp);
t5=(C_word)C_a_i_times(&a,2,t3,((C_word*)t0)[2]);
/* srfi-69.scm: 671  floor */
t6=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}

/* k2482 in re-enter in ##srfi-69#%hash-table-update! in k609 */
static void C_ccall f_2484(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2484,2,t0,t1);}
t2=(C_word)C_i_inexact_to_exact(t1);
t3=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_2476,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],tmp=(C_word)a,a+=15,tmp);
t4=(C_word)C_a_i_times(&a,2,((C_word*)t0)[10],((C_word*)t0)[3]);
/* srfi-69.scm: 672  floor */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* k2474 in k2482 in re-enter in ##srfi-69#%hash-table-update! in k609 */
static void C_ccall f_2476(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2476,2,t0,t1);}
t2=(C_word)C_i_inexact_to_exact(t1);
t3=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_2295,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],tmp=(C_word)a,a+=16,tmp);
/* srfi-69.scm: 673  hash */
t4=((C_word*)t0)[10];
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[6],((C_word*)t0)[9]);}

/* k2293 in k2474 in k2482 in re-enter in ##srfi-69#%hash-table-update! in k609 */
static void C_ccall f_2295(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2295,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_2301,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=t1,a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],tmp=(C_word)a,a+=15,tmp);
if(C_truep((C_word)C_fixnum_lessp(((C_word*)t0)[10],C_fix(1073741823)))){
t3=(C_word)C_fixnum_less_or_equal_p(((C_word*)t0)[3],((C_word*)t0)[6]);
t4=t2;
f_2301(t4,(C_truep(t3)?(C_word)C_fixnum_less_or_equal_p(((C_word*)t0)[6],((C_word*)t0)[2]):C_SCHEME_FALSE));}
else{
t3=t2;
f_2301(t3,C_SCHEME_FALSE);}}

/* k2299 in k2293 in k2474 in k2482 in re-enter in ##srfi-69#%hash-table-update! in k609 */
static void C_fcall f_2301(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[39],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2301,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2304,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[12],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[14],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2317,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_fixnum_times(((C_word*)t0)[9],C_fix(2));
t5=(C_word)C_i_fixnum_min(C_fix(1073741823),t4);
/* srfi-69.scm: 679  hash-table-canonical-length */
t6=*((C_word*)lf[34]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t3,lf[32],t5);}
else{
t2=(C_word)C_slot(((C_word*)t0)[11],((C_word*)t0)[8]);
t3=(C_word)C_eqp(((C_word*)t0)[7],((C_word*)t0)[6]);
if(C_truep(t3)){
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2339,a[2]=t5,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[14],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[11],a[9]=t2,a[10]=((C_word*)t0)[5],a[11]=((C_word)li44),tmp=(C_word)a,a+=12,tmp));
t7=((C_word*)t5)[1];
f_2339(t7,((C_word*)t0)[12],t2);}
else{
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2402,a[2]=((C_word*)t0)[6],a[3]=t5,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[14],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[11],a[10]=t2,a[11]=((C_word*)t0)[5],a[12]=((C_word)li45),tmp=(C_word)a,a+=13,tmp));
t7=((C_word*)t5)[1];
f_2402(t7,((C_word*)t0)[12],t2);}}}

/* loop in k2299 in k2293 in k2474 in k2482 in re-enter in ##srfi-69#%hash-table-update! in k609 */
static void C_fcall f_2402(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[20],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2402,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2412,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],tmp=(C_word)a,a+=9,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2430,a[2]=t3,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* srfi-69.scm: 707  thunk */
t5=((C_word*)t0)[4];
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2439,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_slot(t3,C_fix(0));
/* srfi-69.scm: 713  test */
t6=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,((C_word*)t0)[11],t5);}}

/* k2437 in loop in k2299 in k2293 in k2474 in k2482 in re-enter in ##srfi-69#%hash-table-update! in k609 */
static void C_ccall f_2439(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2439,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2442,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
/* srfi-69.scm: 714  func */
t4=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* srfi-69.scm: 717  loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_2402(t3,((C_word*)t0)[5],t2);}}

/* k2440 in k2437 in loop in k2299 in k2293 in k2474 in k2482 in re-enter in ##srfi-69#%hash-table-update! in k609 */
static void C_ccall f_2442(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[3],C_fix(1),t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* k2428 in loop in k2299 in k2293 in k2474 in k2482 in re-enter in ##srfi-69#%hash-table-update! in k609 */
static void C_ccall f_2430(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-69.scm: 707  func */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2410 in loop in k2299 in k2293 in k2474 in k2482 in re-enter in ##srfi-69#%hash-table-update! in k609 */
static void C_ccall f_2412(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2412,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[7]);
t4=(C_word)C_i_setslot(((C_word*)t0)[6],((C_word*)t0)[5],t3);
t5=(C_word)C_i_set_i_slot(((C_word*)t0)[4],C_fix(2),((C_word*)t0)[3]);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t1);}

/* loop in k2299 in k2293 in k2474 in k2482 in re-enter in ##srfi-69#%hash-table-update! in k609 */
static void C_fcall f_2339(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
loop:
a=C_alloc(17);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2339,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2349,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2367,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* srfi-69.scm: 693  thunk */
t5=((C_word*)t0)[3];
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t3,C_fix(0));
t5=(C_word)C_eqp(((C_word*)t0)[10],t4);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2379,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_slot(t3,C_fix(1));
/* srfi-69.scm: 700  func */
t8=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t8))(3,t8,t6,t7);}
else{
t6=(C_word)C_slot(t2,C_fix(1));
/* srfi-69.scm: 703  loop */
t12=t1;
t13=t6;
t1=t12;
t2=t13;
goto loop;}}}

/* k2377 in loop in k2299 in k2293 in k2474 in k2482 in re-enter in ##srfi-69#%hash-table-update! in k609 */
static void C_ccall f_2379(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[3],C_fix(1),t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* k2365 in loop in k2299 in k2293 in k2474 in k2482 in re-enter in ##srfi-69#%hash-table-update! in k609 */
static void C_ccall f_2367(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-69.scm: 693  func */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2347 in loop in k2299 in k2293 in k2474 in k2482 in re-enter in ##srfi-69#%hash-table-update! in k609 */
static void C_ccall f_2349(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2349,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[7]);
t4=(C_word)C_i_setslot(((C_word*)t0)[6],((C_word*)t0)[5],t3);
t5=(C_word)C_i_set_i_slot(((C_word*)t0)[4],C_fix(2),((C_word*)t0)[3]);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t1);}

/* k2315 in k2299 in k2293 in k2474 in k2482 in re-enter in ##srfi-69#%hash-table-update! in k609 */
static void C_ccall f_2317(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-69.scm: 678  make-vector */
t2=*((C_word*)lf[35]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k2302 in k2299 in k2293 in k2474 in k2482 in re-enter in ##srfi-69#%hash-table-update! in k609 */
static void C_ccall f_2304(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2304,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2307,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* srfi-69.scm: 684  hash-table-rehash */
t3=*((C_word*)lf[85]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2305 in k2302 in k2299 in k2293 in k2474 in k2482 in re-enter in ##srfi-69#%hash-table-update! in k609 */
static void C_ccall f_2307(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[5],C_fix(1),((C_word*)t0)[4]);
/* srfi-69.scm: 686  re-enter */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2279(t3,((C_word*)t0)[2]);}

/* ##srfi-69#hash-table-rehash in k609 */
static void C_ccall f_2179(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[11],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2179,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_block_size(t2);
t6=(C_word)C_block_size(t3);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2191,a[2]=t6,a[3]=t4,a[4]=t3,a[5]=t2,a[6]=t8,a[7]=t5,a[8]=((C_word)li42),tmp=(C_word)a,a+=9,tmp));
t10=((C_word*)t8)[1];
f_2191(t10,t1,C_fix(0));}

/* do253 in ##srfi-69#hash-table-rehash in k609 */
static void C_fcall f_2191(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2191,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[7]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2201,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(((C_word*)t0)[5],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2214,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t6,a[5]=((C_word*)t0)[4],a[6]=((C_word)li41),tmp=(C_word)a,a+=7,tmp));
t8=((C_word*)t6)[1];
f_2214(t8,t3,t4);}}

/* loop in do253 in ##srfi-69#hash-table-rehash in k609 */
static void C_fcall f_2214(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2214,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t3,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2230,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=t4,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
/* srfi-69.scm: 653  hash */
t6=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,t4,((C_word*)t0)[2]);}}

/* k2228 in loop in do253 in ##srfi-69#hash-table-rehash in k609 */
static void C_ccall f_2230(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2230,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[7],C_fix(1));
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t2);
t4=(C_word)C_slot(((C_word*)t0)[5],t1);
t5=(C_word)C_a_i_cons(&a,2,t3,t4);
t6=(C_word)C_i_setslot(((C_word*)t0)[5],t1,t5);
t7=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* srfi-69.scm: 657  loop */
t8=((C_word*)((C_word*)t0)[3])[1];
f_2214(t8,((C_word*)t0)[2],t7);}

/* k2199 in do253 in ##srfi-69#hash-table-rehash in k609 */
static void C_ccall f_2201(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_2191(t3,((C_word*)t0)[2],t2);}

/* hash-table-copy in k609 */
static void C_ccall f_2170(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2170,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[37],lf[84]);
/* srfi-69.scm: 637  %hash-table-copy */
t4=*((C_word*)lf[83]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t2);}

/* ##srfi-69#%hash-table-copy in k609 */
static void C_ccall f_2058(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2058,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(1));
t4=(C_word)C_block_size(t3);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2068,a[2]=t1,a[3]=t3,a[4]=t2,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* srfi-69.scm: 617  make-vector */
t6=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,t4,C_SCHEME_END_OF_LIST);}

/* k2066 in ##srfi-69#%hash-table-copy in k609 */
static void C_ccall f_2068(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2068,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2073,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word)li38),tmp=(C_word)a,a+=8,tmp));
t5=((C_word*)t3)[1];
f_2073(t5,((C_word*)t0)[2],C_fix(0));}

/* do237 in k2066 in ##srfi-69#%hash-table-copy in k609 */
static void C_fcall f_2073(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2073,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[6]))){
t3=(C_word)C_slot(((C_word*)t0)[5],C_fix(3));
t4=(C_word)C_slot(((C_word*)t0)[5],C_fix(4));
t5=(C_word)C_slot(((C_word*)t0)[5],C_fix(2));
t6=(C_word)C_slot(((C_word*)t0)[5],C_fix(5));
t7=(C_word)C_slot(((C_word*)t0)[5],C_fix(6));
t8=(C_word)C_slot(((C_word*)t0)[5],C_fix(7));
t9=(C_word)C_slot(((C_word*)t0)[5],C_fix(8));
t10=(C_word)C_slot(((C_word*)t0)[5],C_fix(9));
/* srfi-69.scm: 620  %make-hash-table */
t11=*((C_word*)lf[36]+1);
((C_proc11)C_retrieve_proc(t11))(11,t11,t1,t3,t4,t5,t6,t7,t8,t9,t10,((C_word*)t0)[4]);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2129,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_slot(((C_word*)t0)[2],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2135,a[2]=t6,a[3]=((C_word)li37),tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_2135(t8,t3,t4);}}

/* copy-loop in do237 in k2066 in ##srfi-69#%hash-table-copy in k609 */
static void C_fcall f_2135(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
a=C_alloc(7);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2135,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t3,C_fix(0));
t5=(C_word)C_slot(t3,C_fix(1));
t6=(C_word)C_a_i_cons(&a,2,t4,t5);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2156,a[2]=t6,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t8=(C_word)C_slot(t2,C_fix(1));
/* srfi-69.scm: 633  copy-loop */
t10=t7;
t11=t8;
t1=t10;
t2=t11;
goto loop;}}

/* k2154 in copy-loop in do237 in k2066 in ##srfi-69#%hash-table-copy in k609 */
static void C_ccall f_2156(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2156,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k2127 in do237 in k2066 in ##srfi-69#%hash-table-copy in k609 */
static void C_ccall f_2129(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[5],((C_word*)t0)[4],t1);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_2073(t4,((C_word*)t0)[2],t3);}

/* hash-table-initial in k609 */
static void C_ccall f_2043(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2043,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[37],lf[82]);
t4=(C_word)C_slot(t2,C_fix(9));
if(C_truep(t4)){
/* srfi-69.scm: 608  thunk */
t5=t4;
((C_proc2)C_retrieve_proc(t5))(2,t5,t1);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}

/* hash-table-has-initial? in k609 */
static void C_ccall f_2031(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2031,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[37],lf[81]);
t4=(C_word)C_slot(t2,C_fix(9));
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_truep(t4)?C_SCHEME_TRUE:C_SCHEME_FALSE));}

/* hash-table-weak-values in k609 */
static void C_ccall f_2022(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2022,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[37],lf[80]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(8)));}

/* hash-table-weak-keys in k609 */
static void C_ccall f_2013(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2013,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[37],lf[79]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(7)));}

/* hash-table-max-load in k609 */
static void C_ccall f_2004(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2004,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[37],lf[78]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(6)));}

/* hash-table-min-load in k609 */
static void C_ccall f_1995(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1995,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[37],lf[77]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(5)));}

/* hash-table-hash-function in k609 */
static void C_ccall f_1986(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1986,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[37],lf[76]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(4)));}

/* hash-table-equivalence-function in k609 */
static void C_ccall f_1977(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1977,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[37],lf[75]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(3)));}

/* hash-table-size in k609 */
static void C_ccall f_1968(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1968,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[37],lf[74]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(2)));}

/* hash-table? in k609 */
static void C_ccall f_1962(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1962,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[37]));}

/* make-hash-table in k609 */
static void C_ccall f_1599(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+47)){
C_save_and_reclaim((void*)tr2r,(void*)f_1599r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1599r(t0,t1,t2);}}

static void C_ccall f_1599r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word *a=C_alloc(47);
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=*((C_word*)lf[40]+1);
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_FALSE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_fix(307);
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_SCHEME_FALSE;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=lf[45];
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=lf[46];
t16=(*a=C_VECTOR_TYPE|1,a[1]=t15,tmp=(C_word)a,a+=2,tmp);
t17=C_SCHEME_FALSE;
t18=(*a=C_VECTOR_TYPE|1,a[1]=t17,tmp=(C_word)a,a+=2,tmp);
t19=C_SCHEME_FALSE;
t20=(*a=C_VECTOR_TYPE|1,a[1]=t19,tmp=(C_word)a,a+=2,tmp);
t21=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1601,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t6,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t22=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_1677,a[2]=t4,a[3]=t2,a[4]=t21,a[5]=t12,a[6]=t20,a[7]=t18,a[8]=t16,a[9]=t14,a[10]=t8,a[11]=t6,a[12]=t1,a[13]=t10,tmp=(C_word)a,a+=14,tmp);
if(C_truep((C_word)C_i_nullp(((C_word*)t4)[1]))){
t23=t22;
f_1677(t23,C_SCHEME_UNDEFINED);}
else{
t23=(C_word)C_i_car(((C_word*)t4)[1]);
t24=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1952,a[2]=t4,a[3]=t23,a[4]=t6,a[5]=t22,tmp=(C_word)a,a+=6,tmp);
/* srfi-69.scm: 487  keyword? */
t25=*((C_word*)lf[21]+1);
((C_proc3)C_retrieve_proc(t25))(3,t25,t24,t23);}}

/* k1950 in make-hash-table in k609 */
static void C_ccall f_1952(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1952,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
f_1677(t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1955,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* srfi-69.scm: 488  ##sys#check-closure */
t3=*((C_word*)lf[52]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],lf[44]);}}

/* k1953 in k1950 in make-hash-table in k609 */
static void C_ccall f_1955(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,((C_word*)t0)[4]);
t3=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=((C_word*)t0)[2];
f_1677(t5,t4);}

/* k1675 in make-hash-table in k609 */
static void C_fcall f_1677(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[20],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1677,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_1680,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
if(C_truep((C_word)C_i_nullp(((C_word*)((C_word*)t0)[2])[1]))){
t3=t2;
f_1680(t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_i_car(((C_word*)((C_word*)t0)[2])[1]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1932,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[10],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* srfi-69.scm: 493  keyword? */
t5=*((C_word*)lf[21]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t3);}}

/* k1930 in k1675 in make-hash-table in k609 */
static void C_ccall f_1932(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1932,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
f_1680(t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1935,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* srfi-69.scm: 494  ##sys#check-closure */
t3=*((C_word*)lf[52]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],lf[44]);}}

/* k1933 in k1930 in k1675 in make-hash-table in k609 */
static void C_ccall f_1935(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,((C_word*)t0)[4]);
t3=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=((C_word*)t0)[2];
f_1680(t5,t4);}

/* k1678 in k1675 in make-hash-table in k609 */
static void C_fcall f_1680(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[20],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1680,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_1683,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
if(C_truep((C_word)C_i_nullp(((C_word*)((C_word*)t0)[2])[1]))){
t3=t2;
f_1683(t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_i_car(((C_word*)((C_word*)t0)[2])[1]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1900,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[13],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* srfi-69.scm: 499  keyword? */
t5=*((C_word*)lf[21]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t3);}}

/* k1898 in k1678 in k1675 in make-hash-table in k609 */
static void C_ccall f_1900(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1900,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
f_1683(t2,C_SCHEME_UNDEFINED);}
else{
t2=(C_word)C_i_check_exact_2(((C_word*)t0)[4],lf[44]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1906,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_lessp(C_fix(0),((C_word*)t0)[4]))){
t4=t3;
f_1906(2,t4,C_SCHEME_UNDEFINED);}
else{
/* srfi-69.scm: 502  error */
t4=*((C_word*)lf[49]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,lf[44],lf[72],((C_word*)t0)[4]);}}}

/* k1904 in k1898 in k1678 in k1675 in make-hash-table in k609 */
static void C_ccall f_1906(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_word)C_i_fixnum_min(*((C_word*)lf[55]+1),((C_word*)t0)[5]);
t3=C_mutate(((C_word *)((C_word*)t0)[4])+1,t2);
t4=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[3])+1,t4);
t6=((C_word*)t0)[2];
f_1683(t6,t5);}

/* k1681 in k1678 in k1675 in make-hash-table in k609 */
static void C_fcall f_1683(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[27],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1683,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_1686,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],tmp=(C_word)a,a+=12,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_1718,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[13],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=t4,a[11]=((C_word*)t0)[3],a[12]=((C_word)li25),tmp=(C_word)a,a+=13,tmp));
t6=((C_word*)t4)[1];
f_1718(t6,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* loop in k1681 in k1678 in k1675 in make-hash-table in k609 */
static void C_fcall f_1718(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[20],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1718,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1729,a[2]=((C_word*)t0)[11],a[3]=t3,a[4]=((C_word)li23),tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_1739,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=t3,a[12]=t1,a[13]=((C_word*)t0)[10],a[14]=t2,tmp=(C_word)a,a+=15,tmp);
/* srfi-69.scm: 512  keyword? */
t6=*((C_word*)lf[21]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t3);}}

/* k1737 in loop in k1681 in k1678 in k1675 in make-hash-table in k609 */
static void C_ccall f_1739(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1739,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[14]);
t3=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_1745,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=t2,tmp=(C_word)a,a+=15,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t4=t3;
f_1745(2,t4,(C_word)C_i_car(t2));}
else{
/* srfi-69.scm: 516  invarg-err */
t4=((C_word*)t0)[2];
f_1729(t4,t3,lf[70]);}}
else{
/* srfi-69.scm: 548  invarg-err */
t2=((C_word*)t0)[2];
f_1729(t2,((C_word*)t0)[12],lf[71]);}}

/* k1743 in k1737 in loop in k1681 in k1678 in k1675 in make-hash-table in k609 */
static void C_ccall f_1745(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word ab[34],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1745,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1748,a[2]=((C_word*)t0)[12],a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[14],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[11],lf[51]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1761,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm: 519  ##sys#check-closure */
t5=*((C_word*)lf[52]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t1,lf[44]);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[11],lf[53]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1771,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm: 522  ##sys#check-closure */
t6=*((C_word*)lf[52]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t1,lf[44]);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[11],lf[54]);
if(C_truep(t5)){
t6=(C_word)C_i_check_exact_2(t1,lf[44]);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1784,a[2]=t2,a[3]=((C_word*)t0)[8],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_fixnum_lessp(C_fix(0),t1))){
t8=t7;
f_1784(2,t8,C_SCHEME_UNDEFINED);}
else{
/* srfi-69.scm: 527  error */
t8=*((C_word*)lf[49]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t7,lf[44],lf[56],t1);}}
else{
t6=(C_word)C_eqp(((C_word*)t0)[11],lf[57]);
if(C_truep(t6)){
t7=C_mutate(((C_word *)((C_word*)t0)[7])+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1802,a[2]=t1,a[3]=((C_word)li24),tmp=(C_word)a,a+=4,tmp));
t8=t2;
f_1748(2,t8,t7);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[11],lf[58]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1812,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm: 532  ##sys#check-inexact */
t9=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t8,t1,lf[44]);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[11],lf[63]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1837,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm: 537  ##sys#check-inexact */
t10=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t9,t1,lf[44]);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[11],lf[67]);
if(C_truep(t9)){
t10=(C_truep(t1)?C_SCHEME_TRUE:C_SCHEME_FALSE);
t11=C_mutate(((C_word *)((C_word*)t0)[4])+1,t10);
t12=t2;
f_1748(2,t12,t11);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[11],lf[68]);
if(C_truep(t10)){
t11=(C_truep(t1)?C_SCHEME_TRUE:C_SCHEME_FALSE);
t12=C_mutate(((C_word *)((C_word*)t0)[3])+1,t11);
t13=t2;
f_1748(2,t13,t12);}
else{
/* srfi-69.scm: 546  invarg-err */
t11=((C_word*)t0)[2];
f_1729(t11,t2,lf[69]);}}}}}}}}}

/* k1835 in k1743 in k1737 in loop in k1681 in k1678 in k1675 in make-hash-table in k609 */
static void C_ccall f_1837(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1837,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1840,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_flonum_lessp(lf[64],((C_word*)t0)[3]);
t4=(C_truep(t3)?(C_word)C_flonum_lessp(((C_word*)t0)[3],lf[65]):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=t2;
f_1840(2,t5,C_SCHEME_UNDEFINED);}
else{
/* srfi-69.scm: 539  error */
t5=*((C_word*)lf[49]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t2,lf[44],lf[66],((C_word*)t0)[3]);}}

/* k1838 in k1835 in k1743 in k1737 in loop in k1681 in k1678 in k1675 in make-hash-table in k609 */
static void C_ccall f_1840(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
f_1748(2,t3,t2);}

/* k1810 in k1743 in k1737 in loop in k1681 in k1678 in k1675 in make-hash-table in k609 */
static void C_ccall f_1812(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1812,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1815,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_flonum_lessp(lf[59],((C_word*)t0)[3]);
t4=(C_truep(t3)?(C_word)C_flonum_lessp(((C_word*)t0)[3],lf[60]):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=t2;
f_1815(2,t5,C_SCHEME_UNDEFINED);}
else{
/* srfi-69.scm: 534  error */
t5=*((C_word*)lf[49]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t2,lf[44],lf[61],((C_word*)t0)[3]);}}

/* k1813 in k1810 in k1743 in k1737 in loop in k1681 in k1678 in k1675 in make-hash-table in k609 */
static void C_ccall f_1815(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
f_1748(2,t3,t2);}

/* f_1802 in k1743 in k1737 in loop in k1681 in k1678 in k1675 in make-hash-table in k609 */
static void C_ccall f_1802(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1802,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k1782 in k1743 in k1737 in loop in k1681 in k1678 in k1675 in make-hash-table in k609 */
static void C_ccall f_1784(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_fixnum_min(*((C_word*)lf[55]+1),((C_word*)t0)[4]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
f_1748(2,t4,t3);}

/* k1769 in k1743 in k1737 in loop in k1681 in k1678 in k1675 in make-hash-table in k609 */
static void C_ccall f_1771(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
f_1748(2,t3,t2);}

/* k1759 in k1743 in k1737 in loop in k1681 in k1678 in k1675 in make-hash-table in k609 */
static void C_ccall f_1761(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
f_1748(2,t3,t2);}

/* k1746 in k1743 in k1737 in loop in k1681 in k1678 in k1675 in make-hash-table in k609 */
static void C_ccall f_1748(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* srfi-69.scm: 547  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1718(t3,((C_word*)t0)[2],t2);}

/* invarg-err in loop in k1681 in k1678 in k1675 in make-hash-table in k609 */
static void C_fcall f_1729(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1729,NULL,3,t0,t1,t2);}
/* srfi-69.scm: 511  error */
t3=*((C_word*)lf[49]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t1,lf[44],t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1684 in k1681 in k1678 in k1675 in make-hash-table in k609 */
static void C_ccall f_1686(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1686,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_1689,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
if(C_truep((C_word)C_flonum_lessp(((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[7])[1]))){
/* srfi-69.scm: 551  error */
t3=*((C_word*)lf[49]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,lf[44],lf[50],((C_word*)((C_word*)t0)[7])[1],((C_word*)((C_word*)t0)[6])[1]);}
else{
t3=t2;
f_1689(2,t3,C_SCHEME_UNDEFINED);}}

/* k1687 in k1684 in k1681 in k1678 in k1675 in make-hash-table in k609 */
static void C_ccall f_1689(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1689,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_1693,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
/* srfi-69.scm: 553  hash-table-canonical-length */
t3=*((C_word*)lf[34]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[32],((C_word*)((C_word*)t0)[11])[1]);}

/* k1691 in k1687 in k1684 in k1681 in k1678 in k1675 in make-hash-table in k609 */
static void C_ccall f_1693(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1693,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[11])+1,t1);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1696,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
if(C_truep(((C_word*)((C_word*)t0)[8])[1])){
t4=t3;
f_1696(t4,C_SCHEME_UNDEFINED);}
else{
t4=f_1601(((C_word*)t0)[2]);
if(C_truep(t4)){
t5=C_mutate(((C_word *)((C_word*)t0)[8])+1,t4);
t6=t3;
f_1696(t6,t5);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1709,a[2]=t3,a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
/* srfi-69.scm: 560  warning */
t6=*((C_word*)lf[47]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,lf[44],lf[48]);}}}

/* k1707 in k1691 in k1687 in k1684 in k1681 in k1678 in k1675 in make-hash-table in k609 */
static void C_ccall f_1709(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,*((C_word*)lf[29]+1));
t3=((C_word*)t0)[2];
f_1696(t3,t2);}

/* k1694 in k1691 in k1687 in k1684 in k1681 in k1678 in k1675 in make-hash-table in k609 */
static void C_fcall f_1696(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-69.scm: 563  %make-hash-table */
t2=*((C_word*)lf[36]+1);
((C_proc10)C_retrieve_proc(t2))(10,t2,((C_word*)t0)[10],((C_word*)((C_word*)t0)[9])[1],((C_word*)((C_word*)t0)[8])[1],((C_word*)((C_word*)t0)[7])[1],((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[5])[1],((C_word*)((C_word*)t0)[4])[1],((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1]);}

/* hash-for-test in make-hash-table in k609 */
static C_word C_fcall f_1601(C_word t0){
C_word tmp;
C_word t1;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_stack_check;
t1=(C_word)C_eqp(((C_word*)t0)[8],((C_word*)((C_word*)t0)[7])[1]);
t2=(C_truep(t1)?t1:(C_word)C_eqp(*((C_word*)lf[38]+1),((C_word*)((C_word*)t0)[7])[1]));
if(C_truep(t2)){
return(*((C_word*)lf[24]+1));}
else{
t3=(C_word)C_eqp(((C_word*)t0)[6],((C_word*)((C_word*)t0)[7])[1]);
t4=(C_truep(t3)?t3:(C_word)C_eqp(*((C_word*)lf[39]+1),((C_word*)((C_word*)t0)[7])[1]));
if(C_truep(t4)){
return(*((C_word*)lf[27]+1));}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],((C_word*)((C_word*)t0)[7])[1]);
t6=(C_truep(t5)?t5:(C_word)C_eqp(*((C_word*)lf[40]+1),((C_word*)((C_word*)t0)[7])[1]));
if(C_truep(t6)){
return(*((C_word*)lf[29]+1));}
else{
t7=(C_word)C_eqp(((C_word*)t0)[4],((C_word*)((C_word*)t0)[7])[1]);
t8=(C_truep(t7)?t7:(C_word)C_eqp(*((C_word*)lf[41]+1),((C_word*)((C_word*)t0)[7])[1]));
if(C_truep(t8)){
return(*((C_word*)lf[17]+1));}
else{
t9=(C_word)C_eqp(((C_word*)t0)[3],((C_word*)((C_word*)t0)[7])[1]);
t10=(C_truep(t9)?t9:(C_word)C_eqp(*((C_word*)lf[42]+1),((C_word*)((C_word*)t0)[7])[1]));
if(C_truep(t10)){
return(*((C_word*)lf[31]+1));}
else{
t11=(C_word)C_eqp(((C_word*)t0)[2],((C_word*)((C_word*)t0)[7])[1]);
t12=(C_truep(t11)?t11:(C_word)C_eqp(*((C_word*)lf[43]+1),((C_word*)((C_word*)t0)[7])[1]));
return((C_truep(t12)?*((C_word*)lf[7]+1):C_SCHEME_FALSE));}}}}}}

/* %make-hash-table in k609 */
static void C_ccall f_1568(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9,...){
C_word tmp;
C_word t10;
va_list v;
C_word *a,c2=c;
C_save_rest(t9,c2,10);
if(c<10) C_bad_min_argc_2(c,10,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr10r,(void*)f_1568r,10,t0,t1,t2,t3,t4,t5,t6,t7,t8,t9);}
else{
a=C_alloc((c-10)*3);
t10=C_restore_rest(a,C_rest_count(0));
f_1568r(t0,t1,t2,t3,t4,t5,t6,t7,t8,t9,t10);}}

static void C_ccall f_1568r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9,C_word t10){
C_word tmp;
C_word t11;
C_word t12;
C_word t13;
C_word *a=C_alloc(8);
t11=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1572,a[2]=t9,a[3]=t6,a[4]=t5,a[5]=t3,a[6]=t2,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_i_nullp(t10))){
/* srfi-69.scm: 435  make-vector */
t12=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t12))(4,t12,t11,t4,C_SCHEME_END_OF_LIST);}
else{
t12=(C_word)C_i_cdr(t10);
if(C_truep((C_word)C_i_nullp(t12))){
t13=t11;
f_1572(2,t13,(C_word)C_i_car(t10));}
else{
/* ##sys#error */
t13=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t13+1)))(4,t13,t11,lf[0],t10);}}}

/* k1570 in %make-hash-table in k609 */
static void C_ccall f_1572(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1572,2,t0,t1);}
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,10,lf[37],t1,C_fix(0),((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],C_SCHEME_FALSE,C_SCHEME_FALSE,((C_word*)t0)[2]));}

/* ##srfi-69#hash-table-canonical-length in k609 */
static void C_ccall f_1538(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1538,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1544,a[2]=t3,a[3]=((C_word)li20),tmp=(C_word)a,a+=4,tmp);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,f_1544(t4,t2));}

/* loop in ##srfi-69#hash-table-canonical-length in k609 */
static C_word C_fcall f_1544(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
loop:
C_stack_check;
t2=(C_word)C_slot(t1,C_fix(0));
t3=(C_word)C_slot(t1,C_fix(1));
t4=(C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[2]);
t5=(C_truep(t4)?t4:(C_word)C_i_nullp(t3));
if(C_truep(t5)){
return(t2);}
else{
t7=t3;
t1=t7;
goto loop;}}

/* string-ci-hash in k609 */
static void C_ccall f_1489(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_1489r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1489r(t0,t1,t2,t3);}}

static void C_ccall f_1489r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1493,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_1493(2,t5,C_fix(536870912));}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_1493(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k1491 in string-ci-hash in k609 */
static void C_ccall f_1493(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
t2=(C_word)C_i_check_string_2(((C_word*)t0)[3],lf[31]);
t3=(C_word)C_i_check_exact_2(t1,lf[31]);
t4=(C_word)C_hash_string_ci(((C_word*)t0)[3]);
t5=(C_word)C_fixnum_lessp(t4,C_fix(0));
t6=(C_truep(t5)?(C_word)C_fixnum_negate(t4):t4);
t7=(C_word)C_fixnum_and(C_fix((C_word)C_MOST_POSITIVE_FIXNUM),t6);
/* srfi-69.scm: 389  fxmod */
t8=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,((C_word*)t0)[2],t7,t1);}

/* string-hash in k609 */
static void C_ccall f_1441(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_1441r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1441r(t0,t1,t2,t3);}}

static void C_ccall f_1441r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1445,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_1445(2,t5,C_fix(536870912));}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_1445(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k1443 in string-hash in k609 */
static void C_ccall f_1445(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
t2=(C_word)C_i_check_string_2(((C_word*)t0)[3],lf[17]);
t3=(C_word)C_i_check_exact_2(t1,lf[17]);
t4=(C_word)C_hash_string(((C_word*)t0)[3]);
t5=(C_word)C_fixnum_lessp(t4,C_fix(0));
t6=(C_truep(t5)?(C_word)C_fixnum_negate(t4):t4);
t7=(C_word)C_fixnum_and(C_fix((C_word)C_MOST_POSITIVE_FIXNUM),t6);
/* srfi-69.scm: 384  fxmod */
t8=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,((C_word*)t0)[2],t7,t1);}

/* equal?-hash in k609 */
static void C_ccall f_1392(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_1392r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1392r(t0,t1,t2,t3);}}

static void C_ccall f_1392r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1396,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_1396(2,t5,C_fix(536870912));}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_1396(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k1394 in equal?-hash in k609 */
static void C_ccall f_1396(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1396,2,t0,t1);}
t2=(C_word)C_i_check_exact_2(t1,lf[30]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1410,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-69.scm: 375  %equal?-hash */
t4=*((C_word*)lf[6]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k1408 in k1394 in equal?-hash in k609 */
static void C_ccall f_1410(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_fixnum_lessp(t1,C_fix(0));
t3=(C_truep(t2)?(C_word)C_fixnum_negate(t1):t1);
t4=(C_word)C_fixnum_and(C_fix((C_word)C_MOST_POSITIVE_FIXNUM),t3);
/* srfi-69.scm: 375  fxmod */
t5=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,((C_word*)t0)[3],t4,((C_word*)t0)[2]);}

/* ##srfi-69#%equal?-hash in k609 */
static void C_ccall f_1120(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[19],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1120,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1123,a[2]=t8,a[3]=((C_word)li13),tmp=(C_word)a,a+=4,tmp));
t10=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1188,a[2]=t8,a[3]=((C_word)li14),tmp=(C_word)a,a+=4,tmp));
t11=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1219,a[2]=t4,a[3]=t6,a[4]=((C_word)li15),tmp=(C_word)a,a+=5,tmp));
/* srfi-69.scm: 371  recursive-hash */
t12=((C_word*)t8)[1];
f_1219(t12,t1,t2,C_fix(0));}

/* recursive-hash in ##srfi-69#%equal?-hash in k609 */
static void C_fcall f_1219(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1219,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,C_fix(4)))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_fix(99));}
else{
if(C_truep((C_word)C_fixnump(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}
else{
if(C_truep((C_word)C_charp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_fix((C_word)C_character_code(t2)));}
else{
switch(t2){
case C_SCHEME_TRUE:
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_fix(256));
case C_SCHEME_FALSE:
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_fix(257));
default:
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_fix(258));}
else{
if(C_truep((C_word)C_eofp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_fix(259));}
else{
if(C_truep((C_word)C_i_symbolp(t2))){
t4=(C_word)C_slot(t2,C_fix(1));
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_hash_string(t4));}
else{
if(C_truep((C_word)C_i_numberp(t2))){
if(C_truep((C_word)C_i_flonump(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_fixnum_times(C_fix(331804471),(C_word)C_quickflonumtruncate(t2)));}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1294,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* srfi-69.scm: 361  ##sys#number-hash-hook */
t5=*((C_word*)lf[5]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}}
else{
if(C_truep((C_word)C_blockp(t2))){
if(C_truep((C_word)C_byteblockp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_hash_string(t2));}
else{
if(C_truep((C_word)C_i_listp(t2))){
t4=(C_word)C_i_length(t2);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1320,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_slot(t2,C_fix(0));
/* srfi-69.scm: 364  recursive-atomic-hash */
t7=((C_word*)((C_word*)t0)[3])[1];
f_1188(t7,t5,t6,t3);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1349,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_slot(t2,C_fix(0));
/* srfi-69.scm: 365  recursive-atomic-hash */
t6=((C_word*)((C_word*)t0)[3])[1];
f_1188(t6,t4,t5,t3);}
else{
if(C_truep((C_word)C_portp(t2))){
t4=(C_word)C_peek_fixnum(t2,C_fix(0));
t5=(C_word)C_fixnum_shift_left(t4,C_fix(4));
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1370,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-69.scm: 366  input-port? */
t7=*((C_word*)lf[28]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t2);}
else{
if(C_truep((C_word)C_specialp(t2))){
t4=(C_word)C_peek_fixnum(t2,C_fix(0));
/* srfi-69.scm: 367  vector-hash */
t5=((C_word*)((C_word*)t0)[2])[1];
f_1123(t5,t1,t2,t4,t3,C_fix(1));}
else{
/* srfi-69.scm: 368  vector-hash */
t4=((C_word*)((C_word*)t0)[2])[1];
f_1123(t4,t1,t2,C_fix(0),t3,C_fix(0));}}}}}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_fix(262));}}}}}}}}}}

/* k1368 in recursive-hash in ##srfi-69#%equal?-hash in k609 */
static void C_ccall f_1370(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?C_fix(260):C_fix(261));
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_fixnum_plus(((C_word*)t0)[2],t2));}

/* k1347 in recursive-hash in ##srfi-69#%equal?-hash in k609 */
static void C_ccall f_1349(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1349,2,t0,t1);}
t2=(C_word)C_fixnum_shift_left(t1,C_fix(16));
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1341,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* srfi-69.scm: 365  recursive-atomic-hash */
t5=((C_word*)((C_word*)t0)[3])[1];
f_1188(t5,t3,t4,((C_word*)t0)[2]);}

/* k1339 in k1347 in recursive-hash in ##srfi-69#%equal?-hash in k609 */
static void C_ccall f_1341(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_fixnum_plus(((C_word*)t0)[2],t1));}

/* k1318 in recursive-hash in ##srfi-69#%equal?-hash in k609 */
static void C_ccall f_1320(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_fixnum_plus(((C_word*)t0)[2],t1));}

/* k1292 in recursive-hash in ##srfi-69#%equal?-hash in k609 */
static void C_ccall f_1294(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_fix(t1));}

/* recursive-atomic-hash in ##srfi-69#%equal?-hash in k609 */
static void C_fcall f_1188(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1188,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_not((C_word)C_blockp(t2));
t5=(C_truep(t4)?t4:(C_word)C_i_symbolp(t2));
t6=(C_truep(t5)?t5:(C_word)C_i_numberp(t2));
t7=(C_truep(t6)?t6:(C_word)C_byteblockp(t2));
if(C_truep(t7)){
t8=(C_word)C_fixnum_plus(t3,C_fix(1));
/* srfi-69.scm: 345  recursive-hash */
t9=((C_word*)((C_word*)t0)[2])[1];
f_1219(t9,t1,t2,t8);}
else{
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_fix(99));}}

/* vector-hash in ##srfi-69#%equal?-hash in k609 */
static void C_fcall f_1123(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1123,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(C_word)C_block_size(t2);
t7=(C_word)C_fixnum_plus(t6,t3);
t8=(C_word)C_i_fixnum_min(C_fix(4),t6);
t9=(C_word)C_fixnum_difference(t8,t5);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1140,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t2,a[5]=t11,a[6]=((C_word)li12),tmp=(C_word)a,a+=7,tmp));
t13=((C_word*)t11)[1];
f_1140(t13,t1,t7,t5,t9);}

/* loop in vector-hash in ##srfi-69#%equal?-hash in k609 */
static void C_fcall f_1140(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1140,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t4,C_fix(0));
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t2);}
else{
t6=(C_word)C_fixnum_shift_left(t2,C_fix(4));
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1174,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=t4,a[5]=t3,a[6]=t2,a[7]=t6,tmp=(C_word)a,a+=8,tmp);
t8=(C_word)C_slot(((C_word*)t0)[4],t3);
t9=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* srfi-69.scm: 337  recursive-hash */
t10=((C_word*)((C_word*)t0)[2])[1];
f_1219(t10,t7,t8,t9);}}

/* k1172 in loop in vector-hash in ##srfi-69#%equal?-hash in k609 */
static void C_ccall f_1174(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[7],t1);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[6],t2);
t4=(C_word)C_fixnum_plus(((C_word*)t0)[5],C_fix(1));
t5=(C_word)C_fixnum_difference(((C_word*)t0)[4],C_fix(1));
/* srfi-69.scm: 335  loop */
t6=((C_word*)((C_word*)t0)[3])[1];
f_1140(t6,((C_word*)t0)[2],t3,t4,t5);}

/* eqv?-hash in k609 */
static void C_ccall f_1072(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_1072r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1072r(t0,t1,t2,t3);}}

static void C_ccall f_1072r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1076,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_1076(2,t5,C_fix(536870912));}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_1076(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k1074 in eqv?-hash in k609 */
static void C_ccall f_1076(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1076,2,t0,t1);}
t2=(C_word)C_i_check_exact_2(t1,lf[27]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1090,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-69.scm: 297  %eqv?-hash */
t4=*((C_word*)lf[26]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k1088 in k1074 in eqv?-hash in k609 */
static void C_ccall f_1090(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_fixnum_lessp(t1,C_fix(0));
t3=(C_truep(t2)?(C_word)C_fixnum_negate(t1):t1);
t4=(C_word)C_fixnum_and(C_fix((C_word)C_MOST_POSITIVE_FIXNUM),t3);
/* srfi-69.scm: 297  fxmod */
t5=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,((C_word*)t0)[3],t4,((C_word*)t0)[2]);}

/* ##srfi-69#%eqv?-hash in k609 */
static void C_ccall f_992(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_992,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnump(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
if(C_truep((C_word)C_charp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_fix((C_word)C_character_code(t2)));}
else{
switch(t2){
case C_SCHEME_TRUE:
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_fix(256));
case C_SCHEME_FALSE:
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_fix(257));
default:
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_fix(258));}
else{
if(C_truep((C_word)C_eofp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_fix(259));}
else{
if(C_truep((C_word)C_i_symbolp(t2))){
t3=(C_word)C_slot(t2,C_fix(1));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_hash_string(t3));}
else{
if(C_truep((C_word)C_i_numberp(t2))){
if(C_truep((C_word)C_i_flonump(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_fixnum_times(C_fix(331804471),(C_word)C_quickflonumtruncate(t2)));}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1061,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* srfi-69.scm: 291  ##sys#number-hash-hook */
t4=*((C_word*)lf[5]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}}
else{
if(C_truep((C_word)C_blockp(t2))){
/* srfi-69.scm: 293  %object-uid-hash */
t3=*((C_word*)lf[14]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,t2);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_fix(262));}}}}}}}}}

/* k1059 in ##srfi-69#%eqv?-hash in k609 */
static void C_ccall f_1061(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_fix(t1));}

/* eq?-hash in k609 */
static void C_ccall f_943(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_943r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_943r(t0,t1,t2,t3);}}

static void C_ccall f_943r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_947,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_947(2,t5,C_fix(536870912));}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_947(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k945 in eq?-hash in k609 */
static void C_ccall f_947(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_947,2,t0,t1);}
t2=(C_word)C_i_check_exact_2(t1,lf[24]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_961,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-69.scm: 271  %eq?-hash */
t4=*((C_word*)lf[23]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k959 in k945 in eq?-hash in k609 */
static void C_ccall f_961(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_fixnum_lessp(t1,C_fix(0));
t3=(C_truep(t2)?(C_word)C_fixnum_negate(t1):t1);
t4=(C_word)C_fixnum_and(C_fix((C_word)C_MOST_POSITIVE_FIXNUM),t3);
/* srfi-69.scm: 271  fxmod */
t5=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,((C_word*)t0)[3],t4,((C_word*)t0)[2]);}

/* ##srfi-69#%eq?-hash in k609 */
static void C_ccall f_882(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_882,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnump(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
if(C_truep((C_word)C_charp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_fix((C_word)C_character_code(t2)));}
else{
switch(t2){
case C_SCHEME_TRUE:
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_fix(256));
case C_SCHEME_FALSE:
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_fix(257));
default:
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_fix(258));}
else{
if(C_truep((C_word)C_eofp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_fix(259));}
else{
if(C_truep((C_word)C_i_symbolp(t2))){
t3=(C_word)C_slot(t2,C_fix(1));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_hash_string(t3));}
else{
if(C_truep((C_word)C_blockp(t2))){
/* srfi-69.scm: 267  %object-uid-hash */
t3=*((C_word*)lf[14]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,t2);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_fix(262));}}}}}}}}

/* keyword-hash in k609 */
static void C_ccall f_830(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_830r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_830r(t0,t1,t2,t3);}}

static void C_ccall f_830r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_834,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_834(2,t5,C_fix(536870912));}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_834(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k832 in keyword-hash in k609 */
static void C_ccall f_834(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_834,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_837,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm: 244  ##sys#check-keyword */
t3=*((C_word*)lf[18]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],lf[22]);}

/* k835 in k832 in keyword-hash in k609 */
static void C_ccall f_837(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
t2=(C_word)C_i_check_exact_2(((C_word*)t0)[4],lf[22]);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
t4=(C_word)C_hash_string(t3);
t5=(C_word)C_fixnum_lessp(t4,C_fix(0));
t6=(C_truep(t5)?(C_word)C_fixnum_negate(t4):t4);
t7=(C_word)C_fixnum_and(C_fix((C_word)C_MOST_POSITIVE_FIXNUM),t6);
/* srfi-69.scm: 246  fxmod */
t8=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,((C_word*)t0)[2],t7,((C_word*)t0)[4]);}

/* ##sys#check-keyword in k609 */
static void C_ccall f_804(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3rv,(void*)f_804r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_804r(t0,t1,t2,t3);}}

static void C_ccall f_804r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_811,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm: 231  keyword? */
t5=*((C_word*)lf[21]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}

/* k809 in ##sys#check-keyword in k609 */
static void C_ccall f_811(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(C_word)C_vemptyp(((C_word*)t0)[3]);
t3=(C_truep(t2)?C_SCHEME_FALSE:(C_word)C_i_vector_ref(((C_word*)t0)[3],C_fix(0)));
/* srfi-69.scm: 232  ##sys#signal-hook */
t4=*((C_word*)lf[10]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,((C_word*)t0)[4],lf[19],t3,lf[20],((C_word*)t0)[2]);}}

/* symbol-hash in k609 */
static void C_ccall f_752(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_752r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_752r(t0,t1,t2,t3);}}

static void C_ccall f_752r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_756,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_756(2,t5,C_fix(536870912));}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_756(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k754 in symbol-hash in k609 */
static void C_ccall f_756(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
t2=(C_word)C_i_check_symbol_2(((C_word*)t0)[3],lf[16]);
t3=(C_word)C_i_check_exact_2(t1,lf[17]);
t4=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
t5=(C_word)C_hash_string(t4);
t6=(C_word)C_fixnum_lessp(t5,C_fix(0));
t7=(C_truep(t6)?(C_word)C_fixnum_negate(t5):t5);
t8=(C_word)C_fixnum_and(C_fix((C_word)C_MOST_POSITIVE_FIXNUM),t7);
/* srfi-69.scm: 226  fxmod */
t9=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,((C_word*)t0)[2],t8,t1);}

/* object-uid-hash in k609 */
static void C_ccall f_704(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_704r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_704r(t0,t1,t2,t3);}}

static void C_ccall f_704r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_708,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_708(2,t5,C_fix(536870912));}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_708(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k706 in object-uid-hash in k609 */
static void C_ccall f_708(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_708,2,t0,t1);}
t2=(C_word)C_i_check_exact_2(t1,lf[15]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_722,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-69.scm: 212  %object-uid-hash */
t4=*((C_word*)lf[14]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k720 in k706 in object-uid-hash in k609 */
static void C_ccall f_722(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_fixnum_lessp(t1,C_fix(0));
t3=(C_truep(t2)?(C_word)C_fixnum_negate(t1):t1);
t4=(C_word)C_fixnum_and(C_fix((C_word)C_MOST_POSITIVE_FIXNUM),t3);
/* srfi-69.scm: 212  fxmod */
t5=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,((C_word*)t0)[3],t4,((C_word*)t0)[2]);}

/* ##srfi-69#%object-uid-hash in k609 */
static void C_ccall f_698(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_698,3,t0,t1,t2);}
/* srfi-69.scm: 208  %equal?-hash */
t3=*((C_word*)lf[6]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,t2);}

/* number-hash in k609 */
static void C_ccall f_625(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_625r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_625r(t0,t1,t2,t3);}}

static void C_ccall f_625r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_629,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_629(2,t5,C_fix(536870912));}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_629(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k627 in number-hash in k609 */
static void C_ccall f_629(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_629,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_632,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_numberp(((C_word*)t0)[2]))){
t3=t2;
f_632(2,t3,C_SCHEME_UNDEFINED);}
else{
/* srfi-69.scm: 197  ##sys#signal-hook */
t3=*((C_word*)lf[10]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,lf[11],lf[7],lf[12],((C_word*)t0)[2]);}}

/* k630 in k627 in number-hash in k609 */
static void C_ccall f_632(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_632,2,t0,t1);}
t2=(C_word)C_i_check_exact_2(((C_word*)t0)[4],lf[7]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_646,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnump(((C_word*)t0)[2]))){
t4=t3;
f_646(t4,((C_word*)t0)[2]);}
else{
if(C_truep((C_word)C_i_flonump(((C_word*)t0)[2]))){
t4=t3;
f_646(t4,(C_word)C_fixnum_times(C_fix(331804471),(C_word)C_quickflonumtruncate(*((C_word*)lf[9]+1))));}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_671,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* srfi-69.scm: 199  ##sys#number-hash-hook */
t5=*((C_word*)lf[5]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,*((C_word*)lf[9]+1));}}}

/* k669 in k630 in k627 in number-hash in k609 */
static void C_ccall f_671(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_646(t2,(C_word)C_fix(t1));}

/* k644 in k630 in k627 in number-hash in k609 */
static void C_fcall f_646(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_fixnum_lessp(t1,C_fix(0));
t3=(C_truep(t2)?(C_word)C_fixnum_negate(t1):t1);
t4=(C_word)C_fixnum_and(C_fix((C_word)C_MOST_POSITIVE_FIXNUM),t3);
/* srfi-69.scm: 199  fxmod */
t5=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,((C_word*)t0)[3],t4,((C_word*)t0)[2]);}

/* ##sys#number-hash-hook in k609 */
static void C_ccall f_619(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_619,3,t0,t1,t2);}
/* srfi-69.scm: 185  %equal?-hash */
t3=*((C_word*)lf[6]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,t2);}

/* ##srfi-69#unbound-value-thunk in k609 */
static void C_ccall f_613(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_613,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_slot(lf[4],C_fix(0)));}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[202] = {
{"toplevelsrfi-69.scm",(void*)C_srfi_69_toplevel},
{"f_611srfi-69.scm",(void*)f_611},
{"f_3492srfi-69.scm",(void*)f_3492},
{"f_3509srfi-69.scm",(void*)f_3509},
{"f_3496srfi-69.scm",(void*)f_3496},
{"f_3502srfi-69.scm",(void*)f_3502},
{"f_2715srfi-69.scm",(void*)f_2715},
{"f_3470srfi-69.scm",(void*)f_3470},
{"f_3477srfi-69.scm",(void*)f_3477},
{"f_3482srfi-69.scm",(void*)f_3482},
{"f_3490srfi-69.scm",(void*)f_3490},
{"f_3458srfi-69.scm",(void*)f_3458},
{"f_3465srfi-69.scm",(void*)f_3465},
{"f_3446srfi-69.scm",(void*)f_3446},
{"f_3453srfi-69.scm",(void*)f_3453},
{"f_3434srfi-69.scm",(void*)f_3434},
{"f_3441srfi-69.scm",(void*)f_3441},
{"f_3368srfi-69.scm",(void*)f_3368},
{"f_3380srfi-69.scm",(void*)f_3380},
{"f_3396srfi-69.scm",(void*)f_3396},
{"f_3424srfi-69.scm",(void*)f_3424},
{"f_3319srfi-69.scm",(void*)f_3319},
{"f_3331srfi-69.scm",(void*)f_3331},
{"f_3350srfi-69.scm",(void*)f_3350},
{"f_3341srfi-69.scm",(void*)f_3341},
{"f_3254srfi-69.scm",(void*)f_3254},
{"f_3269srfi-69.scm",(void*)f_3269},
{"f_3285srfi-69.scm",(void*)f_3285},
{"f_3189srfi-69.scm",(void*)f_3189},
{"f_3204srfi-69.scm",(void*)f_3204},
{"f_3220srfi-69.scm",(void*)f_3220},
{"f_3161srfi-69.scm",(void*)f_3161},
{"f_3168srfi-69.scm",(void*)f_3168},
{"f_3173srfi-69.scm",(void*)f_3173},
{"f_3183srfi-69.scm",(void*)f_3183},
{"f_3171srfi-69.scm",(void*)f_3171},
{"f_3088srfi-69.scm",(void*)f_3088},
{"f_3103srfi-69.scm",(void*)f_3103},
{"f_3119srfi-69.scm",(void*)f_3119},
{"f_3072srfi-69.scm",(void*)f_3072},
{"f_3086srfi-69.scm",(void*)f_3086},
{"f_3060srfi-69.scm",(void*)f_3060},
{"f_2993srfi-69.scm",(void*)f_2993},
{"f_3005srfi-69.scm",(void*)f_3005},
{"f_3028srfi-69.scm",(void*)f_3028},
{"f_3054srfi-69.scm",(void*)f_3054},
{"f_3041srfi-69.scm",(void*)f_3041},
{"f_3015srfi-69.scm",(void*)f_3015},
{"f_2977srfi-69.scm",(void*)f_2977},
{"f_2984srfi-69.scm",(void*)f_2984},
{"f_2881srfi-69.scm",(void*)f_2881},
{"f_2888srfi-69.scm",(void*)f_2888},
{"f_2902srfi-69.scm",(void*)f_2902},
{"f_2928srfi-69.scm",(void*)f_2928},
{"f_2947srfi-69.scm",(void*)f_2947},
{"f_2915srfi-69.scm",(void*)f_2915},
{"f_2750srfi-69.scm",(void*)f_2750},
{"f_2766srfi-69.scm",(void*)f_2766},
{"f_2833srfi-69.scm",(void*)f_2833},
{"f_2852srfi-69.scm",(void*)f_2852},
{"f_2786srfi-69.scm",(void*)f_2786},
{"f_2729srfi-69.scm",(void*)f_2729},
{"f_2748srfi-69.scm",(void*)f_2748},
{"f_2717srfi-69.scm",(void*)f_2717},
{"f_2726srfi-69.scm",(void*)f_2726},
{"f_2604srfi-69.scm",(void*)f_2604},
{"f_2617srfi-69.scm",(void*)f_2617},
{"f_2674srfi-69.scm",(void*)f_2674},
{"f_2693srfi-69.scm",(void*)f_2693},
{"f_2632srfi-69.scm",(void*)f_2632},
{"f_2590srfi-69.scm",(void*)f_2590},
{"f_2599srfi-69.scm",(void*)f_2599},
{"f_2595srfi-69.scm",(void*)f_2595},
{"f_2575srfi-69.scm",(void*)f_2575},
{"f_2582srfi-69.scm",(void*)f_2582},
{"f_2587srfi-69.scm",(void*)f_2587},
{"f_2494srfi-69.scm",(void*)f_2494},
{"f_2527srfi-69.scm",(void*)f_2527},
{"f_2510srfi-69.scm",(void*)f_2510},
{"f_2522srfi-69.scm",(void*)f_2522},
{"f_2496srfi-69.scm",(void*)f_2496},
{"f_2503srfi-69.scm",(void*)f_2503},
{"f_2506srfi-69.scm",(void*)f_2506},
{"f_2258srfi-69.scm",(void*)f_2258},
{"f_2279srfi-69.scm",(void*)f_2279},
{"f_2484srfi-69.scm",(void*)f_2484},
{"f_2476srfi-69.scm",(void*)f_2476},
{"f_2295srfi-69.scm",(void*)f_2295},
{"f_2301srfi-69.scm",(void*)f_2301},
{"f_2402srfi-69.scm",(void*)f_2402},
{"f_2439srfi-69.scm",(void*)f_2439},
{"f_2442srfi-69.scm",(void*)f_2442},
{"f_2430srfi-69.scm",(void*)f_2430},
{"f_2412srfi-69.scm",(void*)f_2412},
{"f_2339srfi-69.scm",(void*)f_2339},
{"f_2379srfi-69.scm",(void*)f_2379},
{"f_2367srfi-69.scm",(void*)f_2367},
{"f_2349srfi-69.scm",(void*)f_2349},
{"f_2317srfi-69.scm",(void*)f_2317},
{"f_2304srfi-69.scm",(void*)f_2304},
{"f_2307srfi-69.scm",(void*)f_2307},
{"f_2179srfi-69.scm",(void*)f_2179},
{"f_2191srfi-69.scm",(void*)f_2191},
{"f_2214srfi-69.scm",(void*)f_2214},
{"f_2230srfi-69.scm",(void*)f_2230},
{"f_2201srfi-69.scm",(void*)f_2201},
{"f_2170srfi-69.scm",(void*)f_2170},
{"f_2058srfi-69.scm",(void*)f_2058},
{"f_2068srfi-69.scm",(void*)f_2068},
{"f_2073srfi-69.scm",(void*)f_2073},
{"f_2135srfi-69.scm",(void*)f_2135},
{"f_2156srfi-69.scm",(void*)f_2156},
{"f_2129srfi-69.scm",(void*)f_2129},
{"f_2043srfi-69.scm",(void*)f_2043},
{"f_2031srfi-69.scm",(void*)f_2031},
{"f_2022srfi-69.scm",(void*)f_2022},
{"f_2013srfi-69.scm",(void*)f_2013},
{"f_2004srfi-69.scm",(void*)f_2004},
{"f_1995srfi-69.scm",(void*)f_1995},
{"f_1986srfi-69.scm",(void*)f_1986},
{"f_1977srfi-69.scm",(void*)f_1977},
{"f_1968srfi-69.scm",(void*)f_1968},
{"f_1962srfi-69.scm",(void*)f_1962},
{"f_1599srfi-69.scm",(void*)f_1599},
{"f_1952srfi-69.scm",(void*)f_1952},
{"f_1955srfi-69.scm",(void*)f_1955},
{"f_1677srfi-69.scm",(void*)f_1677},
{"f_1932srfi-69.scm",(void*)f_1932},
{"f_1935srfi-69.scm",(void*)f_1935},
{"f_1680srfi-69.scm",(void*)f_1680},
{"f_1900srfi-69.scm",(void*)f_1900},
{"f_1906srfi-69.scm",(void*)f_1906},
{"f_1683srfi-69.scm",(void*)f_1683},
{"f_1718srfi-69.scm",(void*)f_1718},
{"f_1739srfi-69.scm",(void*)f_1739},
{"f_1745srfi-69.scm",(void*)f_1745},
{"f_1837srfi-69.scm",(void*)f_1837},
{"f_1840srfi-69.scm",(void*)f_1840},
{"f_1812srfi-69.scm",(void*)f_1812},
{"f_1815srfi-69.scm",(void*)f_1815},
{"f_1802srfi-69.scm",(void*)f_1802},
{"f_1784srfi-69.scm",(void*)f_1784},
{"f_1771srfi-69.scm",(void*)f_1771},
{"f_1761srfi-69.scm",(void*)f_1761},
{"f_1748srfi-69.scm",(void*)f_1748},
{"f_1729srfi-69.scm",(void*)f_1729},
{"f_1686srfi-69.scm",(void*)f_1686},
{"f_1689srfi-69.scm",(void*)f_1689},
{"f_1693srfi-69.scm",(void*)f_1693},
{"f_1709srfi-69.scm",(void*)f_1709},
{"f_1696srfi-69.scm",(void*)f_1696},
{"f_1601srfi-69.scm",(void*)f_1601},
{"f_1568srfi-69.scm",(void*)f_1568},
{"f_1572srfi-69.scm",(void*)f_1572},
{"f_1538srfi-69.scm",(void*)f_1538},
{"f_1544srfi-69.scm",(void*)f_1544},
{"f_1489srfi-69.scm",(void*)f_1489},
{"f_1493srfi-69.scm",(void*)f_1493},
{"f_1441srfi-69.scm",(void*)f_1441},
{"f_1445srfi-69.scm",(void*)f_1445},
{"f_1392srfi-69.scm",(void*)f_1392},
{"f_1396srfi-69.scm",(void*)f_1396},
{"f_1410srfi-69.scm",(void*)f_1410},
{"f_1120srfi-69.scm",(void*)f_1120},
{"f_1219srfi-69.scm",(void*)f_1219},
{"f_1370srfi-69.scm",(void*)f_1370},
{"f_1349srfi-69.scm",(void*)f_1349},
{"f_1341srfi-69.scm",(void*)f_1341},
{"f_1320srfi-69.scm",(void*)f_1320},
{"f_1294srfi-69.scm",(void*)f_1294},
{"f_1188srfi-69.scm",(void*)f_1188},
{"f_1123srfi-69.scm",(void*)f_1123},
{"f_1140srfi-69.scm",(void*)f_1140},
{"f_1174srfi-69.scm",(void*)f_1174},
{"f_1072srfi-69.scm",(void*)f_1072},
{"f_1076srfi-69.scm",(void*)f_1076},
{"f_1090srfi-69.scm",(void*)f_1090},
{"f_992srfi-69.scm",(void*)f_992},
{"f_1061srfi-69.scm",(void*)f_1061},
{"f_943srfi-69.scm",(void*)f_943},
{"f_947srfi-69.scm",(void*)f_947},
{"f_961srfi-69.scm",(void*)f_961},
{"f_882srfi-69.scm",(void*)f_882},
{"f_830srfi-69.scm",(void*)f_830},
{"f_834srfi-69.scm",(void*)f_834},
{"f_837srfi-69.scm",(void*)f_837},
{"f_804srfi-69.scm",(void*)f_804},
{"f_811srfi-69.scm",(void*)f_811},
{"f_752srfi-69.scm",(void*)f_752},
{"f_756srfi-69.scm",(void*)f_756},
{"f_704srfi-69.scm",(void*)f_704},
{"f_708srfi-69.scm",(void*)f_708},
{"f_722srfi-69.scm",(void*)f_722},
{"f_698srfi-69.scm",(void*)f_698},
{"f_625srfi-69.scm",(void*)f_625},
{"f_629srfi-69.scm",(void*)f_629},
{"f_632srfi-69.scm",(void*)f_632},
{"f_671srfi-69.scm",(void*)f_671},
{"f_646srfi-69.scm",(void*)f_646},
{"f_619srfi-69.scm",(void*)f_619},
{"f_613srfi-69.scm",(void*)f_613},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
