/* Generated from srfi-18.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-04-30 11:30
   Version 3.1.10 - linux-unix-gnu-x86	[ manyargs dload ptables applyhook ]
   SVN rev. 10602	compiled 2008-04-30 on galinha (Linux)
   command line: srfi-18.scm -quiet -no-trace -optimize-level 2 -include-path . -explicit-use -unsafe -no-lambda-info -output-file usrfi-18.c
   unit: srfi_18
*/

#include "chicken.h"

static C_TLS long C_ms;
#define C_get_seconds   C_seconds(&C_ms)

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_scheduler_toplevel)
C_externimport void C_ccall C_scheduler_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[112];
static double C_possibly_force_alignment;


C_noret_decl(C_srfi_18_toplevel)
C_externexport void C_ccall C_srfi_18_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_270)
static void C_ccall f_270(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_273)
static void C_ccall f_273(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_539)
static void C_ccall f_539(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1633)
static void C_ccall f_1633(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1607)
static void C_ccall f_1607(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1617)
static void C_ccall f_1617(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1620)
static void C_ccall f_1620(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1623)
static void C_ccall f_1623(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1575)
static void C_fcall f_1575(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1577)
static void C_ccall f_1577(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1577)
static void C_ccall f_1577r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1587)
static void C_ccall f_1587(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1541)
static void C_ccall f_1541(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1565)
static void C_ccall f_1565(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1569)
static void C_ccall f_1569(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1504)
static void C_ccall f_1504(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1516)
static void C_ccall f_1516(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1511)
static void C_ccall f_1511(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1461)
static void C_ccall f_1461(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1452)
static void C_ccall f_1452(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1443)
static void C_ccall f_1443(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1437)
static void C_ccall f_1437(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1418)
static void C_ccall f_1418(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1418)
static void C_ccall f_1418r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1426)
static void C_ccall f_1426(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1236)
static void C_ccall f_1236(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1236)
static void C_ccall f_1236r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1254)
static void C_ccall f_1254(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1261)
static void C_ccall f_1261(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1390)
static void C_ccall f_1390(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1372)
static void C_ccall f_1372(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1350)
static void C_ccall f_1350(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1361)
static void C_ccall f_1361(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1276)
static void C_ccall f_1276(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1279)
static void C_ccall f_1279(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1382)
static void C_ccall f_1382(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1024)
static void C_ccall f_1024(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1024)
static void C_ccall f_1024r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1034)
static void C_ccall f_1034(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1051)
static void C_ccall f_1051(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1099)
static void C_fcall f_1099(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1102)
static void C_ccall f_1102(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1209)
static void C_ccall f_1209(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1161)
static void C_ccall f_1161(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1167)
static void C_ccall f_1167(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1172)
static void C_ccall f_1172(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1194)
static void C_ccall f_1194(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1075)
static void C_fcall f_1075(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1086)
static void C_ccall f_1086(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1054)
static void C_fcall f_1054(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1065)
static void C_ccall f_1065(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1000)
static void C_ccall f_1000(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_991)
static void C_ccall f_991(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_982)
static void C_ccall f_982(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_973)
static void C_ccall f_973(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_955)
static void C_ccall f_955(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_955)
static void C_ccall f_955r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_959)
static void C_ccall f_959(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_949)
static void C_ccall f_949(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_909)
static void C_ccall f_909(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_937)
static void C_ccall f_937(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_944)
static void C_ccall f_944(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_918)
static void C_ccall f_918(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_925)
static void C_ccall f_925(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_930)
static void C_ccall f_930(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_887)
static void C_ccall f_887(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_854)
static void C_ccall f_854(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_872)
static void C_ccall f_872(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_881)
static void C_ccall f_881(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_810)
static void C_ccall f_810(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_852)
static void C_ccall f_852(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_817)
static void C_ccall f_817(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_826)
static void C_ccall f_826(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_691)
static void C_ccall f_691(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_691)
static void C_ccall f_691r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_698)
static void C_ccall f_698(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_712)
static void C_ccall f_712(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_716)
static void C_ccall f_716(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_722)
static void C_ccall f_722(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_727)
static void C_ccall f_727(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_776)
static void C_ccall f_776(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_757)
static void C_ccall f_757(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_655)
static void C_ccall f_655(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_685)
static void C_ccall f_685(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_659)
static void C_fcall f_659(C_word t0,C_word t1) C_noret;
C_noret_decl(f_662)
static void C_ccall f_662(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_668)
static void C_ccall f_668(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_646)
static void C_ccall f_646(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_630)
static void C_ccall f_630(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_621)
static void C_ccall f_621(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_612)
static void C_ccall f_612(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_603)
static void C_ccall f_603(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_594)
static void C_ccall f_594(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_591)
static void C_ccall f_591(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_585)
static void C_ccall f_585(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_541)
static void C_ccall f_541(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_541)
static void C_ccall f_541r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_570)
static void C_ccall f_570(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_545)
static void C_ccall f_545(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_550)
static void C_ccall f_550(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_556)
static void C_ccall f_556(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_556)
static void C_ccall f_556r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_563)
static void C_ccall f_563(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_521)
static void C_ccall f_521(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_505)
static void C_ccall f_505(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_489)
static void C_ccall f_489(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_473)
static void C_ccall f_473(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_465)
static void C_ccall f_465(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_449)
static void C_ccall f_449(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_395)
static void C_ccall f_395(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_402)
static void C_ccall f_402(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_443)
static void C_ccall f_443(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_439)
static void C_ccall f_439(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_405)
static void C_ccall f_405(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_423)
static void C_ccall f_423(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_415)
static void C_ccall f_415(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_366)
static void C_ccall f_366(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_345)
static void C_ccall f_345(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_318)
static void C_ccall f_318(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_330)
static void C_ccall f_330(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_275)
static void C_fcall f_275(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_309)
static void C_ccall f_309(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_1575)
static void C_fcall trf_1575(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1575(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1575(t0,t1);}

C_noret_decl(trf_1099)
static void C_fcall trf_1099(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1099(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1099(t0,t1);}

C_noret_decl(trf_1075)
static void C_fcall trf_1075(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1075(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1075(t0,t1);}

C_noret_decl(trf_1054)
static void C_fcall trf_1054(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1054(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1054(t0,t1);}

C_noret_decl(trf_659)
static void C_fcall trf_659(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_659(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_659(t0,t1);}

C_noret_decl(trf_275)
static void C_fcall trf_275(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_275(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_275(t0,t1,t2);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr2rv)
static void C_fcall tr2rv(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2rv(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n+1);
t2=C_restore_rest_vector(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr3rv)
static void C_fcall tr3rv(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3rv(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n+1);
t3=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_srfi_18_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_srfi_18_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("srfi_18_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(1085)){
C_save(t1);
C_rereclaim2(1085*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,112);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[2]=C_h_intern(&lf[2],8,"truncate");
lf[4]=C_h_intern(&lf[4],4,"time");
lf[5]=C_h_intern(&lf[5],15,"\003syssignal-hook");
lf[6]=C_h_intern(&lf[6],11,"\000type-error");
lf[7]=C_decode_literal(C_heaptop,"\376B\000\000\030invalid timeout argument");
lf[8]=C_h_intern(&lf[8],12,"current-time");
lf[9]=C_h_intern(&lf[9],20,"srfi-18:current-time");
lf[10]=C_h_intern(&lf[10],13,"time->seconds");
lf[11]=C_h_intern(&lf[11],18,"time->milliseconds");
lf[12]=C_h_intern(&lf[12],13,"seconds->time");
lf[13]=C_h_intern(&lf[13],19,"\003sysflonum-fraction");
lf[14]=C_h_intern(&lf[14],18,"\003sysexact->inexact");
lf[15]=C_h_intern(&lf[15],3,"max");
lf[16]=C_h_intern(&lf[16],18,"milliseconds->time");
lf[17]=C_h_intern(&lf[17],5,"time\077");
lf[18]=C_h_intern(&lf[18],13,"srfi-18:time\077");
lf[19]=C_h_intern(&lf[19],5,"raise");
lf[20]=C_h_intern(&lf[20],10,"\003syssignal");
lf[21]=C_h_intern(&lf[21],23,"join-timeout-exception\077");
lf[22]=C_h_intern(&lf[22],9,"condition");
lf[23]=C_h_intern(&lf[23],22,"join-timeout-exception");
lf[24]=C_h_intern(&lf[24],26,"abandoned-mutex-exception\077");
lf[25]=C_h_intern(&lf[25],25,"abandoned-mutex-exception");
lf[26]=C_h_intern(&lf[26],28,"terminated-thread-exception\077");
lf[27]=C_h_intern(&lf[27],27,"terminated-thread-exception");
lf[28]=C_h_intern(&lf[28],19,"uncaught-exception\077");
lf[29]=C_h_intern(&lf[29],18,"uncaught-exception");
lf[30]=C_h_intern(&lf[30],25,"uncaught-exception-reason");
lf[31]=C_h_intern(&lf[31],6,"gensym");
lf[32]=C_h_intern(&lf[32],11,"make-thread");
lf[33]=C_h_intern(&lf[33],12,"\003sysschedule");
lf[34]=C_h_intern(&lf[34],16,"\003systhread-kill!");
lf[35]=C_h_intern(&lf[35],4,"dead");
lf[36]=C_h_intern(&lf[36],18,"\003syscurrent-thread");
lf[37]=C_h_intern(&lf[37],15,"\003sysmake-thread");
lf[38]=C_h_intern(&lf[38],7,"created");
lf[39]=C_h_intern(&lf[39],6,"thread");
lf[40]=C_h_intern(&lf[40],7,"thread\077");
lf[41]=C_h_intern(&lf[41],14,"current-thread");
lf[42]=C_h_intern(&lf[42],12,"thread-state");
lf[43]=C_h_intern(&lf[43],15,"thread-specific");
lf[44]=C_h_intern(&lf[44],20,"thread-specific-set!");
lf[45]=C_h_intern(&lf[45],14,"thread-quantum");
lf[46]=C_h_intern(&lf[46],19,"thread-quantum-set!");
lf[47]=C_h_intern(&lf[47],11,"thread-name");
lf[48]=C_h_intern(&lf[48],13,"thread-start!");
lf[49]=C_h_intern(&lf[49],5,"ready");
lf[50]=C_h_intern(&lf[50],22,"\003sysadd-to-ready-queue");
lf[51]=C_h_intern(&lf[51],9,"\003syserror");
lf[52]=C_decode_literal(C_heaptop,"\376B\000\000\047thread can not be started a second time");
lf[53]=C_h_intern(&lf[53],13,"thread-yield!");
lf[54]=C_h_intern(&lf[54],17,"\003systhread-yield!");
lf[55]=C_h_intern(&lf[55],12,"thread-join!");
lf[56]=C_h_intern(&lf[56],10,"terminated");
lf[57]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\022uncaught-exception\376\001\000\000\006reason");
lf[58]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\022uncaught-exception\376\377\016");
lf[59]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\026join-timeout-exception\376\377\016");
lf[60]=C_h_intern(&lf[60],33,"\003systhread-block-for-termination!");
lf[61]=C_h_intern(&lf[61],29,"\003systhread-block-for-timeout!");
lf[62]=C_h_intern(&lf[62],17,"thread-terminate!");
lf[63]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\033terminated-thread-exception\376\377\016");
lf[64]=C_h_intern(&lf[64],21,"\003sysprimordial-thread");
lf[65]=C_h_intern(&lf[65],16,"\003sysexit-handler");
lf[66]=C_h_intern(&lf[66],15,"thread-suspend!");
lf[67]=C_h_intern(&lf[67],9,"suspended");
lf[68]=C_h_intern(&lf[68],14,"thread-resume!");
lf[69]=C_h_intern(&lf[69],13,"thread-sleep!");
lf[70]=C_decode_literal(C_heaptop,"\376B\000\000\030invalid timeout argument");
lf[71]=C_h_intern(&lf[71],6,"mutex\077");
lf[72]=C_h_intern(&lf[72],5,"mutex");
lf[73]=C_h_intern(&lf[73],10,"make-mutex");
lf[74]=C_h_intern(&lf[74],14,"\003sysmake-mutex");
lf[75]=C_h_intern(&lf[75],10,"mutex-name");
lf[76]=C_h_intern(&lf[76],14,"mutex-specific");
lf[77]=C_h_intern(&lf[77],19,"mutex-specific-set!");
lf[78]=C_h_intern(&lf[78],11,"mutex-state");
lf[79]=C_h_intern(&lf[79],9,"not-owned");
lf[80]=C_h_intern(&lf[80],9,"abandoned");
lf[81]=C_h_intern(&lf[81],13,"not-abandoned");
lf[82]=C_h_intern(&lf[82],11,"mutex-lock!");
lf[83]=C_h_intern(&lf[83],10,"\003sysappend");
lf[84]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\031abandoned-mutex-exception\376\377\016");
lf[85]=C_h_intern(&lf[85],8,"\003sysdelq");
lf[86]=C_h_intern(&lf[86],8,"sleeping");
lf[87]=C_h_intern(&lf[87],13,"mutex-unlock!");
lf[88]=C_h_intern(&lf[88],18,"condition-variable");
lf[89]=C_h_intern(&lf[89],7,"blocked");
lf[90]=C_h_intern(&lf[90],23,"make-condition-variable");
lf[91]=C_h_intern(&lf[91],19,"condition-variable\077");
lf[92]=C_h_intern(&lf[92],27,"condition-variable-specific");
lf[93]=C_h_intern(&lf[93],32,"condition-variable-specific-set!");
lf[94]=C_h_intern(&lf[94],26,"condition-variable-signal!");
lf[95]=C_h_intern(&lf[95],25,"\003systhread-basic-unblock!");
lf[96]=C_h_intern(&lf[96],29,"condition-variable-broadcast!");
lf[97]=C_h_intern(&lf[97],12,"\003sysfor-each");
lf[98]=C_h_intern(&lf[98],14,"thread-signal!");
lf[99]=C_h_intern(&lf[99],19,"\003systhread-unblock!");
lf[100]=C_h_intern(&lf[100],20,"thread-wait-for-i/o!");
lf[101]=C_h_intern(&lf[101],4,"\000all");
lf[102]=C_h_intern(&lf[102],25,"\003systhread-block-for-i/o!");
lf[103]=C_h_intern(&lf[103],4,"msvc");
lf[104]=C_h_intern(&lf[104],20,"\003sysread-prompt-hook");
lf[105]=C_h_intern(&lf[105],13,"\003systty-port\077");
lf[106]=C_h_intern(&lf[106],18,"\003sysstandard-input");
lf[107]=C_h_intern(&lf[107],14,"build-platform");
lf[108]=C_h_intern(&lf[108],27,"condition-property-accessor");
lf[109]=C_h_intern(&lf[109],6,"reason");
lf[110]=C_h_intern(&lf[110],17,"register-feature!");
lf[111]=C_h_intern(&lf[111],7,"srfi-18");
C_register_lf2(lf,112,create_ptable());
t2=C_mutate(&lf[0],lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_270,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_scheduler_toplevel(2,C_SCHEME_UNDEFINED,t3);}

/* k268 */
static void C_ccall f_270(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_270,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_273,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-18.scm: 70   register-feature! */
t3=*((C_word*)lf[110]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[111]);}

/* k271 in k268 */
static void C_ccall f_273(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_273,2,t0,t1);}
t2=*((C_word*)lf[2]+1);
t3=C_mutate(&lf[3],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_275,a[2]=t2,tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[8]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_318,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[9]+1,*((C_word*)lf[8]+1));
t6=C_mutate((C_word*)lf[10]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_345,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate((C_word*)lf[11]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_366,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate((C_word*)lf[12]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_395,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate((C_word*)lf[16]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_449,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate((C_word*)lf[17]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_465,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate((C_word*)lf[18]+1,*((C_word*)lf[17]+1));
t12=C_mutate((C_word*)lf[19]+1,*((C_word*)lf[20]+1));
t13=C_mutate((C_word*)lf[21]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_473,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate((C_word*)lf[24]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_489,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate((C_word*)lf[26]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_505,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate((C_word*)lf[28]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_521,tmp=(C_word)a,a+=2,tmp));
t17=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_539,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-18.scm: 160  condition-property-accessor */
t18=*((C_word*)lf[108]+1);
((C_proc4)(void*)(*((C_word*)t18+1)))(4,t18,t17,lf[29],lf[109]);}

/* k537 in k271 in k268 */
static void C_ccall f_539(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word ab[70],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_539,2,t0,t1);}
t2=C_mutate((C_word*)lf[30]+1,t1);
t3=*((C_word*)lf[31]+1);
t4=C_mutate((C_word*)lf[32]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_541,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[40]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_585,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[41]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_591,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate((C_word*)lf[42]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_594,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate((C_word*)lf[43]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_603,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate((C_word*)lf[44]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_612,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate((C_word*)lf[45]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_621,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate((C_word*)lf[46]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_630,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate((C_word*)lf[47]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_646,tmp=(C_word)a,a+=2,tmp));
t13=*((C_word*)lf[32]+1);
t14=C_mutate((C_word*)lf[48]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_655,a[2]=t13,tmp=(C_word)a,a+=3,tmp));
t15=C_mutate((C_word*)lf[53]+1,*((C_word*)lf[54]+1));
t16=C_mutate((C_word*)lf[55]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_691,tmp=(C_word)a,a+=2,tmp));
t17=C_mutate((C_word*)lf[62]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_810,tmp=(C_word)a,a+=2,tmp));
t18=C_mutate((C_word*)lf[66]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_854,tmp=(C_word)a,a+=2,tmp));
t19=C_mutate((C_word*)lf[68]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_887,tmp=(C_word)a,a+=2,tmp));
t20=C_mutate((C_word*)lf[69]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_909,tmp=(C_word)a,a+=2,tmp));
t21=C_mutate((C_word*)lf[71]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_949,tmp=(C_word)a,a+=2,tmp));
t22=*((C_word*)lf[31]+1);
t23=C_mutate((C_word*)lf[73]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_955,a[2]=t22,tmp=(C_word)a,a+=3,tmp));
t24=C_mutate((C_word*)lf[75]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_973,tmp=(C_word)a,a+=2,tmp));
t25=C_mutate((C_word*)lf[76]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_982,tmp=(C_word)a,a+=2,tmp));
t26=C_mutate((C_word*)lf[77]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_991,tmp=(C_word)a,a+=2,tmp));
t27=C_mutate((C_word*)lf[78]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1000,tmp=(C_word)a,a+=2,tmp));
t28=C_mutate((C_word*)lf[82]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1024,tmp=(C_word)a,a+=2,tmp));
t29=C_mutate((C_word*)lf[87]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1236,tmp=(C_word)a,a+=2,tmp));
t30=*((C_word*)lf[31]+1);
t31=C_mutate((C_word*)lf[90]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1418,a[2]=t30,tmp=(C_word)a,a+=3,tmp));
t32=C_mutate((C_word*)lf[91]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1437,tmp=(C_word)a,a+=2,tmp));
t33=C_mutate((C_word*)lf[92]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1443,tmp=(C_word)a,a+=2,tmp));
t34=C_mutate((C_word*)lf[93]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1452,tmp=(C_word)a,a+=2,tmp));
t35=C_mutate((C_word*)lf[94]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1461,tmp=(C_word)a,a+=2,tmp));
t36=C_mutate((C_word*)lf[96]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1504,tmp=(C_word)a,a+=2,tmp));
t37=C_mutate((C_word*)lf[98]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1541,tmp=(C_word)a,a+=2,tmp));
t38=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1575,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t39=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1633,a[2]=t38,tmp=(C_word)a,a+=3,tmp);
/* srfi-18.scm: 477  build-platform */
t40=*((C_word*)lf[107]+1);
((C_proc2)(void*)(*((C_word*)t40+1)))(2,t40,t39);}

/* k1631 in k537 in k271 in k268 */
static void C_ccall f_1633(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1633,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[103]);
if(C_truep(t2)){
t3=((C_word*)t0)[2];
f_1575(t3,C_SCHEME_UNDEFINED);}
else{
t3=*((C_word*)lf[104]+1);
t4=*((C_word*)lf[53]+1);
t5=C_mutate((C_word*)lf[104]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1607,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t0)[2];
f_1575(t6,t5);}}

/* ##sys#read-prompt-hook in k1631 in k537 in k271 in k268 */
static void C_ccall f_1607(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1607,2,t0,t1);}
t2=(C_word)C_fudge(C_fix(12));
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1617,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t2)){
t4=t3;
f_1617(2,t4,t2);}
else{
/* srfi-18.scm: 482  ##sys#tty-port? */
t4=*((C_word*)lf[105]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,*((C_word*)lf[106]+1));}}

/* k1615 in ##sys#read-prompt-hook in k1631 in k537 in k271 in k268 */
static void C_ccall f_1617(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1617,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1620,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* srfi-18.scm: 483  old */
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k1618 in k1615 in ##sys#read-prompt-hook in k1631 in k537 in k271 in k268 */
static void C_ccall f_1620(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1620,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1623,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-18.scm: 484  ##sys#thread-block-for-i/o! */
t3=*((C_word*)lf[102]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,*((C_word*)lf[36]+1),C_fix(0),C_SCHEME_TRUE);}

/* k1621 in k1618 in k1615 in ##sys#read-prompt-hook in k1631 in k537 in k271 in k268 */
static void C_ccall f_1623(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-18.scm: 485  thread-yield! */
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k1573 in k537 in k271 in k268 */
static void C_fcall f_1575(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1575,NULL,2,t0,t1);}
t2=C_mutate((C_word*)lf[100]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1577,tmp=(C_word)a,a+=2,tmp));
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}

/* thread-wait-for-i/o! in k1573 in k537 in k271 in k268 */
static void C_ccall f_1577(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr3rv,(void*)f_1577r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_1577r(t0,t1,t2,t3);}}

static void C_ccall f_1577r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(3);
t4=(C_word)C_vemptyp(t3);
t5=(C_truep(t4)?lf[101]:(C_word)C_slot(t3,C_fix(0)));
t6=(C_word)C_i_check_exact_2(t2,lf[100]);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1587,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* srfi-18.scm: 492  ##sys#thread-block-for-i/o! */
t8=*((C_word*)lf[102]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t7,*((C_word*)lf[36]+1),t2,t5);}

/* k1585 in thread-wait-for-i/o! in k1573 in k537 in k271 in k268 */
static void C_ccall f_1587(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-18.scm: 493  thread-yield! */
t2=*((C_word*)lf[53]+1);
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* thread-signal! in k537 in k271 in k268 */
static void C_ccall f_1541(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1541,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure_2(t2,lf[39],lf[98]);
t5=(C_word)C_eqp(t2,*((C_word*)lf[36]+1));
if(C_truep(t5)){
/* srfi-18.scm: 465  ##sys#signal */
t6=*((C_word*)lf[20]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t1,t3);}
else{
t6=(C_word)C_slot(t2,C_fix(1));
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1565,a[2]=t3,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t8=(C_word)C_i_setslot(t2,C_fix(1),t7);
/* srfi-18.scm: 472  ##sys#thread-unblock! */
t9=*((C_word*)lf[99]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t1,t2);}}

/* a1564 in thread-signal! in k537 in k271 in k268 */
static void C_ccall f_1565(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1565,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1569,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-18.scm: 470  ##sys#signal */
t3=*((C_word*)lf[20]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k1567 in a1564 in thread-signal! in k537 in k271 in k268 */
static void C_ccall f_1569(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-18.scm: 471  old */
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* condition-variable-broadcast! in k537 in k271 in k268 */
static void C_ccall f_1504(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1504,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[88],lf[96]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1511,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1516,tmp=(C_word)a,a+=2,tmp);
t6=(C_word)C_slot(t2,C_fix(2));
/* srfi-18.scm: 451  ##sys#for-each */
t7=*((C_word*)lf[97]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t4,t5,t6);}

/* a1515 in condition-variable-broadcast! in k537 in k271 in k268 */
static void C_ccall f_1516(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1516,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(3));
t4=(C_word)C_eqp(t3,lf[89]);
t5=(C_truep(t4)?t4:(C_word)C_eqp(t3,lf[86]));
if(C_truep(t5)){
/* srfi-18.scm: 455  ##sys#thread-basic-unblock! */
t6=*((C_word*)lf[95]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t1,t2);}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}}

/* k1509 in condition-variable-broadcast! in k537 in k271 in k268 */
static void C_ccall f_1511(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_set_i_slot(((C_word*)t0)[2],C_fix(2),C_SCHEME_END_OF_LIST));}

/* condition-variable-signal! in k537 in k271 in k268 */
static void C_ccall f_1461(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1461,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[88],lf[94]);
t4=(C_word)C_slot(t2,C_fix(2));
if(C_truep((C_word)C_i_nullp(t4))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}
else{
t5=(C_word)C_slot(t4,C_fix(0));
t6=(C_word)C_slot(t5,C_fix(3));
t7=(C_word)C_slot(t4,C_fix(1));
t8=(C_word)C_i_setslot(t2,C_fix(2),t7);
t9=(C_word)C_eqp(t6,lf[89]);
t10=(C_truep(t9)?t9:(C_word)C_eqp(t6,lf[86]));
if(C_truep(t10)){
/* srfi-18.scm: 446  ##sys#thread-basic-unblock! */
t11=*((C_word*)lf[95]+1);
((C_proc3)(void*)(*((C_word*)t11+1)))(3,t11,t1,t5);}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_UNDEFINED);}}}

/* condition-variable-specific-set! in k537 in k271 in k268 */
static void C_ccall f_1452(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1452,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure_2(t2,lf[88],lf[93]);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_i_setslot(t2,C_fix(3),t3));}

/* condition-variable-specific in k537 in k271 in k268 */
static void C_ccall f_1443(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1443,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[88],lf[92]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(3)));}

/* condition-variable? in k537 in k271 in k268 */
static void C_ccall f_1437(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1437,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[88]));}

/* make-condition-variable in k537 in k271 in k268 */
static void C_ccall f_1418(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2rv,(void*)f_1418r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_1418r(t0,t1,t2);}}

static void C_ccall f_1418r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1426,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_notvemptyp(t2))){
t4=t3;
f_1426(2,t4,(C_word)C_slot(t2,C_fix(0)));}
else{
/* srfi-18.scm: 422  gensym */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[88]);}}

/* k1424 in make-condition-variable in k537 in k271 in k268 */
static void C_ccall f_1426(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1426,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[88],t1,C_SCHEME_END_OF_LIST,C_SCHEME_UNDEFINED));}

/* mutex-unlock! in k537 in k271 in k268 */
static void C_ccall f_1236(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr3rv,(void*)f_1236r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_1236r(t0,t1,t2,t3);}}

static void C_ccall f_1236r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a=C_alloc(6);
t4=(C_word)C_i_check_structure_2(t2,lf[72],lf[87]);
t5=*((C_word*)lf[36]+1);
t6=(C_word)C_notvemptyp(t3);
t7=(C_truep(t6)?(C_word)C_slot(t3,C_fix(0)):C_SCHEME_FALSE);
t8=(C_word)C_block_size(t3);
t9=(C_word)C_fixnum_greaterp(t8,C_fix(1));
t10=(C_truep(t9)?(C_word)C_slot(t3,C_fix(1)):C_SCHEME_FALSE);
t11=(C_truep(t7)?(C_word)C_i_check_structure_2(t7,lf[88],lf[87]):C_SCHEME_UNDEFINED);
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1254,a[2]=t10,a[3]=t7,a[4]=t5,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* srfi-18.scm: 381  ##sys#call-with-current-continuation */
C_call_cc(3,0,t1,t12);}

/* a1253 in mutex-unlock! in k537 in k271 in k268 */
static void C_ccall f_1254(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1254,3,t0,t1,t2);}
t3=(C_word)C_slot(((C_word*)t0)[5],C_fix(3));
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1261,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,a[5]=t2,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[2])){
/* srfi-18.scm: 384  ##sys#compute-time-limit */
t5=lf[3];
f_275(t5,t4,((C_word*)t0)[2]);}
else{
t5=t4;
f_1261(2,t5,C_SCHEME_FALSE);}}

/* k1259 in a1253 in mutex-unlock! in k537 in k271 in k268 */
static void C_ccall f_1261(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1261,2,t0,t1);}
t2=(C_word)C_i_set_i_slot(((C_word*)t0)[7],C_fix(4),C_SCHEME_FALSE);
t3=(C_word)C_i_set_i_slot(((C_word*)t0)[7],C_fix(5),C_SCHEME_FALSE);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1390,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
t5=(C_word)C_slot(((C_word*)t0)[6],C_fix(8));
/* srfi-18.scm: 388  ##sys#delq */
t6=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,((C_word*)t0)[7],t5);}

/* k1388 in k1259 in a1253 in mutex-unlock! in k537 in k271 in k268 */
static void C_ccall f_1390(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1390,2,t0,t1);}
t2=(C_word)C_i_setslot(((C_word*)t0)[8],C_fix(8),t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1382,a[2]=((C_word*)t0)[7],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_setslot(((C_word*)t0)[8],C_fix(1),t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1276,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[3])){
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1372,a[2]=t5,a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
t7=(C_word)C_slot(((C_word*)t0)[3],C_fix(2));
t8=(C_word)C_a_i_list(&a,1,((C_word*)t0)[8]);
/* srfi-18.scm: 391  ##sys#append */
t9=*((C_word*)lf[83]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t6,t7,t8);}
else{
t6=t5;
f_1276(2,t6,C_SCHEME_UNDEFINED);}}

/* k1370 in k1388 in k1259 in a1253 in mutex-unlock! in k537 in k271 in k268 */
static void C_ccall f_1372(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1372,2,t0,t1);}
t2=(C_word)C_i_setslot(((C_word*)t0)[6],C_fix(2),t1);
if(C_truep(((C_word*)t0)[5])){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1350,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_setslot(((C_word*)t0)[3],C_fix(1),t3);
/* srfi-18.scm: 398  ##sys#thread-block-for-timeout! */
t5=*((C_word*)lf[61]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[5]);}
else{
t3=((C_word*)t0)[2];
f_1276(2,t3,(C_word)C_i_setslot(((C_word*)t0)[3],C_fix(3),lf[86]));}}

/* a1349 in k1370 in k1388 in k1259 in a1253 in mutex-unlock! in k537 in k271 in k268 */
static void C_ccall f_1350(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1350,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1361,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_slot(((C_word*)t0)[4],C_fix(2));
/* srfi-18.scm: 396  ##sys#delq */
t4=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,((C_word*)t0)[2],t3);}

/* k1359 in a1349 in k1370 in k1388 in k1259 in a1253 in mutex-unlock! in k537 in k271 in k268 */
static void C_ccall f_1361(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[4],C_fix(2),t1);
/* srfi-18.scm: 397  return */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k1274 in k1388 in k1259 in a1253 in mutex-unlock! in k537 in k271 in k268 */
static void C_ccall f_1276(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1276,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1279,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[3]))){
t3=t2;
f_1279(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(0));
t4=(C_word)C_slot(t3,C_fix(3));
t5=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
t6=(C_word)C_i_setslot(((C_word*)t0)[2],C_fix(3),t5);
t7=(C_word)C_i_set_i_slot(((C_word*)t0)[2],C_fix(5),C_SCHEME_TRUE);
t8=(C_word)C_eqp(t4,lf[89]);
t9=(C_truep(t8)?t8:(C_word)C_eqp(t4,lf[86]));
if(C_truep(t9)){
t10=(C_word)C_i_setslot(((C_word*)t0)[2],C_fix(2),t3);
t11=(C_word)C_slot(t3,C_fix(8));
t12=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t11);
t13=(C_word)C_i_setslot(t3,C_fix(8),t12);
t14=(C_word)C_eqp(t4,lf[86]);
if(C_truep(t14)){
/* srfi-18.scm: 409  ##sys#add-to-ready-queue */
t15=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t15+1)))(3,t15,t2,t3);}
else{
t15=t2;
f_1279(2,t15,C_SCHEME_UNDEFINED);}}
else{
t10=t2;
f_1279(2,t10,C_SCHEME_UNDEFINED);}}}

/* k1277 in k1274 in k1388 in k1259 in a1253 in mutex-unlock! in k537 in k271 in k268 */
static void C_ccall f_1279(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-18.scm: 410  ##sys#schedule */
t2=*((C_word*)lf[33]+1);
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* a1381 in k1388 in k1259 in a1253 in mutex-unlock! in k537 in k271 in k268 */
static void C_ccall f_1382(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1382,2,t0,t1);}
/* srfi-18.scm: 389  return */
t2=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,C_SCHEME_TRUE);}

/* mutex-lock! in k537 in k271 in k268 */
static void C_ccall f_1024(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3rv,(void*)f_1024r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_1024r(t0,t1,t2,t3);}}

static void C_ccall f_1024r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(5);
t4=(C_word)C_i_check_structure_2(t2,lf[72],lf[82]);
t5=(C_word)C_notvemptyp(t3);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1034,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t5)){
t7=(C_word)C_slot(t3,C_fix(0));
/* srfi-18.scm: 327  ##sys#compute-time-limit */
t8=lf[3];
f_275(t8,t6,t7);}
else{
t7=t6;
f_1034(2,t7,C_SCHEME_FALSE);}}

/* k1032 in mutex-lock! in k537 in k271 in k268 */
static void C_ccall f_1034(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1034,2,t0,t1);}
t2=(C_word)C_block_size(((C_word*)t0)[4]);
t3=(C_word)C_fixnum_greaterp(t2,C_fix(1));
t4=(C_truep(t3)?(C_word)C_slot(((C_word*)t0)[4],C_fix(1)):C_SCHEME_FALSE);
t5=(C_word)C_slot(((C_word*)t0)[3],C_fix(4));
t6=(C_truep(t4)?(C_word)C_i_check_structure_2(t4,lf[39],lf[82]):C_SCHEME_UNDEFINED);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1051,a[2]=t3,a[3]=t4,a[4]=t1,a[5]=t5,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* srfi-18.scm: 332  ##sys#call-with-current-continuation */
C_call_cc(3,0,((C_word*)t0)[2],t7);}

/* a1050 in k1032 in mutex-lock! in k537 in k271 in k268 */
static void C_ccall f_1051(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1051,3,t0,t1,t2);}
t3=*((C_word*)lf[36]+1);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1054,a[2]=t3,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1075,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_slot(((C_word*)t0)[6],C_fix(5)))){
if(C_truep(((C_word*)t0)[4])){
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1161,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=t4,a[5]=t3,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* srfi-18.scm: 358  check */
t7=t5;
f_1075(t7,t6);}
else{
t6=(C_word)C_i_setslot(t3,C_fix(3),lf[86]);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1209,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_i_setslot(t3,C_fix(1),t7);
/* srfi-18.scm: 371  switch */
t9=t4;
f_1054(t9,t1);}}
else{
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1099,a[2]=t5,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t7=(C_truep(((C_word*)t0)[2])?(C_word)C_i_not(((C_word*)t0)[3]):C_SCHEME_FALSE);
if(C_truep(t7)){
t8=(C_word)C_i_set_i_slot(((C_word*)t0)[6],C_fix(2),C_SCHEME_FALSE);
t9=t6;
f_1099(t9,(C_word)C_i_set_i_slot(((C_word*)t0)[6],C_fix(5),C_SCHEME_TRUE));}
else{
t8=(C_truep(((C_word*)t0)[3])?((C_word*)t0)[3]:t3);
t9=(C_word)C_slot(t8,C_fix(3));
t10=(C_word)C_eqp(lf[56],t9);
t11=(C_truep(t10)?t10:(C_word)C_eqp(lf[35],t9));
if(C_truep(t11)){
t12=t6;
f_1099(t12,(C_word)C_i_set_i_slot(((C_word*)t0)[6],C_fix(4),C_SCHEME_TRUE));}
else{
t12=(C_word)C_i_set_i_slot(((C_word*)t0)[6],C_fix(5),C_SCHEME_TRUE);
t13=(C_word)C_slot(t8,C_fix(8));
t14=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t13);
t15=(C_word)C_i_setslot(t8,C_fix(8),t14);
t16=t6;
f_1099(t16,(C_word)C_i_setslot(((C_word*)t0)[6],C_fix(2),t8));}}}}

/* k1097 in a1050 in k1032 in mutex-lock! in k537 in k271 in k268 */
static void C_fcall f_1099(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1099,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1102,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* srfi-18.scm: 355  check */
t3=((C_word*)t0)[2];
f_1075(t3,t2);}

/* k1100 in k1097 in a1050 in k1032 in mutex-lock! in k537 in k271 in k268 */
static void C_ccall f_1102(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-18.scm: 356  return */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],C_SCHEME_TRUE);}

/* a1208 in a1050 in k1032 in mutex-lock! in k537 in k271 in k268 */
static void C_ccall f_1209(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1209,2,t0,t1);}
/* srfi-18.scm: 370  return */
t2=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,C_SCHEME_TRUE);}

/* k1159 in a1050 in k1032 in mutex-lock! in k537 in k271 in k268 */
static void C_ccall f_1161(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1161,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1172,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_setslot(((C_word*)t0)[5],C_fix(1),t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1167,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* srfi-18.scm: 366  ##sys#thread-block-for-timeout! */
t5=*((C_word*)lf[61]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[5],((C_word*)t0)[2]);}

/* k1165 in k1159 in a1050 in k1032 in mutex-lock! in k537 in k271 in k268 */
static void C_ccall f_1167(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-18.scm: 367  switch */
t2=((C_word*)t0)[3];
f_1054(t2,((C_word*)t0)[2]);}

/* a1171 in k1159 in a1050 in k1032 in mutex-lock! in k537 in k271 in k268 */
static void C_ccall f_1172(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1172,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1194,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_slot(((C_word*)t0)[4],C_fix(3));
/* srfi-18.scm: 362  ##sys#delq */
t4=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,((C_word*)t0)[2],t3);}

/* k1192 in a1171 in k1159 in a1050 in k1032 in mutex-lock! in k537 in k271 in k268 */
static void C_ccall f_1194(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1194,2,t0,t1);}
t2=(C_word)C_i_setslot(((C_word*)t0)[4],C_fix(3),t1);
t3=(C_word)C_slot(*((C_word*)lf[36]+1),C_fix(8));
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t3);
t5=(C_word)C_i_setslot(*((C_word*)lf[36]+1),C_fix(8),t4);
t6=(C_word)C_i_setslot(((C_word*)t0)[4],C_fix(2),((C_word*)t0)[3]);
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_SCHEME_FALSE);}

/* check in a1050 in k1032 in mutex-lock! in k537 in k271 in k268 */
static void C_fcall f_1075(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1075,NULL,2,t0,t1);}
if(C_truep(((C_word*)t0)[3])){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1086,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_a_i_record(&a,3,lf[22],lf[84],C_SCHEME_END_OF_LIST);
/* srfi-18.scm: 340  ##sys#signal */
t4=*((C_word*)lf[20]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}
else{
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k1084 in check in a1050 in k1032 in mutex-lock! in k537 in k271 in k268 */
static void C_ccall f_1086(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-18.scm: 340  return */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* switch in a1050 in k1032 in mutex-lock! in k537 in k271 in k268 */
static void C_fcall f_1054(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1054,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1065,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(3));
t4=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
/* srfi-18.scm: 336  ##sys#append */
t5=*((C_word*)lf[83]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,t3,t4);}

/* k1063 in switch in a1050 in k1032 in mutex-lock! in k537 in k271 in k268 */
static void C_ccall f_1065(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[3],C_fix(3),t1);
/* srfi-18.scm: 337  ##sys#schedule */
t3=*((C_word*)lf[33]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[2]);}

/* mutex-state in k537 in k271 in k268 */
static void C_ccall f_1000(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1000,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[72],lf[78]);
if(C_truep((C_word)C_slot(t2,C_fix(5)))){
t4=(C_word)C_slot(t2,C_fix(2));
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_truep(t4)?t4:lf[79]));}
else{
t4=(C_word)C_slot(t2,C_fix(4));
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_truep(t4)?lf[80]:lf[81]));}}

/* mutex-specific-set! in k537 in k271 in k268 */
static void C_ccall f_991(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_991,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure_2(t2,lf[72],lf[77]);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_i_setslot(t2,C_fix(6),t3));}

/* mutex-specific in k537 in k271 in k268 */
static void C_ccall f_982(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_982,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[72],lf[76]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(6)));}

/* mutex-name in k537 in k271 in k268 */
static void C_ccall f_973(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_973,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[72],lf[75]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(1)));}

/* make-mutex in k537 in k271 in k268 */
static void C_ccall f_955(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2rv,(void*)f_955r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_955r(t0,t1,t2);}}

static void C_ccall f_955r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_959,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_notvemptyp(t2))){
t4=t3;
f_959(2,t4,(C_word)C_slot(t2,C_fix(0)));}
else{
/* srfi-18.scm: 301  gensym */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[72]);}}

/* k957 in make-mutex in k537 in k271 in k268 */
static void C_ccall f_959(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-18.scm: 302  ##sys#make-mutex */
t2=*((C_word*)lf[74]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,*((C_word*)lf[36]+1));}

/* mutex? in k537 in k271 in k268 */
static void C_ccall f_949(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_949,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[72]));}

/* thread-sleep! in k537 in k271 in k268 */
static void C_ccall f_909(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_909,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_937,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t2)){
t4=t3;
f_937(2,t4,C_SCHEME_UNDEFINED);}
else{
/* srfi-18.scm: 290  ##sys#signal-hook */
t4=*((C_word*)lf[5]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t3,lf[6],lf[69],lf[70],t2);}}

/* k935 in thread-sleep! in k537 in k271 in k268 */
static void C_ccall f_937(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_937,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_944,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* srfi-18.scm: 291  ##sys#compute-time-limit */
t3=lf[3];
f_275(t3,t2,((C_word*)t0)[2]);}

/* k942 in k935 in thread-sleep! in k537 in k271 in k268 */
static void C_ccall f_944(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_944,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_918,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* srfi-18.scm: 284  ##sys#call-with-current-continuation */
C_call_cc(3,0,t2,t3);}

/* a917 in k942 in k935 in thread-sleep! in k537 in k271 in k268 */
static void C_ccall f_918(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_918,3,t0,t1,t2);}
t3=*((C_word*)lf[36]+1);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_930,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_i_setslot(t3,C_fix(1),t4);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_925,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* srfi-18.scm: 288  ##sys#thread-block-for-timeout! */
t7=*((C_word*)lf[61]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,t3,((C_word*)t0)[2]);}

/* k923 in a917 in k942 in k935 in thread-sleep! in k537 in k271 in k268 */
static void C_ccall f_925(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-18.scm: 289  ##sys#schedule */
t2=*((C_word*)lf[33]+1);
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* a929 in a917 in k942 in k935 in thread-sleep! in k537 in k271 in k268 */
static void C_ccall f_930(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_930,2,t0,t1);}
/* srfi-18.scm: 287  return */
t2=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,C_SCHEME_UNDEFINED);}

/* thread-resume! in k537 in k271 in k268 */
static void C_ccall f_887(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_887,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[39],lf[68]);
t4=(C_word)C_slot(t2,C_fix(3));
t5=(C_word)C_eqp(t4,lf[67]);
if(C_truep(t5)){
t6=(C_word)C_i_setslot(t2,C_fix(3),lf[49]);
/* srfi-18.scm: 280  ##sys#add-to-ready-queue */
t7=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t1,t2);}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}}

/* thread-suspend! in k537 in k271 in k268 */
static void C_ccall f_854(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_854,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[39],lf[66]);
t4=(C_word)C_i_setslot(t2,C_fix(3),lf[67]);
t5=(C_word)C_eqp(t2,*((C_word*)lf[36]+1));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_872,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* srfi-18.scm: 271  ##sys#call-with-current-continuation */
C_call_cc(3,0,t1,t6);}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}}

/* a871 in thread-suspend! in k537 in k271 in k268 */
static void C_ccall f_872(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_872,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_881,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_setslot(((C_word*)t0)[2],C_fix(1),t3);
/* srfi-18.scm: 274  ##sys#schedule */
t5=*((C_word*)lf[33]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t1);}

/* a880 in a871 in thread-suspend! in k537 in k271 in k268 */
static void C_ccall f_881(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_881,2,t0,t1);}
/* srfi-18.scm: 273  return */
t2=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,C_SCHEME_UNDEFINED);}

/* thread-terminate! in k537 in k271 in k268 */
static void C_ccall f_810(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_810,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[39],lf[62]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_817,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_eqp(t2,*((C_word*)lf[64]+1));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_852,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* srfi-18.scm: 261  ##sys#exit-handler */
t7=*((C_word*)lf[65]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t6=t4;
f_817(2,t6,C_SCHEME_UNDEFINED);}}

/* k850 in thread-terminate! in k537 in k271 in k268 */
static void C_ccall f_852(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k815 in thread-terminate! in k537 in k271 in k268 */
static void C_ccall f_817(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_817,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,C_SCHEME_UNDEFINED);
t3=(C_word)C_i_set_i_slot(((C_word*)t0)[3],C_fix(2),t2);
t4=(C_word)C_a_i_record(&a,3,lf[22],lf[63],C_SCHEME_END_OF_LIST);
t5=(C_word)C_i_setslot(((C_word*)t0)[3],C_fix(7),t4);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_826,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-18.scm: 264  ##sys#thread-kill! */
t7=*((C_word*)lf[34]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,((C_word*)t0)[3],lf[56]);}

/* k824 in k815 in thread-terminate! in k537 in k271 in k268 */
static void C_ccall f_826(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(((C_word*)t0)[3],*((C_word*)lf[36]+1));
if(C_truep(t2)){
/* srfi-18.scm: 265  ##sys#schedule */
t3=*((C_word*)lf[33]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* thread-join! in k537 in k271 in k268 */
static void C_ccall f_691(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_691r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_691r(t0,t1,t2,t3);}}

static void C_ccall f_691r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t4=(C_word)C_i_check_structure_2(t2,lf[39],lf[55]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_698,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(t3))){
t6=(C_word)C_slot(t3,C_fix(0));
/* srfi-18.scm: 230  ##sys#compute-time-limit */
t7=lf[3];
f_275(t7,t5,t6);}
else{
t6=t5;
f_698(2,t6,C_SCHEME_FALSE);}}

/* k696 in thread-join! in k537 in k271 in k268 */
static void C_ccall f_698(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_698,2,t0,t1);}
t2=(C_word)C_i_pairp(((C_word*)t0)[4]);
t3=(C_truep(t2)?(C_word)C_slot(((C_word*)t0)[4],C_fix(1)):C_SCHEME_FALSE);
t4=(C_truep(t3)?(C_word)C_i_pairp(t3):C_SCHEME_FALSE);
t5=(C_truep(t4)?(C_word)C_slot(t3,C_fix(0)):C_SCHEME_FALSE);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_712,a[2]=t1,a[3]=t5,a[4]=t4,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* srfi-18.scm: 234  ##sys#call-with-current-continuation */
C_call_cc(3,0,((C_word*)t0)[2],t6);}

/* a711 in k696 in thread-join! in k537 in k271 in k268 */
static void C_ccall f_712(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_712,3,t0,t1,t2);}
t3=*((C_word*)lf[36]+1);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_716,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t2,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[2])){
/* srfi-18.scm: 237  ##sys#thread-block-for-timeout! */
t5=*((C_word*)lf[61]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t3,((C_word*)t0)[2]);}
else{
t5=t4;
f_716(2,t5,C_SCHEME_UNDEFINED);}}

/* k714 in a711 in k696 in thread-join! in k537 in k271 in k268 */
static void C_ccall f_716(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_716,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_727,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_setslot(((C_word*)t0)[3],C_fix(1),t2);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_722,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-18.scm: 255  ##sys#thread-block-for-termination! */
t5=*((C_word*)lf[60]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[3],((C_word*)t0)[7]);}

/* k720 in k714 in a711 in k696 in thread-join! in k537 in k271 in k268 */
static void C_ccall f_722(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-18.scm: 256  ##sys#schedule */
t2=*((C_word*)lf[33]+1);
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* a726 in k714 in a711 in k696 in thread-join! in k537 in k271 in k268 */
static void C_ccall f_727(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_727,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(3));
t3=(C_word)C_eqp(t2,lf[35]);
if(C_truep(t3)){
t4=(C_word)C_slot(((C_word*)t0)[5],C_fix(2));
C_apply(4,0,t1,((C_word*)t0)[4],t4);}
else{
t4=(C_word)C_eqp(t2,lf[56]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_757,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_slot(((C_word*)t0)[5],C_fix(7));
t7=(C_word)C_a_i_list(&a,2,lf[57],t6);
t8=(C_word)C_a_i_record(&a,3,lf[22],lf[58],t7);
/* srfi-18.scm: 245  ##sys#signal */
t9=*((C_word*)lf[20]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t5,t8);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_776,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[3])){
t6=t5;
f_776(2,t6,((C_word*)t0)[2]);}
else{
t6=(C_word)C_a_i_record(&a,3,lf[22],lf[59],C_SCHEME_END_OF_LIST);
/* srfi-18.scm: 253  ##sys#signal */
t7=*((C_word*)lf[20]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t5,t6);}}}}

/* k774 in a726 in k714 in a711 in k696 in thread-join! in k537 in k271 in k268 */
static void C_ccall f_776(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-18.scm: 250  return */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k755 in a726 in k714 in a711 in k696 in thread-join! in k537 in k271 in k268 */
static void C_ccall f_757(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-18.scm: 244  return */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* thread-start! in k537 in k271 in k268 */
static void C_ccall f_655(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_655,3,t0,t1,t2);}
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_659,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_closurep(((C_word*)t3)[1]))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_685,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* srfi-18.scm: 217  make-thread */
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t3)[1]);}
else{
t5=t4;
f_659(t5,(C_word)C_i_check_structure_2(((C_word*)t3)[1],lf[39],lf[48]));}}

/* k683 in thread-start! in k537 in k271 in k268 */
static void C_ccall f_685(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_659(t3,t2);}

/* k657 in thread-start! in k537 in k271 in k268 */
static void C_fcall f_659(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_659,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_662,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_slot(((C_word*)((C_word*)t0)[3])[1],C_fix(3));
t4=(C_word)C_eqp(lf[38],t3);
if(C_truep(t4)){
t5=t2;
f_662(2,t5,C_SCHEME_UNDEFINED);}
else{
/* srfi-18.scm: 220  ##sys#error */
t5=*((C_word*)lf[51]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t2,lf[48],lf[52],((C_word*)((C_word*)t0)[3])[1]);}}

/* k660 in k657 in thread-start! in k537 in k271 in k268 */
static void C_ccall f_662(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_662,2,t0,t1);}
t2=(C_word)C_i_setslot(((C_word*)((C_word*)t0)[3])[1],C_fix(3),lf[49]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_668,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* srfi-18.scm: 222  ##sys#add-to-ready-queue */
t4=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)((C_word*)t0)[3])[1]);}

/* k666 in k660 in k657 in thread-start! in k537 in k271 in k268 */
static void C_ccall f_668(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* thread-name in k537 in k271 in k268 */
static void C_ccall f_646(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_646,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[39],lf[47]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(6)));}

/* thread-quantum-set! in k537 in k271 in k268 */
static void C_ccall f_630(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_630,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure_2(t2,lf[39],lf[46]);
t5=(C_word)C_i_check_exact_2(t3,lf[46]);
t6=(C_word)C_i_fixnum_max(t3,C_fix(10));
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_i_set_i_slot(t2,C_fix(9),t6));}

/* thread-quantum in k537 in k271 in k268 */
static void C_ccall f_621(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_621,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[39],lf[45]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(9)));}

/* thread-specific-set! in k537 in k271 in k268 */
static void C_ccall f_612(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_612,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure_2(t2,lf[39],lf[44]);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_i_setslot(t2,C_fix(10),t3));}

/* thread-specific in k537 in k271 in k268 */
static void C_ccall f_603(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_603,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[39],lf[43]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(10)));}

/* thread-state in k537 in k271 in k268 */
static void C_ccall f_594(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_594,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[39],lf[42]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(3)));}

/* current-thread in k537 in k271 in k268 */
static void C_ccall f_591(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_591,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,*((C_word*)lf[36]+1));}

/* thread? in k537 in k271 in k268 */
static void C_ccall f_585(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_585,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[39]));}

/* make-thread in k537 in k271 in k268 */
static void C_ccall f_541(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3r,(void*)f_541r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_541r(t0,t1,t2,t3);}}

static void C_ccall f_541r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(7);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_545,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_570,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(t3))){
t6=t5;
f_570(2,t6,(C_word)C_slot(t3,C_fix(0)));}
else{
/* srfi-18.scm: 172  gensym */
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,lf[39]);}}

/* k568 in make-thread in k537 in k271 in k268 */
static void C_ccall f_570(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(*((C_word*)lf[36]+1),C_fix(9));
/* srfi-18.scm: 169  ##sys#make-thread */
t3=*((C_word*)lf[37]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,((C_word*)t0)[2],C_SCHEME_FALSE,lf[38],t1,t2);}

/* k543 in make-thread in k537 in k271 in k268 */
static void C_ccall f_545(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_545,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_550,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_setslot(t1,C_fix(1),t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t1);}

/* a549 in k543 in make-thread in k537 in k271 in k268 */
static void C_ccall f_550(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_550,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_556,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* srfi-18.scm: 177  ##sys#call-with-values */
C_u_call_with_values(4,0,t1,((C_word*)t0)[2],t2);}

/* a555 in a549 in k543 in make-thread in k537 in k271 in k268 */
static void C_ccall f_556(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_556r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_556r(t0,t1,t2);}}

static void C_ccall f_556r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(3);
t3=(C_word)C_i_setslot(((C_word*)t0)[2],C_fix(2),t2);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_563,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* srfi-18.scm: 181  ##sys#thread-kill! */
t5=*((C_word*)lf[34]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[2],lf[35]);}

/* k561 in a555 in a549 in k543 in make-thread in k537 in k271 in k268 */
static void C_ccall f_563(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-18.scm: 182  ##sys#schedule */
t2=*((C_word*)lf[33]+1);
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* uncaught-exception? in k271 in k268 */
static void C_ccall f_521(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_521,3,t0,t1,t2);}
if(C_truep((C_word)C_i_structurep(t2,lf[22]))){
t3=(C_word)C_slot(t2,C_fix(1));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_u_i_memq(lf[29],t3));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* terminated-thread-exception? in k271 in k268 */
static void C_ccall f_505(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_505,3,t0,t1,t2);}
if(C_truep((C_word)C_i_structurep(t2,lf[22]))){
t3=(C_word)C_slot(t2,C_fix(1));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_u_i_memq(lf[27],t3));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* abandoned-mutex-exception? in k271 in k268 */
static void C_ccall f_489(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_489,3,t0,t1,t2);}
if(C_truep((C_word)C_i_structurep(t2,lf[22]))){
t3=(C_word)C_slot(t2,C_fix(1));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_u_i_memq(lf[25],t3));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* join-timeout-exception? in k271 in k268 */
static void C_ccall f_473(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_473,3,t0,t1,t2);}
if(C_truep((C_word)C_i_structurep(t2,lf[22]))){
t3=(C_word)C_slot(t2,C_fix(1));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_u_i_memq(lf[23],t3));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* time? in k271 in k268 */
static void C_ccall f_465(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_465,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[4]));}

/* milliseconds->time in k271 in k268 */
static void C_ccall f_449(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_449,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[16]);
t4=(C_word)C_a_i_divide(&a,2,t2,C_fix(1000));
t5=(C_word)C_a_i_plus(&a,2,C_flonum(&a,C_startup_time_seconds),t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_record(&a,4,lf[4],t2,t5,C_fix(0)));}

/* seconds->time in k271 in k268 */
static void C_ccall f_395(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_395,3,t0,t1,t2);}
t3=(C_word)C_i_check_number_2(t2,lf[12]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_402,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_a_i_minus(&a,2,t2,C_flonum(&a,C_startup_time_seconds));
/* srfi-18.scm: 124  max */
t6=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,C_fix(0),t5);}

/* k400 in seconds->time in k271 in k268 */
static void C_ccall f_402(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_402,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_405,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_439,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_443,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* srfi-18.scm: 125  ##sys#exact->inexact */
t5=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[2]);}

/* k441 in k400 in seconds->time in k271 in k268 */
static void C_ccall f_443(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-18.scm: 125  ##sys#flonum-fraction */
t2=*((C_word*)lf[13]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k437 in k400 in seconds->time in k271 in k268 */
static void C_ccall f_439(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_439,2,t0,t1);}
t2=(C_word)C_a_i_times(&a,2,C_fix(1000),t1);
/* srfi-18.scm: 125  truncate */
t3=*((C_word*)lf[2]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t2);}

/* k403 in k400 in seconds->time in k271 in k268 */
static void C_ccall f_405(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_405,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_423,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_a_i_times(&a,2,((C_word*)t0)[2],C_fix(1000));
t4=(C_word)C_a_i_plus(&a,2,t3,t1);
/* srfi-18.scm: 126  truncate */
t5=*((C_word*)lf[2]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t2,t4);}

/* k421 in k403 in k400 in seconds->time in k271 in k268 */
static void C_ccall f_423(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_423,2,t0,t1);}
t2=(C_word)C_i_inexact_to_exact(t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_415,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* srfi-18.scm: 127  truncate */
t4=*((C_word*)lf[2]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k413 in k421 in k403 in k400 in seconds->time in k271 in k268 */
static void C_ccall f_415(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_415,2,t0,t1);}
t2=(C_word)C_i_inexact_to_exact(((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[4],((C_word*)t0)[2],t1,t2));}

/* time->milliseconds in k271 in k268 */
static void C_ccall f_366(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_366,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[4],lf[11]);
t4=(C_word)C_slot(t2,C_fix(2));
t5=(C_word)C_a_i_minus(&a,2,t4,C_flonum(&a,C_startup_time_seconds));
t6=(C_word)C_a_i_times(&a,2,t5,C_fix(1000));
t7=(C_word)C_i_inexact_to_exact(t6);
t8=(C_word)C_slot(t2,C_fix(3));
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_a_i_plus(&a,2,t7,t8));}

/* time->seconds in k271 in k268 */
static void C_ccall f_345(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_345,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[4],lf[10]);
t4=(C_word)C_slot(t2,C_fix(2));
t5=(C_word)C_slot(t2,C_fix(3));
t6=(C_word)C_a_i_divide(&a,2,t5,C_fix(1000));
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_plus(&a,2,t4,t6));}

/* current-time in k271 in k268 */
static void C_ccall f_318(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[32],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_318,2,t0,t1);}
t2=C_flonum(&a,C_get_seconds);
t3=C_flonum(&a,C_startup_time_seconds);
t4=C_long_to_num(&a,C_ms);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_330,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_a_i_minus(&a,2,t2,t3);
t7=(C_word)C_a_i_times(&a,2,t6,C_fix(1000));
t8=(C_word)C_a_i_plus(&a,2,t7,C_long_to_num(&a,C_ms));
/* srfi-18.scm: 107  truncate */
t9=*((C_word*)lf[2]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t5,t8);}

/* k328 in current-time in k271 in k268 */
static void C_ccall f_330(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_330,2,t0,t1);}
t2=(C_word)C_i_inexact_to_exact(t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[4],t2,((C_word*)t0)[2],C_long_to_num(&a,C_ms)));}

/* ##sys#compute-time-limit in k271 in k268 */
static void C_fcall f_275(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_275,NULL,3,t0,t1,t2);}
if(C_truep(t2)){
if(C_truep((C_word)C_i_structurep(t2,lf[4]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}
else{
if(C_truep((C_word)C_i_numberp(t2))){
t3=(C_word)C_fudge(C_fix(16));
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_309,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_a_i_times(&a,2,t2,C_fix(1000));
/* srfi-18.scm: 84   truncate */
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}
else{
/* srfi-18.scm: 85   ##sys#signal-hook */
t3=*((C_word*)lf[5]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t1,lf[6],lf[7],t2);}}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k307 in ##sys#compute-time-limit in k271 in k268 */
static void C_ccall f_309(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_inexact_to_exact(t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_u_fixnum_plus(((C_word*)t0)[2],t2));}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[116] = {
{"toplevelsrfi-18.scm",(void*)C_srfi_18_toplevel},
{"f_270srfi-18.scm",(void*)f_270},
{"f_273srfi-18.scm",(void*)f_273},
{"f_539srfi-18.scm",(void*)f_539},
{"f_1633srfi-18.scm",(void*)f_1633},
{"f_1607srfi-18.scm",(void*)f_1607},
{"f_1617srfi-18.scm",(void*)f_1617},
{"f_1620srfi-18.scm",(void*)f_1620},
{"f_1623srfi-18.scm",(void*)f_1623},
{"f_1575srfi-18.scm",(void*)f_1575},
{"f_1577srfi-18.scm",(void*)f_1577},
{"f_1587srfi-18.scm",(void*)f_1587},
{"f_1541srfi-18.scm",(void*)f_1541},
{"f_1565srfi-18.scm",(void*)f_1565},
{"f_1569srfi-18.scm",(void*)f_1569},
{"f_1504srfi-18.scm",(void*)f_1504},
{"f_1516srfi-18.scm",(void*)f_1516},
{"f_1511srfi-18.scm",(void*)f_1511},
{"f_1461srfi-18.scm",(void*)f_1461},
{"f_1452srfi-18.scm",(void*)f_1452},
{"f_1443srfi-18.scm",(void*)f_1443},
{"f_1437srfi-18.scm",(void*)f_1437},
{"f_1418srfi-18.scm",(void*)f_1418},
{"f_1426srfi-18.scm",(void*)f_1426},
{"f_1236srfi-18.scm",(void*)f_1236},
{"f_1254srfi-18.scm",(void*)f_1254},
{"f_1261srfi-18.scm",(void*)f_1261},
{"f_1390srfi-18.scm",(void*)f_1390},
{"f_1372srfi-18.scm",(void*)f_1372},
{"f_1350srfi-18.scm",(void*)f_1350},
{"f_1361srfi-18.scm",(void*)f_1361},
{"f_1276srfi-18.scm",(void*)f_1276},
{"f_1279srfi-18.scm",(void*)f_1279},
{"f_1382srfi-18.scm",(void*)f_1382},
{"f_1024srfi-18.scm",(void*)f_1024},
{"f_1034srfi-18.scm",(void*)f_1034},
{"f_1051srfi-18.scm",(void*)f_1051},
{"f_1099srfi-18.scm",(void*)f_1099},
{"f_1102srfi-18.scm",(void*)f_1102},
{"f_1209srfi-18.scm",(void*)f_1209},
{"f_1161srfi-18.scm",(void*)f_1161},
{"f_1167srfi-18.scm",(void*)f_1167},
{"f_1172srfi-18.scm",(void*)f_1172},
{"f_1194srfi-18.scm",(void*)f_1194},
{"f_1075srfi-18.scm",(void*)f_1075},
{"f_1086srfi-18.scm",(void*)f_1086},
{"f_1054srfi-18.scm",(void*)f_1054},
{"f_1065srfi-18.scm",(void*)f_1065},
{"f_1000srfi-18.scm",(void*)f_1000},
{"f_991srfi-18.scm",(void*)f_991},
{"f_982srfi-18.scm",(void*)f_982},
{"f_973srfi-18.scm",(void*)f_973},
{"f_955srfi-18.scm",(void*)f_955},
{"f_959srfi-18.scm",(void*)f_959},
{"f_949srfi-18.scm",(void*)f_949},
{"f_909srfi-18.scm",(void*)f_909},
{"f_937srfi-18.scm",(void*)f_937},
{"f_944srfi-18.scm",(void*)f_944},
{"f_918srfi-18.scm",(void*)f_918},
{"f_925srfi-18.scm",(void*)f_925},
{"f_930srfi-18.scm",(void*)f_930},
{"f_887srfi-18.scm",(void*)f_887},
{"f_854srfi-18.scm",(void*)f_854},
{"f_872srfi-18.scm",(void*)f_872},
{"f_881srfi-18.scm",(void*)f_881},
{"f_810srfi-18.scm",(void*)f_810},
{"f_852srfi-18.scm",(void*)f_852},
{"f_817srfi-18.scm",(void*)f_817},
{"f_826srfi-18.scm",(void*)f_826},
{"f_691srfi-18.scm",(void*)f_691},
{"f_698srfi-18.scm",(void*)f_698},
{"f_712srfi-18.scm",(void*)f_712},
{"f_716srfi-18.scm",(void*)f_716},
{"f_722srfi-18.scm",(void*)f_722},
{"f_727srfi-18.scm",(void*)f_727},
{"f_776srfi-18.scm",(void*)f_776},
{"f_757srfi-18.scm",(void*)f_757},
{"f_655srfi-18.scm",(void*)f_655},
{"f_685srfi-18.scm",(void*)f_685},
{"f_659srfi-18.scm",(void*)f_659},
{"f_662srfi-18.scm",(void*)f_662},
{"f_668srfi-18.scm",(void*)f_668},
{"f_646srfi-18.scm",(void*)f_646},
{"f_630srfi-18.scm",(void*)f_630},
{"f_621srfi-18.scm",(void*)f_621},
{"f_612srfi-18.scm",(void*)f_612},
{"f_603srfi-18.scm",(void*)f_603},
{"f_594srfi-18.scm",(void*)f_594},
{"f_591srfi-18.scm",(void*)f_591},
{"f_585srfi-18.scm",(void*)f_585},
{"f_541srfi-18.scm",(void*)f_541},
{"f_570srfi-18.scm",(void*)f_570},
{"f_545srfi-18.scm",(void*)f_545},
{"f_550srfi-18.scm",(void*)f_550},
{"f_556srfi-18.scm",(void*)f_556},
{"f_563srfi-18.scm",(void*)f_563},
{"f_521srfi-18.scm",(void*)f_521},
{"f_505srfi-18.scm",(void*)f_505},
{"f_489srfi-18.scm",(void*)f_489},
{"f_473srfi-18.scm",(void*)f_473},
{"f_465srfi-18.scm",(void*)f_465},
{"f_449srfi-18.scm",(void*)f_449},
{"f_395srfi-18.scm",(void*)f_395},
{"f_402srfi-18.scm",(void*)f_402},
{"f_443srfi-18.scm",(void*)f_443},
{"f_439srfi-18.scm",(void*)f_439},
{"f_405srfi-18.scm",(void*)f_405},
{"f_423srfi-18.scm",(void*)f_423},
{"f_415srfi-18.scm",(void*)f_415},
{"f_366srfi-18.scm",(void*)f_366},
{"f_345srfi-18.scm",(void*)f_345},
{"f_318srfi-18.scm",(void*)f_318},
{"f_330srfi-18.scm",(void*)f_330},
{"f_275srfi-18.scm",(void*)f_275},
{"f_309srfi-18.scm",(void*)f_309},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
