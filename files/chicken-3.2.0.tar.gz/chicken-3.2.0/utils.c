/* Generated from utils.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-04-30 11:17
   Version 3.1.10 - linux-unix-gnu-x86	[ manyargs dload ptables applyhook ]
   SVN rev. 10602	compiled 2008-04-30 on galinha (Linux)
   command line: utils.scm -quiet -no-trace -optimize-level 2 -include-path . -explicit-use -output-file utils.c
   unit: utils
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_regex_toplevel)
C_externimport void C_ccall C_regex_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[143];
static double C_possibly_force_alignment;
static C_char C_TLS li0[] C_aligned={C_lihdr(0,0,14),40,109,97,107,112,97,116,32,112,97,116,116,52,41,0,0};
static C_char C_TLS li1[] C_aligned={C_lihdr(0,0,11),40,97,54,52,56,32,115,121,109,57,41,0,0,0,0,0};
static C_char C_TLS li2[] C_aligned={C_lihdr(0,0,35),40,35,35,115,121,115,35,97,112,114,111,112,111,115,45,105,110,116,101,114,110,101,100,32,112,97,116,116,55,32,101,110,118,56,41,0,0,0,0,0};
static C_char C_TLS li3[] C_aligned={C_lihdr(0,0,18),40,97,54,55,52,32,107,101,121,49,52,32,118,97,108,49,53,41,0,0,0,0,0,0};
static C_char C_TLS li4[] C_aligned={C_lihdr(0,0,35),40,35,35,115,121,115,35,97,112,114,111,112,111,115,45,109,97,99,114,111,115,32,112,97,116,116,49,49,32,101,110,118,49,50,41,0,0,0,0,0};
static C_char C_TLS li5[] C_aligned={C_lihdr(0,0,36),40,35,35,115,121,115,35,97,112,114,111,112,111,115,32,112,97,116,116,50,48,32,101,110,118,50,49,32,46,32,103,49,57,50,50,41,0,0,0,0};
static C_char C_TLS li6[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li7[] C_aligned={C_lihdr(0,0,35),40,37,97,112,114,111,112,111,115,45,108,105,115,116,32,108,111,99,51,49,32,112,97,116,116,51,50,32,97,114,103,115,51,51,41,0,0,0,0,0};
static C_char C_TLS li8[] C_aligned={C_lihdr(0,0,14),40,115,121,109,108,101,110,32,115,121,109,53,50,41,0,0};
static C_char C_TLS li9[] C_aligned={C_lihdr(0,0,30),40,97,112,114,111,112,111,115,45,108,105,115,116,32,112,97,116,116,53,52,32,46,32,114,101,115,116,53,53,41,0,0};
static C_char C_TLS li10[] C_aligned={C_lihdr(0,0,10),40,100,111,54,50,32,105,54,52,41,0,0,0,0,0,0};
static C_char C_TLS li11[] C_aligned={C_lihdr(0,0,12),40,97,56,55,54,32,115,121,109,54,49,41,0,0,0,0};
static C_char C_TLS li12[] C_aligned={C_lihdr(0,0,12),40,97,57,52,53,32,115,121,109,54,48,41,0,0,0,0};
static C_char C_TLS li13[] C_aligned={C_lihdr(0,0,25),40,97,112,114,111,112,111,115,32,112,97,116,116,53,54,32,46,32,114,101,115,116,53,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li14[] C_aligned={C_lihdr(0,0,25),40,115,121,115,116,101,109,42,32,102,115,116,114,55,56,32,46,32,97,114,103,115,55,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li15[] C_aligned={C_lihdr(0,0,21),40,100,101,108,101,116,101,45,102,105,108,101,42,32,102,105,108,101,56,52,41,0,0,0};
static C_char C_TLS li16[] C_aligned={C_lihdr(0,0,7),40,97,49,48,55,56,41,0};
static C_char C_TLS li17[] C_aligned={C_lihdr(0,0,15),40,97,49,48,55,50,32,103,49,51,49,49,51,54,41,0};
static C_char C_TLS li18[] C_aligned={C_lihdr(0,0,7),40,97,49,49,49,51,41,0};
static C_char C_TLS li19[] C_aligned={C_lihdr(0,0,7),40,97,49,49,50,53,41,0};
static C_char C_TLS li20[] C_aligned={C_lihdr(0,0,17),40,97,49,49,49,57,32,46,32,103,49,51,52,49,52,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li21[] C_aligned={C_lihdr(0,0,7),40,97,49,49,48,55,41,0};
static C_char C_TLS li22[] C_aligned={C_lihdr(0,0,15),40,97,49,48,54,54,32,103,49,51,51,49,51,53,41,0};
static C_char C_TLS li23[] C_aligned={C_lihdr(0,0,16),40,108,111,111,112,32,100,49,50,55,32,108,49,50,56,41};
static C_char C_TLS li24[] C_aligned={C_lihdr(0,0,7),40,97,49,49,52,54,41,0};
static C_char C_TLS li25[] C_aligned={C_lihdr(0,0,15),40,97,49,49,52,48,32,103,49,49,54,49,50,49,41,0};
static C_char C_TLS li26[] C_aligned={C_lihdr(0,0,7),40,97,49,49,55,49,41,0};
static C_char C_TLS li27[] C_aligned={C_lihdr(0,0,7),40,97,49,49,56,51,41,0};
static C_char C_TLS li28[] C_aligned={C_lihdr(0,0,17),40,97,49,49,55,55,32,46,32,103,49,49,57,49,50,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li29[] C_aligned={C_lihdr(0,0,7),40,97,49,49,54,53,41,0};
static C_char C_TLS li30[] C_aligned={C_lihdr(0,0,15),40,97,49,49,51,52,32,103,49,49,56,49,50,48,41,0};
static C_char C_TLS li31[] C_aligned={C_lihdr(0,0,7),40,97,49,50,48,52,41,0};
static C_char C_TLS li32[] C_aligned={C_lihdr(0,0,15),40,97,49,49,57,56,32,103,49,48,54,49,49,49,41,0};
static C_char C_TLS li33[] C_aligned={C_lihdr(0,0,7),40,97,49,50,50,57,41,0};
static C_char C_TLS li34[] C_aligned={C_lihdr(0,0,7),40,97,49,50,52,49,41,0};
static C_char C_TLS li35[] C_aligned={C_lihdr(0,0,17),40,97,49,50,51,53,32,46,32,103,49,48,57,49,49,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li36[] C_aligned={C_lihdr(0,0,7),40,97,49,50,50,51,41,0};
static C_char C_TLS li37[] C_aligned={C_lihdr(0,0,15),40,97,49,49,57,50,32,103,49,48,56,49,49,48,41,0};
static C_char C_TLS li38[] C_aligned={C_lihdr(0,0,30),40,98,111,100,121,57,49,32,99,108,111,98,98,101,114,57,55,32,98,108,111,99,107,115,105,122,101,57,56,41,0,0};
static C_char C_TLS li39[] C_aligned={C_lihdr(0,0,31),40,100,101,102,45,98,108,111,99,107,115,105,122,101,57,52,32,37,99,108,111,98,98,101,114,56,57,49,53,49,41,0};
static C_char C_TLS li40[] C_aligned={C_lihdr(0,0,15),40,100,101,102,45,99,108,111,98,98,101,114,57,51,41,0};
static C_char C_TLS li41[] C_aligned={C_lihdr(0,0,40),40,102,105,108,101,45,99,111,112,121,32,111,114,105,103,102,105,108,101,56,54,32,110,101,119,102,105,108,101,56,55,32,46,32,103,56,53,56,56,41};
static C_char C_TLS li42[] C_aligned={C_lihdr(0,0,7),40,97,49,52,49,52,41,0};
static C_char C_TLS li43[] C_aligned={C_lihdr(0,0,15),40,97,49,52,48,56,32,103,50,48,49,50,48,54,41,0};
static C_char C_TLS li44[] C_aligned={C_lihdr(0,0,7),40,97,49,52,51,57,41,0};
static C_char C_TLS li45[] C_aligned={C_lihdr(0,0,7),40,97,49,52,53,49,41,0};
static C_char C_TLS li46[] C_aligned={C_lihdr(0,0,17),40,97,49,52,52,53,32,46,32,103,50,48,52,50,48,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li47[] C_aligned={C_lihdr(0,0,7),40,97,49,52,51,51,41,0};
static C_char C_TLS li48[] C_aligned={C_lihdr(0,0,15),40,97,49,52,48,50,32,103,50,48,51,50,48,53,41,0};
static C_char C_TLS li49[] C_aligned={C_lihdr(0,0,7),40,97,49,52,56,54,41,0};
static C_char C_TLS li50[] C_aligned={C_lihdr(0,0,15),40,97,49,52,56,48,32,103,50,49,51,50,49,56,41,0};
static C_char C_TLS li51[] C_aligned={C_lihdr(0,0,7),40,97,49,53,50,49,41,0};
static C_char C_TLS li52[] C_aligned={C_lihdr(0,0,7),40,97,49,53,51,51,41,0};
static C_char C_TLS li53[] C_aligned={C_lihdr(0,0,17),40,97,49,53,50,55,32,46,32,103,50,49,54,50,50,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li54[] C_aligned={C_lihdr(0,0,7),40,97,49,53,49,53,41,0};
static C_char C_TLS li55[] C_aligned={C_lihdr(0,0,15),40,97,49,52,55,52,32,103,50,49,53,50,49,55,41,0};
static C_char C_TLS li56[] C_aligned={C_lihdr(0,0,16),40,108,111,111,112,32,100,49,57,57,32,108,50,48,48,41};
static C_char C_TLS li57[] C_aligned={C_lihdr(0,0,7),40,97,49,53,53,52,41,0};
static C_char C_TLS li58[] C_aligned={C_lihdr(0,0,15),40,97,49,53,52,56,32,103,49,56,56,49,57,51,41,0};
static C_char C_TLS li59[] C_aligned={C_lihdr(0,0,7),40,97,49,53,55,57,41,0};
static C_char C_TLS li60[] C_aligned={C_lihdr(0,0,7),40,97,49,53,57,49,41,0};
static C_char C_TLS li61[] C_aligned={C_lihdr(0,0,17),40,97,49,53,56,53,32,46,32,103,49,57,49,49,57,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li62[] C_aligned={C_lihdr(0,0,7),40,97,49,53,55,51,41,0};
static C_char C_TLS li63[] C_aligned={C_lihdr(0,0,15),40,97,49,53,52,50,32,103,49,57,48,49,57,50,41,0};
static C_char C_TLS li64[] C_aligned={C_lihdr(0,0,7),40,97,49,54,49,50,41,0};
static C_char C_TLS li65[] C_aligned={C_lihdr(0,0,15),40,97,49,54,48,54,32,103,49,55,56,49,56,51,41,0};
static C_char C_TLS li66[] C_aligned={C_lihdr(0,0,7),40,97,49,54,51,55,41,0};
static C_char C_TLS li67[] C_aligned={C_lihdr(0,0,7),40,97,49,54,52,57,41,0};
static C_char C_TLS li68[] C_aligned={C_lihdr(0,0,17),40,97,49,54,52,51,32,46,32,103,49,56,49,49,56,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li69[] C_aligned={C_lihdr(0,0,7),40,97,49,54,51,49,41,0};
static C_char C_TLS li70[] C_aligned={C_lihdr(0,0,15),40,97,49,54,48,48,32,103,49,56,48,49,56,50,41,0};
static C_char C_TLS li71[] C_aligned={C_lihdr(0,0,33),40,98,111,100,121,49,54,51,32,99,108,111,98,98,101,114,49,54,57,32,98,108,111,99,107,115,105,122,101,49,55,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li72[] C_aligned={C_lihdr(0,0,33),40,100,101,102,45,98,108,111,99,107,115,105,122,101,49,54,54,32,37,99,108,111,98,98,101,114,49,54,49,50,51,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li73[] C_aligned={C_lihdr(0,0,16),40,100,101,102,45,99,108,111,98,98,101,114,49,54,53,41};
static C_char C_TLS li74[] C_aligned={C_lihdr(0,0,44),40,102,105,108,101,45,109,111,118,101,32,111,114,105,103,102,105,108,101,49,53,56,32,110,101,119,102,105,108,101,49,53,57,32,46,32,103,49,53,55,49,54,48,41,0,0,0,0};
static C_char C_TLS li75[] C_aligned={C_lihdr(0,0,26),40,97,98,115,111,108,117,116,101,45,112,97,116,104,110,97,109,101,63,32,112,110,50,52,53,41,0,0,0,0,0,0};
static C_char C_TLS li76[] C_aligned={C_lihdr(0,0,24),40,99,104,111,112,45,112,100,115,32,115,116,114,50,52,55,32,112,100,115,50,52,56,41};
static C_char C_TLS li77[] C_aligned={C_lihdr(0,0,14),40,108,111,111,112,32,115,116,114,115,50,54,48,41,0,0};
static C_char C_TLS li78[] C_aligned={C_lihdr(0,0,26),40,99,111,110,99,45,100,105,114,115,32,100,105,114,115,50,53,55,32,112,100,115,50,53,56,41,0,0,0,0,0,0};
static C_char C_TLS li79[] C_aligned={C_lihdr(0,0,34),40,99,97,110,111,110,105,99,97,108,105,122,101,45,100,105,114,115,32,100,105,114,115,50,54,54,32,112,100,115,50,54,55,41,0,0,0,0,0,0};
static C_char C_TLS li80[] C_aligned={C_lihdr(0,0,52),40,95,109,97,107,101,45,112,97,116,104,110,97,109,101,32,108,111,99,50,55,48,32,100,105,114,50,55,49,32,102,105,108,101,50,55,50,32,101,120,116,50,55,51,32,112,100,115,50,55,52,41,0,0,0,0};
static C_char C_TLS li81[] C_aligned={C_lihdr(0,0,23),40,98,111,100,121,50,57,50,32,101,120,116,50,57,56,32,112,100,115,50,57,57,41,0};
static C_char C_TLS li82[] C_aligned={C_lihdr(0,0,23),40,100,101,102,45,112,100,115,50,57,53,32,37,101,120,116,50,57,48,51,48,49,41,0};
static C_char C_TLS li83[] C_aligned={C_lihdr(0,0,12),40,100,101,102,45,101,120,116,50,57,52,41,0,0,0,0};
static C_char C_TLS li84[] C_aligned={C_lihdr(0,0,41),40,109,97,107,101,45,112,97,116,104,110,97,109,101,32,100,105,114,115,50,56,55,32,102,105,108,101,50,56,56,32,46,32,103,50,56,54,50,56,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li85[] C_aligned={C_lihdr(0,0,23),40,98,111,100,121,51,49,51,32,101,120,116,51,49,57,32,112,100,115,51,50,48,41,0};
static C_char C_TLS li86[] C_aligned={C_lihdr(0,0,23),40,100,101,102,45,112,100,115,51,49,54,32,37,101,120,116,51,49,49,51,50,53,41,0};
static C_char C_TLS li87[] C_aligned={C_lihdr(0,0,12),40,100,101,102,45,101,120,116,51,49,53,41,0,0,0,0};
static C_char C_TLS li88[] C_aligned={C_lihdr(0,0,50),40,109,97,107,101,45,97,98,115,111,108,117,116,101,45,112,97,116,104,110,97,109,101,32,100,105,114,115,51,48,56,32,102,105,108,101,51,48,57,32,46,32,103,51,48,55,51,49,48,41,0,0,0,0,0,0};
static C_char C_TLS li89[] C_aligned={C_lihdr(0,0,18),40,115,116,114,105,112,45,112,100,115,32,100,105,114,51,52,51,41,0,0,0,0,0,0};
static C_char C_TLS li90[] C_aligned={C_lihdr(0,0,26),40,100,101,99,111,109,112,111,115,101,45,112,97,116,104,110,97,109,101,32,112,110,51,52,52,41,0,0,0,0,0,0};
static C_char C_TLS li91[] C_aligned={C_lihdr(0,0,7),40,97,50,50,54,56,41,0};
static C_char C_TLS li92[] C_aligned={C_lihdr(0,0,38),40,97,50,50,55,52,32,100,105,114,51,53,48,51,53,51,32,102,105,108,101,51,53,49,51,53,52,32,101,120,116,51,53,50,51,53,53,41,0,0};
static C_char C_TLS li93[] C_aligned={C_lihdr(0,0,26),40,112,97,116,104,110,97,109,101,45,100,105,114,101,99,116,111,114,121,32,112,110,51,52,57,41,0,0,0,0,0,0};
static C_char C_TLS li94[] C_aligned={C_lihdr(0,0,7),40,97,50,50,56,51,41,0};
static C_char C_TLS li95[] C_aligned={C_lihdr(0,0,38),40,97,50,50,56,57,32,100,105,114,51,54,48,51,54,51,32,102,105,108,101,51,54,49,51,54,52,32,101,120,116,51,54,50,51,54,53,41,0,0};
static C_char C_TLS li96[] C_aligned={C_lihdr(0,0,21),40,112,97,116,104,110,97,109,101,45,102,105,108,101,32,112,110,51,53,57,41,0,0,0};
static C_char C_TLS li97[] C_aligned={C_lihdr(0,0,7),40,97,50,50,57,56,41,0};
static C_char C_TLS li98[] C_aligned={C_lihdr(0,0,38),40,97,50,51,48,52,32,100,105,114,51,55,48,51,55,51,32,102,105,108,101,51,55,49,51,55,52,32,101,120,116,51,55,50,51,55,53,41,0,0};
static C_char C_TLS li99[] C_aligned={C_lihdr(0,0,26),40,112,97,116,104,110,97,109,101,45,101,120,116,101,110,115,105,111,110,32,112,110,51,54,57,41,0,0,0,0,0,0};
static C_char C_TLS li100[] C_aligned={C_lihdr(0,0,7),40,97,50,51,49,51,41,0};
static C_char C_TLS li101[] C_aligned={C_lihdr(0,0,38),40,97,50,51,49,57,32,100,105,114,51,56,48,51,56,51,32,102,105,108,101,51,56,49,51,56,52,32,101,120,116,51,56,50,51,56,53,41,0,0};
static C_char C_TLS li102[] C_aligned={C_lihdr(0,0,32),40,112,97,116,104,110,97,109,101,45,115,116,114,105,112,45,100,105,114,101,99,116,111,114,121,32,112,110,51,55,57,41};
static C_char C_TLS li103[] C_aligned={C_lihdr(0,0,7),40,97,50,51,51,49,41,0};
static C_char C_TLS li104[] C_aligned={C_lihdr(0,0,38),40,97,50,51,51,55,32,100,105,114,51,57,48,51,57,51,32,102,105,108,101,51,57,49,51,57,52,32,101,120,116,51,57,50,51,57,53,41,0,0};
static C_char C_TLS li105[] C_aligned={C_lihdr(0,0,32),40,112,97,116,104,110,97,109,101,45,115,116,114,105,112,45,101,120,116,101,110,115,105,111,110,32,112,110,51,56,57,41};
static C_char C_TLS li106[] C_aligned={C_lihdr(0,0,7),40,97,50,51,52,57,41,0};
static C_char C_TLS li107[] C_aligned={C_lihdr(0,0,36),40,97,50,51,53,53,32,95,52,48,49,52,48,52,32,102,105,108,101,52,48,50,52,48,53,32,101,120,116,52,48,51,52,48,54,41,0,0,0,0};
static C_char C_TLS li108[] C_aligned={C_lihdr(0,0,41),40,112,97,116,104,110,97,109,101,45,114,101,112,108,97,99,101,45,100,105,114,101,99,116,111,114,121,32,112,110,51,57,57,32,100,105,114,52,48,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li109[] C_aligned={C_lihdr(0,0,7),40,97,50,51,54,55,41,0};
static C_char C_TLS li110[] C_aligned={C_lihdr(0,0,35),40,97,50,51,55,51,32,100,105,114,52,49,50,52,49,53,32,95,52,49,51,52,49,54,32,101,120,116,52,49,52,52,49,55,41,0,0,0,0,0};
static C_char C_TLS li111[] C_aligned={C_lihdr(0,0,37),40,112,97,116,104,110,97,109,101,45,114,101,112,108,97,99,101,45,102,105,108,101,32,112,110,52,49,48,32,102,105,108,101,52,49,49,41,0,0,0};
static C_char C_TLS li112[] C_aligned={C_lihdr(0,0,7),40,97,50,51,56,53,41,0};
static C_char C_TLS li113[] C_aligned={C_lihdr(0,0,36),40,97,50,51,57,49,32,100,105,114,52,50,51,52,50,54,32,102,105,108,101,52,50,52,52,50,55,32,95,52,50,53,52,50,56,41,0,0,0,0};
static C_char C_TLS li114[] C_aligned={C_lihdr(0,0,41),40,112,97,116,104,110,97,109,101,45,114,101,112,108,97,99,101,45,101,120,116,101,110,115,105,111,110,32,112,110,52,50,49,32,101,120,116,52,50,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li115[] C_aligned={C_lihdr(0,0,12),40,97,50,52,51,54,32,112,52,53,51,41,0,0,0,0};
static C_char C_TLS li116[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li117[] C_aligned={C_lihdr(0,0,32),40,99,114,101,97,116,101,45,116,101,109,112,111,114,97,114,121,45,102,105,108,101,32,46,32,101,120,116,52,52,51,41};
static C_char C_TLS li118[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li119[] C_aligned={C_lihdr(0,0,24),40,100,105,114,101,99,116,111,114,121,45,110,117,108,108,63,32,100,105,114,52,53,54,41};
static C_char C_TLS li120[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li121[] C_aligned={C_lihdr(0,0,33),40,102,111,114,45,101,97,99,104,45,108,105,110,101,32,112,114,111,99,52,54,52,32,46,32,112,111,114,116,52,54,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li122[] C_aligned={C_lihdr(0,0,7),40,97,50,53,54,49,41,0};
static C_char C_TLS li123[] C_aligned={C_lihdr(0,0,14),40,97,50,53,56,50,32,97,114,103,52,55,55,41,0,0};
static C_char C_TLS li124[] C_aligned={C_lihdr(0,0,29),40,102,111,114,45,101,97,99,104,45,97,114,103,118,45,108,105,110,101,32,116,104,117,110,107,52,55,50,41,0,0,0};
static C_char C_TLS li125[] C_aligned={C_lihdr(0,0,7),40,97,50,54,48,54,41,0};
static C_char C_TLS li126[] C_aligned={C_lihdr(0,0,20),40,114,101,97,100,45,97,108,108,32,46,32,102,105,108,101,52,55,57,41,0,0,0,0};
static C_char C_TLS li127[] C_aligned={C_lihdr(0,0,25),40,115,104,105,102,116,33,32,108,115,116,52,56,52,32,46,32,103,52,56,51,52,56,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li128[] C_aligned={C_lihdr(0,0,22),40,117,110,115,104,105,102,116,33,32,120,52,57,53,32,108,115,116,52,57,54,41,0,0};
static C_char C_TLS li129[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li130[] C_aligned={C_lihdr(0,0,30),40,112,111,114,116,45,102,111,114,45,101,97,99,104,32,102,110,53,48,48,32,116,104,117,110,107,53,48,49,41,0,0};
static C_char C_TLS li131[] C_aligned={C_lihdr(0,0,12),40,108,111,111,112,32,120,115,53,49,48,41,0,0,0,0};
static C_char C_TLS li132[] C_aligned={C_lihdr(0,0,25),40,112,111,114,116,45,109,97,112,32,102,110,53,48,55,32,116,104,117,110,107,53,48,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li133[] C_aligned={C_lihdr(0,0,13),40,108,111,111,112,32,97,99,99,53,49,55,41,0,0,0};
static C_char C_TLS li134[] C_aligned={C_lihdr(0,0,33),40,112,111,114,116,45,102,111,108,100,32,102,110,53,49,51,32,97,99,99,53,49,52,32,116,104,117,110,107,53,49,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li135[] C_aligned={C_lihdr(0,0,15),40,97,50,56,48,53,32,103,53,50,50,53,50,51,41,0};
static C_char C_TLS li136[] C_aligned={C_lihdr(0,0,12),40,97,50,55,57,57,32,115,53,50,49,41,0,0,0,0};
static C_char C_TLS li137[] C_aligned={C_lihdr(0,0,7),40,97,50,56,49,49,41,0};
static C_char C_TLS li138[] C_aligned={C_lihdr(0,0,32),40,109,97,107,101,45,98,114,111,97,100,99,97,115,116,45,112,111,114,116,32,46,32,112,111,114,116,115,53,50,48,41};
static C_char C_TLS li139[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li140[] C_aligned={C_lihdr(0,0,7),40,97,50,56,50,54,41,0};
static C_char C_TLS li141[] C_aligned={C_lihdr(0,0,7),40,97,50,56,54,49,41,0};
static C_char C_TLS li142[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li143[] C_aligned={C_lihdr(0,0,7),40,97,50,56,56,49,41,0};
static C_char C_TLS li144[] C_aligned={C_lihdr(0,0,16),40,108,111,111,112,32,110,53,52,48,32,99,53,52,49,41};
static C_char C_TLS li145[] C_aligned={C_lihdr(0,0,34),40,97,50,57,49,54,32,112,53,51,53,32,110,53,51,54,32,100,101,115,116,53,51,55,32,115,116,97,114,116,53,51,56,41,0,0,0,0,0,0};
static C_char C_TLS li146[] C_aligned={C_lihdr(0,0,41),40,109,97,107,101,45,99,111,110,99,97,116,101,110,97,116,101,100,45,112,111,114,116,32,112,49,53,50,52,32,46,32,112,111,114,116,115,53,50,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li147[] C_aligned={C_lihdr(0,0,10),40,116,111,112,108,101,118,101,108,41,0,0,0,0,0,0};


C_noret_decl(C_utils_toplevel)
C_externexport void C_ccall C_utils_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_594)
static void C_ccall f_594(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_597)
static void C_ccall f_597(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_600)
static void C_ccall f_600(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_603)
static void C_ccall f_603(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2972)
static void C_ccall f_2972(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1750)
static void C_ccall f_1750(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1753)
static void C_ccall f_1753(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2137)
static void C_ccall f_2137(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2140)
static void C_ccall f_2140(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2818)
static void C_ccall f_2818(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2818)
static void C_ccall f_2818r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2917)
static void C_ccall f_2917(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_2923)
static void C_fcall f_2923(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2939)
static void C_ccall f_2939(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2942)
static void C_fcall f_2942(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2882)
static void C_ccall f_2882(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2888)
static void C_fcall f_2888(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2898)
static void C_ccall f_2898(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2862)
static void C_ccall f_2862(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2827)
static void C_ccall f_2827(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2833)
static void C_fcall f_2833(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2843)
static void C_ccall f_2843(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2794)
static void C_ccall f_2794(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2794)
static void C_ccall f_2794r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2812)
static void C_ccall f_2812(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2800)
static void C_ccall f_2800(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2806)
static void C_ccall f_2806(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2769)
static void C_ccall f_2769(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2775)
static void C_fcall f_2775(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2779)
static void C_ccall f_2779(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2792)
static void C_ccall f_2792(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2737)
static void C_ccall f_2737(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2743)
static void C_fcall f_2743(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2747)
static void C_ccall f_2747(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2767)
static void C_ccall f_2767(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2713)
static void C_ccall f_2713(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2719)
static void C_fcall f_2719(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2723)
static void C_ccall f_2723(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2732)
static void C_ccall f_2732(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2689)
static void C_ccall f_2689(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2632)
static void C_ccall f_2632(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2632)
static void C_ccall f_2632r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2636)
static void C_ccall f_2636(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2589)
static void C_ccall f_2589(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2589)
static void C_ccall f_2589r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2593)
static void C_ccall f_2593(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2599)
static void C_ccall f_2599(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2607)
static void C_ccall f_2607(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2544)
static void C_ccall f_2544(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2569)
static void C_ccall f_2569(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2583)
static void C_ccall f_2583(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2562)
static void C_ccall f_2562(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2508)
static void C_ccall f_2508(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2508)
static void C_ccall f_2508r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2515)
static void C_ccall f_2515(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2520)
static void C_fcall f_2520(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2524)
static void C_ccall f_2524(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2533)
static void C_ccall f_2533(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2463)
static void C_ccall f_2463(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2471)
static void C_ccall f_2471(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2473)
static C_word C_fcall f_2473(C_word t0);
C_noret_decl(f_2398)
static void C_ccall f_2398(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2398)
static void C_ccall f_2398r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2402)
static void C_ccall f_2402(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2455)
static void C_ccall f_2455(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2405)
static void C_ccall f_2405(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2416)
static void C_fcall f_2416(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2446)
static void C_ccall f_2446(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2442)
static void C_ccall f_2442(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2423)
static void C_ccall f_2423(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2429)
static void C_ccall f_2429(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2437)
static void C_ccall f_2437(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2380)
static void C_ccall f_2380(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2392)
static void C_ccall f_2392(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2386)
static void C_ccall f_2386(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2362)
static void C_ccall f_2362(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2374)
static void C_ccall f_2374(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2368)
static void C_ccall f_2368(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2344)
static void C_ccall f_2344(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2356)
static void C_ccall f_2356(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2350)
static void C_ccall f_2350(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2326)
static void C_ccall f_2326(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2338)
static void C_ccall f_2338(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2332)
static void C_ccall f_2332(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2308)
static void C_ccall f_2308(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2320)
static void C_ccall f_2320(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2314)
static void C_ccall f_2314(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2293)
static void C_ccall f_2293(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2305)
static void C_ccall f_2305(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2299)
static void C_ccall f_2299(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2278)
static void C_ccall f_2278(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2290)
static void C_ccall f_2290(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2284)
static void C_ccall f_2284(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2263)
static void C_ccall f_2263(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2275)
static void C_ccall f_2275(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2269)
static void C_ccall f_2269(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2155)
static void C_ccall f_2155(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2171)
static void C_ccall f_2171(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2200)
static void C_ccall f_2200(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2225)
static void C_ccall f_2225(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2210)
static void C_ccall f_2210(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2181)
static void C_ccall f_2181(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2141)
static void C_fcall f_2141(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2058)
static void C_ccall f_2058(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2058)
static void C_ccall f_2058r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2087)
static void C_fcall f_2087(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2082)
static void C_fcall f_2082(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2060)
static void C_fcall f_2060(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2068)
static void C_ccall f_2068(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2074)
static void C_ccall f_2074(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2071)
static void C_ccall f_2071(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1994)
static void C_ccall f_1994(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1994)
static void C_ccall f_1994r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2010)
static void C_fcall f_2010(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2005)
static void C_fcall f_2005(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1996)
static void C_fcall f_1996(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2004)
static void C_ccall f_2004(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1913)
static void C_fcall f_1913(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_1942)
static void C_ccall f_1942(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1949)
static void C_fcall f_1949(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1882)
static void C_fcall f_1882(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1821)
static void C_fcall f_1821(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1830)
static void C_fcall f_1830(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1860)
static void C_ccall f_1860(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1868)
static void C_ccall f_1868(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1767)
static void C_fcall f_1767(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1783)
static void C_fcall f_1783(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1754)
static void C_ccall f_1754(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1765)
static void C_ccall f_1765(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1337)
static void C_ccall f_1337(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1337)
static void C_ccall f_1337r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1697)
static void C_fcall f_1697(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1692)
static void C_fcall f_1692(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1339)
static void C_fcall f_1339(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1352)
static void C_fcall f_1352(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1685)
static void C_ccall f_1685(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1681)
static void C_ccall f_1681(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1355)
static void C_ccall f_1355(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1358)
static void C_ccall f_1358(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1674)
static void C_ccall f_1674(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1361)
static void C_ccall f_1361(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1657)
static void C_ccall f_1657(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1667)
static void C_ccall f_1667(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1364)
static void C_ccall f_1364(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1601)
static void C_ccall f_1601(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1632)
static void C_ccall f_1632(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1644)
static void C_ccall f_1644(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1644)
static void C_ccall f_1644r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1650)
static void C_ccall f_1650(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1638)
static void C_ccall f_1638(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1607)
static void C_ccall f_1607(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1613)
static void C_ccall f_1613(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1624)
static void C_ccall f_1624(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1599)
static void C_ccall f_1599(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1367)
static void C_ccall f_1367(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1543)
static void C_ccall f_1543(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1574)
static void C_ccall f_1574(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1586)
static void C_ccall f_1586(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1586)
static void C_ccall f_1586r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1592)
static void C_ccall f_1592(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1580)
static void C_ccall f_1580(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1549)
static void C_ccall f_1549(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1555)
static void C_ccall f_1555(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1566)
static void C_ccall f_1566(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1541)
static void C_ccall f_1541(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1370)
static void C_ccall f_1370(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1373)
static void C_ccall f_1373(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1380)
static void C_ccall f_1380(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1382)
static void C_fcall f_1382(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1475)
static void C_ccall f_1475(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1516)
static void C_ccall f_1516(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1528)
static void C_ccall f_1528(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1528)
static void C_ccall f_1528r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1534)
static void C_ccall f_1534(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1522)
static void C_ccall f_1522(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1481)
static void C_ccall f_1481(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1487)
static void C_ccall f_1487(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1494)
static void C_ccall f_1494(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1497)
static void C_ccall f_1497(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1508)
static void C_ccall f_1508(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1504)
static void C_ccall f_1504(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1473)
static void C_ccall f_1473(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1459)
static void C_ccall f_1459(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1466)
static void C_ccall f_1466(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1392)
static void C_ccall f_1392(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1395)
static void C_ccall f_1395(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1403)
static void C_ccall f_1403(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1434)
static void C_ccall f_1434(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1446)
static void C_ccall f_1446(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1446)
static void C_ccall f_1446r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1452)
static void C_ccall f_1452(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1440)
static void C_ccall f_1440(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1409)
static void C_ccall f_1409(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1415)
static void C_ccall f_1415(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1426)
static void C_ccall f_1426(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1401)
static void C_ccall f_1401(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1398)
static void C_ccall f_1398(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_990)
static void C_ccall f_990(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_990)
static void C_ccall f_990r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1289)
static void C_fcall f_1289(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1284)
static void C_fcall f_1284(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_992)
static void C_fcall f_992(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1005)
static void C_fcall f_1005(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1277)
static void C_ccall f_1277(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1273)
static void C_ccall f_1273(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1008)
static void C_ccall f_1008(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1011)
static void C_ccall f_1011(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1266)
static void C_ccall f_1266(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1014)
static void C_ccall f_1014(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1249)
static void C_ccall f_1249(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1259)
static void C_ccall f_1259(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1017)
static void C_ccall f_1017(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1193)
static void C_ccall f_1193(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1224)
static void C_ccall f_1224(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1236)
static void C_ccall f_1236(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1236)
static void C_ccall f_1236r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1242)
static void C_ccall f_1242(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1230)
static void C_ccall f_1230(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1199)
static void C_ccall f_1199(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1205)
static void C_ccall f_1205(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1216)
static void C_ccall f_1216(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1191)
static void C_ccall f_1191(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1020)
static void C_ccall f_1020(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1135)
static void C_ccall f_1135(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1166)
static void C_ccall f_1166(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1178)
static void C_ccall f_1178(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1178)
static void C_ccall f_1178r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1184)
static void C_ccall f_1184(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1172)
static void C_ccall f_1172(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1141)
static void C_ccall f_1141(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1147)
static void C_ccall f_1147(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1158)
static void C_ccall f_1158(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1133)
static void C_ccall f_1133(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1023)
static void C_ccall f_1023(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1026)
static void C_ccall f_1026(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1033)
static void C_ccall f_1033(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1035)
static void C_fcall f_1035(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1067)
static void C_ccall f_1067(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1108)
static void C_ccall f_1108(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1120)
static void C_ccall f_1120(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1120)
static void C_ccall f_1120r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1126)
static void C_ccall f_1126(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1114)
static void C_ccall f_1114(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1073)
static void C_ccall f_1073(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1079)
static void C_ccall f_1079(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1086)
static void C_ccall f_1086(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1089)
static void C_ccall f_1089(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1100)
static void C_ccall f_1100(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1096)
static void C_ccall f_1096(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1065)
static void C_ccall f_1065(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1051)
static void C_ccall f_1051(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1058)
static void C_ccall f_1058(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1045)
static void C_ccall f_1045(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1048)
static void C_ccall f_1048(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_975)
static void C_ccall f_975(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_982)
static void C_ccall f_982(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_988)
static void C_ccall f_988(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_957)
static void C_ccall f_957(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_957)
static void C_ccall f_957r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_961)
static void C_ccall f_961(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_964)
static void C_ccall f_964(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_865)
static void C_ccall f_865(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_865)
static void C_ccall f_865r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_869)
static void C_ccall f_869(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_946)
static void C_ccall f_946(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_955)
static void C_ccall f_955(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_872)
static void C_ccall f_872(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_877)
static void C_ccall f_877(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_881)
static void C_ccall f_881(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_944)
static void C_ccall f_944(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_923)
static void C_fcall f_923(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_933)
static void C_ccall f_933(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_884)
static void C_ccall f_884(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_887)
static void C_ccall f_887(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_890)
static void C_ccall f_890(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_893)
static void C_ccall f_893(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_902)
static void C_ccall f_902(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_813)
static void C_ccall f_813(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_896)
static void C_ccall f_896(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_859)
static void C_ccall f_859(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_859)
static void C_ccall f_859r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_840)
static void C_fcall f_840(C_word t0,C_word t1) C_noret;
C_noret_decl(f_857)
static void C_ccall f_857(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_850)
static void C_ccall f_850(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_737)
static void C_fcall f_737(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_741)
static void C_ccall f_741(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_759)
static void C_ccall f_759(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_750)
static void C_ccall f_750(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_773)
static C_word C_fcall f_773(C_word t0,C_word t1);
C_noret_decl(f_692)
static void C_ccall f_692(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_692)
static void C_ccall f_692r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_696)
static void C_ccall f_696(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_699)
static void C_ccall f_699(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_709)
static void C_ccall f_709(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_665)
static void C_ccall f_665(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_670)
static void C_ccall f_670(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_675)
static void C_ccall f_675(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_690)
static void C_ccall f_690(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_682)
static void C_ccall f_682(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_673)
static void C_ccall f_673(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_639)
static void C_ccall f_639(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_644)
static void C_ccall f_644(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_649)
static void C_ccall f_649(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_663)
static void C_ccall f_663(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_656)
static void C_ccall f_656(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_612)
static void C_fcall f_612(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_637)
static void C_ccall f_637(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_616)
static void C_fcall f_616(C_word t0,C_word t1) C_noret;
C_noret_decl(f_630)
static void C_ccall f_630(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_626)
static void C_ccall f_626(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_619)
static void C_fcall f_619(C_word t0,C_word t1) C_noret;

C_noret_decl(trf_2923)
static void C_fcall trf_2923(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2923(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2923(t0,t1,t2,t3);}

C_noret_decl(trf_2942)
static void C_fcall trf_2942(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2942(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2942(t0,t1);}

C_noret_decl(trf_2888)
static void C_fcall trf_2888(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2888(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2888(t0,t1);}

C_noret_decl(trf_2833)
static void C_fcall trf_2833(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2833(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2833(t0,t1);}

C_noret_decl(trf_2775)
static void C_fcall trf_2775(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2775(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2775(t0,t1,t2);}

C_noret_decl(trf_2743)
static void C_fcall trf_2743(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2743(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2743(t0,t1,t2);}

C_noret_decl(trf_2719)
static void C_fcall trf_2719(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2719(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2719(t0,t1);}

C_noret_decl(trf_2520)
static void C_fcall trf_2520(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2520(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2520(t0,t1);}

C_noret_decl(trf_2416)
static void C_fcall trf_2416(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2416(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2416(t0,t1);}

C_noret_decl(trf_2141)
static void C_fcall trf_2141(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2141(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2141(t0,t1);}

C_noret_decl(trf_2087)
static void C_fcall trf_2087(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2087(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2087(t0,t1);}

C_noret_decl(trf_2082)
static void C_fcall trf_2082(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2082(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2082(t0,t1,t2);}

C_noret_decl(trf_2060)
static void C_fcall trf_2060(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2060(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2060(t0,t1,t2,t3);}

C_noret_decl(trf_2010)
static void C_fcall trf_2010(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2010(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2010(t0,t1);}

C_noret_decl(trf_2005)
static void C_fcall trf_2005(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2005(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2005(t0,t1,t2);}

C_noret_decl(trf_1996)
static void C_fcall trf_1996(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1996(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1996(t0,t1,t2,t3);}

C_noret_decl(trf_1913)
static void C_fcall trf_1913(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1913(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_1913(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_1949)
static void C_fcall trf_1949(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1949(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1949(t0,t1);}

C_noret_decl(trf_1882)
static void C_fcall trf_1882(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1882(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1882(t0,t1,t2,t3);}

C_noret_decl(trf_1821)
static void C_fcall trf_1821(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1821(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1821(t0,t1,t2,t3);}

C_noret_decl(trf_1830)
static void C_fcall trf_1830(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1830(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1830(t0,t1,t2);}

C_noret_decl(trf_1767)
static void C_fcall trf_1767(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1767(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1767(t0,t1,t2);}

C_noret_decl(trf_1783)
static void C_fcall trf_1783(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1783(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1783(t0,t1);}

C_noret_decl(trf_1697)
static void C_fcall trf_1697(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1697(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1697(t0,t1);}

C_noret_decl(trf_1692)
static void C_fcall trf_1692(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1692(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1692(t0,t1,t2);}

C_noret_decl(trf_1339)
static void C_fcall trf_1339(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1339(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1339(t0,t1,t2,t3);}

C_noret_decl(trf_1352)
static void C_fcall trf_1352(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1352(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1352(t0,t1);}

C_noret_decl(trf_1382)
static void C_fcall trf_1382(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1382(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1382(t0,t1,t2,t3);}

C_noret_decl(trf_1289)
static void C_fcall trf_1289(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1289(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1289(t0,t1);}

C_noret_decl(trf_1284)
static void C_fcall trf_1284(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1284(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1284(t0,t1,t2);}

C_noret_decl(trf_992)
static void C_fcall trf_992(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_992(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_992(t0,t1,t2,t3);}

C_noret_decl(trf_1005)
static void C_fcall trf_1005(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1005(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1005(t0,t1);}

C_noret_decl(trf_1035)
static void C_fcall trf_1035(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1035(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1035(t0,t1,t2,t3);}

C_noret_decl(trf_923)
static void C_fcall trf_923(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_923(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_923(t0,t1,t2);}

C_noret_decl(trf_840)
static void C_fcall trf_840(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_840(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_840(t0,t1);}

C_noret_decl(trf_737)
static void C_fcall trf_737(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_737(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_737(t0,t1,t2,t3);}

C_noret_decl(trf_612)
static void C_fcall trf_612(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_612(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_612(t0,t1,t2);}

C_noret_decl(trf_616)
static void C_fcall trf_616(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_616(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_616(t0,t1);}

C_noret_decl(trf_619)
static void C_fcall trf_619(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_619(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_619(t0,t1);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr2rv)
static void C_fcall tr2rv(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2rv(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n+1);
t2=C_restore_rest_vector(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr3rv)
static void C_fcall tr3rv(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3rv(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n+1);
t3=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_utils_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_utils_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("utils_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(1012)){
C_save(t1);
C_rereclaim2(1012*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,143);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[2]=C_h_intern(&lf[2],19,"\003sysundefined-value");
lf[3]=C_h_intern(&lf[3],20,"\003sysapropos-interned");
lf[4]=C_h_intern(&lf[4],18,"\003sysapropos-macros");
lf[5]=C_h_intern(&lf[5],13,"string-search");
lf[6]=C_h_intern(&lf[6],6,"regexp");
lf[7]=C_h_intern(&lf[7],13,"regexp-escape");
lf[8]=C_h_intern(&lf[8],14,"symbol->string");
lf[9]=C_h_intern(&lf[9],32,"\003syssymbol-has-toplevel-binding\077");
lf[10]=C_h_intern(&lf[10],23,"\003sysenvironment-symbols");
lf[11]=C_h_intern(&lf[11],23,"\003syshash-table-for-each");
lf[12]=C_h_intern(&lf[12],21,"\003sysmacro-environment");
lf[13]=C_h_intern(&lf[13],11,"\003sysapropos");
lf[14]=C_h_intern(&lf[14],10,"\003sysappend");
lf[15]=C_h_intern(&lf[15],9,"\003syserror");
lf[16]=C_h_intern(&lf[16],12,"apropos-list");
lf[17]=C_h_intern(&lf[17],7,"apropos");
lf[18]=C_h_intern(&lf[18],8,"\000macros\077");
lf[19]=C_h_intern(&lf[19],11,"environment");
lf[20]=C_h_intern(&lf[20],15,"\003syssignal-hook");
lf[21]=C_h_intern(&lf[21],11,"\000type-error");
lf[22]=C_decode_literal(C_heaptop,"\376B\000\0003bad argument type - not a string, symbol, or regexp");
lf[23]=C_h_intern(&lf[23],7,"regexp\077");
lf[24]=C_h_intern(&lf[24],23,"interaction-environment");
lf[25]=C_h_intern(&lf[25],8,"keyword\077");
lf[26]=C_h_intern(&lf[26],28,"\003syssymbol->qualified-string");
lf[27]=C_h_intern(&lf[27],7,"newline");
lf[28]=C_h_intern(&lf[28],7,"display");
lf[29]=C_h_intern(&lf[29],5,"macro");
lf[30]=C_h_intern(&lf[30],9,"procedure");
lf[31]=C_h_intern(&lf[31],21,"procedure-information");
lf[32]=C_h_intern(&lf[32],8,"variable");
lf[33]=C_h_intern(&lf[33],6,"macro\077");
lf[34]=C_h_intern(&lf[34],12,"\003sysfor-each");
lf[35]=C_h_intern(&lf[35],7,"sprintf");
lf[36]=C_h_intern(&lf[36],6,"system");
lf[37]=C_h_intern(&lf[37],7,"system*");
lf[38]=C_decode_literal(C_heaptop,"\376B\000\0003shell invocation failed with non-zero return status");
lf[39]=C_h_intern(&lf[39],12,"file-exists\077");
lf[40]=C_h_intern(&lf[40],11,"delete-file");
lf[41]=C_h_intern(&lf[41],12,"delete-file*");
lf[42]=C_h_intern(&lf[42],9,"file-copy");
lf[43]=C_h_intern(&lf[43],17,"close-output-port");
lf[44]=C_h_intern(&lf[44],16,"close-input-port");
lf[45]=C_h_intern(&lf[45],12,"read-string!");
lf[46]=C_h_intern(&lf[46],9,"condition");
lf[47]=C_h_intern(&lf[47],13,"string-append");
lf[48]=C_decode_literal(C_heaptop,"\376B\000\000\037error writing file starting at ");
lf[49]=C_h_intern(&lf[49],12,"write-string");
lf[50]=C_h_intern(&lf[50],22,"with-exception-handler");
lf[51]=C_h_intern(&lf[51],30,"call-with-current-continuation");
lf[52]=C_h_intern(&lf[52],11,"make-string");
lf[53]=C_decode_literal(C_heaptop,"\376B\000\000#could not open newfile for write - ");
lf[54]=C_h_intern(&lf[54],16,"open-output-file");
lf[55]=C_decode_literal(C_heaptop,"\376B\000\000#could not open origfile for read - ");
lf[56]=C_h_intern(&lf[56],15,"open-input-file");
lf[57]=C_decode_literal(C_heaptop,"\376B\000\000&newfile exists but clobber is false - ");
lf[58]=C_decode_literal(C_heaptop,"\376B\000\000\032origfile does not exist - ");
lf[59]=C_decode_literal(C_heaptop,"\376B\000\0002invalid blocksize given: not a positive integer - ");
lf[60]=C_h_intern(&lf[60],9,"file-move");
lf[61]=C_decode_literal(C_heaptop,"\376B\000\000\034could not remove origfile - ");
lf[62]=C_decode_literal(C_heaptop,"\376B\000\000\037error writing file starting at ");
lf[63]=C_decode_literal(C_heaptop,"\376B\000\000#could not open newfile for write - ");
lf[64]=C_decode_literal(C_heaptop,"\376B\000\000#could not open origfile for read - ");
lf[65]=C_decode_literal(C_heaptop,"\376B\000\000&newfile exists but clobber is false - ");
lf[66]=C_decode_literal(C_heaptop,"\376B\000\000\032origfile does not exist - ");
lf[67]=C_decode_literal(C_heaptop,"\376B\000\0002invalid blocksize given: not a positive integer - ");
lf[68]=C_h_intern(&lf[68],12,"string-match");
lf[69]=C_h_intern(&lf[69],20,"\003syswindows-platform");
lf[70]=C_decode_literal(C_heaptop,"\376B\000\000\014([A-Za-z]:)\077");
lf[71]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[72]=C_h_intern(&lf[72],18,"absolute-pathname\077");
lf[74]=C_h_intern(&lf[74],13,"\003syssubstring");
lf[75]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000/\376\003\000\000\002\376\377\012\000\000\134\376\377\016");
lf[76]=C_h_intern(&lf[76],13,"make-pathname");
lf[77]=C_h_intern(&lf[77],22,"make-absolute-pathname");
lf[78]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[79]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[80]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[81]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[82]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[83]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[84]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[85]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000\134\376\003\000\000\002\376\377\012\000\000/\376\377\016");
lf[86]=C_h_intern(&lf[86],17,"\003sysstring-append");
lf[87]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[88]=C_decode_literal(C_heaptop,"\376B\000\000\001\134");
lf[89]=C_h_intern(&lf[89],18,"decompose-pathname");
lf[90]=C_h_intern(&lf[90],18,"pathname-directory");
lf[91]=C_h_intern(&lf[91],13,"pathname-file");
lf[92]=C_h_intern(&lf[92],18,"pathname-extension");
lf[93]=C_h_intern(&lf[93],24,"pathname-strip-directory");
lf[94]=C_h_intern(&lf[94],24,"pathname-strip-extension");
lf[95]=C_h_intern(&lf[95],26,"pathname-replace-directory");
lf[96]=C_h_intern(&lf[96],21,"pathname-replace-file");
lf[97]=C_h_intern(&lf[97],26,"pathname-replace-extension");
lf[98]=C_h_intern(&lf[98],6,"getenv");
lf[99]=C_h_intern(&lf[99],21,"call-with-output-file");
lf[100]=C_h_intern(&lf[100],21,"create-temporary-file");
lf[101]=C_decode_literal(C_heaptop,"\376B\000\000\003tmp");
lf[102]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[103]=C_decode_literal(C_heaptop,"\376B\000\000\003TMP");
lf[104]=C_decode_literal(C_heaptop,"\376B\000\000\004TEMP");
lf[105]=C_decode_literal(C_heaptop,"\376B\000\000\006TMPDIR");
lf[106]=C_h_intern(&lf[106],15,"directory-null\077");
lf[107]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[108]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[109]=C_h_intern(&lf[109],12,"string-split");
lf[110]=C_decode_literal(C_heaptop,"\376B\000\000\002/\134");
lf[111]=C_h_intern(&lf[111],9,"read-line");
lf[112]=C_h_intern(&lf[112],13,"for-each-line");
lf[113]=C_h_intern(&lf[113],18,"\003sysstandard-input");
lf[114]=C_h_intern(&lf[114],14,"\003syscheck-port");
lf[115]=C_h_intern(&lf[115],18,"for-each-argv-line");
lf[116]=C_decode_literal(C_heaptop,"\376B\000\000\001-");
lf[117]=C_h_intern(&lf[117],20,"with-input-from-file");
lf[118]=C_h_intern(&lf[118],22,"command-line-arguments");
lf[119]=C_h_intern(&lf[119],8,"read-all");
lf[120]=C_h_intern(&lf[120],20,"\003sysread-string/port");
lf[121]=C_h_intern(&lf[121],5,"port\077");
lf[122]=C_h_intern(&lf[122],6,"shift!");
lf[123]=C_h_intern(&lf[123],8,"unshift!");
lf[124]=C_h_intern(&lf[124],13,"port-for-each");
lf[125]=C_h_intern(&lf[125],7,"reverse");
lf[126]=C_h_intern(&lf[126],8,"port-map");
lf[127]=C_h_intern(&lf[127],9,"port-fold");
lf[128]=C_h_intern(&lf[128],19,"make-broadcast-port");
lf[129]=C_h_intern(&lf[129],12,"flush-output");
lf[130]=C_h_intern(&lf[130],16,"make-output-port");
lf[131]=C_h_intern(&lf[131],4,"noop");
lf[132]=C_h_intern(&lf[132],22,"make-concatenated-port");
lf[133]=C_h_intern(&lf[133],18,"\003sysread-char/port");
lf[134]=C_h_intern(&lf[134],11,"char-ready\077");
lf[135]=C_h_intern(&lf[135],9,"peek-char");
lf[136]=C_h_intern(&lf[136],15,"make-input-port");
lf[137]=C_decode_literal(C_heaptop,"\376B\000\000\034^(.*[\134/\134\134])\077((\134.)\077[^\134/\134\134]+)$");
lf[138]=C_decode_literal(C_heaptop,"\376B\000\000&^(.*[\134/\134\134])\077([^\134/\134\134]+)(\134.([^\134/\134\134.]+))$");
lf[139]=C_h_intern(&lf[139],21,"make-anchored-pattern");
lf[140]=C_decode_literal(C_heaptop,"\376B\000\000\010[\134/\134\134].*");
lf[141]=C_h_intern(&lf[141],17,"register-feature!");
lf[142]=C_h_intern(&lf[142],5,"utils");
C_register_lf2(lf,143,create_ptable());
t2=C_mutate(&lf[0],lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_594,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_regex_toplevel(2,C_SCHEME_UNDEFINED,t3);}

/* k592 */
static void C_ccall f_594(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_594,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_597,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k595 in k592 */
static void C_ccall f_597(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_597,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_600,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k598 in k595 in k592 */
static void C_ccall f_600(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_600,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_603,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* utils.scm: 69   register-feature! */
t3=*((C_word*)lf[141]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[142]);}

/* k601 in k598 in k595 in k592 */
static void C_ccall f_603(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word ab[57],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_603,2,t0,t1);}
t2=*((C_word*)lf[2]+1);
t3=C_mutate((C_word*)lf[3]+1,t2);
t4=*((C_word*)lf[2]+1);
t5=C_mutate((C_word*)lf[4]+1,t4);
t6=*((C_word*)lf[5]+1);
t7=*((C_word*)lf[6]+1);
t8=*((C_word*)lf[7]+1);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_612,a[2]=t8,a[3]=t7,a[4]=((C_word)li0),tmp=(C_word)a,a+=5,tmp);
t10=C_mutate((C_word*)lf[3]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_639,a[2]=t9,a[3]=t6,a[4]=((C_word)li2),tmp=(C_word)a,a+=5,tmp));
t11=C_mutate((C_word*)lf[4]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_665,a[2]=t9,a[3]=t6,a[4]=((C_word)li4),tmp=(C_word)a,a+=5,tmp));
t12=C_mutate((C_word*)lf[13]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_692,a[2]=((C_word)li5),tmp=(C_word)a,a+=3,tmp));
t13=*((C_word*)lf[2]+1);
t14=C_mutate((C_word*)lf[16]+1,t13);
t15=*((C_word*)lf[2]+1);
t16=C_mutate((C_word*)lf[17]+1,t15);
t17=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_737,a[2]=((C_word)li7),tmp=(C_word)a,a+=3,tmp);
t18=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_840,a[2]=((C_word)li8),tmp=(C_word)a,a+=3,tmp);
t19=C_mutate((C_word*)lf[16]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_859,a[2]=t17,a[3]=((C_word)li9),tmp=(C_word)a,a+=4,tmp));
t20=C_mutate((C_word*)lf[17]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_865,a[2]=t17,a[3]=t18,a[4]=((C_word)li13),tmp=(C_word)a,a+=5,tmp));
t21=*((C_word*)lf[35]+1);
t22=*((C_word*)lf[36]+1);
t23=C_mutate((C_word*)lf[37]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_957,a[2]=t21,a[3]=t22,a[4]=((C_word)li14),tmp=(C_word)a,a+=5,tmp));
t24=*((C_word*)lf[39]+1);
t25=*((C_word*)lf[40]+1);
t26=C_mutate((C_word*)lf[41]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_975,a[2]=t24,a[3]=t25,a[4]=((C_word)li15),tmp=(C_word)a,a+=5,tmp));
t27=C_mutate((C_word*)lf[42]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_990,a[2]=((C_word)li41),tmp=(C_word)a,a+=3,tmp));
t28=C_mutate((C_word*)lf[60]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1337,a[2]=((C_word)li74),tmp=(C_word)a,a+=3,tmp));
t29=*((C_word*)lf[68]+1);
t30=*((C_word*)lf[6]+1);
t31=*((C_word*)lf[47]+1);
t32=(C_truep(*((C_word*)lf[69]+1))?lf[70]:lf[71]);
t33=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1750,a[2]=t30,a[3]=((C_word*)t0)[2],a[4]=t29,tmp=(C_word)a,a+=5,tmp);
t34=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2972,a[2]=t33,tmp=(C_word)a,a+=3,tmp);
/* utils.scm: 296  string-append */
t35=t31;
((C_proc4)C_retrieve_proc(t35))(4,t35,t34,t32,lf[140]);}

/* k2970 in k601 in k598 in k595 in k592 */
static void C_ccall f_2972(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 296  make-anchored-pattern */
t2=*((C_word*)lf[139]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1748 in k601 in k598 in k595 in k592 */
static void C_ccall f_1750(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1750,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1753,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 297  regexp */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k1751 in k1748 in k601 in k598 in k595 in k592 */
static void C_ccall f_1753(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word ab[38],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1753,2,t0,t1);}
t2=C_mutate((C_word*)lf[72]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1754,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word)li75),tmp=(C_word)a,a+=5,tmp));
t3=C_mutate(&lf[73],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1767,a[2]=((C_word)li76),tmp=(C_word)a,a+=3,tmp));
t4=*((C_word*)lf[2]+1);
t5=C_mutate((C_word*)lf[76]+1,t4);
t6=*((C_word*)lf[2]+1);
t7=C_mutate((C_word*)lf[77]+1,t6);
t8=*((C_word*)lf[47]+1);
t9=*((C_word*)lf[72]+1);
t10=lf[78];
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1821,a[2]=t8,a[3]=t10,a[4]=((C_word)li78),tmp=(C_word)a,a+=5,tmp);
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1882,a[2]=t11,a[3]=((C_word)li79),tmp=(C_word)a,a+=4,tmp);
t13=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1913,a[2]=t8,a[3]=((C_word)li80),tmp=(C_word)a,a+=4,tmp);
t14=C_mutate((C_word*)lf[76]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1994,a[2]=t12,a[3]=t13,a[4]=((C_word)li84),tmp=(C_word)a,a+=5,tmp));
t15=C_mutate((C_word*)lf[77]+1,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2058,a[2]=t12,a[3]=t9,a[4]=t10,a[5]=t13,a[6]=((C_word)li88),tmp=(C_word)a,a+=7,tmp));
t16=*((C_word*)lf[68]+1);
t17=*((C_word*)lf[6]+1);
t18=*((C_word*)lf[47]+1);
t19=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2137,a[2]=t17,a[3]=((C_word*)t0)[2],a[4]=t16,tmp=(C_word)a,a+=5,tmp);
/* utils.scm: 380  regexp */
t20=t17;
((C_proc3)C_retrieve_proc(t20))(3,t20,t19,lf[138]);}

/* k2135 in k1751 in k1748 in k601 in k598 in k595 in k592 */
static void C_ccall f_2137(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2137,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2140,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* utils.scm: 381  regexp */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[137]);}

/* k2138 in k2135 in k1751 in k1748 in k601 in k598 in k595 in k592 */
static void C_ccall f_2140(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word ab[84],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2140,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2141,a[2]=((C_word)li89),tmp=(C_word)a,a+=3,tmp);
t3=C_mutate((C_word*)lf[89]+1,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2155,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word)li90),tmp=(C_word)a,a+=7,tmp));
t4=*((C_word*)lf[2]+1);
t5=C_mutate((C_word*)lf[90]+1,t4);
t6=*((C_word*)lf[2]+1);
t7=C_mutate((C_word*)lf[91]+1,t6);
t8=*((C_word*)lf[2]+1);
t9=C_mutate((C_word*)lf[92]+1,t8);
t10=*((C_word*)lf[2]+1);
t11=C_mutate((C_word*)lf[93]+1,t10);
t12=*((C_word*)lf[2]+1);
t13=C_mutate((C_word*)lf[94]+1,t12);
t14=*((C_word*)lf[2]+1);
t15=C_mutate((C_word*)lf[95]+1,t14);
t16=*((C_word*)lf[2]+1);
t17=C_mutate((C_word*)lf[96]+1,t16);
t18=*((C_word*)lf[2]+1);
t19=C_mutate((C_word*)lf[97]+1,t18);
t20=*((C_word*)lf[89]+1);
t21=C_mutate((C_word*)lf[90]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2263,a[2]=t20,a[3]=((C_word)li93),tmp=(C_word)a,a+=4,tmp));
t22=C_mutate((C_word*)lf[91]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2278,a[2]=t20,a[3]=((C_word)li96),tmp=(C_word)a,a+=4,tmp));
t23=C_mutate((C_word*)lf[92]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2293,a[2]=t20,a[3]=((C_word)li99),tmp=(C_word)a,a+=4,tmp));
t24=C_mutate((C_word*)lf[93]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2308,a[2]=t20,a[3]=((C_word)li102),tmp=(C_word)a,a+=4,tmp));
t25=C_mutate((C_word*)lf[94]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2326,a[2]=t20,a[3]=((C_word)li105),tmp=(C_word)a,a+=4,tmp));
t26=C_mutate((C_word*)lf[95]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2344,a[2]=t20,a[3]=((C_word)li108),tmp=(C_word)a,a+=4,tmp));
t27=C_mutate((C_word*)lf[96]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2362,a[2]=t20,a[3]=((C_word)li111),tmp=(C_word)a,a+=4,tmp));
t28=C_mutate((C_word*)lf[97]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2380,a[2]=t20,a[3]=((C_word)li114),tmp=(C_word)a,a+=4,tmp));
t29=*((C_word*)lf[98]+1);
t30=*((C_word*)lf[76]+1);
t31=*((C_word*)lf[39]+1);
t32=*((C_word*)lf[99]+1);
t33=C_mutate((C_word*)lf[100]+1,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2398,a[2]=t29,a[3]=t30,a[4]=t31,a[5]=t32,a[6]=((C_word)li117),tmp=(C_word)a,a+=7,tmp));
t34=C_mutate((C_word*)lf[106]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2463,a[2]=((C_word)li119),tmp=(C_word)a,a+=3,tmp));
t35=*((C_word*)lf[111]+1);
t36=C_mutate((C_word*)lf[112]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2508,a[2]=t35,a[3]=((C_word)li121),tmp=(C_word)a,a+=4,tmp));
t37=C_mutate((C_word*)lf[115]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2544,a[2]=((C_word)li124),tmp=(C_word)a,a+=3,tmp));
t38=C_mutate((C_word*)lf[119]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2589,a[2]=((C_word)li126),tmp=(C_word)a,a+=3,tmp));
t39=C_mutate((C_word*)lf[122]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2632,a[2]=((C_word)li127),tmp=(C_word)a,a+=3,tmp));
t40=C_mutate((C_word*)lf[123]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2689,a[2]=((C_word)li128),tmp=(C_word)a,a+=3,tmp));
t41=C_mutate((C_word*)lf[124]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2713,a[2]=((C_word)li130),tmp=(C_word)a,a+=3,tmp));
t42=*((C_word*)lf[125]+1);
t43=C_mutate((C_word*)lf[126]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2737,a[2]=t42,a[3]=((C_word)li132),tmp=(C_word)a,a+=4,tmp));
t44=C_mutate((C_word*)lf[127]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2769,a[2]=((C_word)li134),tmp=(C_word)a,a+=3,tmp));
t45=C_mutate((C_word*)lf[128]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2794,a[2]=((C_word)li138),tmp=(C_word)a,a+=3,tmp));
t46=C_mutate((C_word*)lf[132]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2818,a[2]=((C_word)li146),tmp=(C_word)a,a+=3,tmp));
t47=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t47+1)))(2,t47,C_SCHEME_UNDEFINED);}

/* make-concatenated-port in k2138 in k2135 in k1751 in k1748 in k601 in k598 in k595 in k592 */
static void C_ccall f_2818(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+21)){
C_save_and_reclaim((void*)tr3r,(void*)f_2818r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2818r(t0,t1,t2,t3);}}

static void C_ccall f_2818r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(21);
t4=(C_word)C_a_i_cons(&a,2,t2,t3);
t5=t4;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2827,a[2]=t6,a[3]=((C_word)li140),tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2862,a[2]=t6,a[3]=((C_word)li141),tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2882,a[2]=t6,a[3]=((C_word)li143),tmp=(C_word)a,a+=4,tmp);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2917,a[2]=t6,a[3]=((C_word)li145),tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 574  make-input-port */
t11=*((C_word*)lf[136]+1);
((C_proc7)C_retrieve_proc(t11))(7,t11,t1,t7,t8,*((C_word*)lf[131]+1),t9,t10);}

/* a2916 in make-concatenated-port in k2138 in k2135 in k1751 in k1748 in k601 in k598 in k595 in k592 */
static void C_ccall f_2917(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_2917,6,t0,t1,t2,t3,t4,t5);}
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2923,a[2]=t4,a[3]=t5,a[4]=t7,a[5]=((C_word*)t0)[2],a[6]=((C_word)li144),tmp=(C_word)a,a+=7,tmp));
t9=((C_word*)t7)[1];
f_2923(t9,t1,t3,C_fix(0));}

/* loop in a2916 in make-concatenated-port in k2138 in k2135 in k1751 in k1748 in k601 in k598 in k595 in k592 */
static void C_fcall f_2923(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2923,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(((C_word*)((C_word*)t0)[5])[1]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
if(C_truep((C_word)C_fixnum_less_or_equal_p(t2,C_fix(0)))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2939,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_i_car(((C_word*)((C_word*)t0)[5])[1]);
t6=(C_word)C_fixnum_plus(((C_word*)t0)[3],t3);
/* utils.scm: 602  read-string! */
t7=*((C_word*)lf[45]+1);
((C_proc6)C_retrieve_proc(t7))(6,t7,t4,t2,((C_word*)t0)[2],t5,t6);}}}

/* k2937 in loop in a2916 in make-concatenated-port in k2138 in k2135 in k1751 in k1748 in k601 in k598 in k595 in k592 */
static void C_ccall f_2939(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2939,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2942,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_fixnum_lessp(t1,((C_word*)t0)[6]))){
t3=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[2])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t3);
t5=t2;
f_2942(t5,t4);}
else{
t3=t2;
f_2942(t3,C_SCHEME_UNDEFINED);}}

/* k2940 in k2937 in loop in a2916 in make-concatenated-port in k2138 in k2135 in k1751 in k1748 in k601 in k598 in k595 in k592 */
static void C_fcall f_2942(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_fixnum_difference(((C_word*)t0)[6],((C_word*)t0)[5]);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],((C_word*)t0)[5]);
/* utils.scm: 605  loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2923(t4,((C_word*)t0)[2],t2,t3);}

/* a2881 in make-concatenated-port in k2138 in k2135 in k1751 in k1748 in k601 in k598 in k595 in k592 */
static void C_ccall f_2882(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2882,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2888,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word)li142),tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_2888(t5,t1);}

/* loop in a2881 in make-concatenated-port in k2138 in k2135 in k1751 in k1748 in k601 in k598 in k595 in k592 */
static void C_fcall f_2888(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2888,NULL,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(((C_word*)((C_word*)t0)[3])[1]))){
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_FILE);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2898,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_car(((C_word*)((C_word*)t0)[3])[1]);
/* utils.scm: 592  peek-char */
t4=*((C_word*)lf[135]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}}

/* k2896 in loop in a2881 in make-concatenated-port in k2138 in k2135 in k1751 in k1748 in k601 in k598 in k595 in k592 */
static void C_ccall f_2898(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep((C_word)C_eofp(t1))){
t2=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[4])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[4])+1,t2);
/* utils.scm: 595  loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2888(t4,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}}

/* a2861 in make-concatenated-port in k2138 in k2135 in k1751 in k1748 in k601 in k598 in k595 in k592 */
static void C_ccall f_2862(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2862,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(((C_word*)((C_word*)t0)[2])[1]))){
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(C_word)C_i_car(((C_word*)((C_word*)t0)[2])[1]);
/* utils.scm: 586  char-ready? */
t3=*((C_word*)lf[134]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}}

/* a2826 in make-concatenated-port in k2138 in k2135 in k1751 in k1748 in k601 in k598 in k595 in k592 */
static void C_ccall f_2827(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2827,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2833,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word)li139),tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_2833(t5,t1);}

/* loop in a2826 in make-concatenated-port in k2138 in k2135 in k1751 in k1748 in k601 in k598 in k595 in k592 */
static void C_fcall f_2833(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2833,NULL,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(((C_word*)((C_word*)t0)[3])[1]))){
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_FILE);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2843,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_car(((C_word*)((C_word*)t0)[3])[1]);
/* read-char/port */
t4=*((C_word*)lf[133]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}}

/* k2841 in loop in a2826 in make-concatenated-port in k2138 in k2135 in k1751 in k1748 in k601 in k598 in k595 in k592 */
static void C_ccall f_2843(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep((C_word)C_eofp(t1))){
t2=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[4])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[4])+1,t2);
/* utils.scm: 582  loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2833(t4,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}}

/* make-broadcast-port in k2138 in k2135 in k1751 in k1748 in k601 in k598 in k595 in k592 */
static void C_ccall f_2794(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr2r,(void*)f_2794r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2794r(t0,t1,t2);}}

static void C_ccall f_2794r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(8);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2800,a[2]=t2,a[3]=((C_word)li136),tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2812,a[2]=t2,a[3]=((C_word)li137),tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 567  make-output-port */
t5=*((C_word*)lf[130]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,t1,t3,*((C_word*)lf[131]+1),t4);}

/* a2811 in make-broadcast-port in k2138 in k2135 in k1751 in k1748 in k601 in k598 in k595 in k592 */
static void C_ccall f_2812(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2812,2,t0,t1);}
/* for-each */
t2=*((C_word*)lf[34]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,*((C_word*)lf[129]+1),((C_word*)t0)[2]);}

/* a2799 in make-broadcast-port in k2138 in k2135 in k1751 in k1748 in k601 in k598 in k595 in k592 */
static void C_ccall f_2800(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2800,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2806,a[2]=t2,a[3]=((C_word)li135),tmp=(C_word)a,a+=4,tmp);
/* for-each */
t4=*((C_word*)lf[34]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t3,((C_word*)t0)[2]);}

/* a2805 in a2799 in make-broadcast-port in k2138 in k2135 in k1751 in k1748 in k601 in k598 in k595 in k592 */
static void C_ccall f_2806(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2806,3,t0,t1,t2);}
/* write-string */
t3=*((C_word*)lf[49]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t1,((C_word*)t0)[2],C_SCHEME_FALSE,t2);}

/* port-fold in k2138 in k2135 in k1751 in k1748 in k601 in k598 in k595 in k592 */
static void C_ccall f_2769(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2769,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2775,a[2]=t4,a[3]=t2,a[4]=t6,a[5]=((C_word)li133),tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_2775(t8,t1,t3);}

/* loop in port-fold in k2138 in k2135 in k1751 in k1748 in k601 in k598 in k595 in k592 */
static void C_fcall f_2775(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2775,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2779,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* utils.scm: 559  thunk */
t4=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k2777 in loop in port-fold in k2138 in k2135 in k1751 in k1748 in k601 in k598 in k595 in k592 */
static void C_ccall f_2779(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2779,2,t0,t1);}
t2=(C_word)C_eqp(t1,C_SCHEME_END_OF_FILE);
if(C_truep(t2)){
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[4]);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2792,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 562  fn */
t4=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,t1,((C_word*)t0)[4]);}}

/* k2790 in k2777 in loop in port-fold in k2138 in k2135 in k1751 in k1748 in k601 in k598 in k595 in k592 */
static void C_ccall f_2792(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 562  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_2775(t2,((C_word*)t0)[2],t1);}

/* port-map in k2138 in k2135 in k1751 in k1748 in k601 in k598 in k595 in k592 */
static void C_ccall f_2737(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2737,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2743,a[2]=t3,a[3]=t2,a[4]=t5,a[5]=((C_word*)t0)[2],a[6]=((C_word)li131),tmp=(C_word)a,a+=7,tmp));
t7=((C_word*)t5)[1];
f_2743(t7,t1,C_SCHEME_END_OF_LIST);}

/* loop in port-map in k2138 in k2135 in k1751 in k1748 in k601 in k598 in k595 in k592 */
static void C_fcall f_2743(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2743,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2747,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* utils.scm: 552  thunk */
t4=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k2745 in loop in port-map in k2138 in k2135 in k1751 in k1748 in k601 in k598 in k595 in k592 */
static void C_ccall f_2747(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2747,2,t0,t1);}
t2=(C_word)C_eqp(t1,C_SCHEME_END_OF_FILE);
if(C_truep(t2)){
/* utils.scm: 554  reverse */
t3=((C_word*)t0)[6];
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2767,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* utils.scm: 555  fn */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t1);}}

/* k2765 in k2745 in loop in port-map in k2138 in k2135 in k1751 in k1748 in k601 in k598 in k595 in k592 */
static void C_ccall f_2767(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2767,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[4]);
/* utils.scm: 555  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2743(t3,((C_word*)t0)[2],t2);}

/* port-for-each in k2138 in k2135 in k1751 in k1748 in k601 in k598 in k595 in k592 */
static void C_ccall f_2713(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2713,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2719,a[2]=t3,a[3]=t2,a[4]=t5,a[5]=((C_word)li129),tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_2719(t7,t1);}

/* loop in port-for-each in k2138 in k2135 in k1751 in k1748 in k601 in k598 in k595 in k592 */
static void C_fcall f_2719(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2719,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2723,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* utils.scm: 543  thunk */
t3=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k2721 in loop in port-for-each in k2138 in k2135 in k1751 in k1748 in k601 in k598 in k595 in k592 */
static void C_ccall f_2723(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2723,2,t0,t1);}
t2=(C_word)C_eqp(t1,C_SCHEME_END_OF_FILE);
if(C_truep(t2)){
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2732,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 545  fn */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t1);}}

/* k2730 in k2721 in loop in port-for-each in k2138 in k2135 in k1751 in k1748 in k601 in k598 in k595 in k592 */
static void C_ccall f_2732(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 546  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_2719(t2,((C_word*)t0)[2]);}

/* unshift! in k2138 in k2135 in k1751 in k1748 in k601 in k598 in k595 in k592 */
static void C_ccall f_2689(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2689,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_pair_2(t3,lf[123]);
t5=(C_word)C_slot(t3,C_fix(0));
t6=(C_word)C_slot(t3,C_fix(1));
t7=(C_word)C_a_i_cons(&a,2,t5,t6);
t8=(C_word)C_i_setslot(t3,C_fix(1),t7);
t9=(C_word)C_i_setslot(t3,C_fix(0),t2);
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,t3);}

/* shift! in k2138 in k2135 in k1751 in k1748 in k601 in k598 in k595 in k592 */
static void C_ccall f_2632(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_2632r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2632r(t0,t1,t2,t3);}}

static void C_ccall f_2632r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2636,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_2636(2,t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_2636(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k2634 in shift! in k2138 in k2135 in k1751 in k1748 in k601 in k598 in k595 in k592 */
static void C_ccall f_2636(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[3]))){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_i_check_pair_2(((C_word*)t0)[3],lf[122]);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(0));
t4=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
t5=(C_word)C_i_check_pair_2(t4,lf[122]);
t6=(C_word)C_slot(t4,C_fix(1));
t7=(C_word)C_i_setslot(((C_word*)t0)[3],C_fix(1),t6);
t8=(C_word)C_slot(t4,C_fix(0));
t9=(C_word)C_i_setslot(((C_word*)t0)[3],C_fix(0),t8);
t10=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,t3);}}

/* read-all in k2138 in k2135 in k1751 in k1748 in k601 in k598 in k595 in k592 */
static void C_ccall f_2589(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_2589r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2589r(t0,t1,t2);}}

static void C_ccall f_2589r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2593,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
t4=t3;
f_2593(2,t4,*((C_word*)lf[113]+1));}
else{
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t4))){
t5=t3;
f_2593(2,t5,(C_word)C_i_car(t2));}
else{
/* utils.scm: 512  ##sys#error */
t5=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,lf[0],t2);}}}

/* k2591 in read-all in k2138 in k2135 in k1751 in k1748 in k601 in k598 in k595 in k592 */
static void C_ccall f_2593(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2593,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2599,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 513  port? */
t3=*((C_word*)lf[121]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}

/* k2597 in k2591 in read-all in k2138 in k2135 in k1751 in k1748 in k601 in k598 in k595 in k592 */
static void C_ccall f_2599(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2599,2,t0,t1);}
if(C_truep(t1)){
/* read-string/port */
t2=*((C_word*)lf[120]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],C_SCHEME_FALSE,((C_word*)t0)[2]);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2607,a[2]=((C_word)li125),tmp=(C_word)a,a+=3,tmp);
/* utils.scm: 515  with-input-from-file */
t3=*((C_word*)lf[117]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}}

/* a2606 in k2597 in k2591 in read-all in k2138 in k2135 in k1751 in k1748 in k601 in k598 in k595 in k592 */
static void C_ccall f_2607(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2607,2,t0,t1);}
/* read-string/port */
t2=*((C_word*)lf[120]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,C_SCHEME_FALSE,*((C_word*)lf[113]+1));}

/* for-each-argv-line in k2138 in k2135 in k1751 in k1748 in k601 in k598 in k595 in k592 */
static void C_ccall f_2544(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2544,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2569,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 501  command-line-arguments */
t4=*((C_word*)lf[118]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k2567 in for-each-argv-line in k2138 in k2135 in k1751 in k1748 in k601 in k598 in k595 in k592 */
static void C_ccall f_2569(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2569,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
/* utils.scm: 504  for-each-line */
t2=*((C_word*)lf[112]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2583,a[2]=((C_word*)t0)[2],a[3]=((C_word)li123),tmp=(C_word)a,a+=4,tmp);
/* for-each */
t3=*((C_word*)lf[34]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,t1);}}

/* a2582 in k2567 in for-each-argv-line in k2138 in k2135 in k1751 in k1748 in k601 in k598 in k595 in k592 */
static void C_ccall f_2583(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2583,3,t0,t1,t2);}
t3=((C_word*)t0)[2];
if(C_truep((C_word)C_i_string_equal_p(t2,lf[116]))){
/* utils.scm: 499  for-each-line */
t4=*((C_word*)lf[112]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2562,a[2]=t3,a[3]=((C_word)li122),tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 500  with-input-from-file */
t5=*((C_word*)lf[117]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t2,t4);}}

/* a2561 in a2582 in k2567 in for-each-argv-line in k2138 in k2135 in k1751 in k1748 in k601 in k598 in k595 in k592 */
static void C_ccall f_2562(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2562,2,t0,t1);}
/* for-each-line */
t2=*((C_word*)lf[112]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* for-each-line in k2138 in k2135 in k1751 in k1748 in k601 in k598 in k595 in k592 */
static void C_ccall f_2508(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr3rv,(void*)f_2508r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_2508r(t0,t1,t2,t3);}}

static void C_ccall f_2508r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(6);
t4=(C_word)C_notvemptyp(t3);
t5=(C_truep(t4)?(C_word)C_i_vector_ref(t3,C_fix(0)):*((C_word*)lf[113]+1));
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2515,a[2]=t1,a[3]=t5,a[4]=((C_word*)t0)[2],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* utils.scm: 486  ##sys#check-port */
t7=*((C_word*)lf[114]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,t5,lf[112]);}

/* k2513 in for-each-line in k2138 in k2135 in k1751 in k1748 in k601 in k598 in k595 in k592 */
static void C_ccall f_2515(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2515,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2520,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t3,a[6]=((C_word)li120),tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_2520(t5,((C_word*)t0)[2]);}

/* loop in k2513 in for-each-line in k2138 in k2135 in k1751 in k1748 in k601 in k598 in k595 in k592 */
static void C_fcall f_2520(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2520,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2524,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* utils.scm: 488  read-line */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k2522 in loop in k2513 in for-each-line in k2138 in k2135 in k1751 in k1748 in k601 in k598 in k595 in k592 */
static void C_ccall f_2524(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2524,2,t0,t1);}
if(C_truep((C_word)C_eofp(t1))){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2533,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 490  proc */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}}

/* k2531 in k2522 in loop in k2513 in for-each-line in k2138 in k2135 in k1751 in k1748 in k601 in k598 in k595 in k592 */
static void C_ccall f_2533(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 491  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_2520(t2,((C_word*)t0)[2]);}

/* directory-null? in k2138 in k2135 in k1751 in k1748 in k601 in k598 in k595 in k592 */
static void C_ccall f_2463(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2463,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2471,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_listp(t2))){
t4=t3;
f_2471(2,t4,t2);}
else{
t4=(C_word)C_i_check_string_2(t2,lf[106]);
/* utils.scm: 475  string-split */
t5=*((C_word*)lf[109]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,t2,lf[110],C_SCHEME_TRUE);}}

/* k2469 in directory-null? in k2138 in k2135 in k1751 in k1748 in k601 in k598 in k595 in k592 */
static void C_ccall f_2471(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2471,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2473,a[2]=((C_word)li118),tmp=(C_word)a,a+=3,tmp);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,f_2473(t1));}

/* loop in k2469 in directory-null? in k2138 in k2135 in k1751 in k1748 in k601 in k598 in k595 in k592 */
static C_word C_fcall f_2473(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
loop:
C_stack_check;
t2=(C_word)C_i_nullp(t1);
if(C_truep(t2)){
return(t2);}
else{
t3=(C_word)C_i_car(t1);
if(C_truep((C_truep((C_word)C_i_equalp(t3,lf[107]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t3,lf[108]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
t4=(C_word)C_i_cdr(t1);
t6=t4;
t1=t6;
goto loop;}
else{
return(C_SCHEME_FALSE);}}}

/* create-temporary-file in k2138 in k2135 in k1751 in k1748 in k601 in k598 in k595 in k592 */
static void C_ccall f_2398(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr2rv,(void*)f_2398r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_2398r(t0,t1,t2);}}

static void C_ccall f_2398r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(8);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2402,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* utils.scm: 456  getenv */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[105]);}

/* k2400 in create-temporary-file in k2138 in k2135 in k1751 in k1748 in k601 in k598 in k595 in k592 */
static void C_ccall f_2402(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2402,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2405,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t1)){
t3=t2;
f_2405(2,t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2455,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 456  getenv */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[104]);}}

/* k2453 in k2400 in create-temporary-file in k2138 in k2135 in k1751 in k1748 in k601 in k598 in k595 in k592 */
static void C_ccall f_2455(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_2405(2,t2,t1);}
else{
/* utils.scm: 456  getenv */
t2=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],lf[103]);}}

/* k2403 in k2400 in create-temporary-file in k2138 in k2135 in k1751 in k1748 in k601 in k598 in k595 in k592 */
static void C_ccall f_2405(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2405,2,t0,t1);}
t2=(C_word)C_notvemptyp(((C_word*)t0)[6]);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(((C_word*)t0)[6],C_fix(0)):lf[101]);
t4=(C_word)C_i_check_string_2(t3,lf[100]);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2416,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t6,a[8]=((C_word)li116),tmp=(C_word)a,a+=9,tmp));
t8=((C_word*)t6)[1];
f_2416(t8,((C_word*)t0)[2]);}

/* loop in k2403 in k2400 in create-temporary-file in k2138 in k2135 in k1751 in k1748 in k601 in k598 in k595 in k592 */
static void C_fcall f_2416(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2416,NULL,2,t0,t1);}
t2=(C_word)C_fudge(C_fix(16));
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2423,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t1,a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2442,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2446,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* utils.scm: 461  number->string */
C_number_to_string(4,0,t5,t2,C_fix(16));}

/* k2444 in loop in k2403 in k2400 in create-temporary-file in k2138 in k2135 in k1751 in k1748 in k601 in k598 in k595 in k592 */
static void C_ccall f_2446(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 461  ##sys#string-append */
t2=*((C_word*)lf[86]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[102],t1);}

/* k2440 in loop in k2403 in k2400 in create-temporary-file in k2138 in k2135 in k1751 in k1748 in k601 in k598 in k595 in k592 */
static void C_ccall f_2442(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 461  make-pathname */
t2=((C_word*)t0)[5];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2421 in loop in k2403 in k2400 in create-temporary-file in k2138 in k2135 in k1751 in k1748 in k601 in k598 in k595 in k592 */
static void C_ccall f_2423(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2423,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2429,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* utils.scm: 462  file-exists? */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k2427 in k2421 in loop in k2403 in k2400 in create-temporary-file in k2138 in k2135 in k1751 in k1748 in k601 in k598 in k595 in k592 */
static void C_ccall f_2429(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2429,2,t0,t1);}
if(C_truep(t1)){
/* utils.scm: 463  loop */
t2=((C_word*)((C_word*)t0)[5])[1];
f_2416(t2,((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2437,a[2]=((C_word*)t0)[3],a[3]=((C_word)li115),tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 464  call-with-output-file */
t3=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[4],((C_word*)t0)[3],t2);}}

/* a2436 in k2427 in k2421 in loop in k2403 in k2400 in create-temporary-file in k2138 in k2135 in k1751 in k1748 in k601 in k598 in k595 in k592 */
static void C_ccall f_2437(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2437,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[2]);}

/* pathname-replace-extension in k2138 in k2135 in k1751 in k1748 in k601 in k598 in k595 in k592 */
static void C_ccall f_2380(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2380,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2386,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li112),tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2392,a[2]=t3,a[3]=((C_word)li113),tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t4,t5);}

/* a2391 in pathname-replace-extension in k2138 in k2135 in k1751 in k1748 in k601 in k598 in k595 in k592 */
static void C_ccall f_2392(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2392,5,t0,t1,t2,t3,t4);}
/* utils.scm: 448  make-pathname */
t5=*((C_word*)lf[76]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,t3,((C_word*)t0)[2]);}

/* a2385 in pathname-replace-extension in k2138 in k2135 in k1751 in k1748 in k601 in k598 in k595 in k592 */
static void C_ccall f_2386(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2386,2,t0,t1);}
/* utils.scm: 447  decompose-pathname */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* pathname-replace-file in k2138 in k2135 in k1751 in k1748 in k601 in k598 in k595 in k592 */
static void C_ccall f_2362(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2362,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2368,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li109),tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2374,a[2]=t3,a[3]=((C_word)li110),tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t4,t5);}

/* a2373 in pathname-replace-file in k2138 in k2135 in k1751 in k1748 in k601 in k598 in k595 in k592 */
static void C_ccall f_2374(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2374,5,t0,t1,t2,t3,t4);}
/* utils.scm: 443  make-pathname */
t5=*((C_word*)lf[76]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,((C_word*)t0)[2],t4);}

/* a2367 in pathname-replace-file in k2138 in k2135 in k1751 in k1748 in k601 in k598 in k595 in k592 */
static void C_ccall f_2368(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2368,2,t0,t1);}
/* utils.scm: 442  decompose-pathname */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* pathname-replace-directory in k2138 in k2135 in k1751 in k1748 in k601 in k598 in k595 in k592 */
static void C_ccall f_2344(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2344,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2350,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li106),tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2356,a[2]=t3,a[3]=((C_word)li107),tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t4,t5);}

/* a2355 in pathname-replace-directory in k2138 in k2135 in k1751 in k1748 in k601 in k598 in k595 in k592 */
static void C_ccall f_2356(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2356,5,t0,t1,t2,t3,t4);}
/* utils.scm: 438  make-pathname */
t5=*((C_word*)lf[76]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,((C_word*)t0)[2],t3,t4);}

/* a2349 in pathname-replace-directory in k2138 in k2135 in k1751 in k1748 in k601 in k598 in k595 in k592 */
static void C_ccall f_2350(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2350,2,t0,t1);}
/* utils.scm: 437  decompose-pathname */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* pathname-strip-extension in k2138 in k2135 in k1751 in k1748 in k601 in k598 in k595 in k592 */
static void C_ccall f_2326(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2326,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2332,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li103),tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2338,a[2]=((C_word)li104),tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t3,t4);}

/* a2337 in pathname-strip-extension in k2138 in k2135 in k1751 in k1748 in k601 in k598 in k595 in k592 */
static void C_ccall f_2338(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2338,5,t0,t1,t2,t3,t4);}
/* utils.scm: 433  make-pathname */
t5=*((C_word*)lf[76]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t2,t3);}

/* a2331 in pathname-strip-extension in k2138 in k2135 in k1751 in k1748 in k601 in k598 in k595 in k592 */
static void C_ccall f_2332(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2332,2,t0,t1);}
/* utils.scm: 432  decompose-pathname */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* pathname-strip-directory in k2138 in k2135 in k1751 in k1748 in k601 in k598 in k595 in k592 */
static void C_ccall f_2308(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2308,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2314,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li100),tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2320,a[2]=((C_word)li101),tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t3,t4);}

/* a2319 in pathname-strip-directory in k2138 in k2135 in k1751 in k1748 in k601 in k598 in k595 in k592 */
static void C_ccall f_2320(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2320,5,t0,t1,t2,t3,t4);}
/* utils.scm: 428  make-pathname */
t5=*((C_word*)lf[76]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,C_SCHEME_FALSE,t3,t4);}

/* a2313 in pathname-strip-directory in k2138 in k2135 in k1751 in k1748 in k601 in k598 in k595 in k592 */
static void C_ccall f_2314(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2314,2,t0,t1);}
/* utils.scm: 427  decompose-pathname */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* pathname-extension in k2138 in k2135 in k1751 in k1748 in k601 in k598 in k595 in k592 */
static void C_ccall f_2293(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2293,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2299,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li97),tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2305,a[2]=((C_word)li98),tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t3,t4);}

/* a2304 in pathname-extension in k2138 in k2135 in k1751 in k1748 in k601 in k598 in k595 in k592 */
static void C_ccall f_2305(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2305,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* a2298 in pathname-extension in k2138 in k2135 in k1751 in k1748 in k601 in k598 in k595 in k592 */
static void C_ccall f_2299(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2299,2,t0,t1);}
/* utils.scm: 422  decompose-pathname */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* pathname-file in k2138 in k2135 in k1751 in k1748 in k601 in k598 in k595 in k592 */
static void C_ccall f_2278(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2278,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2284,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li94),tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2290,a[2]=((C_word)li95),tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t3,t4);}

/* a2289 in pathname-file in k2138 in k2135 in k1751 in k1748 in k601 in k598 in k595 in k592 */
static void C_ccall f_2290(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2290,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}

/* a2283 in pathname-file in k2138 in k2135 in k1751 in k1748 in k601 in k598 in k595 in k592 */
static void C_ccall f_2284(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2284,2,t0,t1);}
/* utils.scm: 417  decompose-pathname */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* pathname-directory in k2138 in k2135 in k1751 in k1748 in k601 in k598 in k595 in k592 */
static void C_ccall f_2263(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2263,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2269,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li91),tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2275,a[2]=((C_word)li92),tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t3,t4);}

/* a2274 in pathname-directory in k2138 in k2135 in k1751 in k1748 in k601 in k598 in k595 in k592 */
static void C_ccall f_2275(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2275,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t2);}

/* a2268 in pathname-directory in k2138 in k2135 in k1751 in k1748 in k601 in k598 in k595 in k592 */
static void C_ccall f_2269(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2269,2,t0,t1);}
/* utils.scm: 412  decompose-pathname */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* decompose-pathname in k2138 in k2135 in k1751 in k1748 in k601 in k598 in k595 in k592 */
static void C_ccall f_2155(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2155,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[89]);
t4=(C_word)C_block_size(t2);
t5=(C_word)C_eqp(C_fix(0),t4);
if(C_truep(t5)){
/* utils.scm: 391  values */
C_values(5,0,t1,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE);}
else{
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2171,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* utils.scm: 392  string-match */
t7=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,((C_word*)t0)[2],t2);}}

/* k2169 in decompose-pathname in k2138 in k2135 in k1751 in k1748 in k601 in k598 in k595 in k592 */
static void C_ccall f_2171(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2171,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2181,a[2]=((C_word*)t0)[6],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cadr(t1);
/* utils.scm: 394  strip-pds */
f_2141(t2,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2200,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* utils.scm: 395  string-match */
t3=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],((C_word*)t0)[4]);}}

/* k2198 in k2169 in decompose-pathname in k2138 in k2135 in k1751 in k1748 in k601 in k598 in k595 in k592 */
static void C_ccall f_2200(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2200,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2210,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cadr(t1);
/* utils.scm: 397  strip-pds */
f_2141(t2,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2225,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* utils.scm: 398  strip-pds */
f_2141(t2,((C_word*)t0)[2]);}}

/* k2223 in k2198 in k2169 in decompose-pathname in k2138 in k2135 in k1751 in k1748 in k601 in k598 in k595 in k592 */
static void C_ccall f_2225(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 398  values */
C_values(5,0,((C_word*)t0)[2],t1,C_SCHEME_FALSE,C_SCHEME_FALSE);}

/* k2208 in k2198 in k2169 in decompose-pathname in k2138 in k2135 in k1751 in k1748 in k601 in k598 in k595 in k592 */
static void C_ccall f_2210(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_caddr(((C_word*)t0)[3]);
/* utils.scm: 397  values */
C_values(5,0,((C_word*)t0)[2],t1,t2,C_SCHEME_FALSE);}

/* k2179 in k2169 in decompose-pathname in k2138 in k2135 in k1751 in k1748 in k601 in k598 in k595 in k592 */
static void C_ccall f_2181(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_i_caddr(((C_word*)t0)[3]);
t3=(C_word)C_i_cddddr(((C_word*)t0)[3]);
t4=(C_word)C_i_car(t3);
/* utils.scm: 394  values */
C_values(5,0,((C_word*)t0)[2],t1,t2,t4);}

/* strip-pds in k2138 in k2135 in k1751 in k1748 in k601 in k598 in k595 in k592 */
static void C_fcall f_2141(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2141,NULL,2,t1,t2);}
if(C_truep(t2)){
t3=t2;
if(C_truep((C_truep((C_word)C_i_equalp(t3,lf[87]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t3,lf[88]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}
else{
/* utils.scm: 387  chop-pds */
f_1767(t1,t2,C_SCHEME_FALSE);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* make-absolute-pathname in k1751 in k1748 in k601 in k598 in k595 in k592 */
static void C_ccall f_2058(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+17)){
C_save_and_reclaim((void*)tr4r,(void*)f_2058r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_2058r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2058r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(17);
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2060,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t3,a[7]=((C_word*)t0)[5],a[8]=((C_word)li85),tmp=(C_word)a,a+=9,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2082,a[2]=t5,a[3]=((C_word)li86),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2087,a[2]=t6,a[3]=((C_word)li87),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-ext315326 */
t8=t7;
f_2087(t8,t1);}
else{
t8=(C_word)C_i_car(t4);
t9=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t9))){
/* def-pds316324 */
t10=t6;
f_2082(t10,t1,t8);}
else{
t10=(C_word)C_i_car(t9);
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
/* body313318 */
t12=t5;
f_2060(t12,t1,t8,t10);}
else{
/* ##sys#error */
t12=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t1,lf[0],t11);}}}}

/* def-ext315 in make-absolute-pathname in k1751 in k1748 in k601 in k598 in k595 in k592 */
static void C_fcall f_2087(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2087,NULL,2,t0,t1);}
/* def-pds316324 */
t2=((C_word*)t0)[2];
f_2082(t2,t1,C_SCHEME_FALSE);}

/* def-pds316 in make-absolute-pathname in k1751 in k1748 in k601 in k598 in k595 in k592 */
static void C_fcall f_2082(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2082,NULL,3,t0,t1,t2);}
/* body313318 */
t3=((C_word*)t0)[2];
f_2060(t3,t1,t2,C_SCHEME_FALSE);}

/* body313 in make-absolute-pathname in k1751 in k1748 in k601 in k598 in k595 in k592 */
static void C_fcall f_2060(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2060,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2068,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=t2,a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* utils.scm: 368  canonicalize-dirs */
t5=((C_word*)t0)[3];
f_1882(t5,t4,((C_word*)t0)[2],t3);}

/* k2066 in body313 in make-absolute-pathname in k1751 in k1748 in k601 in k598 in k595 in k592 */
static void C_ccall f_2068(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2068,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2071,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2074,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* utils.scm: 369  absolute-pathname? */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t1);}

/* k2072 in k2066 in body313 in make-absolute-pathname in k1751 in k1748 in k601 in k598 in k595 in k592 */
static void C_ccall f_2074(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
f_2071(2,t2,((C_word*)t0)[4]);}
else{
t2=((C_word*)t0)[3];
t3=(C_truep(t2)?t2:((C_word*)t0)[2]);
/* utils.scm: 371  ##sys#string-append */
t4=*((C_word*)lf[86]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[5],t3,((C_word*)t0)[4]);}}

/* k2069 in k2066 in body313 in make-absolute-pathname in k1751 in k1748 in k601 in k598 in k595 in k592 */
static void C_ccall f_2071(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 366  _make-pathname */
t2=((C_word*)t0)[6];
f_1913(t2,((C_word*)t0)[5],lf[77],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* make-pathname in k1751 in k1748 in k601 in k598 in k595 in k592 */
static void C_ccall f_1994(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+15)){
C_save_and_reclaim((void*)tr4r,(void*)f_1994r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_1994r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1994r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(15);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1996,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=((C_word*)t0)[3],a[6]=((C_word)li81),tmp=(C_word)a,a+=7,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2005,a[2]=t5,a[3]=((C_word)li82),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2010,a[2]=t6,a[3]=((C_word)li83),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-ext294302 */
t8=t7;
f_2010(t8,t1);}
else{
t8=(C_word)C_i_car(t4);
t9=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t9))){
/* def-pds295300 */
t10=t6;
f_2005(t10,t1,t8);}
else{
t10=(C_word)C_i_car(t9);
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
/* body292297 */
t12=t5;
f_1996(t12,t1,t8,t10);}
else{
/* ##sys#error */
t12=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t1,lf[0],t11);}}}}

/* def-ext294 in make-pathname in k1751 in k1748 in k601 in k598 in k595 in k592 */
static void C_fcall f_2010(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2010,NULL,2,t0,t1);}
/* def-pds295300 */
t2=((C_word*)t0)[2];
f_2005(t2,t1,C_SCHEME_FALSE);}

/* def-pds295 in make-pathname in k1751 in k1748 in k601 in k598 in k595 in k592 */
static void C_fcall f_2005(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2005,NULL,3,t0,t1,t2);}
/* body292297 */
t3=((C_word*)t0)[2];
f_1996(t3,t1,t2,C_SCHEME_FALSE);}

/* body292 in make-pathname in k1751 in k1748 in k601 in k598 in k595 in k592 */
static void C_fcall f_1996(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1996,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2004,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* utils.scm: 362  canonicalize-dirs */
t5=((C_word*)t0)[3];
f_1882(t5,t4,((C_word*)t0)[2],t3);}

/* k2002 in body292 in make-pathname in k1751 in k1748 in k601 in k598 in k595 in k592 */
static void C_ccall f_2004(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 362  _make-pathname */
t2=((C_word*)t0)[6];
f_1913(t2,((C_word*)t0)[5],lf[76],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* _make-pathname in k1751 in k1748 in k601 in k598 in k595 in k592 */
static void C_fcall f_1913(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1913,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(C_truep(t5)?t5:lf[81]);
t8=(C_truep(t4)?t4:lf[82]);
t9=(C_truep(t6)?(C_word)C_block_size(t6):C_fix(1));
t10=(C_word)C_i_check_string_2(t3,t2);
t11=(C_word)C_i_check_string_2(t8,t2);
t12=(C_word)C_i_check_string_2(t7,t2);
t13=(C_truep(t6)?(C_word)C_i_check_string_2(t6,t2):C_SCHEME_UNDEFINED);
t14=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1942,a[2]=t7,a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
t15=(C_word)C_block_size(t8);
t16=(C_word)C_fixnum_greater_or_equal_p(t15,t9);
t17=(C_truep(t16)?(C_truep(t6)?(C_word)C_substring_compare(t6,t8,C_fix(0),C_fix(0),t9):(C_word)C_i_memq((C_word)C_subchar(t8,C_fix(0)),lf[85])):C_SCHEME_FALSE);
if(C_truep(t17)){
t18=(C_word)C_block_size(t8);
/* utils.scm: 352  ##sys#substring */
t19=*((C_word*)lf[74]+1);
((C_proc5)(void*)(*((C_word*)t19+1)))(5,t19,t14,t8,t9,t18);}
else{
t18=t14;
f_1942(2,t18,t8);}}

/* k1940 in _make-pathname in k1751 in k1748 in k601 in k598 in k595 in k592 */
static void C_ccall f_1942(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1942,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1949,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[2]);
if(C_truep((C_word)C_fixnum_greaterp(t3,C_fix(0)))){
t4=(C_word)C_eqp((C_word)C_subchar(((C_word*)t0)[2],C_fix(0)),C_make_character(46));
t5=t2;
f_1949(t5,(C_word)C_i_not(t4));}
else{
t4=t2;
f_1949(t4,C_SCHEME_FALSE);}}

/* k1947 in k1940 in _make-pathname in k1751 in k1748 in k601 in k598 in k595 in k592 */
static void C_fcall f_1949(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?lf[83]:lf[84]);
/* utils.scm: 346  string-append */
t3=((C_word*)t0)[6];
((C_proc6)C_retrieve_proc(t3))(6,t3,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* canonicalize-dirs in k1751 in k1748 in k601 in k598 in k595 in k592 */
static void C_fcall f_1882(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1882,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_not(t2);
t5=(C_truep(t4)?t4:(C_word)C_i_nullp(t2));
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,lf[80]);}
else{
if(C_truep((C_word)C_i_stringp(t2))){
t6=(C_word)C_a_i_list(&a,1,t2);
/* utils.scm: 335  conc-dirs */
t7=((C_word*)t0)[2];
f_1821(t7,t1,t6,t3);}
else{
/* utils.scm: 336  conc-dirs */
t6=((C_word*)t0)[2];
f_1821(t6,t1,t2,t3);}}}

/* conc-dirs in k1751 in k1748 in k601 in k598 in k595 in k592 */
static void C_fcall f_1821(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1821,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_list_2(t2,lf[76]);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1830,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t6,a[6]=((C_word)li77),tmp=(C_word)a,a+=7,tmp));
t8=((C_word*)t6)[1];
f_1830(t8,t1,t2);}

/* loop in conc-dirs in k1751 in k1748 in k601 in k598 in k595 in k592 */
static void C_fcall f_1830(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
a=C_alloc(8);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1830,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[79]);}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_string_length(t3);
t5=(C_word)C_eqp(t4,C_fix(0));
if(C_truep(t5)){
t6=(C_word)C_i_cdr(t2);
/* utils.scm: 327  loop */
t10=t1;
t11=t6;
t1=t10;
t2=t11;
goto loop;}
else{
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1860,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
t7=(C_word)C_i_car(t2);
/* utils.scm: 329  chop-pds */
f_1767(t6,t7,((C_word*)t0)[4]);}}}

/* k1858 in loop in conc-dirs in k1751 in k1748 in k601 in k598 in k595 in k592 */
static void C_ccall f_1860(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1860,2,t0,t1);}
t2=((C_word*)t0)[7];
t3=(C_truep(t2)?t2:((C_word*)t0)[6]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1868,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* utils.scm: 331  loop */
t6=((C_word*)((C_word*)t0)[2])[1];
f_1830(t6,t4,t5);}

/* k1866 in k1858 in loop in conc-dirs in k1751 in k1748 in k601 in k598 in k595 in k592 */
static void C_ccall f_1868(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 328  string-append */
t2=((C_word*)t0)[5];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* chop-pds in k1751 in k1748 in k601 in k598 in k595 in k592 */
static void C_fcall f_1767(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1767,NULL,3,t1,t2,t3);}
if(C_truep(t2)){
t4=(C_word)C_block_size(t2);
t5=(C_truep(t3)?(C_word)C_block_size(t3):C_fix(1));
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1783,a[2]=t2,a[3]=t1,a[4]=t5,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t4,C_fix(1)))){
if(C_truep(t3)){
t7=(C_word)C_fixnum_difference(t4,t5);
t8=t6;
f_1783(t8,(C_word)C_substring_compare(t2,t3,t7,C_fix(0),t5));}
else{
t7=(C_word)C_fixnum_difference(t4,t5);
t8=(C_word)C_subchar(t2,t7);
t9=t6;
f_1783(t9,(C_word)C_i_memq(t8,lf[75]));}}
else{
t7=t6;
f_1783(t7,C_SCHEME_FALSE);}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k1781 in chop-pds in k1751 in k1748 in k601 in k598 in k595 in k592 */
static void C_fcall f_1783(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_fixnum_difference(((C_word*)t0)[5],((C_word*)t0)[4]);
/* utils.scm: 311  ##sys#substring */
t3=*((C_word*)lf[74]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0),t2);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* absolute-pathname? in k1751 in k1748 in k601 in k598 in k595 in k592 */
static void C_ccall f_1754(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1754,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[72]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1765,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* utils.scm: 300  string-match */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[2],t2);}

/* k1763 in absolute-pathname? in k1751 in k1748 in k601 in k598 in k595 in k592 */
static void C_ccall f_1765(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_pairp(t1));}

/* file-move in k601 in k598 in k595 in k592 */
static void C_ccall f_1337(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+13)){
C_save_and_reclaim((void*)tr4r,(void*)f_1337r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_1337r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1337r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(13);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1339,a[2]=t3,a[3]=t2,a[4]=((C_word)li71),tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1692,a[2]=t5,a[3]=((C_word)li72),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1697,a[2]=t6,a[3]=((C_word)li73),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-clobber165234 */
t8=t7;
f_1697(t8,t1);}
else{
t8=(C_word)C_i_car(t4);
t9=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t9))){
/* def-blocksize166232 */
t10=t6;
f_1692(t10,t1,t8);}
else{
t10=(C_word)C_i_car(t9);
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
/* body163168 */
t12=t5;
f_1339(t12,t1,t8,t10);}
else{
/* ##sys#error */
t12=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t1,lf[0],t11);}}}}

/* def-clobber165 in file-move in k601 in k598 in k595 in k592 */
static void C_fcall f_1697(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1697,NULL,2,t0,t1);}
/* def-blocksize166232 */
t2=((C_word*)t0)[2];
f_1692(t2,t1,C_SCHEME_FALSE);}

/* def-blocksize166 in file-move in k601 in k598 in k595 in k592 */
static void C_fcall f_1692(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1692,NULL,3,t0,t1,t2);}
/* body163168 */
t3=((C_word*)t0)[2];
f_1339(t3,t1,t2,C_fix(1024));}

/* body163 in file-move in k601 in k598 in k595 in k592 */
static void C_fcall f_1339(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1339,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(((C_word*)t0)[3],lf[60]);
t5=(C_word)C_i_check_string_2(((C_word*)t0)[2],lf[60]);
t6=(C_word)C_i_check_number_2(t3,lf[60]);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1352,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=t3,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_integerp(t3))){
t8=t3;
t9=t7;
f_1352(t9,(C_word)C_fixnum_greaterp(t8,C_fix(0)));}
else{
t8=t7;
f_1352(t8,C_SCHEME_FALSE);}}

/* k1350 in body163 in file-move in k601 in k598 in k595 in k592 */
static void C_fcall f_1352(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1352,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1355,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t1)){
t3=t2;
f_1355(2,t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1681,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1685,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* utils.scm: 248  number->string */
C_number_to_string(3,0,t4,((C_word*)t0)[5]);}}

/* k1683 in k1350 in body163 in file-move in k601 in k598 in k595 in k592 */
static void C_ccall f_1685(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 246  string-append */
t2=*((C_word*)lf[47]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[67],t1);}

/* k1679 in k1350 in body163 in file-move in k601 in k598 in k595 in k592 */
static void C_ccall f_1681(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 246  ##sys#error */
t2=*((C_word*)lf[15]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1353 in k1350 in body163 in file-move in k601 in k598 in k595 in k592 */
static void C_ccall f_1355(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1355,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1358,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* utils.scm: 249  file-exists? */
t3=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[6]);}

/* k1356 in k1353 in k1350 in body163 in file-move in k601 in k598 in k595 in k592 */
static void C_ccall f_1358(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1358,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1361,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t1)){
t3=t2;
f_1361(2,t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1674,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* utils.scm: 250  string-append */
t4=*((C_word*)lf[47]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,lf[66],((C_word*)t0)[6]);}}

/* k1672 in k1356 in k1353 in k1350 in body163 in file-move in k601 in k598 in k595 in k592 */
static void C_ccall f_1674(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 250  ##sys#error */
t2=*((C_word*)lf[15]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1359 in k1356 in k1353 in k1350 in body163 in file-move in k601 in k598 in k595 in k592 */
static void C_ccall f_1361(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1361,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1364,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1657,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* utils.scm: 251  file-exists? */
t4=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[3]);}

/* k1655 in k1359 in k1356 in k1353 in k1350 in body163 in file-move in k601 in k598 in k595 in k592 */
static void C_ccall f_1657(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1657,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
if(C_truep(t2)){
t3=((C_word*)t0)[3];
f_1364(2,t3,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1667,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* utils.scm: 253  string-append */
t4=*((C_word*)lf[47]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,lf[65],((C_word*)t0)[2]);}}
else{
t2=((C_word*)t0)[3];
f_1364(2,t2,C_SCHEME_FALSE);}}

/* k1665 in k1655 in k1359 in k1356 in k1353 in k1350 in body163 in file-move in k601 in k598 in k595 in k592 */
static void C_ccall f_1667(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 253  ##sys#error */
t2=*((C_word*)lf[15]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1362 in k1359 in k1356 in k1353 in k1350 in body163 in file-move in k601 in k598 in k595 in k592 */
static void C_ccall f_1364(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1364,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1367,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1599,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1601,a[2]=((C_word*)t0)[5],a[3]=((C_word)li70),tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 256  call-with-current-continuation */
t5=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a1600 in k1362 in k1359 in k1356 in k1353 in k1350 in body163 in file-move in k601 in k598 in k595 in k592 */
static void C_ccall f_1601(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1601,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1607,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li65),tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1632,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li69),tmp=(C_word)a,a+=5,tmp);
/* utils.scm: 256  with-exception-handler */
t5=*((C_word*)lf[50]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t3,t4);}

/* a1631 in a1600 in k1362 in k1359 in k1356 in k1353 in k1350 in body163 in file-move in k601 in k598 in k595 in k592 */
static void C_ccall f_1632(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1632,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1638,a[2]=((C_word*)t0)[3],a[3]=((C_word)li66),tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1644,a[2]=((C_word*)t0)[2],a[3]=((C_word)li68),tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 256  ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a1643 in a1631 in a1600 in k1362 in k1359 in k1356 in k1353 in k1350 in body163 in file-move in k601 in k598 in k595 in k592 */
static void C_ccall f_1644(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_1644r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1644r(t0,t1,t2);}}

static void C_ccall f_1644r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1650,a[2]=t2,a[3]=((C_word)li67),tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 256  g180 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a1649 in a1643 in a1631 in a1600 in k1362 in k1359 in k1356 in k1353 in k1350 in body163 in file-move in k601 in k598 in k595 in k592 */
static void C_ccall f_1650(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1650,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a1637 in a1631 in a1600 in k1362 in k1359 in k1356 in k1353 in k1350 in body163 in file-move in k601 in k598 in k595 in k592 */
static void C_ccall f_1638(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1638,2,t0,t1);}
/* utils.scm: 256  open-input-file */
t2=*((C_word*)lf[56]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* a1606 in a1600 in k1362 in k1359 in k1356 in k1353 in k1350 in body163 in file-move in k601 in k598 in k595 in k592 */
static void C_ccall f_1607(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1607,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1613,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word)li64),tmp=(C_word)a,a+=5,tmp);
/* utils.scm: 256  g180 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a1612 in a1606 in a1600 in k1362 in k1359 in k1356 in k1353 in k1350 in body163 in file-move in k601 in k598 in k595 in k592 */
static void C_ccall f_1613(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1613,2,t0,t1);}
t2=(C_word)C_i_structurep(((C_word*)t0)[3],lf[46]);
t3=(C_truep(t2)?(C_word)C_slot(((C_word*)t0)[3],C_fix(1)):C_SCHEME_FALSE);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1624,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* utils.scm: 258  string-append */
t5=*((C_word*)lf[47]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,lf[64],((C_word*)t0)[2]);}

/* k1622 in a1612 in a1606 in a1600 in k1362 in k1359 in k1356 in k1353 in k1350 in body163 in file-move in k601 in k598 in k595 in k592 */
static void C_ccall f_1624(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 258  ##sys#error */
t2=*((C_word*)lf[15]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1597 in k1362 in k1359 in k1356 in k1353 in k1350 in body163 in file-move in k601 in k598 in k595 in k592 */
static void C_ccall f_1599(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in body163 in file-move in k601 in k598 in k595 in k592 */
static void C_ccall f_1367(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1367,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1370,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1541,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1543,a[2]=((C_word*)t0)[2],a[3]=((C_word)li63),tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 261  call-with-current-continuation */
t5=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a1542 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in body163 in file-move in k601 in k598 in k595 in k592 */
static void C_ccall f_1543(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1543,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1549,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li58),tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1574,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li62),tmp=(C_word)a,a+=5,tmp);
/* utils.scm: 261  with-exception-handler */
t5=*((C_word*)lf[50]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t3,t4);}

/* a1573 in a1542 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in body163 in file-move in k601 in k598 in k595 in k592 */
static void C_ccall f_1574(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1574,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1580,a[2]=((C_word*)t0)[3],a[3]=((C_word)li59),tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1586,a[2]=((C_word*)t0)[2],a[3]=((C_word)li61),tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 261  ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a1585 in a1573 in a1542 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in body163 in file-move in k601 in k598 in k595 in k592 */
static void C_ccall f_1586(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_1586r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1586r(t0,t1,t2);}}

static void C_ccall f_1586r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1592,a[2]=t2,a[3]=((C_word)li60),tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 261  g190 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a1591 in a1585 in a1573 in a1542 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in body163 in file-move in k601 in k598 in k595 in k592 */
static void C_ccall f_1592(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1592,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a1579 in a1573 in a1542 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in body163 in file-move in k601 in k598 in k595 in k592 */
static void C_ccall f_1580(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1580,2,t0,t1);}
/* utils.scm: 261  open-output-file */
t2=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* a1548 in a1542 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in body163 in file-move in k601 in k598 in k595 in k592 */
static void C_ccall f_1549(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1549,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1555,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word)li57),tmp=(C_word)a,a+=5,tmp);
/* utils.scm: 261  g190 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a1554 in a1548 in a1542 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in body163 in file-move in k601 in k598 in k595 in k592 */
static void C_ccall f_1555(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1555,2,t0,t1);}
t2=(C_word)C_i_structurep(((C_word*)t0)[3],lf[46]);
t3=(C_truep(t2)?(C_word)C_slot(((C_word*)t0)[3],C_fix(1)):C_SCHEME_FALSE);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1566,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* utils.scm: 263  string-append */
t5=*((C_word*)lf[47]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,lf[63],((C_word*)t0)[2]);}

/* k1564 in a1554 in a1548 in a1542 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in body163 in file-move in k601 in k598 in k595 in k592 */
static void C_ccall f_1566(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 263  ##sys#error */
t2=*((C_word*)lf[15]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1539 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in body163 in file-move in k601 in k598 in k595 in k592 */
static void C_ccall f_1541(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k1368 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in body163 in file-move in k601 in k598 in k595 in k592 */
static void C_ccall f_1370(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1370,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1373,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* utils.scm: 266  make-string */
t3=*((C_word*)lf[52]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* k1371 in k1368 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in body163 in file-move in k601 in k598 in k595 in k592 */
static void C_ccall f_1373(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1373,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1380,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* utils.scm: 267  read-string! */
t3=*((C_word*)lf[45]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[3],t1,((C_word*)t0)[4]);}

/* k1378 in k1371 in k1368 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in body163 in file-move in k601 in k598 in k595 in k592 */
static void C_ccall f_1380(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1380,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1382,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word)li56),tmp=(C_word)a,a+=9,tmp));
t5=((C_word*)t3)[1];
f_1382(t5,((C_word*)t0)[2],t1,C_fix(0));}

/* loop in k1378 in k1371 in k1368 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in body163 in file-move in k601 in k598 in k595 in k592 */
static void C_fcall f_1382(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1382,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_eqp(C_fix(0),t4);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1392,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* utils.scm: 271  close-input-port */
t7=*((C_word*)lf[44]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,((C_word*)t0)[5]);}
else{
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1459,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],a[7]=t3,a[8]=t2,tmp=(C_word)a,a+=9,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1473,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1475,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t3,a[7]=((C_word)li55),tmp=(C_word)a,a+=8,tmp);
/* utils.scm: 280  call-with-current-continuation */
t9=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t7,t8);}}

/* a1474 in loop in k1378 in k1371 in k1368 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in body163 in file-move in k601 in k598 in k595 in k592 */
static void C_ccall f_1475(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1475,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1481,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word)li50),tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1516,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word)li54),tmp=(C_word)a,a+=7,tmp);
/* utils.scm: 280  with-exception-handler */
t5=*((C_word*)lf[50]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t3,t4);}

/* a1515 in a1474 in loop in k1378 in k1371 in k1368 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in body163 in file-move in k601 in k598 in k595 in k592 */
static void C_ccall f_1516(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1516,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1522,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word)li51),tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1528,a[2]=((C_word*)t0)[2],a[3]=((C_word)li53),tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 280  ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a1527 in a1515 in a1474 in loop in k1378 in k1371 in k1368 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in body163 in file-move in k601 in k598 in k595 in k592 */
static void C_ccall f_1528(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_1528r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1528r(t0,t1,t2);}}

static void C_ccall f_1528r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1534,a[2]=t2,a[3]=((C_word)li52),tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 280  g215 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a1533 in a1527 in a1515 in a1474 in loop in k1378 in k1371 in k1368 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in body163 in file-move in k601 in k598 in k595 in k592 */
static void C_ccall f_1534(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1534,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a1521 in a1515 in a1474 in loop in k1378 in k1371 in k1368 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in body163 in file-move in k601 in k598 in k595 in k592 */
static void C_ccall f_1522(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1522,2,t0,t1);}
/* utils.scm: 280  write-string */
t2=*((C_word*)lf[49]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a1480 in a1474 in loop in k1378 in k1371 in k1368 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in body163 in file-move in k601 in k598 in k595 in k592 */
static void C_ccall f_1481(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1481,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1487,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=((C_word)li49),tmp=(C_word)a,a+=7,tmp);
/* utils.scm: 280  g215 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a1486 in a1480 in a1474 in loop in k1378 in k1371 in k1368 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in body163 in file-move in k601 in k598 in k595 in k592 */
static void C_ccall f_1487(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1487,2,t0,t1);}
t2=(C_word)C_i_structurep(((C_word*)t0)[5],lf[46]);
t3=(C_truep(t2)?(C_word)C_slot(((C_word*)t0)[5],C_fix(1)):C_SCHEME_FALSE);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1494,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* utils.scm: 282  close-input-port */
t5=*((C_word*)lf[44]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[2]);}

/* k1492 in a1486 in a1480 in a1474 in loop in k1378 in k1371 in k1368 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in body163 in file-move in k601 in k598 in k595 in k592 */
static void C_ccall f_1494(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1494,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1497,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 283  close-output-port */
t3=*((C_word*)lf[43]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k1495 in k1492 in a1486 in a1480 in a1474 in loop in k1378 in k1371 in k1368 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in body163 in file-move in k601 in k598 in k595 in k592 */
static void C_ccall f_1497(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1497,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1504,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1508,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* utils.scm: 286  number->string */
C_number_to_string(3,0,t3,((C_word*)t0)[2]);}

/* k1506 in k1495 in k1492 in a1486 in a1480 in a1474 in loop in k1378 in k1371 in k1368 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in body163 in file-move in k601 in k598 in k595 in k592 */
static void C_ccall f_1508(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 284  string-append */
t2=*((C_word*)lf[47]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[62],t1);}

/* k1502 in k1495 in k1492 in a1486 in a1480 in a1474 in loop in k1378 in k1371 in k1368 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in body163 in file-move in k601 in k598 in k595 in k592 */
static void C_ccall f_1504(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 284  ##sys#error */
t2=*((C_word*)lf[15]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1471 in loop in k1378 in k1371 in k1368 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in body163 in file-move in k601 in k598 in k595 in k592 */
static void C_ccall f_1473(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k1457 in loop in k1378 in k1371 in k1368 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in body163 in file-move in k601 in k598 in k595 in k592 */
static void C_ccall f_1459(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1459,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1466,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
/* utils.scm: 287  read-string! */
t3=*((C_word*)lf[45]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1464 in k1457 in loop in k1378 in k1371 in k1368 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in body163 in file-move in k601 in k598 in k595 in k592 */
static void C_ccall f_1466(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[5],((C_word*)t0)[4]);
/* utils.scm: 287  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1382(t3,((C_word*)t0)[2],t1,t2);}

/* k1390 in loop in k1378 in k1371 in k1368 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in body163 in file-move in k601 in k598 in k595 in k592 */
static void C_ccall f_1392(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1392,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1395,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* utils.scm: 272  close-output-port */
t3=*((C_word*)lf[43]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k1393 in k1390 in loop in k1378 in k1371 in k1368 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in body163 in file-move in k601 in k598 in k595 in k592 */
static void C_ccall f_1395(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1395,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1398,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1401,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1403,a[2]=((C_word*)t0)[2],a[3]=((C_word)li48),tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 273  call-with-current-continuation */
t5=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a1402 in k1393 in k1390 in loop in k1378 in k1371 in k1368 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in body163 in file-move in k601 in k598 in k595 in k592 */
static void C_ccall f_1403(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1403,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1409,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li43),tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1434,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li47),tmp=(C_word)a,a+=5,tmp);
/* utils.scm: 273  with-exception-handler */
t5=*((C_word*)lf[50]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t3,t4);}

/* a1433 in a1402 in k1393 in k1390 in loop in k1378 in k1371 in k1368 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in body163 in file-move in k601 in k598 in k595 in k592 */
static void C_ccall f_1434(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1434,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1440,a[2]=((C_word*)t0)[3],a[3]=((C_word)li44),tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1446,a[2]=((C_word*)t0)[2],a[3]=((C_word)li46),tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 273  ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a1445 in a1433 in a1402 in k1393 in k1390 in loop in k1378 in k1371 in k1368 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in body163 in file-move in k601 in k598 in k595 in k592 */
static void C_ccall f_1446(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_1446r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1446r(t0,t1,t2);}}

static void C_ccall f_1446r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1452,a[2]=t2,a[3]=((C_word)li45),tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 273  g203 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a1451 in a1445 in a1433 in a1402 in k1393 in k1390 in loop in k1378 in k1371 in k1368 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in body163 in file-move in k601 in k598 in k595 in k592 */
static void C_ccall f_1452(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1452,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a1439 in a1433 in a1402 in k1393 in k1390 in loop in k1378 in k1371 in k1368 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in body163 in file-move in k601 in k598 in k595 in k592 */
static void C_ccall f_1440(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1440,2,t0,t1);}
/* utils.scm: 273  delete-file */
t2=*((C_word*)lf[40]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* a1408 in a1402 in k1393 in k1390 in loop in k1378 in k1371 in k1368 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in body163 in file-move in k601 in k598 in k595 in k592 */
static void C_ccall f_1409(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1409,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1415,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word)li42),tmp=(C_word)a,a+=5,tmp);
/* utils.scm: 273  g203 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a1414 in a1408 in a1402 in k1393 in k1390 in loop in k1378 in k1371 in k1368 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in body163 in file-move in k601 in k598 in k595 in k592 */
static void C_ccall f_1415(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1415,2,t0,t1);}
t2=(C_word)C_i_structurep(((C_word*)t0)[3],lf[46]);
t3=(C_truep(t2)?(C_word)C_slot(((C_word*)t0)[3],C_fix(1)):C_SCHEME_FALSE);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1426,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* utils.scm: 275  string-append */
t5=*((C_word*)lf[47]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,lf[61],((C_word*)t0)[2]);}

/* k1424 in a1414 in a1408 in a1402 in k1393 in k1390 in loop in k1378 in k1371 in k1368 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in body163 in file-move in k601 in k598 in k595 in k592 */
static void C_ccall f_1426(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 275  ##sys#error */
t2=*((C_word*)lf[15]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1399 in k1393 in k1390 in loop in k1378 in k1371 in k1368 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in body163 in file-move in k601 in k598 in k595 in k592 */
static void C_ccall f_1401(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k1396 in k1393 in k1390 in loop in k1378 in k1371 in k1368 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in body163 in file-move in k601 in k598 in k595 in k592 */
static void C_ccall f_1398(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* file-copy in k601 in k598 in k595 in k592 */
static void C_ccall f_990(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+13)){
C_save_and_reclaim((void*)tr4r,(void*)f_990r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_990r(t0,t1,t2,t3,t4);}}

static void C_ccall f_990r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(13);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_992,a[2]=t3,a[3]=t2,a[4]=((C_word)li38),tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1284,a[2]=t5,a[3]=((C_word)li39),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1289,a[2]=t6,a[3]=((C_word)li40),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-clobber93152 */
t8=t7;
f_1289(t8,t1);}
else{
t8=(C_word)C_i_car(t4);
t9=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t9))){
/* def-blocksize94150 */
t10=t6;
f_1284(t10,t1,t8);}
else{
t10=(C_word)C_i_car(t9);
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
/* body9196 */
t12=t5;
f_992(t12,t1,t8,t10);}
else{
/* ##sys#error */
t12=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t1,lf[0],t11);}}}}

/* def-clobber93 in file-copy in k601 in k598 in k595 in k592 */
static void C_fcall f_1289(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1289,NULL,2,t0,t1);}
/* def-blocksize94150 */
t2=((C_word*)t0)[2];
f_1284(t2,t1,C_SCHEME_FALSE);}

/* def-blocksize94 in file-copy in k601 in k598 in k595 in k592 */
static void C_fcall f_1284(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1284,NULL,3,t0,t1,t2);}
/* body9196 */
t3=((C_word*)t0)[2];
f_992(t3,t1,t2,C_fix(1024));}

/* body91 in file-copy in k601 in k598 in k595 in k592 */
static void C_fcall f_992(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_992,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(((C_word*)t0)[3],lf[42]);
t5=(C_word)C_i_check_string_2(((C_word*)t0)[2],lf[42]);
t6=(C_word)C_i_check_number_2(t3,lf[42]);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1005,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[2],a[5]=t1,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_integerp(t3))){
t8=t3;
t9=t7;
f_1005(t9,(C_word)C_fixnum_greaterp(t8,C_fix(0)));}
else{
t8=t7;
f_1005(t8,C_SCHEME_FALSE);}}

/* k1003 in body91 in file-copy in k601 in k598 in k595 in k592 */
static void C_fcall f_1005(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1005,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1008,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t1)){
t3=t2;
f_1008(2,t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1273,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1277,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* utils.scm: 205  number->string */
C_number_to_string(3,0,t4,((C_word*)t0)[6]);}}

/* k1275 in k1003 in body91 in file-copy in k601 in k598 in k595 in k592 */
static void C_ccall f_1277(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 203  string-append */
t2=*((C_word*)lf[47]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[59],t1);}

/* k1271 in k1003 in body91 in file-copy in k601 in k598 in k595 in k592 */
static void C_ccall f_1273(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 203  ##sys#error */
t2=*((C_word*)lf[15]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1006 in k1003 in body91 in file-copy in k601 in k598 in k595 in k592 */
static void C_ccall f_1008(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1008,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1011,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* utils.scm: 206  file-exists? */
t3=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* k1009 in k1006 in k1003 in body91 in file-copy in k601 in k598 in k595 in k592 */
static void C_ccall f_1011(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1011,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1014,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t1)){
t3=t2;
f_1014(2,t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1266,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* utils.scm: 207  string-append */
t4=*((C_word*)lf[47]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,lf[58],((C_word*)t0)[3]);}}

/* k1264 in k1009 in k1006 in k1003 in body91 in file-copy in k601 in k598 in k595 in k592 */
static void C_ccall f_1266(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 207  ##sys#error */
t2=*((C_word*)lf[15]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1012 in k1009 in k1006 in k1003 in body91 in file-copy in k601 in k598 in k595 in k592 */
static void C_ccall f_1014(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1014,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1017,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1249,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* utils.scm: 208  file-exists? */
t4=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[4]);}

/* k1247 in k1012 in k1009 in k1006 in k1003 in body91 in file-copy in k601 in k598 in k595 in k592 */
static void C_ccall f_1249(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1249,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
if(C_truep(t2)){
t3=((C_word*)t0)[3];
f_1017(2,t3,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1259,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* utils.scm: 210  string-append */
t4=*((C_word*)lf[47]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,lf[57],((C_word*)t0)[2]);}}
else{
t2=((C_word*)t0)[3];
f_1017(2,t2,C_SCHEME_FALSE);}}

/* k1257 in k1247 in k1012 in k1009 in k1006 in k1003 in body91 in file-copy in k601 in k598 in k595 in k592 */
static void C_ccall f_1259(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 210  ##sys#error */
t2=*((C_word*)lf[15]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1015 in k1012 in k1009 in k1006 in k1003 in body91 in file-copy in k601 in k598 in k595 in k592 */
static void C_ccall f_1017(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1017,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1020,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1191,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1193,a[2]=((C_word*)t0)[2],a[3]=((C_word)li37),tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 213  call-with-current-continuation */
t5=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a1192 in k1015 in k1012 in k1009 in k1006 in k1003 in body91 in file-copy in k601 in k598 in k595 in k592 */
static void C_ccall f_1193(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1193,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1199,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li32),tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1224,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li36),tmp=(C_word)a,a+=5,tmp);
/* utils.scm: 213  with-exception-handler */
t5=*((C_word*)lf[50]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t3,t4);}

/* a1223 in a1192 in k1015 in k1012 in k1009 in k1006 in k1003 in body91 in file-copy in k601 in k598 in k595 in k592 */
static void C_ccall f_1224(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1224,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1230,a[2]=((C_word*)t0)[3],a[3]=((C_word)li33),tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1236,a[2]=((C_word*)t0)[2],a[3]=((C_word)li35),tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 213  ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a1235 in a1223 in a1192 in k1015 in k1012 in k1009 in k1006 in k1003 in body91 in file-copy in k601 in k598 in k595 in k592 */
static void C_ccall f_1236(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_1236r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1236r(t0,t1,t2);}}

static void C_ccall f_1236r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1242,a[2]=t2,a[3]=((C_word)li34),tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 213  g108 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a1241 in a1235 in a1223 in a1192 in k1015 in k1012 in k1009 in k1006 in k1003 in body91 in file-copy in k601 in k598 in k595 in k592 */
static void C_ccall f_1242(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1242,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a1229 in a1223 in a1192 in k1015 in k1012 in k1009 in k1006 in k1003 in body91 in file-copy in k601 in k598 in k595 in k592 */
static void C_ccall f_1230(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1230,2,t0,t1);}
/* utils.scm: 213  open-input-file */
t2=*((C_word*)lf[56]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* a1198 in a1192 in k1015 in k1012 in k1009 in k1006 in k1003 in body91 in file-copy in k601 in k598 in k595 in k592 */
static void C_ccall f_1199(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1199,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1205,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word)li31),tmp=(C_word)a,a+=5,tmp);
/* utils.scm: 213  g108 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a1204 in a1198 in a1192 in k1015 in k1012 in k1009 in k1006 in k1003 in body91 in file-copy in k601 in k598 in k595 in k592 */
static void C_ccall f_1205(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1205,2,t0,t1);}
t2=(C_word)C_i_structurep(((C_word*)t0)[3],lf[46]);
t3=(C_truep(t2)?(C_word)C_slot(((C_word*)t0)[3],C_fix(1)):C_SCHEME_FALSE);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1216,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* utils.scm: 215  string-append */
t5=*((C_word*)lf[47]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,lf[55],((C_word*)t0)[2]);}

/* k1214 in a1204 in a1198 in a1192 in k1015 in k1012 in k1009 in k1006 in k1003 in body91 in file-copy in k601 in k598 in k595 in k592 */
static void C_ccall f_1216(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 215  ##sys#error */
t2=*((C_word*)lf[15]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1189 in k1015 in k1012 in k1009 in k1006 in k1003 in body91 in file-copy in k601 in k598 in k595 in k592 */
static void C_ccall f_1191(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in body91 in file-copy in k601 in k598 in k595 in k592 */
static void C_ccall f_1020(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1020,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1023,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1133,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1135,a[2]=((C_word*)t0)[2],a[3]=((C_word)li30),tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 218  call-with-current-continuation */
t5=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a1134 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in body91 in file-copy in k601 in k598 in k595 in k592 */
static void C_ccall f_1135(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1135,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1141,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li25),tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1166,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li29),tmp=(C_word)a,a+=5,tmp);
/* utils.scm: 218  with-exception-handler */
t5=*((C_word*)lf[50]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t3,t4);}

/* a1165 in a1134 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in body91 in file-copy in k601 in k598 in k595 in k592 */
static void C_ccall f_1166(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1166,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1172,a[2]=((C_word*)t0)[3],a[3]=((C_word)li26),tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1178,a[2]=((C_word*)t0)[2],a[3]=((C_word)li28),tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 218  ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a1177 in a1165 in a1134 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in body91 in file-copy in k601 in k598 in k595 in k592 */
static void C_ccall f_1178(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_1178r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1178r(t0,t1,t2);}}

static void C_ccall f_1178r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1184,a[2]=t2,a[3]=((C_word)li27),tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 218  g118 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a1183 in a1177 in a1165 in a1134 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in body91 in file-copy in k601 in k598 in k595 in k592 */
static void C_ccall f_1184(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1184,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a1171 in a1165 in a1134 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in body91 in file-copy in k601 in k598 in k595 in k592 */
static void C_ccall f_1172(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1172,2,t0,t1);}
/* utils.scm: 218  open-output-file */
t2=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* a1140 in a1134 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in body91 in file-copy in k601 in k598 in k595 in k592 */
static void C_ccall f_1141(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1141,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1147,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word)li24),tmp=(C_word)a,a+=5,tmp);
/* utils.scm: 218  g118 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a1146 in a1140 in a1134 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in body91 in file-copy in k601 in k598 in k595 in k592 */
static void C_ccall f_1147(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1147,2,t0,t1);}
t2=(C_word)C_i_structurep(((C_word*)t0)[3],lf[46]);
t3=(C_truep(t2)?(C_word)C_slot(((C_word*)t0)[3],C_fix(1)):C_SCHEME_FALSE);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1158,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* utils.scm: 220  string-append */
t5=*((C_word*)lf[47]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,lf[53],((C_word*)t0)[2]);}

/* k1156 in a1146 in a1140 in a1134 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in body91 in file-copy in k601 in k598 in k595 in k592 */
static void C_ccall f_1158(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 220  ##sys#error */
t2=*((C_word*)lf[15]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1131 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in body91 in file-copy in k601 in k598 in k595 in k592 */
static void C_ccall f_1133(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in body91 in file-copy in k601 in k598 in k595 in k592 */
static void C_ccall f_1023(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1023,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1026,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* utils.scm: 223  make-string */
t3=*((C_word*)lf[52]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in body91 in file-copy in k601 in k598 in k595 in k592 */
static void C_ccall f_1026(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1026,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1033,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* utils.scm: 224  read-string! */
t3=*((C_word*)lf[45]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[3],t1,((C_word*)t0)[4]);}

/* k1031 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in body91 in file-copy in k601 in k598 in k595 in k592 */
static void C_ccall f_1033(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1033,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1035,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word)li23),tmp=(C_word)a,a+=8,tmp));
t5=((C_word*)t3)[1];
f_1035(t5,((C_word*)t0)[2],t1,C_fix(0));}

/* loop in k1031 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in body91 in file-copy in k601 in k598 in k595 in k592 */
static void C_fcall f_1035(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1035,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_eqp(C_fix(0),t4);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1045,a[2]=((C_word*)t0)[6],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* utils.scm: 228  close-input-port */
t7=*((C_word*)lf[44]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,((C_word*)t0)[5]);}
else{
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1051,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],a[7]=t3,a[8]=t2,tmp=(C_word)a,a+=9,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1065,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1067,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t3,a[7]=((C_word)li22),tmp=(C_word)a,a+=8,tmp);
/* utils.scm: 232  call-with-current-continuation */
t9=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t7,t8);}}

/* a1066 in loop in k1031 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in body91 in file-copy in k601 in k598 in k595 in k592 */
static void C_ccall f_1067(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1067,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1073,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word)li17),tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1108,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word)li21),tmp=(C_word)a,a+=7,tmp);
/* utils.scm: 232  with-exception-handler */
t5=*((C_word*)lf[50]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t3,t4);}

/* a1107 in a1066 in loop in k1031 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in body91 in file-copy in k601 in k598 in k595 in k592 */
static void C_ccall f_1108(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1108,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1114,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word)li18),tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1120,a[2]=((C_word*)t0)[2],a[3]=((C_word)li20),tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 232  ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a1119 in a1107 in a1066 in loop in k1031 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in body91 in file-copy in k601 in k598 in k595 in k592 */
static void C_ccall f_1120(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_1120r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1120r(t0,t1,t2);}}

static void C_ccall f_1120r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1126,a[2]=t2,a[3]=((C_word)li19),tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 232  g133 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a1125 in a1119 in a1107 in a1066 in loop in k1031 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in body91 in file-copy in k601 in k598 in k595 in k592 */
static void C_ccall f_1126(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1126,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a1113 in a1107 in a1066 in loop in k1031 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in body91 in file-copy in k601 in k598 in k595 in k592 */
static void C_ccall f_1114(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1114,2,t0,t1);}
/* utils.scm: 232  write-string */
t2=*((C_word*)lf[49]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a1072 in a1066 in loop in k1031 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in body91 in file-copy in k601 in k598 in k595 in k592 */
static void C_ccall f_1073(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1073,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1079,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=((C_word)li16),tmp=(C_word)a,a+=7,tmp);
/* utils.scm: 232  g133 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a1078 in a1072 in a1066 in loop in k1031 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in body91 in file-copy in k601 in k598 in k595 in k592 */
static void C_ccall f_1079(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1079,2,t0,t1);}
t2=(C_word)C_i_structurep(((C_word*)t0)[5],lf[46]);
t3=(C_truep(t2)?(C_word)C_slot(((C_word*)t0)[5],C_fix(1)):C_SCHEME_FALSE);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1086,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* utils.scm: 234  close-input-port */
t5=*((C_word*)lf[44]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[2]);}

/* k1084 in a1078 in a1072 in a1066 in loop in k1031 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in body91 in file-copy in k601 in k598 in k595 in k592 */
static void C_ccall f_1086(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1086,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1089,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 235  close-output-port */
t3=*((C_word*)lf[43]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k1087 in k1084 in a1078 in a1072 in a1066 in loop in k1031 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in body91 in file-copy in k601 in k598 in k595 in k592 */
static void C_ccall f_1089(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1089,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1096,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1100,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* utils.scm: 238  number->string */
C_number_to_string(3,0,t3,((C_word*)t0)[2]);}

/* k1098 in k1087 in k1084 in a1078 in a1072 in a1066 in loop in k1031 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in body91 in file-copy in k601 in k598 in k595 in k592 */
static void C_ccall f_1100(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 236  string-append */
t2=*((C_word*)lf[47]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[48],t1);}

/* k1094 in k1087 in k1084 in a1078 in a1072 in a1066 in loop in k1031 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in body91 in file-copy in k601 in k598 in k595 in k592 */
static void C_ccall f_1096(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 236  ##sys#error */
t2=*((C_word*)lf[15]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1063 in loop in k1031 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in body91 in file-copy in k601 in k598 in k595 in k592 */
static void C_ccall f_1065(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k1049 in loop in k1031 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in body91 in file-copy in k601 in k598 in k595 in k592 */
static void C_ccall f_1051(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1051,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1058,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
/* utils.scm: 239  read-string! */
t3=*((C_word*)lf[45]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1056 in k1049 in loop in k1031 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in body91 in file-copy in k601 in k598 in k595 in k592 */
static void C_ccall f_1058(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[5],((C_word*)t0)[4]);
/* utils.scm: 239  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1035(t3,((C_word*)t0)[2],t1,t2);}

/* k1043 in loop in k1031 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in body91 in file-copy in k601 in k598 in k595 in k592 */
static void C_ccall f_1045(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1045,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1048,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 229  close-output-port */
t3=*((C_word*)lf[43]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k1046 in k1043 in loop in k1031 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in body91 in file-copy in k601 in k598 in k595 in k592 */
static void C_ccall f_1048(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* delete-file* in k601 in k598 in k595 in k592 */
static void C_ccall f_975(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_975,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_982,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* utils.scm: 195  file-exists? */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k980 in delete-file* in k601 in k598 in k595 in k592 */
static void C_ccall f_982(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_982,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_988,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* utils.scm: 195  delete-file */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k986 in k980 in delete-file* in k601 in k598 in k595 in k592 */
static void C_ccall f_988(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?C_SCHEME_TRUE:C_SCHEME_FALSE));}

/* system* in k601 in k598 in k595 in k592 */
static void C_ccall f_957(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_957r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_957r(t0,t1,t2,t3);}}

static void C_ccall f_957r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_961,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_apply(5,0,t4,((C_word*)t0)[2],t2,t3);}

/* k959 in system* in k601 in k598 in k595 in k592 */
static void C_ccall f_961(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_961,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_964,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 184  system */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k962 in k959 in system* in k601 in k598 in k595 in k592 */
static void C_ccall f_964(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(t1,C_fix(0));
if(C_truep(t2)){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
/* utils.scm: 186  ##sys#error */
t3=*((C_word*)lf[15]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],lf[38],((C_word*)t0)[2],t1);}}

/* apropos in k601 in k598 in k595 in k592 */
static void C_ccall f_865(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_865r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_865r(t0,t1,t2,t3);}}

static void C_ccall f_865r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_869,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 152  %apropos-list */
f_737(t4,lf[17],t2,t3);}

/* k867 in apropos in k601 in k598 in k595 in k592 */
static void C_ccall f_869(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_869,2,t0,t1);}
t2=C_fix(0);
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_872,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_946,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word)li12),tmp=(C_word)a,a+=5,tmp);
/* for-each */
t6=*((C_word*)lf[34]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,t1);}

/* a945 in k867 in apropos in k601 in k598 in k595 in k592 */
static void C_ccall f_946(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_946,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_955,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 156  symlen */
f_840(t3,t2);}

/* k953 in a945 in k867 in apropos in k601 in k598 in k595 in k592 */
static void C_ccall f_955(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_fixnum_max(((C_word*)((C_word*)t0)[3])[1],t1);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k870 in k867 in apropos in k601 in k598 in k595 in k592 */
static void C_ccall f_872(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_872,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_877,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word)li11),tmp=(C_word)a,a+=5,tmp);
/* for-each */
t3=*((C_word*)lf[34]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a876 in k870 in k867 in apropos in k601 in k598 in k595 in k592 */
static void C_ccall f_877(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_877,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_881,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* utils.scm: 160  display */
t4=*((C_word*)lf[28]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k879 in a876 in k870 in k867 in apropos in k601 in k598 in k595 in k592 */
static void C_ccall f_881(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_881,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_884,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_944,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 161  symlen */
f_840(t3,((C_word*)t0)[4]);}

/* k942 in k879 in a876 in k870 in k867 in apropos in k601 in k598 in k595 in k592 */
static void C_ccall f_944(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_944,2,t0,t1);}
t2=(C_word)C_fixnum_difference(((C_word*)((C_word*)t0)[3])[1],t1);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_923,a[2]=t4,a[3]=((C_word)li10),tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_923(t6,((C_word*)t0)[2],t2);}

/* do62 in k942 in k879 in a876 in k870 in k867 in apropos in k601 in k598 in k595 in k592 */
static void C_fcall f_923(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_923,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_less_or_equal_p(t2,C_fix(0)))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_933,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* utils.scm: 163  display */
t4=*((C_word*)lf[28]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,C_make_character(32));}}

/* k931 in do62 in k942 in k879 in a876 in k870 in k867 in apropos in k601 in k598 in k595 in k592 */
static void C_ccall f_933(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_difference(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_923(t3,((C_word*)t0)[2],t2);}

/* k882 in k879 in a876 in k870 in k867 in apropos in k601 in k598 in k595 in k592 */
static void C_ccall f_884(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_884,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_887,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 164  display */
t3=*((C_word*)lf[28]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,C_make_character(32));}

/* k885 in k882 in k879 in a876 in k870 in k867 in apropos in k601 in k598 in k595 in k592 */
static void C_ccall f_887(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_887,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_890,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 164  display */
t3=*((C_word*)lf[28]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,C_make_character(58));}

/* k888 in k885 in k882 in k879 in a876 in k870 in k867 in apropos in k601 in k598 in k595 in k592 */
static void C_ccall f_890(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_890,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_893,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 164  display */
t3=*((C_word*)lf[28]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,C_make_character(32));}

/* k891 in k888 in k885 in k882 in k879 in a876 in k870 in k867 in apropos in k601 in k598 in k595 in k592 */
static void C_ccall f_893(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_893,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_896,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_902,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 165  macro? */
t4=*((C_word*)lf[33]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k900 in k891 in k888 in k885 in k882 in k879 in a876 in k870 in k867 in apropos in k601 in k598 in k595 in k592 */
static void C_ccall f_902(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_902,2,t0,t1);}
if(C_truep(t1)){
/* utils.scm: 167  display */
t2=*((C_word*)lf[28]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],lf[29]);}
else{
t2=(C_word)C_retrieve(((C_word*)t0)[2]);
if(C_truep((C_word)C_i_closurep(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_813,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* utils.scm: 135  procedure-information */
t4=*((C_word*)lf[31]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}
else{
/* utils.scm: 172  display */
t3=*((C_word*)lf[28]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[3],lf[32]);}}}

/* k811 in k900 in k891 in k888 in k885 in k882 in k879 in a876 in k870 in k867 in apropos in k601 in k598 in k595 in k592 */
static void C_ccall f_813(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_813,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(C_word)C_i_cdr(t1);
t3=(C_word)C_a_i_cons(&a,2,lf[30],t2);
/* utils.scm: 136  display */
t4=*((C_word*)lf[28]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,((C_word*)t0)[2],t3);}
else{
if(C_truep(t1)){
/* utils.scm: 137  display */
t2=*((C_word*)lf[28]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],lf[30]);}
else{
/* utils.scm: 138  display */
t2=*((C_word*)lf[28]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],lf[30]);}}}

/* k894 in k891 in k888 in k885 in k882 in k879 in a876 in k870 in k867 in apropos in k601 in k598 in k595 in k592 */
static void C_ccall f_896(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 173  newline */
t2=*((C_word*)lf[27]+1);
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* apropos-list in k601 in k598 in k595 in k592 */
static void C_ccall f_859(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3r,(void*)f_859r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_859r(t0,t1,t2,t3);}}

static void C_ccall f_859r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
/* utils.scm: 148  %apropos-list */
f_737(t1,lf[16],t2,t3);}

/* symlen in k601 in k598 in k595 in k592 */
static void C_fcall f_840(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_840,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_857,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 141  ##sys#symbol->qualified-string */
t4=*((C_word*)lf[26]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k855 in symlen in k601 in k598 in k595 in k592 */
static void C_ccall f_857(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_857,2,t0,t1);}
t2=(C_word)C_block_size(t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_850,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 142  keyword? */
t4=*((C_word*)lf[25]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k848 in k855 in symlen in k601 in k598 in k595 in k592 */
static void C_ccall f_850(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?(C_word)C_fixnum_difference(((C_word*)t0)[2],C_fix(2)):((C_word*)t0)[2]));}

/* %apropos-list in k601 in k598 in k595 in k592 */
static void C_fcall f_737(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_737,NULL,4,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_741,a[2]=t3,a[3]=t1,a[4]=t2,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* utils.scm: 116  interaction-environment */
t6=*((C_word*)lf[24]+1);
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}

/* k739 in %apropos-list in k601 in k598 in k595 in k592 */
static void C_ccall f_741(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_741,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_773,a[2]=t3,a[3]=t5,a[4]=((C_word)li6),tmp=(C_word)a,a+=5,tmp);
t7=f_773(t6,((C_word*)t0)[5]);
t8=(C_word)C_i_check_structure_2(((C_word*)t3)[1],lf[19],((C_word*)t0)[4]);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_750,a[2]=t5,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t10=(C_word)C_i_stringp(((C_word*)t0)[2]);
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_759,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=t9,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t10)){
t12=t11;
f_759(2,t12,t10);}
else{
t12=(C_word)C_i_symbolp(((C_word*)t0)[2]);
if(C_truep(t12)){
t13=t11;
f_759(2,t13,t12);}
else{
/* utils.scm: 130  regexp? */
t13=*((C_word*)lf[23]+1);
((C_proc3)C_retrieve_proc(t13))(3,t13,t11,((C_word*)t0)[2]);}}}

/* k757 in k739 in %apropos-list in k601 in k598 in k595 in k592 */
static void C_ccall f_759(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_750(2,t2,C_SCHEME_UNDEFINED);}
else{
/* utils.scm: 131  ##sys#signal-hook */
t2=*((C_word*)lf[20]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[4],lf[21],((C_word*)t0)[3],lf[22],((C_word*)t0)[2]);}}

/* k748 in k739 in %apropos-list in k601 in k598 in k595 in k592 */
static void C_ccall f_750(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 132  ##sys#apropos */
t2=*((C_word*)lf[13]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1]);}

/* loop in k739 in %apropos-list in k601 in k598 in k595 in k592 */
static C_word C_fcall f_773(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
loop:
C_stack_check;
if(C_truep((C_word)C_i_pairp(t1))){
t2=(C_word)C_i_car(t1);
t3=(C_word)C_eqp(lf[18],t2);
if(C_truep(t3)){
t4=(C_word)C_i_cadr(t1);
t5=C_mutate(((C_word *)((C_word*)t0)[3])+1,t4);
t6=(C_word)C_i_cddr(t1);
t10=t6;
t1=t10;
goto loop;}
else{
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=(C_word)C_i_cdr(t1);
t10=t5;
t1=t10;
goto loop;}}
else{
return(C_SCHEME_UNDEFINED);}}

/* ##sys#apropos in k601 in k598 in k595 in k592 */
static void C_ccall f_692(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_692r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_692r(t0,t1,t2,t3,t4);}}

static void C_ccall f_692r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_696,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_696(2,t6,C_SCHEME_FALSE);}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_696(2,t7,(C_word)C_i_car(t4));}
else{
/* ##sys#error */
t7=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* k694 in ##sys#apropos in k601 in k598 in k595 in k592 */
static void C_ccall f_696(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_696,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_699,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* utils.scm: 107  ##sys#apropos-interned */
t3=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k697 in k694 in ##sys#apropos in k601 in k598 in k595 in k592 */
static void C_ccall f_699(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_699,2,t0,t1);}
if(C_truep(((C_word*)t0)[5])){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_709,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 109  ##sys#apropos-macros */
t3=*((C_word*)lf[4]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}}

/* k707 in k697 in k694 in ##sys#apropos in k601 in k598 in k595 in k592 */
static void C_ccall f_709(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 109  ##sys#append */
t2=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* ##sys#apropos-macros in k601 in k598 in k595 in k592 */
static void C_ccall f_665(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_665,4,t0,t1,t2,t3);}
t4=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_670,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* utils.scm: 97   makpat */
t6=((C_word*)t0)[2];
f_612(t6,t5,((C_word*)t4)[1]);}

/* k668 in ##sys#apropos-macros in k601 in k598 in k595 in k592 */
static void C_ccall f_670(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_670,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_673,a[2]=t4,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_675,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=t4,a[5]=((C_word)li3),tmp=(C_word)a,a+=6,tmp);
/* utils.scm: 99   ##sys#hash-table-for-each */
t7=*((C_word*)lf[11]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,*((C_word*)lf[12]+1));}

/* a674 in k668 in ##sys#apropos-macros in k601 in k598 in k595 in k592 */
static void C_ccall f_675(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_675,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_682,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_690,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* utils.scm: 101  symbol->string */
t6=*((C_word*)lf[8]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k688 in a674 in k668 in ##sys#apropos-macros in k601 in k598 in k595 in k592 */
static void C_ccall f_690(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 101  string-search */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t1);}

/* k680 in a674 in k668 in ##sys#apropos-macros in k601 in k598 in k595 in k592 */
static void C_ccall f_682(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_682,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k671 in k668 in ##sys#apropos-macros in k601 in k598 in k595 in k592 */
static void C_ccall f_673(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* ##sys#apropos-interned in k601 in k598 in k595 in k592 */
static void C_ccall f_639(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_639,4,t0,t1,t2,t3);}
t4=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_644,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* utils.scm: 89   makpat */
t6=((C_word*)t0)[2];
f_612(t6,t5,((C_word*)t4)[1]);}

/* k642 in ##sys#apropos-interned in k601 in k598 in k595 in k592 */
static void C_ccall f_644(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_644,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_649,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],a[4]=((C_word)li1),tmp=(C_word)a,a+=5,tmp);
/* utils.scm: 90   ##sys#environment-symbols */
t4=*((C_word*)lf[10]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* a648 in k642 in ##sys#apropos-interned in k601 in k598 in k595 in k592 */
static void C_ccall f_649(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_649,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_656,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_663,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* utils.scm: 92   symbol->string */
t5=*((C_word*)lf[8]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k661 in a648 in k642 in ##sys#apropos-interned in k601 in k598 in k595 in k592 */
static void C_ccall f_663(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 92   string-search */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t1);}

/* k654 in a648 in k642 in ##sys#apropos-interned in k601 in k598 in k595 in k592 */
static void C_ccall f_656(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* utils.scm: 93   ##sys#symbol-has-toplevel-binding? */
t2=*((C_word*)lf[9]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* makpat in k601 in k598 in k595 in k592 */
static void C_fcall f_612(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_612,NULL,3,t0,t1,t2);}
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_616,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t3)[1]))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_637,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 82   symbol->string */
t6=*((C_word*)lf[8]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t3)[1]);}
else{
t5=t4;
f_616(t5,C_SCHEME_UNDEFINED);}}

/* k635 in makpat in k601 in k598 in k595 in k592 */
static void C_ccall f_637(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_616(t3,t2);}

/* k614 in makpat in k601 in k598 in k595 in k592 */
static void C_fcall f_616(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_616,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_619,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_stringp(((C_word*)((C_word*)t0)[4])[1]))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_626,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_630,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 84   regexp-escape */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)((C_word*)t0)[4])[1]);}
else{
t3=t2;
f_619(t3,C_SCHEME_UNDEFINED);}}

/* k628 in k614 in makpat in k601 in k598 in k595 in k592 */
static void C_ccall f_630(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 84   regexp */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k624 in k614 in makpat in k601 in k598 in k595 in k592 */
static void C_ccall f_626(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_619(t3,t2);}

/* k617 in k614 in makpat in k601 in k598 in k595 in k592 */
static void C_fcall f_619(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[292] = {
{"toplevelutils.scm",(void*)C_utils_toplevel},
{"f_594utils.scm",(void*)f_594},
{"f_597utils.scm",(void*)f_597},
{"f_600utils.scm",(void*)f_600},
{"f_603utils.scm",(void*)f_603},
{"f_2972utils.scm",(void*)f_2972},
{"f_1750utils.scm",(void*)f_1750},
{"f_1753utils.scm",(void*)f_1753},
{"f_2137utils.scm",(void*)f_2137},
{"f_2140utils.scm",(void*)f_2140},
{"f_2818utils.scm",(void*)f_2818},
{"f_2917utils.scm",(void*)f_2917},
{"f_2923utils.scm",(void*)f_2923},
{"f_2939utils.scm",(void*)f_2939},
{"f_2942utils.scm",(void*)f_2942},
{"f_2882utils.scm",(void*)f_2882},
{"f_2888utils.scm",(void*)f_2888},
{"f_2898utils.scm",(void*)f_2898},
{"f_2862utils.scm",(void*)f_2862},
{"f_2827utils.scm",(void*)f_2827},
{"f_2833utils.scm",(void*)f_2833},
{"f_2843utils.scm",(void*)f_2843},
{"f_2794utils.scm",(void*)f_2794},
{"f_2812utils.scm",(void*)f_2812},
{"f_2800utils.scm",(void*)f_2800},
{"f_2806utils.scm",(void*)f_2806},
{"f_2769utils.scm",(void*)f_2769},
{"f_2775utils.scm",(void*)f_2775},
{"f_2779utils.scm",(void*)f_2779},
{"f_2792utils.scm",(void*)f_2792},
{"f_2737utils.scm",(void*)f_2737},
{"f_2743utils.scm",(void*)f_2743},
{"f_2747utils.scm",(void*)f_2747},
{"f_2767utils.scm",(void*)f_2767},
{"f_2713utils.scm",(void*)f_2713},
{"f_2719utils.scm",(void*)f_2719},
{"f_2723utils.scm",(void*)f_2723},
{"f_2732utils.scm",(void*)f_2732},
{"f_2689utils.scm",(void*)f_2689},
{"f_2632utils.scm",(void*)f_2632},
{"f_2636utils.scm",(void*)f_2636},
{"f_2589utils.scm",(void*)f_2589},
{"f_2593utils.scm",(void*)f_2593},
{"f_2599utils.scm",(void*)f_2599},
{"f_2607utils.scm",(void*)f_2607},
{"f_2544utils.scm",(void*)f_2544},
{"f_2569utils.scm",(void*)f_2569},
{"f_2583utils.scm",(void*)f_2583},
{"f_2562utils.scm",(void*)f_2562},
{"f_2508utils.scm",(void*)f_2508},
{"f_2515utils.scm",(void*)f_2515},
{"f_2520utils.scm",(void*)f_2520},
{"f_2524utils.scm",(void*)f_2524},
{"f_2533utils.scm",(void*)f_2533},
{"f_2463utils.scm",(void*)f_2463},
{"f_2471utils.scm",(void*)f_2471},
{"f_2473utils.scm",(void*)f_2473},
{"f_2398utils.scm",(void*)f_2398},
{"f_2402utils.scm",(void*)f_2402},
{"f_2455utils.scm",(void*)f_2455},
{"f_2405utils.scm",(void*)f_2405},
{"f_2416utils.scm",(void*)f_2416},
{"f_2446utils.scm",(void*)f_2446},
{"f_2442utils.scm",(void*)f_2442},
{"f_2423utils.scm",(void*)f_2423},
{"f_2429utils.scm",(void*)f_2429},
{"f_2437utils.scm",(void*)f_2437},
{"f_2380utils.scm",(void*)f_2380},
{"f_2392utils.scm",(void*)f_2392},
{"f_2386utils.scm",(void*)f_2386},
{"f_2362utils.scm",(void*)f_2362},
{"f_2374utils.scm",(void*)f_2374},
{"f_2368utils.scm",(void*)f_2368},
{"f_2344utils.scm",(void*)f_2344},
{"f_2356utils.scm",(void*)f_2356},
{"f_2350utils.scm",(void*)f_2350},
{"f_2326utils.scm",(void*)f_2326},
{"f_2338utils.scm",(void*)f_2338},
{"f_2332utils.scm",(void*)f_2332},
{"f_2308utils.scm",(void*)f_2308},
{"f_2320utils.scm",(void*)f_2320},
{"f_2314utils.scm",(void*)f_2314},
{"f_2293utils.scm",(void*)f_2293},
{"f_2305utils.scm",(void*)f_2305},
{"f_2299utils.scm",(void*)f_2299},
{"f_2278utils.scm",(void*)f_2278},
{"f_2290utils.scm",(void*)f_2290},
{"f_2284utils.scm",(void*)f_2284},
{"f_2263utils.scm",(void*)f_2263},
{"f_2275utils.scm",(void*)f_2275},
{"f_2269utils.scm",(void*)f_2269},
{"f_2155utils.scm",(void*)f_2155},
{"f_2171utils.scm",(void*)f_2171},
{"f_2200utils.scm",(void*)f_2200},
{"f_2225utils.scm",(void*)f_2225},
{"f_2210utils.scm",(void*)f_2210},
{"f_2181utils.scm",(void*)f_2181},
{"f_2141utils.scm",(void*)f_2141},
{"f_2058utils.scm",(void*)f_2058},
{"f_2087utils.scm",(void*)f_2087},
{"f_2082utils.scm",(void*)f_2082},
{"f_2060utils.scm",(void*)f_2060},
{"f_2068utils.scm",(void*)f_2068},
{"f_2074utils.scm",(void*)f_2074},
{"f_2071utils.scm",(void*)f_2071},
{"f_1994utils.scm",(void*)f_1994},
{"f_2010utils.scm",(void*)f_2010},
{"f_2005utils.scm",(void*)f_2005},
{"f_1996utils.scm",(void*)f_1996},
{"f_2004utils.scm",(void*)f_2004},
{"f_1913utils.scm",(void*)f_1913},
{"f_1942utils.scm",(void*)f_1942},
{"f_1949utils.scm",(void*)f_1949},
{"f_1882utils.scm",(void*)f_1882},
{"f_1821utils.scm",(void*)f_1821},
{"f_1830utils.scm",(void*)f_1830},
{"f_1860utils.scm",(void*)f_1860},
{"f_1868utils.scm",(void*)f_1868},
{"f_1767utils.scm",(void*)f_1767},
{"f_1783utils.scm",(void*)f_1783},
{"f_1754utils.scm",(void*)f_1754},
{"f_1765utils.scm",(void*)f_1765},
{"f_1337utils.scm",(void*)f_1337},
{"f_1697utils.scm",(void*)f_1697},
{"f_1692utils.scm",(void*)f_1692},
{"f_1339utils.scm",(void*)f_1339},
{"f_1352utils.scm",(void*)f_1352},
{"f_1685utils.scm",(void*)f_1685},
{"f_1681utils.scm",(void*)f_1681},
{"f_1355utils.scm",(void*)f_1355},
{"f_1358utils.scm",(void*)f_1358},
{"f_1674utils.scm",(void*)f_1674},
{"f_1361utils.scm",(void*)f_1361},
{"f_1657utils.scm",(void*)f_1657},
{"f_1667utils.scm",(void*)f_1667},
{"f_1364utils.scm",(void*)f_1364},
{"f_1601utils.scm",(void*)f_1601},
{"f_1632utils.scm",(void*)f_1632},
{"f_1644utils.scm",(void*)f_1644},
{"f_1650utils.scm",(void*)f_1650},
{"f_1638utils.scm",(void*)f_1638},
{"f_1607utils.scm",(void*)f_1607},
{"f_1613utils.scm",(void*)f_1613},
{"f_1624utils.scm",(void*)f_1624},
{"f_1599utils.scm",(void*)f_1599},
{"f_1367utils.scm",(void*)f_1367},
{"f_1543utils.scm",(void*)f_1543},
{"f_1574utils.scm",(void*)f_1574},
{"f_1586utils.scm",(void*)f_1586},
{"f_1592utils.scm",(void*)f_1592},
{"f_1580utils.scm",(void*)f_1580},
{"f_1549utils.scm",(void*)f_1549},
{"f_1555utils.scm",(void*)f_1555},
{"f_1566utils.scm",(void*)f_1566},
{"f_1541utils.scm",(void*)f_1541},
{"f_1370utils.scm",(void*)f_1370},
{"f_1373utils.scm",(void*)f_1373},
{"f_1380utils.scm",(void*)f_1380},
{"f_1382utils.scm",(void*)f_1382},
{"f_1475utils.scm",(void*)f_1475},
{"f_1516utils.scm",(void*)f_1516},
{"f_1528utils.scm",(void*)f_1528},
{"f_1534utils.scm",(void*)f_1534},
{"f_1522utils.scm",(void*)f_1522},
{"f_1481utils.scm",(void*)f_1481},
{"f_1487utils.scm",(void*)f_1487},
{"f_1494utils.scm",(void*)f_1494},
{"f_1497utils.scm",(void*)f_1497},
{"f_1508utils.scm",(void*)f_1508},
{"f_1504utils.scm",(void*)f_1504},
{"f_1473utils.scm",(void*)f_1473},
{"f_1459utils.scm",(void*)f_1459},
{"f_1466utils.scm",(void*)f_1466},
{"f_1392utils.scm",(void*)f_1392},
{"f_1395utils.scm",(void*)f_1395},
{"f_1403utils.scm",(void*)f_1403},
{"f_1434utils.scm",(void*)f_1434},
{"f_1446utils.scm",(void*)f_1446},
{"f_1452utils.scm",(void*)f_1452},
{"f_1440utils.scm",(void*)f_1440},
{"f_1409utils.scm",(void*)f_1409},
{"f_1415utils.scm",(void*)f_1415},
{"f_1426utils.scm",(void*)f_1426},
{"f_1401utils.scm",(void*)f_1401},
{"f_1398utils.scm",(void*)f_1398},
{"f_990utils.scm",(void*)f_990},
{"f_1289utils.scm",(void*)f_1289},
{"f_1284utils.scm",(void*)f_1284},
{"f_992utils.scm",(void*)f_992},
{"f_1005utils.scm",(void*)f_1005},
{"f_1277utils.scm",(void*)f_1277},
{"f_1273utils.scm",(void*)f_1273},
{"f_1008utils.scm",(void*)f_1008},
{"f_1011utils.scm",(void*)f_1011},
{"f_1266utils.scm",(void*)f_1266},
{"f_1014utils.scm",(void*)f_1014},
{"f_1249utils.scm",(void*)f_1249},
{"f_1259utils.scm",(void*)f_1259},
{"f_1017utils.scm",(void*)f_1017},
{"f_1193utils.scm",(void*)f_1193},
{"f_1224utils.scm",(void*)f_1224},
{"f_1236utils.scm",(void*)f_1236},
{"f_1242utils.scm",(void*)f_1242},
{"f_1230utils.scm",(void*)f_1230},
{"f_1199utils.scm",(void*)f_1199},
{"f_1205utils.scm",(void*)f_1205},
{"f_1216utils.scm",(void*)f_1216},
{"f_1191utils.scm",(void*)f_1191},
{"f_1020utils.scm",(void*)f_1020},
{"f_1135utils.scm",(void*)f_1135},
{"f_1166utils.scm",(void*)f_1166},
{"f_1178utils.scm",(void*)f_1178},
{"f_1184utils.scm",(void*)f_1184},
{"f_1172utils.scm",(void*)f_1172},
{"f_1141utils.scm",(void*)f_1141},
{"f_1147utils.scm",(void*)f_1147},
{"f_1158utils.scm",(void*)f_1158},
{"f_1133utils.scm",(void*)f_1133},
{"f_1023utils.scm",(void*)f_1023},
{"f_1026utils.scm",(void*)f_1026},
{"f_1033utils.scm",(void*)f_1033},
{"f_1035utils.scm",(void*)f_1035},
{"f_1067utils.scm",(void*)f_1067},
{"f_1108utils.scm",(void*)f_1108},
{"f_1120utils.scm",(void*)f_1120},
{"f_1126utils.scm",(void*)f_1126},
{"f_1114utils.scm",(void*)f_1114},
{"f_1073utils.scm",(void*)f_1073},
{"f_1079utils.scm",(void*)f_1079},
{"f_1086utils.scm",(void*)f_1086},
{"f_1089utils.scm",(void*)f_1089},
{"f_1100utils.scm",(void*)f_1100},
{"f_1096utils.scm",(void*)f_1096},
{"f_1065utils.scm",(void*)f_1065},
{"f_1051utils.scm",(void*)f_1051},
{"f_1058utils.scm",(void*)f_1058},
{"f_1045utils.scm",(void*)f_1045},
{"f_1048utils.scm",(void*)f_1048},
{"f_975utils.scm",(void*)f_975},
{"f_982utils.scm",(void*)f_982},
{"f_988utils.scm",(void*)f_988},
{"f_957utils.scm",(void*)f_957},
{"f_961utils.scm",(void*)f_961},
{"f_964utils.scm",(void*)f_964},
{"f_865utils.scm",(void*)f_865},
{"f_869utils.scm",(void*)f_869},
{"f_946utils.scm",(void*)f_946},
{"f_955utils.scm",(void*)f_955},
{"f_872utils.scm",(void*)f_872},
{"f_877utils.scm",(void*)f_877},
{"f_881utils.scm",(void*)f_881},
{"f_944utils.scm",(void*)f_944},
{"f_923utils.scm",(void*)f_923},
{"f_933utils.scm",(void*)f_933},
{"f_884utils.scm",(void*)f_884},
{"f_887utils.scm",(void*)f_887},
{"f_890utils.scm",(void*)f_890},
{"f_893utils.scm",(void*)f_893},
{"f_902utils.scm",(void*)f_902},
{"f_813utils.scm",(void*)f_813},
{"f_896utils.scm",(void*)f_896},
{"f_859utils.scm",(void*)f_859},
{"f_840utils.scm",(void*)f_840},
{"f_857utils.scm",(void*)f_857},
{"f_850utils.scm",(void*)f_850},
{"f_737utils.scm",(void*)f_737},
{"f_741utils.scm",(void*)f_741},
{"f_759utils.scm",(void*)f_759},
{"f_750utils.scm",(void*)f_750},
{"f_773utils.scm",(void*)f_773},
{"f_692utils.scm",(void*)f_692},
{"f_696utils.scm",(void*)f_696},
{"f_699utils.scm",(void*)f_699},
{"f_709utils.scm",(void*)f_709},
{"f_665utils.scm",(void*)f_665},
{"f_670utils.scm",(void*)f_670},
{"f_675utils.scm",(void*)f_675},
{"f_690utils.scm",(void*)f_690},
{"f_682utils.scm",(void*)f_682},
{"f_673utils.scm",(void*)f_673},
{"f_639utils.scm",(void*)f_639},
{"f_644utils.scm",(void*)f_644},
{"f_649utils.scm",(void*)f_649},
{"f_663utils.scm",(void*)f_663},
{"f_656utils.scm",(void*)f_656},
{"f_612utils.scm",(void*)f_612},
{"f_637utils.scm",(void*)f_637},
{"f_616utils.scm",(void*)f_616},
{"f_630utils.scm",(void*)f_630},
{"f_626utils.scm",(void*)f_626},
{"f_619utils.scm",(void*)f_619},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
