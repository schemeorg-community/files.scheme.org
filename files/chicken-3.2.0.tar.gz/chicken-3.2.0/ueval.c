/* Generated from eval.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-04-30 11:26
   Version 3.1.10 - linux-unix-gnu-x86	[ manyargs dload ptables applyhook ]
   SVN rev. 10602	compiled 2008-04-30 on galinha (Linux)
   command line: eval.scm -quiet -no-trace -optimize-level 2 -include-path . -explicit-use -unsafe -no-lambda-info -output-file ueval.c
   unit: eval
*/

#include "chicken.h"


#ifndef C_INSTALL_EGG_HOME
# define C_INSTALL_EGG_HOME    "."
#endif

#ifndef C_INSTALL_SHARE_HOME
# define C_INSTALL_SHARE_HOME NULL
#endif


#define C_store_result(x, ptr)   (*((C_word *)C_block_item(ptr, 0)) = (x), C_SCHEME_TRUE)


#define C_copy_result_string(str, buf, n)  (C_memcpy((char *)C_block_item(buf, 0), C_c_string(str), C_unfix(n)), ((char *)C_block_item(buf, 0))[ C_unfix(n) ] = '\0', C_SCHEME_TRUE)


C_externexport  void  CHICKEN_get_error_message(char *t0,int t1);

C_externexport  int  CHICKEN_load(char * t0);

C_externexport  int  CHICKEN_read(char * t0,C_word *t1);

C_externexport  int  CHICKEN_apply_to_string(C_word t0,C_word t1,char *t2,int t3);

C_externexport  int  CHICKEN_apply(C_word t0,C_word t1,C_word *t2);

C_externexport  int  CHICKEN_eval_string_to_string(char * t0,char *t1,int t2);

C_externexport  int  CHICKEN_eval_to_string(C_word t0,char *t1,int t2);

C_externexport  int  CHICKEN_eval_string(char * t0,C_word *t1);

C_externexport  int  CHICKEN_eval(C_word t0,C_word *t1);

C_externexport  int  CHICKEN_yield();

static C_PTABLE_ENTRY *create_ptable(void);

static C_TLS C_word lf[523];
static double C_possibly_force_alignment;


/* from ##sys#clear-trace-buffer in k8991 in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static C_word C_fcall stub1364(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub1364(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_clear_trace_buffer();
return C_r;}

C_noret_decl(C_eval_toplevel)
C_externexport void C_ccall C_eval_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1730)
static void C_ccall f_1730(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1733)
static void C_ccall f_1733(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1775)
static void C_ccall f_1775(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11451)
static void C_ccall f_11451(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_11451)
static void C_ccall f_11451r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_11455)
static void C_fcall f_11455(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11479)
static void C_ccall f_11479(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11473)
static void C_ccall f_11473(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11463)
static void C_ccall f_11463(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11461)
static void C_ccall f_11461(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6065)
static void C_ccall f_6065(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6164)
static void C_ccall f_6164(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6244)
static void C_ccall f_6244(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11445)
static void C_ccall f_11445(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11441)
static void C_ccall f_11441(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11437)
static void C_ccall f_11437(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11433)
static void C_ccall f_11433(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11423)
static void C_fcall f_11423(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6763)
static void C_fcall f_6763(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6768)
static void C_ccall f_6768(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11401)
static void C_ccall f_11401(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11393)
static void C_ccall f_11393(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11395)
static void C_ccall f_11395(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6775)
static void C_ccall f_6775(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11362)
static void C_ccall f_11362(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11382)
static void C_ccall f_11382(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11378)
static void C_ccall f_11378(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11368)
static void C_ccall f_11368(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11365)
static void C_ccall f_11365(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7128)
static void C_ccall f_7128(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11308)
static void C_ccall f_11308(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11322)
static void C_fcall f_11322(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11358)
static void C_ccall f_11358(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11354)
static void C_ccall f_11354(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11342)
static void C_ccall f_11342(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11346)
static void C_ccall f_11346(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11316)
static void C_ccall f_11316(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7847)
static void C_ccall f_7847(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11187)
static void C_ccall f_11187(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11224)
static void C_fcall f_11224(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11233)
static void C_ccall f_11233(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11252)
static void C_ccall f_11252(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11256)
static void C_ccall f_11256(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11242)
static void C_ccall f_11242(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11239)
static void C_ccall f_11239(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11190)
static void C_fcall f_11190(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7850)
static void C_ccall f_7850(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7908)
static void C_ccall f_7908(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11185)
static void C_ccall f_11185(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8243)
static void C_ccall f_8243(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8247)
static void C_ccall f_8247(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11181)
static void C_ccall f_11181(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8250)
static void C_ccall f_8250(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8254)
static void C_ccall f_8254(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11084)
static void C_ccall f_11084(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11090)
static void C_fcall f_11090(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11106)
static void C_ccall f_11106(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11109)
static void C_ccall f_11109(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11144)
static void C_ccall f_11144(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11147)
static void C_ccall f_11147(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11131)
static void C_ccall f_11131(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11134)
static void C_ccall f_11134(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11141)
static void C_ccall f_11141(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8937)
static void C_ccall f_8937(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11056)
static void C_ccall f_11056(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8940)
static void C_ccall f_8940(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11013)
static void C_ccall f_11013(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11035)
static void C_ccall f_11035(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8943)
static void C_ccall f_8943(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10816)
static void C_ccall f_10816(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10822)
static void C_fcall f_10822(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10838)
static void C_ccall f_10838(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10914)
static void C_fcall f_10914(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10971)
static void C_ccall f_10971(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10917)
static void C_ccall f_10917(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10944)
static void C_ccall f_10944(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10877)
static void C_ccall f_10877(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10896)
static void C_ccall f_10896(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10868)
static void C_ccall f_10868(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8946)
static void C_ccall f_8946(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10713)
static void C_ccall f_10713(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10723)
static void C_ccall f_10723(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10736)
static void C_fcall f_10736(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10752)
static void C_ccall f_10752(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10790)
static void C_ccall f_10790(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10788)
static void C_ccall f_10788(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10780)
static void C_ccall f_10780(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10734)
static void C_ccall f_10734(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8949)
static void C_ccall f_8949(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10660)
static void C_ccall f_10660(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10670)
static void C_ccall f_10670(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10673)
static void C_ccall f_10673(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10678)
static void C_fcall f_10678(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10703)
static void C_ccall f_10703(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8952)
static void C_ccall f_8952(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10590)
static void C_ccall f_10590(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10600)
static void C_ccall f_10600(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10603)
static void C_ccall f_10603(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10650)
static void C_ccall f_10650(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10614)
static void C_ccall f_10614(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10636)
static void C_ccall f_10636(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10622)
static void C_ccall f_10622(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10618)
static void C_ccall f_10618(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8955)
static void C_ccall f_8955(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10471)
static void C_ccall f_10471(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_10471)
static void C_ccall f_10471r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_10475)
static void C_ccall f_10475(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10478)
static void C_ccall f_10478(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10481)
static void C_ccall f_10481(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10572)
static void C_ccall f_10572(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10488)
static void C_ccall f_10488(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10511)
static void C_fcall f_10511(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10525)
static void C_ccall f_10525(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10523)
static void C_ccall f_10523(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8958)
static void C_ccall f_8958(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10179)
static void C_ccall f_10179(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10389)
static void C_fcall f_10389(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10393)
static void C_ccall f_10393(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10414)
static void C_ccall f_10414(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10456)
static void C_ccall f_10456(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10192)
static void C_fcall f_10192(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10380)
static void C_ccall f_10380(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10384)
static void C_ccall f_10384(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10363)
static void C_ccall f_10363(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10367)
static void C_ccall f_10367(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10352)
static void C_ccall f_10352(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10344)
static void C_ccall f_10344(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10333)
static void C_ccall f_10333(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10299)
static void C_ccall f_10299(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10280)
static void C_ccall f_10280(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10253)
static void C_ccall f_10253(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10210)
static void C_ccall f_10210(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10206)
static void C_ccall f_10206(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10182)
static void C_fcall f_10182(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10190)
static void C_ccall f_10190(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8961)
static void C_ccall f_8961(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10169)
static void C_ccall f_10169(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8964)
static void C_ccall f_8964(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9923)
static void C_ccall f_9923(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10078)
static void C_fcall f_10078(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10149)
static void C_ccall f_10149(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10094)
static void C_ccall f_10094(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10092)
static void C_ccall f_10092(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9936)
static void C_fcall f_9936(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10062)
static void C_ccall f_10062(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10024)
static void C_ccall f_10024(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9985)
static void C_ccall f_9985(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9926)
static void C_fcall f_9926(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8967)
static void C_ccall f_8967(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8971)
static void C_ccall f_8971(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9920)
static void C_ccall f_9920(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8993)
static void C_ccall f_8993(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9353)
static void C_ccall f_9353(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9778)
static void C_ccall f_9778(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_9778)
static void C_ccall f_9778r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_9896)
static void C_ccall f_9896(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9899)
static void C_ccall f_9899(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9886)
static void C_ccall f_9886(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9781)
static void C_fcall f_9781(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9785)
static void C_fcall f_9785(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9796)
static void C_fcall f_9796(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9439)
static void C_ccall f_9439(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9759)
static void C_ccall f_9759(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_9759)
static void C_ccall f_9759r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_9763)
static void C_ccall f_9763(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9772)
static void C_ccall f_9772(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9770)
static void C_ccall f_9770(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9442)
static void C_ccall f_9442(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9753)
static void C_ccall f_9753(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9445)
static void C_ccall f_9445(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9747)
static void C_ccall f_9747(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9448)
static void C_ccall f_9448(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9738)
static void C_ccall f_9738(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9745)
static void C_ccall f_9745(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9728)
static void C_ccall f_9728(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9713)
static void C_ccall f_9713(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9717)
static void C_ccall f_9717(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9722)
static void C_ccall f_9722(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9726)
static void C_ccall f_9726(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9691)
static void C_ccall f_9691(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9695)
static void C_ccall f_9695(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9700)
static void C_ccall f_9700(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9704)
static void C_ccall f_9704(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9711)
static void C_ccall f_9711(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9665)
static void C_ccall f_9665(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_9671)
static void C_ccall f_9671(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9675)
static void C_ccall f_9675(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9689)
static void C_ccall f_9689(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9678)
static void C_ccall f_9678(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9685)
static void C_ccall f_9685(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9649)
static void C_ccall f_9649(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9655)
static void C_ccall f_9655(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9663)
static void C_ccall f_9663(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9612)
static void C_ccall f_9612(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9616)
static void C_ccall f_9616(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9621)
static void C_ccall f_9621(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9625)
static void C_ccall f_9625(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9647)
static void C_ccall f_9647(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9643)
static void C_ccall f_9643(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9639)
static void C_ccall f_9639(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9628)
static void C_ccall f_9628(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9635)
static void C_ccall f_9635(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9586)
static void C_ccall f_9586(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9592)
static void C_ccall f_9592(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9596)
static void C_ccall f_9596(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9610)
static void C_ccall f_9610(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9599)
static void C_ccall f_9599(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9606)
static void C_ccall f_9606(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9573)
static C_word C_fcall f_9573(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_9547)
static void C_ccall f_9547(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9551)
static void C_ccall f_9551(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9556)
static void C_ccall f_9556(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9560)
static void C_ccall f_9560(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9571)
static void C_ccall f_9571(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9567)
static void C_ccall f_9567(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9531)
static void C_ccall f_9531(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9537)
static void C_ccall f_9537(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9545)
static void C_ccall f_9545(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9519)
static void C_ccall f_9519(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9525)
static void C_ccall f_9525(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9529)
static void C_ccall f_9529(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9510)
static void C_fcall f_9510(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9514)
static void C_ccall f_9514(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9451)
static void C_fcall f_9451(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9461)
static void C_ccall f_9461(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9486)
static void C_ccall f_9486(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9498)
static void C_ccall f_9498(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_9498)
static void C_ccall f_9498r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_9504)
static void C_ccall f_9504(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9492)
static void C_ccall f_9492(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9467)
static void C_ccall f_9467(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9473)
static void C_ccall f_9473(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9477)
static void C_ccall f_9477(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9480)
static void C_ccall f_9480(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9484)
static void C_ccall f_9484(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9459)
static void C_ccall f_9459(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9364)
static void C_ccall f_9364(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9374)
static void C_ccall f_9374(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9377)
static void C_ccall f_9377(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9391)
static void C_fcall f_9391(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9409)
static void C_ccall f_9409(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9378)
static void C_fcall f_9378(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9355)
static void C_ccall f_9355(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9014)
static void C_ccall f_9014(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9058)
static void C_ccall f_9058(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9061)
static void C_ccall f_9061(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9338)
static void C_ccall f_9338(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9342)
static void C_ccall f_9342(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9346)
static void C_ccall f_9346(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9143)
static void C_ccall f_9143(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9149)
static void C_fcall f_9149(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9321)
static void C_ccall f_9321(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9327)
static void C_ccall f_9327(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9156)
static void C_ccall f_9156(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9159)
static void C_ccall f_9159(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9162)
static void C_ccall f_9162(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9316)
static void C_ccall f_9316(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9171)
static void C_ccall f_9171(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9174)
static void C_ccall f_9174(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9189)
static void C_ccall f_9189(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_9189)
static void C_ccall f_9189r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_9207)
static void C_fcall f_9207(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9270)
static void C_ccall f_9270(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9223)
static void C_ccall f_9223(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9228)
static void C_ccall f_9228(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9232)
static void C_ccall f_9232(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9235)
static void C_ccall f_9235(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9247)
static void C_ccall f_9247(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9250)
static void C_ccall f_9250(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9238)
static void C_ccall f_9238(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9211)
static void C_ccall f_9211(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9193)
static void C_ccall f_9193(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9039)
static void C_fcall f_9039(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9044)
static void C_ccall f_9044(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9196)
static void C_ccall f_9196(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9180)
static void C_ccall f_9180(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9078)
static void C_ccall f_9078(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9083)
static void C_ccall f_9083(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9086)
static void C_ccall f_9086(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9091)
static void C_ccall f_9091(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_9091)
static void C_ccall f_9091r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_9098)
static void C_ccall f_9098(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9138)
static void C_ccall f_9138(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9101)
static void C_ccall f_9101(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9113)
static void C_fcall f_9113(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9122)
static void C_ccall f_9122(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9116)
static void C_ccall f_9116(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9104)
static void C_ccall f_9104(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9107)
static void C_ccall f_9107(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9069)
static C_word C_fcall f_9069(C_word t0);
C_noret_decl(f_9063)
static C_word C_fcall f_9063(C_word t0);
C_noret_decl(f_9017)
static void C_fcall f_9017(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9023)
static void C_ccall f_9023(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9011)
static void C_ccall f_9011(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8995)
static void C_ccall f_8995(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9009)
static void C_ccall f_9009(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9006)
static void C_ccall f_9006(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8999)
static void C_ccall f_8999(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8976)
static void C_ccall f_8976(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8985)
static void C_ccall f_8985(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8980)
static void C_ccall f_8980(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8545)
static void C_ccall f_8545(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_8545)
static void C_ccall f_8545r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_8682)
static void C_fcall f_8682(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8687)
static void C_fcall f_8687(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8905)
static void C_ccall f_8905(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8886)
static void C_ccall f_8886(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8832)
static void C_ccall f_8832(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8703)
static void C_fcall f_8703(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8708)
static void C_fcall f_8708(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8727)
static void C_ccall f_8727(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8653)
static void C_ccall f_8653(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8659)
static C_word C_fcall f_8659(C_word t0);
C_noret_decl(f_8591)
static void C_ccall f_8591(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8595)
static void C_ccall f_8595(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8603)
static void C_fcall f_8603(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8626)
static void C_ccall f_8626(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8548)
static void C_fcall f_8548(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8555)
static void C_ccall f_8555(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8560)
static void C_fcall f_8560(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8564)
static void C_ccall f_8564(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8589)
static void C_ccall f_8589(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8578)
static void C_ccall f_8578(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8582)
static void C_ccall f_8582(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8571)
static void C_ccall f_8571(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8509)
static void C_ccall f_8509(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8531)
static void C_ccall f_8531(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8501)
static void C_ccall f_8501(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_8501)
static void C_ccall f_8501r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_8447)
static void C_ccall f_8447(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8451)
static void C_ccall f_8451(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8454)
static void C_ccall f_8454(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8457)
static void C_ccall f_8457(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8460)
static void C_ccall f_8460(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8463)
static void C_ccall f_8463(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8466)
static void C_ccall f_8466(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8469)
static void C_ccall f_8469(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8472)
static void C_ccall f_8472(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8475)
static void C_ccall f_8475(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8426)
static void C_fcall f_8426(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8430)
static void C_ccall f_8430(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8433)
static void C_ccall f_8433(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8402)
static void C_fcall f_8402(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8408)
static void C_fcall f_8408(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8418)
static void C_ccall f_8418(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8279)
static void C_ccall f_8279(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_8279)
static void C_ccall f_8279r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_8337)
static void C_ccall f_8337(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8388)
static void C_ccall f_8388(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8347)
static void C_ccall f_8347(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8349)
static void C_fcall f_8349(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8373)
static void C_ccall f_8373(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8359)
static void C_ccall f_8359(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8320)
static void C_fcall f_8320(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8285)
static void C_fcall f_8285(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8301)
static void C_ccall f_8301(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8307)
static void C_ccall f_8307(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8298)
static void C_ccall f_8298(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8260)
static void C_fcall f_8260(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8264)
static void C_ccall f_8264(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8227)
static void C_fcall f_8227(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8229)
static void C_ccall f_8229(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8233)
static void C_ccall f_8233(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8189)
static void C_ccall f_8189(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_8189)
static void C_ccall f_8189r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_8196)
static void C_ccall f_8196(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8203)
static void C_ccall f_8203(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8145)
static void C_ccall f_8145(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_8145)
static void C_ccall f_8145r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_8178)
static void C_ccall f_8178(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8165)
static void C_ccall f_8165(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8142)
static void C_ccall f_8142(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8023)
static void C_ccall f_8023(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_8023)
static void C_ccall f_8023r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_8117)
static void C_ccall f_8117(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8127)
static void C_ccall f_8127(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8115)
static void C_ccall f_8115(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8044)
static void C_fcall f_8044(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8068)
static void C_fcall f_8068(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8087)
static void C_ccall f_8087(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8062)
static void C_ccall f_8062(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7915)
static void C_ccall f_7915(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_7915)
static void C_ccall f_7915r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_7925)
static void C_ccall f_7925(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7930)
static void C_fcall f_7930(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7957)
static void C_fcall f_7957(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7990)
static void C_ccall f_7990(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7951)
static void C_ccall f_7951(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7852)
static void C_ccall f_7852(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7856)
static void C_ccall f_7856(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7864)
static void C_fcall f_7864(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7884)
static void C_fcall f_7884(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7808)
static void C_ccall f_7808(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7840)
static void C_ccall f_7840(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7826)
static void C_ccall f_7826(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7409)
static void C_ccall f_7409(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7684)
static void C_fcall f_7684(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7693)
static void C_ccall f_7693(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7719)
static void C_ccall f_7719(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7721)
static void C_fcall f_7721(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7754)
static void C_ccall f_7754(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7744)
static void C_ccall f_7744(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7739)
static void C_ccall f_7739(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7433)
static void C_fcall f_7433(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7443)
static void C_ccall f_7443(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7577)
static void C_ccall f_7577(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7658)
static void C_ccall f_7658(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7589)
static void C_ccall f_7589(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7604)
static void C_fcall f_7604(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7624)
static void C_ccall f_7624(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7622)
static void C_ccall f_7622(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7608)
static void C_fcall f_7608(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7600)
static void C_ccall f_7600(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7519)
static void C_ccall f_7519(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7537)
static void C_fcall f_7537(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7545)
static void C_fcall f_7545(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7533)
static void C_ccall f_7533(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7492)
static void C_fcall f_7492(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7455)
static void C_ccall f_7455(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7479)
static void C_ccall f_7479(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7475)
static void C_ccall f_7475(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7467)
static void C_ccall f_7467(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7458)
static void C_fcall f_7458(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7412)
static void C_fcall f_7412(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7427)
static void C_ccall f_7427(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7421)
static void C_ccall f_7421(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7360)
static void C_ccall f_7360(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7366)
static void C_fcall f_7366(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7380)
static void C_ccall f_7380(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7383)
static void C_fcall f_7383(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7390)
static void C_ccall f_7390(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7354)
static void C_ccall f_7354(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7323)
static void C_ccall f_7323(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7327)
static void C_ccall f_7327(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7352)
static void C_ccall f_7352(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7330)
static void C_ccall f_7330(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7348)
static void C_ccall f_7348(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7333)
static void C_ccall f_7333(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7340)
static void C_ccall f_7340(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7310)
static void C_ccall f_7310(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_7310)
static void C_ccall f_7310r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_7316)
static void C_ccall f_7316(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7296)
static void C_ccall f_7296(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7307)
static void C_ccall f_7307(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7276)
static void C_ccall f_7276(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_7276)
static void C_ccall f_7276r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_7282)
static void C_ccall f_7282(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7289)
static void C_ccall f_7289(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7208)
static void C_ccall f_7208(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_7208)
static void C_ccall f_7208r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_7271)
static void C_ccall f_7271(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7212)
static void C_fcall f_7212(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7215)
static void C_ccall f_7215(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7233)
static void C_ccall f_7233(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7239)
static void C_ccall f_7239(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7131)
static void C_ccall f_7131(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7205)
static void C_ccall f_7205(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7198)
static void C_ccall f_7198(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7165)
static void C_ccall f_7165(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7167)
static void C_fcall f_7167(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7180)
static void C_ccall f_7180(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7134)
static void C_fcall f_7134(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7138)
static void C_ccall f_7138(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7158)
static void C_ccall f_7158(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7144)
static void C_ccall f_7144(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7154)
static void C_ccall f_7154(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7147)
static void C_ccall f_7147(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6968)
static void C_ccall f_6968(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7073)
static void C_fcall f_7073(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7090)
static void C_ccall f_7090(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7098)
static void C_ccall f_7098(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6990)
static void C_ccall f_6990(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6995)
static void C_fcall f_6995(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7034)
static void C_ccall f_7034(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7021)
static void C_ccall f_7021(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6977)
static C_word C_fcall f_6977(C_word t0);
C_noret_decl(f_6971)
static void C_fcall f_6971(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6912)
static void C_ccall f_6912(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6921)
static void C_fcall f_6921(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6959)
static void C_ccall f_6959(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6939)
static void C_ccall f_6939(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6883)
static void C_ccall f_6883(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6883)
static void C_ccall f_6883r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6890)
static void C_ccall f_6890(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6900)
static void C_ccall f_6900(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6777)
static void C_ccall f_6777(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6781)
static void C_ccall f_6781(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6873)
static void C_ccall f_6873(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6877)
static void C_ccall f_6877(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6790)
static void C_fcall f_6790(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6859)
static void C_ccall f_6859(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6855)
static void C_ccall f_6855(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6793)
static void C_ccall f_6793(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6842)
static void C_ccall f_6842(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6845)
static void C_ccall f_6845(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6848)
static void C_ccall f_6848(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6796)
static void C_ccall f_6796(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6801)
static void C_fcall f_6801(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6835)
static void C_ccall f_6835(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6814)
static void C_ccall f_6814(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6817)
static void C_fcall f_6817(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6737)
static void C_ccall f_6737(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6737)
static void C_ccall f_6737r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6758)
static void C_ccall f_6758(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6741)
static void C_ccall f_6741(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6755)
static void C_ccall f_6755(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6744)
static void C_ccall f_6744(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6752)
static void C_ccall f_6752(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6747)
static void C_ccall f_6747(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6701)
static void C_ccall f_6701(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6701)
static void C_ccall f_6701r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6709)
static void C_ccall f_6709(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6679)
static void C_ccall f_6679(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6679)
static void C_ccall f_6679r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6292)
static void C_ccall f_6292(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_6292)
static void C_ccall f_6292r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_6634)
static void C_fcall f_6634(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6629)
static void C_fcall f_6629(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6294)
static void C_fcall f_6294(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6628)
static void C_ccall f_6628(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6298)
static void C_fcall f_6298(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6562)
static void C_ccall f_6562(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6577)
static void C_ccall f_6577(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6580)
static void C_fcall f_6580(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6583)
static void C_ccall f_6583(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6589)
static void C_ccall f_6589(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6592)
static void C_ccall f_6592(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6598)
static void C_ccall f_6598(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6301)
static void C_ccall f_6301(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6553)
static void C_ccall f_6553(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6544)
static void C_ccall f_6544(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6547)
static void C_ccall f_6547(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6307)
static void C_ccall f_6307(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6529)
static void C_ccall f_6529(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6501)
static void C_ccall f_6501(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6525)
static void C_ccall f_6525(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6521)
static void C_ccall f_6521(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6517)
static void C_ccall f_6517(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6310)
static void C_ccall f_6310(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6318)
static void C_ccall f_6318(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6488)
static void C_ccall f_6488(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6322)
static void C_ccall f_6322(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6473)
static void C_ccall f_6473(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6346)
static void C_ccall f_6346(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6350)
static void C_ccall f_6350(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6464)
static void C_ccall f_6464(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6358)
static void C_ccall f_6358(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6362)
static void C_ccall f_6362(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6458)
static void C_ccall f_6458(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6365)
static void C_ccall f_6365(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6368)
static void C_ccall f_6368(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6373)
static void C_fcall f_6373(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6383)
static void C_ccall f_6383(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6429)
static void C_ccall f_6429(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6429)
static void C_ccall f_6429r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_6438)
static void C_ccall f_6438(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6442)
static void C_ccall f_6442(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6395)
static void C_ccall f_6395(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6402)
static void C_ccall f_6402(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6413)
static void C_ccall f_6413(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6413)
static void C_ccall f_6413r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_6424)
static void C_ccall f_6424(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6417)
static void C_ccall f_6417(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6407)
static void C_ccall f_6407(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6386)
static void C_ccall f_6386(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6393)
static void C_ccall f_6393(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6355)
static void C_ccall f_6355(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6332)
static void C_ccall f_6332(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6323)
static void C_ccall f_6323(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6313)
static void C_ccall f_6313(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6246)
static void C_fcall f_6246(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6256)
static C_word C_fcall f_6256(C_word t0,C_word t1);
C_noret_decl(f_6171)
static void C_ccall f_6171(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6183)
static void C_fcall f_6183(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6196)
static void C_ccall f_6196(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6178)
static void C_ccall f_6178(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6166)
static void C_ccall f_6166(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6082)
static void C_ccall f_6082(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6095)
static void C_fcall f_6095(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6128)
static void C_ccall f_6128(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6109)
static void C_ccall f_6109(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6085)
static void C_fcall f_6085(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6068)
static void C_ccall f_6068(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6068)
static void C_ccall f_6068r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6076)
static void C_ccall f_6076(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6080)
static void C_ccall f_6080(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3829)
static void C_ccall f_3829(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_3829)
static void C_ccall f_3829r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_5813)
static void C_fcall f_5813(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_5817)
static void C_ccall f_5817(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6030)
static void C_ccall f_6030(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6006)
static void C_ccall f_6006(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6007)
static void C_ccall f_6007(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6018)
static void C_ccall f_6018(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6024)
static void C_ccall f_6024(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6022)
static void C_ccall f_6022(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5963)
static void C_ccall f_5963(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5966)
static void C_ccall f_5966(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5969)
static void C_ccall f_5969(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5972)
static void C_ccall f_5972(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5973)
static void C_ccall f_5973(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5984)
static void C_ccall f_5984(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5988)
static void C_ccall f_5988(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5992)
static void C_ccall f_5992(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5996)
static void C_ccall f_5996(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5999)
static void C_ccall f_5999(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5921)
static void C_ccall f_5921(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5924)
static void C_ccall f_5924(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5927)
static void C_ccall f_5927(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5928)
static void C_ccall f_5928(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5939)
static void C_ccall f_5939(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5943)
static void C_ccall f_5943(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5947)
static void C_ccall f_5947(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5950)
static void C_ccall f_5950(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5886)
static void C_ccall f_5886(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5889)
static void C_ccall f_5889(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5890)
static void C_ccall f_5890(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5901)
static void C_ccall f_5901(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5905)
static void C_ccall f_5905(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5908)
static void C_ccall f_5908(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5858)
static void C_ccall f_5858(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5859)
static void C_ccall f_5859(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5870)
static void C_ccall f_5870(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5873)
static void C_ccall f_5873(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5839)
static void C_ccall f_5839(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5849)
static void C_ccall f_5849(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5787)
static C_word C_fcall f_5787(C_word t0,C_word t1);
C_noret_decl(f_4057)
static void C_fcall f_4057(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_4160)
static void C_ccall f_4160(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4216)
static void C_fcall f_4216(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4245)
static void C_ccall f_4245(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4251)
static void C_ccall f_4251(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5620)
static void C_fcall f_5620(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5607)
static void C_ccall f_5607(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5568)
static void C_ccall f_5568(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5557)
static void C_ccall f_5557(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5519)
static void C_ccall f_5519(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5513)
static void C_ccall f_5513(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5467)
static void C_fcall f_5467(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5489)
static void C_ccall f_5489(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5497)
static void C_ccall f_5497(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5479)
static void C_ccall f_5479(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5461)
static void C_ccall f_5461(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5437)
static void C_ccall f_5437(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5444)
static void C_ccall f_5444(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5406)
static void C_ccall f_5406(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5409)
static void C_ccall f_5409(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5412)
static void C_ccall f_5412(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5431)
static void C_ccall f_5431(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5429)
static void C_ccall f_5429(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5419)
static void C_fcall f_5419(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5004)
static void C_ccall f_5004(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5341)
static void C_ccall f_5341(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5352)
static void C_ccall f_5352(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5346)
static void C_ccall f_5346(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5016)
static void C_ccall f_5016(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5021)
static void C_ccall f_5021(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5330)
static void C_ccall f_5330(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5324)
static void C_ccall f_5324(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5028)
static void C_ccall f_5028(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5286)
static void C_ccall f_5286(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5292)
static void C_ccall f_5292(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5292)
static void C_ccall f_5292r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_5316)
static void C_ccall f_5316(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5263)
static void C_ccall f_5263(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5269)
static void C_ccall f_5269(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5269)
static void C_ccall f_5269r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_5754)
static void C_fcall f_5754(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5285)
static void C_ccall f_5285(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5281)
static void C_ccall f_5281(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5241)
static void C_ccall f_5241(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5247)
static void C_ccall f_5247(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_5259)
static void C_ccall f_5259(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5222)
static void C_ccall f_5222(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5228)
static void C_ccall f_5228(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,...) C_noret;
C_noret_decl(f_5228)
static void C_ccall f_5228r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t7) C_noret;
C_noret_decl(f_5194)
static void C_ccall f_5194(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5200)
static void C_ccall f_5200(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5175)
static void C_ccall f_5175(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5181)
static void C_ccall f_5181(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_5181)
static void C_ccall f_5181r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_5147)
static void C_ccall f_5147(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5153)
static void C_ccall f_5153(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5128)
static void C_ccall f_5128(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5134)
static void C_ccall f_5134(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5134)
static void C_ccall f_5134r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5100)
static void C_ccall f_5100(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5106)
static void C_ccall f_5106(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5081)
static void C_ccall f_5081(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5087)
static void C_ccall f_5087(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5087)
static void C_ccall f_5087r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5057)
static void C_ccall f_5057(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5063)
static void C_ccall f_5063(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5038)
static void C_ccall f_5038(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5044)
static void C_ccall f_5044(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5044)
static void C_ccall f_5044r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4666)
static void C_ccall f_4666(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4991)
static void C_ccall f_4991(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4675)
static void C_ccall f_4675(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4985)
static void C_ccall f_4985(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4979)
static void C_ccall f_4979(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4681)
static void C_ccall f_4681(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4963)
static void C_ccall f_4963(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4916)
static void C_ccall f_4916(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4917)
static void C_ccall f_4917(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4921)
static void C_ccall f_4921(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4933)
static void C_fcall f_4933(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4958)
static void C_ccall f_4958(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4924)
static void C_ccall f_4924(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4840)
static void C_ccall f_4840(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4901)
static void C_ccall f_4901(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4843)
static void C_ccall f_4843(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4849)
static void C_ccall f_4849(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4885)
static void C_ccall f_4885(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4852)
static void C_ccall f_4852(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4853)
static void C_ccall f_4853(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4869)
static void C_ccall f_4869(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4873)
static void C_ccall f_4873(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4877)
static void C_ccall f_4877(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4881)
static void C_ccall f_4881(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4773)
static void C_ccall f_4773(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4819)
static void C_ccall f_4819(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4776)
static void C_ccall f_4776(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4782)
static void C_ccall f_4782(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4783)
static void C_ccall f_4783(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4799)
static void C_ccall f_4799(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4803)
static void C_ccall f_4803(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4807)
static void C_ccall f_4807(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4724)
static void C_ccall f_4724(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4752)
static void C_ccall f_4752(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4727)
static void C_ccall f_4727(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4728)
static void C_ccall f_4728(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4744)
static void C_ccall f_4744(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4748)
static void C_ccall f_4748(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4690)
static void C_ccall f_4690(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4691)
static void C_ccall f_4691(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4707)
static void C_ccall f_4707(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4557)
static void C_ccall f_4557(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4571)
static void C_ccall f_4571(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4575)
static void C_ccall f_4575(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4584)
static void C_ccall f_4584(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4617)
static void C_ccall f_4617(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4625)
static void C_ccall f_4625(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4590)
static void C_ccall f_4590(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4593)
static void C_ccall f_4593(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4609)
static void C_ccall f_4609(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4600)
static void C_ccall f_4600(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4608)
static void C_ccall f_4608(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4645)
static void C_ccall f_4645(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4653)
static void C_ccall f_4653(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4632)
static void C_ccall f_4632(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4644)
static void C_ccall f_4644(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4565)
static void C_ccall f_4565(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4449)
static void C_ccall f_4449(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4508)
static void C_ccall f_4508(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4511)
static void C_ccall f_4511(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4514)
static void C_ccall f_4514(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4515)
static void C_ccall f_4515(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4519)
static void C_ccall f_4519(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4522)
static void C_ccall f_4522(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4486)
static void C_ccall f_4486(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4489)
static void C_ccall f_4489(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4490)
static void C_ccall f_4490(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4494)
static void C_ccall f_4494(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4392)
static void C_ccall f_4392(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4395)
static void C_ccall f_4395(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4398)
static void C_ccall f_4398(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4401)
static void C_ccall f_4401(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4402)
static void C_ccall f_4402(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4409)
static void C_ccall f_4409(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4382)
static void C_ccall f_4382(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4348)
static void C_ccall f_4348(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4342)
static void C_ccall f_4342(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4343)
static void C_ccall f_4343(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4266)
static void C_ccall f_4266(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4326)
static void C_ccall f_4326(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4324)
static void C_ccall f_4324(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4316)
static void C_ccall f_4316(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4308)
static void C_ccall f_4308(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4300)
static void C_ccall f_4300(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4292)
static void C_ccall f_4292(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4284)
static void C_ccall f_4284(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4276)
static void C_ccall f_4276(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4217)
static void C_ccall f_4217(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4206)
static void C_ccall f_4206(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4204)
static void C_ccall f_4204(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4193)
static void C_ccall f_4193(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4191)
static void C_ccall f_4191(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4183)
static void C_ccall f_4183(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4175)
static void C_ccall f_4175(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4167)
static void C_ccall f_4167(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4075)
static void C_ccall f_4075(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4085)
static void C_ccall f_4085(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4134)
static void C_ccall f_4134(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4119)
static void C_fcall f_4119(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4114)
static void C_fcall f_4114(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4115)
static void C_ccall f_4115(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4091)
static void C_ccall f_4091(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4094)
static void C_ccall f_4094(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4095)
static void C_ccall f_4095(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4150)
static void C_ccall f_4150(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4141)
static void C_ccall f_4141(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4069)
static void C_ccall f_4069(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4051)
static void C_fcall f_4051(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4045)
static C_word C_fcall f_4045(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_4039)
static C_word C_fcall f_4039(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_3986)
static void C_fcall f_3986(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3990)
static void C_ccall f_3990(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4037)
static void C_ccall f_4037(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4005)
static void C_fcall f_4005(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4014)
static void C_fcall f_4014(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3874)
static void C_fcall f_3874(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3886)
static void C_ccall f_3886(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3880)
static void C_ccall f_3880(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3832)
static void C_fcall f_3832(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3838)
static void C_fcall f_3838(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3956)
static C_word C_fcall f_3956(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_3823)
static void C_ccall f_3823(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3782)
static void C_ccall f_3782(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_3801)
static void C_ccall f_3801(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3813)
static void C_ccall f_3813(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3816)
static void C_ccall f_3816(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3819)
static void C_ccall f_3819(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3809)
static void C_ccall f_3809(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3788)
static void C_ccall f_3788(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3722)
static void C_ccall f_3722(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3726)
static void C_ccall f_3726(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3734)
static void C_fcall f_3734(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3655)
static void C_ccall f_3655(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3661)
static void C_fcall f_3661(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3677)
static void C_fcall f_3677(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3612)
static void C_ccall f_3612(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3618)
static void C_fcall f_3618(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3637)
static void C_ccall f_3637(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3628)
static void C_ccall f_3628(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3592)
static void C_ccall f_3592(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_3604)
static void C_ccall f_3604(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3607)
static void C_ccall f_3607(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3600)
static void C_ccall f_3600(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3537)
static void C_ccall f_3537(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3541)
static void C_ccall f_3541(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3549)
static void C_fcall f_3549(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3492)
static void C_ccall f_3492(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3496)
static void C_ccall f_3496(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3505)
static C_word C_fcall f_3505(C_word t0,C_word t1);
C_noret_decl(f_3477)
static void C_ccall f_3477(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3417)
static void C_ccall f_3417(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3472)
static void C_ccall f_3472(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3420)
static void C_fcall f_3420(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3326)
static void C_ccall f_3326(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3415)
static void C_ccall f_3415(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3329)
static void C_fcall f_3329(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3384)
static void C_ccall f_3384(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2843)
static void C_ccall f_2843(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2843)
static void C_ccall f_2843r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3281)
static void C_fcall f_3281(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3276)
static void C_fcall f_3276(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2845)
static void C_fcall f_2845(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3028)
static void C_fcall f_3028(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3034)
static void C_fcall f_3034(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_3068)
static void C_ccall f_3068(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3240)
static void C_ccall f_3240(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3226)
static void C_ccall f_3226(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3233)
static void C_ccall f_3233(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3198)
static void C_ccall f_3198(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3080)
static void C_ccall f_3080(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3085)
static void C_fcall f_3085(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3098)
static void C_ccall f_3098(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3150)
static void C_ccall f_3150(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3132)
static void C_ccall f_3132(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3143)
static void C_ccall f_3143(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2848)
static void C_fcall f_2848(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_2930)
static void C_ccall f_2930(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3020)
static void C_ccall f_3020(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3008)
static void C_ccall f_3008(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2941)
static void C_ccall f_2941(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3006)
static void C_ccall f_3006(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2998)
static void C_ccall f_2998(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2949)
static void C_ccall f_2949(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2992)
static void C_ccall f_2992(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2996)
static void C_ccall f_2996(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2959)
static void C_ccall f_2959(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2963)
static void C_ccall f_2963(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2984)
static void C_ccall f_2984(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2982)
static void C_ccall f_2982(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2957)
static void C_ccall f_2957(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2953)
static void C_ccall f_2953(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2945)
static void C_ccall f_2945(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2860)
static void C_fcall f_2860(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2879)
static void C_fcall f_2879(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2890)
static void C_ccall f_2890(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2898)
static void C_ccall f_2898(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2886)
static void C_ccall f_2886(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2324)
static void C_ccall f_2324(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2346)
static void C_fcall f_2346(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_2786)
static void C_fcall f_2786(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2724)
static void C_ccall f_2724(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2705)
static void C_fcall f_2705(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2659)
static void C_fcall f_2659(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2662)
static void C_fcall f_2662(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2641)
static void C_ccall f_2641(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2622)
static void C_fcall f_2622(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2590)
static void C_fcall f_2590(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2569)
static void C_ccall f_2569(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2360)
static void C_ccall f_2360(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2562)
static void C_ccall f_2562(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2505)
static void C_ccall f_2505(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2558)
static void C_ccall f_2558(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2532)
static void C_fcall f_2532(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2503)
static void C_ccall f_2503(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2364)
static void C_fcall f_2364(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2376)
static void C_fcall f_2376(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2455)
static void C_ccall f_2455(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2451)
static void C_ccall f_2451(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2432)
static void C_ccall f_2432(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2367)
static void C_fcall f_2367(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2327)
static void C_fcall f_2327(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2281)
static void C_ccall f_2281(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2287)
static void C_fcall f_2287(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2306)
static void C_fcall f_2306(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2265)
static void C_ccall f_2265(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2265)
static void C_ccall f_2265r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2229)
static void C_ccall f_2229(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2229)
static void C_ccall f_2229r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2238)
static void C_fcall f_2238(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2250)
static void C_ccall f_2250(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2244)
static void C_ccall f_2244(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2222)
static void C_ccall f_2222(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2219)
static void C_ccall f_2219(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2216)
static void C_ccall f_2216(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1846)
static void C_ccall f_1846(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2156)
static void C_fcall f_2156(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2162)
static void C_ccall f_2162(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2169)
static void C_ccall f_2169(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2083)
static void C_ccall f_2083(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2095)
static void C_ccall f_2095(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2143)
static void C_ccall f_2143(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2137)
static void C_ccall f_2137(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2117)
static void C_ccall f_2117(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1995)
static void C_fcall f_1995(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2015)
static void C_ccall f_2015(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2023)
static void C_fcall f_2023(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2037)
static void C_ccall f_2037(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2009)
static void C_ccall f_2009(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1849)
static void C_fcall f_1849(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1858)
static void C_ccall f_1858(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1971)
static void C_ccall f_1971(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1983)
static void C_ccall f_1983(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1983)
static void C_ccall f_1983r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1989)
static void C_ccall f_1989(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1977)
static void C_ccall f_1977(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1864)
static void C_ccall f_1864(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1870)
static void C_ccall f_1870(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1881)
static void C_fcall f_1881(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1898)
static void C_fcall f_1898(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1917)
static void C_fcall f_1917(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1928)
static void C_ccall f_1928(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1892)
static void C_ccall f_1892(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1878)
static void C_fcall f_1878(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1856)
static void C_ccall f_1856(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1837)
static void C_ccall f_1837(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1819)
static void C_ccall f_1819(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1829)
static void C_ccall f_1829(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1809)
static void C_ccall f_1809(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1817)
static void C_ccall f_1817(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1793)
static void C_ccall f_1793(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1799)
static void C_ccall f_1799(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1777)
static void C_ccall f_1777(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1783)
static void C_ccall f_1783(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1761)
static void C_ccall f_1761(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1765)
static void C_ccall f_1765(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1734)
static void C_ccall f_1734(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1734)
static void C_ccall f_1734r(C_word t0,C_word t1,C_word t3) C_noret;

/* from CHICKEN_get_error_message */
 void  CHICKEN_get_error_message(char *t0,int t1){
C_word x,s=0+3,*a=C_alloc(s);
C_callback_adjust_stack(a,s);
x=C_mpointer_or_false(&a,(void*)t0);
C_save(x);
x=C_fix((C_word)t1);
C_save(x);C_callback_wrapper((void *)f_9728,2);}

/* from CHICKEN_load */
 int  CHICKEN_load(char * t0){
C_word x,s=0+2+(t0==NULL?1:C_bytestowords(C_strlen(t0))),*a=C_alloc(s);
C_callback_adjust_stack(a,s);
x=C_mpointer(&a,(void*)t0);
C_save(x);
return C_truep(C_callback_wrapper((void *)f_9713,1));}

/* from CHICKEN_read */
 int  CHICKEN_read(char * t0,C_word *t1){
C_word x,s=0+2+(t0==NULL?1:C_bytestowords(C_strlen(t0)))+3,*a=C_alloc(s);
C_callback_adjust_stack(a,s);
x=C_mpointer(&a,(void*)t0);
C_save(x);
x=C_mpointer_or_false(&a,(void*)t1);
C_save(x);
return C_truep(C_callback_wrapper((void *)f_9691,2));}

/* from CHICKEN_apply_to_string */
 int  CHICKEN_apply_to_string(C_word t0,C_word t1,char *t2,int t3){
C_word x,s=0+3,*a=C_alloc(s);
C_callback_adjust_stack(a,s);
x=((C_word)t0);
C_save(x);
x=((C_word)t1);
C_save(x);
x=C_mpointer_or_false(&a,(void*)t2);
C_save(x);
x=C_fix((C_word)t3);
C_save(x);
return C_truep(C_callback_wrapper((void *)f_9665,4));}

/* from CHICKEN_apply */
 int  CHICKEN_apply(C_word t0,C_word t1,C_word *t2){
C_word x,s=0+3,*a=C_alloc(s);
C_callback_adjust_stack(a,s);
x=((C_word)t0);
C_save(x);
x=((C_word)t1);
C_save(x);
x=C_mpointer_or_false(&a,(void*)t2);
C_save(x);
return C_truep(C_callback_wrapper((void *)f_9649,3));}

/* from CHICKEN_eval_string_to_string */
 int  CHICKEN_eval_string_to_string(char * t0,char *t1,int t2){
C_word x,s=0+2+(t0==NULL?1:C_bytestowords(C_strlen(t0)))+3,*a=C_alloc(s);
C_callback_adjust_stack(a,s);
x=C_mpointer(&a,(void*)t0);
C_save(x);
x=C_mpointer_or_false(&a,(void*)t1);
C_save(x);
x=C_fix((C_word)t2);
C_save(x);
return C_truep(C_callback_wrapper((void *)f_9612,3));}

/* from CHICKEN_eval_to_string */
 int  CHICKEN_eval_to_string(C_word t0,char *t1,int t2){
C_word x,s=0+3,*a=C_alloc(s);
C_callback_adjust_stack(a,s);
x=((C_word)t0);
C_save(x);
x=C_mpointer_or_false(&a,(void*)t1);
C_save(x);
x=C_fix((C_word)t2);
C_save(x);
return C_truep(C_callback_wrapper((void *)f_9586,3));}

/* from CHICKEN_eval_string */
 int  CHICKEN_eval_string(char * t0,C_word *t1){
C_word x,s=0+2+(t0==NULL?1:C_bytestowords(C_strlen(t0)))+3,*a=C_alloc(s);
C_callback_adjust_stack(a,s);
x=C_mpointer(&a,(void*)t0);
C_save(x);
x=C_mpointer_or_false(&a,(void*)t1);
C_save(x);
return C_truep(C_callback_wrapper((void *)f_9547,2));}

/* from CHICKEN_eval */
 int  CHICKEN_eval(C_word t0,C_word *t1){
C_word x,s=0+3,*a=C_alloc(s);
C_callback_adjust_stack(a,s);
x=((C_word)t0);
C_save(x);
x=C_mpointer_or_false(&a,(void*)t1);
C_save(x);
return C_truep(C_callback_wrapper((void *)f_9531,2));}

/* from CHICKEN_yield */
 int  CHICKEN_yield(){
C_word x,s=0,*a=C_alloc(s);
C_callback_adjust_stack(a,s);
return C_truep(C_callback_wrapper((void *)f_9519,0));}

C_noret_decl(trf_11455)
static void C_fcall trf_11455(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11455(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11455(t0,t1);}

C_noret_decl(trf_11423)
static void C_fcall trf_11423(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11423(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11423(t0,t1);}

C_noret_decl(trf_6763)
static void C_fcall trf_6763(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6763(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6763(t0,t1);}

C_noret_decl(trf_11322)
static void C_fcall trf_11322(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11322(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11322(t0,t1,t2);}

C_noret_decl(trf_11224)
static void C_fcall trf_11224(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11224(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11224(t0,t1);}

C_noret_decl(trf_11190)
static void C_fcall trf_11190(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11190(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11190(t0,t1);}

C_noret_decl(trf_11090)
static void C_fcall trf_11090(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11090(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11090(t0,t1,t2);}

C_noret_decl(trf_10822)
static void C_fcall trf_10822(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10822(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10822(t0,t1,t2);}

C_noret_decl(trf_10914)
static void C_fcall trf_10914(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10914(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10914(t0,t1);}

C_noret_decl(trf_10736)
static void C_fcall trf_10736(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10736(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10736(t0,t1,t2);}

C_noret_decl(trf_10678)
static void C_fcall trf_10678(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10678(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10678(t0,t1,t2);}

C_noret_decl(trf_10511)
static void C_fcall trf_10511(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10511(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10511(t0,t1);}

C_noret_decl(trf_10389)
static void C_fcall trf_10389(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10389(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10389(t0,t1,t2);}

C_noret_decl(trf_10192)
static void C_fcall trf_10192(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10192(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_10192(t0,t1,t2,t3);}

C_noret_decl(trf_10182)
static void C_fcall trf_10182(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10182(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_10182(t0,t1,t2,t3);}

C_noret_decl(trf_10078)
static void C_fcall trf_10078(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10078(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10078(t0,t1,t2);}

C_noret_decl(trf_9936)
static void C_fcall trf_9936(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9936(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9936(t0,t1,t2);}

C_noret_decl(trf_9926)
static void C_fcall trf_9926(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9926(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9926(t0,t1,t2);}

C_noret_decl(trf_9781)
static void C_fcall trf_9781(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9781(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9781(t0,t1,t2);}

C_noret_decl(trf_9785)
static void C_fcall trf_9785(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9785(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9785(t0,t1);}

C_noret_decl(trf_9796)
static void C_fcall trf_9796(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9796(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9796(t0,t1);}

C_noret_decl(trf_9510)
static void C_fcall trf_9510(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9510(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9510(t0,t1,t2);}

C_noret_decl(trf_9451)
static void C_fcall trf_9451(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9451(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9451(t0,t1);}

C_noret_decl(trf_9391)
static void C_fcall trf_9391(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9391(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9391(t0,t1);}

C_noret_decl(trf_9378)
static void C_fcall trf_9378(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9378(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9378(t0,t1);}

C_noret_decl(trf_9149)
static void C_fcall trf_9149(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9149(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9149(t0,t1);}

C_noret_decl(trf_9207)
static void C_fcall trf_9207(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9207(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_9207(t0,t1,t2,t3);}

C_noret_decl(trf_9039)
static void C_fcall trf_9039(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9039(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9039(t0,t1);}

C_noret_decl(trf_9113)
static void C_fcall trf_9113(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9113(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9113(t0,t1);}

C_noret_decl(trf_9017)
static void C_fcall trf_9017(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9017(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9017(t0,t1);}

C_noret_decl(trf_8682)
static void C_fcall trf_8682(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8682(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8682(t0,t1);}

C_noret_decl(trf_8687)
static void C_fcall trf_8687(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8687(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8687(t0,t1,t2,t3);}

C_noret_decl(trf_8703)
static void C_fcall trf_8703(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8703(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8703(t0,t1);}

C_noret_decl(trf_8708)
static void C_fcall trf_8708(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8708(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8708(t0,t1,t2,t3);}

C_noret_decl(trf_8603)
static void C_fcall trf_8603(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8603(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8603(t0,t1,t2);}

C_noret_decl(trf_8548)
static void C_fcall trf_8548(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8548(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_8548(t0,t1,t2,t3,t4);}

C_noret_decl(trf_8560)
static void C_fcall trf_8560(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8560(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8560(t0,t1,t2);}

C_noret_decl(trf_8426)
static void C_fcall trf_8426(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8426(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8426(t0,t1,t2,t3);}

C_noret_decl(trf_8402)
static void C_fcall trf_8402(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8402(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8402(t0,t1,t2);}

C_noret_decl(trf_8408)
static void C_fcall trf_8408(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8408(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8408(t0,t1,t2);}

C_noret_decl(trf_8349)
static void C_fcall trf_8349(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8349(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8349(t0,t1,t2);}

C_noret_decl(trf_8320)
static void C_fcall trf_8320(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8320(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8320(t0,t1,t2);}

C_noret_decl(trf_8285)
static void C_fcall trf_8285(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8285(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8285(t0,t1,t2,t3);}

C_noret_decl(trf_8260)
static void C_fcall trf_8260(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8260(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8260(t0,t1);}

C_noret_decl(trf_8227)
static void C_fcall trf_8227(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8227(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8227(t0,t1);}

C_noret_decl(trf_8044)
static void C_fcall trf_8044(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8044(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8044(t0,t1,t2,t3);}

C_noret_decl(trf_8068)
static void C_fcall trf_8068(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8068(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8068(t0,t1,t2,t3);}

C_noret_decl(trf_7930)
static void C_fcall trf_7930(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7930(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7930(t0,t1,t2);}

C_noret_decl(trf_7957)
static void C_fcall trf_7957(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7957(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7957(t0,t1,t2);}

C_noret_decl(trf_7864)
static void C_fcall trf_7864(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7864(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7864(t0,t1,t2);}

C_noret_decl(trf_7884)
static void C_fcall trf_7884(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7884(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7884(t0,t1);}

C_noret_decl(trf_7684)
static void C_fcall trf_7684(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7684(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7684(t0,t1);}

C_noret_decl(trf_7721)
static void C_fcall trf_7721(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7721(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_7721(t0,t1,t2,t3,t4);}

C_noret_decl(trf_7433)
static void C_fcall trf_7433(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7433(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7433(t0,t1,t2);}

C_noret_decl(trf_7604)
static void C_fcall trf_7604(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7604(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7604(t0,t1);}

C_noret_decl(trf_7608)
static void C_fcall trf_7608(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7608(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7608(t0,t1);}

C_noret_decl(trf_7537)
static void C_fcall trf_7537(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7537(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7537(t0,t1);}

C_noret_decl(trf_7545)
static void C_fcall trf_7545(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7545(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7545(t0,t1);}

C_noret_decl(trf_7492)
static void C_fcall trf_7492(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7492(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7492(t0,t1);}

C_noret_decl(trf_7458)
static void C_fcall trf_7458(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7458(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7458(t0,t1);}

C_noret_decl(trf_7412)
static void C_fcall trf_7412(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7412(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7412(t0,t1,t2);}

C_noret_decl(trf_7366)
static void C_fcall trf_7366(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7366(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7366(t0,t1,t2);}

C_noret_decl(trf_7383)
static void C_fcall trf_7383(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7383(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7383(t0,t1);}

C_noret_decl(trf_7212)
static void C_fcall trf_7212(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7212(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7212(t0,t1);}

C_noret_decl(trf_7167)
static void C_fcall trf_7167(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7167(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7167(t0,t1,t2);}

C_noret_decl(trf_7134)
static void C_fcall trf_7134(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7134(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7134(t0,t1,t2);}

C_noret_decl(trf_7073)
static void C_fcall trf_7073(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7073(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7073(t0,t1,t2);}

C_noret_decl(trf_6995)
static void C_fcall trf_6995(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6995(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6995(t0,t1,t2);}

C_noret_decl(trf_6971)
static void C_fcall trf_6971(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6971(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6971(t0,t1);}

C_noret_decl(trf_6921)
static void C_fcall trf_6921(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6921(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_6921(t0,t1,t2,t3,t4);}

C_noret_decl(trf_6790)
static void C_fcall trf_6790(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6790(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6790(t0,t1);}

C_noret_decl(trf_6801)
static void C_fcall trf_6801(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6801(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6801(t0,t1,t2);}

C_noret_decl(trf_6817)
static void C_fcall trf_6817(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6817(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6817(t0,t1);}

C_noret_decl(trf_6634)
static void C_fcall trf_6634(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6634(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6634(t0,t1);}

C_noret_decl(trf_6629)
static void C_fcall trf_6629(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6629(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6629(t0,t1,t2);}

C_noret_decl(trf_6294)
static void C_fcall trf_6294(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6294(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6294(t0,t1,t2,t3);}

C_noret_decl(trf_6298)
static void C_fcall trf_6298(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6298(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6298(t0,t1);}

C_noret_decl(trf_6580)
static void C_fcall trf_6580(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6580(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6580(t0,t1);}

C_noret_decl(trf_6373)
static void C_fcall trf_6373(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6373(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6373(t0,t1,t2);}

C_noret_decl(trf_6246)
static void C_fcall trf_6246(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6246(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6246(t0,t1);}

C_noret_decl(trf_6183)
static void C_fcall trf_6183(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6183(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6183(t0,t1,t2);}

C_noret_decl(trf_6095)
static void C_fcall trf_6095(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6095(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_6095(t0,t1,t2,t3,t4);}

C_noret_decl(trf_6085)
static void C_fcall trf_6085(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6085(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6085(t0,t1);}

C_noret_decl(trf_5813)
static void C_fcall trf_5813(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5813(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_5813(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_4057)
static void C_fcall trf_4057(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4057(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_4057(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_4216)
static void C_fcall trf_4216(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4216(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4216(t0,t1);}

C_noret_decl(trf_5620)
static void C_fcall trf_5620(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5620(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5620(t0,t1);}

C_noret_decl(trf_5467)
static void C_fcall trf_5467(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5467(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5467(t0,t1,t2);}

C_noret_decl(trf_5419)
static void C_fcall trf_5419(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5419(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5419(t0,t1);}

C_noret_decl(trf_5754)
static void C_fcall trf_5754(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5754(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_5754(t0,t1,t2,t3,t4);}

C_noret_decl(trf_4933)
static void C_fcall trf_4933(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4933(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4933(t0,t1,t2,t3);}

C_noret_decl(trf_4119)
static void C_fcall trf_4119(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4119(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4119(t0,t1);}

C_noret_decl(trf_4114)
static void C_fcall trf_4114(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4114(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4114(t0,t1);}

C_noret_decl(trf_4051)
static void C_fcall trf_4051(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4051(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_4051(t0,t1,t2,t3,t4);}

C_noret_decl(trf_3986)
static void C_fcall trf_3986(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3986(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3986(t0,t1,t2,t3);}

C_noret_decl(trf_4005)
static void C_fcall trf_4005(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4005(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4005(t0,t1);}

C_noret_decl(trf_4014)
static void C_fcall trf_4014(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4014(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4014(t0,t1);}

C_noret_decl(trf_3874)
static void C_fcall trf_3874(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3874(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3874(t0,t1,t2,t3);}

C_noret_decl(trf_3832)
static void C_fcall trf_3832(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3832(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3832(t0,t1,t2);}

C_noret_decl(trf_3838)
static void C_fcall trf_3838(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3838(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3838(t0,t1,t2,t3);}

C_noret_decl(trf_3734)
static void C_fcall trf_3734(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3734(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3734(t0,t1,t2);}

C_noret_decl(trf_3661)
static void C_fcall trf_3661(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3661(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3661(t0,t1,t2,t3);}

C_noret_decl(trf_3677)
static void C_fcall trf_3677(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3677(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3677(t0,t1,t2,t3);}

C_noret_decl(trf_3618)
static void C_fcall trf_3618(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3618(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3618(t0,t1,t2);}

C_noret_decl(trf_3549)
static void C_fcall trf_3549(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3549(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3549(t0,t1,t2);}

C_noret_decl(trf_3420)
static void C_fcall trf_3420(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3420(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3420(t0,t1,t2,t3);}

C_noret_decl(trf_3329)
static void C_fcall trf_3329(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3329(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3329(t0,t1,t2,t3);}

C_noret_decl(trf_3281)
static void C_fcall trf_3281(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3281(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3281(t0,t1);}

C_noret_decl(trf_3276)
static void C_fcall trf_3276(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3276(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3276(t0,t1,t2);}

C_noret_decl(trf_2845)
static void C_fcall trf_2845(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2845(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2845(t0,t1,t2);}

C_noret_decl(trf_3028)
static void C_fcall trf_3028(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3028(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3028(t0,t1,t2);}

C_noret_decl(trf_3034)
static void C_fcall trf_3034(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3034(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_3034(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_3085)
static void C_fcall trf_3085(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3085(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3085(t0,t1,t2);}

C_noret_decl(trf_2848)
static void C_fcall trf_2848(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2848(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_2848(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_2860)
static void C_fcall trf_2860(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2860(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2860(t0,t1,t2,t3);}

C_noret_decl(trf_2879)
static void C_fcall trf_2879(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2879(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2879(t0,t1);}

C_noret_decl(trf_2346)
static void C_fcall trf_2346(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2346(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_2346(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_2786)
static void C_fcall trf_2786(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2786(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2786(t0,t1);}

C_noret_decl(trf_2705)
static void C_fcall trf_2705(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2705(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2705(t0,t1);}

C_noret_decl(trf_2659)
static void C_fcall trf_2659(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2659(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2659(t0,t1);}

C_noret_decl(trf_2662)
static void C_fcall trf_2662(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2662(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2662(t0,t1);}

C_noret_decl(trf_2622)
static void C_fcall trf_2622(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2622(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2622(t0,t1);}

C_noret_decl(trf_2590)
static void C_fcall trf_2590(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2590(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2590(t0,t1);}

C_noret_decl(trf_2532)
static void C_fcall trf_2532(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2532(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2532(t0,t1);}

C_noret_decl(trf_2364)
static void C_fcall trf_2364(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2364(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2364(t0,t1);}

C_noret_decl(trf_2376)
static void C_fcall trf_2376(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2376(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2376(t0,t1);}

C_noret_decl(trf_2367)
static void C_fcall trf_2367(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2367(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2367(t0,t1);}

C_noret_decl(trf_2327)
static void C_fcall trf_2327(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2327(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2327(t0,t1,t2);}

C_noret_decl(trf_2287)
static void C_fcall trf_2287(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2287(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2287(t0,t1,t2);}

C_noret_decl(trf_2306)
static void C_fcall trf_2306(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2306(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2306(t0,t1);}

C_noret_decl(trf_2238)
static void C_fcall trf_2238(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2238(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2238(t0,t1,t2);}

C_noret_decl(trf_2156)
static void C_fcall trf_2156(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2156(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2156(t0,t1);}

C_noret_decl(trf_1995)
static void C_fcall trf_1995(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1995(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1995(t0,t1,t2,t3);}

C_noret_decl(trf_2023)
static void C_fcall trf_2023(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2023(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2023(t0,t1,t2);}

C_noret_decl(trf_1849)
static void C_fcall trf_1849(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1849(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1849(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1881)
static void C_fcall trf_1881(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1881(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1881(t0,t1);}

C_noret_decl(trf_1898)
static void C_fcall trf_1898(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1898(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1898(t0,t1,t2);}

C_noret_decl(trf_1917)
static void C_fcall trf_1917(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1917(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1917(t0,t1);}

C_noret_decl(trf_1878)
static void C_fcall trf_1878(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1878(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1878(t0,t1);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr6r)
static void C_fcall tr6r(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6r(C_proc6 k){
int n;
C_word *a,t6;
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
n=C_rest_count(0);
a=C_alloc(n*3);
t6=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(tr5r)
static void C_fcall tr5r(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5r(C_proc5 k){
int n;
C_word *a,t5;
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
n=C_rest_count(0);
a=C_alloc(n*3);
t5=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr2rv)
static void C_fcall tr2rv(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2rv(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n+1);
t2=C_restore_rest_vector(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr4rv)
static void C_fcall tr4rv(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4rv(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n+1);
t4=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr5rv)
static void C_fcall tr5rv(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5rv(C_proc5 k){
int n;
C_word *a,t5;
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
n=C_rest_count(0);
a=C_alloc(n+1);
t5=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr3rv)
static void C_fcall tr3rv(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3rv(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n+1);
t3=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_eval_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_eval_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("eval_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(7669)){
C_save(t1);
C_rereclaim2(7669*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,523);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[2]=C_h_intern(&lf[2],24,"\003syscore-library-modules");
lf[3]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006extras\376\003\000\000\002\376\001\000\000\007lolevel\376\003\000\000\002\376\001\000\000\005utils\376\003\000\000\002\376\001\000\000\003tcp\376\003\000\000\002\376\001\000\000\005regex\376\003\000\000"
"\002\376\001\000\000\014regex-extras\376\003\000\000\002\376\001\000\000\005posix\376\003\000\000\002\376\001\000\000\005match\376\003\000\000\002\376\001\000\000\017data-structures\376\003\000\000\002\376\001"
"\000\000\006srfi-1\376\003\000\000\002\376\001\000\000\006srfi-4\376\003\000\000\002\376\001\000\000\007srfi-13\376\003\000\000\002\376\001\000\000\007srfi-14\376\003\000\000\002\376\001\000\000\007srfi-18\376\003\000\000"
"\002\376\001\000\000\007srfi-69\376\377\016");
lf[4]=C_h_intern(&lf[4],28,"\003sysexplicit-library-modules");
lf[6]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\012libchicken\376\377\016");
lf[8]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\014cygchicken-0\376\377\016");
lf[10]=C_decode_literal(C_heaptop,"\376B\000\000\006.dylib");
lf[12]=C_decode_literal(C_heaptop,"\376B\000\000\004.dll");
lf[14]=C_decode_literal(C_heaptop,"\376B\000\000\003.sl");
lf[16]=C_decode_literal(C_heaptop,"\376B\000\000\003.so");
lf[18]=C_decode_literal(C_heaptop,"\376B\000\000\004.scm");
lf[20]=C_decode_literal(C_heaptop,"\376B\000\000\012setup-info");
lf[22]=C_decode_literal(C_heaptop,"\376B\000\000\022CHICKEN_REPOSITORY");
lf[24]=C_decode_literal(C_heaptop,"\376B\000\000\016CHICKEN_PREFIX");
lf[26]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\022chicken-ffi-macros\376\003\000\000\002\376\001\000\000\023chicken-more-macros\376\377\016");
lf[28]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\007chicken\376\003\000\000\002\376\001\000\000\006srfi-2\376\003\000\000\002\376\001\000\000\006srfi-6\376\003\000\000\002\376\001\000\000\007srfi-10\376\003\000\000\002\376\001\000\000\007srfi"
"-12\376\003\000\000\002\376\001\000\000\007srfi-23\376\003\000\000\002\376\001\000\000\007srfi-28\376\003\000\000\002\376\001\000\000\007srfi-30\376\003\000\000\002\376\001\000\000\007srfi-31\376\003\000\000\002\376\001\000\000"
"\007srfi-39\376\377\016");
lf[30]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006srfi-6\376\003\000\000\002\376\001\000\000\006srfi-8\376\003\000\000\002\376\001\000\000\006srfi-9\376\003\000\000\002\376\001\000\000\007srfi-11\376\003\000\000\002\376\001\000\000\007srfi-"
"15\376\003\000\000\002\376\001\000\000\007srfi-16\376\003\000\000\002\376\001\000\000\007srfi-17\376\003\000\000\002\376\001\000\000\007srfi-26\376\003\000\000\002\376\001\000\000\007srfi-55\376\377\016");
lf[31]=C_h_intern(&lf[31],18,"\003syschicken-prefix");
lf[32]=C_h_intern(&lf[32],17,"\003sysstring-append");
lf[33]=C_h_intern(&lf[33],6,"getenv");
lf[34]=C_h_intern(&lf[34],12,"chicken-home");
lf[35]=C_h_intern(&lf[35],17,"\003syspeek-c-string");
lf[36]=C_decode_literal(C_heaptop,"\376B\000\000\015share/chicken");
lf[37]=C_h_intern(&lf[37],21,"\003sysmacro-environment");
lf[38]=C_h_intern(&lf[38],20,"\003sysregister-macro-2");
lf[39]=C_h_intern(&lf[39],19,"\003syshash-table-set!");
lf[40]=C_h_intern(&lf[40],18,"\003sysregister-macro");
lf[41]=C_h_intern(&lf[41],14,"\003syscopy-macro");
lf[42]=C_h_intern(&lf[42],18,"\003syshash-table-ref");
lf[43]=C_h_intern(&lf[43],6,"macro\077");
lf[44]=C_h_intern(&lf[44],15,"undefine-macro!");
lf[45]=C_h_intern(&lf[45],13,"string-append");
lf[46]=C_h_intern(&lf[46],17,"\003sysmacroexpand-0");
lf[47]=C_h_intern(&lf[47],9,"\003sysabort");
lf[48]=C_h_intern(&lf[48],9,"condition");
lf[49]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\003exn\376\001\000\000\007message");
lf[50]=C_decode_literal(C_heaptop,"\376B\000\000\025during expansion of (");
lf[51]=C_decode_literal(C_heaptop,"\376B\000\000\010 ...) - ");
lf[52]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\003exn\376\001\000\000\007message");
lf[53]=C_h_intern(&lf[53],3,"exn");
lf[54]=C_h_intern(&lf[54],22,"with-exception-handler");
lf[55]=C_h_intern(&lf[55],30,"call-with-current-continuation");
lf[56]=C_h_intern(&lf[56],21,"\003syssyntax-error-hook");
lf[57]=C_decode_literal(C_heaptop,"\376B\000\000\034invalid syntax in macro form");
lf[58]=C_h_intern(&lf[58],3,"let");
lf[59]=C_h_intern(&lf[59],16,"\004coreloop-lambda");
lf[60]=C_h_intern(&lf[60],6,"letrec");
lf[61]=C_h_intern(&lf[61],8,"\004coreapp");
lf[62]=C_h_intern(&lf[62],7,"\003sysmap");
lf[63]=C_h_intern(&lf[63],4,"cadr");
lf[64]=C_h_intern(&lf[64],16,"\003syscheck-syntax");
lf[65]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\000\000\000\002\376\003\000\000\002\376\001\000\000\010variable\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[66]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\002");
lf[67]=C_h_intern(&lf[67],10,"\003syssetter");
lf[68]=C_h_intern(&lf[68],6,"append");
lf[69]=C_h_intern(&lf[69],4,"set!");
lf[70]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[71]=C_h_intern(&lf[71],9,"\004coreset!");
lf[72]=C_h_intern(&lf[72],38,"\003syscompiler-toplevel-macroexpand-hook");
lf[73]=C_h_intern(&lf[73],41,"\003sysinterpreter-toplevel-macroexpand-hook");
lf[74]=C_h_intern(&lf[74],23,"\003sysmacroexpand-1-local");
lf[75]=C_h_intern(&lf[75],25,"\003sysenable-runtime-macros");
lf[76]=C_h_intern(&lf[76],11,"macroexpand");
lf[77]=C_h_intern(&lf[77],13,"macroexpand-1");
lf[78]=C_h_intern(&lf[78],25,"\003sysextended-lambda-list\077");
lf[79]=C_h_intern(&lf[79],6,"#!rest");
lf[80]=C_h_intern(&lf[80],10,"#!optional");
lf[81]=C_h_intern(&lf[81],5,"#!key");
lf[82]=C_h_intern(&lf[82],7,"reverse");
lf[83]=C_h_intern(&lf[83],6,"gensym");
lf[84]=C_h_intern(&lf[84],31,"\003sysexpand-extended-lambda-list");
lf[85]=C_h_intern(&lf[85],9,":optional");
lf[86]=C_h_intern(&lf[86],13,"let-optionals");
lf[87]=C_h_intern(&lf[87],14,"let-optionals*");
lf[88]=C_h_intern(&lf[88],10,"\003sysappend");
lf[89]=C_h_intern(&lf[89],4,"let*");
lf[90]=C_h_intern(&lf[90],5,"quote");
lf[91]=C_h_intern(&lf[91],15,"\003sysget-keyword");
lf[92]=C_h_intern(&lf[92],6,"lambda");
lf[93]=C_h_intern(&lf[93],15,"string->keyword");
lf[94]=C_decode_literal(C_heaptop,"\376B\000\000+rest argument list specified more than once");
lf[95]=C_decode_literal(C_heaptop,"\376B\000\000-`#!optional\047 argument marker in wrong context");
lf[96]=C_decode_literal(C_heaptop,"\376B\000\000#invalid syntax of `#!rest\047 argument");
lf[97]=C_decode_literal(C_heaptop,"\376B\000\000)`#!rest\047 argument marker in wrong context");
lf[98]=C_decode_literal(C_heaptop,"\376B\000\000(`#!key\047 argument marker in wrong context");
lf[99]=C_decode_literal(C_heaptop,"\376B\000\0000invalid lambda list syntax after `#!rest\047 marker");
lf[100]=C_decode_literal(C_heaptop,"\376B\000\000 invalid required argument syntax");
lf[101]=C_decode_literal(C_heaptop,"\376B\000\0000invalid lambda list syntax after `#!rest\047 marker");
lf[102]=C_decode_literal(C_heaptop,"\376B\000\000\032invalid lambda list syntax");
lf[103]=C_decode_literal(C_heaptop,"\376B\000\000\032invalid lambda list syntax");
lf[104]=C_h_intern(&lf[104],3,"map");
lf[105]=C_h_intern(&lf[105],21,"\003syscanonicalize-body");
lf[106]=C_h_intern(&lf[106],5,"begin");
lf[107]=C_h_intern(&lf[107],6,"define");
lf[108]=C_h_intern(&lf[108],13,"define-values");
lf[109]=C_h_intern(&lf[109],20,"\003syscall-with-values");
lf[110]=C_h_intern(&lf[110],14,"\004coreundefined");
lf[111]=C_h_intern(&lf[111],25,"\003sysexpand-curried-define");
lf[112]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006define\376\003\000\000\002\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\013lambda-list\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[113]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006define\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010variable\376\001\000\000\013lambda-list\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[114]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010\003sysvoid\376\377\016");
lf[115]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006define\376\003\000\000\002\376\001\000\000\010variable\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[116]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006define\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[117]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\015define-values\376\003\000\000\002\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[118]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005begin\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[119]=C_h_intern(&lf[119],20,"\003sysmatch-expression");
lf[120]=C_h_intern(&lf[120],15,"\003syshash-symbol");
lf[121]=C_h_intern(&lf[121],22,"\003syshash-table-update!");
lf[122]=C_h_intern(&lf[122],23,"\003syshash-table-for-each");
lf[123]=C_h_intern(&lf[123],12,"\003sysfor-each");
lf[124]=C_h_intern(&lf[124],21,"\003syshash-table->alist");
lf[125]=C_h_intern(&lf[125],3,"vec");
lf[126]=C_h_intern(&lf[126],28,"\003sysarbitrary-unbound-symbol");
lf[127]=C_h_intern(&lf[127],23,"\003syshash-table-location");
lf[128]=C_h_intern(&lf[128],20,"\003syseval-environment");
lf[129]=C_h_intern(&lf[129],26,"\003sysenvironment-is-mutable");
lf[130]=C_h_intern(&lf[130],18,"\003syseval-decorator");
lf[131]=C_h_intern(&lf[131],20,"\003sysmake-lambda-info");
lf[132]=C_h_intern(&lf[132],17,"get-output-string");
lf[133]=C_h_intern(&lf[133],5,"write");
lf[134]=C_h_intern(&lf[134],18,"open-output-string");
lf[135]=C_h_intern(&lf[135],19,"\003sysdecorate-lambda");
lf[136]=C_h_intern(&lf[136],19,"\003sysunbound-in-eval");
lf[137]=C_h_intern(&lf[137],20,"\003syseval-debug-level");
lf[138]=C_h_intern(&lf[138],21,"\003sysalias-global-hook");
lf[139]=C_h_intern(&lf[139],6,"cadadr");
lf[140]=C_h_intern(&lf[140],20,"with-input-from-file");
lf[141]=C_h_intern(&lf[141],7,"display");
lf[142]=C_h_intern(&lf[142],22,"\003syscompile-to-closure");
lf[143]=C_h_intern(&lf[143],18,"\003syscurrent-thread");
lf[144]=C_h_intern(&lf[144],9,"\003syserror");
lf[145]=C_decode_literal(C_heaptop,"\376B\000\000\020unbound variable");
lf[146]=C_decode_literal(C_heaptop,"\376B\000\000!reference to undefined identifier");
lf[147]=C_h_intern(&lf[147],32,"\003syssymbol-has-toplevel-binding\077");
lf[148]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005quote\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[149]=C_h_intern(&lf[149],15,"\004coreglobal-ref");
lf[150]=C_h_intern(&lf[150],10,"\004corecheck");
lf[151]=C_h_intern(&lf[151],14,"\004coreimmutable");
lf[152]=C_h_intern(&lf[152],2,"if");
lf[153]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[154]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\002if\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\001\376\001\000\000\001_");
lf[155]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[156]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005begin\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[157]=C_decode_literal(C_heaptop,"\376B\000\000 assignment to immutable variable");
lf[158]=C_decode_literal(C_heaptop,"\376B\000\000\042assignment of undefined identifier");
lf[159]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\010variable\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[160]=C_h_intern(&lf[160],15,"\003sysmake-vector");
lf[161]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\003let\376\003\000\000\002\376\000\000\000\002\376\003\000\000\002\376\001\000\000\010variable\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001"
);
lf[162]=C_h_intern(&lf[162],1,"\077");
lf[163]=C_h_intern(&lf[163],10,"\003sysvector");
lf[164]=C_decode_literal(C_heaptop,"\376B\000\000\022bad argument count");
lf[165]=C_h_intern(&lf[165],25,"\003sysdecompose-lambda-list");
lf[166]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006lambda\376\003\000\000\002\376\001\000\000\013lambda-list\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[167]=C_h_intern(&lf[167],17,"\004corenamed-lambda");
lf[168]=C_h_intern(&lf[168],23,"\004corerequire-for-syntax");
lf[169]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[170]=C_h_intern(&lf[170],11,"\003sysrequire");
lf[171]=C_h_intern(&lf[171],31,"\003syslookup-runtime-requirements");
lf[172]=C_h_intern(&lf[172],22,"\004corerequire-extension");
lf[173]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[174]=C_h_intern(&lf[174],22,"\003sysdo-the-right-thing");
lf[175]=C_h_intern(&lf[175],24,"\004coreelaborationtimeonly");
lf[176]=C_h_intern(&lf[176],23,"\004coreelaborationtimetoo");
lf[177]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[178]=C_h_intern(&lf[178],19,"\004corecompiletimetoo");
lf[179]=C_h_intern(&lf[179],20,"\004corecompiletimeonly");
lf[180]=C_h_intern(&lf[180],13,"\004corecallunit");
lf[181]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[182]=C_h_intern(&lf[182],12,"\004coredeclare");
lf[183]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[184]=C_h_intern(&lf[184],10,"\000compiling");
lf[185]=C_h_intern(&lf[185],12,"\003sysfeatures");
lf[186]=C_h_intern(&lf[186],28,"\010compilerprocess-declaration");
lf[187]=C_h_intern(&lf[187],8,"\003syswarn");
lf[188]=C_decode_literal(C_heaptop,"\376B\000\000,declarations are ignored in interpreted code");
lf[189]=C_h_intern(&lf[189],18,"\004coredefine-inline");
lf[190]=C_h_intern(&lf[190],20,"\004coredefine-constant");
lf[191]=C_h_intern(&lf[191],14,"\004coreprimitive");
lf[192]=C_decode_literal(C_heaptop,"\376B\000\000&can not evaluate compiler-special-form");
lf[193]=C_h_intern(&lf[193],8,"location");
lf[194]=C_decode_literal(C_heaptop,"\376B\000\000&can not evaluate compiler-special-form");
lf[195]=C_h_intern(&lf[195],11,"\004coreinline");
lf[196]=C_h_intern(&lf[196],20,"\004coreinline_allocate");
lf[197]=C_h_intern(&lf[197],19,"\004coreforeign-lambda");
lf[198]=C_h_intern(&lf[198],28,"\004coredefine-foreign-variable");
lf[199]=C_h_intern(&lf[199],29,"\004coredefine-external-variable");
lf[200]=C_h_intern(&lf[200],17,"\004corelet-location");
lf[201]=C_h_intern(&lf[201],22,"\004coreforeign-primitive");
lf[202]=C_h_intern(&lf[202],20,"\004coreforeign-lambda*");
lf[203]=C_h_intern(&lf[203],24,"\004coredefine-foreign-type");
lf[204]=C_decode_literal(C_heaptop,"\376B\000\000\031illegal non-atomic object");
lf[205]=C_h_intern(&lf[205],11,"\003sysnumber\077");
lf[206]=C_decode_literal(C_heaptop,"\376B\000\000\024malformed expression");
lf[207]=C_h_intern(&lf[207],16,"\003syseval-handler");
lf[208]=C_h_intern(&lf[208],12,"eval-handler");
lf[209]=C_h_intern(&lf[209],4,"eval");
lf[210]=C_h_intern(&lf[210],24,"\003syssyntax-error-culprit");
lf[211]=C_decode_literal(C_heaptop,"\376B\000\000\032illegal lambda-list syntax");
lf[212]=C_h_intern(&lf[212],12,"load-verbose");
lf[213]=C_h_intern(&lf[213],14,"\003sysabort-load");
lf[214]=C_h_intern(&lf[214],27,"\003syscurrent-source-filename");
lf[215]=C_h_intern(&lf[215],21,"\003syscurrent-load-path");
lf[216]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[217]=C_h_intern(&lf[217],22,"set-dynamic-load-mode!");
lf[218]=C_h_intern(&lf[218],21,"\003sysset-dlopen-flags!");
lf[219]=C_h_intern(&lf[219],6,"global");
lf[220]=C_h_intern(&lf[220],5,"local");
lf[221]=C_h_intern(&lf[221],4,"lazy");
lf[222]=C_h_intern(&lf[222],3,"now");
lf[223]=C_h_intern(&lf[223],15,"\003syssignal-hook");
lf[224]=C_decode_literal(C_heaptop,"\376B\000\000\031invalid dynamic-load mode");
lf[225]=C_h_intern(&lf[225],4,"read");
lf[226]=C_h_intern(&lf[226],7,"newline");
lf[227]=C_h_intern(&lf[227],15,"open-input-file");
lf[228]=C_h_intern(&lf[228],16,"close-input-port");
lf[229]=C_h_intern(&lf[229],8,"\003sysload");
lf[230]=C_h_intern(&lf[230],31,"\003sysread-error-with-line-number");
lf[231]=C_h_intern(&lf[231],19,"\003sysundefined-value");
lf[232]=C_h_intern(&lf[232],17,"\003sysdisplay-times");
lf[233]=C_h_intern(&lf[233],14,"\003sysstop-timer");
lf[234]=C_h_intern(&lf[234],15,"\003sysstart-timer");
lf[235]=C_h_intern(&lf[235],4,"load");
lf[236]=C_decode_literal(C_heaptop,"\376B\000\000\036unable to load compiled module");
lf[237]=C_h_intern(&lf[237],9,"peek-char");
lf[238]=C_h_intern(&lf[238],16,"\003sysdynamic-wind");
lf[239]=C_h_intern(&lf[239],13,"\003syssubstring");
lf[240]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[241]=C_h_intern(&lf[241],9,"\003sysdload");
lf[242]=C_h_intern(&lf[242],17,"\003sysmake-c-string");
lf[243]=C_decode_literal(C_heaptop,"\376B\000\000\002./");
lf[244]=C_h_intern(&lf[244],11,"\000file-error");
lf[245]=C_decode_literal(C_heaptop,"\376B\000\000\021can not open file");
lf[246]=C_decode_literal(C_heaptop,"\376B\000\000\005 ...\012");
lf[247]=C_decode_literal(C_heaptop,"\376B\000\000\012; loading ");
lf[248]=C_h_intern(&lf[248],13,"\003sysfile-info");
lf[249]=C_h_intern(&lf[249],26,"\003sysload-dynamic-extension");
lf[250]=C_h_intern(&lf[250],11,"\000type-error");
lf[251]=C_decode_literal(C_heaptop,"\376B\000\000(bad argument type - not a port or string");
lf[252]=C_h_intern(&lf[252],5,"port\077");
lf[253]=C_h_intern(&lf[253],20,"\003sysexpand-home-path");
lf[254]=C_h_intern(&lf[254],13,"load-relative");
lf[255]=C_h_intern(&lf[255],12,"load-noisily");
lf[256]=C_h_intern(&lf[256],8,"\000printer");
lf[257]=C_h_intern(&lf[257],5,"\000time");
lf[258]=C_h_intern(&lf[258],10,"\000evaluator");
lf[259]=C_h_intern(&lf[259],26,"\003sysload-library-extension");
lf[260]=C_h_intern(&lf[260],6,"cygwin");
lf[261]=C_h_intern(&lf[261],34,"\003sysdefault-dynamic-load-libraries");
lf[262]=C_h_intern(&lf[262],22,"dynamic-load-libraries");
lf[263]=C_h_intern(&lf[263],16,"\003sysload-library");
lf[264]=C_decode_literal(C_heaptop,"\376B\000\000\005 ...\012");
lf[265]=C_decode_literal(C_heaptop,"\376B\000\000\022; loading library ");
lf[266]=C_decode_literal(C_heaptop,"\376B\000\000\002C_");
lf[267]=C_decode_literal(C_heaptop,"\376B\000\000\011_toplevel");
lf[268]=C_h_intern(&lf[268],24,"\003sysstring->c-identifier");
lf[269]=C_h_intern(&lf[269],16,"\003sys->feature-id");
lf[270]=C_h_intern(&lf[270],12,"load-library");
lf[271]=C_decode_literal(C_heaptop,"\376B\000\000\026unable to load library");
lf[273]=C_h_intern(&lf[273],31,"\003syscanonicalize-extension-path");
lf[274]=C_decode_literal(C_heaptop,"\376B\000\000\026invalid extension path");
lf[275]=C_h_intern(&lf[275],18,"\003syssymbol->string");
lf[276]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[277]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[278]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[279]=C_h_intern(&lf[279],19,"\003sysrepository-path");
lf[280]=C_h_intern(&lf[280],15,"repository-path");
lf[281]=C_h_intern(&lf[281],12,"file-exists\077");
lf[282]=C_h_intern(&lf[282],18,"\003sysfind-extension");
lf[283]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[284]=C_h_intern(&lf[284],21,"\003sysinclude-pathnames");
lf[285]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\001.\376\377\016");
lf[286]=C_h_intern(&lf[286],21,"\003sysloaded-extensions");
lf[287]=C_h_intern(&lf[287],14,"string->symbol");
lf[288]=C_h_intern(&lf[288],18,"\003sysload-extension");
lf[289]=C_decode_literal(C_heaptop,"\376B\000\000\026can not load extension");
lf[290]=C_h_intern(&lf[290],11,"\003sysprovide");
lf[291]=C_h_intern(&lf[291],7,"provide");
lf[292]=C_h_intern(&lf[292],13,"\003sysprovided\077");
lf[293]=C_h_intern(&lf[293],9,"provided\077");
lf[294]=C_h_intern(&lf[294],7,"require");
lf[295]=C_h_intern(&lf[295],25,"\003sysextension-information");
lf[296]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[297]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[298]=C_h_intern(&lf[298],21,"extension-information");
lf[299]=C_h_intern(&lf[299],18,"require-at-runtime");
lf[300]=C_h_intern(&lf[300],12,"vector->list");
lf[301]=C_h_intern(&lf[301],11,"lset-adjoin");
lf[302]=C_h_intern(&lf[302],3,"eq\077");
lf[303]=C_h_intern(&lf[303],26,"\010compilerfile-requirements");
lf[304]=C_h_intern(&lf[304],19,"syntax-requirements");
lf[305]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010\003sysvoid\376\377\016");
lf[306]=C_h_intern(&lf[306],18,"chicken-ffi-macros");
lf[307]=C_h_intern(&lf[307],19,"chicken-more-macros");
lf[308]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010\003sysvoid\376\377\016");
lf[309]=C_h_intern(&lf[309],28,"\003sysresolve-include-filename");
lf[310]=C_h_intern(&lf[310],4,"uses");
lf[311]=C_h_intern(&lf[311],6,"syntax");
lf[312]=C_h_intern(&lf[312],17,"require-extension");
lf[313]=C_h_intern(&lf[313],12,"\003sysfeature\077");
lf[314]=C_h_intern(&lf[314],24,"\003sysextension-specifiers");
lf[315]=C_decode_literal(C_heaptop,"\376B\000\000\035undefined extension specifier");
lf[316]=C_decode_literal(C_heaptop,"\376B\000\000\033invalid extension specifier");
lf[317]=C_h_intern(&lf[317],24,"set-extension-specifier!");
lf[318]=C_h_intern(&lf[318],11,"string-copy");
lf[321]=C_h_intern(&lf[321],11,"environment");
lf[323]=C_h_intern(&lf[323],18,"\003syscopy-env-table");
lf[324]=C_h_intern(&lf[324],23,"\003sysenvironment-symbols");
lf[325]=C_h_intern(&lf[325],18,"\003syswalk-namespace");
lf[326]=C_h_intern(&lf[326],23,"interaction-environment");
lf[327]=C_h_intern(&lf[327],25,"scheme-report-environment");
lf[328]=C_decode_literal(C_heaptop,"\376B\000\000\026no support for version");
lf[329]=C_h_intern(&lf[329],11,"make-vector");
lf[330]=C_h_intern(&lf[330],16,"null-environment");
lf[331]=C_decode_literal(C_heaptop,"\376B\000\000\026no support for version");
lf[332]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[333]=C_decode_literal(C_heaptop,"\376B\000\000\0010");
lf[334]=C_decode_literal(C_heaptop,"\376B\000\000\013 major GCs\012");
lf[335]=C_decode_literal(C_heaptop,"\376B\000\000\013 minor GCs\012");
lf[336]=C_decode_literal(C_heaptop,"\376B\000\000\013 mutations\012");
lf[337]=C_decode_literal(C_heaptop,"\376B\000\000\027 seconds in (major) GC\012");
lf[338]=C_decode_literal(C_heaptop,"\376B\000\000\021 seconds elapsed\012");
lf[339]=C_h_intern(&lf[339],24,"\003sysline-number-database");
lf[340]=C_h_intern(&lf[340],13,"\000syntax-error");
lf[341]=C_h_intern(&lf[341],12,"syntax-error");
lf[342]=C_h_intern(&lf[342],15,"get-line-number");
lf[343]=C_h_intern(&lf[343],8,"keyword\077");
lf[344]=C_h_intern(&lf[344],14,"symbol->string");
lf[345]=C_decode_literal(C_heaptop,"\376B\000\000\001(");
lf[346]=C_decode_literal(C_heaptop,"\376B\000\000\012) in line ");
lf[347]=C_decode_literal(C_heaptop,"\376B\000\000\003 - ");
lf[348]=C_decode_literal(C_heaptop,"\376B\000\000\001(");
lf[349]=C_decode_literal(C_heaptop,"\376B\000\000\002) ");
lf[350]=C_decode_literal(C_heaptop,"\376B\000\000\024not enough arguments");
lf[351]=C_decode_literal(C_heaptop,"\376B\000\000\022too many arguments");
lf[352]=C_decode_literal(C_heaptop,"\376B\000\000\021not a proper list");
lf[353]=C_h_intern(&lf[353],1,"_");
lf[354]=C_h_intern(&lf[354],4,"pair");
lf[355]=C_h_intern(&lf[355],5,"pair\077");
lf[356]=C_decode_literal(C_heaptop,"\376B\000\000\015pair expected");
lf[357]=C_h_intern(&lf[357],8,"variable");
lf[358]=C_decode_literal(C_heaptop,"\376B\000\000\023identifier expected");
lf[359]=C_h_intern(&lf[359],6,"symbol");
lf[360]=C_h_intern(&lf[360],7,"symbol\077");
lf[361]=C_decode_literal(C_heaptop,"\376B\000\000\017symbol expected");
lf[362]=C_h_intern(&lf[362],4,"list");
lf[363]=C_decode_literal(C_heaptop,"\376B\000\000\024proper list expected");
lf[364]=C_h_intern(&lf[364],6,"number");
lf[365]=C_h_intern(&lf[365],7,"number\077");
lf[366]=C_decode_literal(C_heaptop,"\376B\000\000\017number expected");
lf[367]=C_h_intern(&lf[367],6,"string");
lf[368]=C_h_intern(&lf[368],7,"string\077");
lf[369]=C_decode_literal(C_heaptop,"\376B\000\000\017string expected");
lf[370]=C_h_intern(&lf[370],11,"lambda-list");
lf[371]=C_decode_literal(C_heaptop,"\376B\000\000\024lambda-list expected");
lf[372]=C_decode_literal(C_heaptop,"\376B\000\000\017missing keyword");
lf[373]=C_decode_literal(C_heaptop,"\376B\000\000\017incomplete form");
lf[374]=C_decode_literal(C_heaptop,"\376B\000\000\021unexpected object");
lf[375]=C_h_intern(&lf[375],18,"\003sysrepl-eval-hook");
lf[376]=C_h_intern(&lf[376],27,"\003sysrepl-print-length-limit");
lf[377]=C_h_intern(&lf[377],18,"\003sysrepl-read-hook");
lf[378]=C_h_intern(&lf[378],19,"\003sysrepl-print-hook");
lf[379]=C_h_intern(&lf[379],16,"\003syswrite-char-0");
lf[380]=C_h_intern(&lf[380],9,"\003sysprint");
lf[381]=C_h_intern(&lf[381],27,"\003syswith-print-length-limit");
lf[382]=C_h_intern(&lf[382],11,"repl-prompt");
lf[383]=C_h_intern(&lf[383],20,"\003sysread-prompt-hook");
lf[384]=C_h_intern(&lf[384],16,"\003sysflush-output");
lf[385]=C_h_intern(&lf[385],19,"\003sysstandard-output");
lf[386]=C_h_intern(&lf[386],22,"\003sysclear-trace-buffer");
lf[387]=C_h_intern(&lf[387],16,"print-call-chain");
lf[388]=C_h_intern(&lf[388],12,"flush-output");
lf[389]=C_h_intern(&lf[389],5,"reset");
lf[390]=C_h_intern(&lf[390],4,"repl");
lf[391]=C_h_intern(&lf[391],18,"\003sysstandard-error");
lf[392]=C_h_intern(&lf[392],18,"\003sysstandard-input");
lf[393]=C_decode_literal(C_heaptop,"\376B\000\000\002: ");
lf[394]=C_decode_literal(C_heaptop,"\376B\000\000\002: ");
lf[395]=C_decode_literal(C_heaptop,"\376B\000\000\005Error");
lf[396]=C_h_intern(&lf[396],17,"\003syserror-handler");
lf[397]=C_h_intern(&lf[397],20,"\003syswarnings-enabled");
lf[398]=C_decode_literal(C_heaptop,"\376B\000\000\005 (in ");
lf[399]=C_decode_literal(C_heaptop,"\376B\000\000\002  ");
lf[400]=C_decode_literal(C_heaptop,"\376B\000\000FWarning: the following toplevel variables are referenced but unbound:\012");
lf[401]=C_h_intern(&lf[401],15,"\003sysread-char-0");
lf[402]=C_h_intern(&lf[402],15,"\003syspeek-char-0");
lf[403]=C_h_intern(&lf[403],21,"\003sysenable-qualifiers");
lf[404]=C_h_intern(&lf[404],17,"\003sysreset-handler");
lf[405]=C_h_intern(&lf[405],28,"\003syssharp-comma-reader-ctors");
lf[406]=C_h_intern(&lf[406],18,"define-reader-ctor");
lf[407]=C_h_intern(&lf[407],18,"\003sysuser-read-hook");
lf[408]=C_h_intern(&lf[408],9,"read-char");
lf[409]=C_h_intern(&lf[409],14,"\003sysread-error");
lf[410]=C_decode_literal(C_heaptop,"\376B\000\000!invalid sharp-comma external form");
lf[411]=C_decode_literal(C_heaptop,"\376B\000\000!undefined sharp-comma constructor");
lf[414]=C_h_intern(&lf[414],19,"print-error-message");
lf[416]=C_h_intern(&lf[416],6,"\003sysgc");
lf[418]=C_h_intern(&lf[418],13,"thread-yield!");
lf[421]=C_h_intern(&lf[421],17,"open-input-string");
lf[423]=C_decode_literal(C_heaptop,"\376B\000\000(Error: not enough room for result string");
lf[431]=C_decode_literal(C_heaptop,"\376B\000\000\010No error");
lf[432]=C_h_intern(&lf[432],15,"\003sysmake-string");
lf[433]=C_h_intern(&lf[433],6,"module");
lf[434]=C_decode_literal(C_heaptop,"\376B\000\000\031modules are not supported");
lf[435]=C_h_intern(&lf[435],13,"define-syntax");
lf[436]=C_decode_literal(C_heaptop,"\376B\000\000\042highlevel macros are not supported");
lf[437]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[438]=C_h_intern(&lf[438],12,"define-macro");
lf[439]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[440]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[441]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006symbol\376\001\000\000\013lambda-list");
lf[442]=C_decode_literal(C_heaptop,"\376B\000\000\004#;> ");
lf[443]=C_h_intern(&lf[443],14,"make-parameter");
lf[444]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\007\000srfi-8\376\003\000\000\002\376\001\000\000\007\000srfi-6\376\003\000\000\002\376\001\000\000\007\000srfi-2\376\003\000\000\002\376\001\000\000\007\000srfi-0\376\003\000\000\002\376\001\000\000\010\000s"
"rfi-10\376\003\000\000\002\376\001\000\000\007\000srfi-9\376\003\000\000\002\376\001\000\000\010\000srfi-55\376\003\000\000\002\376\001\000\000\010\000srfi-61\376\377\016");
lf[445]=C_h_intern(&lf[445],11,"cond-expand");
lf[446]=C_decode_literal(C_heaptop,"\376B\000\000\042syntax error in `cond-expand\047 form");
lf[447]=C_h_intern(&lf[447],3,"and");
lf[448]=C_h_intern(&lf[448],2,"or");
lf[449]=C_h_intern(&lf[449],3,"not");
lf[450]=C_decode_literal(C_heaptop,"\376B\000\000(no matching clause in `cond-expand\047 form");
lf[451]=C_h_intern(&lf[451],4,"else");
lf[452]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[453]=C_h_intern(&lf[453],16,"\003sysmake-promise");
lf[454]=C_h_intern(&lf[454],5,"delay");
lf[455]=C_h_intern(&lf[455],16,"\003syslist->vector");
lf[456]=C_h_intern(&lf[456],7,"unquote");
lf[457]=C_h_intern(&lf[457],8,"\003syslist");
lf[458]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005quote\376\003\000\000\002\376\001\000\000\007unquote\376\377\016");
lf[459]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005quote\376\003\000\000\002\376\001\000\000\007unquote\376\377\016");
lf[460]=C_h_intern(&lf[460],10,"quasiquote");
lf[461]=C_h_intern(&lf[461],8,"\003syscons");
lf[462]=C_h_intern(&lf[462],16,"unquote-splicing");
lf[463]=C_h_intern(&lf[463],1,"a");
lf[464]=C_h_intern(&lf[464],1,"b");
lf[465]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\012\003sysappend\376\003\000\000\002\376\001\000\000\001a\376\003\000\000\002\376\003\000\000\002\376\001\000\000\005quote\376\003\000\000\002\376\377\016\376\377\016\376\377\016");
lf[466]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001a\376\377\016");
lf[467]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010\003syscons\376\003\000\000\002\376\001\000\000\001a\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010\003syslist\376\001\000\000\001b\376\377\016");
lf[468]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001a\376\003\000\000\002\376\001\000\000\001b\376\377\016");
lf[469]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010\003syscons\376\003\000\000\002\376\001\000\000\001a\376\003\000\000\002\376\003\000\000\002\376\001\000\000\005quote\376\003\000\000\002\376\377\016\376\377\016\376\377\016");
lf[470]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001a\376\377\016");
lf[471]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[472]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[473]=C_decode_literal(C_heaptop,"\376B\000\000\002do");
lf[474]=C_h_intern(&lf[474],2,"do");
lf[475]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[476]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\001\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[477]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[478]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[479]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000");
lf[480]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[481]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000");
lf[482]=C_h_intern(&lf[482],4,"eqv\077");
lf[483]=C_h_intern(&lf[483],4,"case");
lf[484]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[485]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[486]=C_h_intern(&lf[486],2,"=>");
lf[487]=C_h_intern(&lf[487],9,"\003sysapply");
lf[488]=C_h_intern(&lf[488],4,"cond");
lf[489]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[490]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[491]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[492]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\013lambda-list");
lf[493]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[494]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006symbol\376\001\000\000\013lambda-list");
lf[495]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010\003sysvoid\376\377\016");
lf[496]=C_decode_literal(C_heaptop,"\376\000\000\000\003\376\001\000\000\001_\376\377\001\000\000\000\000\376\377\001\000\000\000\001");
lf[497]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\014dynamic-wind\376\003\000\000\002\376\001\000\000\006values\376\003\000\000\002\376\001\000\000\020call-with-values\376\003\000\000\002\376\001\000\000\004eval\376\003"
"\000\000\002\376\001\000\000\031scheme-report-environment\376\003\000\000\002\376\001\000\000\020null-environment\376\003\000\000\002\376\001\000\000\027interaction"
"-environment\376\377\016");
lf[498]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\003not\376\003\000\000\002\376\001\000\000\010boolean\077\376\003\000\000\002\376\001\000\000\003eq\077\376\003\000\000\002\376\001\000\000\004eqv\077\376\003\000\000\002\376\001\000\000\006equal\077\376\003\000\000\002\376"
"\001\000\000\005pair\077\376\003\000\000\002\376\001\000\000\004cons\376\003\000\000\002\376\001\000\000\003car\376\003\000\000\002\376\001\000\000\003cdr\376\003\000\000\002\376\001\000\000\004caar\376\003\000\000\002\376\001\000\000\004cadr\376\003\000"
"\000\002\376\001\000\000\004cdar\376\003\000\000\002\376\001\000\000\004cddr\376\003\000\000\002\376\001\000\000\005caaar\376\003\000\000\002\376\001\000\000\005caadr\376\003\000\000\002\376\001\000\000\005cadar\376\003\000\000\002\376\001\000\000\005"
"caddr\376\003\000\000\002\376\001\000\000\005cdaar\376\003\000\000\002\376\001\000\000\005cdadr\376\003\000\000\002\376\001\000\000\005cddar\376\003\000\000\002\376\001\000\000\005cdddr\376\003\000\000\002\376\001\000\000\006caaaa"
"r\376\003\000\000\002\376\001\000\000\006caaadr\376\003\000\000\002\376\001\000\000\006caadar\376\003\000\000\002\376\001\000\000\006caaddr\376\003\000\000\002\376\001\000\000\006cadaar\376\003\000\000\002\376\001\000\000\006cadad"
"r\376\003\000\000\002\376\001\000\000\006cadddr\376\003\000\000\002\376\001\000\000\006cdaaar\376\003\000\000\002\376\001\000\000\006cdaadr\376\003\000\000\002\376\001\000\000\006cdadar\376\003\000\000\002\376\001\000\000\006cdadd"
"r\376\003\000\000\002\376\001\000\000\006cddaar\376\003\000\000\002\376\001\000\000\006cddadr\376\003\000\000\002\376\001\000\000\006cdddar\376\003\000\000\002\376\001\000\000\006cddddr\376\003\000\000\002\376\001\000\000\010set-c"
"ar!\376\003\000\000\002\376\001\000\000\010set-cdr!\376\003\000\000\002\376\001\000\000\005null\077\376\003\000\000\002\376\001\000\000\005list\077\376\003\000\000\002\376\001\000\000\004list\376\003\000\000\002\376\001\000\000\006lengt"
"h\376\003\000\000\002\376\001\000\000\011list-tail\376\003\000\000\002\376\001\000\000\010list-ref\376\003\000\000\002\376\001\000\000\006append\376\003\000\000\002\376\001\000\000\007reverse\376\003\000\000\002\376\001\000\000"
"\004memq\376\003\000\000\002\376\001\000\000\004memv\376\003\000\000\002\376\001\000\000\006member\376\003\000\000\002\376\001\000\000\004assq\376\003\000\000\002\376\001\000\000\004assv\376\003\000\000\002\376\001\000\000\005assoc\376\003"
"\000\000\002\376\001\000\000\007symbol\077\376\003\000\000\002\376\001\000\000\016symbol->string\376\003\000\000\002\376\001\000\000\016string->symbol\376\003\000\000\002\376\001\000\000\007number\077"
"\376\003\000\000\002\376\001\000\000\010integer\077\376\003\000\000\002\376\001\000\000\006exact\077\376\003\000\000\002\376\001\000\000\005real\077\376\003\000\000\002\376\001\000\000\010complex\077\376\003\000\000\002\376\001\000\000\010ine"
"xact\077\376\003\000\000\002\376\001\000\000\011rational\077\376\003\000\000\002\376\001\000\000\005zero\077\376\003\000\000\002\376\001\000\000\004odd\077\376\003\000\000\002\376\001\000\000\005even\077\376\003\000\000\002\376\001\000\000\011po"
"sitive\077\376\003\000\000\002\376\001\000\000\011negative\077\376\003\000\000\002\376\001\000\000\003max\376\003\000\000\002\376\001\000\000\003min\376\003\000\000\002\376\001\000\000\001+\376\003\000\000\002\376\001\000\000\001-\376\003\000\000\002\376"
"\001\000\000\001*\376\003\000\000\002\376\001\000\000\001/\376\003\000\000\002\376\001\000\000\001=\376\003\000\000\002\376\001\000\000\001>\376\003\000\000\002\376\001\000\000\001<\376\003\000\000\002\376\001\000\000\002>=\376\003\000\000\002\376\001\000\000\002<=\376\003\000\000\002\376\001"
"\000\000\010quotient\376\003\000\000\002\376\001\000\000\011remainder\376\003\000\000\002\376\001\000\000\006modulo\376\003\000\000\002\376\001\000\000\003gcd\376\003\000\000\002\376\001\000\000\003lcm\376\003\000\000\002\376\001\000"
"\000\003abs\376\003\000\000\002\376\001\000\000\005floor\376\003\000\000\002\376\001\000\000\007ceiling\376\003\000\000\002\376\001\000\000\010truncate\376\003\000\000\002\376\001\000\000\005round\376\003\000\000\002\376\001\000\000\016"
"exact->inexact\376\003\000\000\002\376\001\000\000\016inexact->exact\376\003\000\000\002\376\001\000\000\003exp\376\003\000\000\002\376\001\000\000\003log\376\003\000\000\002\376\001\000\000\004expt\376\003"
"\000\000\002\376\001\000\000\004sqrt\376\003\000\000\002\376\001\000\000\003sin\376\003\000\000\002\376\001\000\000\003cos\376\003\000\000\002\376\001\000\000\003tan\376\003\000\000\002\376\001\000\000\004asin\376\003\000\000\002\376\001\000\000\004acos\376"
"\003\000\000\002\376\001\000\000\004atan\376\003\000\000\002\376\001\000\000\016number->string\376\003\000\000\002\376\001\000\000\016string->number\376\003\000\000\002\376\001\000\000\005char\077\376\003\000\000"
"\002\376\001\000\000\006char=\077\376\003\000\000\002\376\001\000\000\006char>\077\376\003\000\000\002\376\001\000\000\006char<\077\376\003\000\000\002\376\001\000\000\007char>=\077\376\003\000\000\002\376\001\000\000\007char<=\077\376\003"
"\000\000\002\376\001\000\000\011char-ci=\077\376\003\000\000\002\376\001\000\000\011char-ci<\077\376\003\000\000\002\376\001\000\000\011char-ci>\077\376\003\000\000\002\376\001\000\000\012char-ci>=\077\376\003\000\000\002"
"\376\001\000\000\012char-ci<=\077\376\003\000\000\002\376\001\000\000\020char-alphabetic\077\376\003\000\000\002\376\001\000\000\020char-whitespace\077\376\003\000\000\002\376\001\000\000\015cha"
"r-numeric\077\376\003\000\000\002\376\001\000\000\020char-upper-case\077\376\003\000\000\002\376\001\000\000\020char-lower-case\077\376\003\000\000\002\376\001\000\000\013char-upc"
"ase\376\003\000\000\002\376\001\000\000\015char-downcase\376\003\000\000\002\376\001\000\000\015char->integer\376\003\000\000\002\376\001\000\000\015integer->char\376\003\000\000\002\376\001\000"
"\000\007string\077\376\003\000\000\002\376\001\000\000\010string=\077\376\003\000\000\002\376\001\000\000\010string>\077\376\003\000\000\002\376\001\000\000\010string<\077\376\003\000\000\002\376\001\000\000\011string>"
"=\077\376\003\000\000\002\376\001\000\000\011string<=\077\376\003\000\000\002\376\001\000\000\013string-ci=\077\376\003\000\000\002\376\001\000\000\013string-ci<\077\376\003\000\000\002\376\001\000\000\013string-"
"ci>\077\376\003\000\000\002\376\001\000\000\014string-ci>=\077\376\003\000\000\002\376\001\000\000\014string-ci<=\077\376\003\000\000\002\376\001\000\000\013make-string\376\003\000\000\002\376\001\000\000\015s"
"tring-length\376\003\000\000\002\376\001\000\000\012string-ref\376\003\000\000\002\376\001\000\000\013string-set!\376\003\000\000\002\376\001\000\000\015string-append\376\003\000\000"
"\002\376\001\000\000\013string-copy\376\003\000\000\002\376\001\000\000\014string->list\376\003\000\000\002\376\001\000\000\014list->string\376\003\000\000\002\376\001\000\000\011substring"
"\376\003\000\000\002\376\001\000\000\014string-fill!\376\003\000\000\002\376\001\000\000\007vector\077\376\003\000\000\002\376\001\000\000\013make-vector\376\003\000\000\002\376\001\000\000\012vector-ref"
"\376\003\000\000\002\376\001\000\000\013vector-set!\376\003\000\000\002\376\001\000\000\006string\376\003\000\000\002\376\001\000\000\006vector\376\003\000\000\002\376\001\000\000\015vector-length\376\003\000\000"
"\002\376\001\000\000\014vector->list\376\003\000\000\002\376\001\000\000\014list->vector\376\003\000\000\002\376\001\000\000\014vector-fill!\376\003\000\000\002\376\001\000\000\012procedur"
"e\077\376\003\000\000\002\376\001\000\000\003map\376\003\000\000\002\376\001\000\000\010for-each\376\003\000\000\002\376\001\000\000\005apply\376\003\000\000\002\376\001\000\000\005force\376\003\000\000\002\376\001\000\000\036call-wi"
"th-current-continuation\376\003\000\000\002\376\001\000\000\013input-port\077\376\003\000\000\002\376\001\000\000\014output-port\077\376\003\000\000\002\376\001\000\000\022curr"
"ent-input-port\376\003\000\000\002\376\001\000\000\023current-output-port\376\003\000\000\002\376\001\000\000\024call-with-input-file\376\003\000\000\002\376\001"
"\000\000\025call-with-output-file\376\003\000\000\002\376\001\000\000\017open-input-file\376\003\000\000\002\376\001\000\000\020open-output-file\376\003\000\000\002"
"\376\001\000\000\020close-input-port\376\003\000\000\002\376\001\000\000\021close-output-port\376\003\000\000\002\376\001\000\000\004load\376\003\000\000\002\376\001\000\000\004read\376\003\000\000"
"\002\376\001\000\000\013eof-object\077\376\003\000\000\002\376\001\000\000\011read-char\376\003\000\000\002\376\001\000\000\011peek-char\376\003\000\000\002\376\001\000\000\005write\376\003\000\000\002\376\001\000\000\007"
"display\376\003\000\000\002\376\001\000\000\012write-char\376\003\000\000\002\376\001\000\000\007newline\376\003\000\000\002\376\001\000\000\024with-input-from-file\376\003\000\000\002\376"
"\001\000\000\023with-output-to-file\376\003\000\000\002\376\001\000\000\024\003syscall-with-values\376\003\000\000\002\376\001\000\000\012\003sysvalues\376\003\000\000\002\376\001"
"\000\000\020\003sysdynamic-wind\376\003\000\000\002\376\001\000\000\010\003sysvoid\376\003\000\000\002\376\001\000\000\020\003syslist->vector\376\003\000\000\002\376\001\000\000\010\003syslis"
"t\376\003\000\000\002\376\001\000\000\012\003sysappend\376\003\000\000\002\376\001\000\000\010\003syscons\376\003\000\000\002\376\001\000\000\020\003sysmake-promise\376\377\016");
lf[499]=C_h_intern(&lf[499],18,"\003sysnumber->string");
lf[500]=C_h_intern(&lf[500],5,"error");
lf[501]=C_decode_literal(C_heaptop,"\376B\000\000\031invalid extension version");
lf[502]=C_h_intern(&lf[502],7,"version");
lf[503]=C_decode_literal(C_heaptop,"\376B\000\0003installed extension does not match required version");
lf[504]=C_h_intern(&lf[504],9,"string>=\077");
lf[505]=C_decode_literal(C_heaptop,"\376B\000\000\035invalid version specification");
lf[506]=C_h_intern(&lf[506],12,"list->vector");
lf[507]=C_h_intern(&lf[507],18,"\003sysstring->symbol");
lf[508]=C_decode_literal(C_heaptop,"\376B\000\000\005srfi-");
lf[509]=C_h_intern(&lf[509],4,"srfi");
lf[510]=C_decode_literal(C_heaptop,"\376B\000\000\014lib/chicken/");
lf[511]=C_h_intern(&lf[511],14,"build-platform");
lf[512]=C_h_intern(&lf[512],7,"windows");
lf[513]=C_h_intern(&lf[513],6,"macosx");
lf[514]=C_h_intern(&lf[514],4,"hpux");
lf[515]=C_h_intern(&lf[515],4,"hppa");
lf[516]=C_h_intern(&lf[516],12,"machine-type");
lf[517]=C_h_intern(&lf[517],16,"software-version");
lf[518]=C_h_intern(&lf[518],13,"software-type");
lf[519]=C_decode_literal(C_heaptop,"\376B\000\000\012C_toplevel");
lf[520]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000\134\376\003\000\000\002\376\377\012\000\000/\376\377\016");
lf[521]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[522]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
C_register_lf2(lf,523,create_ptable());
t2=C_mutate(&lf[0],lf[1]);
t3=C_mutate((C_word*)lf[2]+1,lf[3]);
t4=C_set_block_item(lf[4],0,C_SCHEME_END_OF_LIST);
t5=C_mutate(&lf[5],lf[6]);
t6=C_mutate(&lf[7],lf[8]);
t7=C_mutate(&lf[9],lf[10]);
t8=C_mutate(&lf[11],lf[12]);
t9=C_mutate(&lf[13],lf[14]);
t10=C_mutate(&lf[15],lf[16]);
t11=C_mutate(&lf[17],lf[18]);
t12=C_mutate(&lf[19],lf[20]);
t13=C_mutate(&lf[21],lf[22]);
t14=C_mutate(&lf[23],lf[24]);
t15=C_mutate(&lf[25],lf[26]);
t16=C_mutate(&lf[27],lf[28]);
t17=C_mutate(&lf[29],lf[30]);
t18=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1730,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 136  getenv */
t19=*((C_word*)lf[33]+1);
((C_proc3)(void*)(*((C_word*)t19+1)))(3,t19,t18,lf[24]);}

/* k1728 */
static void C_ccall f_1730(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1730,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1733,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
t3=(C_word)C_block_size(t1);
t4=(C_word)C_u_fixnum_difference(t3,C_fix(1));
t5=(C_word)C_subchar(t1,t4);
t6=(C_word)C_u_i_memq(t5,lf[520]);
t7=(C_truep(t6)?lf[521]:lf[522]);
/* eval.scm: 137  ##sys#string-append */
t8=*((C_word*)lf[32]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t2,t1,t7);}
else{
t3=t2;
f_1733(2,t3,C_SCHEME_FALSE);}}

/* k1731 in k1728 */
static void C_ccall f_1733(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1733,2,t0,t1);}
t2=C_mutate((C_word*)lf[31]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1734,a[2]=t1,tmp=(C_word)a,a+=3,tmp));
t3=*((C_word*)lf[33]+1);
t4=C_mutate((C_word*)lf[34]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1761,tmp=(C_word)a,a+=2,tmp));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1775,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 157  make-vector */
t6=*((C_word*)lf[329]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,C_fix(301),C_SCHEME_END_OF_LIST);}

/* k1773 in k1731 in k1728 */
static void C_ccall f_1775(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word ab[71],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1775,2,t0,t1);}
t2=C_mutate((C_word*)lf[37]+1,t1);
t3=C_mutate((C_word*)lf[38]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1777,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate((C_word*)lf[40]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1793,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[41]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1809,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[43]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1819,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate((C_word*)lf[44]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1837,tmp=(C_word)a,a+=2,tmp));
t8=*((C_word*)lf[45]+1);
t9=C_mutate((C_word*)lf[46]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1846,a[2]=t8,tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[72]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2216,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate((C_word*)lf[73]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2219,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate((C_word*)lf[74]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2222,tmp=(C_word)a,a+=2,tmp));
t13=C_set_block_item(lf[75],0,C_SCHEME_FALSE);
t14=C_mutate((C_word*)lf[76]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2229,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate((C_word*)lf[77]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2265,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate((C_word*)lf[78]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2281,tmp=(C_word)a,a+=2,tmp));
t17=*((C_word*)lf[82]+1);
t18=*((C_word*)lf[83]+1);
t19=C_mutate((C_word*)lf[84]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2324,a[2]=t18,a[3]=t17,tmp=(C_word)a,a+=4,tmp));
t20=*((C_word*)lf[82]+1);
t21=*((C_word*)lf[104]+1);
t22=C_mutate((C_word*)lf[105]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2843,a[2]=t21,a[3]=t20,tmp=(C_word)a,a+=4,tmp));
t23=C_mutate((C_word*)lf[119]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3326,tmp=(C_word)a,a+=2,tmp));
t24=C_mutate((C_word*)lf[111]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3417,tmp=(C_word)a,a+=2,tmp));
t25=C_SCHEME_FALSE;
t26=(*a=C_VECTOR_TYPE|1,a[1]=t25,tmp=(C_word)a,a+=2,tmp);
t27=C_SCHEME_FALSE;
t28=(*a=C_VECTOR_TYPE|1,a[1]=t27,tmp=(C_word)a,a+=2,tmp);
t29=C_mutate((C_word*)lf[120]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3477,a[2]=t28,a[3]=t26,tmp=(C_word)a,a+=4,tmp));
t30=C_mutate((C_word*)lf[42]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3492,tmp=(C_word)a,a+=2,tmp));
t31=C_mutate((C_word*)lf[39]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3537,tmp=(C_word)a,a+=2,tmp));
t32=C_mutate((C_word*)lf[121]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3592,tmp=(C_word)a,a+=2,tmp));
t33=C_mutate((C_word*)lf[122]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3612,tmp=(C_word)a,a+=2,tmp));
t34=C_mutate((C_word*)lf[124]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3655,tmp=(C_word)a,a+=2,tmp));
t35=(C_word)C_slot(lf[126],C_fix(0));
t36=C_mutate((C_word*)lf[127]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3722,a[2]=t35,tmp=(C_word)a,a+=3,tmp));
t37=C_set_block_item(lf[128],0,C_SCHEME_FALSE);
t38=C_set_block_item(lf[129],0,C_SCHEME_FALSE);
t39=C_mutate((C_word*)lf[130]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3782,tmp=(C_word)a,a+=2,tmp));
t40=C_set_block_item(lf[136],0,C_SCHEME_FALSE);
t41=C_set_block_item(lf[137],0,C_fix(1));
t42=C_mutate((C_word*)lf[138]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3823,tmp=(C_word)a,a+=2,tmp));
t43=*((C_word*)lf[43]+1);
t44=*((C_word*)lf[133]+1);
t45=*((C_word*)lf[139]+1);
t46=*((C_word*)lf[82]+1);
t47=*((C_word*)lf[134]+1);
t48=*((C_word*)lf[132]+1);
t49=*((C_word*)lf[140]+1);
t50=(C_word)C_slot(lf[126],C_fix(0));
t51=*((C_word*)lf[141]+1);
t52=C_mutate((C_word*)lf[142]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3829,a[2]=t45,a[3]=t50,tmp=(C_word)a,a+=4,tmp));
t53=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6065,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t54=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11451,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 1057 make-parameter */
t55=*((C_word*)lf[443]+1);
((C_proc3)(void*)(*((C_word*)t55+1)))(3,t55,t53,t54);}

/* a11450 in k1773 in k1731 in k1728 */
static void C_ccall f_11451(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr3rv,(void*)f_11451r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_11451r(t0,t1,t2,t3);}}

static void C_ccall f_11451r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(10);
t4=*((C_word*)lf[129]+1);
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11455,a[2]=t2,a[3]=t1,a[4]=t7,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_notvemptyp(t3))){
t9=(C_word)C_slot(t3,C_fix(0));
if(C_truep(t9)){
t10=(C_word)C_i_check_structure(t9,lf[321]);
t11=(C_word)C_slot(t9,C_fix(1));
t12=C_set_block_item(t7,0,t11);
t13=(C_word)C_slot(t9,C_fix(2));
t14=C_set_block_item(t5,0,t13);
t15=t8;
f_11455(t15,t14);}
else{
t10=t8;
f_11455(t10,C_SCHEME_UNDEFINED);}}
else{
t9=t8;
f_11455(t9,C_SCHEME_UNDEFINED);}}

/* k11453 in a11450 in k1773 in k1731 in k1728 */
static void C_fcall f_11455(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[26],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11455,NULL,2,t0,t1);}
t2=((C_word*)((C_word*)t0)[5])[1];
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=((C_word*)((C_word*)t0)[4])[1];
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_FALSE;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11461,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11463,a[2]=t5,a[3]=t3,a[4]=t9,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
t12=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11473,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t13=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11479,a[2]=t9,a[3]=t7,a[4]=t5,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1067 ##sys#dynamic-wind */
t14=*((C_word*)lf[238]+1);
((C_proc5)(void*)(*((C_word*)t14+1)))(5,t14,t10,t11,t12,t13);}

/* a11478 in k11453 in a11450 in k1773 in k1731 in k1728 */
static void C_ccall f_11479(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11479,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,*((C_word*)lf[129]+1));
t3=C_mutate(((C_word *)((C_word*)t0)[4])+1,*((C_word*)lf[128]+1));
t4=C_mutate((C_word*)lf[129]+1,((C_word*)((C_word*)t0)[3])[1]);
t5=C_mutate((C_word*)lf[128]+1,((C_word*)((C_word*)t0)[2])[1]);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,*((C_word*)lf[231]+1));}

/* a11472 in k11453 in a11450 in k1773 in k1731 in k1728 */
static void C_ccall f_11473(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11473,2,t0,t1);}
/* eval.scm: 1069 ##sys#compile-to-closure */
t2=*((C_word*)lf[142]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[2],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}

/* a11462 in k11453 in a11450 in k1773 in k1731 in k1728 */
static void C_ccall f_11463(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11463,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,*((C_word*)lf[129]+1));
t3=C_mutate(((C_word *)((C_word*)t0)[4])+1,*((C_word*)lf[128]+1));
t4=C_mutate((C_word*)lf[129]+1,((C_word*)((C_word*)t0)[3])[1]);
t5=C_mutate((C_word*)lf[128]+1,((C_word*)((C_word*)t0)[2])[1]);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,*((C_word*)lf[231]+1));}

/* k11459 in k11453 in a11450 in k1773 in k1731 in k1728 */
static void C_ccall f_11461(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_6065(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6065,2,t0,t1);}
t2=C_mutate((C_word*)lf[207]+1,t1);
t3=C_mutate((C_word*)lf[208]+1,*((C_word*)lf[207]+1));
t4=C_mutate((C_word*)lf[209]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6068,tmp=(C_word)a,a+=2,tmp));
t5=*((C_word*)lf[82]+1);
t6=C_mutate((C_word*)lf[165]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6082,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6164,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_fudge(C_fix(13));
/* eval.scm: 1101 make-parameter */
t9=*((C_word*)lf[443]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t7,t8);}

/* k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_6164(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6164,2,t0,t1);}
t2=C_mutate((C_word*)lf[212]+1,t1);
t3=C_mutate((C_word*)lf[213]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6166,tmp=(C_word)a,a+=2,tmp));
t4=C_set_block_item(lf[214],0,C_SCHEME_FALSE);
t5=C_mutate((C_word*)lf[215]+1,lf[216]);
t6=C_mutate((C_word*)lf[217]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6171,tmp=(C_word)a,a+=2,tmp));
t7=*((C_word*)lf[225]+1);
t8=*((C_word*)lf[133]+1);
t9=*((C_word*)lf[141]+1);
t10=*((C_word*)lf[226]+1);
t11=*((C_word*)lf[209]+1);
t12=*((C_word*)lf[227]+1);
t13=*((C_word*)lf[228]+1);
t14=*((C_word*)lf[45]+1);
t15=*((C_word*)lf[212]+1);
t16=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6244,a[2]=((C_word*)t0)[2],a[3]=t15,a[4]=t9,a[5]=t12,a[6]=t13,a[7]=t8,a[8]=t10,a[9]=t7,a[10]=t11,tmp=(C_word)a,a+=11,tmp);
/* eval.scm: 1133 ##sys#make-c-string */
t17=*((C_word*)lf[242]+1);
((C_proc3)(void*)(*((C_word*)t17+1)))(3,t17,t16,lf[519]);}

/* k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_6244(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[26],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6244,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6246,tmp=(C_word)a,a+=2,tmp);
t3=C_mutate((C_word*)lf[229]+1,(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6292,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=t2,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp));
t4=C_mutate((C_word*)lf[235]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6679,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[254]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6701,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[255]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6737,tmp=(C_word)a,a+=2,tmp));
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6763,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11445,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1223 software-type */
t9=*((C_word*)lf[518]+1);
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}

/* k11443 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_11445(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11445,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[512]);
if(C_truep(t2)){
t3=((C_word*)t0)[2];
f_6763(t3,lf[12]);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11441,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1224 software-version */
t4=*((C_word*)lf[517]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k11439 in k11443 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_11441(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11441,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[513]);
if(C_truep(t2)){
t3=((C_word*)t0)[2];
f_6763(t3,lf[10]);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11423,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11437,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1225 software-version */
t5=*((C_word*)lf[517]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k11435 in k11439 in k11443 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_11437(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11437,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[514]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11433,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1226 machine-type */
t4=*((C_word*)lf[516]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=((C_word*)t0)[2];
f_11423(t3,C_SCHEME_FALSE);}}

/* k11431 in k11435 in k11439 in k11443 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_11433(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_11423(t2,(C_word)C_eqp(t1,lf[515]));}

/* k11421 in k11439 in k11443 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_fcall f_11423(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_6763(t2,(C_truep(t1)?lf[14]:lf[15]));}

/* k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_fcall f_6763(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6763,NULL,2,t0,t1);}
t2=C_mutate((C_word*)lf[259]+1,t1);
t3=C_mutate((C_word*)lf[249]+1,lf[15]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6768,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1232 build-platform */
t5=*((C_word*)lf[511]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_6768(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6768,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[260]);
t3=(C_truep(t2)?lf[8]:lf[6]);
t4=C_mutate((C_word*)lf[261]+1,t3);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6775,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11393,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11401,tmp=(C_word)a,a+=2,tmp);
/* map */
t8=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,t7,*((C_word*)lf[261]+1));}

/* a11400 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_11401(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11401,3,t0,t1,t2);}
/* ##sys#string-append */
t3=*((C_word*)lf[32]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,*((C_word*)lf[259]+1));}

/* k11391 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_11393(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11393,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11395,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 1237 make-parameter */
t3=*((C_word*)lf[443]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t1,t2);}

/* a11394 in k11391 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_11395(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11395,3,t0,t1,t2);}
t3=(C_word)C_i_check_list(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}

/* k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_6775(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[20],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6775,2,t0,t1);}
t2=C_mutate((C_word*)lf[262]+1,t1);
t3=*((C_word*)lf[212]+1);
t4=*((C_word*)lf[45]+1);
t5=*((C_word*)lf[262]+1);
t6=*((C_word*)lf[141]+1);
t7=C_mutate((C_word*)lf[263]+1,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6777,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t6,tmp=(C_word)a,a+=6,tmp));
t8=C_mutate((C_word*)lf[270]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6883,tmp=(C_word)a,a+=2,tmp));
t9=*((C_word*)lf[82]+1);
t10=C_mutate(&lf[272],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6912,a[2]=t9,tmp=(C_word)a,a+=3,tmp));
t11=*((C_word*)lf[45]+1);
t12=C_mutate((C_word*)lf[273]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6968,a[2]=t11,tmp=(C_word)a,a+=3,tmp));
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7128,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11362,a[2]=t13,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1325 getenv */
t15=*((C_word*)lf[33]+1);
((C_proc3)(void*)(*((C_word*)t15+1)))(3,t15,t14,lf[22]);}

/* k11360 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_11362(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11362,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11365,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
t3=t2;
f_11365(2,t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11368,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11378,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11382,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(C_word)C_fudge(C_fix(42));
t7=(C_truep(t6)?t6:C_fix(3));
/* eval.scm: 1329 ##sys#number->string */
t8=*((C_word*)lf[499]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t5,t7);}}

/* k11380 in k11360 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_11382(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1327 ##sys#string-append */
t2=*((C_word*)lf[32]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[510],t1);}

/* k11376 in k11360 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_11378(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1326 ##sys#chicken-prefix */
t2=*((C_word*)lf[31]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k11366 in k11360 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_11368(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11368,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
f_11365(2,t2,t1);}
else{
/* ##sys#peek-c-string */
t2=*((C_word*)lf[35]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_mpointer(&a,(void*)C_INSTALL_EGG_HOME),C_fix(0));}}

/* k11363 in k11360 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_11365(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1324 make-parameter */
t2=*((C_word*)lf[443]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_7128(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word ab[34],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7128,2,t0,t1);}
t2=C_mutate((C_word*)lf[279]+1,t1);
t3=C_mutate((C_word*)lf[280]+1,*((C_word*)lf[279]+1));
t4=*((C_word*)lf[281]+1);
t5=*((C_word*)lf[45]+1);
t6=C_mutate((C_word*)lf[282]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7131,a[2]=t5,a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t7=C_set_block_item(lf[286],0,C_SCHEME_END_OF_LIST);
t8=*((C_word*)lf[287]+1);
t9=C_mutate((C_word*)lf[288]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7208,a[2]=t8,tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[290]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7276,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate((C_word*)lf[291]+1,*((C_word*)lf[290]+1));
t12=C_mutate((C_word*)lf[292]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7296,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate((C_word*)lf[293]+1,*((C_word*)lf[292]+1));
t14=C_mutate((C_word*)lf[170]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7310,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate((C_word*)lf[294]+1,*((C_word*)lf[170]+1));
t16=*((C_word*)lf[140]+1);
t17=*((C_word*)lf[281]+1);
t18=*((C_word*)lf[45]+1);
t19=*((C_word*)lf[225]+1);
t20=C_mutate((C_word*)lf[295]+1,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7323,a[2]=t18,a[3]=t17,a[4]=t19,a[5]=t16,tmp=(C_word)a,a+=6,tmp));
t21=C_mutate((C_word*)lf[298]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7354,tmp=(C_word)a,a+=2,tmp));
t22=*((C_word*)lf[140]+1);
t23=*((C_word*)lf[225]+1);
t24=C_mutate((C_word*)lf[171]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7360,tmp=(C_word)a,a+=2,tmp));
t25=*((C_word*)lf[300]+1);
t26=C_mutate((C_word*)lf[174]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7409,a[2]=t25,tmp=(C_word)a,a+=3,tmp));
t27=C_set_block_item(lf[314],0,C_SCHEME_END_OF_LIST);
t28=C_mutate((C_word*)lf[317]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7808,tmp=(C_word)a,a+=2,tmp));
t29=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7847,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t30=*((C_word*)lf[506]+1);
t31=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11308,a[2]=t30,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1516 set-extension-specifier! */
t32=*((C_word*)lf[317]+1);
((C_proc4)(void*)(*((C_word*)t32+1)))(4,t32,t29,lf[509],t31);}

/* a11307 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_11308(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_11308,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11316,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_slot(t2,C_fix(1));
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11322,a[2]=t7,tmp=(C_word)a,a+=3,tmp));
t9=((C_word*)t7)[1];
f_11322(t9,t4,t5);}

/* loop in a11307 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_fcall f_11322(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11322,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_i_check_exact_2(t3,lf[312]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11342,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11354,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11358,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1526 number->string */
C_number_to_string(3,0,t7,t3);}}

/* k11356 in loop in a11307 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_11358(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1526 ##sys#string-append */
t2=*((C_word*)lf[32]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[508],t1);}

/* k11352 in loop in a11307 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_11354(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1526 ##sys#string->symbol */
t2=*((C_word*)lf[507]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k11340 in loop in a11307 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_11342(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11342,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11346,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* eval.scm: 1527 loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_11322(t4,t2,t3);}

/* k11344 in k11340 in loop in a11307 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_11346(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11346,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k11314 in a11307 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_11316(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1520 list->vector */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_7847(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7847,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7850,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11187,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 1532 set-extension-specifier! */
t4=*((C_word*)lf[317]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,lf[502],t3);}

/* a11186 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_11187(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_11187,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11190,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11224,a[2]=t4,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t6=(C_word)C_u_i_car(t2);
t7=(C_word)C_eqp(t6,lf[502]);
if(C_truep(t7)){
t8=(C_word)C_slot(t2,C_fix(1));
if(C_truep((C_word)C_i_pairp(t8))){
t9=(C_word)C_u_i_cddr(t2);
if(C_truep((C_word)C_i_pairp(t9))){
t10=(C_word)C_u_i_cdddr(t2);
t11=t5;
f_11224(t11,(C_word)C_i_nullp(t10));}
else{
t10=t5;
f_11224(t10,C_SCHEME_FALSE);}}
else{
t9=t5;
f_11224(t9,C_SCHEME_FALSE);}}
else{
t8=t5;
f_11224(t8,C_SCHEME_FALSE);}}
else{
t6=t5;
f_11224(t6,C_SCHEME_FALSE);}}

/* k11222 in a11186 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_fcall f_11224(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11224,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_u_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_u_i_caddr(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11233,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t2,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1542 extension-information */
t5=*((C_word*)lf[298]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}
else{
/* syntax-error */
t2=*((C_word*)lf[341]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[312],lf[505],((C_word*)t0)[4]);}}

/* k11231 in k11222 in a11186 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_11233(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11233,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_u_i_assq(lf[502],t1):C_SCHEME_FALSE);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11239,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11242,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11252,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_u_i_car(t2);
/* eval.scm: 1544 ->string */
f_11190(t5,t6);}
else{
t5=t4;
f_11242(2,t5,C_SCHEME_FALSE);}}

/* k11250 in k11231 in k11222 in a11186 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_11252(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11252,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11256,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1544 ->string */
f_11190(t2,((C_word*)t0)[2]);}

/* k11254 in k11250 in k11231 in k11222 in a11186 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_11256(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1544 string>=? */
t2=*((C_word*)lf[504]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k11240 in k11231 in k11222 in a11186 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_11242(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
f_11239(2,t2,C_SCHEME_UNDEFINED);}
else{
/* eval.scm: 1545 error */
t2=*((C_word*)lf[500]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[5],lf[503],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k11237 in k11231 in k11222 in a11186 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_11239(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* ->string in a11186 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_fcall f_11190(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11190,NULL,2,t1,t2);}
if(C_truep((C_word)C_i_stringp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
if(C_truep((C_word)C_i_symbolp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}
else{
if(C_truep((C_word)C_i_numberp(t2))){
/* eval.scm: 1538 ##sys#number->string */
t3=*((C_word*)lf[499]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}
else{
/* eval.scm: 1539 error */
t3=*((C_word*)lf[500]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,lf[501],t2);}}}}

/* k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_7850(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7850,2,t0,t1);}
t2=*((C_word*)lf[318]+1);
t3=C_mutate((C_word*)lf[268]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7852,a[2]=t2,tmp=(C_word)a,a+=3,tmp));
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7908,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1566 make-vector */
t5=*((C_word*)lf[329]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_fix(301),C_SCHEME_END_OF_LIST);}

/* k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_7908(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[24],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7908,2,t0,t1);}
t2=C_mutate(&lf[319],t1);
t3=lf[320]=C_SCHEME_FALSE;;
t4=(C_word)C_a_i_record(&a,3,lf[321],C_SCHEME_FALSE,C_SCHEME_TRUE);
t5=C_mutate(&lf[322],t4);
t6=C_mutate((C_word*)lf[323]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7915,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate((C_word*)lf[324]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8023,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate((C_word*)lf[326]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8142,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate((C_word*)lf[327]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8145,tmp=(C_word)a,a+=2,tmp));
t10=*((C_word*)lf[329]+1);
t11=C_mutate((C_word*)lf[330]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8189,a[2]=t10,tmp=(C_word)a,a+=3,tmp));
t12=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8227,tmp=(C_word)a,a+=2,tmp);
t13=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8243,a[2]=t12,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11185,a[2]=t13,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1647 initb */
f_8227(t14,lf[319]);}

/* k11183 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_11185(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[123]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,lf[498]);}

/* k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_8243(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8243,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8247,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1668 ##sys#copy-env-table */
t3=*((C_word*)lf[323]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[319],C_SCHEME_TRUE,C_SCHEME_TRUE);}

/* k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_8247(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8247,2,t0,t1);}
t2=C_mutate(&lf[320],t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8250,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11181,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1670 initb */
f_8227(t4,lf[320]);}

/* k11179 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_11181(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[123]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,lf[497]);}

/* k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_8250(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8250,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8254,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1677 chicken-home */
t3=*((C_word*)lf[34]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_8254(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word ab[35],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8254,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_a_i_list(&a,1,t1):C_SCHEME_END_OF_LIST);
t3=C_mutate((C_word*)lf[284]+1,t2);
t4=*((C_word*)lf[45]+1);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8260,tmp=(C_word)a,a+=2,tmp);
t6=C_mutate((C_word*)lf[309]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8279,a[2]=t4,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t7=*((C_word*)lf[141]+1);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8402,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8426,a[2]=t8,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
t10=C_mutate((C_word*)lf[232]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8447,a[2]=t9,a[3]=t7,tmp=(C_word)a,a+=4,tmp));
t11=C_set_block_item(lf[339],0,C_SCHEME_FALSE);
t12=C_mutate((C_word*)lf[56]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8501,tmp=(C_word)a,a+=2,tmp));
t13=C_set_block_item(lf[210],0,C_SCHEME_FALSE);
t14=C_mutate((C_word*)lf[341]+1,*((C_word*)lf[56]+1));
t15=C_mutate((C_word*)lf[342]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8509,tmp=(C_word)a,a+=2,tmp));
t16=*((C_word*)lf[45]+1);
t17=*((C_word*)lf[343]+1);
t18=*((C_word*)lf[342]+1);
t19=*((C_word*)lf[344]+1);
t20=C_mutate((C_word*)lf[64]+1,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8545,a[2]=t17,a[3]=t18,a[4]=t19,a[5]=t16,tmp=(C_word)a,a+=6,tmp));
t21=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8937,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t22=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11084,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 1838 ##sys#register-macro-2 */
t23=*((C_word*)lf[38]+1);
((C_proc4)(void*)(*((C_word*)t23+1)))(4,t23,t21,lf[107],t22);}

/* a11083 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_11084(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11084,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11090,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_11090(t6,t1,t2);}

/* loop in a11083 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_fcall f_11090(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11090,NULL,3,t0,t1,t2);}
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_slot(t2,C_fix(1));
if(C_truep((C_word)C_i_pairp(t3))){
t5=(C_word)C_slot(t3,C_fix(0));
if(C_truep((C_word)C_i_pairp(t5))){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11131,a[2]=t4,a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1849 ##sys#check-syntax */
t7=*((C_word*)lf[64]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t6,lf[107],t3,lf[492]);}
else{
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11144,a[2]=t1,a[3]=t4,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1853 ##sys#check-syntax */
t7=*((C_word*)lf[64]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t6,lf[107],t3,lf[494]);}}
else{
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11106,a[2]=t3,a[3]=t1,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1845 ##sys#check-syntax */
t6=*((C_word*)lf[64]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[107],t3,lf[359]);}}

/* k11104 in loop in a11083 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_11106(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11106,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11109,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1846 ##sys#check-syntax */
t3=*((C_word*)lf[64]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[107],((C_word*)t0)[4],lf[496]);}

/* k11107 in k11104 in loop in a11083 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_11109(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11109,2,t0,t1);}
t2=(C_word)C_i_pairp(((C_word*)t0)[4]);
t3=(C_truep(t2)?(C_word)C_u_i_car(((C_word*)t0)[4]):lf[495]);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[71],((C_word*)t0)[2],t3));}

/* k11142 in loop in a11083 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_11144(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11144,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11147,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1854 ##sys#check-syntax */
t3=*((C_word*)lf[64]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[107],((C_word*)t0)[3],lf[493]);}

/* k11145 in k11142 in loop in a11083 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_11147(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11147,2,t0,t1);}
t2=(C_word)C_u_i_car(((C_word*)t0)[4]);
t3=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[3]);
t5=(C_word)C_a_i_cons(&a,2,lf[92],t4);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_list(&a,3,lf[71],t2,t5));}

/* k11129 in loop in a11083 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_11131(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11131,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11134,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1850 ##sys#check-syntax */
t3=*((C_word*)lf[64]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[107],((C_word*)t0)[2],lf[491]);}

/* k11132 in k11129 in loop in a11083 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_11134(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11134,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11141,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1851 ##sys#expand-curried-define */
t3=*((C_word*)lf[111]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k11139 in k11132 in k11129 in loop in a11083 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_11141(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1851 loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_11090(t2,((C_word*)t0)[2],t1);}

/* k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_8937(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8937,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8940,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11056,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 1857 ##sys#register-macro-2 */
t4=*((C_word*)lf[38]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,lf[447],t3);}

/* a11055 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_11056(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11056,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_TRUE);}
else{
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_slot(t2,C_fix(0));
t6=(C_word)C_eqp(t4,C_SCHEME_END_OF_LIST);
if(C_truep(t6)){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t5);}
else{
t7=(C_word)C_a_i_cons(&a,2,lf[447],t4);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_list(&a,4,lf[152],t5,t7,C_SCHEME_FALSE));}}}

/* k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_8940(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8940,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8943,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=*((C_word*)lf[83]+1);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11013,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1868 ##sys#register-macro-2 */
t5=*((C_word*)lf[38]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,lf[448],t4);}

/* a11012 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_11013(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11013,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_slot(t2,C_fix(0));
t6=(C_word)C_eqp(t4,C_SCHEME_END_OF_LIST);
if(C_truep(t6)){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t5);}
else{
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11035,a[2]=t1,a[3]=t4,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1878 gensym */
t8=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}}}

/* k11033 in a11012 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_11035(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[33],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11035,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[4]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(C_word)C_a_i_cons(&a,2,lf[448],((C_word*)t0)[3]);
t5=(C_word)C_a_i_list(&a,4,lf[152],t1,t1,t4);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_list(&a,3,lf[58],t3,t5));}

/* k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_8943(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8943,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8946,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=*((C_word*)lf[83]+1);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10816,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1882 ##sys#register-macro-2 */
t5=*((C_word*)lf[38]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,lf[488],t4);}

/* a10815 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_10816(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10816,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10822,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_10822(t6,t1,t2);}

/* expand in a10815 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_fcall f_10822(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10822,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10838,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 1891 ##sys#check-syntax */
t6=*((C_word*)lf[64]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[488],t3,lf[489]);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[490]);}}

/* k10836 in expand in a10815 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_10838(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[20],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10838,2,t0,t1);}
t2=(C_word)C_u_i_car(((C_word*)t0)[6]);
t3=(C_word)C_eqp(lf[451],t2);
if(C_truep(t3)){
t4=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t5=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,lf[106],t4));}
else{
t4=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t5=(C_word)C_eqp(t4,C_SCHEME_END_OF_LIST);
if(C_truep(t5)){
t6=(C_word)C_u_i_car(((C_word*)t0)[6]);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10868,a[2]=t6,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1893 expand */
t8=((C_word*)((C_word*)t0)[4])[1];
f_10822(t8,t7,((C_word*)t0)[3]);}
else{
t6=(C_word)C_u_i_cadr(((C_word*)t0)[6]);
t7=(C_word)C_eqp(lf[486],t6);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10877,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1895 gensym */
t9=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}
else{
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10914,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_listp(((C_word*)t0)[6]))){
t9=(C_word)C_i_length(((C_word*)t0)[6]);
t10=(C_word)C_eqp(t9,C_fix(4));
if(C_truep(t10)){
t11=(C_word)C_u_i_caddr(((C_word*)t0)[6]);
t12=t8;
f_10914(t12,(C_word)C_eqp(lf[486],t11));}
else{
t11=t8;
f_10914(t11,C_SCHEME_FALSE);}}
else{
t9=t8;
f_10914(t9,C_SCHEME_FALSE);}}}}}

/* k10912 in k10836 in expand in a10815 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_fcall f_10914(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10914,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10917,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1901 gensym */
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=(C_word)C_u_i_car(((C_word*)t0)[6]);
t3=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t4=(C_word)C_a_i_cons(&a,2,lf[106],t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10971,a[2]=t4,a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1910 expand */
t6=((C_word*)((C_word*)t0)[4])[1];
f_10822(t6,t5,((C_word*)t0)[3]);}}

/* k10969 in k10912 in k10836 in expand in a10815 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_10971(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10971,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,4,lf[152],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k10915 in k10912 in k10836 in expand in a10815 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_10917(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[34],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10917,2,t0,t1);}
t2=(C_word)C_u_i_car(((C_word*)t0)[5]);
t3=(C_word)C_a_i_list(&a,3,lf[92],C_SCHEME_END_OF_LIST,t2);
t4=(C_word)C_u_i_cadr(((C_word*)t0)[5]);
t5=(C_word)C_a_i_list(&a,3,lf[487],t4,t1);
t6=(C_word)C_u_i_cadddr(((C_word*)t0)[5]);
t7=(C_word)C_a_i_list(&a,3,lf[487],t6,t1);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10944,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=t7,a[6]=t5,tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 1907 expand */
t9=((C_word*)((C_word*)t0)[3])[1];
f_10822(t9,t8,((C_word*)t0)[2]);}

/* k10942 in k10915 in k10912 in k10836 in expand in a10815 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_10944(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[30],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10944,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,4,lf[152],((C_word*)t0)[6],((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_list(&a,3,lf[92],((C_word*)t0)[4],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[109],((C_word*)t0)[2],t3));}

/* k10875 in k10836 in expand in a10815 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_10877(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[21],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10877,2,t0,t1);}
t2=(C_word)C_u_i_car(((C_word*)t0)[5]);
t3=(C_word)C_a_i_list(&a,2,t1,t2);
t4=(C_word)C_a_i_list(&a,1,t3);
t5=(C_word)C_u_i_caddr(((C_word*)t0)[5]);
t6=(C_word)C_a_i_list(&a,2,t5,t1);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10896,a[2]=t4,a[3]=((C_word*)t0)[4],a[4]=t6,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1899 expand */
t8=((C_word*)((C_word*)t0)[3])[1];
f_10822(t8,t7,((C_word*)t0)[2]);}

/* k10894 in k10875 in k10836 in expand in a10815 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_10896(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[21],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10896,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,4,lf[152],((C_word*)t0)[5],((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,3,lf[58],((C_word*)t0)[2],t2));}

/* k10866 in k10836 in expand in a10815 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_10868(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10868,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[448],((C_word*)t0)[2],t1));}

/* k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_8946(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8946,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8949,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=*((C_word*)lf[83]+1);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10713,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1912 ##sys#register-macro-2 */
t5=*((C_word*)lf[38]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,lf[483],t4);}

/* a10712 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_10713(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10713,3,t0,t1,t2);}
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10723,a[2]=t4,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1918 gensym */
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}

/* k10721 in a10712 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_10723(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10723,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[4]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10734,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10736,a[2]=t1,a[3]=t6,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_10736(t8,t4,((C_word*)t0)[2]);}

/* expand in k10721 in a10712 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_fcall f_10736(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10736,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10752,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 1925 ##sys#check-syntax */
t6=*((C_word*)lf[64]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[483],t3,lf[484]);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[485]);}}

/* k10750 in expand in k10721 in a10712 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_10752(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10752,2,t0,t1);}
t2=(C_word)C_u_i_car(((C_word*)t0)[6]);
t3=(C_word)C_eqp(lf[451],t2);
if(C_truep(t3)){
t4=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t5=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,lf[106],t4));}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10788,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10790,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t6=(C_word)C_u_i_car(((C_word*)t0)[6]);
/* eval.scm: 1928 ##sys#map */
t7=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t4,t5,t6);}}

/* a10789 in k10750 in expand in k10721 in a10712 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_10790(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10790,3,t0,t1,t2);}
t3=(C_word)C_a_i_list(&a,2,lf[90],t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[482],((C_word*)t0)[2],t3));}

/* k10786 in k10750 in expand in k10721 in a10712 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_10788(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10788,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[448],t1);
t3=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t4=(C_word)C_a_i_cons(&a,2,lf[106],t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10780,a[2]=t4,a[3]=t2,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1930 expand */
t6=((C_word*)((C_word*)t0)[3])[1];
f_10736(t6,t5,((C_word*)t0)[2]);}

/* k10778 in k10786 in k10750 in expand in k10721 in a10712 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_10780(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10780,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,4,lf[152],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k10732 in k10721 in a10712 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_10734(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10734,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[58],((C_word*)t0)[2],t1));}

/* k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_8949(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8949,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8952,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10660,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 1932 ##sys#register-macro-2 */
t4=*((C_word*)lf[38]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,lf[89],t3);}

/* a10659 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_10660(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10660,3,t0,t1,t2);}
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10670,a[2]=t3,a[3]=t1,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1937 ##sys#check-syntax */
t6=*((C_word*)lf[64]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[89],t3,lf[481]);}

/* k10668 in a10659 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_10670(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10670,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10673,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1938 ##sys#check-syntax */
t3=*((C_word*)lf[64]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[89],((C_word*)t0)[4],lf[480]);}

/* k10671 in k10668 in a10659 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_10673(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10673,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10678,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_10678(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* expand in k10671 in k10668 in a10659 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_fcall f_10678(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
a=C_alloc(13);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_10678,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t3)){
t4=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,((C_word*)t0)[3]);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,lf[58],t4));}
else{
t4=(C_word)C_u_i_car(t2);
t5=(C_word)C_a_i_list(&a,1,t4);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10703,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_slot(t2,C_fix(1));
/* eval.scm: 1942 expand */
t10=t6;
t11=t7;
t1=t10;
t2=t11;
goto loop;}}

/* k10701 in expand in k10671 in k10668 in a10659 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_10703(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10703,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[58],((C_word*)t0)[2],t1));}

/* k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_8952(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8952,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8955,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10590,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 1944 ##sys#register-macro-2 */
t4=*((C_word*)lf[38]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,lf[60],t3);}

/* a10589 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_10590(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10590,3,t0,t1,t2);}
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10600,a[2]=t3,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1949 ##sys#check-syntax */
t6=*((C_word*)lf[64]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[60],t3,lf[479]);}

/* k10598 in a10589 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_10600(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10600,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10603,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1950 ##sys#check-syntax */
t3=*((C_word*)lf[64]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[60],((C_word*)t0)[3],lf[478]);}

/* k10601 in k10598 in a10589 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_10603(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10603,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10614,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10650,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 1951 ##sys#map */
t4=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a10649 in k10601 in k10598 in a10589 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_10650(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10650,3,t0,t1,t2);}
t3=(C_word)C_u_i_car(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,2,t3,lf[477]));}

/* k10612 in k10601 in k10598 in a10589 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_10614(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10614,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10618,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10622,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10636,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 1952 ##sys#map */
t5=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a10635 in k10612 in k10601 in k10598 in a10589 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_10636(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10636,3,t0,t1,t2);}
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_u_i_cadr(t2);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,3,lf[71],t3,t4));}

/* k10620 in k10612 in k10601 in k10598 in a10589 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_10622(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10622,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,((C_word*)t0)[3]);
t3=(C_word)C_a_i_cons(&a,2,lf[58],t2);
t4=(C_word)C_a_i_list(&a,1,t3);
/* ##sys#append */
t5=*((C_word*)lf[88]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,((C_word*)t0)[2],t1,t4);}

/* k10616 in k10612 in k10601 in k10598 in a10589 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_10618(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10618,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[58],t2));}

/* k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_8955(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8955,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8958,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=*((C_word*)lf[83]+1);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10471,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1955 ##sys#register-macro */
t5=*((C_word*)lf[40]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,lf[474],t4);}

/* a10470 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_10471(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr4r,(void*)f_10471r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_10471r(t0,t1,t2,t3,t4);}}

static void C_ccall f_10471r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(7);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10475,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t2,a[5]=t1,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 1959 ##sys#check-syntax */
t6=*((C_word*)lf[64]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[474],t2,lf[476]);}

/* k10473 in a10470 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_10475(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10475,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10478,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 1960 ##sys#check-syntax */
t3=*((C_word*)lf[64]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[474],((C_word*)t0)[6],lf[475]);}

/* k10476 in k10473 in a10470 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_10478(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10478,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10481,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1961 gensym */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[473]);}

/* k10479 in k10476 in k10473 in a10470 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_10481(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10481,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10488,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10572,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 1962 ##sys#map */
t4=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[3]);}

/* a10571 in k10479 in k10476 in k10473 in a10470 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_10572(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10572,3,t0,t1,t2);}
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_u_i_car(t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_list(&a,2,t3,t5));}

/* k10486 in k10479 in k10476 in k10473 in a10470 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_10488(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10488,2,t0,t1);}
t2=(C_word)C_u_i_car(((C_word*)t0)[6]);
t3=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t4=(C_word)C_eqp(t3,C_SCHEME_END_OF_LIST);
t5=(C_truep(t4)?lf[471]:(C_word)C_a_i_cons(&a,2,lf[106],t3));
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10511,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t5,a[6]=t2,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t7=(C_word)C_eqp(((C_word*)t0)[2],C_SCHEME_END_OF_LIST);
if(C_truep(t7)){
t8=t6;
f_10511(t8,lf[472]);}
else{
t8=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,((C_word*)t0)[2]);
t9=t6;
f_10511(t9,(C_word)C_a_i_cons(&a,2,lf[58],t8));}}

/* k10509 in k10486 in k10479 in k10476 in k10473 in a10470 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_fcall f_10511(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10511,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10523,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10525,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 1973 ##sys#map */
t4=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a10524 in k10509 in k10486 in k10479 in k10476 in k10473 in a10470 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_10525(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10525,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(1));
t4=(C_word)C_slot(t3,C_fix(1));
t5=(C_word)C_eqp(t4,C_SCHEME_END_OF_LIST);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_u_i_car(t2));}
else{
t6=(C_word)C_slot(t2,C_fix(1));
t7=(C_word)C_slot(t6,C_fix(1));
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_u_i_car(t7));}}

/* k10521 in k10509 in k10486 in k10479 in k10476 in k10473 in a10470 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_10523(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[39],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10523,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[61],t2);
t4=(C_word)C_a_i_list(&a,3,lf[106],((C_word*)t0)[6],t3);
t5=(C_word)C_a_i_list(&a,4,lf[152],((C_word*)t0)[5],((C_word*)t0)[4],t4);
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_list(&a,4,lf[58],((C_word*)t0)[7],((C_word*)t0)[2],t5));}

/* k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_8958(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8958,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8961,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=*((C_word*)lf[300]+1);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10179,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1979 ##sys#register-macro */
t5=*((C_word*)lf[40]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,lf[460],t4);}

/* a10178 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_10179(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10179,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10182,a[2]=t6,a[3]=t8,tmp=(C_word)a,a+=4,tmp));
t10=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10192,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t11=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10389,a[2]=t8,tmp=(C_word)a,a+=3,tmp));
/* eval.scm: 2040 walk */
t12=((C_word*)t4)[1];
f_10182(t12,t1,t2,C_fix(0));}

/* simplify in a10178 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_fcall f_10389(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10389,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10393,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 2027 ##sys#match-expression */
t4=*((C_word*)lf[119]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,t2,lf[469],lf[470]);}

/* k10391 in simplify in a10178 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_10393(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10393,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_u_i_assq(lf[463],t1);
t3=(C_word)C_slot(t2,C_fix(1));
t4=(C_word)C_a_i_list(&a,2,lf[457],t3);
/* eval.scm: 2028 simplify */
t5=((C_word*)((C_word*)t0)[4])[1];
f_10389(t5,((C_word*)t0)[3],t4);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10414,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 2029 ##sys#match-expression */
t3=*((C_word*)lf[119]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[2],lf[467],lf[468]);}}

/* k10412 in k10391 in simplify in a10178 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_10414(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10414,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_u_i_assq(lf[464],t1);
t3=(C_word)C_i_length(t2);
if(C_truep((C_word)C_fixnum_lessp(t3,C_fix(32)))){
t4=(C_word)C_u_i_assq(lf[463],t1);
t5=(C_word)C_slot(t4,C_fix(1));
t6=(C_word)C_slot(t2,C_fix(1));
t7=(C_word)C_a_i_cons(&a,2,t5,t6);
t8=(C_word)C_a_i_cons(&a,2,lf[457],t7);
/* eval.scm: 2033 simplify */
t9=((C_word*)((C_word*)t0)[4])[1];
f_10389(t9,((C_word*)t0)[3],t8);}
else{
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[2]);}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10456,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2036 ##sys#match-expression */
t3=*((C_word*)lf[119]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[2],lf[465],lf[466]);}}

/* k10454 in k10412 in k10391 in simplify in a10178 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_10456(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_u_i_assq(lf[463],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* walk1 in a10178 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_fcall f_10192(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word ab[72],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10192,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_blockp(t2))){
if(C_truep((C_word)C_vectorp(t2))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10206,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10210,a[2]=t3,a[3]=t4,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1989 vector->list */
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}
else{
if(C_truep((C_word)C_pairp(t2))){
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_slot(t2,C_fix(1));
t6=(C_word)C_eqp(t4,lf[456]);
if(C_truep(t6)){
t7=(C_truep((C_word)C_blockp(t5))?(C_word)C_pairp(t5):C_SCHEME_FALSE);
if(C_truep(t7)){
t8=(C_word)C_slot(t5,C_fix(0));
t9=(C_word)C_eqp(t3,C_fix(0));
if(C_truep(t9)){
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,t8);}
else{
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10253,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t11=(C_word)C_u_fixnum_difference(t3,C_fix(1));
/* eval.scm: 2001 walk */
t12=((C_word*)((C_word*)t0)[3])[1];
f_10182(t12,t10,t8,t11);}}
else{
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,lf[459]);}}
else{
t7=(C_word)C_eqp(t4,lf[460]);
if(C_truep(t7)){
t8=(C_truep((C_word)C_blockp(t5))?(C_word)C_pairp(t5):C_SCHEME_FALSE);
if(C_truep(t8)){
t9=(C_word)C_a_i_list(&a,2,lf[90],lf[460]);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10280,a[2]=t9,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t11=(C_word)C_slot(t5,C_fix(0));
t12=(C_word)C_u_fixnum_plus(t3,C_fix(1));
/* eval.scm: 2006 walk */
t13=((C_word*)((C_word*)t0)[3])[1];
f_10182(t13,t10,t11,t12);}
else{
t9=(C_word)C_a_i_list(&a,2,lf[90],lf[460]);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10299,a[2]=t9,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2007 walk */
t11=((C_word*)((C_word*)t0)[3])[1];
f_10182(t11,t10,t5,t3);}}
else{
t8=(C_truep((C_word)C_blockp(t4))?(C_word)C_pairp(t4):C_SCHEME_FALSE);
if(C_truep(t8)){
t9=(C_word)C_slot(t4,C_fix(0));
t10=(C_word)C_slot(t4,C_fix(1));
t11=(C_word)C_eqp(t9,lf[462]);
t12=(C_truep(t11)?(C_truep((C_word)C_blockp(t10))?(C_word)C_pairp(t10):C_SCHEME_FALSE):C_SCHEME_FALSE);
if(C_truep(t12)){
t13=(C_word)C_slot(t10,C_fix(0));
t14=(C_word)C_eqp(t3,C_fix(0));
if(C_truep(t14)){
t15=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10333,a[2]=t13,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2018 walk */
t16=((C_word*)((C_word*)t0)[3])[1];
f_10182(t16,t15,t5,t3);}
else{
t15=(C_word)C_a_i_list(&a,2,lf[90],lf[462]);
t16=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10352,a[2]=t3,a[3]=t5,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t15,tmp=(C_word)a,a+=7,tmp);
t17=(C_word)C_u_fixnum_difference(t3,C_fix(1));
/* eval.scm: 2020 walk */
t18=((C_word*)((C_word*)t0)[3])[1];
f_10182(t18,t16,t13,t17);}}
else{
t13=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10363,a[2]=t3,a[3]=t5,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 2022 walk */
t14=((C_word*)((C_word*)t0)[3])[1];
f_10182(t14,t13,t4,t3);}}
else{
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10380,a[2]=t3,a[3]=t5,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 2023 walk */
t10=((C_word*)((C_word*)t0)[3])[1];
f_10182(t10,t9,t4,t3);}}}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,2,lf[90],t2));}}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,2,lf[90],t2));}}

/* k10378 in walk1 in a10178 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_10380(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10380,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10384,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2023 walk */
t3=((C_word*)((C_word*)t0)[4])[1];
f_10182(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k10382 in k10378 in walk1 in a10178 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_10384(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10384,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[461],((C_word*)t0)[2],t1));}

/* k10361 in walk1 in a10178 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_10363(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10363,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10367,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2022 walk */
t3=((C_word*)((C_word*)t0)[4])[1];
f_10182(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k10365 in k10361 in walk1 in a10178 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_10367(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10367,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[461],((C_word*)t0)[2],t1));}

/* k10350 in walk1 in a10178 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_10352(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10352,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,lf[457],((C_word*)t0)[6],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10344,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2021 walk */
t4=((C_word*)((C_word*)t0)[4])[1];
f_10182(t4,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k10342 in k10350 in walk1 in a10178 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_10344(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10344,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[461],((C_word*)t0)[2],t1));}

/* k10331 in walk1 in a10178 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_10333(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10333,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[88],((C_word*)t0)[2],t1));}

/* k10297 in walk1 in a10178 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_10299(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10299,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[461],((C_word*)t0)[2],t1));}

/* k10278 in walk1 in a10178 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_10280(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10280,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[457],((C_word*)t0)[2],t1));}

/* k10251 in walk1 in a10178 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_10253(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10253,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[457],lf[458],t1));}

/* k10208 in walk1 in a10178 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_10210(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1989 walk */
t2=((C_word*)((C_word*)t0)[4])[1];
f_10182(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k10204 in walk1 in a10178 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_10206(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10206,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,lf[455],t1));}

/* walk in a10178 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_fcall f_10182(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10182,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10190,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1984 walk1 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_10192(t5,t4,t2,t3);}

/* k10188 in walk in a10178 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_10190(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1984 simplify */
t2=((C_word*)((C_word*)t0)[3])[1];
f_10389(t2,((C_word*)t0)[2],t1);}

/* k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_8961(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8961,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8964,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10169,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 2042 ##sys#register-macro */
t4=*((C_word*)lf[40]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,lf[454],t3);}

/* a10168 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_10169(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10169,3,t0,t1,t2);}
t3=(C_word)C_a_i_list(&a,3,lf[92],C_SCHEME_END_OF_LIST,t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,2,lf[453],t3));}

/* k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_8964(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8964,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8967,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9923,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 2046 ##sys#register-macro-2 */
t4=*((C_word*)lf[38]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,lf[445],t3);}

/* a9922 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_9923(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9923,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9926,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9936,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10078,a[2]=t3,a[3]=t5,a[4]=t8,a[5]=t2,tmp=(C_word)a,a+=6,tmp));
t10=((C_word*)t8)[1];
f_10078(t10,t1,t2);}

/* expand in a9922 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_fcall f_10078(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10078,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10092,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10094,tmp=(C_word)a,a+=2,tmp);
/* map */
t6=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,((C_word*)t0)[5]);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_slot(t2,C_fix(1));
if(C_truep((C_word)C_i_pairp(t4))){
t6=(C_word)C_slot(t4,C_fix(0));
t7=(C_word)C_eqp(t6,lf[451]);
if(C_truep(t7)){
t8=(C_word)C_slot(t4,C_fix(1));
t9=(C_word)C_eqp(t8,C_SCHEME_END_OF_LIST);
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_truep(t9)?lf[452]:(C_word)C_a_i_cons(&a,2,lf[106],t8)));}
else{
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10149,a[2]=t5,a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 2091 test */
t9=((C_word*)((C_word*)t0)[3])[1];
f_9936(t9,t8,t6);}}
else{
/* eval.scm: 2084 err */
t6=((C_word*)t0)[2];
f_9926(t6,t1,t4);}}
else{
/* eval.scm: 2079 err */
t4=((C_word*)t0)[2];
f_9926(t4,t1,t2);}}}

/* k10147 in expand in a9922 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_10149(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10149,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[106],t2));}
else{
/* eval.scm: 2092 expand */
t2=((C_word*)((C_word*)t0)[3])[1];
f_10078(t2,((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* a10093 in expand in a9922 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_10094(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10094,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_u_i_car(t2));}

/* k10090 in expand in a9922 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_10092(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(5,0,((C_word*)t0)[2],*((C_word*)lf[144]+1),lf[450],t1);}

/* test in a9922 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_fcall f_9936(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word *a;
loop:
a=C_alloc(13);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_9936,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_symbolp(t2))){
/* eval.scm: 2054 ##sys#feature? */
t3=*((C_word*)lf[313]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(1));
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_eqp(t4,lf[447]);
if(C_truep(t5)){
t6=(C_word)C_eqp(t3,C_SCHEME_END_OF_LIST);
if(C_truep(t6)){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
if(C_truep((C_word)C_i_pairp(t3))){
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9985,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t8=(C_word)C_slot(t3,C_fix(0));
/* eval.scm: 2062 test */
t17=t7;
t18=t8;
t1=t17;
t2=t18;
goto loop;}
else{
/* eval.scm: 2064 err */
t7=((C_word*)t0)[2];
f_9926(t7,t1,t2);}}}
else{
t6=(C_word)C_eqp(t4,lf[448]);
if(C_truep(t6)){
t7=(C_word)C_eqp(t3,C_SCHEME_END_OF_LIST);
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_i_pairp(t3))){
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10024,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t9=(C_word)C_slot(t3,C_fix(0));
/* eval.scm: 2068 test */
t17=t8;
t18=t9;
t1=t17;
t2=t18;
goto loop;}
else{
/* eval.scm: 2070 err */
t8=((C_word*)t0)[2];
f_9926(t8,t1,t2);}}}
else{
t7=(C_word)C_eqp(t4,lf[449]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10062,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t9=(C_word)C_u_i_cadr(t2);
/* eval.scm: 2071 test */
t17=t8;
t18=t9;
t1=t17;
t2=t18;
goto loop;}
else{
/* eval.scm: 2072 err */
t8=((C_word*)t0)[2];
f_9926(t8,t1,t2);}}}}
else{
/* eval.scm: 2055 err */
t3=((C_word*)t0)[2];
f_9926(t3,t1,t2);}}}

/* k10060 in test in a9922 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_10062(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_not(t1));}

/* k10022 in test in a9922 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_10024(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10024,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
t3=(C_word)C_a_i_cons(&a,2,lf[448],t2);
/* eval.scm: 2069 test */
t4=((C_word*)((C_word*)t0)[2])[1];
f_9936(t4,((C_word*)t0)[4],t3);}}

/* k9983 in test in a9922 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_9985(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9985,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=(C_word)C_a_i_cons(&a,2,lf[447],t2);
/* eval.scm: 2063 test */
t4=((C_word*)((C_word*)t0)[3])[1];
f_9936(t4,((C_word*)t0)[2],t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* err in a9922 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_fcall f_9926(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9926,NULL,3,t0,t1,t2);}
t3=(C_word)C_a_i_cons(&a,2,lf[445],((C_word*)t0)[2]);
/* eval.scm: 2051 ##sys#error */
t4=*((C_word*)lf[144]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t1,lf[446],t2,t3);}

/* k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_8967(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8967,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8971,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 2098 append */
t3=*((C_word*)lf[68]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[444],*((C_word*)lf[185]+1));}

/* k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_8971(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8971,2,t0,t1);}
t2=C_mutate((C_word*)lf[185]+1,t1);
t3=C_set_block_item(lf[375],0,C_SCHEME_FALSE);
t4=C_set_block_item(lf[376],0,C_SCHEME_FALSE);
t5=C_set_block_item(lf[377],0,C_SCHEME_FALSE);
t6=C_mutate((C_word*)lf[378]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8976,tmp=(C_word)a,a+=2,tmp));
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8993,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9920,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 2112 make-parameter */
t9=*((C_word*)lf[443]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t7,t8);}

/* a9919 in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_9920(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9920,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[442]);}

/* k8991 in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_8993(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8993,2,t0,t1);}
t2=C_mutate((C_word*)lf[382]+1,t1);
t3=*((C_word*)lf[382]+1);
t4=C_mutate((C_word*)lf[383]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8995,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[386]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9011,tmp=(C_word)a,a+=2,tmp));
t6=*((C_word*)lf[209]+1);
t7=*((C_word*)lf[225]+1);
t8=*((C_word*)lf[55]+1);
t9=*((C_word*)lf[387]+1);
t10=*((C_word*)lf[388]+1);
t11=*((C_word*)lf[212]+1);
t12=*((C_word*)lf[389]+1);
t13=C_mutate((C_word*)lf[390]+1,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9014,a[2]=t8,a[3]=t7,a[4]=t6,a[5]=t11,a[6]=t9,a[7]=t10,tmp=(C_word)a,a+=8,tmp));
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9353,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 2228 make-vector */
t15=*((C_word*)lf[329]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t14,C_fix(301),C_SCHEME_END_OF_LIST);}

/* k9351 in k8991 in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_9353(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9353,2,t0,t1);}
t2=C_mutate((C_word*)lf[405]+1,t1);
t3=C_mutate((C_word*)lf[406]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9355,tmp=(C_word)a,a+=2,tmp));
t4=*((C_word*)lf[407]+1);
t5=*((C_word*)lf[408]+1);
t6=*((C_word*)lf[225]+1);
t7=C_mutate((C_word*)lf[407]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9364,a[2]=t4,a[3]=t5,a[4]=t6,tmp=(C_word)a,a+=5,tmp));
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9439,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9778,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 2257 ##sys#register-macro */
t10=*((C_word*)lf[40]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t8,lf[438],t9);}

/* a9777 in k9351 in k8991 in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_9778(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+14)){
C_save_and_reclaim((void*)tr3r,(void*)f_9778r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_9778r(t0,t1,t2,t3);}}

static void C_ccall f_9778r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(14);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9781,tmp=(C_word)a,a+=2,tmp);
if(C_truep((C_word)C_i_symbolp(t2))){
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9886,a[2]=t2,a[3]=t1,a[4]=t4,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 2268 ##sys#check-syntax */
t6=*((C_word*)lf[64]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[438],t3,lf[439]);}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9896,a[2]=t1,a[3]=t4,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 2271 ##sys#check-syntax */
t6=*((C_word*)lf[64]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[438],t2,lf[441]);}}

/* k9894 in a9777 in k9351 in k8991 in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_9896(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9896,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9899,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 2272 ##sys#check-syntax */
t3=*((C_word*)lf[64]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[438],((C_word*)t0)[4],lf[440]);}

/* k9897 in k9894 in a9777 in k9351 in k8991 in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_9899(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9899,2,t0,t1);}
t2=(C_word)C_u_i_car(((C_word*)t0)[5]);
t3=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[4]);
t5=(C_word)C_a_i_cons(&a,2,lf[92],t4);
/* eval.scm: 2273 expand */
f_9781(((C_word*)t0)[2],t2,t5);}

/* k9884 in a9777 in k9351 in k8991 in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_9886(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_i_car(((C_word*)t0)[5]);
/* eval.scm: 2269 expand */
f_9781(((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* expand in a9777 in k9351 in k8991 in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_fcall f_9781(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9781,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9785,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(t3))){
t5=(C_word)C_u_i_car(t3);
t6=(C_word)C_eqp(lf[92],t5);
if(C_truep(t6)){
t7=(C_word)C_slot(t3,C_fix(1));
if(C_truep((C_word)C_i_pairp(t7))){
t8=(C_word)C_u_i_cadr(t3);
t9=t4;
f_9785(t9,(C_word)C_i_symbolp(t8));}
else{
t8=t4;
f_9785(t8,C_SCHEME_FALSE);}}
else{
t7=t4;
f_9785(t7,C_SCHEME_FALSE);}}
else{
t5=t4;
f_9785(t5,C_SCHEME_FALSE);}}

/* k9783 in expand in a9777 in k9351 in k8991 in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_fcall f_9785(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[64],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9785,NULL,2,t0,t1);}
t2=(C_truep(*((C_word*)lf[75]+1))?lf[176]:lf[175]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9796,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t4=(C_word)C_a_i_list(&a,2,lf[90],((C_word*)t0)[3]);
t5=(C_word)C_u_i_cadr(((C_word*)t0)[2]);
t6=(C_word)C_a_i_list(&a,1,t5);
t7=(C_word)C_u_i_cddr(((C_word*)t0)[2]);
t8=(C_word)C_a_i_cons(&a,2,t6,t7);
t9=(C_word)C_a_i_cons(&a,2,lf[92],t8);
t10=t3;
f_9796(t10,(C_word)C_a_i_list(&a,3,lf[38],t4,t9));}
else{
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[2]))){
t4=(C_word)C_a_i_list(&a,2,lf[90],((C_word*)t0)[2]);
t5=(C_word)C_a_i_list(&a,2,lf[90],((C_word*)t0)[3]);
t6=t3;
f_9796(t6,(C_word)C_a_i_list(&a,3,lf[41],t4,t5));}
else{
t4=(C_word)C_a_i_list(&a,2,lf[90],((C_word*)t0)[3]);
t5=t3;
f_9796(t5,(C_word)C_a_i_list(&a,3,lf[40],t4,((C_word*)t0)[2]));}}}

/* k9794 in k9783 in expand in a9777 in k9351 in k8991 in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_fcall f_9796(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9796,NULL,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[2],t1));}

/* k9437 in k9351 in k8991 in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_9439(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9439,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9442,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9759,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 2275 ##sys#register-macro */
t4=*((C_word*)lf[40]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,lf[312],t3);}

/* a9758 in k9437 in k9351 in k8991 in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_9759(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_9759r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_9759r(t0,t1,t2);}}

static void C_ccall f_9759r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9763,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2278 ##sys#check-syntax */
t4=*((C_word*)lf[64]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,lf[312],t2,lf[437]);}

/* k9761 in a9758 in k9437 in k9351 in k8991 in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_9763(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9763,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9770,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9772,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a9771 in k9761 in a9758 in k9437 in k9351 in k8991 in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_9772(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9772,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[90],t2));}

/* k9768 in k9761 in a9758 in k9437 in k9351 in k8991 in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_9770(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9770,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[172],t1));}

/* k9440 in k9437 in k9351 in k8991 in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_9442(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9442,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9445,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9753,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 2284 ##sys#register-macro-2 */
t4=*((C_word*)lf[38]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,lf[435],t3);}

/* a9752 in k9440 in k9437 in k9351 in k8991 in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_9753(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9753,3,t0,t1,t2);}
/* eval.scm: 2287 ##sys#syntax-error-hook */
t3=*((C_word*)lf[56]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,lf[435],lf[436]);}

/* k9443 in k9440 in k9437 in k9351 in k8991 in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_9445(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9445,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9448,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9747,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 2289 ##sys#register-macro-2 */
t4=*((C_word*)lf[38]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,lf[433],t3);}

/* a9746 in k9443 in k9440 in k9437 in k9351 in k8991 in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_9747(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9747,3,t0,t1,t2);}
/* eval.scm: 2292 ##sys#syntax-error-hook */
t3=*((C_word*)lf[56]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,lf[433],lf[434]);}

/* k9446 in k9443 in k9440 in k9437 in k9351 in k8991 in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_9448(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[28],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9448,2,t0,t1);}
t2=lf[412]=C_SCHEME_FALSE;;
t3=C_mutate(&lf[413],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9451,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate(&lf[415],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9510,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate(&lf[417],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9519,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate(&lf[419],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9531,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate(&lf[420],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9547,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate(&lf[422],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9573,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate(&lf[424],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9586,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate(&lf[425],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9612,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate(&lf[426],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9649,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate(&lf[427],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9665,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate(&lf[428],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9691,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate(&lf[429],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9713,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate(&lf[430],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9728,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate((C_word*)lf[131]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9738,tmp=(C_word)a,a+=2,tmp));
t17=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t17+1)))(2,t17,C_SCHEME_UNDEFINED);}

/* ##sys#make-lambda-info in k9446 in k9443 in k9440 in k9437 in k9351 in k8991 in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_9738(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9738,3,t0,t1,t2);}
t3=(C_word)C_block_size(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9745,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 2399 ##sys#make-string */
t5=*((C_word*)lf[432]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t3);}

/* k9743 in ##sys#make-lambda-info in k9446 in k9443 in k9440 in k9437 in k9351 in k8991 in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_9745(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_copy_memory(t1,((C_word*)t0)[4],((C_word*)t0)[3]);
t3=(C_word)C_string_to_lambdainfo(t1);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t1);}

/* CHICKEN_get_error_message in k9446 in k9443 in k9440 in k9437 in k9351 in k8991 in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_9728(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9728,4,t0,t1,t2,t3);}
t4=lf[412];
t5=(C_truep(t4)?t4:lf[431]);
/* eval.scm: 2392 store-string */
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,f_9573(t5,t3,t2));}

/* CHICKEN_load in k9446 in k9443 in k9440 in k9437 in k9351 in k8991 in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_9713(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9713,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9717,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[35]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,C_fix(0));}

/* k9715 in CHICKEN_load in k9446 in k9443 in k9440 in k9437 in k9351 in k8991 in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_9717(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9717,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9722,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 2389 run-safe */
f_9451(((C_word*)t0)[2],t2);}

/* a9721 in k9715 in CHICKEN_load in k9446 in k9443 in k9440 in k9437 in k9351 in k8991 in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_9722(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9722,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9726,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 2389 load */
t3=*((C_word*)lf[235]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k9724 in a9721 in k9715 in CHICKEN_load in k9446 in k9443 in k9440 in k9437 in k9351 in k8991 in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_9726(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* CHICKEN_read in k9446 in k9443 in k9440 in k9437 in k9351 in k8991 in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_9691(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9691,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9695,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* ##sys#peek-c-string */
t5=*((C_word*)lf[35]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,C_fix(0));}

/* k9693 in CHICKEN_read in k9446 in k9443 in k9440 in k9437 in k9351 in k8991 in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_9695(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9695,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9700,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2383 run-safe */
f_9451(((C_word*)t0)[2],t3);}

/* a9699 in k9693 in CHICKEN_read in k9446 in k9443 in k9440 in k9437 in k9351 in k8991 in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_9700(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9700,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9704,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2385 open-input-string */
t3=*((C_word*)lf[421]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k9702 in a9699 in k9693 in CHICKEN_read in k9446 in k9443 in k9440 in k9437 in k9351 in k8991 in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_9704(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9704,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9711,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2386 read */
t3=*((C_word*)lf[225]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}

/* k9709 in k9702 in a9699 in k9693 in CHICKEN_read in k9446 in k9443 in k9440 in k9437 in k9351 in k8991 in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_9711(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2386 store-result */
f_9510(((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* CHICKEN_apply_to_string in k9446 in k9443 in k9440 in k9437 in k9351 in k8991 in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_9665(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_9665,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9671,a[2]=t3,a[3]=t2,a[4]=t4,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 2376 run-safe */
f_9451(t1,t6);}

/* a9670 in CHICKEN_apply_to_string in k9446 in k9443 in k9440 in k9437 in k9351 in k8991 in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_9671(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9671,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9675,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 2378 open-output-string */
t3=*((C_word*)lf[134]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k9673 in a9670 in CHICKEN_apply_to_string in k9446 in k9443 in k9440 in k9437 in k9351 in k8991 in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_9675(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9675,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9678,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9689,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_apply(4,0,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9687 in k9673 in a9670 in CHICKEN_apply_to_string in k9446 in k9443 in k9440 in k9437 in k9351 in k8991 in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_9689(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2379 write */
t2=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k9676 in k9673 in a9670 in CHICKEN_apply_to_string in k9446 in k9443 in k9440 in k9437 in k9351 in k8991 in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_9678(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9678,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9685,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 2380 get-output-string */
t3=*((C_word*)lf[132]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k9683 in k9676 in k9673 in a9670 in CHICKEN_apply_to_string in k9446 in k9443 in k9440 in k9437 in k9351 in k8991 in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_9685(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2380 store-string */
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,f_9573(t1,((C_word*)t0)[3],((C_word*)t0)[2]));}

/* CHICKEN_apply in k9446 in k9443 in k9440 in k9437 in k9351 in k8991 in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_9649(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9649,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9655,a[2]=t3,a[3]=t2,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 2371 run-safe */
f_9451(t1,t5);}

/* a9654 in CHICKEN_apply in k9446 in k9443 in k9440 in k9437 in k9351 in k8991 in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_9655(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9655,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9663,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_apply(4,0,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9661 in a9654 in CHICKEN_apply in k9446 in k9443 in k9440 in k9437 in k9351 in k8991 in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_9663(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2371 store-result */
f_9510(((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* CHICKEN_eval_string_to_string in k9446 in k9443 in k9440 in k9437 in k9351 in k8991 in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_9612(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9612,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9616,a[2]=t1,a[3]=t4,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* ##sys#peek-c-string */
t6=*((C_word*)lf[35]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t2,C_fix(0));}

/* k9614 in CHICKEN_eval_string_to_string in k9446 in k9443 in k9440 in k9437 in k9351 in k8991 in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_9616(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9616,2,t0,t1);}
t2=((C_word*)t0)[4];
t3=((C_word*)t0)[3];
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9621,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 2362 run-safe */
f_9451(((C_word*)t0)[2],t4);}

/* a9620 in k9614 in CHICKEN_eval_string_to_string in k9446 in k9443 in k9440 in k9437 in k9351 in k8991 in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_9621(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9621,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9625,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 2364 open-output-string */
t3=*((C_word*)lf[134]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k9623 in a9620 in k9614 in CHICKEN_eval_string_to_string in k9446 in k9443 in k9440 in k9437 in k9351 in k8991 in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_9625(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9625,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9628,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9639,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9643,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9647,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 2365 open-input-string */
t6=*((C_word*)lf[421]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[2]);}

/* k9645 in k9623 in a9620 in k9614 in CHICKEN_eval_string_to_string in k9446 in k9443 in k9440 in k9437 in k9351 in k8991 in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_9647(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2365 read */
t2=*((C_word*)lf[225]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k9641 in k9623 in a9620 in k9614 in CHICKEN_eval_string_to_string in k9446 in k9443 in k9440 in k9437 in k9351 in k8991 in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_9643(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2365 eval */
t2=*((C_word*)lf[209]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k9637 in k9623 in a9620 in k9614 in CHICKEN_eval_string_to_string in k9446 in k9443 in k9440 in k9437 in k9351 in k8991 in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_9639(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2365 write */
t2=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k9626 in k9623 in a9620 in k9614 in CHICKEN_eval_string_to_string in k9446 in k9443 in k9440 in k9437 in k9351 in k8991 in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_9628(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9628,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9635,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 2366 get-output-string */
t3=*((C_word*)lf[132]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k9633 in k9626 in k9623 in a9620 in k9614 in CHICKEN_eval_string_to_string in k9446 in k9443 in k9440 in k9437 in k9351 in k8991 in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_9635(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2366 store-string */
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,f_9573(t1,((C_word*)t0)[3],((C_word*)t0)[2]));}

/* CHICKEN_eval_to_string in k9446 in k9443 in k9440 in k9437 in k9351 in k8991 in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_9586(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9586,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9592,a[2]=t2,a[3]=t3,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 2353 run-safe */
f_9451(t1,t5);}

/* a9591 in CHICKEN_eval_to_string in k9446 in k9443 in k9440 in k9437 in k9351 in k8991 in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_9592(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9592,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9596,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 2355 open-output-string */
t3=*((C_word*)lf[134]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k9594 in a9591 in CHICKEN_eval_to_string in k9446 in k9443 in k9440 in k9437 in k9351 in k8991 in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_9596(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9596,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9599,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9610,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2356 eval */
t4=*((C_word*)lf[209]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k9608 in k9594 in a9591 in CHICKEN_eval_to_string in k9446 in k9443 in k9440 in k9437 in k9351 in k8991 in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_9610(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2356 write */
t2=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k9597 in k9594 in a9591 in CHICKEN_eval_to_string in k9446 in k9443 in k9440 in k9437 in k9351 in k8991 in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_9599(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9599,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9606,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 2357 get-output-string */
t3=*((C_word*)lf[132]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k9604 in k9597 in k9594 in a9591 in CHICKEN_eval_to_string in k9446 in k9443 in k9440 in k9437 in k9351 in k8991 in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_9606(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2357 store-string */
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,f_9573(t1,((C_word*)t0)[3],((C_word*)t0)[2]));}

/* store-string in k9446 in k9443 in k9440 in k9437 in k9351 in k8991 in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static C_word C_fcall f_9573(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
t4=(C_word)C_block_size(t1);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t4,t2))){
t5=C_mutate(&lf[412],lf[423]);
return(C_SCHEME_FALSE);}
else{
return((C_word)C_copy_result_string(t1,t3,t4));}}

/* CHICKEN_eval_string in k9446 in k9443 in k9440 in k9437 in k9351 in k8991 in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_9547(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9547,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9551,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* ##sys#peek-c-string */
t5=*((C_word*)lf[35]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,C_fix(0));}

/* k9549 in CHICKEN_eval_string in k9446 in k9443 in k9440 in k9437 in k9351 in k8991 in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_9551(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9551,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9556,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2334 run-safe */
f_9451(((C_word*)t0)[2],t3);}

/* a9555 in k9549 in CHICKEN_eval_string in k9446 in k9443 in k9440 in k9437 in k9351 in k8991 in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_9556(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9556,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9560,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2336 open-input-string */
t3=*((C_word*)lf[421]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k9558 in a9555 in k9549 in CHICKEN_eval_string in k9446 in k9443 in k9440 in k9437 in k9351 in k8991 in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_9560(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9560,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9567,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9571,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 2337 read */
t4=*((C_word*)lf[225]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t1);}

/* k9569 in k9558 in a9555 in k9549 in CHICKEN_eval_string in k9446 in k9443 in k9440 in k9437 in k9351 in k8991 in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_9571(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2337 eval */
t2=*((C_word*)lf[209]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k9565 in k9558 in a9555 in k9549 in CHICKEN_eval_string in k9446 in k9443 in k9440 in k9437 in k9351 in k8991 in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_9567(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2337 store-result */
f_9510(((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* CHICKEN_eval in k9446 in k9443 in k9440 in k9437 in k9351 in k8991 in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_9531(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9531,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9537,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2329 run-safe */
f_9451(t1,t4);}

/* a9536 in CHICKEN_eval in k9446 in k9443 in k9440 in k9437 in k9351 in k8991 in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_9537(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9537,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9545,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2331 eval */
t3=*((C_word*)lf[209]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k9543 in a9536 in CHICKEN_eval in k9446 in k9443 in k9440 in k9437 in k9351 in k8991 in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_9545(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2331 store-result */
f_9510(((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* CHICKEN_yield in k9446 in k9443 in k9440 in k9437 in k9351 in k8991 in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_9519(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9519,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9525,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 2326 run-safe */
f_9451(t1,t2);}

/* a9524 in CHICKEN_yield in k9446 in k9443 in k9440 in k9437 in k9351 in k8991 in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_9525(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9525,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9529,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 2326 thread-yield! */
t3=*((C_word*)lf[418]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k9527 in a9524 in CHICKEN_yield in k9446 in k9443 in k9440 in k9437 in k9351 in k8991 in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_9529(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* store-result in k9446 in k9443 in k9440 in k9437 in k9351 in k8991 in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_fcall f_9510(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9510,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9514,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 2320 ##sys#gc */
t5=*((C_word*)lf[416]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,C_SCHEME_FALSE);}

/* k9512 in store-result in k9446 in k9443 in k9440 in k9437 in k9351 in k8991 in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_9514(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(((C_word*)t0)[4])?(C_word)C_store_result(((C_word*)t0)[3],((C_word*)t0)[4]):C_SCHEME_UNDEFINED);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_TRUE);}

/* run-safe in k9446 in k9443 in k9440 in k9437 in k9351 in k8991 in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_fcall f_9451(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9451,NULL,2,t1,t2);}
t3=lf[412]=C_SCHEME_FALSE;;
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9459,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9461,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 2308 call-with-current-continuation */
t6=*((C_word*)lf[55]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}

/* a9460 in run-safe in k9446 in k9443 in k9440 in k9437 in k9351 in k8991 in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_9461(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9461,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9467,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9486,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2308 with-exception-handler */
t5=*((C_word*)lf[54]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t3,t4);}

/* a9485 in a9460 in run-safe in k9446 in k9443 in k9440 in k9437 in k9351 in k8991 in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_9486(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9486,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9492,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9498,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 2308 ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t2,t3);}

/* a9497 in a9485 in a9460 in run-safe in k9446 in k9443 in k9440 in k9437 in k9351 in k8991 in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_9498(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_9498r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_9498r(t0,t1,t2);}}

static void C_ccall f_9498r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9504,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 2308 g1480 */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}

/* a9503 in a9497 in a9485 in a9460 in run-safe in k9446 in k9443 in k9440 in k9437 in k9351 in k8991 in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_9504(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9504,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a9491 in a9485 in a9460 in run-safe in k9446 in k9443 in k9440 in k9437 in k9351 in k8991 in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_9492(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9492,2,t0,t1);}
/* eval.scm: 2313 thunk */
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}

/* a9466 in a9460 in run-safe in k9446 in k9443 in k9440 in k9437 in k9351 in k8991 in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_9467(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9467,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9473,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 2308 g1480 */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}

/* a9472 in a9466 in a9460 in run-safe in k9446 in k9443 in k9440 in k9437 in k9351 in k8991 in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_9473(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9473,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9477,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2309 open-output-string */
t3=*((C_word*)lf[134]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k9475 in a9472 in a9466 in a9460 in run-safe in k9446 in k9443 in k9440 in k9437 in k9351 in k8991 in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_9477(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9477,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9480,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2310 print-error-message */
t3=*((C_word*)lf[414]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],t1);}

/* k9478 in k9475 in a9472 in a9466 in a9460 in run-safe in k9446 in k9443 in k9440 in k9437 in k9351 in k8991 in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_9480(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9480,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9484,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 2311 get-output-string */
t3=*((C_word*)lf[132]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k9482 in k9478 in k9475 in a9472 in a9466 in a9460 in run-safe in k9446 in k9443 in k9440 in k9437 in k9351 in k8991 in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_9484(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[412],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}

/* k9457 in run-safe in k9446 in k9443 in k9440 in k9437 in k9351 in k8991 in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_9459(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* ##sys#user-read-hook in k9351 in k8991 in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_9364(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9364,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t2,C_make_character(44));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9374,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 2240 read-char */
t6=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t3);}
else{
/* eval.scm: 2252 old */
t5=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t2,t3);}}

/* k9372 in ##sys#user-read-hook in k9351 in k8991 in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_9374(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9374,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9377,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2241 read */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[4]);}

/* k9375 in k9372 in ##sys#user-read-hook in k9351 in k8991 in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_9377(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9377,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9378,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_nullp(t1);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9391,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t3)){
t5=t4;
f_9391(t5,t3);}
else{
t5=(C_word)C_i_listp(t1);
t6=t4;
f_9391(t6,(C_word)C_i_not(t5));}}

/* k9389 in k9375 in k9372 in ##sys#user-read-hook in k9351 in k8991 in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_fcall f_9391(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9391,NULL,2,t0,t1);}
if(C_truep(t1)){
/* eval.scm: 2244 err */
t2=((C_word*)t0)[5];
f_9378(t2,((C_word*)t0)[4]);}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(0));
if(C_truep((C_word)C_i_symbolp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9409,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 2248 ##sys#hash-table-ref */
t4=*((C_word*)lf[42]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,*((C_word*)lf[405]+1),t2);}
else{
/* eval.scm: 2247 err */
t3=((C_word*)t0)[5];
f_9378(t3,((C_word*)t0)[4]);}}}

/* k9407 in k9389 in k9375 in k9372 in ##sys#user-read-hook in k9351 in k8991 in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_9409(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
C_apply(4,0,((C_word*)t0)[4],t1,t2);}
else{
/* eval.scm: 2251 ##sys#read-error */
t2=*((C_word*)lf[409]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],lf[411],((C_word*)t0)[2]);}}

/* err in k9375 in k9372 in ##sys#user-read-hook in k9351 in k8991 in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_fcall f_9378(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9378,NULL,2,t0,t1);}
/* eval.scm: 2242 ##sys#read-error */
t2=*((C_word*)lf[409]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[3],lf[410],((C_word*)t0)[2]);}

/* define-reader-ctor in k9351 in k8991 in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_9355(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9355,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_symbol_2(t2,lf[406]);
/* eval.scm: 2232 ##sys#hash-table-set! */
t5=*((C_word*)lf[39]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,*((C_word*)lf[405]+1),t2,t3);}

/* repl in k8991 in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_9014(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[21],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9014,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9017,tmp=(C_word)a,a+=2,tmp);
t3=*((C_word*)lf[392]+1);
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=*((C_word*)lf[385]+1);
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=*((C_word*)lf[391]+1);
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_9058,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t2,a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=t8,a[11]=t6,a[12]=t4,tmp=(C_word)a,a+=13,tmp);
/* eval.scm: 2142 ##sys#error-handler */
t10=*((C_word*)lf[396]+1);
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,t9);}

/* k9056 in repl in k8991 in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_9058(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9058,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_9061,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
/* eval.scm: 2143 ##sys#reset-handler */
t3=*((C_word*)lf[404]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k9059 in k9056 in repl in k8991 in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_9061(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[34],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9061,2,t0,t1);}
t2=C_SCHEME_FALSE;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=*((C_word*)lf[136]+1);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9063,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[13],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9069,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[13],tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9078,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=t6,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9143,a[2]=((C_word*)t0)[4],a[3]=t6,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t5,tmp=(C_word)a,a+=7,tmp);
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9338,a[2]=t3,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 2157 ##sys#dynamic-wind */
t10=*((C_word*)lf[238]+1);
((C_proc5)(void*)(*((C_word*)t10+1)))(5,t10,((C_word*)t0)[2],t7,t8,t9);}

/* a9337 in k9059 in k9056 in repl in k8991 in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_9338(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9338,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9342,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 2220 load-verbose */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* k9340 in a9337 in k9059 in k9056 in repl in k8991 in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_9342(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9342,2,t0,t1);}
t2=C_mutate((C_word*)lf[136]+1,((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9346,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2222 ##sys#error-handler */
t4=*((C_word*)lf[396]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k9344 in k9340 in a9337 in k9059 in k9056 in repl in k8991 in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_9346(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2223 ##sys#reset-handler */
t2=*((C_word*)lf[404]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a9142 in k9059 in k9056 in repl in k8991 in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_9143(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9143,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9149,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp));
t5=((C_word*)t3)[1];
f_9149(t5,t1);}

/* loop in a9142 in k9059 in k9056 in repl in k8991 in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_fcall f_9149(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9149,NULL,2,t0,t1);}
t2=f_9063(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9156,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9321,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 2180 call-with-current-continuation */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a9320 in loop in a9142 in k9059 in k9056 in repl in k8991 in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_9321(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9321,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9327,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2182 ##sys#reset-handler */
t4=*((C_word*)lf[404]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}

/* a9326 in a9320 in loop in a9142 in k9059 in k9056 in repl in k8991 in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_9327(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9327,2,t0,t1);}
t2=C_set_block_item(lf[230],0,C_SCHEME_FALSE);
t3=C_set_block_item(lf[403],0,C_SCHEME_TRUE);
t4=f_9069(((C_word*)t0)[3]);
/* eval.scm: 2187 c */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t1,C_SCHEME_FALSE);}

/* k9154 in loop in a9142 in k9059 in k9056 in repl in k8991 in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_9156(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9156,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9159,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 2188 ##sys#read-prompt-hook */
t3=*((C_word*)lf[383]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k9157 in k9154 in loop in a9142 in k9059 in k9056 in repl in k8991 in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_9159(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9159,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9162,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=*((C_word*)lf[377]+1);
t4=(C_truep(t3)?t3:((C_word*)t0)[2]);
t5=t4;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t2);}

/* k9160 in k9157 in k9154 in loop in a9142 in k9059 in k9056 in repl in k8991 in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_9162(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9162,2,t0,t1);}
if(C_truep((C_word)C_eofp(t1))){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9171,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9316,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 2191 ##sys#peek-char-0 */
t4=*((C_word*)lf[402]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,*((C_word*)lf[392]+1));}}

/* k9314 in k9160 in k9157 in k9154 in loop in a9142 in k9059 in k9056 in repl in k8991 in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_9316(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(C_make_character(10),t1);
if(C_truep(t2)){
/* eval.scm: 2192 ##sys#read-char-0 */
t3=*((C_word*)lf[401]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],*((C_word*)lf[392]+1));}
else{
t3=((C_word*)t0)[2];
f_9171(2,t3,C_SCHEME_UNDEFINED);}}

/* k9169 in k9160 in k9157 in k9154 in loop in a9142 in k9059 in k9056 in repl in k8991 in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_9171(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9171,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9174,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 2193 ##sys#clear-trace-buffer */
t3=*((C_word*)lf[386]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k9172 in k9169 in k9160 in k9157 in k9154 in loop in a9142 in k9059 in k9056 in repl in k8991 in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_9174(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9174,2,t0,t1);}
t2=C_set_block_item(lf[136],0,C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9180,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9189,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 2195 ##sys#call-with-values */
C_u_call_with_values(4,0,((C_word*)t0)[2],t3,t4);}

/* a9188 in k9172 in k9169 in k9160 in k9157 in k9154 in loop in a9142 in k9059 in k9056 in repl in k8991 in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_9189(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr2r,(void*)f_9189r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_9189r(t0,t1,t2);}}

static void C_ccall f_9189r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(10);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9193,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t4=(C_truep(*((C_word*)lf[397]+1))?(C_word)C_i_pairp(*((C_word*)lf[136]+1)):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9207,a[2]=t6,tmp=(C_word)a,a+=3,tmp));
t8=((C_word*)t6)[1];
f_9207(t8,t3,*((C_word*)lf[136]+1),C_SCHEME_END_OF_LIST);}
else{
t5=t3;
f_9193(2,t5,C_SCHEME_UNDEFINED);}}

/* loop in a9188 in k9172 in k9169 in k9160 in k9157 in k9154 in loop in a9142 in k9059 in k9056 in repl in k8991 in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_fcall f_9207(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9207,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9211,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
if(C_truep((C_word)C_i_pairp(t3))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9223,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2200 ##sys#print */
t6=*((C_word*)lf[380]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[400],C_SCHEME_FALSE,*((C_word*)lf[391]+1));}
else{
t5=t4;
f_9211(2,t5,C_SCHEME_UNDEFINED);}}
else{
t5=(C_word)C_u_i_caar(t2);
t6=(C_word)C_u_i_memq(t5,t3);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9270,a[2]=t3,a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t6)){
t8=t7;
f_9270(2,t8,t6);}
else{
t8=(C_word)C_u_i_caar(t2);
/* eval.scm: 2214 ##sys#symbol-has-toplevel-binding? */
t9=*((C_word*)lf[147]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t7,t8);}}}

/* k9268 in loop in a9188 in k9172 in k9169 in k9160 in k9157 in k9154 in loop in a9142 in k9059 in k9056 in repl in k8991 in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_9270(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9270,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* eval.scm: 2215 loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_9207(t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}
else{
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_u_i_car(((C_word*)t0)[5]);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[2]);
/* eval.scm: 2216 loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_9207(t5,((C_word*)t0)[3],t2,t4);}}

/* k9221 in loop in a9188 in k9172 in k9169 in k9160 in k9157 in k9154 in loop in a9142 in k9059 in k9056 in repl in k8991 in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_9223(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9223,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9228,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t3=*((C_word*)lf[123]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a9227 in k9221 in loop in a9188 in k9172 in k9169 in k9160 in k9157 in k9154 in loop in a9142 in k9059 in k9056 in repl in k8991 in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_9228(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9228,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9232,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2205 ##sys#print */
t4=*((C_word*)lf[380]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,lf[399],C_SCHEME_FALSE,*((C_word*)lf[391]+1));}

/* k9230 in a9227 in k9221 in loop in a9188 in k9172 in k9169 in k9160 in k9157 in k9154 in loop in a9142 in k9059 in k9056 in repl in k8991 in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_9232(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9232,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9235,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_u_i_car(((C_word*)t0)[2]);
/* eval.scm: 2206 ##sys#print */
t4=*((C_word*)lf[380]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,t3,C_SCHEME_TRUE,*((C_word*)lf[391]+1));}

/* k9233 in k9230 in a9227 in k9221 in loop in a9188 in k9172 in k9169 in k9160 in k9157 in k9154 in loop in a9142 in k9059 in k9056 in repl in k8991 in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_9235(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9235,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9238,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_slot(((C_word*)t0)[2],C_fix(1)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9247,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2208 ##sys#print */
t4=*((C_word*)lf[380]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,lf[398],C_SCHEME_FALSE,*((C_word*)lf[391]+1));}
else{
t3=t2;
f_9238(2,t3,C_SCHEME_UNDEFINED);}}

/* k9245 in k9233 in k9230 in a9227 in k9221 in loop in a9188 in k9172 in k9169 in k9160 in k9157 in k9154 in loop in a9142 in k9059 in k9056 in repl in k8991 in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_9247(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9247,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9250,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_slot(((C_word*)t0)[2],C_fix(1));
/* eval.scm: 2209 ##sys#print */
t4=*((C_word*)lf[380]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,t3,C_SCHEME_TRUE,*((C_word*)lf[391]+1));}

/* k9248 in k9245 in k9233 in k9230 in a9227 in k9221 in loop in a9188 in k9172 in k9169 in k9160 in k9157 in k9154 in loop in a9142 in k9059 in k9056 in repl in k8991 in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_9250(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2210 ##sys#write-char-0 */
t2=*((C_word*)lf[379]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_make_character(41),*((C_word*)lf[391]+1));}

/* k9236 in k9233 in k9230 in a9227 in k9221 in loop in a9188 in k9172 in k9169 in k9160 in k9157 in k9154 in loop in a9142 in k9059 in k9056 in repl in k8991 in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_9238(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2211 ##sys#write-char-0 */
t2=*((C_word*)lf[379]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_make_character(10),*((C_word*)lf[391]+1));}

/* k9209 in loop in a9188 in k9172 in k9169 in k9160 in k9157 in k9154 in loop in a9142 in k9059 in k9056 in repl in k8991 in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_9211(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(9));}

/* k9191 in a9188 in k9172 in k9169 in k9160 in k9157 in k9154 in loop in a9142 in k9059 in k9056 in repl in k8991 in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_9193(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9193,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9196,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[2];
t4=(C_word)C_i_nullp(t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9039,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t4)){
t6=t5;
f_9039(t6,t4);}
else{
t6=(C_word)C_u_i_car(t3);
t7=t5;
f_9039(t7,(C_word)C_eqp(C_SCHEME_UNDEFINED,t6));}}

/* k9037 in k9191 in a9188 in k9172 in k9169 in k9160 in k9157 in k9154 in loop in a9142 in k9059 in k9056 in repl in k8991 in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_fcall f_9039(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9039,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_9196(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9044,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t3=*((C_word*)lf[123]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}}

/* a9043 in k9037 in k9191 in a9188 in k9172 in k9169 in k9160 in k9157 in k9154 in loop in a9142 in k9059 in k9056 in repl in k8991 in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_9044(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9044,3,t0,t1,t2);}
/* ##sys#repl-print-hook */
t3=*((C_word*)lf[378]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,*((C_word*)lf[385]+1));}

/* k9194 in k9191 in a9188 in k9172 in k9169 in k9160 in k9157 in k9154 in loop in a9142 in k9059 in k9056 in repl in k8991 in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_9196(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2218 loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_9149(t2,((C_word*)t0)[2]);}

/* a9179 in k9172 in k9169 in k9160 in k9157 in k9154 in loop in a9142 in k9059 in k9056 in repl in k8991 in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_9180(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9180,2,t0,t1);}
t2=*((C_word*)lf[375]+1);
t3=(C_truep(t2)?t2:((C_word*)t0)[3]);
t4=t3;
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,((C_word*)t0)[2]);}

/* a9077 in k9059 in k9056 in repl in k8991 in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_9078(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9078,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9083,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* eval.scm: 2159 load-verbose */
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k9081 in a9077 in k9059 in k9056 in repl in k8991 in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_9083(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9083,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[8])+1,t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9086,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 2160 load-verbose */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,C_SCHEME_TRUE);}

/* k9084 in k9081 in a9077 in k9059 in k9056 in repl in k8991 in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_9086(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9086,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9091,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 2161 ##sys#error-handler */
t3=*((C_word*)lf[396]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t2);}

/* a9090 in k9084 in k9081 in a9077 in k9059 in k9056 in repl in k8991 in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_9091(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3r,(void*)f_9091r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_9091r(t0,t1,t2,t3);}}

static void C_ccall f_9091r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(8);
t4=f_9069(((C_word*)t0)[5]);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9098,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=t1,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
/* eval.scm: 2164 ##sys#print */
t6=*((C_word*)lf[380]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[395],C_SCHEME_FALSE,*((C_word*)lf[391]+1));}

/* k9096 in a9090 in k9084 in k9081 in a9077 in k9059 in k9056 in repl in k8991 in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_9098(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9098,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9101,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9138,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2166 ##sys#print */
t4=*((C_word*)lf[380]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,lf[394],C_SCHEME_FALSE,*((C_word*)lf[391]+1));}
else{
t3=t2;
f_9101(2,t3,C_SCHEME_UNDEFINED);}}

/* k9136 in k9096 in a9090 in k9084 in k9081 in a9077 in k9059 in k9056 in repl in k8991 in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_9138(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2167 ##sys#print */
t2=*((C_word*)lf[380]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE,*((C_word*)lf[391]+1));}

/* k9099 in k9096 in a9090 in k9084 in k9081 in a9077 in k9059 in k9056 in repl in k8991 in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_9101(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9101,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9104,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9113,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t4=(C_word)C_slot(((C_word*)t0)[2],C_fix(1));
t5=t3;
f_9113(t5,(C_word)C_i_nullp(t4));}
else{
t4=t3;
f_9113(t4,C_SCHEME_FALSE);}}

/* k9111 in k9099 in k9096 in a9090 in k9084 in k9081 in a9077 in k9059 in k9056 in repl in k8991 in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_fcall f_9113(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9113,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9116,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 2170 ##sys#print */
t3=*((C_word*)lf[380]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[393],C_SCHEME_FALSE,*((C_word*)lf[391]+1));}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9122,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 2173 ##sys#write-char-0 */
t3=*((C_word*)lf[379]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),*((C_word*)lf[391]+1));}}

/* k9120 in k9111 in k9099 in k9096 in a9090 in k9084 in k9081 in a9077 in k9059 in k9056 in repl in k8991 in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_9122(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2174 write-err */
f_9017(((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9114 in k9111 in k9099 in k9096 in a9090 in k9084 in k9081 in a9077 in k9059 in k9056 in repl in k8991 in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_9116(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2171 write-err */
f_9017(((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9102 in k9099 in k9096 in a9090 in k9084 in k9081 in a9077 in k9059 in k9056 in repl in k8991 in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_9104(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9104,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9107,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2175 print-call-chain */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[391]+1));}

/* k9105 in k9102 in k9099 in k9096 in a9090 in k9084 in k9081 in a9077 in k9059 in k9056 in repl in k8991 in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_9107(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2176 flush-output */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],*((C_word*)lf[391]+1));}

/* resetports in k9059 in k9056 in repl in k8991 in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static C_word C_fcall f_9069(C_word t0){
C_word tmp;
C_word t1;
C_word t2;
C_word t3;
C_word t4;
t1=C_mutate((C_word*)lf[392]+1,((C_word*)((C_word*)t0)[4])[1]);
t2=C_mutate((C_word*)lf[385]+1,((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate((C_word*)lf[391]+1,((C_word*)((C_word*)t0)[2])[1]);
return(t3);}

/* saveports in k9059 in k9056 in repl in k8991 in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static C_word C_fcall f_9063(C_word t0){
C_word tmp;
C_word t1;
C_word t2;
C_word t3;
C_word t4;
t1=C_mutate(((C_word *)((C_word*)t0)[4])+1,*((C_word*)lf[392]+1));
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,*((C_word*)lf[385]+1));
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,*((C_word*)lf[391]+1));
return(t3);}

/* write-err in repl in k8991 in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_fcall f_9017(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9017,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9023,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[123]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t3,t2);}

/* a9022 in write-err in repl in k8991 in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_9023(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9023,3,t0,t1,t2);}
/* ##sys#repl-print-hook */
t3=*((C_word*)lf[378]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,*((C_word*)lf[391]+1));}

/* ##sys#clear-trace-buffer in k8991 in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_9011(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9011,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub1364(C_SCHEME_UNDEFINED));}

/* ##sys#read-prompt-hook in k8991 in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_8995(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8995,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8999,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9006,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9009,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 2117 repl-prompt */
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* k9007 in ##sys#read-prompt-hook in k8991 in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_9009(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k9004 in ##sys#read-prompt-hook in k8991 in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_9006(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2117 ##sys#print */
t2=*((C_word*)lf[380]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],t1,C_SCHEME_FALSE,*((C_word*)lf[385]+1));}

/* k8997 in ##sys#read-prompt-hook in k8991 in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_8999(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2118 ##sys#flush-output */
t2=*((C_word*)lf[384]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],*((C_word*)lf[385]+1));}

/* ##sys#repl-print-hook in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_8976(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8976,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8980,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8985,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2109 ##sys#with-print-length-limit */
t6=*((C_word*)lf[381]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,*((C_word*)lf[376]+1),t5);}

/* a8984 in ##sys#repl-print-hook in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_8985(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8985,2,t0,t1);}
/* ##sys#print */
t2=*((C_word*)lf[380]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[3],C_SCHEME_TRUE,((C_word*)t0)[2]);}

/* k8978 in ##sys#repl-print-hook in k8969 in k8965 in k8962 in k8959 in k8956 in k8953 in k8950 in k8947 in k8944 in k8941 in k8938 in k8935 in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_8980(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2110 ##sys#write-char-0 */
t2=*((C_word*)lf[379]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],C_make_character(10),((C_word*)t0)[2]);}

/* ##sys#check-syntax in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_8545(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+24)){
C_save_and_reclaim((void*)tr5rv,(void*)f_8545r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest_vector(a,C_rest_count(0));
f_8545r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_8545r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a=C_alloc(24);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8560,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8548,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8591,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8653,tmp=(C_word)a,a+=2,tmp);
t10=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8682,a[2]=t4,a[3]=t3,a[4]=t1,a[5]=t8,a[6]=t9,a[7]=t7,a[8]=t6,tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_notvemptyp(t5))){
t11=(C_word)C_slot(t5,C_fix(0));
t12=C_mutate((C_word*)lf[210]+1,t11);
t13=t10;
f_8682(t13,t12);}
else{
t11=t10;
f_8682(t11,C_SCHEME_UNDEFINED);}}

/* k8680 in ##sys#check-syntax in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_fcall f_8682(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8682,NULL,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8687,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=t3,a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_8687(t5,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* walk in k8680 in ##sys#check-syntax in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_fcall f_8687(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word *a;
loop:
a=C_alloc(19);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_8687,NULL,4,t0,t1,t2,t3);}
t4=(C_truep((C_word)C_blockp(t3))?(C_word)C_vectorp(t3):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=(C_word)C_slot(t3,C_fix(0));
t6=(C_word)C_block_size(t3);
t7=(C_word)C_fixnum_greaterp(t6,C_fix(1));
t8=(C_truep(t7)?(C_word)C_slot(t3,C_fix(1)):C_fix(0));
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8703,a[2]=t2,a[3]=t1,a[4]=t5,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t8,tmp=(C_word)a,a+=8,tmp);
t10=(C_word)C_eqp(t6,C_fix(1));
if(C_truep(t10)){
t11=t9;
f_8703(t11,C_fix(1));}
else{
t11=(C_word)C_fixnum_greaterp(t6,C_fix(2));
t12=t9;
f_8703(t12,(C_truep(t11)?(C_word)C_slot(t3,C_fix(2)):C_fix(99999)));}}
else{
if(C_truep((C_word)C_blockp(t3))){
if(C_truep((C_word)C_symbolp(t3))){
t5=t3;
t6=(C_word)C_eqp(t5,lf[353]);
if(C_truep(t6)){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_SCHEME_TRUE);}
else{
t7=(C_word)C_eqp(t5,lf[354]);
if(C_truep(t7)){
/* eval.scm: 1821 test */
t8=((C_word*)t0)[4];
f_8548(t8,t1,t2,*((C_word*)lf[355]+1),lf[356]);}
else{
t8=(C_word)C_eqp(t5,lf[357]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8832,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 1822 test */
t10=((C_word*)t0)[4];
f_8548(t10,t1,t2,t9,lf[358]);}
else{
t9=(C_word)C_eqp(t5,lf[359]);
if(C_truep(t9)){
/* eval.scm: 1823 test */
t10=((C_word*)t0)[4];
f_8548(t10,t1,t2,*((C_word*)lf[360]+1),lf[361]);}
else{
t10=(C_word)C_eqp(t5,lf[362]);
if(C_truep(t10)){
/* eval.scm: 1824 test */
t11=((C_word*)t0)[4];
f_8548(t11,t1,t2,((C_word*)t0)[3],lf[363]);}
else{
t11=(C_word)C_eqp(t5,lf[364]);
if(C_truep(t11)){
/* eval.scm: 1825 test */
t12=((C_word*)t0)[4];
f_8548(t12,t1,t2,*((C_word*)lf[365]+1),lf[366]);}
else{
t12=(C_word)C_eqp(t5,lf[367]);
if(C_truep(t12)){
/* eval.scm: 1826 test */
t13=((C_word*)t0)[4];
f_8548(t13,t1,t2,*((C_word*)lf[368]+1),lf[369]);}
else{
t13=(C_word)C_eqp(t5,lf[370]);
if(C_truep(t13)){
/* eval.scm: 1827 test */
t14=((C_word*)t0)[4];
f_8548(t14,t1,t2,((C_word*)t0)[2],lf[371]);}
else{
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8886,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1828 test */
t15=((C_word*)t0)[4];
f_8548(t15,t1,t2,t14,lf[372]);}}}}}}}}}
else{
t5=(C_word)C_i_not((C_word)C_blockp(t2));
t6=(C_truep(t5)?t5:(C_word)C_i_not((C_word)C_pairp(t2)));
if(C_truep(t6)){
/* eval.scm: 1830 err */
t7=((C_word*)t0)[6];
f_8560(t7,t1,lf[373]);}
else{
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8905,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t8=(C_word)C_slot(t2,C_fix(0));
t9=(C_word)C_slot(t3,C_fix(0));
/* eval.scm: 1832 walk */
t30=t7;
t31=t8;
t32=t9;
t1=t30;
t2=t31;
t3=t32;
goto loop;}}}
else{
t5=(C_word)C_eqp(t3,t2);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}
else{
/* eval.scm: 1817 err */
t6=((C_word*)t0)[6];
f_8560(t6,t1,lf[374]);}}}}

/* k8903 in walk in k8680 in ##sys#check-syntax in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_8905(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* eval.scm: 1833 walk */
t4=((C_word*)((C_word*)t0)[3])[1];
f_8687(t4,((C_word*)t0)[2],t2,t3);}

/* a8885 in walk in k8680 in ##sys#check-syntax in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_8886(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8886,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_eqp(t2,((C_word*)t0)[2]));}

/* a8831 in walk in k8680 in ##sys#check-syntax in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_8832(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8832,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_symbolp(t2));}

/* k8701 in walk in k8680 in ##sys#check-syntax in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_fcall f_8703(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8703,NULL,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8708,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=t3,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp));
t5=((C_word*)t3)[1];
f_8708(t5,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0));}

/* do1217 in k8701 in walk in k8680 in ##sys#check-syntax in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_fcall f_8708(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8708,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t4)){
if(C_truep((C_word)C_fixnum_lessp(t3,((C_word*)t0)[7]))){
/* eval.scm: 1810 err */
t5=((C_word*)t0)[6];
f_8560(t5,t1,lf[350]);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8727,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[4]))){
/* eval.scm: 1812 err */
t6=((C_word*)t0)[6];
f_8560(t6,t5,lf[351]);}
else{
t6=(C_word)C_i_not((C_word)C_blockp(t2));
t7=(C_truep(t6)?t6:(C_word)C_i_not((C_word)C_pairp(t2)));
if(C_truep(t7)){
/* eval.scm: 1814 err */
t8=((C_word*)t0)[6];
f_8560(t8,t5,lf[352]);}
else{
t8=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 1815 walk */
t9=((C_word*)((C_word*)t0)[3])[1];
f_8687(t9,t5,t8,((C_word*)t0)[2]);}}}}

/* k8725 in do1217 in k8701 in walk in k8680 in ##sys#check-syntax in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_8727(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_8708(t4,((C_word*)t0)[2],t2,t3);}

/* proper-list? in ##sys#check-syntax in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_8653(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8653,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8659,tmp=(C_word)a,a+=2,tmp);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,f_8659(t2));}

/* loop in proper-list? in ##sys#check-syntax in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static C_word C_fcall f_8659(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
loop:
t2=(C_word)C_eqp(t1,C_SCHEME_END_OF_LIST);
if(C_truep(t2)){
return(t2);}
else{
t3=(C_truep((C_word)C_blockp(t1))?(C_word)C_pairp(t1):C_SCHEME_FALSE);
if(C_truep(t3)){
t4=(C_word)C_slot(t1,C_fix(1));
t6=t4;
t1=t6;
goto loop;}
else{
return(C_SCHEME_FALSE);}}}

/* lambda-list? in ##sys#check-syntax in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_8591(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8591,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8595,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1777 ##sys#extended-lambda-list? */
t4=*((C_word*)lf[78]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k8593 in lambda-list? in ##sys#check-syntax in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_8595(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8595,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8603,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_8603(t5,((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* loop in k8593 in lambda-list? in ##sys#check-syntax in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_fcall f_8603(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
a=C_alloc(3);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_8603,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
if(C_truep((C_word)C_blockp(t2))){
if(C_truep((C_word)C_symbolp(t2))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8626,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1781 keyword? */
t5=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}
else{
if(C_truep((C_word)C_pairp(t2))){
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_i_not((C_word)C_blockp(t4));
t6=(C_truep(t5)?t5:(C_word)C_i_not((C_word)C_symbolp(t4)));
if(C_truep(t6)){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_SCHEME_FALSE);}
else{
t7=(C_word)C_slot(t2,C_fix(1));
/* eval.scm: 1786 loop */
t10=t1;
t11=t7;
t1=t10;
t2=t11;
goto loop;}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}}

/* k8624 in loop in k8593 in lambda-list? in ##sys#check-syntax in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_8626(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_not(t1));}

/* test in ##sys#check-syntax in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_fcall f_8548(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8548,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8555,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1765 pred */
t6=t3;
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k8553 in test in ##sys#check-syntax in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_8555(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
/* eval.scm: 1765 err */
t2=((C_word*)t0)[3];
f_8560(t2,((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* err in ##sys#check-syntax in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_fcall f_8560(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8560,NULL,3,t0,t1,t2);}
t3=*((C_word*)lf[210]+1);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8564,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* eval.scm: 1769 get-line-number */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t3);}

/* k8562 in err in ##sys#check-syntax in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_8564(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8564,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8571,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8578,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1772 symbol->string */
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8589,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1773 symbol->string */
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}}

/* k8587 in k8562 in err in ##sys#check-syntax in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_8589(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1773 string-append */
t2=((C_word*)t0)[4];
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[348],t1,lf[349],((C_word*)t0)[2]);}

/* k8576 in k8562 in err in ##sys#check-syntax in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_8578(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8578,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8582,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1772 number->string */
C_number_to_string(3,0,t2,((C_word*)t0)[2]);}

/* k8580 in k8576 in k8562 in err in ##sys#check-syntax in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_8582(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1772 string-append */
t2=((C_word*)t0)[5];
((C_proc8)(void*)(*((C_word*)t2+1)))(8,t2,((C_word*)t0)[4],lf[345],((C_word*)t0)[3],lf[346],t1,lf[347],((C_word*)t0)[2]);}

/* k8569 in k8562 in err in ##sys#check-syntax in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_8571(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1770 ##sys#syntax-error-hook */
t2=*((C_word*)lf[56]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* get-line-number in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_8509(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8509,3,t0,t1,t2);}
if(C_truep(*((C_word*)lf[339]+1))){
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
if(C_truep((C_word)C_i_symbolp(t3))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8531,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1751 ##sys#hash-table-ref */
t5=*((C_word*)lf[42]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,*((C_word*)lf[339]+1),t3);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k8529 in get-line-number in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_8531(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_u_i_assq(((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?(C_word)C_slot(t2,C_fix(1)):C_SCHEME_FALSE));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* ##sys#syntax-error-hook in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_8501(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_8501r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_8501r(t0,t1,t2);}}

static void C_ccall f_8501r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_apply(5,0,t1,*((C_word*)lf[223]+1),lf[340],t2);}

/* ##sys#display-times in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_8447(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8447,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8451,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 1726 display-rj */
t5=((C_word*)t0)[2];
f_8426(t5,t3,t4,C_fix(8));}

/* k8449 in ##sys#display-times in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_8451(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8451,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8454,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1727 display */
t3=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[338]);}

/* k8452 in k8449 in ##sys#display-times in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_8454(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8454,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8457,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* eval.scm: 1728 display-rj */
t4=((C_word*)t0)[2];
f_8426(t4,t2,t3,C_fix(8));}

/* k8455 in k8452 in k8449 in ##sys#display-times in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_8457(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8457,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8460,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1729 display */
t3=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[337]);}

/* k8458 in k8455 in k8452 in k8449 in ##sys#display-times in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_8460(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8460,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8463,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(2));
/* eval.scm: 1730 display-rj */
t4=((C_word*)t0)[2];
f_8426(t4,t2,t3,C_fix(8));}

/* k8461 in k8458 in k8455 in k8452 in k8449 in ##sys#display-times in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_8463(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8463,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8466,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1731 display */
t3=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[336]);}

/* k8464 in k8461 in k8458 in k8455 in k8452 in k8449 in ##sys#display-times in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_8466(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8466,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8469,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(3));
/* eval.scm: 1732 display-rj */
t4=((C_word*)t0)[2];
f_8426(t4,t2,t3,C_fix(8));}

/* k8467 in k8464 in k8461 in k8458 in k8455 in k8452 in k8449 in ##sys#display-times in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_8469(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8469,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8472,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1733 display */
t3=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[335]);}

/* k8470 in k8467 in k8464 in k8461 in k8458 in k8455 in k8452 in k8449 in ##sys#display-times in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_8472(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8472,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8475,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(4));
/* eval.scm: 1734 display-rj */
t4=((C_word*)t0)[2];
f_8426(t4,t2,t3,C_fix(8));}

/* k8473 in k8470 in k8467 in k8464 in k8461 in k8458 in k8455 in k8452 in k8449 in ##sys#display-times in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_8475(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1735 display */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],lf[334]);}

/* display-rj in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_fcall f_8426(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8426,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8430,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_zerop(t2))){
t5=t4;
f_8430(2,t5,lf[333]);}
else{
/* eval.scm: 1721 number->string */
C_number_to_string(3,0,t4,t2);}}

/* k8428 in display-rj in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_8430(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8430,2,t0,t1);}
t2=(C_word)C_block_size(t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8433,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_u_fixnum_difference(((C_word*)t0)[3],t2);
/* eval.scm: 1723 spaces */
t5=((C_word*)t0)[2];
f_8402(t5,t3,t4);}

/* k8431 in k8428 in display-rj in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_8433(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1724 display */
t2=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* spaces in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_fcall f_8402(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8402,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8408,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_8408(t6,t1,t2);}

/* do1147 in spaces in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_fcall f_8408(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8408,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_less_or_equal_p(t2,C_fix(0)))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8418,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1718 display */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,C_make_character(32));}}

/* k8416 in do1147 in spaces in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_8418(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_difference(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_8408(t3,((C_word*)t0)[2],t2);}

/* ##sys#resolve-include-filename in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_8279(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+17)){
C_save_and_reclaim((void*)tr4rv,(void*)f_8279r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_8279r(t0,t1,t2,t3,t4);}}

static void C_ccall f_8279r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(17);
t5=(C_word)C_vemptyp(t4);
t6=(C_truep(t5)?C_SCHEME_FALSE:(C_word)C_slot(t4,C_fix(0)));
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8285,a[2]=t8,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp));
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8320,a[2]=t8,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t11=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8337,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=t10,a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 1699 test */
t12=t10;
f_8320(t12,t11,t2);}

/* k8335 in ##sys#resolve-include-filename in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_8337(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8337,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8347,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8388,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1701 ##sys#repository-path */
t4=*((C_word*)lf[279]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t2;
f_8347(2,t3,*((C_word*)lf[284]+1));}}}

/* k8386 in k8335 in ##sys#resolve-include-filename in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_8388(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8388,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* eval.scm: 1701 ##sys#append */
t3=*((C_word*)lf[88]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],*((C_word*)lf[284]+1),t2);}

/* k8345 in k8335 in ##sys#resolve-include-filename in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_8347(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8347,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8349,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_8349(t5,((C_word*)t0)[2],t1);}

/* loop in k8345 in k8335 in ##sys#resolve-include-filename in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_fcall f_8349(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8349,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[5]);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8359,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8373,a[2]=t4,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 1704 string-append */
t7=((C_word*)t0)[2];
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t5,t6,lf[332],((C_word*)t0)[5]);}}

/* k8371 in loop in k8345 in k8335 in ##sys#resolve-include-filename in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_8373(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1704 test */
t2=((C_word*)t0)[3];
f_8320(t2,((C_word*)t0)[2],t1);}

/* k8357 in loop in k8345 in k8335 in ##sys#resolve-include-filename in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_8359(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* eval.scm: 1707 loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_8349(t3,((C_word*)t0)[4],t2);}}

/* test in ##sys#resolve-include-filename in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_fcall f_8320(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8320,NULL,3,t0,t1,t2);}
t3=(C_truep(((C_word*)t0)[3])?(C_word)C_a_i_list(&a,2,lf[17],*((C_word*)lf[249]+1)):(C_word)C_a_i_list(&a,2,*((C_word*)lf[249]+1),lf[17]));
/* eval.scm: 1694 test2 */
t4=((C_word*)((C_word*)t0)[2])[1];
f_8285(t4,t1,t2,t3);}

/* test2 in ##sys#resolve-include-filename in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_fcall f_8285(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8285,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8298,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1688 exists? */
f_8260(t4,t2);}
else{
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8301,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=t3,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_u_i_car(t3);
/* eval.scm: 1689 ##sys#string-append */
t6=*((C_word*)lf[32]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t2,t5);}}

/* k8299 in test2 in ##sys#resolve-include-filename in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_8301(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8301,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8307,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 1690 exists? */
f_8260(t2,t1);}

/* k8305 in k8299 in test2 in ##sys#resolve-include-filename in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_8307(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[5]);}
else{
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* eval.scm: 1692 test2 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_8285(t3,((C_word*)t0)[6],((C_word*)t0)[2],t2);}}

/* k8296 in test2 in ##sys#resolve-include-filename in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_8298(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?((C_word*)t0)[2]:C_SCHEME_FALSE));}

/* exists? in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_fcall f_8260(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8260,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8264,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1683 ##sys#file-info */
t4=*((C_word*)lf[248]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k8262 in exists? in k8252 in k8248 in k8245 in k8241 in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_8264(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(t1,C_fix(4));
t3=(C_word)C_eqp(C_fix(1),t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_not(t3));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* initb in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_fcall f_8227(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8227,NULL,2,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8229,a[2]=t2,tmp=(C_word)a,a+=3,tmp));}

/* f_8229 in initb in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_8229(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8229,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8233,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1644 ##sys#hash-table-location */
t4=*((C_word*)lf[127]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)t0)[2],t2,C_SCHEME_TRUE);}

/* k8231 */
static void C_ccall f_8233(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(0));
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_setslot(t1,C_fix(1),t2));}

/* null-environment in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_8189(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3rv,(void*)f_8189r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_8189r(t0,t1,t2,t3);}}

static void C_ccall f_8189r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(5);
t4=(C_word)C_i_check_exact_2(t2,lf[330]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8196,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_fixnum_lessp(t2,C_fix(4));
t7=(C_truep(t6)?t6:(C_word)C_fixnum_greaterp(t2,C_fix(5)));
if(C_truep(t7)){
/* eval.scm: 1635 ##sys#error */
t8=*((C_word*)lf[144]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t5,lf[330],lf[331],t2);}
else{
t8=t5;
f_8196(2,t8,C_SCHEME_UNDEFINED);}}

/* k8194 in null-environment in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_8196(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8196,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8203,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1638 make-vector */
t3=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_fix(301),C_SCHEME_END_OF_LIST);}

/* k8201 in k8194 in null-environment in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_8203(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8203,2,t0,t1);}
t2=(C_word)C_notvemptyp(((C_word*)t0)[3]);
t3=(C_truep(t2)?(C_word)C_slot(((C_word*)t0)[3],C_fix(0)):C_SCHEME_FALSE);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_record(&a,3,lf[321],t1,t3));}

/* scheme-report-environment in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_8145(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3rv,(void*)f_8145r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_8145r(t0,t1,t2,t3);}}

static void C_ccall f_8145r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(8);
t4=(C_word)C_i_check_exact_2(t2,lf[327]);
t5=(C_word)C_notvemptyp(t3);
t6=(C_truep(t5)?(C_word)C_slot(t3,C_fix(0)):C_SCHEME_FALSE);
t7=t2;
switch(t7){
case C_fix(4):
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8165,a[2]=t6,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1626 ##sys#copy-env-table */
t9=*((C_word*)lf[323]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,t8,lf[319],C_SCHEME_TRUE,t6);
case C_fix(5):
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8178,a[2]=t6,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1627 ##sys#copy-env-table */
t9=*((C_word*)lf[323]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,t8,lf[320],C_SCHEME_TRUE,t6);
default:
/* eval.scm: 1628 ##sys#error */
t8=*((C_word*)lf[144]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t1,lf[327],lf[328],t2);}}

/* k8176 in scheme-report-environment in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_8178(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8178,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,3,lf[321],t1,((C_word*)t0)[2]));}

/* k8163 in scheme-report-environment in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_8165(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8165,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,3,lf[321],t1,((C_word*)t0)[2]));}

/* interaction-environment in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_8142(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8142,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[322]);}

/* ##sys#environment-symbols in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_8023(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+18)){
C_save_and_reclaim((void*)tr3rv,(void*)f_8023r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_8023r(t0,t1,t2,t3);}}

static void C_ccall f_8023r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a=C_alloc(18);
t4=(C_word)C_i_check_structure(t2,lf[321]);
t5=(C_word)C_notvemptyp(t3);
t6=(C_truep(t5)?(C_word)C_slot(t3,C_fix(0)):C_SCHEME_FALSE);
t7=(C_word)C_slot(t2,C_fix(1));
if(C_truep(t7)){
t8=(C_word)C_fix((C_word)C_header_size(t7));
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8044,a[2]=t6,a[3]=t7,a[4]=t10,a[5]=t8,tmp=(C_word)a,a+=6,tmp));
t12=((C_word*)t10)[1];
f_8044(t12,t1,C_fix(0),C_SCHEME_END_OF_LIST);}
else{
t8=C_SCHEME_END_OF_LIST;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8115,a[2]=t9,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8117,a[2]=t9,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1613 ##sys#walk-namespace */
t12=*((C_word*)lf[325]+1);
((C_proc3)(void*)(*((C_word*)t12+1)))(3,t12,t10,t11);}}

/* a8116 in ##sys#environment-symbols in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_8117(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8117,3,t0,t1,t2);}
t3=(C_word)C_i_not(((C_word*)t0)[3]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8127,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t3)){
t5=t4;
f_8127(2,t5,t3);}
else{
/* eval.scm: 1615 pred */
t5=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}}

/* k8125 in a8116 in ##sys#environment-symbols in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_8127(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8127,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k8113 in ##sys#environment-symbols in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_8115(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* do1078 in ##sys#environment-symbols in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_fcall f_8044(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8044,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_u_fixnum_plus(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8062,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_slot(((C_word*)t0)[3],t2);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8068,a[2]=t8,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp));
t10=((C_word*)t8)[1];
f_8068(t10,t5,t6,t3);}}

/* loop in do1078 in ##sys#environment-symbols in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_fcall f_8068(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8068,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_u_i_car(t2);
t5=(C_word)C_slot(t4,C_fix(0));
t6=(C_word)C_i_not(((C_word*)t0)[3]);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8087,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t5,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t6)){
t8=t7;
f_8087(2,t8,t6);}
else{
/* eval.scm: 1607 pred */
t8=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t5);}}}

/* k8085 in loop in do1078 in ##sys#environment-symbols in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_8087(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8087,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[4]);
/* eval.scm: 1608 loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_8068(t4,((C_word*)t0)[2],t2,t3);}
else{
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
/* eval.scm: 1609 loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_8068(t3,((C_word*)t0)[2],t2,((C_word*)t0)[4]);}}

/* k8060 in do1078 in ##sys#environment-symbols in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_8062(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[4])[1];
f_8044(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* ##sys#copy-env-table in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_7915(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr5rv,(void*)f_7915r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest_vector(a,C_rest_count(0));
f_7915r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_7915r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(8);
t6=(C_word)C_notvemptyp(t5);
t7=(C_truep(t6)?(C_word)C_slot(t5,C_fix(0)):C_SCHEME_FALSE);
t8=(C_word)C_block_size(t2);
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7925,a[2]=t1,a[3]=t4,a[4]=t3,a[5]=t7,a[6]=t2,a[7]=t8,tmp=(C_word)a,a+=8,tmp);
/* eval.scm: 1574 ##sys#make-vector */
t10=*((C_word*)lf[160]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t9,t8,C_SCHEME_END_OF_LIST);}

/* k7923 in ##sys#copy-env-table in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_7925(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7925,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7930,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t3,a[7]=t1,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp));
t5=((C_word*)t3)[1];
f_7930(t5,((C_word*)t0)[2],C_fix(0));}

/* do1061 in k7923 in ##sys#copy-env-table in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_fcall f_7930(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7930,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[8]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[7]);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7951,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=t2,a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_slot(((C_word*)t0)[5],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7957,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_7957(t8,t3,t4);}}

/* copy in do1061 in k7923 in ##sys#copy-env-table in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_fcall f_7957(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
a=C_alloc(8);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_7957,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t3,C_fix(0));
t5=(C_word)C_i_not(((C_word*)t0)[5]);
t6=(C_truep(t5)?t5:(C_word)C_u_i_memq(t4,((C_word*)t0)[5]));
if(C_truep(t6)){
t7=(C_word)C_slot(t3,C_fix(1));
t8=(C_truep(((C_word*)t0)[4])?((C_word*)t0)[3]:(C_word)C_slot(t3,C_fix(2)));
t9=(C_word)C_a_i_vector(&a,3,t4,t7,t8);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7990,a[2]=t9,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t11=(C_word)C_slot(t2,C_fix(1));
/* eval.scm: 1589 copy */
t14=t10;
t15=t11;
t1=t14;
t2=t15;
goto loop;}
else{
t7=(C_word)C_slot(t2,C_fix(1));
/* eval.scm: 1590 copy */
t14=t1;
t15=t7;
t1=t14;
t2=t15;
goto loop;}}}

/* k7988 in copy in do1061 in k7923 in ##sys#copy-env-table in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_7990(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7990,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k7949 in do1061 in k7923 in ##sys#copy-env-table in k7906 in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_7951(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[5],((C_word*)t0)[4],t1);
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_7930(t4,((C_word*)t0)[2],t3);}

/* ##sys#string->c-identifier in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_7852(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7852,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7856,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1555 string-copy */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k7854 in ##sys#string->c-identifier in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_7856(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7856,2,t0,t1);}
t2=(C_word)C_block_size(t1);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7864,a[2]=t4,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_7864(t6,((C_word*)t0)[2],C_fix(0));}

/* do1046 in k7854 in ##sys#string->c-identifier in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_fcall f_7864(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7864,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[4]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}
else{
t3=(C_word)C_subchar(((C_word*)t0)[3],t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7884,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_u_i_char_alphabeticp(t3))){
t5=t4;
f_7884(t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_u_i_char_numericp(t3);
t6=(C_word)C_i_not(t5);
t7=t4;
f_7884(t7,(C_truep(t6)?t6:(C_word)C_eqp(t2,C_fix(0))));}}}

/* k7882 in do1046 in k7854 in ##sys#string->c-identifier in k7848 in k7845 in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_fcall f_7884(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_truep(t1)?(C_word)C_setsubchar(((C_word*)t0)[5],((C_word*)t0)[4],C_make_character(95)):C_SCHEME_UNDEFINED);
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_7864(t4,((C_word*)t0)[2],t3);}

/* set-extension-specifier! in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_7808(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7808,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_symbol_2(t2,lf[317]);
t5=(C_word)C_u_i_assq(t2,*((C_word*)lf[314]+1));
if(C_truep(t5)){
t6=(C_word)C_slot(t5,C_fix(1));
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7826,a[2]=t6,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_i_setslot(t5,C_fix(1),t7));}
else{
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7840,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t7=(C_word)C_a_i_cons(&a,2,t2,t6);
t8=(C_word)C_a_i_cons(&a,2,t7,*((C_word*)lf[314]+1));
t9=C_mutate((C_word*)lf[314]+1,t8);
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,t9);}}

/* a7839 in set-extension-specifier! in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_7840(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7840,3,t0,t1,t2);}
/* eval.scm: 1510 proc */
t3=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,C_SCHEME_FALSE);}

/* a7825 in set-extension-specifier! in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_7826(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7826,3,t0,t1,t2);}
/* eval.scm: 1508 proc */
t3=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,((C_word*)t0)[2]);}

/* ##sys#do-the-right-thing in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_7409(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7409,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7412,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7433,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7684,a[2]=t5,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t1,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t7=(C_word)C_u_i_car(t2);
t8=t6;
f_7684(t8,(C_word)C_i_symbolp(t7));}
else{
t7=t6;
f_7684(t7,C_SCHEME_FALSE);}}

/* k7682 in ##sys#do-the-right-thing in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_fcall f_7684(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7684,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(0));
t3=(C_word)C_u_i_assq(t2,*((C_word*)lf[314]+1));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7693,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_slot(t3,C_fix(1));
t6=t5;
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,((C_word*)t0)[6]);}
else{
/* eval.scm: 1496 ##sys#error */
t4=*((C_word*)lf[144]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[5],lf[315],((C_word*)t0)[6]);}}
else{
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[6]))){
/* eval.scm: 1498 doit */
t2=((C_word*)t0)[2];
f_7433(t2,((C_word*)t0)[5],((C_word*)t0)[6]);}
else{
/* eval.scm: 1499 ##sys#error */
t2=*((C_word*)lf[144]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[5],lf[316],((C_word*)t0)[6]);}}}

/* k7691 in k7682 in ##sys#do-the-right-thing in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_7693(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7693,2,t0,t1);}
if(C_truep((C_word)C_i_stringp(t1))){
t2=(C_word)C_a_i_list(&a,2,lf[235],t1);
/* eval.scm: 1484 values */
C_values(4,0,((C_word*)t0)[4],t2,C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_i_vectorp(t1))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7719,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1486 vector->list */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}
else{
/* eval.scm: 1495 ##sys#do-the-right-thing */
t2=*((C_word*)lf[174]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[4],t1,((C_word*)t0)[3]);}}}

/* k7717 in k7691 in k7682 in ##sys#do-the-right-thing in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_7719(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7719,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7721,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_7721(t5,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST,C_SCHEME_FALSE);}

/* loop in k7717 in k7691 in k7682 in ##sys#do-the-right-thing in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_fcall f_7721(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7721,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7739,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1490 reverse */
t6=*((C_word*)lf[82]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t3);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7744,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7754,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1491 ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t5,t6);}}

/* a7753 in loop in k7717 in k7691 in k7682 in ##sys#do-the-right-thing in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_7754(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7754,4,t0,t1,t2,t3);}
t4=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t5=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[4]);
t6=(C_truep(t3)?t3:((C_word*)t0)[3]);
/* eval.scm: 1492 loop */
t7=((C_word*)((C_word*)t0)[2])[1];
f_7721(t7,t1,t4,t5,t6);}

/* a7743 in loop in k7717 in k7691 in k7682 in ##sys#do-the-right-thing in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_7744(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7744,2,t0,t1);}
t2=(C_word)C_u_i_car(((C_word*)t0)[3]);
/* eval.scm: 1491 ##sys#do-the-right-thing */
t3=*((C_word*)lf[174]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,((C_word*)t0)[2]);}

/* k7737 in loop in k7717 in k7691 in k7682 in ##sys#do-the-right-thing in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_7739(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7739,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[106],t1);
/* eval.scm: 1490 values */
C_values(4,0,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* doit in ##sys#do-the-right-thing in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_fcall f_7433(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7433,NULL,3,t0,t1,t2);}
t3=(C_word)C_u_i_memq(t2,lf[28]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7443,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t3)){
t5=t4;
f_7443(2,t5,t3);}
else{
if(C_truep(((C_word*)t0)[3])){
t5=t4;
f_7443(2,t5,(C_word)C_u_i_memq(t2,lf[30]));}
else{
/* eval.scm: 1437 ##sys#feature? */
t5=*((C_word*)lf[313]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}}}

/* k7441 in doit in ##sys#do-the-right-thing in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_7443(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[47],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7443,2,t0,t1);}
if(C_truep(t1)){
/* eval.scm: 1438 values */
C_values(4,0,((C_word*)t0)[5],lf[305],C_SCHEME_TRUE);}
else{
t2=((C_word*)t0)[4];
if(C_truep((C_truep((C_word)C_eqp(t2,lf[306]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t2,lf[307]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7455,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1440 ##sys#->feature-id */
t4=*((C_word*)lf[269]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[4]);}
else{
if(C_truep((C_word)C_u_i_memq(((C_word*)t0)[4],*((C_word*)lf[2]+1)))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7492,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[3])){
t4=(C_word)C_a_i_list(&a,2,lf[310],((C_word*)t0)[4]);
t5=(C_word)C_a_i_list(&a,2,lf[90],t4);
t6=t3;
f_7492(t6,(C_word)C_a_i_list(&a,2,lf[182],t5));}
else{
t4=(C_word)C_a_i_list(&a,2,lf[90],((C_word*)t0)[4]);
t5=t3;
f_7492(t5,(C_word)C_a_i_list(&a,2,lf[270],t4));}}
else{
if(C_truep((C_word)C_u_i_memq(((C_word*)t0)[4],*((C_word*)lf[4]+1)))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7519,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1452 ##sys#extension-information */
t4=*((C_word*)lf[295]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[4],lf[312]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7577,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1462 ##sys#extension-information */
t4=*((C_word*)lf[295]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[4],lf[312]);}}}}}

/* k7575 in k7441 in doit in ##sys#do-the-right-thing in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_7577(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7577,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_u_i_assq(lf[311],t1);
t3=(C_word)C_u_i_assq(lf[299],t1);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7589,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
/* eval.scm: 1466 add-req */
t5=((C_word*)t0)[2];
f_7412(t5,t4,((C_word*)t0)[3]);}
else{
t5=t4;
f_7589(2,t5,C_SCHEME_UNDEFINED);}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7658,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1478 add-req */
t3=((C_word*)t0)[2];
f_7412(t3,t2,((C_word*)t0)[3]);}}

/* k7656 in k7575 in k7441 in doit in ##sys#do-the-right-thing in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_7658(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7658,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[90],((C_word*)t0)[3]);
t3=(C_word)C_a_i_list(&a,2,lf[170],t2);
/* eval.scm: 1479 values */
C_values(4,0,((C_word*)t0)[2],t3,C_SCHEME_FALSE);}

/* k7587 in k7575 in k7441 in doit in ##sys#do-the-right-thing in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_7589(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[24],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7589,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7600,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7604,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[3])){
t4=(C_word)C_a_i_list(&a,2,lf[90],((C_word*)t0)[2]);
t5=(C_word)C_a_i_list(&a,2,lf[168],t4);
t6=t3;
f_7604(t6,(C_word)C_a_i_list(&a,1,t5));}
else{
t4=t3;
f_7604(t4,C_SCHEME_END_OF_LIST);}}

/* k7602 in k7587 in k7575 in k7441 in doit in ##sys#do-the-right-thing in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_fcall f_7604(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7604,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7608,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_truep(((C_word*)t0)[4])?C_SCHEME_FALSE:((C_word*)t0)[3]);
if(C_truep(t3)){
t4=t2;
f_7608(t4,C_SCHEME_END_OF_LIST);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7622,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7624,tmp=(C_word)a,a+=2,tmp);
t6=(C_truep(((C_word*)t0)[4])?(C_word)C_slot(((C_word*)t0)[4],C_fix(1)):(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]));
/* map */
t7=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t4,t5,t6);}}

/* a7623 in k7602 in k7587 in k7575 in k7441 in doit in ##sys#do-the-right-thing in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_7624(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7624,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[90],t2));}

/* k7620 in k7602 in k7587 in k7575 in k7441 in doit in ##sys#do-the-right-thing in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_7622(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7622,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[170],t1);
t3=((C_word*)t0)[2];
f_7608(t3,(C_word)C_a_i_list(&a,1,t2));}

/* k7606 in k7602 in k7587 in k7575 in k7441 in doit in ##sys#do-the-right-thing in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_fcall f_7608(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1423 ##sys#append */
t2=*((C_word*)lf[88]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7598 in k7587 in k7575 in k7441 in doit in ##sys#do-the-right-thing in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_7600(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7600,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[106],t1);
/* eval.scm: 1467 values */
C_values(4,0,((C_word*)t0)[2],t2,C_SCHEME_TRUE);}

/* k7517 in k7441 in doit in ##sys#do-the-right-thing in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_7519(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[23],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7519,2,t0,t1);}
t2=(C_word)C_u_i_assq(lf[311],t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7533,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7537,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t2)){
t5=(C_word)C_a_i_list(&a,2,lf[90],((C_word*)t0)[2]);
t6=(C_word)C_a_i_list(&a,2,lf[168],t5);
t7=t4;
f_7537(t7,(C_word)C_a_i_list(&a,1,t6));}
else{
t5=t4;
f_7537(t5,C_SCHEME_END_OF_LIST);}}

/* k7535 in k7517 in k7441 in doit in ##sys#do-the-right-thing in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_fcall f_7537(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[34],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7537,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7545,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=(C_word)C_a_i_list(&a,2,lf[310],((C_word*)t0)[2]);
t4=(C_word)C_a_i_list(&a,2,lf[90],t3);
t5=t2;
f_7545(t5,(C_word)C_a_i_list(&a,2,lf[182],t4));}
else{
t3=(C_word)C_a_i_list(&a,2,lf[90],((C_word*)t0)[2]);
t4=t2;
f_7545(t4,(C_word)C_a_i_list(&a,2,lf[270],t3));}}

/* k7543 in k7535 in k7517 in k7441 in doit in ##sys#do-the-right-thing in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_fcall f_7545(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7545,NULL,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* eval.scm: 1423 ##sys#append */
t3=*((C_word*)lf[88]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k7531 in k7517 in k7441 in doit in ##sys#do-the-right-thing in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_7533(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7533,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[106],t1);
/* eval.scm: 1454 values */
C_values(4,0,((C_word*)t0)[2],t2,C_SCHEME_TRUE);}

/* k7490 in k7441 in doit in ##sys#do-the-right-thing in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_fcall f_7492(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1446 values */
C_values(4,0,((C_word*)t0)[2],t1,C_SCHEME_TRUE);}

/* k7453 in k7441 in doit in ##sys#do-the-right-thing in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_7455(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7455,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7458,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_u_i_memq(t1,*((C_word*)lf[185]+1)))){
t3=t2;
f_7458(t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7467,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7475,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7479,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1442 ##sys#symbol->string */
t6=*((C_word*)lf[275]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[2]);}}

/* k7477 in k7453 in k7441 in doit in ##sys#do-the-right-thing in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_7479(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1442 ##sys#resolve-include-filename */
t2=*((C_word*)lf[309]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_TRUE);}

/* k7473 in k7453 in k7441 in doit in ##sys#do-the-right-thing in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_7475(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1442 ##sys#load */
t2=*((C_word*)lf[229]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],t1,C_SCHEME_FALSE,C_SCHEME_FALSE);}

/* k7465 in k7453 in k7441 in doit in ##sys#do-the-right-thing in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_7467(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7467,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],*((C_word*)lf[185]+1));
t3=C_mutate((C_word*)lf[185]+1,t2);
t4=((C_word*)t0)[2];
f_7458(t4,t3);}

/* k7456 in k7453 in k7441 in doit in ##sys#do-the-right-thing in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_fcall f_7458(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1444 values */
C_values(4,0,((C_word*)t0)[2],lf[308],C_SCHEME_TRUE);}

/* add-req in ##sys#do-the-right-thing in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_fcall f_7412(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7412,NULL,3,t0,t1,t2);}
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7421,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7427,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1428 ##sys#hash-table-update! */
t5=*((C_word*)lf[121]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t1,*((C_word*)lf[303]+1),lf[304],t3,t4);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* a7426 in add-req in ##sys#do-the-right-thing in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_7427(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7427,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]));}

/* a7420 in add-req in ##sys#do-the-right-thing in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_7421(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7421,3,t0,t1,t2);}
/* lset-adjoin */
t3=*((C_word*)lf[301]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t1,*((C_word*)lf[302]+1),t2,((C_word*)t0)[2]);}

/* ##sys#lookup-runtime-requirements in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_7360(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7360,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7366,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_7366(t6,t1,t2);}

/* loop1 in ##sys#lookup-runtime-requirements in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_fcall f_7366(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7366,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7380,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_u_i_car(t2);
/* eval.scm: 1417 ##sys#extension-information */
t5=*((C_word*)lf[295]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,C_SCHEME_FALSE);}}

/* k7378 in loop1 in ##sys#lookup-runtime-requirements in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_7380(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7380,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7383,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=(C_word)C_u_i_assq(lf[299],t1);
t4=t2;
f_7383(t4,(C_truep(t3)?(C_word)C_slot(t3,C_fix(1)):C_SCHEME_FALSE));}
else{
t3=t2;
f_7383(t3,C_SCHEME_FALSE);}}

/* k7381 in k7378 in loop1 in ##sys#lookup-runtime-requirements in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_fcall f_7383(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7383,NULL,2,t0,t1);}
t2=(C_truep(t1)?t1:C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7390,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* eval.scm: 1421 loop1 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_7366(t5,t3,t4);}

/* k7388 in k7381 in k7378 in loop1 in ##sys#lookup-runtime-requirements in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_7390(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1416 append */
t2=*((C_word*)lf[68]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* extension-information in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_7354(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7354,3,t0,t1,t2);}
/* eval.scm: 1407 ##sys#extension-information */
t3=*((C_word*)lf[295]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,lf[298]);}

/* ##sys#extension-information in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_7323(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7323,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7327,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 1400 ##sys#canonicalize-extension-path */
t5=*((C_word*)lf[273]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,t3);}

/* k7325 in ##sys#extension-information in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_7327(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7327,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7330,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7352,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1401 ##sys#repository-path */
t4=*((C_word*)lf[279]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k7350 in k7325 in ##sys#extension-information in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_7352(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1401 string-append */
t2=((C_word*)t0)[4];
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],t1,lf[296],((C_word*)t0)[2],lf[297]);}

/* k7328 in k7325 in ##sys#extension-information in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_7330(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7330,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7333,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7348,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1402 string-append */
t4=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t1,lf[20]);}

/* k7346 in k7328 in k7325 in ##sys#extension-information in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_7348(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1402 file-exists? */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k7331 in k7328 in k7325 in ##sys#extension-information in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_7333(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7333,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7340,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* f_7340 in k7331 in k7328 in k7325 in ##sys#extension-information in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_7340(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7340,3,t0,t1,t2);}
/* with-input-from-file951 */
t3=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,((C_word*)t0)[2]);}

/* ##sys#require in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_7310(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+2)){
C_save_and_reclaim((void*)tr2r,(void*)f_7310r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_7310r(t0,t1,t2);}}

static void C_ccall f_7310r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(2);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7316,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[123]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t3,t2);}

/* a7315 in ##sys#require in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_7316(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7316,3,t0,t1,t2);}
/* ##sys#load-extension */
t3=*((C_word*)lf[288]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,lf[294]);}

/* ##sys#provided? in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_7296(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7296,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7307,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1381 ##sys#canonicalize-extension-path */
t4=*((C_word*)lf[273]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[293]);}

/* k7305 in ##sys#provided? in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_7307(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_member(t1,*((C_word*)lf[286]+1));
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?C_SCHEME_TRUE:C_SCHEME_FALSE));}

/* ##sys#provide in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_7276(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+2)){
C_save_and_reclaim((void*)tr2r,(void*)f_7276r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_7276r(t0,t1,t2);}}

static void C_ccall f_7276r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(2);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7282,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[123]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t3,t2);}

/* a7281 in ##sys#provide in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_7282(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7282,3,t0,t1,t2);}
t3=(C_word)C_i_check_symbol_2(t2,lf[291]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7289,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1374 ##sys#canonicalize-extension-path */
t5=*((C_word*)lf[273]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,lf[291]);}

/* k7287 in a7281 in ##sys#provide in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_7289(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7289,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,*((C_word*)lf[286]+1));
t3=C_mutate((C_word*)lf[286]+1,t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* ##sys#load-extension in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_7208(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr4r,(void*)f_7208r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_7208r(t0,t1,t2,t3,t4);}}

static void C_ccall f_7208r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(12);
t5=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7212,a[2]=t3,a[3]=t4,a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_stringp(((C_word*)t5)[1]))){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7271,a[2]=t6,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1355 string->symbol */
t8=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,((C_word*)t5)[1]);}
else{
t7=t6;
f_7212(t7,(C_word)C_i_check_symbol_2(((C_word*)t5)[1],t3));}}

/* k7269 in ##sys#load-extension in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_7271(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_7212(t3,t2);}

/* k7210 in ##sys#load-extension in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_fcall f_7212(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7212,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7215,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1357 ##sys#canonicalize-extension-path */
t3=*((C_word*)lf[273]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[2]);}

/* k7213 in k7210 in ##sys#load-extension in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_7215(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7215,2,t0,t1);}
t2=(C_word)C_i_member(t1,*((C_word*)lf[286]+1));
if(C_truep(t2)){
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
if(C_truep((C_word)C_u_i_memq(((C_word*)((C_word*)t0)[4])[1],*((C_word*)lf[2]+1)))){
/* eval.scm: 1360 ##sys#load-library */
t3=*((C_word*)lf[263]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[5],((C_word*)((C_word*)t0)[4])[1],C_SCHEME_FALSE);}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7233,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 1362 ##sys#find-extension */
t4=*((C_word*)lf[282]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t1,C_SCHEME_TRUE);}}}

/* k7231 in k7213 in k7210 in ##sys#load-extension in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_7233(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7233,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7239,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1364 ##sys#load */
t3=*((C_word*)lf[229]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,t1,C_SCHEME_FALSE,C_SCHEME_FALSE);}
else{
t2=((C_word*)t0)[4];
t3=(C_word)C_i_nullp(t2);
t4=(C_truep(t3)?C_SCHEME_TRUE:(C_word)C_u_i_car(t2));
if(C_truep(t4)){
/* eval.scm: 1367 ##sys#error */
t5=*((C_word*)lf[144]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,((C_word*)t0)[5],((C_word*)t0)[3],lf[289],((C_word*)((C_word*)t0)[2])[1]);}
else{
t5=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}}

/* k7237 in k7231 in k7213 in k7210 in ##sys#load-extension in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_7239(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7239,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],*((C_word*)lf[286]+1));
t3=C_mutate((C_word*)lf[286]+1,t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_TRUE);}

/* ##sys#find-extension in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_7131(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7131,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7134,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7165,a[2]=t1,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7205,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1343 ##sys#repository-path */
t7=*((C_word*)lf[279]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}

/* k7203 in ##sys#find-extension in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_7205(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7205,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7198,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[2])){
/* eval.scm: 1344 ##sys#append */
t4=*((C_word*)lf[88]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,*((C_word*)lf[284]+1),lf[285]);}
else{
t4=t3;
f_7198(2,t4,C_SCHEME_END_OF_LIST);}}

/* k7196 in k7203 in ##sys#find-extension in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_7198(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1343 ##sys#append */
t2=*((C_word*)lf[88]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7163 in ##sys#find-extension in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_7165(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7165,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7167,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_7167(t5,((C_word*)t0)[2],t1);}

/* loop in k7163 in ##sys#find-extension in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_fcall f_7167(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7167,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7180,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1347 check */
t5=((C_word*)t0)[2];
f_7134(t5,t4,t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k7178 in loop in k7163 in ##sys#find-extension in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_7180(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* eval.scm: 1348 loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_7167(t3,((C_word*)t0)[4],t2);}}

/* check in ##sys#find-extension in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_fcall f_7134(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7134,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7138,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1339 string-append */
t4=((C_word*)t0)[3];
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,t2,lf[283],((C_word*)t0)[2]);}

/* k7136 in check in ##sys#find-extension in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_7138(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7138,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7144,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7158,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1340 ##sys#string-append */
t4=*((C_word*)lf[32]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t1,*((C_word*)lf[249]+1));}

/* k7156 in k7136 in check in ##sys#find-extension in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_7158(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1340 file-exists? */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k7142 in k7136 in check in ##sys#find-extension in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_7144(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7144,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7147,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=t2;
f_7147(2,t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7154,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1341 ##sys#string-append */
t4=*((C_word*)lf[32]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[3],lf[17]);}}

/* k7152 in k7142 in k7136 in check in ##sys#find-extension in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_7154(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1341 file-exists? */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k7145 in k7142 in k7136 in check in ##sys#find-extension in k7126 in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_7147(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?((C_word*)t0)[2]:C_SCHEME_FALSE));}

/* ##sys#canonicalize-extension-path in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_6968(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6968,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6971,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6977,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6990,a[2]=t1,a[3]=t5,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_stringp(t2))){
t7=t6;
f_6990(2,t7,t2);}
else{
if(C_truep((C_word)C_i_symbolp(t2))){
/* eval.scm: 1300 ##sys#symbol->string */
t7=*((C_word*)lf[275]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t2);}
else{
if(C_truep((C_word)C_i_listp(t2))){
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7073,a[2]=t4,a[3]=t8,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp));
t10=((C_word*)t8)[1];
f_7073(t10,t6,t2);}
else{
t7=t6;
f_6990(2,t7,C_SCHEME_UNDEFINED);}}}}

/* loop in ##sys#canonicalize-extension-path in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_fcall f_7073(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7073,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[276]);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7090,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_symbolp(t3))){
/* eval.scm: 1307 ##sys#symbol->string */
t5=*((C_word*)lf[275]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t3);}
else{
if(C_truep((C_word)C_i_stringp(t3))){
t5=t4;
f_7090(2,t5,t3);}
else{
/* eval.scm: 1309 err */
t5=((C_word*)t0)[2];
f_6971(t5,t4);}}}}

/* k7088 in loop in ##sys#canonicalize-extension-path in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_7090(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7090,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_i_nullp(t2);
t4=(C_truep(t3)?lf[277]:lf[278]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7098,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* eval.scm: 1313 loop */
t7=((C_word*)((C_word*)t0)[2])[1];
f_7073(t7,t5,t6);}

/* k7096 in k7088 in loop in ##sys#canonicalize-extension-path in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_7098(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1305 string-append */
t2=((C_word*)t0)[5];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k6988 in ##sys#canonicalize-extension-path in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_6990(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6990,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6995,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_6995(t5,((C_word*)t0)[2],t1);}

/* check in k6988 in ##sys#canonicalize-extension-path in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_fcall f_6995(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6995,NULL,3,t0,t1,t2);}
t3=(C_word)C_block_size(t2);
t4=(C_word)C_eqp(C_fix(0),t3);
if(C_truep(t4)){
/* eval.scm: 1316 err */
t5=((C_word*)t0)[4];
f_6971(t5,t1);}
else{
t5=(C_word)C_subchar(t2,C_fix(0));
t6=f_6977(t5);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7021,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1318 ##sys#substring */
t8=*((C_word*)lf[239]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t7,t2,C_fix(1),t3);}
else{
t7=(C_word)C_u_fixnum_difference(t3,C_fix(1));
t8=(C_word)C_subchar(t2,t7);
t9=f_6977(t8);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7034,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t11=(C_word)C_u_fixnum_difference(t3,C_fix(1));
/* eval.scm: 1320 ##sys#substring */
t12=*((C_word*)lf[239]+1);
((C_proc5)(void*)(*((C_word*)t12+1)))(5,t12,t10,t2,C_fix(0),t11);}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,t2);}}}}

/* k7032 in check in k6988 in ##sys#canonicalize-extension-path in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_7034(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1320 check */
t2=((C_word*)((C_word*)t0)[3])[1];
f_6995(t2,((C_word*)t0)[2],t1);}

/* k7019 in check in k6988 in ##sys#canonicalize-extension-path in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_7021(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1318 check */
t2=((C_word*)((C_word*)t0)[3])[1];
f_6995(t2,((C_word*)t0)[2],t1);}

/* sep? in ##sys#canonicalize-extension-path in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static C_word C_fcall f_6977(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
t2=(C_word)C_eqp(C_make_character(92),t1);
return((C_truep(t2)?t2:(C_word)C_eqp(C_make_character(47),t1)));}

/* err in ##sys#canonicalize-extension-path in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_fcall f_6971(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6971,NULL,2,t0,t1);}
/* eval.scm: 1297 ##sys#error */
t2=*((C_word*)lf[144]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[3],lf[274],((C_word*)t0)[2]);}

/* ##sys#split-at-separator in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_6912(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6912,4,t0,t1,t2,t3);}
t4=(C_word)C_block_size(t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6921,a[2]=t6,a[3]=t3,a[4]=t2,a[5]=((C_word*)t0)[2],a[6]=t4,tmp=(C_word)a,a+=7,tmp));
t8=((C_word*)t6)[1];
f_6921(t8,t1,C_SCHEME_END_OF_LIST,C_fix(0),C_fix(0));}

/* loop in ##sys#split-at-separator in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_fcall f_6921(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
loop:
a=C_alloc(11);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_6921,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[6]))){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6939,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1285 ##sys#substring */
t6=*((C_word*)lf[239]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,((C_word*)t0)[4],t4,((C_word*)t0)[6]);}
else{
t5=(C_word)C_eqp((C_word)C_subchar(((C_word*)t0)[4],t3),((C_word*)t0)[3]);
if(C_truep(t5)){
t6=(C_word)C_u_fixnum_plus(t3,C_fix(1));
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6959,a[2]=t6,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1288 ##sys#substring */
t8=*((C_word*)lf[239]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t7,((C_word*)t0)[4],t4,t3);}
else{
t6=(C_word)C_u_fixnum_plus(t3,C_fix(1));
/* eval.scm: 1289 loop */
t11=t1;
t12=t2;
t13=t6;
t14=t4;
t1=t11;
t2=t12;
t3=t13;
t4=t14;
goto loop;}}}

/* k6957 in loop in ##sys#split-at-separator in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_6959(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6959,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
/* eval.scm: 1288 loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_6921(t3,((C_word*)t0)[3],t2,((C_word*)t0)[2],((C_word*)t0)[2]);}

/* k6937 in loop in ##sys#split-at-separator in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_6939(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6939,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[4]);
/* eval.scm: 1285 reverse */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t2);}

/* load-library in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_6883(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3rv,(void*)f_6883r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_6883r(t0,t1,t2,t3);}}

static void C_ccall f_6883r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(4);
t4=(C_word)C_i_check_symbol_2(t2,lf[270]);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6890,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_notvemptyp(t3);
t7=(C_truep(t6)?(C_word)C_slot(t3,C_fix(0)):C_SCHEME_FALSE);
/* eval.scm: 1276 ##sys#load-library */
t8=*((C_word*)lf[263]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t5,t2,t7);}

/* k6888 in load-library in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_6890(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6890,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6900,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* ##sys#peek-c-string */
t3=*((C_word*)lf[35]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_dlerror),C_fix(0));}}

/* k6898 in k6888 in load-library in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_6900(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1277 ##sys#error */
t2=*((C_word*)lf[144]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[270],lf[271],((C_word*)t0)[2],t1);}

/* ##sys#load-library in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_6777(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6777,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6781,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t2,a[7]=((C_word*)t0)[5],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
/* eval.scm: 1249 ##sys#->feature-id */
t5=*((C_word*)lf[269]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k6779 in ##sys#load-library in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_6781(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6781,2,t0,t1);}
t2=(C_word)C_u_i_memq(t1,*((C_word*)lf[185]+1));
if(C_truep(t2)){
t3=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6790,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[3])){
t4=t3;
f_6790(t4,(C_word)C_a_i_list(&a,1,((C_word*)t0)[3]));}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6873,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
/* eval.scm: 1254 ##sys#string-append */
t6=*((C_word*)lf[32]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,*((C_word*)lf[259]+1));}}}

/* k6871 in k6779 in ##sys#load-library in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_6873(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6873,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6877,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1255 dynamic-load-libraries */
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k6875 in k6871 in k6779 in ##sys#load-library in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_6877(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6877,2,t0,t1);}
t2=((C_word*)t0)[3];
f_6790(t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k6788 in k6779 in ##sys#load-library in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_fcall f_6790(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6790,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6793,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6855,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6859,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* eval.scm: 1260 ##sys#string->c-identifier */
t6=*((C_word*)lf[268]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}

/* k6857 in k6788 in k6779 in ##sys#load-library in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_6859(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1258 string-append */
t2=((C_word*)t0)[3];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[266],t1,lf[267]);}

/* k6853 in k6788 in k6779 in ##sys#load-library in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_6855(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1257 ##sys#make-c-string */
t2=*((C_word*)lf[242]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k6791 in k6788 in k6779 in ##sys#load-library in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_6793(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6793,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6796,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t1,a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6842,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1262 load-verbose */
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6840 in k6791 in k6788 in k6779 in ##sys#load-library in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_6842(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6842,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6845,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1263 display */
t3=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[265]);}
else{
t2=((C_word*)t0)[3];
f_6796(2,t2,C_SCHEME_UNDEFINED);}}

/* k6843 in k6840 in k6791 in k6788 in k6779 in ##sys#load-library in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_6845(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6845,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6848,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1264 display */
t3=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k6846 in k6843 in k6840 in k6791 in k6788 in k6779 in ##sys#load-library in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_6848(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1265 display */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],lf[264]);}

/* k6794 in k6791 in k6788 in k6779 in ##sys#load-library in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_6796(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6796,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6801,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_6801(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop in k6794 in k6791 in k6788 in k6779 in ##sys#load-library in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_fcall f_6801(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6801,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6814,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6835,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 1268 ##sys#make-c-string */
t6=*((C_word*)lf[242]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}}

/* k6833 in loop in k6794 in k6791 in k6788 in k6779 in ##sys#load-library in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_6835(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1268 ##sys#dload */
t2=*((C_word*)lf[241]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k6812 in loop in k6794 in k6791 in k6788 in k6779 in ##sys#load-library in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_6814(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6814,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6817,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_u_i_memq(((C_word*)t0)[4],*((C_word*)lf[185]+1)))){
t3=t2;
f_6817(t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],*((C_word*)lf[185]+1));
t4=C_mutate((C_word*)lf[185]+1,t3);
t5=t2;
f_6817(t5,t4);}}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* eval.scm: 1271 loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_6801(t3,((C_word*)t0)[5],t2);}}

/* k6815 in k6812 in loop in k6794 in k6791 in k6788 in k6779 in ##sys#load-library in k6773 in k6766 in k6761 in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_fcall f_6817(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* load-noisily in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_6737(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3r,(void*)f_6737r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6737r(t0,t1,t2,t3);}}

static void C_ccall f_6737r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(7);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6741,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6758,tmp=(C_word)a,a+=2,tmp);
/* ##sys#get-keyword */
t6=*((C_word*)lf[91]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t4,lf[258],t3,t5);}

/* a6757 in load-noisily in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_6758(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6758,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* k6739 in load-noisily in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_6741(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6741,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6744,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6755,tmp=(C_word)a,a+=2,tmp);
/* ##sys#get-keyword */
t4=*((C_word*)lf[91]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,lf[257],((C_word*)t0)[2],t3);}

/* a6754 in k6739 in load-noisily in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_6755(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6755,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* k6742 in k6739 in load-noisily in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_6744(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6744,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6747,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6752,tmp=(C_word)a,a+=2,tmp);
/* ##sys#get-keyword */
t4=*((C_word*)lf[91]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,lf[256],((C_word*)t0)[2],t3);}

/* a6751 in k6742 in k6739 in load-noisily in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_6752(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6752,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* k6745 in k6742 in k6739 in load-noisily in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_6747(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1220 ##sys#load */
t2=*((C_word*)lf[229]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],C_SCHEME_TRUE,((C_word*)t0)[2],t1);}

/* load-relative in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_6701(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_6701r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6701r(t0,t1,t2,t3);}}

static void C_ccall f_6701r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6709,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_subchar(t2,C_fix(0));
if(C_truep((C_truep((C_word)C_eqp(t5,C_make_character(92)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t5,C_make_character(47)))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
t6=t4;
f_6709(2,t6,t2);}
else{
/* eval.scm: 1216 ##sys#string-append */
t6=*((C_word*)lf[32]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,*((C_word*)lf[215]+1),t2);}}

/* k6707 in load-relative in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_6709(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=((C_word*)t0)[3];
t3=(C_word)C_i_nullp(t2);
t4=(C_truep(t3)?C_SCHEME_FALSE:(C_word)C_u_i_car(t2));
/* eval.scm: 1213 ##sys#load */
t5=*((C_word*)lf[229]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,((C_word*)t0)[2],t1,t4,C_SCHEME_FALSE);}

/* load in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_6679(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3rv,(void*)f_6679r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_6679r(t0,t1,t2,t3);}}

static void C_ccall f_6679r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
t4=(C_word)C_vemptyp(t3);
t5=(C_truep(t4)?C_SCHEME_FALSE:(C_word)C_slot(t3,C_fix(0)));
/* eval.scm: 1210 ##sys#load */
t6=*((C_word*)lf[229]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t1,t2,t5,C_SCHEME_FALSE);}

/* ##sys#load in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_6292(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+23)){
C_save_and_reclaim((void*)tr5r,(void*)f_6292r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_6292r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_6292r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(23);
t6=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_6294,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t6,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=t4,a[12]=((C_word*)t0)[10],a[13]=((C_word*)t0)[11],a[14]=t3,tmp=(C_word)a,a+=15,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6629,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6634,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t5))){
/* def-timer748826 */
t10=t9;
f_6634(t10,t1);}
else{
t10=(C_word)C_u_i_car(t5);
t11=(C_word)C_slot(t5,C_fix(1));
if(C_truep((C_word)C_i_nullp(t11))){
/* def-printer749824 */
t12=t8;
f_6629(t12,t1,t10);}
else{
t12=(C_word)C_u_i_car(t11);
t13=(C_word)C_slot(t11,C_fix(1));
/* body746751 */
t14=t7;
f_6294(t14,t1,t10,t12);}}}

/* def-timer748 in ##sys#load in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_fcall f_6634(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6634,NULL,2,t0,t1);}
/* def-printer749824 */
t2=((C_word*)t0)[2];
f_6629(t2,t1,C_SCHEME_FALSE);}

/* def-printer749 in ##sys#load in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_fcall f_6629(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6629,NULL,3,t0,t1,t2);}
/* body746751 */
t3=((C_word*)t0)[2];
f_6294(t3,t1,t2,C_SCHEME_FALSE);}

/* body746 in ##sys#load in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_fcall f_6294(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[22],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6294,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_6298,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t3,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=t2,a[14]=((C_word*)t0)[12],a[15]=t1,a[16]=((C_word*)t0)[13],a[17]=((C_word*)t0)[14],tmp=(C_word)a,a+=18,tmp);
if(C_truep((C_word)C_i_stringp(((C_word*)((C_word*)t0)[6])[1]))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6628,a[2]=t4,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1145 ##sys#expand-home-path */
t6=*((C_word*)lf[253]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)((C_word*)t0)[6])[1]);}
else{
t5=t4;
f_6298(t5,C_SCHEME_UNDEFINED);}}

/* k6626 in body746 in ##sys#load in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_6628(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_6298(t3,t2);}

/* k6296 in body746 in ##sys#load in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_fcall f_6298(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[25],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6298,NULL,2,t0,t1);}
t2=C_SCHEME_FALSE;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_6301,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],tmp=(C_word)a,a+=18,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6562,a[2]=t3,a[3]=((C_word*)t0)[6],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1148 port? */
t6=*((C_word*)lf[252]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)((C_word*)t0)[6])[1]);}

/* k6560 in k6296 in body746 in ##sys#load in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_6562(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6562,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_6301(2,t2,C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_i_stringp(((C_word*)((C_word*)t0)[3])[1]))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6577,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1150 ##sys#file-info */
t3=*((C_word*)lf[248]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)((C_word*)t0)[3])[1]);}
else{
t2=((C_word*)((C_word*)t0)[3])[1];
/* eval.scm: 1141 ##sys#signal-hook */
t3=*((C_word*)lf[223]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,((C_word*)t0)[4],lf[250],lf[235],lf[251],t2);}}}

/* k6575 in k6560 in k6296 in body746 in ##sys#load in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_6577(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6577,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6580,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=(C_word)C_slot(t1,C_fix(4));
if(C_truep(t3)){
t4=(C_word)C_eqp(C_fix(1),t3);
t5=C_mutate(((C_word *)((C_word*)t0)[2])+1,t4);
t6=t2;
f_6580(t6,(C_word)C_i_not(t3));}
else{
t4=t2;
f_6580(t4,C_SCHEME_FALSE);}}
else{
t3=t2;
f_6580(t3,C_SCHEME_FALSE);}}

/* k6578 in k6575 in k6560 in k6296 in body746 in ##sys#load in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_fcall f_6580(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6580,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_6301(2,t2,((C_word*)((C_word*)t0)[3])[1]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6583,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1156 ##sys#string-append */
t3=*((C_word*)lf[32]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)((C_word*)t0)[3])[1],*((C_word*)lf[249]+1));}}

/* k6581 in k6578 in k6575 in k6560 in k6296 in body746 in ##sys#load in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_6583(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6583,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6589,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1157 ##sys#file-info */
t3=*((C_word*)lf[248]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}

/* k6587 in k6581 in k6578 in k6575 in k6560 in k6296 in body746 in ##sys#load in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_6589(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6589,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
f_6301(2,t2,((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6592,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1159 ##sys#string-append */
t3=*((C_word*)lf[32]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)((C_word*)t0)[2])[1],lf[17]);}}

/* k6590 in k6587 in k6581 in k6578 in k6575 in k6560 in k6296 in body746 in ##sys#load in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_6592(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6592,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6598,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1160 ##sys#file-info */
t3=*((C_word*)lf[248]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}

/* k6596 in k6590 in k6587 in k6581 in k6578 in k6575 in k6560 in k6296 in body746 in ##sys#load in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_6598(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
f_6301(2,t2,((C_word*)t0)[4]);}
else{
t2=((C_word*)((C_word*)t0)[3])[1];
t3=((C_word*)t0)[5];
f_6301(2,t3,(C_truep(t2)?C_SCHEME_FALSE:((C_word*)((C_word*)t0)[2])[1]));}}

/* k6299 in k6296 in body746 in ##sys#load in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_6301(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[21],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6301,2,t0,t1);}
t2=((C_word*)t0)[17];
t3=(C_truep(t2)?t2:((C_word*)t0)[16]);
t4=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_6307,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=t3,a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=t1,a[15]=((C_word*)t0)[15],tmp=(C_word)a,a+=16,tmp);
t5=(C_word)C_i_stringp(((C_word*)((C_word*)t0)[6])[1]);
t6=(C_truep(t5)?(C_word)C_i_not(t1):C_SCHEME_FALSE);
if(C_truep(t6)){
/* eval.scm: 1165 ##sys#signal-hook */
t7=*((C_word*)lf[223]+1);
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t4,lf[244],lf[235],lf[245],((C_word*)((C_word*)t0)[6])[1]);}
else{
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6553,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1166 load-verbose */
t8=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}}

/* k6551 in k6299 in k6296 in body746 in ##sys#load in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_6553(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6553,2,t0,t1);}
t2=(C_truep(t1)?((C_word*)t0)[4]:C_SCHEME_FALSE);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6544,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1167 display */
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[247]);}
else{
t3=((C_word*)t0)[2];
f_6307(2,t3,C_SCHEME_UNDEFINED);}}

/* k6542 in k6551 in k6299 in k6296 in body746 in ##sys#load in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_6544(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6544,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6547,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1168 display */
t3=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k6545 in k6542 in k6551 in k6299 in k6296 in body746 in ##sys#load in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_6547(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1169 display */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],lf[246]);}

/* k6305 in k6299 in k6296 in body746 in ##sys#load in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_6307(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[25],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6307,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_6310,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],tmp=(C_word)a,a+=15,tmp);
if(C_truep(((C_word*)t0)[14])){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6501,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[14],a[4]=((C_word*)t0)[2],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6529,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1171 ##sys#make-c-string */
t5=*((C_word*)lf[242]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[14]);}
else{
t3=t2;
f_6310(2,t3,C_SCHEME_FALSE);}}

/* k6527 in k6305 in k6299 in k6296 in body746 in ##sys#load in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_6529(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1171 ##sys#dload */
t2=*((C_word*)lf[241]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2],C_SCHEME_TRUE);}

/* k6499 in k6305 in k6299 in k6296 in body746 in ##sys#load in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_6501(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6501,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
f_6310(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6525,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1172 has-sep? */
f_6246(t2,((C_word*)t0)[3]);}}

/* k6523 in k6499 in k6305 in k6299 in k6296 in body746 in ##sys#load in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_6525(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6525,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_6310(2,t2,C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6517,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6521,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1173 ##sys#string-append */
t4=*((C_word*)lf[32]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,lf[243],((C_word*)t0)[2]);}}

/* k6519 in k6523 in k6499 in k6305 in k6299 in k6296 in body746 in ##sys#load in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_6521(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1173 ##sys#make-c-string */
t2=*((C_word*)lf[242]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k6515 in k6523 in k6499 in k6305 in k6299 in k6296 in body746 in ##sys#load in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_6517(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1173 ##sys#dload */
t2=*((C_word*)lf[241]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2],C_SCHEME_TRUE);}

/* k6308 in k6305 in k6299 in k6296 in body746 in ##sys#load in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_6310(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6310,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6313,a[2]=((C_word*)t0)[14],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
t3=t2;
f_6313(2,t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_6318,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
/* eval.scm: 1174 call-with-current-continuation */
t4=*((C_word*)lf[55]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}}

/* a6317 in k6308 in k6305 in k6299 in k6296 in body746 in ##sys#load in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_6318(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[25],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6318,3,t0,t1,t2);}
t3=C_SCHEME_TRUE;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=((C_word*)t0)[13];
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_6322,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[13],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=t6,a[15]=t4,a[16]=t2,tmp=(C_word)a,a+=17,tmp);
if(C_truep(((C_word*)t0)[13])){
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6488,a[2]=((C_word*)t0)[13],a[3]=t7,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1180 has-sep? */
f_6246(t8,((C_word*)t0)[13]);}
else{
t8=t7;
f_6322(2,t8,C_SCHEME_FALSE);}}

/* k6486 in a6317 in k6308 in k6305 in k6299 in k6296 in body746 in ##sys#load in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_6488(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_u_fixnum_plus(t1,C_fix(1));
/* eval.scm: 1181 ##sys#substring */
t3=*((C_word*)lf[239]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0),t2);}
else{
t2=((C_word*)t0)[3];
f_6322(2,t2,lf[240]);}}

/* k6320 in a6317 in k6308 in k6305 in k6299 in k6296 in body746 in ##sys#load in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_6322(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[48],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6322,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6323,a[2]=((C_word*)t0)[16],tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_FALSE;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_SCHEME_FALSE;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_SCHEME_FALSE;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6332,a[2]=t5,a[3]=t3,a[4]=((C_word*)t0)[14],a[5]=((C_word*)t0)[15],a[6]=t13,a[7]=t11,a[8]=t9,a[9]=t7,tmp=(C_word)a,a+=10,tmp);
t15=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_6346,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],tmp=(C_word)a,a+=13,tmp);
t16=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6473,a[2]=t13,a[3]=t11,a[4]=t9,a[5]=t7,a[6]=t5,a[7]=t3,a[8]=((C_word*)t0)[14],a[9]=((C_word*)t0)[15],tmp=(C_word)a,a+=10,tmp);
/* ##sys#dynamic-wind */
t17=*((C_word*)lf[238]+1);
((C_proc5)(void*)(*((C_word*)t17+1)))(5,t17,((C_word*)t0)[2],t14,t15,t16);}

/* a6472 in k6320 in a6317 in k6308 in k6305 in k6299 in k6296 in body746 in ##sys#load in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_6473(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6473,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[9])+1,*((C_word*)lf[230]+1));
t3=C_mutate(((C_word *)((C_word*)t0)[8])+1,*((C_word*)lf[214]+1));
t4=C_mutate(((C_word *)((C_word*)t0)[7])+1,*((C_word*)lf[215]+1));
t5=C_mutate(((C_word *)((C_word*)t0)[6])+1,*((C_word*)lf[213]+1));
t6=C_mutate((C_word*)lf[230]+1,((C_word*)((C_word*)t0)[5])[1]);
t7=C_mutate((C_word*)lf[214]+1,((C_word*)((C_word*)t0)[4])[1]);
t8=C_mutate((C_word*)lf[215]+1,((C_word*)((C_word*)t0)[3])[1]);
t9=C_mutate((C_word*)lf[213]+1,((C_word*)((C_word*)t0)[2])[1]);
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,*((C_word*)lf[231]+1));}

/* a6345 in k6320 in a6317 in k6308 in k6305 in k6299 in k6296 in body746 in ##sys#load in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_6346(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6346,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6350,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],tmp=(C_word)a,a+=12,tmp);
if(C_truep(((C_word*)t0)[5])){
/* eval.scm: 1183 open-input-file */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}
else{
t3=t2;
f_6350(2,t3,((C_word*)((C_word*)t0)[2])[1]);}}

/* k6348 in a6345 in k6320 in a6317 in k6308 in k6305 in k6299 in k6296 in body746 in ##sys#load in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_6350(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6350,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6355,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6358,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=t1,a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6464,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1184 ##sys#dynamic-wind */
t5=*((C_word*)lf[238]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,((C_word*)t0)[2],t2,t3,t4);}

/* a6463 in k6348 in a6345 in k6320 in a6317 in k6308 in k6305 in k6299 in k6296 in body746 in ##sys#load in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_6464(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6464,2,t0,t1);}
/* eval.scm: 1206 close-input-port */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* a6357 in k6348 in a6345 in k6320 in a6317 in k6308 in k6305 in k6299 in k6296 in body746 in ##sys#load in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_6358(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6358,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6362,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* eval.scm: 1187 peek-char */
t3=*((C_word*)lf[237]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[9]);}

/* k6360 in a6357 in k6348 in a6345 in k6320 in a6317 in k6308 in k6305 in k6299 in k6296 in body746 in ##sys#load in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_6362(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6362,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6365,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
t3=(C_word)C_eqp(t1,C_make_character(127));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6458,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* ##sys#peek-c-string */
t5=*((C_word*)lf[35]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_dlerror),C_fix(0));}
else{
t4=t2;
f_6365(2,t4,C_SCHEME_UNDEFINED);}}

/* k6456 in k6360 in a6357 in k6348 in a6345 in k6320 in a6317 in k6308 in k6305 in k6299 in k6296 in body746 in ##sys#load in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_6458(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1189 ##sys#error */
t2=*((C_word*)lf[144]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[235],lf[236],((C_word*)t0)[2],t1);}

/* k6363 in k6360 in a6357 in k6348 in a6345 in k6320 in a6317 in k6308 in k6305 in k6299 in k6296 in body746 in ##sys#load in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_6365(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6365,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6368,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
/* eval.scm: 1190 read */
t3=((C_word*)t0)[10];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[9]);}

/* k6366 in k6363 in k6360 in a6357 in k6348 in a6345 in k6320 in a6317 in k6308 in k6305 in k6299 in k6296 in body746 in ##sys#load in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_6368(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6368,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6373,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=t3,tmp=(C_word)a,a+=11,tmp));
t5=((C_word*)t3)[1];
f_6373(t5,((C_word*)t0)[2],t1);}

/* do799 in k6366 in k6363 in k6360 in a6357 in k6348 in a6345 in k6320 in a6317 in k6308 in k6305 in k6299 in k6296 in body746 in ##sys#load in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_fcall f_6373(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6373,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_eofp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6383,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t1,a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
if(C_truep(((C_word*)t0)[2])){
/* eval.scm: 1193 printer */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}
else{
t4=t3;
f_6383(2,t4,C_SCHEME_UNDEFINED);}}}

/* k6381 in do799 in k6366 in k6363 in k6360 in a6357 in k6348 in a6345 in k6320 in a6317 in k6308 in k6305 in k6299 in k6296 in body746 in ##sys#load in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_6383(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6383,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6386,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[11],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6395,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6429,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1194 ##sys#call-with-values */
C_u_call_with_values(4,0,t2,t3,t4);}

/* a6428 in k6381 in do799 in k6366 in k6363 in k6360 in a6357 in k6348 in a6345 in k6320 in a6317 in k6308 in k6305 in k6299 in k6296 in body746 in ##sys#load in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_6429(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_6429r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_6429r(t0,t1,t2);}}

static void C_ccall f_6429r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
if(C_truep(((C_word*)t0)[4])){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6438,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t4=*((C_word*)lf[123]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t3,t2);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* a6437 in a6428 in k6381 in do799 in k6366 in k6363 in k6360 in a6357 in k6348 in a6345 in k6320 in a6317 in k6308 in k6305 in k6299 in k6296 in body746 in ##sys#load in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_6438(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6438,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6442,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1203 write */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k6440 in a6437 in a6428 in k6381 in do799 in k6366 in k6363 in k6360 in a6357 in k6348 in a6345 in k6320 in a6317 in k6308 in k6305 in k6299 in k6296 in body746 in ##sys#load in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_6442(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1204 newline */
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* a6394 in k6381 in do799 in k6366 in k6363 in k6360 in a6357 in k6348 in a6345 in k6320 in a6317 in k6308 in k6305 in k6299 in k6296 in body746 in ##sys#load in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_6395(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6395,2,t0,t1);}
if(C_truep(((C_word*)t0)[4])){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6402,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1197 ##sys#start-timer */
t3=*((C_word*)lf[234]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
/* eval.scm: 1198 evproc */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}}

/* k6400 in a6394 in k6381 in do799 in k6366 in k6363 in k6360 in a6357 in k6348 in a6345 in k6320 in a6317 in k6308 in k6305 in k6299 in k6296 in body746 in ##sys#load in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_6402(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6402,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6407,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6413,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 1197 ##sys#call-with-values */
C_u_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a6412 in k6400 in a6394 in k6381 in do799 in k6366 in k6363 in k6360 in a6357 in k6348 in a6345 in k6320 in a6317 in k6308 in k6305 in k6299 in k6296 in body746 in ##sys#load in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_6413(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr2r,(void*)f_6413r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_6413r(t0,t1,t2);}}

static void C_ccall f_6413r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(7);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6417,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6424,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1197 ##sys#stop-timer */
t5=*((C_word*)lf[233]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* k6422 in a6412 in k6400 in a6394 in k6381 in do799 in k6366 in k6363 in k6360 in a6357 in k6348 in a6345 in k6320 in a6317 in k6308 in k6305 in k6299 in k6296 in body746 in ##sys#load in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_6424(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1197 ##sys#display-times */
t2=*((C_word*)lf[232]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k6415 in a6412 in k6400 in a6394 in k6381 in do799 in k6366 in k6363 in k6360 in a6357 in k6348 in a6345 in k6320 in a6317 in k6308 in k6305 in k6299 in k6296 in body746 in ##sys#load in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_6417(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a6406 in k6400 in a6394 in k6381 in do799 in k6366 in k6363 in k6360 in a6357 in k6348 in a6345 in k6320 in a6317 in k6308 in k6305 in k6299 in k6296 in body746 in ##sys#load in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_6407(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6407,2,t0,t1);}
/* eval.scm: 1197 evproc */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* k6384 in k6381 in do799 in k6366 in k6363 in k6360 in a6357 in k6348 in a6345 in k6320 in a6317 in k6308 in k6305 in k6299 in k6296 in body746 in ##sys#load in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_6386(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6386,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6393,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1191 read */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k6391 in k6384 in k6381 in do799 in k6366 in k6363 in k6360 in a6357 in k6348 in a6345 in k6320 in a6317 in k6308 in k6305 in k6299 in k6296 in body746 in ##sys#load in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_6393(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[3])[1];
f_6373(t2,((C_word*)t0)[2],t1);}

/* a6354 in k6348 in a6345 in k6320 in a6317 in k6308 in k6305 in k6299 in k6296 in body746 in ##sys#load in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_6355(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6355,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* a6331 in k6320 in a6317 in k6308 in k6305 in k6299 in k6296 in body746 in ##sys#load in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_6332(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6332,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[9])+1,*((C_word*)lf[230]+1));
t3=C_mutate(((C_word *)((C_word*)t0)[8])+1,*((C_word*)lf[214]+1));
t4=C_mutate(((C_word *)((C_word*)t0)[7])+1,*((C_word*)lf[215]+1));
t5=C_mutate(((C_word *)((C_word*)t0)[6])+1,*((C_word*)lf[213]+1));
t6=C_mutate((C_word*)lf[230]+1,((C_word*)((C_word*)t0)[5])[1]);
t7=C_mutate((C_word*)lf[214]+1,((C_word*)((C_word*)t0)[4])[1]);
t8=C_mutate((C_word*)lf[215]+1,((C_word*)((C_word*)t0)[3])[1]);
t9=C_mutate((C_word*)lf[213]+1,((C_word*)((C_word*)t0)[2])[1]);
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,*((C_word*)lf[231]+1));}

/* f_6323 in k6320 in a6317 in k6308 in k6305 in k6299 in k6296 in body746 in ##sys#load in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_6323(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6323,2,t0,t1);}
/* eval.scm: 1182 abrt */
t2=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,C_SCHEME_FALSE);}

/* k6311 in k6308 in k6305 in k6299 in k6296 in body746 in ##sys#load in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_6313(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* has-sep? in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_fcall f_6246(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6246,NULL,2,t1,t2);}
t3=(C_word)C_block_size(t2);
t4=(C_word)C_u_fixnum_difference(t3,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6256,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,f_6256(t5,t4));}

/* loop in has-sep? in k6242 in k6162 in k6063 in k1773 in k1731 in k1728 */
static C_word C_fcall f_6256(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
loop:
if(C_truep((C_word)C_i_zerop(t1))){
return(C_SCHEME_FALSE);}
else{
t2=(C_word)C_subchar(((C_word*)t0)[2],t1);
if(C_truep((C_truep((C_word)C_eqp(t2,C_make_character(92)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t2,C_make_character(47)))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
return(t1);}
else{
t3=(C_word)C_u_fixnum_difference(t1,C_fix(1));
t5=t3;
t1=t5;
goto loop;}}}

/* set-dynamic-load-mode! in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_6171(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6171,3,t0,t1,t2);}
t3=(C_word)C_i_pairp(t2);
t4=(C_truep(t3)?t2:(C_word)C_a_i_list(&a,1,t2));
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_TRUE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6178,a[2]=t8,a[3]=t6,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6183,a[2]=t6,a[3]=t8,a[4]=t11,tmp=(C_word)a,a+=5,tmp));
t13=((C_word*)t11)[1];
f_6183(t13,t9,t4);}

/* loop in set-dynamic-load-mode! in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_fcall f_6183(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6183,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6196,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_eqp(t3,lf[219]);
if(C_truep(t5)){
t6=C_set_block_item(((C_word*)t0)[3],0,C_SCHEME_TRUE);
t7=t4;
f_6196(2,t7,t6);}
else{
t6=(C_word)C_eqp(t3,lf[220]);
if(C_truep(t6)){
t7=C_set_block_item(((C_word*)t0)[3],0,C_SCHEME_FALSE);
t8=t4;
f_6196(2,t8,t7);}
else{
t7=(C_word)C_eqp(t3,lf[221]);
if(C_truep(t7)){
t8=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_FALSE);
t9=t4;
f_6196(2,t9,t8);}
else{
t8=(C_word)C_eqp(t3,lf[222]);
if(C_truep(t8)){
t9=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_TRUE);
t10=t4;
f_6196(2,t10,t9);}
else{
t9=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 1120 ##sys#signal-hook */
t10=*((C_word*)lf[223]+1);
((C_proc5)(void*)(*((C_word*)t10+1)))(5,t10,t4,lf[217],lf[224],t9);}}}}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k6194 in loop in set-dynamic-load-mode! in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_6196(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* eval.scm: 1121 loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_6183(t3,((C_word*)t0)[2],t2);}

/* k6176 in set-dynamic-load-mode! in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_6178(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1122 ##sys#set-dlopen-flags! */
t2=*((C_word*)lf[218]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1]);}

/* f_6166 in k6162 in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_6166(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6166,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* ##sys#decompose-lambda-list in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_6082(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6082,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6085,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6095,a[2]=t4,a[3]=t6,a[4]=((C_word*)t0)[2],a[5]=t3,tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_6095(t8,t1,t2,C_SCHEME_END_OF_LIST,C_fix(0));}

/* loop in ##sys#decompose-lambda-list in k6063 in k1773 in k1731 in k1728 */
static void C_fcall f_6095(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a;
loop:
a=C_alloc(17);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_6095,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6109,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1090 reverse */
t7=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t3);}
else{
if(C_truep((C_word)C_blockp(t2))){
if(C_truep((C_word)C_symbolp(t2))){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6128,a[2]=t2,a[3]=t4,a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_a_i_cons(&a,2,t2,t3);
/* eval.scm: 1092 reverse */
t8=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t6,t7);}
else{
if(C_truep((C_word)C_pairp(t2))){
t6=(C_word)C_slot(t2,C_fix(1));
t7=(C_word)C_slot(t2,C_fix(0));
t8=(C_word)C_a_i_cons(&a,2,t7,t3);
t9=(C_word)C_u_fixnum_plus(t4,C_fix(1));
/* eval.scm: 1094 loop */
t14=t1;
t15=t6;
t16=t8;
t17=t9;
t1=t14;
t2=t15;
t3=t16;
t4=t17;
goto loop;}
else{
/* eval.scm: 1093 err */
t6=((C_word*)t0)[2];
f_6085(t6,t1);}}}
else{
/* eval.scm: 1091 err */
t6=((C_word*)t0)[2];
f_6085(t6,t1);}}}

/* k6126 in loop in ##sys#decompose-lambda-list in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_6128(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1092 k */
t2=((C_word*)t0)[5];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k6107 in loop in ##sys#decompose-lambda-list in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_6109(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1090 k */
t2=((C_word*)t0)[4];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* err in ##sys#decompose-lambda-list in k6063 in k1773 in k1731 in k1728 */
static void C_fcall f_6085(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6085,NULL,2,t0,t1);}
t2=C_set_block_item(lf[210],0,C_SCHEME_FALSE);
/* eval.scm: 1087 ##sys#syntax-error-hook */
t3=*((C_word*)lf[56]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,lf[211],((C_word*)t0)[2]);}

/* eval in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_6068(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_6068r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6068r(t0,t1,t2,t3);}}

static void C_ccall f_6068r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6076,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1075 ##sys#eval-handler */
t5=*((C_word*)lf[207]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* k6074 in eval in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_6076(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6076,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6080,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1076 ##sys#interpreter-toplevel-macroexpand-hook */
t3=*((C_word*)lf[73]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k6078 in k6074 in eval in k6063 in k1773 in k1731 in k1728 */
static void C_ccall f_6080(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(5,0,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_3829(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+37)){
C_save_and_reclaim((void*)tr5r,(void*)f_3829r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_3829r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_3829r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word *a=C_alloc(37);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3832,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3874,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3986,a[2]=t7,a[3]=t9,tmp=(C_word)a,a+=4,tmp));
t11=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4039,tmp=(C_word)a,a+=2,tmp);
t12=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4045,tmp=(C_word)a,a+=2,tmp);
t13=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4051,tmp=(C_word)a,a+=2,tmp);
t14=C_SCHEME_UNDEFINED;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_SCHEME_UNDEFINED;
t17=(*a=C_VECTOR_TYPE|1,a[1]=t16,tmp=(C_word)a,a+=2,tmp);
t18=C_set_block_item(t15,0,(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4057,a[2]=t9,a[3]=t13,a[4]=t7,a[5]=t4,a[6]=((C_word*)t0)[2],a[7]=t15,a[8]=t17,a[9]=t12,a[10]=((C_word*)t0)[3],a[11]=t6,tmp=(C_word)a,a+=12,tmp));
t19=C_set_block_item(t17,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5813,a[2]=t15,a[3]=t11,tmp=(C_word)a,a+=4,tmp));
t20=(C_word)C_fixnum_greaterp(*((C_word*)lf[137]+1),C_fix(0));
t21=(C_word)C_i_nullp(t5);
t22=(C_truep(t21)?C_SCHEME_FALSE:(C_word)C_u_i_car(t5));
/* eval.scm: 1054 compile */
t23=((C_word*)t15)[1];
f_4057(t23,t1,t2,t3,C_SCHEME_FALSE,t20,t22);}

/* compile-call in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_fcall f_5813(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5813,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5817,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t5,a[5]=t4,a[6]=((C_word*)t0)[3],a[7]=t1,a[8]=t2,tmp=(C_word)a,a+=9,tmp);
t7=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 1018 compile */
t8=((C_word*)((C_word*)t0)[2])[1];
f_4057(t8,t6,t7,t3,C_SCHEME_FALSE,t4,t5);}

/* k5815 in compile-call in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_5817(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[64],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5817,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5787,tmp=(C_word)a,a+=2,tmp);
t4=f_5787(t2,C_fix(0));
t5=((C_word*)t0)[8];
switch(t4){
case C_SCHEME_FALSE:
/* eval.scm: 1023 ##sys#syntax-error-hook */
t6=*((C_word*)lf[56]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,((C_word*)t0)[7],lf[206],((C_word*)t0)[8]);
case C_fix(0):
t6=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5839,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t5,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp));
case C_fix(1):
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5858,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t5,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t7=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 1027 compile */
t8=((C_word*)((C_word*)t0)[3])[1];
f_4057(t8,t6,t7,((C_word*)t0)[2],C_SCHEME_FALSE,((C_word*)t0)[5],((C_word*)t0)[4]);
case C_fix(2):
t6=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5886,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],a[7]=t5,a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[7],tmp=(C_word)a,a+=11,tmp);
t7=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 1031 compile */
t8=((C_word*)((C_word*)t0)[3])[1];
f_4057(t8,t6,t7,((C_word*)t0)[2],C_SCHEME_FALSE,((C_word*)t0)[5],((C_word*)t0)[4]);
case C_fix(3):
t6=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5921,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],a[7]=t5,a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[7],tmp=(C_word)a,a+=11,tmp);
t7=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 1036 compile */
t8=((C_word*)((C_word*)t0)[3])[1];
f_4057(t8,t6,t7,((C_word*)t0)[2],C_SCHEME_FALSE,((C_word*)t0)[5],((C_word*)t0)[4]);
case C_fix(4):
t6=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5963,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],a[7]=t5,a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[7],tmp=(C_word)a,a+=11,tmp);
t7=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 1042 compile */
t8=((C_word*)((C_word*)t0)[3])[1];
f_4057(t8,t6,t7,((C_word*)t0)[2],C_SCHEME_FALSE,((C_word*)t0)[5],((C_word*)t0)[4]);
default:
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6006,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t5,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6030,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1049 ##sys#map */
t8=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,t7,t2);}}

/* a6029 in k5815 in compile-call in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_6030(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6030,3,t0,t1,t2);}
/* eval.scm: 1049 compile */
t3=((C_word*)((C_word*)t0)[5])[1];
f_4057(t3,t1,t2,((C_word*)t0)[4],C_SCHEME_FALSE,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k6004 in k5815 in compile-call in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_6006(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6006,2,t0,t1);}
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6007,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp));}

/* f_6007 in k6004 in k5815 in compile-call in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_6007(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6007,3,t0,t1,t2);}
t3=f_4039(((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6018,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k6016 */
static void C_ccall f_6018(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6018,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6022,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6024,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1052 ##sys#map */
t4=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a6023 in k6016 */
static void C_ccall f_6024(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6024,3,t0,t1,t2);}
t3=t2;
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,((C_word*)t0)[2]);}

/* k6020 in k6016 */
static void C_ccall f_6022(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k5961 in k5815 in compile-call in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_5963(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5963,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5966,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* eval.scm: 1043 compile */
t3=((C_word*)((C_word*)t0)[4])[1];
f_4057(t3,t2,(C_word)C_u_i_list_ref(((C_word*)t0)[3],C_fix(1)),((C_word*)t0)[2],C_SCHEME_FALSE,((C_word*)t0)[8],((C_word*)t0)[6]);}

/* k5964 in k5961 in k5815 in compile-call in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_5966(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5966,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_5969,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
/* eval.scm: 1044 compile */
t3=((C_word*)((C_word*)t0)[4])[1];
f_4057(t3,t2,(C_word)C_u_i_list_ref(((C_word*)t0)[3],C_fix(2)),((C_word*)t0)[2],C_SCHEME_FALSE,((C_word*)t0)[9],((C_word*)t0)[7]);}

/* k5967 in k5964 in k5961 in k5815 in compile-call in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_5969(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5969,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5972,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t1,a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],tmp=(C_word)a,a+=11,tmp);
/* eval.scm: 1045 compile */
t3=((C_word*)((C_word*)t0)[4])[1];
f_4057(t3,t2,(C_word)C_u_i_list_ref(((C_word*)t0)[3],C_fix(3)),((C_word*)t0)[2],C_SCHEME_FALSE,((C_word*)t0)[10],((C_word*)t0)[8]);}

/* k5970 in k5967 in k5964 in k5961 in k5815 in compile-call in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_5972(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5972,2,t0,t1);}
t2=((C_word*)t0)[10];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5973,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp));}

/* f_5973 in k5970 in k5967 in k5964 in k5961 in k5815 in compile-call in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_5973(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5973,3,t0,t1,t2);}
t3=f_4039(((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5984,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=((C_word*)t0)[6],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k5982 */
static void C_ccall f_5984(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5984,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5988,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}

/* k5986 in k5982 */
static void C_ccall f_5988(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5988,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5992,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[4]);}

/* k5990 in k5986 in k5982 */
static void C_ccall f_5992(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5992,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5996,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* k5994 in k5990 in k5986 in k5982 */
static void C_ccall f_5996(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5996,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5999,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k5997 in k5994 in k5990 in k5986 in k5982 */
static void C_ccall f_5999(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5919 in k5815 in compile-call in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_5921(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5921,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5924,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* eval.scm: 1037 compile */
t3=((C_word*)((C_word*)t0)[4])[1];
f_4057(t3,t2,(C_word)C_u_i_list_ref(((C_word*)t0)[3],C_fix(1)),((C_word*)t0)[2],C_SCHEME_FALSE,((C_word*)t0)[8],((C_word*)t0)[6]);}

/* k5922 in k5919 in k5815 in compile-call in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_5924(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5924,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5927,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
/* eval.scm: 1038 compile */
t3=((C_word*)((C_word*)t0)[4])[1];
f_4057(t3,t2,(C_word)C_u_i_list_ref(((C_word*)t0)[3],C_fix(2)),((C_word*)t0)[2],C_SCHEME_FALSE,((C_word*)t0)[9],((C_word*)t0)[7]);}

/* k5925 in k5922 in k5919 in k5815 in compile-call in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_5927(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5927,2,t0,t1);}
t2=((C_word*)t0)[9];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5928,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp));}

/* f_5928 in k5925 in k5922 in k5919 in k5815 in compile-call in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_5928(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5928,3,t0,t1,t2);}
t3=f_4039(((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5939,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k5937 */
static void C_ccall f_5939(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5939,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5943,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[4]);}

/* k5941 in k5937 */
static void C_ccall f_5943(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5943,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5947,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* k5945 in k5941 in k5937 */
static void C_ccall f_5947(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5947,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5950,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k5948 in k5945 in k5941 in k5937 */
static void C_ccall f_5950(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5884 in k5815 in compile-call in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_5886(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5886,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5889,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
/* eval.scm: 1032 compile */
t3=((C_word*)((C_word*)t0)[4])[1];
f_4057(t3,t2,(C_word)C_u_i_list_ref(((C_word*)t0)[3],C_fix(1)),((C_word*)t0)[2],C_SCHEME_FALSE,((C_word*)t0)[8],((C_word*)t0)[6]);}

/* k5887 in k5884 in k5815 in compile-call in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_5889(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5889,2,t0,t1);}
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5890,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp));}

/* f_5890 in k5887 in k5884 in k5815 in compile-call in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_5890(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5890,3,t0,t1,t2);}
t3=f_4039(((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5901,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k5899 */
static void C_ccall f_5901(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5901,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5905,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* k5903 in k5899 */
static void C_ccall f_5905(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5905,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5908,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k5906 in k5903 in k5899 */
static void C_ccall f_5908(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5856 in k5815 in compile-call in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_5858(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5858,2,t0,t1);}
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5859,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp));}

/* f_5859 in k5856 in k5815 in compile-call in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_5859(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5859,3,t0,t1,t2);}
t3=f_4039(((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5870,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k5868 */
static void C_ccall f_5870(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5870,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5873,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k5871 in k5868 */
static void C_ccall f_5873(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* f_5839 in k5815 in compile-call in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_5839(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5839,3,t0,t1,t2);}
t3=f_4039(((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5849,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1026 fn */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k5847 */
static void C_ccall f_5849(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* loop in k5815 in compile-call in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static C_word C_fcall f_5787(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
loop:
if(C_truep((C_word)C_i_nullp(t1))){
return(t2);}
else{
if(C_truep((C_word)C_i_pairp(t1))){
t3=(C_word)C_slot(t1,C_fix(1));
t4=(C_word)C_u_fixnum_plus(t2,C_fix(1));
t6=t3;
t7=t4;
t1=t6;
t2=t7;
goto loop;}
else{
return(C_SCHEME_FALSE);}}}

/* compile in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_fcall f_4057(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[27],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4057,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
if(C_truep((C_word)C_i_symbolp(t2))){
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4069,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[11],tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4075,a[2]=t2,a[3]=t6,a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 667  ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t7,t8);}
else{
t7=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_4160,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[11],a[8]=t4,a[9]=((C_word*)t0)[7],a[10]=t3,a[11]=((C_word*)t0)[8],a[12]=t6,a[13]=t5,a[14]=((C_word*)t0)[9],a[15]=t1,a[16]=t2,tmp=(C_word)a,a+=17,tmp);
/* eval.scm: 689  ##sys#number? */
t8=*((C_word*)lf[205]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}}

/* k4158 in compile in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_4160(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[32],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4160,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[16];
switch(t2){
case C_fix(-1):
t3=((C_word*)t0)[15];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4167,tmp=(C_word)a,a+=2,tmp));
case C_fix(0):
t3=((C_word*)t0)[15];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4175,tmp=(C_word)a,a+=2,tmp));
case C_fix(1):
t3=((C_word*)t0)[15];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4183,tmp=(C_word)a,a+=2,tmp));
default:
t3=(C_word)C_eqp(t2,C_fix(2));
t4=((C_word*)t0)[15];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4191,tmp=(C_word)a,a+=2,tmp):(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4193,a[2]=((C_word*)t0)[16],tmp=(C_word)a,a+=3,tmp)));}}
else{
if(C_truep((C_word)C_booleanp(((C_word*)t0)[16]))){
t2=((C_word*)t0)[15];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(((C_word*)t0)[16])?(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4204,tmp=(C_word)a,a+=2,tmp):(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4206,tmp=(C_word)a,a+=2,tmp)));}
else{
t2=(C_word)C_charp(((C_word*)t0)[16]);
t3=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_4216,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[15],tmp=(C_word)a,a+=17,tmp);
if(C_truep(t2)){
t4=t3;
f_4216(t4,t2);}
else{
t4=(C_word)C_eofp(((C_word*)t0)[16]);
t5=t3;
f_4216(t5,(C_truep(t4)?t4:(C_word)C_i_stringp(((C_word*)t0)[16])));}}}}

/* k4214 in k4158 in compile in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_fcall f_4216(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[20],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4216,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[16];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4217,a[2]=((C_word*)t0)[15],tmp=(C_word)a,a+=3,tmp));}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[15]))){
t2=(C_word)C_slot(((C_word*)t0)[15],C_fix(0));
if(C_truep((C_word)C_i_symbolp(t2))){
t3=f_4045(((C_word*)t0)[13],((C_word*)t0)[15],((C_word*)t0)[12]);
t4=(C_word)C_slot(((C_word*)t0)[15],C_fix(0));
t5=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_4245,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t4,a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[10],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[11],tmp=(C_word)a,a+=17,tmp);
/* eval.scm: 708  defined? */
t6=((C_word*)t0)[4];
f_3874(t6,t5,t4,((C_word*)t0)[10]);}
else{
t3=f_4045(((C_word*)t0)[13],((C_word*)t0)[15],((C_word*)t0)[12]);
/* eval.scm: 999  compile-call */
t4=((C_word*)((C_word*)t0)[11])[1];
f_5813(t4,((C_word*)t0)[16],((C_word*)t0)[15],((C_word*)t0)[10],((C_word*)t0)[13],((C_word*)t0)[12]);}}
else{
/* eval.scm: 704  ##sys#syntax-error-hook */
t2=*((C_word*)lf[56]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[16],lf[204],((C_word*)t0)[15]);}}}

/* k4243 in k4214 in k4158 in compile in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_4245(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4245,2,t0,t1);}
if(C_truep(t1)){
/* eval.scm: 709  compile-call */
t2=((C_word*)((C_word*)t0)[16])[1];
f_5813(t2,((C_word*)t0)[15],((C_word*)t0)[14],((C_word*)t0)[13],((C_word*)t0)[12],((C_word*)t0)[11]);}
else{
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_4251,a[2]=((C_word*)t0)[16],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[9],a[13]=((C_word*)t0)[15],a[14]=((C_word*)t0)[10],a[15]=((C_word*)t0)[14],tmp=(C_word)a,a+=16,tmp);
/* eval.scm: 710  macroexpand-1-checked */
t3=((C_word*)((C_word*)t0)[2])[1];
f_3986(t3,t2,((C_word*)t0)[14],((C_word*)t0)[13]);}}

/* k4249 in k4243 in k4214 in k4158 in compile in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_4251(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word ab[121],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4251,2,t0,t1);}
t2=(C_word)C_eqp(t1,((C_word*)t0)[15]);
if(C_truep(t2)){
t3=(C_word)C_eqp(((C_word*)t0)[14],lf[90]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4266,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[15],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 715  ##sys#check-syntax */
t5=*((C_word*)lf[64]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t4,lf[90],((C_word*)t0)[15],lf[148],C_SCHEME_FALSE);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[14],lf[149]);
if(C_truep(t4)){
t5=(C_word)C_u_i_cadr(((C_word*)t0)[15]);
if(C_truep(*((C_word*)lf[128]+1))){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4342,a[2]=((C_word*)t0)[13],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 730  ##sys#hash-table-location */
t7=*((C_word*)lf[127]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t6,*((C_word*)lf[128]+1),t5,C_SCHEME_TRUE);}
else{
t6=((C_word*)t0)[13];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4348,a[2]=t5,tmp=(C_word)a,a+=3,tmp));}}
else{
t5=(C_word)C_eqp(((C_word*)t0)[14],lf[150]);
if(C_truep(t5)){
t6=(C_word)C_u_i_cadr(((C_word*)t0)[15]);
/* eval.scm: 735  compile */
t7=((C_word*)((C_word*)t0)[12])[1];
f_4057(t7,((C_word*)t0)[13],t6,((C_word*)t0)[11],((C_word*)t0)[10],((C_word*)t0)[9],((C_word*)t0)[8]);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[14],lf[151]);
if(C_truep(t6)){
t7=(C_word)C_u_i_cadr(((C_word*)t0)[15]);
/* eval.scm: 738  compile */
t8=((C_word*)((C_word*)t0)[12])[1];
f_4057(t8,((C_word*)t0)[13],t7,((C_word*)t0)[11],C_SCHEME_FALSE,((C_word*)t0)[9],((C_word*)t0)[8]);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[14],lf[110]);
if(C_truep(t7)){
t8=((C_word*)t0)[13];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4382,tmp=(C_word)a,a+=2,tmp));}
else{
t8=(C_word)C_eqp(((C_word*)t0)[14],lf[152]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4392,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[15],a[7]=((C_word*)t0)[13],tmp=(C_word)a,a+=8,tmp);
/* eval.scm: 743  ##sys#check-syntax */
t10=*((C_word*)lf[64]+1);
((C_proc6)(void*)(*((C_word*)t10+1)))(6,t10,t9,lf[152],((C_word*)t0)[15],lf[154],C_SCHEME_FALSE);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[14],lf[106]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4449,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[12],a[7]=((C_word*)t0)[15],tmp=(C_word)a,a+=8,tmp);
/* eval.scm: 752  ##sys#check-syntax */
t11=*((C_word*)lf[64]+1);
((C_proc6)(void*)(*((C_word*)t11+1)))(6,t11,t10,lf[106],((C_word*)t0)[15],lf[156],C_SCHEME_FALSE);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[14],lf[69]);
t11=(C_truep(t10)?t10:(C_word)C_eqp(((C_word*)t0)[14],lf[71]));
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4557,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[15],tmp=(C_word)a,a+=9,tmp);
/* eval.scm: 768  ##sys#check-syntax */
t13=*((C_word*)lf[64]+1);
((C_proc6)(void*)(*((C_word*)t13+1)))(6,t13,t12,lf[69],((C_word*)t0)[15],lf[159],C_SCHEME_FALSE);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[14],lf[58]);
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4666,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[12],a[8]=((C_word*)t0)[13],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[15],tmp=(C_word)a,a+=11,tmp);
/* eval.scm: 792  ##sys#check-syntax */
t14=*((C_word*)lf[64]+1);
((C_proc6)(void*)(*((C_word*)t14+1)))(6,t14,t13,lf[58],((C_word*)t0)[15],lf[161],C_SCHEME_FALSE);}
else{
t13=(C_word)C_eqp(((C_word*)t0)[14],lf[92]);
if(C_truep(t13)){
t14=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5004,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[15],tmp=(C_word)a,a+=10,tmp);
/* eval.scm: 842  ##sys#check-syntax */
t15=*((C_word*)lf[64]+1);
((C_proc6)(void*)(*((C_word*)t15+1)))(6,t15,t14,lf[92],((C_word*)t0)[15],lf[166],C_SCHEME_FALSE);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[14],lf[59]);
if(C_truep(t14)){
t15=(C_word)C_slot(((C_word*)t0)[15],C_fix(1));
t16=(C_word)C_a_i_cons(&a,2,lf[92],t15);
/* eval.scm: 936  compile */
t17=((C_word*)((C_word*)t0)[12])[1];
f_4057(t17,((C_word*)t0)[13],t16,((C_word*)t0)[11],C_SCHEME_FALSE,((C_word*)t0)[9],((C_word*)t0)[8]);}
else{
t15=(C_word)C_eqp(((C_word*)t0)[14],lf[167]);
if(C_truep(t15)){
t16=(C_word)C_u_i_cddr(((C_word*)t0)[15]);
t17=(C_word)C_a_i_cons(&a,2,lf[92],t16);
t18=(C_word)C_u_i_cadr(((C_word*)t0)[15]);
/* eval.scm: 939  compile */
t19=((C_word*)((C_word*)t0)[12])[1];
f_4057(t19,((C_word*)t0)[13],t17,((C_word*)t0)[11],t18,((C_word*)t0)[9],((C_word*)t0)[8]);}
else{
t16=(C_word)C_eqp(((C_word*)t0)[14],lf[168]);
if(C_truep(t16)){
t17=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5406,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[12],tmp=(C_word)a,a+=7,tmp);
t18=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5437,tmp=(C_word)a,a+=2,tmp);
t19=(C_word)C_slot(((C_word*)t0)[15],C_fix(1));
/* map */
t20=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t20+1)))(4,t20,t17,t18,t19);}
else{
t17=(C_word)C_eqp(((C_word*)t0)[14],lf[172]);
if(C_truep(t17)){
t18=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5461,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[12],tmp=(C_word)a,a+=7,tmp);
t19=(C_word)C_slot(((C_word*)t0)[15],C_fix(1));
t20=C_SCHEME_UNDEFINED;
t21=(*a=C_VECTOR_TYPE|1,a[1]=t20,tmp=(C_word)a,a+=2,tmp);
t22=C_set_block_item(t21,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5467,a[2]=t21,tmp=(C_word)a,a+=3,tmp));
t23=((C_word*)t21)[1];
f_5467(t23,t18,t19);}
else{
t18=(C_word)C_eqp(((C_word*)t0)[14],lf[175]);
t19=(C_truep(t18)?t18:(C_word)C_eqp(((C_word*)t0)[14],lf[176]));
if(C_truep(t19)){
t20=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5513,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[12],tmp=(C_word)a,a+=7,tmp);
t21=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5519,a[2]=t20,tmp=(C_word)a,a+=3,tmp);
t22=(C_word)C_u_i_cadr(((C_word*)t0)[15]);
/* eval.scm: 961  ##sys#compile-to-closure */
t23=*((C_word*)lf[142]+1);
((C_proc6)(void*)(*((C_word*)t23+1)))(6,t23,t21,t22,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_FALSE);}
else{
t20=(C_word)C_eqp(((C_word*)t0)[14],lf[178]);
if(C_truep(t20)){
t21=(C_word)C_u_i_cadr(((C_word*)t0)[15]);
/* eval.scm: 965  compile */
t22=((C_word*)((C_word*)t0)[12])[1];
f_4057(t22,((C_word*)t0)[13],t21,((C_word*)t0)[11],C_SCHEME_FALSE,((C_word*)t0)[9],((C_word*)t0)[8]);}
else{
t21=(C_word)C_eqp(((C_word*)t0)[14],lf[179]);
t22=(C_truep(t21)?t21:(C_word)C_eqp(((C_word*)t0)[14],lf[180]));
if(C_truep(t22)){
/* eval.scm: 968  compile */
t23=((C_word*)((C_word*)t0)[12])[1];
f_4057(t23,((C_word*)t0)[13],lf[181],((C_word*)t0)[11],C_SCHEME_FALSE,((C_word*)t0)[9],((C_word*)t0)[8]);}
else{
t23=(C_word)C_eqp(((C_word*)t0)[14],lf[182]);
if(C_truep(t23)){
t24=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5557,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[12],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_u_i_memq(lf[184],*((C_word*)lf[185]+1)))){
t25=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5568,tmp=(C_word)a,a+=2,tmp);
t26=(C_word)C_slot(((C_word*)t0)[15],C_fix(1));
/* for-each */
t27=*((C_word*)lf[123]+1);
((C_proc4)(void*)(*((C_word*)t27+1)))(4,t27,t24,t25,t26);}
else{
/* eval.scm: 973  ##sys#warn */
t25=*((C_word*)lf[187]+1);
((C_proc4)(void*)(*((C_word*)t25+1)))(4,t25,t24,lf[188],((C_word*)t0)[15]);}}
else{
t24=(C_word)C_eqp(((C_word*)t0)[14],lf[189]);
t25=(C_truep(t24)?t24:(C_word)C_eqp(((C_word*)t0)[14],lf[190]));
if(C_truep(t25)){
t26=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5607,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[12],a[7]=((C_word*)t0)[15],tmp=(C_word)a,a+=8,tmp);
/* eval.scm: 977  cadadr */
t27=((C_word*)t0)[6];
((C_proc3)(void*)(*((C_word*)t27+1)))(3,t27,t26,((C_word*)t0)[15]);}
else{
t26=(C_word)C_eqp(((C_word*)t0)[14],lf[191]);
t27=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5620,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[14],a[7]=((C_word*)t0)[15],a[8]=((C_word*)t0)[13],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t26)){
t28=t27;
f_5620(t28,t26);}
else{
t28=(C_word)C_eqp(((C_word*)t0)[14],lf[195]);
if(C_truep(t28)){
t29=t27;
f_5620(t29,t28);}
else{
t29=(C_word)C_eqp(((C_word*)t0)[14],lf[196]);
if(C_truep(t29)){
t30=t27;
f_5620(t30,t29);}
else{
t30=(C_word)C_eqp(((C_word*)t0)[14],lf[197]);
if(C_truep(t30)){
t31=t27;
f_5620(t31,t30);}
else{
t31=(C_word)C_eqp(((C_word*)t0)[14],lf[198]);
if(C_truep(t31)){
t32=t27;
f_5620(t32,t31);}
else{
t32=(C_word)C_eqp(((C_word*)t0)[14],lf[199]);
if(C_truep(t32)){
t33=t27;
f_5620(t33,t32);}
else{
t33=(C_word)C_eqp(((C_word*)t0)[14],lf[200]);
if(C_truep(t33)){
t34=t27;
f_5620(t34,t33);}
else{
t34=(C_word)C_eqp(((C_word*)t0)[14],lf[201]);
if(C_truep(t34)){
t35=t27;
f_5620(t35,t34);}
else{
t35=(C_word)C_eqp(((C_word*)t0)[14],lf[202]);
t36=t27;
f_5620(t36,(C_truep(t35)?t35:(C_word)C_eqp(((C_word*)t0)[14],lf[203])));}}}}}}}}}}}}}}}}}}}}}}}}}}}}
else{
/* eval.scm: 995  compile */
t3=((C_word*)((C_word*)t0)[12])[1];
f_4057(t3,((C_word*)t0)[13],t1,((C_word*)t0)[11],((C_word*)t0)[10],((C_word*)t0)[9],((C_word*)t0)[8]);}}

/* k5618 in k4249 in k4243 in k4214 in k4158 in compile in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_fcall f_5620(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_truep(t1)){
/* eval.scm: 984  ##sys#syntax-error-hook */
t2=*((C_word*)lf[56]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[8],lf[192],((C_word*)t0)[7]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[6],lf[61]);
if(C_truep(t2)){
t3=(C_word)C_slot(((C_word*)t0)[7],C_fix(1));
/* eval.scm: 987  compile-call */
t4=((C_word*)((C_word*)t0)[5])[1];
f_5813(t4,((C_word*)t0)[8],t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[6],lf[193]);
if(C_truep(t3)){
/* eval.scm: 991  ##sys#syntax-error-hook */
t4=*((C_word*)lf[56]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[8],lf[194],((C_word*)t0)[7]);}
else{
/* eval.scm: 993  compile-call */
t4=((C_word*)((C_word*)t0)[5])[1];
f_5813(t4,((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}}}}

/* k5605 in k4249 in k4243 in k4214 in k4158 in compile in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_5607(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5607,2,t0,t1);}
t2=(C_word)C_u_i_cddr(((C_word*)t0)[7]);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,lf[69],t3);
/* eval.scm: 977  compile */
t5=((C_word*)((C_word*)t0)[6])[1];
f_4057(t5,((C_word*)t0)[5],t4,((C_word*)t0)[4],C_SCHEME_FALSE,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5567 in k4249 in k4243 in k4214 in k4158 in compile in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_5568(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5568,3,t0,t1,t2);}
t3=(C_word)C_u_i_cadr(t2);
/* eval.scm: 972  ##compiler#process-declaration */
t4=*((C_word*)lf[186]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}

/* k5555 in k4249 in k4243 in k4214 in k4158 in compile in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_5557(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 974  compile */
t2=((C_word*)((C_word*)t0)[6])[1];
f_4057(t2,((C_word*)t0)[5],lf[183],((C_word*)t0)[4],C_SCHEME_FALSE,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5517 in k4249 in k4243 in k4214 in k4158 in compile in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_5519(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k5511 in k4249 in k4243 in k4214 in k4158 in compile in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_5513(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 962  compile */
t2=((C_word*)((C_word*)t0)[6])[1];
f_4057(t2,((C_word*)t0)[5],lf[177],((C_word*)t0)[4],C_SCHEME_FALSE,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop in k4249 in k4243 in k4214 in k4158 in compile in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_fcall f_5467(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5467,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[173]);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5479,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5489,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 956  ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t3,t4);}}

/* a5488 in loop in k4249 in k4243 in k4214 in k4158 in compile in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_5489(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5489,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5497,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* eval.scm: 957  loop */
t6=((C_word*)((C_word*)t0)[2])[1];
f_5467(t6,t4,t5);}

/* k5495 in a5488 in loop in k4249 in k4243 in k4214 in k4158 in compile in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_5497(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5497,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[106],((C_word*)t0)[2],t1));}

/* a5478 in loop in k4249 in k4243 in k4214 in k4158 in compile in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_5479(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5479,2,t0,t1);}
t2=(C_word)C_u_i_cadar(((C_word*)t0)[2]);
/* eval.scm: 956  ##sys#do-the-right-thing */
t3=*((C_word*)lf[174]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,C_SCHEME_FALSE);}

/* k5459 in k4249 in k4243 in k4214 in k4158 in compile in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_5461(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 952  compile */
t2=((C_word*)((C_word*)t0)[6])[1];
f_4057(t2,((C_word*)t0)[5],t1,((C_word*)t0)[4],C_SCHEME_FALSE,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5436 in k4249 in k4243 in k4214 in k4158 in compile in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_5437(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5437,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5444,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 942  ##sys#compile-to-closure */
t4=*((C_word*)lf[142]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,t2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}

/* k5442 in a5436 in k4249 in k4243 in k4214 in k4158 in compile in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_5444(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST,C_SCHEME_FALSE);}

/* k5404 in k4249 in k4243 in k4214 in k4158 in compile in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_5406(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5406,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5409,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
C_apply(4,0,t2,*((C_word*)lf[170]+1),t1);}

/* k5407 in k5404 in k4249 in k4243 in k4214 in k4158 in compile in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_5409(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5409,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5412,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 944  ##sys#lookup-runtime-requirements */
t3=*((C_word*)lf[171]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k5410 in k5407 in k5404 in k4249 in k4243 in k4214 in k4158 in compile in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_5412(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5412,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5419,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_nullp(t1))){
t3=t2;
f_5419(t3,lf[169]);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5429,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5431,tmp=(C_word)a,a+=2,tmp);
/* map */
t5=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,t1);}}

/* a5430 in k5410 in k5407 in k5404 in k4249 in k4243 in k4214 in k4158 in compile in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_5431(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5431,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[90],t2));}

/* k5427 in k5410 in k5407 in k5404 in k4249 in k4243 in k4214 in k4158 in compile in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_5429(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5429,2,t0,t1);}
t2=((C_word*)t0)[2];
f_5419(t2,(C_word)C_a_i_cons(&a,2,lf[170],t1));}

/* k5417 in k5410 in k5407 in k5404 in k4249 in k4243 in k4214 in k4158 in compile in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_fcall f_5419(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 945  compile */
t2=((C_word*)((C_word*)t0)[6])[1];
f_4057(t2,((C_word*)t0)[5],t1,((C_word*)t0)[4],C_SCHEME_FALSE,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5002 in k4249 in k4243 in k4214 in k4158 in compile in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_5004(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[24],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5004,2,t0,t1);}
t2=(C_word)C_u_i_cadr(((C_word*)t0)[9]);
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(C_word)C_u_i_cddr(((C_word*)t0)[9]);
t6=t5;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=((C_word*)t0)[8];
t9=(C_truep(t8)?t8:lf[162]);
t10=(C_word)C_a_i_cons(&a,2,t9,((C_word*)t4)[1]);
t11=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5016,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t7,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[8],a[9]=t10,a[10]=((C_word*)t0)[6],a[11]=((C_word*)t0)[7],tmp=(C_word)a,a+=12,tmp);
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5341,a[2]=t11,a[3]=t7,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 846  ##sys#extended-lambda-list? */
t13=*((C_word*)lf[78]+1);
((C_proc3)(void*)(*((C_word*)t13+1)))(3,t13,t12,((C_word*)t4)[1]);}

/* k5339 in k5002 in k4249 in k4243 in k4214 in k4158 in compile in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_5341(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5341,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5346,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5352,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 847  ##sys#call-with-values */
C_u_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}
else{
t2=((C_word*)t0)[2];
f_5016(2,t2,C_SCHEME_UNDEFINED);}}

/* a5351 in k5339 in k5002 in k4249 in k4243 in k4214 in k4158 in compile in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_5352(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5352,4,t0,t1,t2,t3);}
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t5=C_mutate(((C_word *)((C_word*)t0)[2])+1,t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}

/* a5345 in k5339 in k5002 in k4249 in k4243 in k4214 in k4158 in compile in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_5346(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5346,2,t0,t1);}
/* eval.scm: 849  ##sys#expand-extended-lambda-list */
t2=*((C_word*)lf[84]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1],*((C_word*)lf[56]+1));}

/* k5014 in k5002 in k4249 in k4243 in k4214 in k4158 in compile in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_5016(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5016,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5021,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
/* eval.scm: 852  ##sys#decompose-lambda-list */
t3=*((C_word*)lf[165]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t2);}

/* a5020 in k5014 in k5002 in k4249 in k4243 in k4214 in k4158 in compile in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_5021(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[23],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5021,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[9]);
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5028,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=t4,a[7]=t1,a[8]=t3,tmp=(C_word)a,a+=9,tmp);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5324,a[2]=((C_word*)t0)[4],a[3]=t5,a[4]=t6,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5330,a[2]=t5,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t9=((C_word*)t0)[6];
t10=(C_truep(t9)?t9:((C_word*)t0)[5]);
/* eval.scm: 858  ##sys#canonicalize-body */
t11=*((C_word*)lf[105]+1);
((C_proc6)(void*)(*((C_word*)t11+1)))(6,t11,t7,((C_word*)((C_word*)t0)[2])[1],t8,((C_word*)t0)[4],t10);}

/* a5329 in a5020 in k5014 in k5002 in k4249 in k4243 in k4214 in k4158 in compile in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_5330(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5330,3,t0,t1,t2);}
/* defined?323 */
t3=((C_word*)t0)[3];
f_3874(t3,t1,t2,((C_word*)t0)[2]);}

/* k5322 in a5020 in k5014 in k5002 in k4249 in k4243 in k4214 in k4158 in compile in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_5324(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=((C_word*)t0)[6];
t3=(C_truep(t2)?t2:((C_word*)t0)[5]);
/* eval.scm: 857  ##sys#compile-to-closure */
t4=*((C_word*)lf[142]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* k5026 in a5020 in k5014 in k5002 in k4249 in k4243 in k4214 in k4158 in compile in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_5028(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[86],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5028,2,t0,t1);}
t2=((C_word*)t0)[8];
switch(t2){
case C_fix(0):
t3=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(((C_word*)t0)[6])?(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5038,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp):(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5057,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp)));
case C_fix(1):
t3=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(((C_word*)t0)[6])?(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5081,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp):(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5100,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp)));
case C_fix(2):
t3=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(((C_word*)t0)[6])?(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5128,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp):(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5147,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp)));
case C_fix(3):
t3=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(((C_word*)t0)[6])?(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5175,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp):(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5194,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp)));
default:
t3=(C_word)C_eqp(t2,C_fix(4));
t4=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?(C_truep(((C_word*)t0)[6])?(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5222,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp):(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5241,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp)):(C_truep(((C_word*)t0)[6])?(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5263,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[8],a[7]=t1,tmp=(C_word)a,a+=8,tmp):(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5286,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp))));}}

/* f_5286 in k5026 in a5020 in k5014 in k5002 in k4249 in k4243 in k4214 in k4158 in compile in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_5286(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5286,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5292,a[2]=((C_word*)t0)[6],a[3]=t2,a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 927  decorate */
f_4051(t1,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5291 */
static void C_ccall f_5292(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_5292r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_5292r(t0,t1,t2);}}

static void C_ccall f_5292r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t3=(C_word)C_i_length(t2);
t4=(C_word)C_eqp(t3,((C_word*)t0)[4]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5316,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_apply(4,0,t5,*((C_word*)lf[163]+1),t2);}
else{
/* eval.scm: 931  ##sys#error */
t5=*((C_word*)lf[144]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,lf[164],((C_word*)t0)[4],t3);}}

/* k5314 in a5291 */
static void C_ccall f_5316(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5316,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t2);}

/* f_5263 in k5026 in a5020 in k5014 in k5002 in k4249 in k4243 in k4214 in k4158 in compile in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_5263(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5263,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5269,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 920  decorate */
f_4051(t1,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5268 */
static void C_ccall f_5269(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+17)){
C_save_and_reclaim((void*)tr2r,(void*)f_5269r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_5269r(t0,t1,t2);}}

static void C_ccall f_5269r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a=C_alloc(17);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5281,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5285,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=((C_word*)t0)[2];
if(C_truep((C_word)C_i_nullp(t2))){
t6=t4;
f_5285(2,t6,(C_word)C_a_i_list(&a,1,t2));}
else{
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5754,a[2]=t7,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_5754(t9,t4,t5,t2,C_SCHEME_FALSE);}}

/* do613 in a5268 */
static void C_fcall f_5754(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
loop:
a=C_alloc(3);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5754,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t5)){
t6=(C_word)C_a_i_list(&a,1,t3);
t7=(C_word)C_i_setslot(t4,C_fix(1),t6);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,((C_word*)t0)[3]);}
else{
t6=(C_word)C_u_fixnum_difference(t2,C_fix(1));
t7=(C_word)C_slot(t3,C_fix(1));
t11=t1;
t12=t6;
t13=t7;
t14=t3;
t1=t11;
t2=t12;
t3=t13;
t4=t14;
goto loop;}}

/* k5283 in a5268 */
static void C_ccall f_5285(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],*((C_word*)lf[163]+1),t1);}

/* k5279 in a5268 */
static void C_ccall f_5281(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5281,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t2);}

/* f_5241 in k5026 in a5020 in k5014 in k5002 in k4249 in k4243 in k4214 in k4158 in compile in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_5241(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5241,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5247,a[2]=((C_word*)t0)[6],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 913  decorate */
f_4051(t1,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5246 */
static void C_ccall f_5247(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_5247,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5259,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 915  ##sys#vector */
t7=*((C_word*)lf[163]+1);
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t6,t2,t3,t4,t5);}

/* k5257 in a5246 */
static void C_ccall f_5259(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5259,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t2);}

/* f_5222 in k5026 in a5020 in k5014 in k5002 in k4249 in k4243 in k4214 in k4158 in compile in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_5222(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5222,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5228,a[2]=((C_word*)t0)[6],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 908  decorate */
f_4051(t1,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5227 */
static void C_ccall f_5228(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,...){
C_word tmp;
C_word t6;
va_list v;
C_word *a,c2=c;
C_save_rest(t5,c2,6);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr6r,(void*)f_5228r,6,t0,t1,t2,t3,t4,t5);}
else{
a=C_alloc((c-6)*3);
t6=C_restore_rest(a,C_rest_count(0));
f_5228r(t0,t1,t2,t3,t4,t5,t6);}}

static void C_ccall f_5228r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word *a=C_alloc(9);
t7=(C_word)C_a_i_vector(&a,5,t2,t3,t4,t5,t6);
t8=(C_word)C_a_i_cons(&a,2,t7,((C_word*)t0)[3]);
t9=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t1,t8);}

/* f_5194 in k5026 in a5020 in k5014 in k5002 in k4249 in k4243 in k4214 in k4158 in compile in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_5194(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5194,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5200,a[2]=((C_word*)t0)[6],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 902  decorate */
f_4051(t1,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5199 */
static void C_ccall f_5200(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5200,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_a_i_vector(&a,3,t2,t3,t4);
t6=(C_word)C_a_i_cons(&a,2,t5,((C_word*)t0)[3]);
t7=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t1,t6);}

/* f_5175 in k5026 in a5020 in k5014 in k5002 in k4249 in k4243 in k4214 in k4158 in compile in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_5175(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5175,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5181,a[2]=((C_word*)t0)[6],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 897  decorate */
f_4051(t1,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5180 */
static void C_ccall f_5181(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr5r,(void*)f_5181r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_5181r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_5181r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(8);
t6=(C_word)C_a_i_vector(&a,4,t2,t3,t4,t5);
t7=(C_word)C_a_i_cons(&a,2,t6,((C_word*)t0)[3]);
t8=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t1,t7);}

/* f_5147 in k5026 in a5020 in k5014 in k5002 in k4249 in k4243 in k4214 in k4158 in compile in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_5147(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5147,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5153,a[2]=((C_word*)t0)[6],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 891  decorate */
f_4051(t1,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5152 */
static void C_ccall f_5153(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5153,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_vector(&a,2,t2,t3);
t5=(C_word)C_a_i_cons(&a,2,t4,((C_word*)t0)[3]);
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t1,t5);}

/* f_5128 in k5026 in a5020 in k5014 in k5002 in k4249 in k4243 in k4214 in k4158 in compile in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_5128(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5128,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5134,a[2]=((C_word*)t0)[6],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 886  decorate */
f_4051(t1,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5133 */
static void C_ccall f_5134(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr4r,(void*)f_5134r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5134r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5134r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(7);
t5=(C_word)C_a_i_vector(&a,3,t2,t3,t4);
t6=(C_word)C_a_i_cons(&a,2,t5,((C_word*)t0)[3]);
t7=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t1,t6);}

/* f_5100 in k5026 in a5020 in k5014 in k5002 in k4249 in k4243 in k4214 in k4158 in compile in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_5100(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5100,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5106,a[2]=((C_word*)t0)[6],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 880  decorate */
f_4051(t1,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5105 */
static void C_ccall f_5106(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5106,3,t0,t1,t2);}
t3=(C_word)C_a_i_vector(&a,1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[3]);
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t1,t4);}

/* f_5081 in k5026 in a5020 in k5014 in k5002 in k4249 in k4243 in k4214 in k4158 in compile in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_5081(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5081,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5087,a[2]=((C_word*)t0)[6],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 875  decorate */
f_4051(t1,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5086 */
static void C_ccall f_5087(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr3r,(void*)f_5087r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5087r(t0,t1,t2,t3);}}

static void C_ccall f_5087r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t4=(C_word)C_a_i_vector(&a,2,t2,t3);
t5=(C_word)C_a_i_cons(&a,2,t4,((C_word*)t0)[3]);
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t1,t5);}

/* f_5057 in k5026 in a5020 in k5014 in k5002 in k4249 in k4243 in k4214 in k4158 in compile in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_5057(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5057,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5063,a[2]=((C_word*)t0)[6],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 870  decorate */
f_4051(t1,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5062 */
static void C_ccall f_5063(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5063,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}

/* f_5038 in k5026 in a5020 in k5014 in k5002 in k4249 in k4243 in k4214 in k4158 in compile in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_5038(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5038,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5044,a[2]=((C_word*)t0)[6],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 865  decorate */
f_4051(t1,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5043 */
static void C_ccall f_5044(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_5044r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_5044r(t0,t1,t2);}}

static void C_ccall f_5044r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t3=(C_word)C_a_i_vector(&a,1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[3]);
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t1,t4);}

/* k4664 in k4249 in k4243 in k4214 in k4158 in compile in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_4666(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4666,2,t0,t1);}
t2=(C_word)C_u_i_cadr(((C_word*)t0)[10]);
t3=(C_word)C_i_length(t2);
t4=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4675,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=t2,a[10]=((C_word*)t0)[8],a[11]=t3,a[12]=((C_word*)t0)[9],tmp=(C_word)a,a+=13,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4991,tmp=(C_word)a,a+=2,tmp);
/* map */
t6=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,t2);}

/* a4990 in k4664 in k4249 in k4243 in k4214 in k4158 in compile in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_4991(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4991,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_u_i_car(t2));}

/* k4673 in k4664 in k4249 in k4243 in k4214 in k4158 in compile in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_4675(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[24],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4675,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[12]);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4681,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[8],a[7]=t1,a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4979,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_u_i_cddr(((C_word*)t0)[3]);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4985,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 798  ##sys#canonicalize-body */
t7=*((C_word*)lf[105]+1);
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t4,t5,t6,((C_word*)t0)[4],((C_word*)t0)[6]);}

/* a4984 in k4673 in k4664 in k4249 in k4243 in k4214 in k4158 in compile in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_4985(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4985,3,t0,t1,t2);}
/* defined?323 */
t3=((C_word*)t0)[3];
f_3874(t3,t1,t2,((C_word*)t0)[2]);}

/* k4977 in k4673 in k4664 in k4249 in k4243 in k4214 in k4158 in compile in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_4979(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 797  ##sys#compile-to-closure */
t2=*((C_word*)lf[142]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4679 in k4673 in k4664 in k4249 in k4243 in k4214 in k4158 in compile in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_4681(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[48],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4681,2,t0,t1);}
switch(((C_word*)t0)[10]){
case C_fix(1):
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4690,a[2]=t1,a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_u_i_cadar(((C_word*)t0)[8]);
t4=(C_word)C_u_i_car(((C_word*)t0)[7]);
/* eval.scm: 803  compile */
t5=((C_word*)((C_word*)t0)[6])[1];
f_4057(t5,t2,t3,((C_word*)t0)[5],t4,((C_word*)t0)[4],((C_word*)t0)[3]);
case C_fix(2):
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4724,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=t1,a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t3=(C_word)C_u_i_cadar(((C_word*)t0)[8]);
t4=(C_word)C_u_i_car(((C_word*)t0)[7]);
/* eval.scm: 806  compile */
t5=((C_word*)((C_word*)t0)[6])[1];
f_4057(t5,t2,t3,((C_word*)t0)[5],t4,((C_word*)t0)[4],((C_word*)t0)[3]);
case C_fix(3):
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4773,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp);
t3=(C_word)C_u_i_cadar(((C_word*)t0)[8]);
t4=(C_word)C_u_i_car(((C_word*)t0)[7]);
/* eval.scm: 810  compile */
t5=((C_word*)((C_word*)t0)[6])[1];
f_4057(t5,t2,t3,((C_word*)t0)[5],t4,((C_word*)t0)[4],((C_word*)t0)[3]);
case C_fix(4):
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4840,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp);
t3=(C_word)C_u_i_cadar(((C_word*)t0)[8]);
t4=(C_word)C_u_i_car(((C_word*)t0)[7]);
/* eval.scm: 818  compile */
t5=((C_word*)((C_word*)t0)[6])[1];
f_4057(t5,t2,t3,((C_word*)t0)[5],t4,((C_word*)t0)[4],((C_word*)t0)[3]);
default:
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4916,a[2]=((C_word*)t0)[10],a[3]=t1,a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4963,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* map */
t4=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[8]);}}

/* a4962 in k4679 in k4673 in k4664 in k4249 in k4243 in k4214 in k4158 in compile in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_4963(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4963,3,t0,t1,t2);}
t3=(C_word)C_u_i_cadr(t2);
t4=(C_word)C_u_i_car(t2);
/* eval.scm: 832  compile */
t5=((C_word*)((C_word*)t0)[5])[1];
f_4057(t5,t1,t3,((C_word*)t0)[4],t4,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4914 in k4679 in k4673 in k4664 in k4249 in k4243 in k4214 in k4158 in compile in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_4916(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4916,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4917,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp));}

/* f_4917 in k4914 in k4679 in k4673 in k4664 in k4249 in k4243 in k4214 in k4158 in compile in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_4917(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4917,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4921,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 834  ##sys#make-vector */
t4=*((C_word*)lf[160]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[3]);}

/* k4919 */
static void C_ccall f_4921(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4921,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4924,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4933,a[2]=((C_word*)t0)[6],a[3]=t4,a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_4933(t6,t2,C_fix(0),((C_word*)t0)[2]);}

/* do495 in k4919 */
static void C_fcall f_4933(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4933,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4958,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_slot(t3,C_fix(0));
t6=t5;
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,((C_word*)t0)[2]);}}

/* k4956 in do495 in k4919 */
static void C_ccall f_4958(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[6],((C_word*)t0)[5],t1);
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[5],C_fix(1));
t4=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t5=((C_word*)((C_word*)t0)[3])[1];
f_4933(t5,((C_word*)t0)[2],t3,t4);}

/* k4922 in k4919 */
static void C_ccall f_4924(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4924,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t2);}

/* k4838 in k4679 in k4673 in k4664 in k4249 in k4243 in k4214 in k4158 in compile in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_4840(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[20],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4840,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4843,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4901,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* eval.scm: 819  cadadr */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[10]);}

/* k4899 in k4838 in k4679 in k4673 in k4664 in k4249 in k4243 in k4214 in k4158 in compile in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_4901(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_i_cadr(((C_word*)t0)[7]);
/* eval.scm: 819  compile */
t3=((C_word*)((C_word*)t0)[6])[1];
f_4057(t3,((C_word*)t0)[5],t1,((C_word*)t0)[4],t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4841 in k4838 in k4679 in k4673 in k4664 in k4249 in k4243 in k4214 in k4158 in compile in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_4843(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4843,2,t0,t1);}
t2=(C_word)C_u_i_cddr(((C_word*)t0)[11]);
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4849,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=t1,a[11]=((C_word*)t0)[9],a[12]=((C_word*)t0)[10],tmp=(C_word)a,a+=13,tmp);
t4=(C_word)C_u_i_cadar(t2);
t5=(C_word)C_u_i_caddr(((C_word*)t0)[7]);
/* eval.scm: 821  compile */
t6=((C_word*)((C_word*)t0)[6])[1];
f_4057(t6,t3,t4,((C_word*)t0)[5],t5,((C_word*)t0)[4],((C_word*)t0)[3]);}

/* k4847 in k4841 in k4838 in k4679 in k4673 in k4664 in k4249 in k4243 in k4214 in k4158 in compile in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_4849(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4849,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4852,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=t1,a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[12],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4885,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t2,a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* eval.scm: 822  cadadr */
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k4883 in k4847 in k4841 in k4838 in k4679 in k4673 in k4664 in k4249 in k4243 in k4214 in k4158 in compile in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_4885(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_i_cadddr(((C_word*)t0)[7]);
/* eval.scm: 822  compile */
t3=((C_word*)((C_word*)t0)[6])[1];
f_4057(t3,((C_word*)t0)[5],t1,((C_word*)t0)[4],t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4850 in k4847 in k4841 in k4838 in k4679 in k4673 in k4664 in k4249 in k4243 in k4214 in k4158 in compile in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_4852(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4852,2,t0,t1);}
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4853,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp));}

/* f_4853 in k4850 in k4847 in k4841 in k4838 in k4679 in k4673 in k4664 in k4249 in k4243 in k4214 in k4158 in compile in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_4853(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4853,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4869,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k4867 */
static void C_ccall f_4869(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4869,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4873,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[7]);}

/* k4871 in k4867 */
static void C_ccall f_4873(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4873,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4877,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[6]);}

/* k4875 in k4871 in k4867 */
static void C_ccall f_4877(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4877,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4881,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}

/* k4879 in k4875 in k4871 in k4867 */
static void C_ccall f_4881(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4881,2,t0,t1);}
t2=(C_word)C_a_i_vector(&a,4,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[4]);
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,((C_word*)t0)[2],t3);}

/* k4771 in k4679 in k4673 in k4664 in k4249 in k4243 in k4214 in k4158 in compile in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_4773(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4773,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4776,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4819,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* eval.scm: 811  cadadr */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[10]);}

/* k4817 in k4771 in k4679 in k4673 in k4664 in k4249 in k4243 in k4214 in k4158 in compile in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_4819(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_i_cadr(((C_word*)t0)[7]);
/* eval.scm: 811  compile */
t3=((C_word*)((C_word*)t0)[6])[1];
f_4057(t3,((C_word*)t0)[5],t1,((C_word*)t0)[4],t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4774 in k4771 in k4679 in k4673 in k4664 in k4249 in k4243 in k4214 in k4158 in compile in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_4776(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4776,2,t0,t1);}
t2=(C_word)C_u_i_cddr(((C_word*)t0)[10]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4782,a[2]=((C_word*)t0)[7],a[3]=t1,a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_u_i_cadar(t2);
t5=(C_word)C_u_i_caddr(((C_word*)t0)[6]);
/* eval.scm: 813  compile */
t6=((C_word*)((C_word*)t0)[5])[1];
f_4057(t6,t3,t4,((C_word*)t0)[4],t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4780 in k4774 in k4771 in k4679 in k4673 in k4664 in k4249 in k4243 in k4214 in k4158 in compile in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_4782(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4782,2,t0,t1);}
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4783,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp));}

/* f_4783 in k4780 in k4774 in k4771 in k4679 in k4673 in k4664 in k4249 in k4243 in k4214 in k4158 in compile in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_4783(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4783,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4799,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k4797 */
static void C_ccall f_4799(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4799,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4803,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[6]);}

/* k4801 in k4797 */
static void C_ccall f_4803(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4803,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4807,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}

/* k4805 in k4801 in k4797 */
static void C_ccall f_4807(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4807,2,t0,t1);}
t2=(C_word)C_a_i_vector(&a,3,((C_word*)t0)[6],((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[4]);
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,((C_word*)t0)[2],t3);}

/* k4722 in k4679 in k4673 in k4664 in k4249 in k4243 in k4214 in k4158 in compile in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_4724(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4724,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4727,a[2]=t1,a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4752,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t2,a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* eval.scm: 807  cadadr */
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k4750 in k4722 in k4679 in k4673 in k4664 in k4249 in k4243 in k4214 in k4158 in compile in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_4752(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_i_cadr(((C_word*)t0)[7]);
/* eval.scm: 807  compile */
t3=((C_word*)((C_word*)t0)[6])[1];
f_4057(t3,((C_word*)t0)[5],t1,((C_word*)t0)[4],t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4725 in k4722 in k4679 in k4673 in k4664 in k4249 in k4243 in k4214 in k4158 in compile in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_4727(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4727,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4728,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp));}

/* f_4728 in k4725 in k4722 in k4679 in k4673 in k4664 in k4249 in k4243 in k4214 in k4158 in compile in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_4728(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4728,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4744,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k4742 */
static void C_ccall f_4744(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4744,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4748,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}

/* k4746 in k4742 */
static void C_ccall f_4748(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4748,2,t0,t1);}
t2=(C_word)C_a_i_vector(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[4]);
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,((C_word*)t0)[2],t3);}

/* k4688 in k4679 in k4673 in k4664 in k4249 in k4243 in k4214 in k4158 in compile in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_4690(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4690,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4691,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp));}

/* f_4691 in k4688 in k4679 in k4673 in k4664 in k4249 in k4243 in k4214 in k4158 in compile in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_4691(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4691,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4707,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k4705 */
static void C_ccall f_4707(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4707,2,t0,t1);}
t2=(C_word)C_a_i_vector(&a,1,t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[4]);
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,((C_word*)t0)[2],t3);}

/* k4555 in k4249 in k4243 in k4214 in k4158 in compile in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_4557(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4557,2,t0,t1);}
t2=(C_word)C_u_i_cadr(((C_word*)t0)[8]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4565,a[2]=((C_word*)t0)[6],a[3]=t2,a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4571,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[8],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,((C_word*)t0)[2],t3,t4);}

/* a4570 in k4555 in k4249 in k4243 in k4214 in k4158 in compile in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_4571(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4571,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4575,a[2]=((C_word*)t0)[7],a[3]=t3,a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_u_i_caddr(((C_word*)t0)[6]);
/* eval.scm: 771  compile */
t6=((C_word*)((C_word*)t0)[5])[1];
f_4057(t6,t4,t5,((C_word*)t0)[4],((C_word*)t0)[7],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4573 in a4570 in k4555 in k4249 in k4243 in k4214 in k4158 in compile in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_4575(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4575,2,t0,t1);}
t2=((C_word*)t0)[5];
if(C_truep(t2)){
t3=(C_word)C_i_zerop(((C_word*)t0)[5]);
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4632,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp):(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4645,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp)));}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4584,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 773  ##sys#alias-global-hook */
t4=*((C_word*)lf[138]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}}

/* k4582 in k4573 in a4570 in k4555 in k4249 in k4243 in k4214 in k4158 in compile in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_4584(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4584,2,t0,t1);}
if(C_truep(*((C_word*)lf[128]+1))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4590,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 775  ##sys#hash-table-location */
t3=*((C_word*)lf[127]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,*((C_word*)lf[128]+1),t1,*((C_word*)lf[129]+1));}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4617,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp));}}

/* f_4617 in k4582 in k4573 in a4570 in k4555 in k4249 in k4243 in k4214 in k4158 in compile in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_4617(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4617,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4625,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k4623 */
static void C_ccall f_4625(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_setslot(((C_word*)t0)[2],C_fix(0),t1));}

/* k4588 in k4582 in k4573 in a4570 in k4555 in k4249 in k4243 in k4214 in k4158 in compile in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_4590(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4590,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4593,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t1)){
t3=t2;
f_4593(2,t3,C_SCHEME_UNDEFINED);}
else{
/* eval.scm: 779  ##sys#error */
t3=*((C_word*)lf[144]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[158],((C_word*)t0)[2]);}}

/* k4591 in k4588 in k4582 in k4573 in a4570 in k4555 in k4249 in k4243 in k4214 in k4158 in compile in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_4593(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4593,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(2));
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4600,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp):(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4609,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp)));}

/* f_4609 in k4591 in k4588 in k4582 in k4573 in a4570 in k4555 in k4249 in k4243 in k4214 in k4158 in compile in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_4609(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4609,2,t0,t1);}
/* eval.scm: 782  ##sys#error */
t2=*((C_word*)lf[144]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[157],((C_word*)t0)[2]);}

/* f_4600 in k4591 in k4588 in k4582 in k4573 in a4570 in k4555 in k4249 in k4243 in k4214 in k4158 in compile in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_4600(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4600,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4608,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k4606 */
static void C_ccall f_4608(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_setslot(((C_word*)t0)[2],C_fix(1),t1));}

/* f_4645 in k4573 in a4570 in k4555 in k4249 in k4243 in k4214 in k4158 in compile in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_4645(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4645,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4653,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k4651 */
static void C_ccall f_4653(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_setslot((C_word)C_u_i_list_ref(((C_word*)t0)[4],((C_word*)t0)[3]),((C_word*)t0)[2],t1));}

/* f_4632 in k4573 in a4570 in k4555 in k4249 in k4243 in k4214 in k4158 in compile in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_4632(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4632,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4644,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k4642 */
static void C_ccall f_4644(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_setslot(((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* a4564 in k4555 in k4249 in k4243 in k4214 in k4158 in compile in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_4565(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4565,2,t0,t1);}
/* eval.scm: 770  lookup */
f_3832(t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4447 in k4249 in k4243 in k4214 in k4158 in compile in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_4449(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4449,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[7],C_fix(1));
t3=(C_word)C_i_length(t2);
switch(t3){
case C_fix(0):
/* eval.scm: 756  compile */
t4=((C_word*)((C_word*)t0)[6])[1];
f_4057(t4,((C_word*)t0)[5],lf[155],((C_word*)t0)[4],C_SCHEME_FALSE,((C_word*)t0)[3],((C_word*)t0)[2]);
case C_fix(1):
t4=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 757  compile */
t5=((C_word*)((C_word*)t0)[6])[1];
f_4057(t5,((C_word*)t0)[5],t4,((C_word*)t0)[4],C_SCHEME_FALSE,((C_word*)t0)[3],((C_word*)t0)[2]);
case C_fix(2):
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4486,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t5=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 758  compile */
t6=((C_word*)((C_word*)t0)[6])[1];
f_4057(t6,t4,t5,((C_word*)t0)[4],C_SCHEME_FALSE,((C_word*)t0)[3],((C_word*)t0)[2]);
default:
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4508,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t5=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 762  compile */
t6=((C_word*)((C_word*)t0)[6])[1];
f_4057(t6,t4,t5,((C_word*)t0)[4],C_SCHEME_FALSE,((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k4506 in k4447 in k4249 in k4243 in k4214 in k4158 in compile in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_4508(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4508,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4511,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(C_word)C_u_i_cadr(((C_word*)t0)[6]);
/* eval.scm: 763  compile */
t4=((C_word*)((C_word*)t0)[5])[1];
f_4057(t4,t2,t3,((C_word*)t0)[4],C_SCHEME_FALSE,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4509 in k4506 in k4447 in k4249 in k4243 in k4214 in k4158 in compile in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_4511(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4511,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4514,a[2]=((C_word*)t0)[7],a[3]=t1,a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t4=(C_word)C_slot(t3,C_fix(1));
t5=(C_word)C_a_i_cons(&a,2,lf[106],t4);
/* eval.scm: 764  compile */
t6=((C_word*)((C_word*)t0)[5])[1];
f_4057(t6,t2,t5,((C_word*)t0)[4],C_SCHEME_FALSE,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4512 in k4509 in k4506 in k4447 in k4249 in k4243 in k4214 in k4158 in compile in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_4514(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4514,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4515,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp));}

/* f_4515 in k4512 in k4509 in k4506 in k4447 in k4249 in k4243 in k4214 in k4158 in compile in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_4515(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4515,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4519,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k4517 */
static void C_ccall f_4519(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4519,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4522,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* k4520 in k4517 */
static void C_ccall f_4522(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4484 in k4447 in k4249 in k4243 in k4214 in k4158 in compile in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_4486(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4486,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4489,a[2]=t1,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_u_i_cadr(((C_word*)t0)[6]);
/* eval.scm: 759  compile */
t4=((C_word*)((C_word*)t0)[5])[1];
f_4057(t4,t2,t3,((C_word*)t0)[4],C_SCHEME_FALSE,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4487 in k4484 in k4447 in k4249 in k4243 in k4214 in k4158 in compile in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_4489(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4489,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4490,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp));}

/* f_4490 in k4487 in k4484 in k4447 in k4249 in k4243 in k4214 in k4158 in compile in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_4490(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4490,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4494,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k4492 */
static void C_ccall f_4494(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4390 in k4249 in k4243 in k4214 in k4158 in compile in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_4392(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4392,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4395,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_u_i_cadr(((C_word*)t0)[6]);
/* eval.scm: 744  compile */
t4=((C_word*)((C_word*)t0)[5])[1];
f_4057(t4,t2,t3,((C_word*)t0)[4],C_SCHEME_FALSE,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4393 in k4390 in k4249 in k4243 in k4214 in k4158 in compile in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_4395(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4395,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4398,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(C_word)C_u_i_caddr(((C_word*)t0)[6]);
/* eval.scm: 745  compile */
t4=((C_word*)((C_word*)t0)[5])[1];
f_4057(t4,t2,t3,((C_word*)t0)[4],C_SCHEME_FALSE,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4396 in k4393 in k4390 in k4249 in k4243 in k4214 in k4158 in compile in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_4398(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4398,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4401,a[2]=((C_word*)t0)[7],a[3]=t1,a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_u_i_cdddr(((C_word*)t0)[6]);
if(C_truep((C_word)C_i_pairp(t3))){
t4=(C_word)C_u_i_cadddr(((C_word*)t0)[6]);
/* eval.scm: 747  compile */
t5=((C_word*)((C_word*)t0)[5])[1];
f_4057(t5,t2,t4,((C_word*)t0)[4],C_SCHEME_FALSE,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* eval.scm: 748  compile */
t4=((C_word*)((C_word*)t0)[5])[1];
f_4057(t4,t2,lf[153],((C_word*)t0)[4],C_SCHEME_FALSE,((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k4399 in k4396 in k4393 in k4390 in k4249 in k4243 in k4214 in k4158 in compile in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_4401(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4401,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4402,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp));}

/* f_4402 in k4399 in k4396 in k4393 in k4390 in k4249 in k4243 in k4214 in k4158 in compile in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_4402(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4402,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4409,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k4407 */
static void C_ccall f_4409(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t2=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[4],((C_word*)t0)[3]);}}

/* f_4382 in k4249 in k4243 in k4214 in k4158 in compile in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_4382(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4382,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}

/* f_4348 in k4249 in k4243 in k4214 in k4158 in compile in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_4348(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4348,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_slot(((C_word*)t0)[2],C_fix(0)));}

/* k4340 in k4249 in k4243 in k4214 in k4158 in compile in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_4342(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4342,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4343,a[2]=t1,tmp=(C_word)a,a+=3,tmp));}

/* f_4343 in k4340 in k4249 in k4243 in k4214 in k4158 in compile in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_4343(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4343,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_slot(((C_word*)t0)[2],C_fix(1)));}

/* k4264 in k4249 in k4243 in k4214 in k4158 in compile in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_4266(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4266,2,t0,t1);}
t2=(C_word)C_u_i_cadr(((C_word*)t0)[3]);
switch(t2){
case C_fix(-1):
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4276,tmp=(C_word)a,a+=2,tmp));
case C_fix(0):
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4284,tmp=(C_word)a,a+=2,tmp));
case C_fix(1):
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4292,tmp=(C_word)a,a+=2,tmp));
case C_fix(2):
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4300,tmp=(C_word)a,a+=2,tmp));
case C_SCHEME_TRUE:
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4308,tmp=(C_word)a,a+=2,tmp));
case C_SCHEME_FALSE:
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4316,tmp=(C_word)a,a+=2,tmp));
default:
t3=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4324,tmp=(C_word)a,a+=2,tmp):(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4326,a[2]=t2,tmp=(C_word)a,a+=3,tmp)));}}

/* f_4326 in k4264 in k4249 in k4243 in k4214 in k4158 in compile in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_4326(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4326,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* f_4324 in k4264 in k4249 in k4243 in k4214 in k4158 in compile in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_4324(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4324,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_LIST);}

/* f_4316 in k4264 in k4249 in k4243 in k4214 in k4158 in compile in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_4316(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4316,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* f_4308 in k4264 in k4249 in k4243 in k4214 in k4158 in compile in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_4308(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4308,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* f_4300 in k4264 in k4249 in k4243 in k4214 in k4158 in compile in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_4300(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4300,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(2));}

/* f_4292 in k4264 in k4249 in k4243 in k4214 in k4158 in compile in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_4292(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4292,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(1));}

/* f_4284 in k4264 in k4249 in k4243 in k4214 in k4158 in compile in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_4284(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4284,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}

/* f_4276 in k4264 in k4249 in k4243 in k4214 in k4158 in compile in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_4276(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4276,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(-1));}

/* f_4217 in k4214 in k4158 in compile in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_4217(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4217,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* f_4206 in k4158 in compile in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_4206(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4206,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* f_4204 in k4158 in compile in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_4204(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4204,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* f_4193 in k4158 in compile in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_4193(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4193,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* f_4191 in k4158 in compile in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_4191(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4191,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(2));}

/* f_4183 in k4158 in compile in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_4183(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4183,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(1));}

/* f_4175 in k4158 in compile in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_4175(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4175,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}

/* f_4167 in k4158 in compile in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_4167(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4167,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(-1));}

/* a4074 in compile in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_4075(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4075,4,t0,t1,t2,t3);}
t4=t2;
if(C_truep(t4)){
t5=(C_word)C_i_zerop(t2);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_truep(t5)?(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4141,a[2]=t3,tmp=(C_word)a,a+=3,tmp):(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4150,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp)));}
else{
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4085,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 669  ##sys#alias-global-hook */
t6=*((C_word*)lf[138]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[2]);}}

/* k4083 in a4074 in compile in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_4085(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4085,2,t0,t1);}
if(C_truep(*((C_word*)lf[128]+1))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4091,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 671  ##sys#hash-table-location */
t3=*((C_word*)lf[127]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,*((C_word*)lf[128]+1),t1,C_SCHEME_TRUE);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4114,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4119,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(*((C_word*)lf[136]+1))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4134,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 684  ##sys#symbol-has-toplevel-binding? */
t5=*((C_word*)lf[147]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t1);}
else{
t4=t3;
f_4119(t4,C_SCHEME_FALSE);}}}

/* k4132 in k4083 in a4074 in compile in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_4134(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_4119(t2,(C_word)C_i_not(t1));}

/* k4117 in k4083 in a4074 in compile in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_fcall f_4119(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4119,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)t0)[3]);
t3=(C_word)C_a_i_cons(&a,2,t2,*((C_word*)lf[136]+1));
t4=C_mutate((C_word*)lf[136]+1,t3);
t5=((C_word*)t0)[2];
f_4114(t5,t4);}
else{
t2=((C_word*)t0)[2];
f_4114(t2,C_SCHEME_UNDEFINED);}}

/* k4112 in k4083 in a4074 in compile in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_fcall f_4114(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4114,NULL,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4115,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp));}

/* f_4115 in k4112 in k4083 in a4074 in compile in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_4115(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4115,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_retrieve(((C_word*)t0)[2]));}

/* k4089 in k4083 in a4074 in compile in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_4091(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4091,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4094,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t1)){
t3=t2;
f_4094(2,t3,C_SCHEME_UNDEFINED);}
else{
/* eval.scm: 672  ##sys#syntax-error-hook */
t3=*((C_word*)lf[56]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[146],((C_word*)t0)[2]);}}

/* k4092 in k4089 in k4083 in a4074 in compile in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_4094(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4094,2,t0,t1);}
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4095,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));}

/* f_4095 in k4092 in k4089 in k4083 in a4074 in compile in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_4095(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4095,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=(C_word)C_eqp(((C_word*)t0)[3],t2);
if(C_truep(t3)){
/* eval.scm: 679  ##sys#error */
t4=*((C_word*)lf[144]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,lf[145],((C_word*)t0)[2]);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}}

/* f_4150 in a4074 in compile in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_4150(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4150,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot((C_word)C_u_i_list_ref(t2,((C_word*)t0)[3]),((C_word*)t0)[2]));}

/* f_4141 in a4074 in compile in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_4141(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4141,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(0));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t3,((C_word*)t0)[2]));}

/* a4068 in compile in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_4069(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4069,2,t0,t1);}
/* eval.scm: 667  lookup */
f_3832(t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* decorate in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_fcall f_4051(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4051,NULL,5,t1,t2,t3,t4,t5);}
/* eval.scm: 663  ##sys#eval-decorator */
t6=*((C_word*)lf[130]+1);
((C_proc6)(void*)(*((C_word*)t6+1)))(6,t6,t1,t2,t3,t4,t5);}

/* emit-syntax-trace-info in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static C_word C_fcall f_4045(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
return((C_truep(t1)?(C_word)C_emit_syntax_trace_info(t2,t3,*((C_word*)lf[143]+1)):C_SCHEME_UNDEFINED));}

/* emit-trace-info in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static C_word C_fcall f_4039(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
return((C_truep(t1)?(C_word)C_emit_eval_trace_info(t2,t3,*((C_word*)lf[143]+1)):C_SCHEME_UNDEFINED));}

/* macroexpand-1-checked in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_fcall f_3986(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3986,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3990,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 643  ##sys#macroexpand-1-local */
t5=*((C_word*)lf[74]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,C_SCHEME_END_OF_LIST);}

/* k3988 in macroexpand-1-checked in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_3990(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3990,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(C_word)C_slot(t1,C_fix(0));
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4005,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_eqp(t2,lf[58]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4037,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 646  defined? */
t6=((C_word*)t0)[2];
f_3874(t6,t5,lf[58],((C_word*)t0)[3]);}
else{
t5=t3;
f_4005(t5,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}}

/* k4035 in k3988 in macroexpand-1-checked in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_4037(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_4005(t2,(C_word)C_i_not(t1));}

/* k4003 in k3988 in macroexpand-1-checked in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_fcall f_4005(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4005,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4014,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_slot(t2,C_fix(0));
t5=t3;
f_4014(t5,(C_word)C_i_symbolp(t4));}
else{
t4=t3;
f_4014(t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[5]);}}

/* k4012 in k4003 in k3988 in macroexpand-1-checked in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_fcall f_4014(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* eval.scm: 649  macroexpand-1-checked */
t2=((C_word*)((C_word*)t0)[5])[1];
f_3986(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}}

/* defined? in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_fcall f_3874(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3874,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3880,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3886,tmp=(C_word)a,a+=2,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t4,t5);}

/* a3885 in defined? in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_3886(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3886,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}

/* a3879 in defined? in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_ccall f_3880(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3880,2,t0,t1);}
/* eval.scm: 618  lookup */
f_3832(t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* lookup in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_fcall f_3832(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3832,NULL,3,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3838,a[2]=t5,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_3838(t7,t1,t3,C_fix(0));}

/* loop in lookup in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static void C_fcall f_3838(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
loop:
a=C_alloc(3);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3838,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
/* eval.scm: 613  values */
C_values(4,0,t1,C_SCHEME_FALSE,((C_word*)t0)[3]);}
else{
t4=(C_word)C_slot(t2,C_fix(0));
t5=((C_word*)t0)[3];
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3956,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=f_3956(t6,t4,C_fix(0));
if(C_truep(t7)){
/* eval.scm: 614  values */
C_values(4,0,t1,t3,t7);}
else{
t8=(C_word)C_slot(t2,C_fix(1));
t9=(C_word)C_u_fixnum_plus(t3,C_fix(1));
/* eval.scm: 615  loop */
t11=t1;
t12=t8;
t13=t9;
t1=t11;
t2=t12;
t3=t13;
goto loop;}}}

/* loop in loop in lookup in ##sys#compile-to-closure in k1773 in k1731 in k1728 */
static C_word C_fcall f_3956(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
loop:
if(C_truep((C_word)C_i_nullp(t1))){
return(C_SCHEME_FALSE);}
else{
t3=(C_word)C_slot(t1,C_fix(0));
t4=(C_word)C_eqp(((C_word*)t0)[2],t3);
if(C_truep(t4)){
return(t2);}
else{
t5=(C_word)C_slot(t1,C_fix(1));
t6=(C_word)C_u_fixnum_plus(t2,C_fix(1));
t8=t5;
t9=t6;
t1=t8;
t2=t9;
goto loop;}}}

/* ##sys#alias-global-hook in k1773 in k1731 in k1728 */
static void C_ccall f_3823(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3823,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* ##sys#eval-decorator in k1773 in k1731 in k1728 */
static void C_ccall f_3782(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_3782,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3788,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3801,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 583  ##sys#decorate-lambda */
t8=*((C_word*)lf[135]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t1,t2,t6,t7);}

/* a3800 in ##sys#eval-decorator in k1773 in k1731 in k1728 */
static void C_ccall f_3801(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3801,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3809,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3813,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 590  open-output-string */
t6=*((C_word*)lf[134]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}

/* k3811 in a3800 in ##sys#eval-decorator in k1773 in k1731 in k1728 */
static void C_ccall f_3813(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3813,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3816,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 591  write */
t3=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],t1);}

/* k3814 in k3811 in a3800 in ##sys#eval-decorator in k1773 in k1731 in k1728 */
static void C_ccall f_3816(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3816,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3819,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 592  get-output-string */
t3=*((C_word*)lf[132]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k3817 in k3814 in k3811 in a3800 in ##sys#eval-decorator in k1773 in k1731 in k1728 */
static void C_ccall f_3819(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 589  ##sys#make-lambda-info */
t2=*((C_word*)lf[131]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3807 in a3800 in ##sys#eval-decorator in k1773 in k1731 in k1728 */
static void C_ccall f_3809(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[4],((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[4]);}

/* a3787 in ##sys#eval-decorator in k1773 in k1731 in k1728 */
static void C_ccall f_3788(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3788,3,t0,t1,t2);}
t3=(C_word)C_immp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?C_SCHEME_FALSE:(C_word)C_lambdainfop(t2)));}

/* ##sys#hash-table-location in k1773 in k1731 in k1728 */
static void C_ccall f_3722(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3722,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3726,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t4,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t6=(C_word)C_block_size(t2);
/* eval.scm: 563  ##sys#hash-symbol */
t7=*((C_word*)lf[120]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t3,t6);}

/* k3724 in ##sys#hash-table-location in k1773 in k1731 in k1728 */
static void C_ccall f_3726(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3726,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[6],t1);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3734,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[6],a[5]=t2,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp));
t6=((C_word*)t4)[1];
f_3734(t6,((C_word*)t0)[2],t2);}

/* loop in k3724 in ##sys#hash-table-location in k1773 in k1731 in k1728 */
static void C_fcall f_3734(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(7);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3734,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
if(C_truep(((C_word*)t0)[8])){
t3=(C_word)C_a_i_vector(&a,3,((C_word*)t0)[7],((C_word*)t0)[6],C_SCHEME_TRUE);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[5]);
t5=(C_word)C_i_setslot(((C_word*)t0)[4],((C_word*)t0)[3],t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t3,C_fix(0));
t5=(C_word)C_eqp(((C_word*)t0)[7],t4);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t3);}
else{
t6=(C_word)C_slot(t2,C_fix(1));
/* eval.scm: 574  loop */
t11=t1;
t12=t6;
t1=t11;
t2=t12;
goto loop;}}}

/* ##sys#hash-table->alist in k1773 in k1731 in k1728 */
static void C_ccall f_3655(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3655,3,t0,t1,t2);}
t3=(C_word)C_block_size(t2);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3661,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_3661(t7,t1,C_fix(0),C_SCHEME_END_OF_LIST);}

/* loop in ##sys#hash-table->alist in k1773 in k1731 in k1728 */
static void C_fcall f_3661(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3661,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[3]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_slot(*((C_word*)lf[125]+1),t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3677,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_3677(t8,t1,t4,t3);}}

/* loop2 in loop in ##sys#hash-table->alist in k1773 in k1731 in k1728 */
static void C_fcall f_3677(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
loop:
a=C_alloc(6);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3677,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* eval.scm: 555  loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_3661(t5,t1,t4,t3);}
else{
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_slot(t2,C_fix(0));
t6=(C_word)C_slot(t5,C_fix(0));
t7=(C_word)C_slot(t5,C_fix(1));
t8=(C_word)C_a_i_cons(&a,2,t6,t7);
t9=(C_word)C_a_i_cons(&a,2,t8,t3);
/* eval.scm: 556  loop2 */
t12=t1;
t13=t4;
t14=t9;
t1=t12;
t2=t13;
t3=t14;
goto loop;}}

/* ##sys#hash-table-for-each in k1773 in k1731 in k1728 */
static void C_ccall f_3612(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3612,4,t0,t1,t2,t3);}
t4=(C_word)C_block_size(t3);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3618,a[2]=t3,a[3]=t2,a[4]=t6,a[5]=t4,tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_3618(t8,t1,C_fix(0));}

/* do269 in ##sys#hash-table-for-each in k1773 in k1731 in k1728 */
static void C_fcall f_3618(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3618,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3628,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3637,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_slot(((C_word*)t0)[2],t2);
/* eval.scm: 543  ##sys#for-each */
t6=*((C_word*)lf[123]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}}

/* a3636 in do269 in ##sys#hash-table-for-each in k1773 in k1731 in k1728 */
static void C_ccall f_3637(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3637,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t2,C_fix(1));
/* eval.scm: 544  p */
t5=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t3,t4);}

/* k3626 in do269 in ##sys#hash-table-for-each in k1773 in k1731 in k1728 */
static void C_ccall f_3628(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_3618(t3,((C_word*)t0)[2],t2);}

/* ##sys#hash-table-update! in k1773 in k1731 in k1728 */
static void C_ccall f_3592(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_3592,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3600,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3604,a[2]=t5,a[3]=t6,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 537  ##sys#hash-table-ref */
t8=*((C_word*)lf[42]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,t2,t3);}

/* k3602 in ##sys#hash-table-update! in k1773 in k1731 in k1728 */
static void C_ccall f_3604(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3604,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3607,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=t2;
f_3607(2,t3,t1);}
else{
/* eval.scm: 537  valufunc */
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k3605 in k3602 in ##sys#hash-table-update! in k1773 in k1731 in k1728 */
static void C_ccall f_3607(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 537  updtfunc */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3598 in ##sys#hash-table-update! in k1773 in k1731 in k1728 */
static void C_ccall f_3600(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 537  ##sys#hash-table-set! */
t2=*((C_word*)lf[39]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* ##sys#hash-table-set! in k1773 in k1731 in k1728 */
static void C_ccall f_3537(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3537,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3541,a[2]=t1,a[3]=t4,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 526  ##sys#hash-symbol */
t6=*((C_word*)lf[120]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t3,(C_word)C_block_size(t2));}

/* k3539 in ##sys#hash-table-set! in k1773 in k1731 in k1728 */
static void C_ccall f_3541(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3541,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[5],t1);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3549,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp));
t6=((C_word*)t4)[1];
f_3549(t6,((C_word*)t0)[2],t2);}

/* loop in k3539 in ##sys#hash-table-set! in k1773 in k1731 in k1728 */
static void C_fcall f_3549(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(6);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3549,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t3)){
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],((C_word*)t0)[6]);
t5=(C_word)C_a_i_cons(&a,2,t4,((C_word*)t0)[5]);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_i_setslot(((C_word*)t0)[4],((C_word*)t0)[3],t5));}
else{
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_slot(t4,C_fix(0));
t6=(C_word)C_eqp(((C_word*)t0)[7],t5);
if(C_truep(t6)){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_i_setslot(t4,C_fix(1),((C_word*)t0)[6]));}
else{
t7=(C_word)C_slot(t2,C_fix(1));
/* eval.scm: 534  loop */
t11=t1;
t12=t7;
t1=t11;
t2=t12;
goto loop;}}}

/* ##sys#hash-table-ref in k1773 in k1731 in k1728 */
static void C_ccall f_3492(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3492,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3496,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 516  ##sys#hash-symbol */
t5=*((C_word*)lf[120]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t3,(C_word)C_block_size(t2));}

/* k3494 in ##sys#hash-table-ref in k1773 in k1731 in k1728 */
static void C_ccall f_3496(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3496,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[4],t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3505,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,f_3505(t3,t2));}

/* loop in k3494 in ##sys#hash-table-ref in k1773 in k1731 in k1728 */
static C_word C_fcall f_3505(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
loop:
t2=(C_word)C_eqp(t1,C_SCHEME_END_OF_LIST);
if(C_truep(t2)){
return(C_SCHEME_FALSE);}
else{
t3=(C_word)C_slot(t1,C_fix(0));
t4=(C_word)C_slot(t3,C_fix(0));
t5=(C_word)C_eqp(((C_word*)t0)[2],t4);
if(C_truep(t5)){
return((C_word)C_slot(t3,C_fix(1)));}
else{
t6=(C_word)C_slot(t1,C_fix(1));
t8=t6;
t1=t8;
goto loop;}}}

/* ##sys#hash-symbol in k1773 in k1731 in k1728 */
static void C_ccall f_3477(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3477,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t2,((C_word*)((C_word*)t0)[3])[1]);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_fixnum_modulo(((C_word*)((C_word*)t0)[2])[1],t3));}
else{
t5=(C_word)C_slot(t2,C_fix(1));
t6=(C_word)C_hash_string(t5);
t7=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t8=C_mutate(((C_word *)((C_word*)t0)[2])+1,t6);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_fixnum_modulo(t6,t3));}}

/* ##sys#expand-curried-define in k1773 in k1731 in k1728 */
static void C_ccall f_3417(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3417,4,t0,t1,t2,t3);}
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3420,a[2]=t7,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3472,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 493  loop */
t10=((C_word*)t7)[1];
f_3420(t10,t9,t2,t3);}

/* k3470 in ##sys#expand-curried-define in k1773 in k1731 in k1728 */
static void C_ccall f_3472(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3472,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,((C_word*)((C_word*)t0)[2])[1],t1));}

/* loop in ##sys#expand-curried-define in k1773 in k1731 in k1728 */
static void C_fcall f_3420(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a;
loop:
a=C_alloc(15);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3420,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_slot(t2,C_fix(0));
if(C_truep((C_word)C_i_symbolp(t4))){
t5=(C_word)C_slot(t2,C_fix(0));
t6=C_mutate(((C_word *)((C_word*)t0)[3])+1,t5);
t7=(C_word)C_slot(t2,C_fix(1));
t8=(C_word)C_a_i_cons(&a,2,t7,t3);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_a_i_cons(&a,2,lf[92],t8));}
else{
t5=(C_word)C_slot(t2,C_fix(0));
t6=(C_word)C_slot(t2,C_fix(1));
t7=(C_word)C_a_i_cons(&a,2,t6,t3);
t8=(C_word)C_a_i_cons(&a,2,lf[92],t7);
t9=(C_word)C_a_i_list(&a,1,t8);
/* eval.scm: 492  loop */
t15=t1;
t16=t5;
t17=t9;
t1=t15;
t2=t16;
t3=t17;
goto loop;}}

/* ##sys#match-expression in k1773 in k1731 in k1728 */
static void C_ccall f_3326(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3326,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3329,a[2]=t8,a[3]=t4,a[4]=t6,tmp=(C_word)a,a+=5,tmp));
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3415,a[2]=t6,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 480  mwalk */
t11=((C_word*)t8)[1];
f_3329(t11,t10,t2,t3);}

/* k3413 in ##sys#match-expression in k1773 in k1731 in k1728 */
static void C_ccall f_3415(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?((C_word*)((C_word*)t0)[2])[1]:C_SCHEME_FALSE));}

/* mwalk in ##sys#match-expression in k1773 in k1731 in k1728 */
static void C_fcall f_3329(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word *a;
loop:
a=C_alloc(12);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3329,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_not((C_word)C_blockp(t3));
t5=(C_truep(t4)?t4:(C_word)C_i_not((C_word)C_pairp(t3)));
if(C_truep(t5)){
t6=(C_word)C_u_i_assq(t3,((C_word*)((C_word*)t0)[4])[1]);
if(C_truep(t6)){
t7=(C_word)C_slot(t6,C_fix(1));
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_i_equalp(t2,t7));}
else{
if(C_truep((C_word)C_u_i_memq(t3,((C_word*)t0)[3]))){
t7=(C_word)C_a_i_cons(&a,2,t3,t2);
t8=(C_word)C_a_i_cons(&a,2,t7,((C_word*)((C_word*)t0)[4])[1]);
t9=C_mutate(((C_word *)((C_word*)t0)[4])+1,t8);
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_TRUE);}
else{
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_eqp(t2,t3));}}}
else{
t6=(C_word)C_i_not((C_word)C_blockp(t2));
t7=(C_truep(t6)?t6:(C_word)C_i_not((C_word)C_pairp(t2)));
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_FALSE);}
else{
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3384,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t9=(C_word)C_slot(t2,C_fix(0));
t10=(C_word)C_slot(t3,C_fix(0));
/* eval.scm: 477  mwalk */
t17=t8;
t18=t9;
t19=t10;
t1=t17;
t2=t18;
t3=t19;
goto loop;}}}

/* k3382 in mwalk in ##sys#match-expression in k1773 in k1731 in k1728 */
static void C_ccall f_3384(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* eval.scm: 478  mwalk */
t4=((C_word*)((C_word*)t0)[3])[1];
f_3329(t4,((C_word*)t0)[2],t2,t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* ##sys#canonicalize-body in k1773 in k1731 in k1728 */
static void C_ccall f_2843(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr4r,(void*)f_2843r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_2843r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2843r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(12);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2845,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3276,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3281,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-me154207 */
t8=t7;
f_3281(t8,t1);}
else{
t8=(C_word)C_u_i_car(t4);
t9=(C_word)C_slot(t4,C_fix(1));
if(C_truep((C_word)C_i_nullp(t9))){
/* def-container155205 */
t10=t6;
f_3276(t10,t1,t8);}
else{
t10=(C_word)C_u_i_car(t9);
t11=(C_word)C_slot(t9,C_fix(1));
/* body152157 */
t12=t5;
f_2845(t12,t1,t8);}}}

/* def-me154 in ##sys#canonicalize-body in k1773 in k1731 in k1728 */
static void C_fcall f_3281(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3281,NULL,2,t0,t1);}
/* def-container155205 */
t2=((C_word*)t0)[2];
f_3276(t2,t1,C_SCHEME_FALSE);}

/* def-container155 in ##sys#canonicalize-body in k1773 in k1731 in k1728 */
static void C_fcall f_3276(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3276,NULL,3,t0,t1,t2);}
/* body152157 */
t3=((C_word*)t0)[2];
f_2845(t3,t1,t2);}

/* body152 in ##sys#canonicalize-body in k1773 in k1731 in k1728 */
static void C_fcall f_2845(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2845,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2848,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t6,tmp=(C_word)a,a+=5,tmp));
t8=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3028,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t4,tmp=(C_word)a,a+=5,tmp));
/* eval.scm: 461  expand */
t9=((C_word*)t6)[1];
f_3028(t9,t1,((C_word*)t0)[2]);}

/* expand in body152 in ##sys#canonicalize-body in k1773 in k1731 in k1728 */
static void C_fcall f_3028(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3028,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3034,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_3034(t6,t1,t2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}

/* loop in expand in body152 in ##sys#canonicalize-body in k1773 in k1731 in k1728 */
static void C_fcall f_3034(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3034,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
if(C_truep((C_word)C_i_pairp(t2))){
t7=(C_word)C_slot(t2,C_fix(0));
t8=(C_word)C_slot(t2,C_fix(1));
t9=(C_word)C_i_pairp(t7);
t10=(C_truep(t9)?(C_word)C_slot(t7,C_fix(0)):C_SCHEME_FALSE);
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_3068,a[2]=((C_word*)t0)[3],a[3]=t7,a[4]=t8,a[5]=((C_word*)t0)[4],a[6]=t10,a[7]=t2,a[8]=t6,a[9]=t5,a[10]=t4,a[11]=t3,a[12]=t1,a[13]=((C_word*)t0)[5],tmp=(C_word)a,a+=14,tmp);
if(C_truep((C_word)C_i_symbolp(t10))){
/* eval.scm: 427  lookup */
t12=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t12+1)))(3,t12,t11,t10);}
else{
t12=t11;
f_3068(2,t12,C_SCHEME_FALSE);}}
else{
/* eval.scm: 426  fini */
t11=((C_word*)((C_word*)t0)[5])[1];
f_2848(t11,t1,t3,t4,t5,t6,t2);}}
else{
/* eval.scm: 422  fini */
t7=((C_word*)((C_word*)t0)[5])[1];
f_2848(t7,t1,t3,t4,t5,t6,t2);}}

/* k3066 in loop in expand in body152 in ##sys#canonicalize-body in k1773 in k1731 in k1728 */
static void C_ccall f_3068(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[42],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3068,2,t0,t1);}
if(C_truep(t1)){
/* eval.scm: 428  fini */
t2=((C_word*)((C_word*)t0)[13])[1];
f_2848(t2,((C_word*)t0)[12],((C_word*)t0)[11],((C_word*)t0)[10],((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7]);}
else{
t2=(C_word)C_eqp(lf[107],((C_word*)t0)[6]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3080,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
/* eval.scm: 430  ##sys#check-syntax */
t4=*((C_word*)lf[64]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t3,lf[107],((C_word*)t0)[3],lf[116],C_SCHEME_FALSE);}
else{
t3=(C_word)C_eqp(lf[108],((C_word*)t0)[6]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3198,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[3],tmp=(C_word)a,a+=10,tmp);
/* eval.scm: 451  ##sys#check-syntax */
t5=*((C_word*)lf[64]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t4,lf[108],((C_word*)t0)[3],lf[117],C_SCHEME_FALSE);}
else{
t4=(C_word)C_eqp(lf[106],((C_word*)t0)[6]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3226,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[12],a[9]=((C_word*)t0)[5],tmp=(C_word)a,a+=10,tmp);
/* eval.scm: 454  ##sys#check-syntax */
t6=*((C_word*)lf[64]+1);
((C_proc6)(void*)(*((C_word*)t6+1)))(6,t6,t5,lf[106],((C_word*)t0)[3],lf[118],C_SCHEME_FALSE);}
else{
t5=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3240,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[13],a[11]=((C_word*)t0)[3],tmp=(C_word)a,a+=12,tmp);
/* eval.scm: 457  ##sys#macroexpand-0 */
t6=*((C_word*)lf[46]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,((C_word*)t0)[3],((C_word*)t0)[2]);}}}}}

/* k3238 in k3066 in loop in expand in body152 in ##sys#canonicalize-body in k1773 in k1731 in k1728 */
static void C_ccall f_3240(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3240,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[11],t1);
if(C_truep(t2)){
/* eval.scm: 459  fini */
t3=((C_word*)((C_word*)t0)[10])[1];
f_2848(t3,((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t3=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[3]);
/* eval.scm: 460  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_3034(t4,((C_word*)t0)[9],t3,((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5]);}}

/* k3224 in k3066 in loop in expand in body152 in ##sys#canonicalize-body in k1773 in k1731 in k1728 */
static void C_ccall f_3226(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3226,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3233,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* eval.scm: 455  ##sys#append */
t4=*((C_word*)lf[88]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* k3231 in k3224 in k3066 in loop in expand in body152 in ##sys#canonicalize-body in k1773 in k1731 in k1728 */
static void C_ccall f_3233(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 455  loop */
t2=((C_word*)((C_word*)t0)[7])[1];
f_3034(t2,((C_word*)t0)[6],t1,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3196 in k3066 in loop in expand in body152 in ##sys#canonicalize-body in k1773 in k1731 in k1728 */
static void C_ccall f_3198(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3198,2,t0,t1);}
t2=(C_word)C_u_i_cadr(((C_word*)t0)[9]);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[8]);
t4=(C_word)C_u_i_caddr(((C_word*)t0)[9]);
t5=(C_word)C_a_i_cons(&a,2,t4,((C_word*)t0)[7]);
/* eval.scm: 452  loop */
t6=((C_word*)((C_word*)t0)[6])[1];
f_3034(t6,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t3,t5);}

/* k3078 in k3066 in loop in expand in body152 in ##sys#canonicalize-body in k1773 in k1731 in k1728 */
static void C_ccall f_3080(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3080,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3085,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=t3,tmp=(C_word)a,a+=9,tmp));
t5=((C_word*)t3)[1];
f_3085(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop2 in k3078 in k3066 in loop in expand in body152 in ##sys#canonicalize-body in k1773 in k1731 in k1728 */
static void C_fcall f_3085(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[28],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3085,NULL,3,t0,t1,t2);}
t3=(C_word)C_u_i_cadr(t2);
if(C_truep((C_word)C_i_pairp(t3))){
t4=(C_word)C_slot(t3,C_fix(0));
if(C_truep((C_word)C_i_pairp(t4))){
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3132,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 442  ##sys#check-syntax */
t6=*((C_word*)lf[64]+1);
((C_proc6)(void*)(*((C_word*)t6+1)))(6,t6,t5,lf[107],t2,lf[112],C_SCHEME_FALSE);}
else{
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3150,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t2,a[9]=((C_word*)t0)[7],a[10]=t3,tmp=(C_word)a,a+=11,tmp);
/* eval.scm: 445  ##sys#check-syntax */
t6=*((C_word*)lf[64]+1);
((C_proc6)(void*)(*((C_word*)t6+1)))(6,t6,t5,lf[107],t2,lf[113],C_SCHEME_FALSE);}}
else{
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3098,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t2,a[9]=((C_word*)t0)[7],a[10]=t3,tmp=(C_word)a,a+=11,tmp);
/* eval.scm: 434  ##sys#check-syntax */
t5=*((C_word*)lf[64]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t4,lf[107],t2,lf[115],C_SCHEME_FALSE);}}

/* k3096 in loop2 in k3078 in k3066 in loop in expand in body152 in ##sys#canonicalize-body in k1773 in k1731 in k1728 */
static void C_ccall f_3098(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3098,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],((C_word*)t0)[9]);
t3=(C_word)C_u_i_cddr(((C_word*)t0)[8]);
t4=(C_word)C_i_pairp(t3);
t5=(C_truep(t4)?(C_word)C_u_i_caddr(((C_word*)t0)[8]):lf[114]);
t6=(C_word)C_a_i_cons(&a,2,t5,((C_word*)t0)[7]);
/* eval.scm: 435  loop */
t7=((C_word*)((C_word*)t0)[6])[1];
f_3034(t7,((C_word*)t0)[5],((C_word*)t0)[4],t2,t6,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3148 in loop2 in k3078 in k3066 in loop in expand in body152 in ##sys#canonicalize-body in k1773 in k1731 in k1728 */
static void C_ccall f_3150(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3150,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[10],C_fix(0));
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[9]);
t4=(C_word)C_slot(((C_word*)t0)[10],C_fix(1));
t5=(C_word)C_u_i_cddr(((C_word*)t0)[8]);
t6=(C_word)C_a_i_cons(&a,2,t4,t5);
t7=(C_word)C_a_i_cons(&a,2,lf[92],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,((C_word*)t0)[7]);
/* eval.scm: 446  loop */
t9=((C_word*)((C_word*)t0)[6])[1];
f_3034(t9,((C_word*)t0)[5],((C_word*)t0)[4],t3,t8,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3130 in loop2 in k3078 in k3066 in loop in expand in body152 in ##sys#canonicalize-body in k1773 in k1731 in k1728 */
static void C_ccall f_3132(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3132,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3143,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_u_i_cddr(((C_word*)t0)[3]);
/* eval.scm: 443  ##sys#expand-curried-define */
t4=*((C_word*)lf[111]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,((C_word*)t0)[2],t3);}

/* k3141 in k3130 in loop2 in k3078 in k3066 in loop in expand in body152 in ##sys#canonicalize-body in k1773 in k1731 in k1728 */
static void C_ccall f_3143(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3143,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[107],t1);
/* eval.scm: 443  loop2 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_3085(t3,((C_word*)t0)[2],t2);}

/* fini in body152 in ##sys#canonicalize-body in k1773 in k1731 in k1728 */
static void C_fcall f_2848(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2848,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(C_word)C_i_nullp(t2);
t8=(C_truep(t7)?(C_word)C_i_nullp(t4):C_SCHEME_FALSE);
if(C_truep(t8)){
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2860,a[2]=t6,a[3]=t10,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp));
t12=((C_word*)t10)[1];
f_2860(t12,t1,t6,C_SCHEME_END_OF_LIST);}
else{
t9=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2930,a[2]=t3,a[3]=t4,a[4]=t5,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[2],a[7]=t6,a[8]=t1,tmp=(C_word)a,a+=9,tmp);
/* eval.scm: 406  reverse */
t10=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,t2);}}

/* k2928 in fini in body152 in ##sys#canonicalize-body in k1773 in k1731 in k1728 */
static void C_ccall f_2930(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2930,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2941,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3008,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3020,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_apply(5,0,t4,*((C_word*)lf[88]+1),t1,((C_word*)t0)[3]);}

/* k3018 in k2928 in fini in body152 in ##sys#canonicalize-body in k1773 in k1731 in k1728 */
static void C_ccall f_3020(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 407  ##sys#map */
t2=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a3007 in k2928 in fini in body152 in ##sys#canonicalize-body in k1773 in k1731 in k1728 */
static void C_ccall f_3008(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3008,3,t0,t1,t2);}
t3=(C_word)C_a_i_list(&a,1,lf[110]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,2,t2,t3));}

/* k2939 in k2928 in fini in body152 in ##sys#canonicalize-body in k1773 in k1731 in k1728 */
static void C_ccall f_2941(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[20],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2941,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2945,a[2]=((C_word*)t0)[9],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2949,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2998,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3006,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t3,a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 409  reverse */
t6=((C_word*)t0)[6];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[2]);}

/* k3004 in k2939 in k2928 in fini in body152 in ##sys#canonicalize-body in k1773 in k1731 in k1728 */
static void C_ccall f_3006(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 409  map */
t2=((C_word*)t0)[5];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2997 in k2939 in k2928 in fini in body152 in ##sys#canonicalize-body in k1773 in k1731 in k1728 */
static void C_ccall f_2998(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2998,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[71],t2,t3));}

/* k2947 in k2939 in k2928 in fini in body152 in ##sys#canonicalize-body in k1773 in k1731 in k1728 */
static void C_ccall f_2949(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2949,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2953,a[2]=t1,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2957,a[2]=((C_word*)t0)[6],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2959,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2992,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=t3,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 416  reverse */
t6=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[2]);}

/* k2990 in k2947 in k2939 in k2928 in fini in body152 in ##sys#canonicalize-body in k1773 in k1731 in k1728 */
static void C_ccall f_2992(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2992,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2996,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 417  reverse */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k2994 in k2990 in k2947 in k2939 in k2928 in fini in body152 in ##sys#canonicalize-body in k1773 in k1731 in k1728 */
static void C_ccall f_2996(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 410  map */
t2=((C_word*)t0)[5];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2958 in k2947 in k2939 in k2928 in fini in body152 in ##sys#canonicalize-body in k1773 in k1731 in k1728 */
static void C_ccall f_2959(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2959,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2963,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 411  ##sys#map */
t5=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,*((C_word*)lf[83]+1),t2);}

/* k2961 in a2958 in k2947 in k2939 in k2928 in fini in body152 in ##sys#canonicalize-body in k1773 in k1731 in k1728 */
static void C_ccall f_2963(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2963,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,lf[92],C_SCHEME_END_OF_LIST,((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2982,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2984,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 415  map */
t5=((C_word*)t0)[3];
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t3,t4,((C_word*)t0)[2],t1);}

/* a2983 in k2961 in a2958 in k2947 in k2939 in k2928 in fini in body152 in ##sys#canonicalize-body in k1773 in k1731 in k1728 */
static void C_ccall f_2984(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2984,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[71],t2,t3));}

/* k2980 in k2961 in a2958 in k2947 in k2939 in k2928 in fini in body152 in ##sys#canonicalize-body in k1773 in k1731 in k1728 */
static void C_ccall f_2982(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2982,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[92],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[109],((C_word*)t0)[2],t3));}

/* k2955 in k2947 in k2939 in k2928 in fini in body152 in ##sys#canonicalize-body in k1773 in k1731 in k1728 */
static void C_ccall f_2957(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[88]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2951 in k2947 in k2939 in k2928 in fini in body152 in ##sys#canonicalize-body in k1773 in k1731 in k1728 */
static void C_ccall f_2953(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[88]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2943 in k2939 in k2928 in fini in body152 in ##sys#canonicalize-body in k1773 in k1731 in k1728 */
static void C_ccall f_2945(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2945,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[58],t2));}

/* loop in fini in body152 in ##sys#canonicalize-body in k1773 in k1731 in k1728 */
static void C_fcall f_2860(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2860,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_slot(t2,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2879,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t3,a[5]=((C_word*)t0)[4],a[6]=t2,a[7]=((C_word*)t0)[5],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_i_pairp(t4))){
t6=(C_word)C_slot(t4,C_fix(0));
t7=(C_word)C_a_i_list(&a,2,lf[107],lf[108]);
t8=t5;
f_2879(t8,(C_word)C_u_i_memq(t6,t7));}
else{
t6=t5;
f_2879(t6,C_SCHEME_FALSE);}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[106],((C_word*)t0)[2]));}}

/* k2877 in loop in fini in body152 in ##sys#canonicalize-body in k1773 in k1731 in k1728 */
static void C_fcall f_2879(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2879,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2886,a[2]=((C_word*)t0)[8],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2890,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 404  reverse */
t4=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[4]);}
else{
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)t0)[4]);
/* eval.scm: 405  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_2860(t4,((C_word*)t0)[8],t2,t3);}}

/* k2888 in k2877 in loop in fini in body152 in ##sys#canonicalize-body in k1773 in k1731 in k1728 */
static void C_ccall f_2890(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2890,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2898,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 404  expand */
t3=((C_word*)((C_word*)t0)[3])[1];
f_3028(t3,t2,((C_word*)t0)[2]);}

/* k2896 in k2888 in k2877 in loop in fini in body152 in ##sys#canonicalize-body in k1773 in k1731 in k1728 */
static void C_ccall f_2898(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2898,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* eval.scm: 404  ##sys#append */
t3=*((C_word*)lf[88]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k2884 in k2877 in loop in fini in body152 in ##sys#canonicalize-body in k1773 in k1731 in k1728 */
static void C_ccall f_2886(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2886,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[106],t1));}

/* ##sys#expand-extended-lambda-list in k1773 in k1731 in k1728 */
static void C_ccall f_2324(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2324,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2327,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_FALSE;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2346,a[2]=((C_word*)t0)[2],a[3]=t11,a[4]=t5,a[5]=t3,a[6]=((C_word*)t0)[3],a[7]=t9,a[8]=t7,tmp=(C_word)a,a+=9,tmp));
t13=((C_word*)t11)[1];
f_2346(t13,t1,C_fix(0),C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,t2);}

/* loop in ##sys#expand-extended-lambda-list in k1773 in k1731 in k1728 */
static void C_fcall f_2346(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word *a;
loop:
a=C_alloc(85);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2346,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
if(C_truep((C_word)C_i_nullp(t6))){
t7=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2360,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t5,a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=t4,a[8]=t1,tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)((C_word*)t0)[8])[1])){
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2569,a[2]=((C_word*)t0)[8],a[3]=t7,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 322  reverse */
t9=((C_word*)t0)[6];
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t3);}
else{
/* eval.scm: 322  reverse */
t8=((C_word*)t0)[6];
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t3);}}
else{
if(C_truep((C_word)C_i_symbolp(t6))){
if(C_truep((C_word)C_fixnum_greaterp(t2,C_fix(2)))){
/* eval.scm: 345  err */
t7=((C_word*)t0)[4];
f_2327(t7,t1,lf[94]);}
else{
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2590,a[2]=t4,a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=t6,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t8=((C_word*)((C_word*)t0)[8])[1];
if(C_truep(t8)){
t9=t7;
f_2590(t9,C_SCHEME_UNDEFINED);}
else{
t9=C_mutate(((C_word *)((C_word*)t0)[8])+1,t6);
t10=t7;
f_2590(t10,t9);}}}
else{
if(C_truep((C_word)C_i_pairp(t6))){
t7=(C_word)C_slot(t6,C_fix(0));
t8=(C_word)C_slot(t6,C_fix(1));
t9=(C_word)C_eqp(t7,lf[80]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2622,a[2]=((C_word*)t0)[4],a[3]=t8,a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[3],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t11=((C_word*)((C_word*)t0)[8])[1];
if(C_truep(t11)){
t12=t10;
f_2622(t12,C_SCHEME_UNDEFINED);}
else{
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2641,a[2]=t10,a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 357  gensym */
t13=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,t12);}}
else{
t10=(C_word)C_eqp(t7,lf[79]);
if(C_truep(t10)){
if(C_truep((C_word)C_fixnum_less_or_equal_p(t2,C_fix(1)))){
t11=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2659,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[8],a[4]=t4,a[5]=t3,a[6]=t1,a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[7],a[9]=t8,tmp=(C_word)a,a+=10,tmp);
if(C_truep((C_word)C_i_pairp(t8))){
t12=(C_word)C_slot(t8,C_fix(0));
t13=t11;
f_2659(t13,(C_word)C_i_symbolp(t12));}
else{
t12=t11;
f_2659(t12,C_SCHEME_FALSE);}}
else{
/* eval.scm: 369  err */
t11=((C_word*)t0)[4];
f_2327(t11,t1,lf[97]);}}
else{
t11=(C_word)C_eqp(t7,lf[81]);
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2705,a[2]=((C_word*)t0)[4],a[3]=t8,a[4]=t4,a[5]=t3,a[6]=t1,a[7]=((C_word*)t0)[3],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
t13=((C_word*)((C_word*)t0)[8])[1];
if(C_truep(t13)){
t14=t12;
f_2705(t14,C_SCHEME_UNDEFINED);}
else{
t14=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2724,a[2]=t12,a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 371  gensym */
t15=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,t14);}}
else{
if(C_truep((C_word)C_i_symbolp(t7))){
t12=t2;
switch(t12){
case C_fix(0):
t13=(C_word)C_a_i_cons(&a,2,t7,t3);
/* eval.scm: 378  loop */
t34=t1;
t35=C_fix(0);
t36=t13;
t37=C_SCHEME_END_OF_LIST;
t38=C_SCHEME_END_OF_LIST;
t39=t8;
t1=t34;
t2=t35;
t3=t36;
t4=t37;
t5=t38;
t6=t39;
goto loop;
case C_fix(1):
t13=(C_word)C_a_i_list(&a,2,t7,C_SCHEME_FALSE);
t14=(C_word)C_a_i_cons(&a,2,t13,t4);
/* eval.scm: 379  loop */
t34=t1;
t35=C_fix(1);
t36=t3;
t37=t14;
t38=C_SCHEME_END_OF_LIST;
t39=t8;
t1=t34;
t2=t35;
t3=t36;
t4=t37;
t5=t38;
t6=t39;
goto loop;
case C_fix(2):
/* eval.scm: 380  err */
t13=((C_word*)t0)[4];
f_2327(t13,t1,lf[99]);
default:
t13=(C_word)C_a_i_list(&a,1,t7);
t14=(C_word)C_a_i_cons(&a,2,t13,t5);
/* eval.scm: 381  loop */
t34=t1;
t35=C_fix(3);
t36=t3;
t37=t4;
t38=t14;
t39=t8;
t1=t34;
t2=t35;
t3=t36;
t4=t37;
t5=t38;
t6=t39;
goto loop;}}
else{
t12=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2786,a[2]=t5,a[3]=t8,a[4]=t3,a[5]=((C_word*)t0)[3],a[6]=t4,a[7]=t7,a[8]=t1,a[9]=((C_word*)t0)[4],a[10]=t2,tmp=(C_word)a,a+=11,tmp);
if(C_truep((C_word)C_i_listp(t7))){
t13=(C_word)C_i_length(t7);
t14=t12;
f_2786(t14,(C_word)C_eqp(C_fix(2),t13));}
else{
t13=t12;
f_2786(t13,C_SCHEME_FALSE);}}}}}}
else{
/* eval.scm: 351  err */
t7=((C_word*)t0)[4];
f_2327(t7,t1,lf[103]);}}}}

/* k2784 in loop in ##sys#expand-extended-lambda-list in k1773 in k1731 in k1728 */
static void C_fcall f_2786(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2786,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[10];
switch(t2){
case C_fix(0):
/* eval.scm: 384  err */
t3=((C_word*)t0)[9];
f_2327(t3,((C_word*)t0)[8],lf[100]);
case C_fix(1):
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],((C_word*)t0)[6]);
/* eval.scm: 385  loop */
t4=((C_word*)((C_word*)t0)[5])[1];
f_2346(t4,((C_word*)t0)[8],C_fix(1),((C_word*)t0)[4],t3,C_SCHEME_END_OF_LIST,((C_word*)t0)[3]);
case C_fix(2):
/* eval.scm: 386  err */
t3=((C_word*)t0)[9];
f_2327(t3,((C_word*)t0)[8],lf[101]);
default:
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],((C_word*)t0)[2]);
/* eval.scm: 387  loop */
t4=((C_word*)((C_word*)t0)[5])[1];
f_2346(t4,((C_word*)t0)[8],C_fix(3),((C_word*)t0)[4],((C_word*)t0)[6],t3,((C_word*)t0)[3]);}}
else{
/* eval.scm: 388  err */
t2=((C_word*)t0)[9];
f_2327(t2,((C_word*)t0)[8],lf[102]);}}

/* k2722 in loop in ##sys#expand-extended-lambda-list in k1773 in k1731 in k1728 */
static void C_ccall f_2724(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_2705(t3,t2);}

/* k2703 in loop in ##sys#expand-extended-lambda-list in k1773 in k1731 in k1728 */
static void C_fcall f_2705(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_fixnum_less_or_equal_p(((C_word*)t0)[8],C_fix(3)))){
/* eval.scm: 373  loop */
t2=((C_word*)((C_word*)t0)[7])[1];
f_2346(t2,((C_word*)t0)[6],C_fix(3),((C_word*)t0)[5],((C_word*)t0)[4],C_SCHEME_END_OF_LIST,((C_word*)t0)[3]);}
else{
/* eval.scm: 374  err */
t2=((C_word*)t0)[2];
f_2327(t2,((C_word*)t0)[6],lf[98]);}}

/* k2657 in loop in ##sys#expand-extended-lambda-list in k1773 in k1731 in k1728 */
static void C_fcall f_2659(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2659,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2662,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
t3=((C_word*)((C_word*)t0)[3])[1];
if(C_truep(t3)){
t4=t2;
f_2662(t4,C_SCHEME_UNDEFINED);}
else{
t4=(C_word)C_slot(((C_word*)t0)[9],C_fix(0));
t5=C_mutate(((C_word *)((C_word*)t0)[3])+1,t4);
t6=t2;
f_2662(t6,t5);}}
else{
/* eval.scm: 368  err */
t2=((C_word*)t0)[2];
f_2327(t2,((C_word*)t0)[6],lf[96]);}}

/* k2660 in k2657 in loop in ##sys#expand-extended-lambda-list in k1773 in k1731 in k1728 */
static void C_fcall f_2662(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[7],C_fix(0));
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t4=(C_word)C_slot(((C_word*)t0)[7],C_fix(1));
/* eval.scm: 367  loop */
t5=((C_word*)((C_word*)t0)[5])[1];
f_2346(t5,((C_word*)t0)[4],C_fix(2),((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_END_OF_LIST,t4);}

/* k2639 in loop in ##sys#expand-extended-lambda-list in k1773 in k1731 in k1728 */
static void C_ccall f_2641(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_2622(t3,t2);}

/* k2620 in loop in ##sys#expand-extended-lambda-list in k1773 in k1731 in k1728 */
static void C_fcall f_2622(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(((C_word*)t0)[7],C_fix(0));
if(C_truep(t2)){
/* eval.scm: 359  loop */
t3=((C_word*)((C_word*)t0)[6])[1];
f_2346(t3,((C_word*)t0)[5],C_fix(1),((C_word*)t0)[4],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,((C_word*)t0)[3]);}
else{
/* eval.scm: 360  err */
t3=((C_word*)t0)[2];
f_2327(t3,((C_word*)t0)[5],lf[95]);}}

/* k2588 in loop in ##sys#expand-extended-lambda-list in k1773 in k1731 in k1728 */
static void C_fcall f_2590(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[7])+1,((C_word*)t0)[6]);
/* eval.scm: 349  loop */
t3=((C_word*)((C_word*)t0)[5])[1];
f_2346(t3,((C_word*)t0)[4],C_fix(4),((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}

/* k2567 in loop in ##sys#expand-extended-lambda-list in k1773 in k1731 in k1728 */
static void C_ccall f_2569(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 322  ##sys#append */
t2=*((C_word*)lf[88]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)((C_word*)t0)[2])[1]);}

/* k2358 in loop in ##sys#expand-extended-lambda-list in k1773 in k1731 in k1728 */
static void C_ccall f_2360(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[20],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2360,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2364,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[4]))){
t3=t2;
f_2364(t3,((C_word*)t0)[2]);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2503,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2505,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2562,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 333  reverse */
t6=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[4]);}}

/* k2560 in k2358 in loop in ##sys#expand-extended-lambda-list in k1773 in k1731 in k1728 */
static void C_ccall f_2562(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2504 in k2358 in loop in ##sys#expand-extended-lambda-list in k1773 in k1731 in k1728 */
static void C_ccall f_2505(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2505,3,t0,t1,t2);}
t3=(C_word)C_u_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2558,a[2]=t2,a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_slot(t3,C_fix(1));
/* eval.scm: 312  string->keyword */
t6=*((C_word*)lf[93]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}

/* k2556 in a2504 in k2358 in loop in ##sys#expand-extended-lambda-list in k1773 in k1731 in k1728 */
static void C_ccall f_2558(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[21],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2558,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[90],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2532,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_slot(((C_word*)t0)[2],C_fix(1));
if(C_truep((C_word)C_i_pairp(t4))){
t5=(C_word)C_slot(((C_word*)t0)[2],C_fix(1));
t6=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t5);
t7=(C_word)C_a_i_cons(&a,2,lf[92],t6);
t8=t3;
f_2532(t8,(C_word)C_a_i_list(&a,1,t7));}
else{
t5=t3;
f_2532(t5,C_SCHEME_END_OF_LIST);}}

/* k2530 in k2556 in a2504 in k2358 in loop in ##sys#expand-extended-lambda-list in k1773 in k1731 in k1728 */
static void C_fcall f_2532(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2532,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[5])[1],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=(C_word)C_a_i_cons(&a,2,lf[91],t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,2,((C_word*)t0)[2],t4));}

/* k2501 in k2358 in loop in ##sys#expand-extended-lambda-list in k1773 in k1731 in k1728 */
static void C_ccall f_2503(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2503,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[3]);
t3=(C_word)C_a_i_cons(&a,2,lf[89],t2);
t4=((C_word*)t0)[2];
f_2364(t4,(C_word)C_a_i_list(&a,1,t3));}

/* k2362 in k2358 in loop in ##sys#expand-extended-lambda-list in k1773 in k1731 in k1728 */
static void C_fcall f_2364(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2364,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2367,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[6]))){
t3=t2;
f_2367(t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2376,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=t1,a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
t4=((C_word*)((C_word*)t0)[4])[1];
if(C_truep(t4)){
t5=t3;
f_2376(t5,C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[3]))){
t5=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t6=t3;
f_2376(t6,(C_word)C_i_nullp(t5));}
else{
t5=t3;
f_2376(t5,C_SCHEME_FALSE);}}}}

/* k2374 in k2362 in k2358 in loop in ##sys#expand-extended-lambda-list in k1773 in k1731 in k1728 */
static void C_fcall f_2376(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[42],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2376,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_u_i_caar(((C_word*)t0)[8]);
t3=(C_word)C_u_i_cadar(((C_word*)t0)[8]);
t4=(C_word)C_a_i_list(&a,3,lf[85],((C_word*)((C_word*)t0)[7])[1],t3);
t5=(C_word)C_a_i_list(&a,2,t2,t4);
t6=(C_word)C_a_i_list(&a,1,t5);
t7=(C_word)C_a_i_cons(&a,2,t6,((C_word*)t0)[6]);
t8=(C_word)C_a_i_cons(&a,2,lf[58],t7);
t9=((C_word*)t0)[5];
f_2367(t9,(C_word)C_a_i_list(&a,1,t8));}
else{
t2=((C_word*)((C_word*)t0)[4])[1];
t3=(C_truep(t2)?C_SCHEME_FALSE:(C_word)C_i_nullp(((C_word*)t0)[3]));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2432,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 339  reverse */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[8]);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2451,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2455,a[2]=t4,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 341  reverse */
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[8]);}}}

/* k2453 in k2374 in k2362 in k2358 in loop in ##sys#expand-extended-lambda-list in k1773 in k1731 in k1728 */
static void C_ccall f_2455(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2455,2,t0,t1);}
t2=((C_word*)((C_word*)t0)[4])[1];
t3=(C_truep(t2)?t2:((C_word*)((C_word*)t0)[3])[1]);
t4=(C_word)C_a_i_list(&a,1,t3);
/* eval.scm: 341  ##sys#append */
t5=*((C_word*)lf[88]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,((C_word*)t0)[2],t1,t4);}

/* k2449 in k2374 in k2362 in k2358 in loop in ##sys#expand-extended-lambda-list in k1773 in k1731 in k1728 */
static void C_ccall f_2451(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2451,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[4]);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[3])[1],t2);
t4=(C_word)C_a_i_cons(&a,2,lf[87],t3);
t5=((C_word*)t0)[2];
f_2367(t5,(C_word)C_a_i_list(&a,1,t4));}

/* k2430 in k2374 in k2362 in k2358 in loop in ##sys#expand-extended-lambda-list in k1773 in k1731 in k1728 */
static void C_ccall f_2432(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2432,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[4]);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[3])[1],t2);
t4=(C_word)C_a_i_cons(&a,2,lf[86],t3);
t5=((C_word*)t0)[2];
f_2367(t5,(C_word)C_a_i_list(&a,1,t4));}

/* k2365 in k2362 in k2358 in loop in ##sys#expand-extended-lambda-list in k1773 in k1731 in k1728 */
static void C_fcall f_2367(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 321  values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* err in ##sys#expand-extended-lambda-list in k1773 in k1731 in k1728 */
static void C_fcall f_2327(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2327,NULL,3,t0,t1,t2);}
/* eval.scm: 311  errh */
t3=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,((C_word*)t0)[2]);}

/* ##sys#extended-lambda-list? in k1773 in k1731 in k1728 */
static void C_ccall f_2281(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2281,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2287,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_2287(t6,t1,t2);}

/* loop in ##sys#extended-lambda-list? in k1773 in k1731 in k1728 */
static void C_fcall f_2287(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2287,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_eqp(t3,lf[79]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2306,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t4)){
t6=t5;
f_2306(t6,t4);}
else{
t6=(C_word)C_eqp(t3,lf[80]);
t7=t5;
f_2306(t7,(C_truep(t6)?t6:(C_word)C_eqp(t3,lf[81])));}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k2304 in loop in ##sys#extended-lambda-list? in k1773 in k1731 in k1728 */
static void C_fcall f_2306(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* eval.scm: 305  loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_2287(t3,((C_word*)t0)[4],t2);}}

/* macroexpand-1 in k1773 in k1731 in k1728 */
static void C_ccall f_2265(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3rv,(void*)f_2265r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_2265r(t0,t1,t2,t3);}}

static void C_ccall f_2265r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
t4=(C_word)C_notvemptyp(t3);
t5=(C_truep(t4)?(C_word)C_slot(t3,C_fix(0)):C_SCHEME_END_OF_LIST);
/* eval.scm: 285  ##sys#macroexpand-0 */
t6=*((C_word*)lf[46]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t1,t2,t5);}

/* macroexpand in k1773 in k1731 in k1728 */
static void C_ccall f_2229(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr3rv,(void*)f_2229r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_2229r(t0,t1,t2,t3);}}

static void C_ccall f_2229r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a=C_alloc(6);
t4=(C_word)C_notvemptyp(t3);
t5=(C_truep(t4)?(C_word)C_slot(t3,C_fix(0)):C_SCHEME_END_OF_LIST);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2238,a[2]=t7,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_2238(t9,t1,t2);}

/* loop in macroexpand in k1773 in k1731 in k1728 */
static void C_fcall f_2238(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2238,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2244,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2250,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t3,t4);}

/* a2249 in loop in macroexpand in k1773 in k1731 in k1728 */
static void C_ccall f_2250(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2250,4,t0,t1,t2,t3);}
if(C_truep(t3)){
/* eval.scm: 281  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_2238(t4,t1,t2);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}}

/* a2243 in loop in macroexpand in k1773 in k1731 in k1728 */
static void C_ccall f_2244(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2244,2,t0,t1);}
/* eval.scm: 279  ##sys#macroexpand-0 */
t2=*((C_word*)lf[46]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##sys#macroexpand-1-local in k1773 in k1731 in k1728 */
static void C_ccall f_2222(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2222,4,t0,t1,t2,t3);}
/* eval.scm: 266  ##sys#macroexpand-0 */
t4=*((C_word*)lf[46]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t2,t3);}

/* ##sys#interpreter-toplevel-macroexpand-hook in k1773 in k1731 in k1728 */
static void C_ccall f_2219(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2219,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* ##sys#compiler-toplevel-macroexpand-hook in k1773 in k1731 in k1728 */
static void C_ccall f_2216(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2216,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* ##sys#macroexpand-0 in k1773 in k1731 in k1728 */
static void C_ccall f_1846(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1846,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1849,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1995,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t6=(C_word)C_slot(t2,C_fix(0));
t7=(C_word)C_slot(t2,C_fix(1));
if(C_truep((C_word)C_i_symbolp(t6))){
t8=(C_word)C_eqp(t6,lf[58]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2083,a[2]=t2,a[3]=t1,a[4]=t7,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 235  ##sys#check-syntax */
t10=*((C_word*)lf[64]+1);
((C_proc5)(void*)(*((C_word*)t10+1)))(5,t10,t9,lf[58],t7,lf[66]);}
else{
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2156,a[2]=t6,a[3]=t2,a[4]=t5,a[5]=t1,a[6]=t7,tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_truep((C_word)C_eqp(t6,lf[69]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t6,lf[71]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
if(C_truep((C_word)C_i_pairp(t7))){
t10=(C_word)C_slot(t7,C_fix(0));
t11=t9;
f_2156(t11,(C_word)C_i_pairp(t10));}
else{
t10=t9;
f_2156(t10,C_SCHEME_FALSE);}}
else{
t10=t9;
f_2156(t10,C_SCHEME_FALSE);}}}
else{
/* eval.scm: 258  values */
C_values(4,0,t1,t2,C_SCHEME_FALSE);}}
else{
/* eval.scm: 259  values */
C_values(4,0,t1,t2,C_SCHEME_FALSE);}}

/* k2154 in ##sys#macroexpand-0 in k1773 in k1731 in k1728 */
static void C_fcall f_2156(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2156,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(0));
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2162,a[2]=((C_word*)t0)[6],a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 251  ##sys#check-syntax */
t4=*((C_word*)lf[64]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,lf[69],((C_word*)t0)[6],lf[70]);}
else{
/* eval.scm: 257  expand */
t2=((C_word*)t0)[4];
f_1995(t2,((C_word*)t0)[5],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k2160 in k2154 in ##sys#macroexpand-0 in k1773 in k1731 in k1728 */
static void C_ccall f_2162(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2162,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2169,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(0));
t4=(C_word)C_a_i_list(&a,2,lf[67],t3);
t5=(C_word)C_a_i_list(&a,1,t4);
t6=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
t7=(C_word)C_slot(((C_word*)t0)[2],C_fix(1));
/* eval.scm: 253  append */
t8=*((C_word*)lf[68]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t2,t5,t6,t7);}

/* k2167 in k2160 in k2154 in ##sys#macroexpand-0 in k1773 in k1731 in k1728 */
static void C_ccall f_2169(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 252  values */
C_values(4,0,((C_word*)t0)[2],t1,C_SCHEME_TRUE);}

/* k2081 in ##sys#macroexpand-0 in k1773 in k1731 in k1728 */
static void C_ccall f_2083(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2083,2,t0,t1);}
t2=(C_word)C_u_i_car(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_symbolp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2095,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 238  ##sys#check-syntax */
t4=*((C_word*)lf[64]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,lf[58],((C_word*)t0)[4],lf[65]);}
else{
/* eval.scm: 246  values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}}

/* k2093 in k2081 in ##sys#macroexpand-0 in k1773 in k1731 in k1728 */
static void C_ccall f_2095(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2095,2,t0,t1);}
t2=(C_word)C_u_i_cadr(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2137,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2143,tmp=(C_word)a,a+=2,tmp);
/* map */
t5=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,t2);}

/* a2142 in k2093 in k2081 in ##sys#macroexpand-0 in k1773 in k1731 in k1728 */
static void C_ccall f_2143(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2143,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_u_i_car(t2));}

/* k2135 in k2093 in k2081 in ##sys#macroexpand-0 in k1773 in k1731 in k1728 */
static void C_ccall f_2137(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[28],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2137,2,t0,t1);}
t2=(C_word)C_u_i_cddr(((C_word*)t0)[5]);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,lf[59],t3);
t5=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t4);
t6=(C_word)C_a_i_list(&a,1,t5);
t7=(C_word)C_a_i_list(&a,3,lf[60],t6,((C_word*)t0)[4]);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2117,a[2]=((C_word*)t0)[3],a[3]=t7,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 244  ##sys#map */
t9=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t8,*((C_word*)lf[63]+1),((C_word*)t0)[2]);}

/* k2115 in k2135 in k2093 in k2081 in ##sys#macroexpand-0 in k1773 in k1731 in k1728 */
static void C_ccall f_2117(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2117,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[61],t2);
/* eval.scm: 240  values */
C_values(4,0,((C_word*)t0)[2],t3,C_SCHEME_TRUE);}

/* expand in ##sys#macroexpand-0 in k1773 in k1731 in k1728 */
static void C_fcall f_1995(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1995,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_u_i_assq(t3,((C_word*)t0)[3]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2009,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=(C_word)C_slot(t4,C_fix(1));
t7=t6;
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t5,t2);}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2015,a[2]=t1,a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 219  ##sys#hash-table-ref */
t6=*((C_word*)lf[42]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,*((C_word*)lf[37]+1),t3);}}

/* k2013 in expand in ##sys#macroexpand-0 in k1773 in k1731 in k1728 */
static void C_ccall f_2015(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2015,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2023,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_2023(t5,((C_word*)t0)[2],((C_word*)t0)[3]);}
else{
/* eval.scm: 228  values */
C_values(4,0,((C_word*)t0)[2],((C_word*)t0)[3],C_SCHEME_FALSE);}}

/* scan in k2013 in expand in ##sys#macroexpand-0 in k1773 in k1731 in k1728 */
static void C_fcall f_2023(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
loop:
a=C_alloc(3);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2023,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2037,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 225  call-handler */
t4=((C_word*)t0)[6];
f_1849(t4,t3,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(1));
/* eval.scm: 226  scan */
t6=t1;
t7=t3;
t1=t6;
t2=t7;
goto loop;}
else{
/* eval.scm: 227  ##sys#syntax-error-hook */
t3=*((C_word*)lf[56]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,lf[57],((C_word*)t0)[3]);}}}

/* k2035 in scan in k2013 in expand in ##sys#macroexpand-0 in k1773 in k1731 in k1728 */
static void C_ccall f_2037(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 225  values */
C_values(4,0,((C_word*)t0)[2],t1,C_SCHEME_TRUE);}

/* k2007 in expand in ##sys#macroexpand-0 in k1773 in k1731 in k1728 */
static void C_ccall f_2009(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 218  values */
C_values(4,0,((C_word*)t0)[2],t1,C_SCHEME_TRUE);}

/* call-handler in ##sys#macroexpand-0 in k1773 in k1731 in k1728 */
static void C_fcall f_1849(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1849,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1856,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1858,a[2]=t4,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* call-with-current-continuation */
t7=*((C_word*)lf[55]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t5,t6);}

/* a1857 in call-handler in ##sys#macroexpand-0 in k1773 in k1731 in k1728 */
static void C_ccall f_1858(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1858,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1864,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1971,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* with-exception-handler */
t5=*((C_word*)lf[54]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t3,t4);}

/* a1970 in a1857 in call-handler in ##sys#macroexpand-0 in k1773 in k1731 in k1728 */
static void C_ccall f_1971(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1971,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1977,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1983,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t2,t3);}

/* a1982 in a1970 in a1857 in call-handler in ##sys#macroexpand-0 in k1773 in k1731 in k1728 */
static void C_ccall f_1983(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_1983r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1983r(t0,t1,t2);}}

static void C_ccall f_1983r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1989,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* g4547 */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}

/* a1988 in a1982 in a1970 in a1857 in call-handler in ##sys#macroexpand-0 in k1773 in k1731 in k1728 */
static void C_ccall f_1989(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1989,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a1976 in a1970 in a1857 in call-handler in ##sys#macroexpand-0 in k1773 in k1731 in k1728 */
static void C_ccall f_1977(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1977,2,t0,t1);}
/* eval.scm: 215  handler */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* a1863 in a1857 in call-handler in ##sys#macroexpand-0 in k1773 in k1731 in k1728 */
static void C_ccall f_1864(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1864,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1870,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* g4547 */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}

/* a1869 in a1863 in a1857 in call-handler in ##sys#macroexpand-0 in k1773 in k1731 in k1728 */
static void C_ccall f_1870(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1870,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1878,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1881,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_structurep(((C_word*)t0)[4],lf[48]))){
t4=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t5=t3;
f_1881(t5,(C_word)C_i_memv(lf[53],t4));}
else{
t4=t3;
f_1881(t4,C_SCHEME_FALSE);}}

/* k1879 in a1869 in a1863 in a1857 in call-handler in ##sys#macroexpand-0 in k1773 in k1731 in k1728 */
static void C_fcall f_1881(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1881,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1892,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_slot(((C_word*)t0)[5],C_fix(2));
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1898,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_1898(t8,t3,t4);}
else{
t2=((C_word*)t0)[4];
f_1878(t2,((C_word*)t0)[5]);}}

/* copy in k1879 in a1869 in a1863 in a1857 in call-handler in ##sys#macroexpand-0 in k1773 in k1731 in k1728 */
static void C_fcall f_1898(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1898,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1917,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_equalp(lf[52],t3))){
if(C_truep((C_word)C_i_pairp(t4))){
t6=(C_word)C_u_i_car(t4);
t7=t5;
f_1917(t7,(C_word)C_i_stringp(t6));}
else{
t6=t5;
f_1917(t6,C_SCHEME_FALSE);}}
else{
t6=t5;
f_1917(t6,C_SCHEME_FALSE);}}}

/* k1915 in copy in k1879 in a1869 in a1863 in a1857 in call-handler in ##sys#macroexpand-0 in k1773 in k1731 in k1728 */
static void C_fcall f_1917(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1917,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1928,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t4=(C_word)C_u_i_car(((C_word*)t0)[6]);
/* eval.scm: 209  string-append */
t5=((C_word*)t0)[3];
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t2,lf[50],t3,lf[51],t4);}
else{
/* eval.scm: 213  copy */
t2=((C_word*)((C_word*)t0)[2])[1];
f_1898(t2,((C_word*)t0)[5],((C_word*)t0)[6]);}}

/* k1926 in k1915 in copy in k1879 in a1869 in a1863 in a1857 in call-handler in ##sys#macroexpand-0 in k1773 in k1731 in k1728 */
static void C_ccall f_1928(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1928,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[49],t3));}

/* k1890 in k1879 in a1869 in a1863 in a1857 in call-handler in ##sys#macroexpand-0 in k1773 in k1731 in k1728 */
static void C_ccall f_1892(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1892,2,t0,t1);}
t2=((C_word*)t0)[3];
f_1878(t2,(C_word)C_a_i_record(&a,3,lf[48],((C_word*)t0)[2],t1));}

/* k1876 in a1869 in a1863 in a1857 in call-handler in ##sys#macroexpand-0 in k1773 in k1731 in k1728 */
static void C_fcall f_1878(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 193  ##sys#abort */
t2=*((C_word*)lf[47]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1854 in call-handler in ##sys#macroexpand-0 in k1773 in k1731 in k1728 */
static void C_ccall f_1856(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* undefine-macro! in k1773 in k1731 in k1728 */
static void C_ccall f_1837(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1837,3,t0,t1,t2);}
t3=(C_word)C_i_check_symbol_2(t2,lf[44]);
t4=t2;
/* eval.scm: 178  ##sys#hash-table-set! */
t5=*((C_word*)lf[39]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,*((C_word*)lf[37]+1),t4,C_SCHEME_FALSE);}

/* macro? in k1773 in k1731 in k1728 */
static void C_ccall f_1819(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1819,3,t0,t1,t2);}
t3=(C_word)C_i_check_symbol_2(t2,lf[43]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1829,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 175  ##sys#hash-table-ref */
t5=*((C_word*)lf[42]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,*((C_word*)lf[37]+1),t2);}

/* k1827 in macro? in k1773 in k1731 in k1728 */
static void C_ccall f_1829(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?C_SCHEME_TRUE:C_SCHEME_FALSE));}

/* ##sys#copy-macro in k1773 in k1731 in k1728 */
static void C_ccall f_1809(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1809,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1817,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 171  ##sys#hash-table-ref */
t5=*((C_word*)lf[42]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,*((C_word*)lf[37]+1),t2);}

/* k1815 in ##sys#copy-macro in k1773 in k1731 in k1728 */
static void C_ccall f_1817(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 171  ##sys#hash-table-set! */
t2=*((C_word*)lf[39]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],*((C_word*)lf[37]+1),((C_word*)t0)[2],t1);}

/* ##sys#register-macro in k1773 in k1731 in k1728 */
static void C_ccall f_1793(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1793,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1799,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 166  ##sys#hash-table-set! */
t5=*((C_word*)lf[39]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,*((C_word*)lf[37]+1),t2,t4);}

/* a1798 in ##sys#register-macro in k1773 in k1731 in k1728 */
static void C_ccall f_1799(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1799,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(1));
C_apply(4,0,t1,((C_word*)t0)[2],t3);}

/* ##sys#register-macro-2 in k1773 in k1731 in k1728 */
static void C_ccall f_1777(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1777,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1783,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 160  ##sys#hash-table-set! */
t5=*((C_word*)lf[39]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,*((C_word*)lf[37]+1),t2,t4);}

/* a1782 in ##sys#register-macro-2 in k1773 in k1731 in k1728 */
static void C_ccall f_1783(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1783,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(1));
/* eval.scm: 162  handler */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}

/* chicken-home in k1731 in k1728 */
static void C_ccall f_1761(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1761,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1765,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 151  ##sys#chicken-prefix */
t3=*((C_word*)lf[31]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[36]);}

/* k1763 in chicken-home in k1731 in k1728 */
static void C_ccall f_1765(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1765,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
/* ##sys#peek-c-string */
t2=*((C_word*)lf[35]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_mpointer(&a,(void*)C_INSTALL_SHARE_HOME),C_fix(0));}}

/* ##sys#chicken-prefix in k1731 in k1728 */
static void C_ccall f_1734(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2rv,(void*)f_1734r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_1734r(t0,t1,t2);}}

static void C_ccall f_1734r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
t3=(C_word)C_vemptyp(t2);
t4=(C_truep(t3)?C_SCHEME_FALSE:(C_word)C_slot(t2,C_fix(0)));
if(C_truep(((C_word*)t0)[2])){
if(C_truep(t4)){
/* eval.scm: 143  ##sys#string-append */
t5=*((C_word*)lf[32]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,((C_word*)t0)[2],t4);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,((C_word*)t0)[2]);}}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[937] = {
{"topleveleval.scm",(void*)C_eval_toplevel},
{"f_1730eval.scm",(void*)f_1730},
{"f_1733eval.scm",(void*)f_1733},
{"f_1775eval.scm",(void*)f_1775},
{"f_11451eval.scm",(void*)f_11451},
{"f_11455eval.scm",(void*)f_11455},
{"f_11479eval.scm",(void*)f_11479},
{"f_11473eval.scm",(void*)f_11473},
{"f_11463eval.scm",(void*)f_11463},
{"f_11461eval.scm",(void*)f_11461},
{"f_6065eval.scm",(void*)f_6065},
{"f_6164eval.scm",(void*)f_6164},
{"f_6244eval.scm",(void*)f_6244},
{"f_11445eval.scm",(void*)f_11445},
{"f_11441eval.scm",(void*)f_11441},
{"f_11437eval.scm",(void*)f_11437},
{"f_11433eval.scm",(void*)f_11433},
{"f_11423eval.scm",(void*)f_11423},
{"f_6763eval.scm",(void*)f_6763},
{"f_6768eval.scm",(void*)f_6768},
{"f_11401eval.scm",(void*)f_11401},
{"f_11393eval.scm",(void*)f_11393},
{"f_11395eval.scm",(void*)f_11395},
{"f_6775eval.scm",(void*)f_6775},
{"f_11362eval.scm",(void*)f_11362},
{"f_11382eval.scm",(void*)f_11382},
{"f_11378eval.scm",(void*)f_11378},
{"f_11368eval.scm",(void*)f_11368},
{"f_11365eval.scm",(void*)f_11365},
{"f_7128eval.scm",(void*)f_7128},
{"f_11308eval.scm",(void*)f_11308},
{"f_11322eval.scm",(void*)f_11322},
{"f_11358eval.scm",(void*)f_11358},
{"f_11354eval.scm",(void*)f_11354},
{"f_11342eval.scm",(void*)f_11342},
{"f_11346eval.scm",(void*)f_11346},
{"f_11316eval.scm",(void*)f_11316},
{"f_7847eval.scm",(void*)f_7847},
{"f_11187eval.scm",(void*)f_11187},
{"f_11224eval.scm",(void*)f_11224},
{"f_11233eval.scm",(void*)f_11233},
{"f_11252eval.scm",(void*)f_11252},
{"f_11256eval.scm",(void*)f_11256},
{"f_11242eval.scm",(void*)f_11242},
{"f_11239eval.scm",(void*)f_11239},
{"f_11190eval.scm",(void*)f_11190},
{"f_7850eval.scm",(void*)f_7850},
{"f_7908eval.scm",(void*)f_7908},
{"f_11185eval.scm",(void*)f_11185},
{"f_8243eval.scm",(void*)f_8243},
{"f_8247eval.scm",(void*)f_8247},
{"f_11181eval.scm",(void*)f_11181},
{"f_8250eval.scm",(void*)f_8250},
{"f_8254eval.scm",(void*)f_8254},
{"f_11084eval.scm",(void*)f_11084},
{"f_11090eval.scm",(void*)f_11090},
{"f_11106eval.scm",(void*)f_11106},
{"f_11109eval.scm",(void*)f_11109},
{"f_11144eval.scm",(void*)f_11144},
{"f_11147eval.scm",(void*)f_11147},
{"f_11131eval.scm",(void*)f_11131},
{"f_11134eval.scm",(void*)f_11134},
{"f_11141eval.scm",(void*)f_11141},
{"f_8937eval.scm",(void*)f_8937},
{"f_11056eval.scm",(void*)f_11056},
{"f_8940eval.scm",(void*)f_8940},
{"f_11013eval.scm",(void*)f_11013},
{"f_11035eval.scm",(void*)f_11035},
{"f_8943eval.scm",(void*)f_8943},
{"f_10816eval.scm",(void*)f_10816},
{"f_10822eval.scm",(void*)f_10822},
{"f_10838eval.scm",(void*)f_10838},
{"f_10914eval.scm",(void*)f_10914},
{"f_10971eval.scm",(void*)f_10971},
{"f_10917eval.scm",(void*)f_10917},
{"f_10944eval.scm",(void*)f_10944},
{"f_10877eval.scm",(void*)f_10877},
{"f_10896eval.scm",(void*)f_10896},
{"f_10868eval.scm",(void*)f_10868},
{"f_8946eval.scm",(void*)f_8946},
{"f_10713eval.scm",(void*)f_10713},
{"f_10723eval.scm",(void*)f_10723},
{"f_10736eval.scm",(void*)f_10736},
{"f_10752eval.scm",(void*)f_10752},
{"f_10790eval.scm",(void*)f_10790},
{"f_10788eval.scm",(void*)f_10788},
{"f_10780eval.scm",(void*)f_10780},
{"f_10734eval.scm",(void*)f_10734},
{"f_8949eval.scm",(void*)f_8949},
{"f_10660eval.scm",(void*)f_10660},
{"f_10670eval.scm",(void*)f_10670},
{"f_10673eval.scm",(void*)f_10673},
{"f_10678eval.scm",(void*)f_10678},
{"f_10703eval.scm",(void*)f_10703},
{"f_8952eval.scm",(void*)f_8952},
{"f_10590eval.scm",(void*)f_10590},
{"f_10600eval.scm",(void*)f_10600},
{"f_10603eval.scm",(void*)f_10603},
{"f_10650eval.scm",(void*)f_10650},
{"f_10614eval.scm",(void*)f_10614},
{"f_10636eval.scm",(void*)f_10636},
{"f_10622eval.scm",(void*)f_10622},
{"f_10618eval.scm",(void*)f_10618},
{"f_8955eval.scm",(void*)f_8955},
{"f_10471eval.scm",(void*)f_10471},
{"f_10475eval.scm",(void*)f_10475},
{"f_10478eval.scm",(void*)f_10478},
{"f_10481eval.scm",(void*)f_10481},
{"f_10572eval.scm",(void*)f_10572},
{"f_10488eval.scm",(void*)f_10488},
{"f_10511eval.scm",(void*)f_10511},
{"f_10525eval.scm",(void*)f_10525},
{"f_10523eval.scm",(void*)f_10523},
{"f_8958eval.scm",(void*)f_8958},
{"f_10179eval.scm",(void*)f_10179},
{"f_10389eval.scm",(void*)f_10389},
{"f_10393eval.scm",(void*)f_10393},
{"f_10414eval.scm",(void*)f_10414},
{"f_10456eval.scm",(void*)f_10456},
{"f_10192eval.scm",(void*)f_10192},
{"f_10380eval.scm",(void*)f_10380},
{"f_10384eval.scm",(void*)f_10384},
{"f_10363eval.scm",(void*)f_10363},
{"f_10367eval.scm",(void*)f_10367},
{"f_10352eval.scm",(void*)f_10352},
{"f_10344eval.scm",(void*)f_10344},
{"f_10333eval.scm",(void*)f_10333},
{"f_10299eval.scm",(void*)f_10299},
{"f_10280eval.scm",(void*)f_10280},
{"f_10253eval.scm",(void*)f_10253},
{"f_10210eval.scm",(void*)f_10210},
{"f_10206eval.scm",(void*)f_10206},
{"f_10182eval.scm",(void*)f_10182},
{"f_10190eval.scm",(void*)f_10190},
{"f_8961eval.scm",(void*)f_8961},
{"f_10169eval.scm",(void*)f_10169},
{"f_8964eval.scm",(void*)f_8964},
{"f_9923eval.scm",(void*)f_9923},
{"f_10078eval.scm",(void*)f_10078},
{"f_10149eval.scm",(void*)f_10149},
{"f_10094eval.scm",(void*)f_10094},
{"f_10092eval.scm",(void*)f_10092},
{"f_9936eval.scm",(void*)f_9936},
{"f_10062eval.scm",(void*)f_10062},
{"f_10024eval.scm",(void*)f_10024},
{"f_9985eval.scm",(void*)f_9985},
{"f_9926eval.scm",(void*)f_9926},
{"f_8967eval.scm",(void*)f_8967},
{"f_8971eval.scm",(void*)f_8971},
{"f_9920eval.scm",(void*)f_9920},
{"f_8993eval.scm",(void*)f_8993},
{"f_9353eval.scm",(void*)f_9353},
{"f_9778eval.scm",(void*)f_9778},
{"f_9896eval.scm",(void*)f_9896},
{"f_9899eval.scm",(void*)f_9899},
{"f_9886eval.scm",(void*)f_9886},
{"f_9781eval.scm",(void*)f_9781},
{"f_9785eval.scm",(void*)f_9785},
{"f_9796eval.scm",(void*)f_9796},
{"f_9439eval.scm",(void*)f_9439},
{"f_9759eval.scm",(void*)f_9759},
{"f_9763eval.scm",(void*)f_9763},
{"f_9772eval.scm",(void*)f_9772},
{"f_9770eval.scm",(void*)f_9770},
{"f_9442eval.scm",(void*)f_9442},
{"f_9753eval.scm",(void*)f_9753},
{"f_9445eval.scm",(void*)f_9445},
{"f_9747eval.scm",(void*)f_9747},
{"f_9448eval.scm",(void*)f_9448},
{"f_9738eval.scm",(void*)f_9738},
{"f_9745eval.scm",(void*)f_9745},
{"f_9728eval.scm",(void*)f_9728},
{"f_9713eval.scm",(void*)f_9713},
{"f_9717eval.scm",(void*)f_9717},
{"f_9722eval.scm",(void*)f_9722},
{"f_9726eval.scm",(void*)f_9726},
{"f_9691eval.scm",(void*)f_9691},
{"f_9695eval.scm",(void*)f_9695},
{"f_9700eval.scm",(void*)f_9700},
{"f_9704eval.scm",(void*)f_9704},
{"f_9711eval.scm",(void*)f_9711},
{"f_9665eval.scm",(void*)f_9665},
{"f_9671eval.scm",(void*)f_9671},
{"f_9675eval.scm",(void*)f_9675},
{"f_9689eval.scm",(void*)f_9689},
{"f_9678eval.scm",(void*)f_9678},
{"f_9685eval.scm",(void*)f_9685},
{"f_9649eval.scm",(void*)f_9649},
{"f_9655eval.scm",(void*)f_9655},
{"f_9663eval.scm",(void*)f_9663},
{"f_9612eval.scm",(void*)f_9612},
{"f_9616eval.scm",(void*)f_9616},
{"f_9621eval.scm",(void*)f_9621},
{"f_9625eval.scm",(void*)f_9625},
{"f_9647eval.scm",(void*)f_9647},
{"f_9643eval.scm",(void*)f_9643},
{"f_9639eval.scm",(void*)f_9639},
{"f_9628eval.scm",(void*)f_9628},
{"f_9635eval.scm",(void*)f_9635},
{"f_9586eval.scm",(void*)f_9586},
{"f_9592eval.scm",(void*)f_9592},
{"f_9596eval.scm",(void*)f_9596},
{"f_9610eval.scm",(void*)f_9610},
{"f_9599eval.scm",(void*)f_9599},
{"f_9606eval.scm",(void*)f_9606},
{"f_9573eval.scm",(void*)f_9573},
{"f_9547eval.scm",(void*)f_9547},
{"f_9551eval.scm",(void*)f_9551},
{"f_9556eval.scm",(void*)f_9556},
{"f_9560eval.scm",(void*)f_9560},
{"f_9571eval.scm",(void*)f_9571},
{"f_9567eval.scm",(void*)f_9567},
{"f_9531eval.scm",(void*)f_9531},
{"f_9537eval.scm",(void*)f_9537},
{"f_9545eval.scm",(void*)f_9545},
{"f_9519eval.scm",(void*)f_9519},
{"f_9525eval.scm",(void*)f_9525},
{"f_9529eval.scm",(void*)f_9529},
{"f_9510eval.scm",(void*)f_9510},
{"f_9514eval.scm",(void*)f_9514},
{"f_9451eval.scm",(void*)f_9451},
{"f_9461eval.scm",(void*)f_9461},
{"f_9486eval.scm",(void*)f_9486},
{"f_9498eval.scm",(void*)f_9498},
{"f_9504eval.scm",(void*)f_9504},
{"f_9492eval.scm",(void*)f_9492},
{"f_9467eval.scm",(void*)f_9467},
{"f_9473eval.scm",(void*)f_9473},
{"f_9477eval.scm",(void*)f_9477},
{"f_9480eval.scm",(void*)f_9480},
{"f_9484eval.scm",(void*)f_9484},
{"f_9459eval.scm",(void*)f_9459},
{"f_9364eval.scm",(void*)f_9364},
{"f_9374eval.scm",(void*)f_9374},
{"f_9377eval.scm",(void*)f_9377},
{"f_9391eval.scm",(void*)f_9391},
{"f_9409eval.scm",(void*)f_9409},
{"f_9378eval.scm",(void*)f_9378},
{"f_9355eval.scm",(void*)f_9355},
{"f_9014eval.scm",(void*)f_9014},
{"f_9058eval.scm",(void*)f_9058},
{"f_9061eval.scm",(void*)f_9061},
{"f_9338eval.scm",(void*)f_9338},
{"f_9342eval.scm",(void*)f_9342},
{"f_9346eval.scm",(void*)f_9346},
{"f_9143eval.scm",(void*)f_9143},
{"f_9149eval.scm",(void*)f_9149},
{"f_9321eval.scm",(void*)f_9321},
{"f_9327eval.scm",(void*)f_9327},
{"f_9156eval.scm",(void*)f_9156},
{"f_9159eval.scm",(void*)f_9159},
{"f_9162eval.scm",(void*)f_9162},
{"f_9316eval.scm",(void*)f_9316},
{"f_9171eval.scm",(void*)f_9171},
{"f_9174eval.scm",(void*)f_9174},
{"f_9189eval.scm",(void*)f_9189},
{"f_9207eval.scm",(void*)f_9207},
{"f_9270eval.scm",(void*)f_9270},
{"f_9223eval.scm",(void*)f_9223},
{"f_9228eval.scm",(void*)f_9228},
{"f_9232eval.scm",(void*)f_9232},
{"f_9235eval.scm",(void*)f_9235},
{"f_9247eval.scm",(void*)f_9247},
{"f_9250eval.scm",(void*)f_9250},
{"f_9238eval.scm",(void*)f_9238},
{"f_9211eval.scm",(void*)f_9211},
{"f_9193eval.scm",(void*)f_9193},
{"f_9039eval.scm",(void*)f_9039},
{"f_9044eval.scm",(void*)f_9044},
{"f_9196eval.scm",(void*)f_9196},
{"f_9180eval.scm",(void*)f_9180},
{"f_9078eval.scm",(void*)f_9078},
{"f_9083eval.scm",(void*)f_9083},
{"f_9086eval.scm",(void*)f_9086},
{"f_9091eval.scm",(void*)f_9091},
{"f_9098eval.scm",(void*)f_9098},
{"f_9138eval.scm",(void*)f_9138},
{"f_9101eval.scm",(void*)f_9101},
{"f_9113eval.scm",(void*)f_9113},
{"f_9122eval.scm",(void*)f_9122},
{"f_9116eval.scm",(void*)f_9116},
{"f_9104eval.scm",(void*)f_9104},
{"f_9107eval.scm",(void*)f_9107},
{"f_9069eval.scm",(void*)f_9069},
{"f_9063eval.scm",(void*)f_9063},
{"f_9017eval.scm",(void*)f_9017},
{"f_9023eval.scm",(void*)f_9023},
{"f_9011eval.scm",(void*)f_9011},
{"f_8995eval.scm",(void*)f_8995},
{"f_9009eval.scm",(void*)f_9009},
{"f_9006eval.scm",(void*)f_9006},
{"f_8999eval.scm",(void*)f_8999},
{"f_8976eval.scm",(void*)f_8976},
{"f_8985eval.scm",(void*)f_8985},
{"f_8980eval.scm",(void*)f_8980},
{"f_8545eval.scm",(void*)f_8545},
{"f_8682eval.scm",(void*)f_8682},
{"f_8687eval.scm",(void*)f_8687},
{"f_8905eval.scm",(void*)f_8905},
{"f_8886eval.scm",(void*)f_8886},
{"f_8832eval.scm",(void*)f_8832},
{"f_8703eval.scm",(void*)f_8703},
{"f_8708eval.scm",(void*)f_8708},
{"f_8727eval.scm",(void*)f_8727},
{"f_8653eval.scm",(void*)f_8653},
{"f_8659eval.scm",(void*)f_8659},
{"f_8591eval.scm",(void*)f_8591},
{"f_8595eval.scm",(void*)f_8595},
{"f_8603eval.scm",(void*)f_8603},
{"f_8626eval.scm",(void*)f_8626},
{"f_8548eval.scm",(void*)f_8548},
{"f_8555eval.scm",(void*)f_8555},
{"f_8560eval.scm",(void*)f_8560},
{"f_8564eval.scm",(void*)f_8564},
{"f_8589eval.scm",(void*)f_8589},
{"f_8578eval.scm",(void*)f_8578},
{"f_8582eval.scm",(void*)f_8582},
{"f_8571eval.scm",(void*)f_8571},
{"f_8509eval.scm",(void*)f_8509},
{"f_8531eval.scm",(void*)f_8531},
{"f_8501eval.scm",(void*)f_8501},
{"f_8447eval.scm",(void*)f_8447},
{"f_8451eval.scm",(void*)f_8451},
{"f_8454eval.scm",(void*)f_8454},
{"f_8457eval.scm",(void*)f_8457},
{"f_8460eval.scm",(void*)f_8460},
{"f_8463eval.scm",(void*)f_8463},
{"f_8466eval.scm",(void*)f_8466},
{"f_8469eval.scm",(void*)f_8469},
{"f_8472eval.scm",(void*)f_8472},
{"f_8475eval.scm",(void*)f_8475},
{"f_8426eval.scm",(void*)f_8426},
{"f_8430eval.scm",(void*)f_8430},
{"f_8433eval.scm",(void*)f_8433},
{"f_8402eval.scm",(void*)f_8402},
{"f_8408eval.scm",(void*)f_8408},
{"f_8418eval.scm",(void*)f_8418},
{"f_8279eval.scm",(void*)f_8279},
{"f_8337eval.scm",(void*)f_8337},
{"f_8388eval.scm",(void*)f_8388},
{"f_8347eval.scm",(void*)f_8347},
{"f_8349eval.scm",(void*)f_8349},
{"f_8373eval.scm",(void*)f_8373},
{"f_8359eval.scm",(void*)f_8359},
{"f_8320eval.scm",(void*)f_8320},
{"f_8285eval.scm",(void*)f_8285},
{"f_8301eval.scm",(void*)f_8301},
{"f_8307eval.scm",(void*)f_8307},
{"f_8298eval.scm",(void*)f_8298},
{"f_8260eval.scm",(void*)f_8260},
{"f_8264eval.scm",(void*)f_8264},
{"f_8227eval.scm",(void*)f_8227},
{"f_8229eval.scm",(void*)f_8229},
{"f_8233eval.scm",(void*)f_8233},
{"f_8189eval.scm",(void*)f_8189},
{"f_8196eval.scm",(void*)f_8196},
{"f_8203eval.scm",(void*)f_8203},
{"f_8145eval.scm",(void*)f_8145},
{"f_8178eval.scm",(void*)f_8178},
{"f_8165eval.scm",(void*)f_8165},
{"f_8142eval.scm",(void*)f_8142},
{"f_8023eval.scm",(void*)f_8023},
{"f_8117eval.scm",(void*)f_8117},
{"f_8127eval.scm",(void*)f_8127},
{"f_8115eval.scm",(void*)f_8115},
{"f_8044eval.scm",(void*)f_8044},
{"f_8068eval.scm",(void*)f_8068},
{"f_8087eval.scm",(void*)f_8087},
{"f_8062eval.scm",(void*)f_8062},
{"f_7915eval.scm",(void*)f_7915},
{"f_7925eval.scm",(void*)f_7925},
{"f_7930eval.scm",(void*)f_7930},
{"f_7957eval.scm",(void*)f_7957},
{"f_7990eval.scm",(void*)f_7990},
{"f_7951eval.scm",(void*)f_7951},
{"f_7852eval.scm",(void*)f_7852},
{"f_7856eval.scm",(void*)f_7856},
{"f_7864eval.scm",(void*)f_7864},
{"f_7884eval.scm",(void*)f_7884},
{"f_7808eval.scm",(void*)f_7808},
{"f_7840eval.scm",(void*)f_7840},
{"f_7826eval.scm",(void*)f_7826},
{"f_7409eval.scm",(void*)f_7409},
{"f_7684eval.scm",(void*)f_7684},
{"f_7693eval.scm",(void*)f_7693},
{"f_7719eval.scm",(void*)f_7719},
{"f_7721eval.scm",(void*)f_7721},
{"f_7754eval.scm",(void*)f_7754},
{"f_7744eval.scm",(void*)f_7744},
{"f_7739eval.scm",(void*)f_7739},
{"f_7433eval.scm",(void*)f_7433},
{"f_7443eval.scm",(void*)f_7443},
{"f_7577eval.scm",(void*)f_7577},
{"f_7658eval.scm",(void*)f_7658},
{"f_7589eval.scm",(void*)f_7589},
{"f_7604eval.scm",(void*)f_7604},
{"f_7624eval.scm",(void*)f_7624},
{"f_7622eval.scm",(void*)f_7622},
{"f_7608eval.scm",(void*)f_7608},
{"f_7600eval.scm",(void*)f_7600},
{"f_7519eval.scm",(void*)f_7519},
{"f_7537eval.scm",(void*)f_7537},
{"f_7545eval.scm",(void*)f_7545},
{"f_7533eval.scm",(void*)f_7533},
{"f_7492eval.scm",(void*)f_7492},
{"f_7455eval.scm",(void*)f_7455},
{"f_7479eval.scm",(void*)f_7479},
{"f_7475eval.scm",(void*)f_7475},
{"f_7467eval.scm",(void*)f_7467},
{"f_7458eval.scm",(void*)f_7458},
{"f_7412eval.scm",(void*)f_7412},
{"f_7427eval.scm",(void*)f_7427},
{"f_7421eval.scm",(void*)f_7421},
{"f_7360eval.scm",(void*)f_7360},
{"f_7366eval.scm",(void*)f_7366},
{"f_7380eval.scm",(void*)f_7380},
{"f_7383eval.scm",(void*)f_7383},
{"f_7390eval.scm",(void*)f_7390},
{"f_7354eval.scm",(void*)f_7354},
{"f_7323eval.scm",(void*)f_7323},
{"f_7327eval.scm",(void*)f_7327},
{"f_7352eval.scm",(void*)f_7352},
{"f_7330eval.scm",(void*)f_7330},
{"f_7348eval.scm",(void*)f_7348},
{"f_7333eval.scm",(void*)f_7333},
{"f_7340eval.scm",(void*)f_7340},
{"f_7310eval.scm",(void*)f_7310},
{"f_7316eval.scm",(void*)f_7316},
{"f_7296eval.scm",(void*)f_7296},
{"f_7307eval.scm",(void*)f_7307},
{"f_7276eval.scm",(void*)f_7276},
{"f_7282eval.scm",(void*)f_7282},
{"f_7289eval.scm",(void*)f_7289},
{"f_7208eval.scm",(void*)f_7208},
{"f_7271eval.scm",(void*)f_7271},
{"f_7212eval.scm",(void*)f_7212},
{"f_7215eval.scm",(void*)f_7215},
{"f_7233eval.scm",(void*)f_7233},
{"f_7239eval.scm",(void*)f_7239},
{"f_7131eval.scm",(void*)f_7131},
{"f_7205eval.scm",(void*)f_7205},
{"f_7198eval.scm",(void*)f_7198},
{"f_7165eval.scm",(void*)f_7165},
{"f_7167eval.scm",(void*)f_7167},
{"f_7180eval.scm",(void*)f_7180},
{"f_7134eval.scm",(void*)f_7134},
{"f_7138eval.scm",(void*)f_7138},
{"f_7158eval.scm",(void*)f_7158},
{"f_7144eval.scm",(void*)f_7144},
{"f_7154eval.scm",(void*)f_7154},
{"f_7147eval.scm",(void*)f_7147},
{"f_6968eval.scm",(void*)f_6968},
{"f_7073eval.scm",(void*)f_7073},
{"f_7090eval.scm",(void*)f_7090},
{"f_7098eval.scm",(void*)f_7098},
{"f_6990eval.scm",(void*)f_6990},
{"f_6995eval.scm",(void*)f_6995},
{"f_7034eval.scm",(void*)f_7034},
{"f_7021eval.scm",(void*)f_7021},
{"f_6977eval.scm",(void*)f_6977},
{"f_6971eval.scm",(void*)f_6971},
{"f_6912eval.scm",(void*)f_6912},
{"f_6921eval.scm",(void*)f_6921},
{"f_6959eval.scm",(void*)f_6959},
{"f_6939eval.scm",(void*)f_6939},
{"f_6883eval.scm",(void*)f_6883},
{"f_6890eval.scm",(void*)f_6890},
{"f_6900eval.scm",(void*)f_6900},
{"f_6777eval.scm",(void*)f_6777},
{"f_6781eval.scm",(void*)f_6781},
{"f_6873eval.scm",(void*)f_6873},
{"f_6877eval.scm",(void*)f_6877},
{"f_6790eval.scm",(void*)f_6790},
{"f_6859eval.scm",(void*)f_6859},
{"f_6855eval.scm",(void*)f_6855},
{"f_6793eval.scm",(void*)f_6793},
{"f_6842eval.scm",(void*)f_6842},
{"f_6845eval.scm",(void*)f_6845},
{"f_6848eval.scm",(void*)f_6848},
{"f_6796eval.scm",(void*)f_6796},
{"f_6801eval.scm",(void*)f_6801},
{"f_6835eval.scm",(void*)f_6835},
{"f_6814eval.scm",(void*)f_6814},
{"f_6817eval.scm",(void*)f_6817},
{"f_6737eval.scm",(void*)f_6737},
{"f_6758eval.scm",(void*)f_6758},
{"f_6741eval.scm",(void*)f_6741},
{"f_6755eval.scm",(void*)f_6755},
{"f_6744eval.scm",(void*)f_6744},
{"f_6752eval.scm",(void*)f_6752},
{"f_6747eval.scm",(void*)f_6747},
{"f_6701eval.scm",(void*)f_6701},
{"f_6709eval.scm",(void*)f_6709},
{"f_6679eval.scm",(void*)f_6679},
{"f_6292eval.scm",(void*)f_6292},
{"f_6634eval.scm",(void*)f_6634},
{"f_6629eval.scm",(void*)f_6629},
{"f_6294eval.scm",(void*)f_6294},
{"f_6628eval.scm",(void*)f_6628},
{"f_6298eval.scm",(void*)f_6298},
{"f_6562eval.scm",(void*)f_6562},
{"f_6577eval.scm",(void*)f_6577},
{"f_6580eval.scm",(void*)f_6580},
{"f_6583eval.scm",(void*)f_6583},
{"f_6589eval.scm",(void*)f_6589},
{"f_6592eval.scm",(void*)f_6592},
{"f_6598eval.scm",(void*)f_6598},
{"f_6301eval.scm",(void*)f_6301},
{"f_6553eval.scm",(void*)f_6553},
{"f_6544eval.scm",(void*)f_6544},
{"f_6547eval.scm",(void*)f_6547},
{"f_6307eval.scm",(void*)f_6307},
{"f_6529eval.scm",(void*)f_6529},
{"f_6501eval.scm",(void*)f_6501},
{"f_6525eval.scm",(void*)f_6525},
{"f_6521eval.scm",(void*)f_6521},
{"f_6517eval.scm",(void*)f_6517},
{"f_6310eval.scm",(void*)f_6310},
{"f_6318eval.scm",(void*)f_6318},
{"f_6488eval.scm",(void*)f_6488},
{"f_6322eval.scm",(void*)f_6322},
{"f_6473eval.scm",(void*)f_6473},
{"f_6346eval.scm",(void*)f_6346},
{"f_6350eval.scm",(void*)f_6350},
{"f_6464eval.scm",(void*)f_6464},
{"f_6358eval.scm",(void*)f_6358},
{"f_6362eval.scm",(void*)f_6362},
{"f_6458eval.scm",(void*)f_6458},
{"f_6365eval.scm",(void*)f_6365},
{"f_6368eval.scm",(void*)f_6368},
{"f_6373eval.scm",(void*)f_6373},
{"f_6383eval.scm",(void*)f_6383},
{"f_6429eval.scm",(void*)f_6429},
{"f_6438eval.scm",(void*)f_6438},
{"f_6442eval.scm",(void*)f_6442},
{"f_6395eval.scm",(void*)f_6395},
{"f_6402eval.scm",(void*)f_6402},
{"f_6413eval.scm",(void*)f_6413},
{"f_6424eval.scm",(void*)f_6424},
{"f_6417eval.scm",(void*)f_6417},
{"f_6407eval.scm",(void*)f_6407},
{"f_6386eval.scm",(void*)f_6386},
{"f_6393eval.scm",(void*)f_6393},
{"f_6355eval.scm",(void*)f_6355},
{"f_6332eval.scm",(void*)f_6332},
{"f_6323eval.scm",(void*)f_6323},
{"f_6313eval.scm",(void*)f_6313},
{"f_6246eval.scm",(void*)f_6246},
{"f_6256eval.scm",(void*)f_6256},
{"f_6171eval.scm",(void*)f_6171},
{"f_6183eval.scm",(void*)f_6183},
{"f_6196eval.scm",(void*)f_6196},
{"f_6178eval.scm",(void*)f_6178},
{"f_6166eval.scm",(void*)f_6166},
{"f_6082eval.scm",(void*)f_6082},
{"f_6095eval.scm",(void*)f_6095},
{"f_6128eval.scm",(void*)f_6128},
{"f_6109eval.scm",(void*)f_6109},
{"f_6085eval.scm",(void*)f_6085},
{"f_6068eval.scm",(void*)f_6068},
{"f_6076eval.scm",(void*)f_6076},
{"f_6080eval.scm",(void*)f_6080},
{"f_3829eval.scm",(void*)f_3829},
{"f_5813eval.scm",(void*)f_5813},
{"f_5817eval.scm",(void*)f_5817},
{"f_6030eval.scm",(void*)f_6030},
{"f_6006eval.scm",(void*)f_6006},
{"f_6007eval.scm",(void*)f_6007},
{"f_6018eval.scm",(void*)f_6018},
{"f_6024eval.scm",(void*)f_6024},
{"f_6022eval.scm",(void*)f_6022},
{"f_5963eval.scm",(void*)f_5963},
{"f_5966eval.scm",(void*)f_5966},
{"f_5969eval.scm",(void*)f_5969},
{"f_5972eval.scm",(void*)f_5972},
{"f_5973eval.scm",(void*)f_5973},
{"f_5984eval.scm",(void*)f_5984},
{"f_5988eval.scm",(void*)f_5988},
{"f_5992eval.scm",(void*)f_5992},
{"f_5996eval.scm",(void*)f_5996},
{"f_5999eval.scm",(void*)f_5999},
{"f_5921eval.scm",(void*)f_5921},
{"f_5924eval.scm",(void*)f_5924},
{"f_5927eval.scm",(void*)f_5927},
{"f_5928eval.scm",(void*)f_5928},
{"f_5939eval.scm",(void*)f_5939},
{"f_5943eval.scm",(void*)f_5943},
{"f_5947eval.scm",(void*)f_5947},
{"f_5950eval.scm",(void*)f_5950},
{"f_5886eval.scm",(void*)f_5886},
{"f_5889eval.scm",(void*)f_5889},
{"f_5890eval.scm",(void*)f_5890},
{"f_5901eval.scm",(void*)f_5901},
{"f_5905eval.scm",(void*)f_5905},
{"f_5908eval.scm",(void*)f_5908},
{"f_5858eval.scm",(void*)f_5858},
{"f_5859eval.scm",(void*)f_5859},
{"f_5870eval.scm",(void*)f_5870},
{"f_5873eval.scm",(void*)f_5873},
{"f_5839eval.scm",(void*)f_5839},
{"f_5849eval.scm",(void*)f_5849},
{"f_5787eval.scm",(void*)f_5787},
{"f_4057eval.scm",(void*)f_4057},
{"f_4160eval.scm",(void*)f_4160},
{"f_4216eval.scm",(void*)f_4216},
{"f_4245eval.scm",(void*)f_4245},
{"f_4251eval.scm",(void*)f_4251},
{"f_5620eval.scm",(void*)f_5620},
{"f_5607eval.scm",(void*)f_5607},
{"f_5568eval.scm",(void*)f_5568},
{"f_5557eval.scm",(void*)f_5557},
{"f_5519eval.scm",(void*)f_5519},
{"f_5513eval.scm",(void*)f_5513},
{"f_5467eval.scm",(void*)f_5467},
{"f_5489eval.scm",(void*)f_5489},
{"f_5497eval.scm",(void*)f_5497},
{"f_5479eval.scm",(void*)f_5479},
{"f_5461eval.scm",(void*)f_5461},
{"f_5437eval.scm",(void*)f_5437},
{"f_5444eval.scm",(void*)f_5444},
{"f_5406eval.scm",(void*)f_5406},
{"f_5409eval.scm",(void*)f_5409},
{"f_5412eval.scm",(void*)f_5412},
{"f_5431eval.scm",(void*)f_5431},
{"f_5429eval.scm",(void*)f_5429},
{"f_5419eval.scm",(void*)f_5419},
{"f_5004eval.scm",(void*)f_5004},
{"f_5341eval.scm",(void*)f_5341},
{"f_5352eval.scm",(void*)f_5352},
{"f_5346eval.scm",(void*)f_5346},
{"f_5016eval.scm",(void*)f_5016},
{"f_5021eval.scm",(void*)f_5021},
{"f_5330eval.scm",(void*)f_5330},
{"f_5324eval.scm",(void*)f_5324},
{"f_5028eval.scm",(void*)f_5028},
{"f_5286eval.scm",(void*)f_5286},
{"f_5292eval.scm",(void*)f_5292},
{"f_5316eval.scm",(void*)f_5316},
{"f_5263eval.scm",(void*)f_5263},
{"f_5269eval.scm",(void*)f_5269},
{"f_5754eval.scm",(void*)f_5754},
{"f_5285eval.scm",(void*)f_5285},
{"f_5281eval.scm",(void*)f_5281},
{"f_5241eval.scm",(void*)f_5241},
{"f_5247eval.scm",(void*)f_5247},
{"f_5259eval.scm",(void*)f_5259},
{"f_5222eval.scm",(void*)f_5222},
{"f_5228eval.scm",(void*)f_5228},
{"f_5194eval.scm",(void*)f_5194},
{"f_5200eval.scm",(void*)f_5200},
{"f_5175eval.scm",(void*)f_5175},
{"f_5181eval.scm",(void*)f_5181},
{"f_5147eval.scm",(void*)f_5147},
{"f_5153eval.scm",(void*)f_5153},
{"f_5128eval.scm",(void*)f_5128},
{"f_5134eval.scm",(void*)f_5134},
{"f_5100eval.scm",(void*)f_5100},
{"f_5106eval.scm",(void*)f_5106},
{"f_5081eval.scm",(void*)f_5081},
{"f_5087eval.scm",(void*)f_5087},
{"f_5057eval.scm",(void*)f_5057},
{"f_5063eval.scm",(void*)f_5063},
{"f_5038eval.scm",(void*)f_5038},
{"f_5044eval.scm",(void*)f_5044},
{"f_4666eval.scm",(void*)f_4666},
{"f_4991eval.scm",(void*)f_4991},
{"f_4675eval.scm",(void*)f_4675},
{"f_4985eval.scm",(void*)f_4985},
{"f_4979eval.scm",(void*)f_4979},
{"f_4681eval.scm",(void*)f_4681},
{"f_4963eval.scm",(void*)f_4963},
{"f_4916eval.scm",(void*)f_4916},
{"f_4917eval.scm",(void*)f_4917},
{"f_4921eval.scm",(void*)f_4921},
{"f_4933eval.scm",(void*)f_4933},
{"f_4958eval.scm",(void*)f_4958},
{"f_4924eval.scm",(void*)f_4924},
{"f_4840eval.scm",(void*)f_4840},
{"f_4901eval.scm",(void*)f_4901},
{"f_4843eval.scm",(void*)f_4843},
{"f_4849eval.scm",(void*)f_4849},
{"f_4885eval.scm",(void*)f_4885},
{"f_4852eval.scm",(void*)f_4852},
{"f_4853eval.scm",(void*)f_4853},
{"f_4869eval.scm",(void*)f_4869},
{"f_4873eval.scm",(void*)f_4873},
{"f_4877eval.scm",(void*)f_4877},
{"f_4881eval.scm",(void*)f_4881},
{"f_4773eval.scm",(void*)f_4773},
{"f_4819eval.scm",(void*)f_4819},
{"f_4776eval.scm",(void*)f_4776},
{"f_4782eval.scm",(void*)f_4782},
{"f_4783eval.scm",(void*)f_4783},
{"f_4799eval.scm",(void*)f_4799},
{"f_4803eval.scm",(void*)f_4803},
{"f_4807eval.scm",(void*)f_4807},
{"f_4724eval.scm",(void*)f_4724},
{"f_4752eval.scm",(void*)f_4752},
{"f_4727eval.scm",(void*)f_4727},
{"f_4728eval.scm",(void*)f_4728},
{"f_4744eval.scm",(void*)f_4744},
{"f_4748eval.scm",(void*)f_4748},
{"f_4690eval.scm",(void*)f_4690},
{"f_4691eval.scm",(void*)f_4691},
{"f_4707eval.scm",(void*)f_4707},
{"f_4557eval.scm",(void*)f_4557},
{"f_4571eval.scm",(void*)f_4571},
{"f_4575eval.scm",(void*)f_4575},
{"f_4584eval.scm",(void*)f_4584},
{"f_4617eval.scm",(void*)f_4617},
{"f_4625eval.scm",(void*)f_4625},
{"f_4590eval.scm",(void*)f_4590},
{"f_4593eval.scm",(void*)f_4593},
{"f_4609eval.scm",(void*)f_4609},
{"f_4600eval.scm",(void*)f_4600},
{"f_4608eval.scm",(void*)f_4608},
{"f_4645eval.scm",(void*)f_4645},
{"f_4653eval.scm",(void*)f_4653},
{"f_4632eval.scm",(void*)f_4632},
{"f_4644eval.scm",(void*)f_4644},
{"f_4565eval.scm",(void*)f_4565},
{"f_4449eval.scm",(void*)f_4449},
{"f_4508eval.scm",(void*)f_4508},
{"f_4511eval.scm",(void*)f_4511},
{"f_4514eval.scm",(void*)f_4514},
{"f_4515eval.scm",(void*)f_4515},
{"f_4519eval.scm",(void*)f_4519},
{"f_4522eval.scm",(void*)f_4522},
{"f_4486eval.scm",(void*)f_4486},
{"f_4489eval.scm",(void*)f_4489},
{"f_4490eval.scm",(void*)f_4490},
{"f_4494eval.scm",(void*)f_4494},
{"f_4392eval.scm",(void*)f_4392},
{"f_4395eval.scm",(void*)f_4395},
{"f_4398eval.scm",(void*)f_4398},
{"f_4401eval.scm",(void*)f_4401},
{"f_4402eval.scm",(void*)f_4402},
{"f_4409eval.scm",(void*)f_4409},
{"f_4382eval.scm",(void*)f_4382},
{"f_4348eval.scm",(void*)f_4348},
{"f_4342eval.scm",(void*)f_4342},
{"f_4343eval.scm",(void*)f_4343},
{"f_4266eval.scm",(void*)f_4266},
{"f_4326eval.scm",(void*)f_4326},
{"f_4324eval.scm",(void*)f_4324},
{"f_4316eval.scm",(void*)f_4316},
{"f_4308eval.scm",(void*)f_4308},
{"f_4300eval.scm",(void*)f_4300},
{"f_4292eval.scm",(void*)f_4292},
{"f_4284eval.scm",(void*)f_4284},
{"f_4276eval.scm",(void*)f_4276},
{"f_4217eval.scm",(void*)f_4217},
{"f_4206eval.scm",(void*)f_4206},
{"f_4204eval.scm",(void*)f_4204},
{"f_4193eval.scm",(void*)f_4193},
{"f_4191eval.scm",(void*)f_4191},
{"f_4183eval.scm",(void*)f_4183},
{"f_4175eval.scm",(void*)f_4175},
{"f_4167eval.scm",(void*)f_4167},
{"f_4075eval.scm",(void*)f_4075},
{"f_4085eval.scm",(void*)f_4085},
{"f_4134eval.scm",(void*)f_4134},
{"f_4119eval.scm",(void*)f_4119},
{"f_4114eval.scm",(void*)f_4114},
{"f_4115eval.scm",(void*)f_4115},
{"f_4091eval.scm",(void*)f_4091},
{"f_4094eval.scm",(void*)f_4094},
{"f_4095eval.scm",(void*)f_4095},
{"f_4150eval.scm",(void*)f_4150},
{"f_4141eval.scm",(void*)f_4141},
{"f_4069eval.scm",(void*)f_4069},
{"f_4051eval.scm",(void*)f_4051},
{"f_4045eval.scm",(void*)f_4045},
{"f_4039eval.scm",(void*)f_4039},
{"f_3986eval.scm",(void*)f_3986},
{"f_3990eval.scm",(void*)f_3990},
{"f_4037eval.scm",(void*)f_4037},
{"f_4005eval.scm",(void*)f_4005},
{"f_4014eval.scm",(void*)f_4014},
{"f_3874eval.scm",(void*)f_3874},
{"f_3886eval.scm",(void*)f_3886},
{"f_3880eval.scm",(void*)f_3880},
{"f_3832eval.scm",(void*)f_3832},
{"f_3838eval.scm",(void*)f_3838},
{"f_3956eval.scm",(void*)f_3956},
{"f_3823eval.scm",(void*)f_3823},
{"f_3782eval.scm",(void*)f_3782},
{"f_3801eval.scm",(void*)f_3801},
{"f_3813eval.scm",(void*)f_3813},
{"f_3816eval.scm",(void*)f_3816},
{"f_3819eval.scm",(void*)f_3819},
{"f_3809eval.scm",(void*)f_3809},
{"f_3788eval.scm",(void*)f_3788},
{"f_3722eval.scm",(void*)f_3722},
{"f_3726eval.scm",(void*)f_3726},
{"f_3734eval.scm",(void*)f_3734},
{"f_3655eval.scm",(void*)f_3655},
{"f_3661eval.scm",(void*)f_3661},
{"f_3677eval.scm",(void*)f_3677},
{"f_3612eval.scm",(void*)f_3612},
{"f_3618eval.scm",(void*)f_3618},
{"f_3637eval.scm",(void*)f_3637},
{"f_3628eval.scm",(void*)f_3628},
{"f_3592eval.scm",(void*)f_3592},
{"f_3604eval.scm",(void*)f_3604},
{"f_3607eval.scm",(void*)f_3607},
{"f_3600eval.scm",(void*)f_3600},
{"f_3537eval.scm",(void*)f_3537},
{"f_3541eval.scm",(void*)f_3541},
{"f_3549eval.scm",(void*)f_3549},
{"f_3492eval.scm",(void*)f_3492},
{"f_3496eval.scm",(void*)f_3496},
{"f_3505eval.scm",(void*)f_3505},
{"f_3477eval.scm",(void*)f_3477},
{"f_3417eval.scm",(void*)f_3417},
{"f_3472eval.scm",(void*)f_3472},
{"f_3420eval.scm",(void*)f_3420},
{"f_3326eval.scm",(void*)f_3326},
{"f_3415eval.scm",(void*)f_3415},
{"f_3329eval.scm",(void*)f_3329},
{"f_3384eval.scm",(void*)f_3384},
{"f_2843eval.scm",(void*)f_2843},
{"f_3281eval.scm",(void*)f_3281},
{"f_3276eval.scm",(void*)f_3276},
{"f_2845eval.scm",(void*)f_2845},
{"f_3028eval.scm",(void*)f_3028},
{"f_3034eval.scm",(void*)f_3034},
{"f_3068eval.scm",(void*)f_3068},
{"f_3240eval.scm",(void*)f_3240},
{"f_3226eval.scm",(void*)f_3226},
{"f_3233eval.scm",(void*)f_3233},
{"f_3198eval.scm",(void*)f_3198},
{"f_3080eval.scm",(void*)f_3080},
{"f_3085eval.scm",(void*)f_3085},
{"f_3098eval.scm",(void*)f_3098},
{"f_3150eval.scm",(void*)f_3150},
{"f_3132eval.scm",(void*)f_3132},
{"f_3143eval.scm",(void*)f_3143},
{"f_2848eval.scm",(void*)f_2848},
{"f_2930eval.scm",(void*)f_2930},
{"f_3020eval.scm",(void*)f_3020},
{"f_3008eval.scm",(void*)f_3008},
{"f_2941eval.scm",(void*)f_2941},
{"f_3006eval.scm",(void*)f_3006},
{"f_2998eval.scm",(void*)f_2998},
{"f_2949eval.scm",(void*)f_2949},
{"f_2992eval.scm",(void*)f_2992},
{"f_2996eval.scm",(void*)f_2996},
{"f_2959eval.scm",(void*)f_2959},
{"f_2963eval.scm",(void*)f_2963},
{"f_2984eval.scm",(void*)f_2984},
{"f_2982eval.scm",(void*)f_2982},
{"f_2957eval.scm",(void*)f_2957},
{"f_2953eval.scm",(void*)f_2953},
{"f_2945eval.scm",(void*)f_2945},
{"f_2860eval.scm",(void*)f_2860},
{"f_2879eval.scm",(void*)f_2879},
{"f_2890eval.scm",(void*)f_2890},
{"f_2898eval.scm",(void*)f_2898},
{"f_2886eval.scm",(void*)f_2886},
{"f_2324eval.scm",(void*)f_2324},
{"f_2346eval.scm",(void*)f_2346},
{"f_2786eval.scm",(void*)f_2786},
{"f_2724eval.scm",(void*)f_2724},
{"f_2705eval.scm",(void*)f_2705},
{"f_2659eval.scm",(void*)f_2659},
{"f_2662eval.scm",(void*)f_2662},
{"f_2641eval.scm",(void*)f_2641},
{"f_2622eval.scm",(void*)f_2622},
{"f_2590eval.scm",(void*)f_2590},
{"f_2569eval.scm",(void*)f_2569},
{"f_2360eval.scm",(void*)f_2360},
{"f_2562eval.scm",(void*)f_2562},
{"f_2505eval.scm",(void*)f_2505},
{"f_2558eval.scm",(void*)f_2558},
{"f_2532eval.scm",(void*)f_2532},
{"f_2503eval.scm",(void*)f_2503},
{"f_2364eval.scm",(void*)f_2364},
{"f_2376eval.scm",(void*)f_2376},
{"f_2455eval.scm",(void*)f_2455},
{"f_2451eval.scm",(void*)f_2451},
{"f_2432eval.scm",(void*)f_2432},
{"f_2367eval.scm",(void*)f_2367},
{"f_2327eval.scm",(void*)f_2327},
{"f_2281eval.scm",(void*)f_2281},
{"f_2287eval.scm",(void*)f_2287},
{"f_2306eval.scm",(void*)f_2306},
{"f_2265eval.scm",(void*)f_2265},
{"f_2229eval.scm",(void*)f_2229},
{"f_2238eval.scm",(void*)f_2238},
{"f_2250eval.scm",(void*)f_2250},
{"f_2244eval.scm",(void*)f_2244},
{"f_2222eval.scm",(void*)f_2222},
{"f_2219eval.scm",(void*)f_2219},
{"f_2216eval.scm",(void*)f_2216},
{"f_1846eval.scm",(void*)f_1846},
{"f_2156eval.scm",(void*)f_2156},
{"f_2162eval.scm",(void*)f_2162},
{"f_2169eval.scm",(void*)f_2169},
{"f_2083eval.scm",(void*)f_2083},
{"f_2095eval.scm",(void*)f_2095},
{"f_2143eval.scm",(void*)f_2143},
{"f_2137eval.scm",(void*)f_2137},
{"f_2117eval.scm",(void*)f_2117},
{"f_1995eval.scm",(void*)f_1995},
{"f_2015eval.scm",(void*)f_2015},
{"f_2023eval.scm",(void*)f_2023},
{"f_2037eval.scm",(void*)f_2037},
{"f_2009eval.scm",(void*)f_2009},
{"f_1849eval.scm",(void*)f_1849},
{"f_1858eval.scm",(void*)f_1858},
{"f_1971eval.scm",(void*)f_1971},
{"f_1983eval.scm",(void*)f_1983},
{"f_1989eval.scm",(void*)f_1989},
{"f_1977eval.scm",(void*)f_1977},
{"f_1864eval.scm",(void*)f_1864},
{"f_1870eval.scm",(void*)f_1870},
{"f_1881eval.scm",(void*)f_1881},
{"f_1898eval.scm",(void*)f_1898},
{"f_1917eval.scm",(void*)f_1917},
{"f_1928eval.scm",(void*)f_1928},
{"f_1892eval.scm",(void*)f_1892},
{"f_1878eval.scm",(void*)f_1878},
{"f_1856eval.scm",(void*)f_1856},
{"f_1837eval.scm",(void*)f_1837},
{"f_1819eval.scm",(void*)f_1819},
{"f_1829eval.scm",(void*)f_1829},
{"f_1809eval.scm",(void*)f_1809},
{"f_1817eval.scm",(void*)f_1817},
{"f_1793eval.scm",(void*)f_1793},
{"f_1799eval.scm",(void*)f_1799},
{"f_1777eval.scm",(void*)f_1777},
{"f_1783eval.scm",(void*)f_1783},
{"f_1761eval.scm",(void*)f_1761},
{"f_1765eval.scm",(void*)f_1765},
{"f_1734eval.scm",(void*)f_1734},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
