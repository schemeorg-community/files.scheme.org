/* Generated from tcp.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-04-30 11:28
   Version 3.1.10 - linux-unix-gnu-x86	[ manyargs dload ptables applyhook ]
   SVN rev. 10602	compiled 2008-04-30 on galinha (Linux)
   command line: tcp.scm -quiet -no-trace -optimize-level 2 -include-path . -explicit-use -unsafe -no-lambda-info -output-file utcp.c
   unit: tcp
*/

#include "chicken.h"

#include <errno.h>
#ifdef _WIN32
# if _MSC_VER > 1300
# include <winsock2.h>
# include <ws2tcpip.h>
# else
# include <winsock.h>
# endif
/* Beware: winsock2.h must come BEFORE windows.h */
# define socklen_t       int
static WSADATA wsa;
# define fcntl(a, b, c)  0
# define EWOULDBLOCK     0
# define EINPROGRESS     0
# define typecorrect_getsockopt(socket, level, optname, optval, optlen)	\
    getsockopt(socket, level, optname, (char *)optval, optlen)
#else
# include <fcntl.h>
# include <sys/types.h>
# include <sys/socket.h>
# include <sys/time.h>
# include <netinet/in.h>
# include <unistd.h>
# include <netdb.h>
# include <signal.h>
# define closesocket     close
# define INVALID_SOCKET  -1
# define typecorrect_getsockopt getsockopt
#endif

#ifndef SD_RECEIVE
# define SD_RECEIVE      0
# define SD_SEND         1
#endif

#ifdef ECOS
#include <sys/sockio.h>
#endif

static char addr_buffer[ 20 ];

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_scheduler_toplevel)
C_externimport void C_ccall C_scheduler_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[95];
static double C_possibly_force_alignment;


/* from general-strerror */
static C_word C_fcall stub346(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub346(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_mpointer(&C_a,(void*)strerror(t0));
return C_r;}

/* from get-socket-error */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub342(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub342(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int socket=(int )C_unfix(C_a0);
int err, optlen;optlen = sizeof(err);if (typecorrect_getsockopt(socket, SOL_SOCKET, SO_ERROR, &err, (socklen_t *)&optlen) == -1)return(-1);return(err);
C_ret:
#undef return

return C_r;}

/* from f_779 in k708 in k702 in a810 in body184 in tcp-listen in k556 in k472 in k469 in k466 in k463 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub167(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub167(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int socket=(int )C_unfix(C_a0);
int yes = 1; 
                      return(setsockopt(socket, SOL_SOCKET, SO_REUSEADDR, (const char *)&yes, sizeof(int)));
C_ret:
#undef return

return C_r;}

/* from k693 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub153(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub153(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * saddr=(void * )C_data_pointer_or_null(C_a0);
unsigned short port=(unsigned short )(unsigned short)C_unfix(C_a1);
struct sockaddr_in *addr = (struct sockaddr_in *)saddr;memset(addr, 0, sizeof(struct sockaddr_in));addr->sin_family = AF_INET;addr->sin_port = htons(port);addr->sin_addr.s_addr = htonl(INADDR_ANY);
C_ret:
#undef return

return C_r;}

/* from k590 in ##net#gethostaddr in k556 in k472 in k469 in k466 in k463 */
#define return(x) C_cblock C_r = (C_mk_bool((x))); goto C_ret; C_cblockend
static C_word C_fcall stub127(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub127(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * saddr=(void * )C_data_pointer_or_null(C_a0);
char * host=(char * )C_string_or_null(C_a1);
unsigned short port=(unsigned short )(unsigned short)C_unfix(C_a2);
struct hostent *he = gethostbyname(host);struct sockaddr_in *addr = (struct sockaddr_in *)saddr;if(he == NULL) return(0);memset(addr, 0, sizeof(struct sockaddr_in));addr->sin_family = AF_INET;addr->sin_port = htons((short)port);addr->sin_addr = *((struct in_addr *)he->h_addr);return(1);
C_ret:
#undef return

return C_r;}

/* from ##net#select-write */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub121(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub121(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int fd=(int )C_unfix(C_a0);
fd_set out;
     struct timeval tm;
     int rv;
     FD_ZERO(&out);
     FD_SET(fd, &out);
     tm.tv_sec = tm.tv_usec = 0;
     rv = select(fd + 1, NULL, &out, NULL, &tm);
     if(rv > 0) { rv = FD_ISSET(fd, &out) ? 1 : 0; }
     return(rv);
C_ret:
#undef return

return C_r;}

/* from ##net#select in k556 in k472 in k469 in k466 in k463 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub117(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub117(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int fd=(int )C_unfix(C_a0);
fd_set in;
     struct timeval tm;
     int rv;
     FD_ZERO(&in);
     FD_SET(fd, &in);
     tm.tv_sec = tm.tv_usec = 0;
     rv = select(fd + 1, &in, NULL, NULL, &tm);
     if(rv > 0) { rv = FD_ISSET(fd, &in) ? 1 : 0; }
     return(rv);
C_ret:
#undef return

return C_r;}

/* from k567 in k563 in k652 in k648 in loop in ##net#parse-host in k556 in k472 in k469 in k466 in k463 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub108(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub108(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
char * serv=(char * )C_string_or_null(C_a0);
char * proto=(char * )C_string_or_null(C_a1);
struct servent *se;
     if((se = getservbyname(serv, proto)) == NULL) return(0);
     else return(ntohs(se->s_port));
C_ret:
#undef return

return C_r;}

/* from ##net#startup */
#define return(x) C_cblock C_r = (C_mk_bool((x))); goto C_ret; C_cblockend
static C_word C_fcall stub104(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub104(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
#ifdef _WIN32
     return(WSAStartup(MAKEWORD(1, 1), &wsa) == 0);
#else
     signal(SIGPIPE, SIG_IGN);
     return(1);
#endif
C_ret:
#undef return

return C_r;}

/* from ##net#getpeername */
#define return(x) C_cblock C_r = (C_mpointer(&C_a,(void*)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub100(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub100(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int s=(int )C_unfix(C_a0);
struct sockaddr_in sa;unsigned char *ptr;unsigned int len = sizeof(struct sockaddr_in);if(getpeername(s, (struct sockaddr *)&sa, ((unsigned int *)&len)) != 0) return(NULL);ptr = (unsigned char *)&sa.sin_addr;sprintf(addr_buffer, "%d.%d.%d.%d", ptr[ 0 ], ptr[ 1 ], ptr[ 2 ], ptr[ 3 ]);return(addr_buffer);
C_ret:
#undef return

return C_r;}

/* from ##net#getpeerport */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub96(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub96(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int s=(int )C_unfix(C_a0);
struct sockaddr_in sa;int len = sizeof(struct sockaddr_in);if(getpeername(s, (struct sockaddr *)&sa, (socklen_t *)(&len)) != 0) return(-1);else return(ntohs(sa.sin_port));
C_ret:
#undef return

return C_r;}

/* from ##net#getsockport in k472 in k469 in k466 in k463 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub92(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub92(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int s=(int )C_unfix(C_a0);
struct sockaddr_in sa;int len = sizeof(struct sockaddr_in);if(getsockname(s, (struct sockaddr *)&sa, (socklen_t *)(&len)) != 0) return(-1);else return(ntohs(sa.sin_port));
C_ret:
#undef return

return C_r;}

/* from ##net#getsockname */
#define return(x) C_cblock C_r = (C_mpointer(&C_a,(void*)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub87(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub87(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int s=(int )C_unfix(C_a0);
struct sockaddr_in sa;unsigned char *ptr;int len = sizeof(struct sockaddr_in);if(getsockname(s, (struct sockaddr *)&sa, (socklen_t *)&len) != 0) return(NULL);ptr = (unsigned char *)&sa.sin_addr;sprintf(addr_buffer, "%d.%d.%d.%d", ptr[ 0 ], ptr[ 1 ], ptr[ 2 ], ptr[ 3 ]);return(addr_buffer);
C_ret:
#undef return

return C_r;}

/* from ##net#make-nonblocking in k472 in k469 in k466 in k463 */
#define return(x) C_cblock C_r = (C_mk_bool((x))); goto C_ret; C_cblockend
static C_word C_fcall stub83(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub83(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int fd=(int )C_unfix(C_a0);
int val = fcntl(fd, F_GETFL, 0);if(val == -1) return(0);return(fcntl(fd, F_SETFL, val | O_NONBLOCK) != -1);
C_ret:
#undef return

return C_r;}

/* from k529 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub73(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4) C_regparm;
C_regparm static C_word C_fcall stub73(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int s=(int )C_unfix(C_a0);
void * msg=(void * )C_data_pointer_or_null(C_a1);
int offset=(int )C_unfix(C_a2);
int len=(int )C_unfix(C_a3);
int flags=(int )C_unfix(C_a4);
return(send(s, (char *)msg+offset, len, flags));
C_ret:
#undef return

return C_r;}

/* from k522 */
static C_word C_fcall stub61(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub61(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
void * t1=(void * )C_data_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
C_r=C_fix((C_word)connect(t0,t1,t2));
return C_r;}

/* from ##net#shutdown in k472 in k469 in k466 in k463 */
static C_word C_fcall stub54(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub54(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
int t1=(int )C_unfix(C_a1);
C_r=C_fix((C_word)shutdown(t0,t1));
return C_r;}

/* from k512 */
static C_word C_fcall stub44(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3) C_regparm;
C_regparm static C_word C_fcall stub44(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
void * t1=(void * )C_data_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
int t3=(int )C_unfix(C_a3);
C_r=C_fix((C_word)recv(t0,t1,t2,t3));
return C_r;}

/* from ##net#close in k472 in k469 in k466 in k463 */
static C_word C_fcall stub37(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub37(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_fix((C_word)closesocket(t0));
return C_r;}

/* from k496 */
static C_word C_fcall stub27(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub27(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
void * t1=(void * )C_c_pointer_or_null(C_a1);
void * t2=(void * )C_c_pointer_or_null(C_a2);
C_r=C_fix((C_word)accept(t0,t1,t2));
return C_r;}

/* from ##net#listen */
static C_word C_fcall stub20(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub20(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
int t1=(int )C_unfix(C_a1);
C_r=C_fix((C_word)listen(t0,t1));
return C_r;}

/* from k482 */
static C_word C_fcall stub11(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub11(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
void * t1=(void * )C_data_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
C_r=C_fix((C_word)bind(t0,t1,t2));
return C_r;}

/* from ##net#socket in k472 in k469 in k466 in k463 */
static C_word C_fcall stub3(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub3(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
int t1=(int )C_unfix(C_a1);
int t2=(int )C_unfix(C_a2);
C_r=C_fix((C_word)socket(t0,t1,t2));
return C_r;}

C_noret_decl(C_tcp_toplevel)
C_externexport void C_ccall C_tcp_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_465)
static void C_ccall f_465(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_468)
static void C_ccall f_468(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_471)
static void C_ccall f_471(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_474)
static void C_ccall f_474(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_558)
static void C_ccall f_558(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_942)
static void C_ccall f_942(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2142)
static void C_ccall f_2142(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_977)
static void C_ccall f_977(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2138)
static void C_ccall f_2138(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_981)
static void C_ccall f_981(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2134)
static void C_ccall f_2134(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_985)
static void C_ccall f_985(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2130)
static void C_ccall f_2130(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_989)
static void C_ccall f_989(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2119)
static void C_ccall f_2119(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2099)
static void C_ccall f_2099(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2103)
static void C_ccall f_2103(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2110)
static void C_ccall f_2110(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2070)
static void C_ccall f_2070(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2097)
static void C_ccall f_2097(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2093)
static void C_ccall f_2093(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2083)
static void C_ccall f_2083(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2025)
static void C_ccall f_2025(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2029)
static void C_ccall f_2029(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2068)
static void C_ccall f_2068(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2064)
static void C_ccall f_2064(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2039)
static void C_ccall f_2039(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2057)
static void C_ccall f_2057(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2053)
static void C_ccall f_2053(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2046)
static void C_ccall f_2046(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1980)
static void C_ccall f_1980(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1984)
static void C_ccall f_1984(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1991)
static void C_ccall f_1991(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2023)
static void C_ccall f_2023(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2019)
static void C_ccall f_2019(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1994)
static void C_ccall f_1994(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1998)
static void C_ccall f_1998(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2012)
static void C_ccall f_2012(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2008)
static void C_ccall f_2008(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2001)
static void C_ccall f_2001(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1970)
static void C_ccall f_1970(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1978)
static void C_ccall f_1978(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1730)
static void C_ccall f_1730(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1730)
static void C_ccall f_1730r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1737)
static void C_ccall f_1737(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1953)
static void C_ccall f_1953(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1947)
static void C_ccall f_1947(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1939)
static void C_ccall f_1939(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1743)
static void C_ccall f_1743(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1749)
static void C_ccall f_1749(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1925)
static void C_ccall f_1925(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1936)
static void C_ccall f_1936(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1932)
static void C_ccall f_1932(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1775)
static void C_ccall f_1775(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1916)
static void C_ccall f_1916(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1778)
static void C_ccall f_1778(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1902)
static void C_ccall f_1902(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1913)
static void C_ccall f_1913(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1909)
static void C_ccall f_1909(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1781)
static void C_ccall f_1781(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1838)
static void C_fcall f_1838(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1845)
static void C_ccall f_1845(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1854)
static void C_ccall f_1854(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1857)
static void C_ccall f_1857(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1860)
static void C_ccall f_1860(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1863)
static void C_ccall f_1863(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1784)
static void C_ccall f_1784(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1824)
static void C_ccall f_1824(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1820)
static void C_ccall f_1820(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1807)
static void C_ccall f_1807(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1803)
static void C_ccall f_1803(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1790)
static void C_ccall f_1790(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1754)
static void C_fcall f_1754(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1761)
static void C_ccall f_1761(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1772)
static void C_ccall f_1772(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1768)
static void C_ccall f_1768(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1685)
static void C_ccall f_1685(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1704)
static void C_ccall f_1704(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1715)
static void C_ccall f_1715(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1711)
static void C_ccall f_1711(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1695)
static void C_ccall f_1695(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1599)
static void C_ccall f_1599(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1609)
static void C_ccall f_1609(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1614)
static void C_fcall f_1614(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1650)
static void C_ccall f_1650(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1653)
static void C_ccall f_1653(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1656)
static void C_ccall f_1656(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1659)
static void C_ccall f_1659(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1636)
static void C_ccall f_1636(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1647)
static void C_ccall f_1647(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1643)
static void C_ccall f_1643(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1627)
static void C_ccall f_1627(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_991)
static void C_fcall f_991(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1586)
static void C_ccall f_1586(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1597)
static void C_ccall f_1597(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1593)
static void C_ccall f_1593(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_995)
static void C_ccall f_995(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_998)
static void C_ccall f_998(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1004)
static void C_ccall f_1004(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1007)
static void C_fcall f_1007(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1010)
static void C_ccall f_1010(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1013)
static void C_ccall f_1013(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1490)
static void C_ccall f_1490(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1496)
static void C_fcall f_1496(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1565)
static void C_ccall f_1565(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1508)
static void C_ccall f_1508(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1512)
static void C_ccall f_1512(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1522)
static void C_ccall f_1522(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1538)
static void C_ccall f_1538(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1425)
static void C_ccall f_1425(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_1431)
static void C_fcall f_1431(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1479)
static void C_ccall f_1479(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1382)
static void C_ccall f_1382(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1396)
static void C_fcall f_1396(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1399)
static void C_ccall f_1399(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1410)
static void C_ccall f_1410(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1406)
static void C_ccall f_1406(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1347)
static void C_ccall f_1347(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1369)
static void C_ccall f_1369(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1380)
static void C_ccall f_1380(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1376)
static void C_ccall f_1376(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1360)
static void C_ccall f_1360(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1325)
static void C_ccall f_1325(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1329)
static void C_ccall f_1329(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1087)
static void C_ccall f_1087(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1273)
static void C_ccall f_1273(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1283)
static void C_ccall f_1283(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1210)
static void C_ccall f_1210(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1257)
static void C_fcall f_1257(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1260)
static void C_ccall f_1260(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1218)
static void C_fcall f_1218(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1227)
static void C_fcall f_1227(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1230)
static void C_ccall f_1230(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1241)
static void C_ccall f_1241(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1237)
static void C_ccall f_1237(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1309)
static void C_ccall f_1309(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1289)
static void C_ccall f_1289(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1294)
static void C_ccall f_1294(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1303)
static void C_ccall f_1303(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1183)
static void C_ccall f_1183(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1088)
static void C_fcall f_1088(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1098)
static void C_fcall f_1098(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1152)
static void C_ccall f_1152(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1163)
static void C_ccall f_1163(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1159)
static void C_ccall f_1159(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1120)
static void C_ccall f_1120(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1123)
static void C_ccall f_1123(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1126)
static void C_ccall f_1126(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1129)
static void C_ccall f_1129(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1014)
static void C_fcall f_1014(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1020)
static void C_fcall f_1020(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1071)
static void C_ccall f_1071(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1082)
static void C_ccall f_1082(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1078)
static void C_ccall f_1078(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1039)
static void C_ccall f_1039(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1042)
static void C_ccall f_1042(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1045)
static void C_ccall f_1045(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1048)
static void C_ccall f_1048(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_960)
static void C_fcall f_960(C_word t0,C_word t1) C_noret;
C_noret_decl(f_962)
static void C_ccall f_962(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_907)
static void C_ccall f_907(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_923)
static void C_ccall f_923(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_934)
static void C_ccall f_934(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_930)
static void C_ccall f_930(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_898)
static void C_ccall f_898(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_803)
static void C_ccall f_803(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_803)
static void C_ccall f_803r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_853)
static void C_fcall f_853(C_word t0,C_word t1) C_noret;
C_noret_decl(f_848)
static void C_fcall f_848(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_805)
static void C_fcall f_805(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_817)
static void C_ccall f_817(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_836)
static void C_ccall f_836(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_847)
static void C_ccall f_847(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_843)
static void C_ccall f_843(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_827)
static void C_ccall f_827(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_811)
static void C_ccall f_811(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_704)
static void C_ccall f_704(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_786)
static void C_ccall f_786(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_710)
static void C_ccall f_710(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_779)
static void C_ccall f_779(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_778)
static void C_ccall f_778(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_763)
static void C_ccall f_763(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_774)
static void C_ccall f_774(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_770)
static void C_ccall f_770(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_713)
static void C_ccall f_713(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_716)
static void C_ccall f_716(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_751)
static void C_ccall f_751(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_719)
static void C_ccall f_719(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_734)
static void C_ccall f_734(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_745)
static void C_ccall f_745(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_741)
static void C_ccall f_741(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_725)
static void C_ccall f_725(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_618)
static void C_fcall f_618(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_627)
static void C_fcall f_627(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_650)
static void C_ccall f_650(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_654)
static void C_ccall f_654(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_565)
static void C_ccall f_565(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_569)
static void C_ccall f_569(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_666)
static void C_ccall f_666(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_677)
static void C_ccall f_677(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_673)
static void C_ccall f_673(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_660)
static void C_ccall f_660(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_597)
static void C_fcall f_597(C_word t0) C_noret;
C_noret_decl(f_603)
static void C_ccall f_603(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_612)
static void C_ccall f_612(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_583)
static void C_fcall f_583(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_592)
static void C_ccall f_592(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_577)
static C_word C_fcall f_577(C_word t0);
C_noret_decl(f_542)
static C_word C_fcall f_542(C_word t0);
C_noret_decl(f_533)
static C_word C_fcall f_533(C_word t0);
C_noret_decl(f_516)
static C_word C_fcall f_516(C_word t0,C_word t1);
C_noret_decl(f_506)
static C_word C_fcall f_506(C_word t0);
C_noret_decl(f_476)
static C_word C_fcall f_476(C_word t0,C_word t1,C_word t2);

C_noret_decl(trf_1838)
static void C_fcall trf_1838(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1838(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1838(t0,t1);}

C_noret_decl(trf_1754)
static void C_fcall trf_1754(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1754(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1754(t0,t1);}

C_noret_decl(trf_1614)
static void C_fcall trf_1614(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1614(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1614(t0,t1);}

C_noret_decl(trf_991)
static void C_fcall trf_991(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_991(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_991(t0,t1,t2);}

C_noret_decl(trf_1007)
static void C_fcall trf_1007(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1007(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1007(t0,t1);}

C_noret_decl(trf_1496)
static void C_fcall trf_1496(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1496(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1496(t0,t1,t2);}

C_noret_decl(trf_1431)
static void C_fcall trf_1431(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1431(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1431(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1396)
static void C_fcall trf_1396(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1396(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1396(t0,t1);}

C_noret_decl(trf_1257)
static void C_fcall trf_1257(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1257(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1257(t0,t1);}

C_noret_decl(trf_1218)
static void C_fcall trf_1218(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1218(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1218(t0,t1);}

C_noret_decl(trf_1227)
static void C_fcall trf_1227(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1227(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1227(t0,t1);}

C_noret_decl(trf_1088)
static void C_fcall trf_1088(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1088(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1088(t0,t1,t2);}

C_noret_decl(trf_1098)
static void C_fcall trf_1098(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1098(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1098(t0,t1,t2,t3);}

C_noret_decl(trf_1014)
static void C_fcall trf_1014(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1014(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1014(t0,t1);}

C_noret_decl(trf_1020)
static void C_fcall trf_1020(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1020(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1020(t0,t1);}

C_noret_decl(trf_960)
static void C_fcall trf_960(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_960(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_960(t0,t1);}

C_noret_decl(trf_853)
static void C_fcall trf_853(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_853(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_853(t0,t1);}

C_noret_decl(trf_848)
static void C_fcall trf_848(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_848(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_848(t0,t1,t2);}

C_noret_decl(trf_805)
static void C_fcall trf_805(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_805(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_805(t0,t1,t2,t3);}

C_noret_decl(trf_618)
static void C_fcall trf_618(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_618(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_618(t0,t1,t2,t3);}

C_noret_decl(trf_627)
static void C_fcall trf_627(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_627(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_627(t0,t1,t2);}

C_noret_decl(trf_597)
static void C_fcall trf_597(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_597(void *dummy){
C_word t0=C_pick(0);
C_adjust_stack(-1);
f_597(t0);}

C_noret_decl(trf_583)
static void C_fcall trf_583(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_583(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_583(t0,t1,t2,t3);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr3rv)
static void C_fcall tr3rv(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3rv(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n+1);
t3=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_tcp_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_tcp_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("tcp_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(440)){
C_save(t1);
C_rereclaim2(440*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,95);
lf[7]=C_h_intern(&lf[7],17,"\003sysmake-c-string");
lf[9]=C_h_intern(&lf[9],18,"\003syscurrent-thread");
lf[10]=C_h_intern(&lf[10],12,"\003sysschedule");
lf[11]=C_h_intern(&lf[11],9,"substring");
lf[13]=C_h_intern(&lf[13],15,"\003syssignal-hook");
lf[14]=C_h_intern(&lf[14],14,"\000network-error");
lf[15]=C_h_intern(&lf[15],11,"tcp-connect");
lf[16]=C_h_intern(&lf[16],17,"\003sysstring-append");
lf[17]=C_decode_literal(C_heaptop,"\376B\000\000$can not compute port from service - ");
lf[18]=C_h_intern(&lf[18],17,"\003syspeek-c-string");
lf[19]=C_h_intern(&lf[19],16,"\003sysupdate-errno");
lf[20]=C_h_intern(&lf[20],10,"tcp-listen");
lf[21]=C_decode_literal(C_heaptop,"\376B\000\000\031can not bind to socket - ");
lf[22]=C_decode_literal(C_heaptop,"\376B\000\000\042getting listener host IP failed - ");
lf[23]=C_h_intern(&lf[23],11,"make-string");
lf[24]=C_decode_literal(C_heaptop,"\376B\000\000 error while setting up socket - ");
lf[25]=C_h_intern(&lf[25],9,"\003syserror");
lf[26]=C_decode_literal(C_heaptop,"\376B\000\000\025can not create socket");
lf[27]=C_h_intern(&lf[27],13,"\000domain-error");
lf[28]=C_decode_literal(C_heaptop,"\376B\000\000\023invalid port number");
lf[29]=C_h_intern(&lf[29],12,"tcp-listener");
lf[30]=C_decode_literal(C_heaptop,"\376B\000\000\033can not listen on socket - ");
lf[31]=C_h_intern(&lf[31],13,"tcp-listener\077");
lf[32]=C_h_intern(&lf[32],9,"tcp-close");
lf[33]=C_decode_literal(C_heaptop,"\376B\000\000\033can not close TCP socket - ");
lf[34]=C_h_intern(&lf[34],15,"tcp-buffer-size");
lf[35]=C_h_intern(&lf[35],19,"\003sysundefined-value");
lf[36]=C_h_intern(&lf[36],16,"tcp-read-timeout");
lf[37]=C_h_intern(&lf[37],17,"tcp-write-timeout");
lf[38]=C_h_intern(&lf[38],19,"tcp-connect-timeout");
lf[39]=C_h_intern(&lf[39],18,"tcp-accept-timeout");
lf[40]=C_h_intern(&lf[40],15,"make-input-port");
lf[41]=C_h_intern(&lf[41],16,"make-output-port");
lf[43]=C_decode_literal(C_heaptop,"\376B\000\000\030read operation timed out");
lf[44]=C_h_intern(&lf[44],25,"\003systhread-block-for-i/o!");
lf[45]=C_h_intern(&lf[45],29,"\003systhread-block-for-timeout!");
lf[46]=C_decode_literal(C_heaptop,"\376B\000\000\033can not read from socket - ");
lf[47]=C_decode_literal(C_heaptop,"\376B\000\000\031write operation timed out");
lf[48]=C_decode_literal(C_heaptop,"\376B\000\000\032can not write to socket - ");
lf[49]=C_decode_literal(C_heaptop,"\376B\000\000\005(tcp)");
lf[50]=C_decode_literal(C_heaptop,"\376B\000\000\005(tcp)");
lf[51]=C_h_intern(&lf[51],6,"socket");
lf[52]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[53]=C_decode_literal(C_heaptop,"\376B\000\000#can not close socket output port - ");
lf[54]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[55]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[56]=C_decode_literal(C_heaptop,"\376B\000\000!can not check socket for input - ");
lf[57]=C_decode_literal(C_heaptop,"\376B\000\000\042can not close socket input port - ");
lf[58]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[59]=C_h_intern(&lf[59],15,"\003sysmake-string");
lf[60]=C_h_intern(&lf[60],20,"\003sysscan-buffer-line");
lf[61]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[62]=C_decode_literal(C_heaptop,"\376B\000\000\033can not create TCP ports - ");
lf[63]=C_h_intern(&lf[63],10,"tcp-accept");
lf[64]=C_decode_literal(C_heaptop,"\376B\000\000!could not accept from listener - ");
lf[65]=C_decode_literal(C_heaptop,"\376B\000\000\032accept operation timed out");
lf[66]=C_h_intern(&lf[66],17,"tcp-accept-ready\077");
lf[67]=C_decode_literal(C_heaptop,"\376B\000\000!can not check socket for input - ");
lf[68]=C_decode_literal(C_heaptop,"\376B\000\000\034can not connect to socket - ");
lf[69]=C_decode_literal(C_heaptop,"\376B\000\000\026getsockopt() failed - ");
lf[70]=C_decode_literal(C_heaptop,"\376B\000\000\030can not create socket - ");
lf[71]=C_decode_literal(C_heaptop,"\376B\000\000\033connect operation timed out");
lf[72]=C_h_intern(&lf[72],4,"\000all");
lf[73]=C_decode_literal(C_heaptop,"\376B\000\000\021fcntl() failed - ");
lf[74]=C_decode_literal(C_heaptop,"\376B\000\000\031can not find host address");
lf[75]=C_decode_literal(C_heaptop,"\376B\000\000\030can not create socket - ");
lf[76]=C_decode_literal(C_heaptop,"\376B\000\000\021no port specified");
lf[77]=C_decode_literal(C_heaptop,"\376B\000\000\003tcp");
lf[78]=C_h_intern(&lf[78],20,"\003systcp-port->fileno");
lf[79]=C_h_intern(&lf[79],13,"\003sysport-data");
lf[80]=C_h_intern(&lf[80],13,"tcp-addresses");
lf[81]=C_decode_literal(C_heaptop,"\376B\000\000!can not compute remote address - ");
lf[82]=C_decode_literal(C_heaptop,"\376B\000\000 can not compute local address - ");
lf[83]=C_h_intern(&lf[83],16,"tcp-port-numbers");
lf[84]=C_decode_literal(C_heaptop,"\376B\000\000\036can not compute remote port - ");
lf[85]=C_decode_literal(C_heaptop,"\376B\000\000\035can not compute local port - ");
lf[86]=C_h_intern(&lf[86],17,"tcp-listener-port");
lf[87]=C_decode_literal(C_heaptop,"\376B\000\000\037can not obtain listener port - ");
lf[88]=C_h_intern(&lf[88],16,"tcp-abandon-port");
lf[89]=C_h_intern(&lf[89],14,"\003syscheck-port");
lf[90]=C_h_intern(&lf[90],19,"tcp-listener-fileno");
lf[91]=C_h_intern(&lf[91],14,"make-parameter");
lf[92]=C_decode_literal(C_heaptop,"\376B\000\000\032can not initialize Winsock");
lf[93]=C_h_intern(&lf[93],17,"register-feature!");
lf[94]=C_h_intern(&lf[94],3,"tcp");
C_register_lf2(lf,95,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_465,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k463 */
static void C_ccall f_465(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_465,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_468,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k466 in k463 */
static void C_ccall f_468(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_468,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_471,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_scheduler_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k469 in k466 in k463 */
static void C_ccall f_471(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_471,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_474,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* tcp.scm: 89   register-feature! */
t3=*((C_word*)lf[93]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[94]);}

/* k472 in k469 in k466 in k463 */
static void C_ccall f_474(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_474,2,t0,t1);}
t2=C_mutate(&lf[0],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_476,tmp=(C_word)a,a+=2,tmp));
t3=C_mutate(&lf[1],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_506,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate(&lf[2],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_516,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate(&lf[3],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_533,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate(&lf[4],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_542,tmp=(C_word)a,a+=2,tmp));
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_558,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)stub104(C_SCHEME_UNDEFINED))){
t8=t7;
f_558(2,t8,C_SCHEME_UNDEFINED);}
else{
/* tcp.scm: 190  ##sys#signal-hook */
t8=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,lf[14],lf[92]);}}

/* k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_558(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_558,2,t0,t1);}
t2=C_mutate(&lf[5],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_577,tmp=(C_word)a,a+=2,tmp));
t3=C_mutate(&lf[6],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_583,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate(&lf[8],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_597,tmp=(C_word)a,a+=2,tmp));
t5=*((C_word*)lf[11]+1);
t6=C_mutate(&lf[12],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_618,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[20]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_803,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate((C_word*)lf[31]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_898,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate((C_word*)lf[32]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_907,tmp=(C_word)a,a+=2,tmp));
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_942,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* tcp.scm: 324  make-parameter */
t11=*((C_word*)lf[91]+1);
((C_proc3)(void*)(*((C_word*)t11+1)))(3,t11,t10,C_SCHEME_FALSE);}

/* k940 in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_942(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_942,2,t0,t1);}
t2=C_mutate((C_word*)lf[34]+1,t1);
t3=*((C_word*)lf[35]+1);
t4=C_mutate((C_word*)lf[36]+1,t3);
t5=*((C_word*)lf[35]+1);
t6=C_mutate((C_word*)lf[37]+1,t5);
t7=*((C_word*)lf[35]+1);
t8=C_mutate((C_word*)lf[38]+1,t7);
t9=*((C_word*)lf[35]+1);
t10=C_mutate((C_word*)lf[39]+1,t9);
t11=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_960,tmp=(C_word)a,a+=2,tmp);
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_977,a[2]=t11,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2142,a[2]=t12,tmp=(C_word)a,a+=3,tmp);
/* tcp.scm: 335  check */
f_960(t13,lf[36]);}

/* k2140 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_2142(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 335  make-parameter */
t2=*((C_word*)lf[91]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_fix(60000),t1);}

/* k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_977(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_977,2,t0,t1);}
t2=C_mutate((C_word*)lf[36]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_981,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2138,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* tcp.scm: 336  check */
f_960(t4,lf[37]);}

/* k2136 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_2138(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 336  make-parameter */
t2=*((C_word*)lf[91]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_fix(60000),t1);}

/* k979 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_981(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_981,2,t0,t1);}
t2=C_mutate((C_word*)lf[37]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_985,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2134,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* tcp.scm: 337  check */
f_960(t4,lf[38]);}

/* k2132 in k979 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_2134(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 337  make-parameter */
t2=*((C_word*)lf[91]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_SCHEME_FALSE,t1);}

/* k983 in k979 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_985(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_985,2,t0,t1);}
t2=C_mutate((C_word*)lf[38]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_989,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2130,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* tcp.scm: 338  check */
f_960(t4,lf[39]);}

/* k2128 in k983 in k979 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_2130(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 338  make-parameter */
t2=*((C_word*)lf[91]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_SCHEME_FALSE,t1);}

/* k987 in k983 in k979 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_989(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[24],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_989,2,t0,t1);}
t2=C_mutate((C_word*)lf[39]+1,t1);
t3=*((C_word*)lf[40]+1);
t4=*((C_word*)lf[41]+1);
t5=*((C_word*)lf[34]+1);
t6=*((C_word*)lf[23]+1);
t7=C_mutate(&lf[42],(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_991,a[2]=t6,a[3]=t5,a[4]=t3,a[5]=t4,tmp=(C_word)a,a+=6,tmp));
t8=C_mutate((C_word*)lf[63]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1599,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate((C_word*)lf[66]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1685,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate((C_word*)lf[15]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1730,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate((C_word*)lf[78]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1970,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate((C_word*)lf[80]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1980,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate((C_word*)lf[83]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2025,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate((C_word*)lf[86]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2070,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate((C_word*)lf[88]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2099,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate((C_word*)lf[90]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2119,tmp=(C_word)a,a+=2,tmp));
t17=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t17+1)))(2,t17,C_SCHEME_UNDEFINED);}

/* tcp-listener-fileno in k987 in k983 in k979 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_2119(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2119,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[29],lf[90]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(1)));}

/* tcp-abandon-port in k987 in k983 in k979 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_2099(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2099,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2103,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 643  ##sys#check-port */
t4=*((C_word*)lf[89]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[88]);}

/* k2101 in tcp-abandon-port in k987 in k983 in k979 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_2103(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2103,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2110,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 645  ##sys#port-data */
t3=*((C_word*)lf[79]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* k2108 in k2101 in tcp-abandon-port in k987 in k983 in k979 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_2110(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
t3=(C_truep(t2)?C_fix(2):C_fix(1));
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_set_i_slot(t1,t3,C_SCHEME_TRUE));}

/* tcp-listener-port in k987 in k983 in k979 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_2070(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2070,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[29],lf[86]);
t4=(C_word)C_slot(t2,C_fix(1));
t5=f_542(t4);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2083,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_eqp(C_fix(-1),t5);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2093,a[2]=t4,a[3]=t2,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2097,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t10=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t9,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}
else{
t8=t6;
f_2083(2,t8,C_SCHEME_UNDEFINED);}}

/* k2095 in tcp-listener-port in k987 in k983 in k979 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_2097(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 638  ##sys#string-append */
t2=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[87],t1);}

/* k2091 in tcp-listener-port in k987 in k983 in k979 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_2093(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 637  ##sys#signal-hook */
t2=*((C_word*)lf[13]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[4],lf[14],lf[86],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2081 in tcp-listener-port in k987 in k983 in k979 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_2083(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* tcp-port-numbers in k987 in k983 in k979 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_2025(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2025,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2029,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 625  ##sys#tcp-port->fileno */
t4=*((C_word*)lf[78]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k2027 in tcp-port-numbers in k987 in k983 in k979 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_2029(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2029,2,t0,t1);}
t2=f_542(t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2039,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t2)){
t4=t3;
f_2039(2,t4,t2);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2064,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2068,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t6=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}}

/* k2066 in k2027 in tcp-port-numbers in k987 in k983 in k979 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_2068(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 628  ##sys#string-append */
t2=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[85],t1);}

/* k2062 in k2027 in tcp-port-numbers in k987 in k983 in k979 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_2064(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 628  ##sys#signal-hook */
t2=*((C_word*)lf[13]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[14],lf[83],t1,((C_word*)t0)[2]);}

/* k2037 in k2027 in tcp-port-numbers in k987 in k983 in k979 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_2039(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2039,2,t0,t1);}
t2=((C_word*)t0)[4];
t3=(C_word)stub96(C_SCHEME_UNDEFINED,t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2046,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t3)){
t5=t4;
f_2046(2,t5,t3);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2053,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2057,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t7=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}}

/* k2055 in k2037 in k2027 in tcp-port-numbers in k987 in k983 in k979 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_2057(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 630  ##sys#string-append */
t2=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[84],t1);}

/* k2051 in k2037 in k2027 in tcp-port-numbers in k987 in k983 in k979 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_2053(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 630  ##sys#signal-hook */
t2=*((C_word*)lf[13]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[14],lf[83],t1,((C_word*)t0)[2]);}

/* k2044 in k2037 in k2027 in tcp-port-numbers in k987 in k983 in k979 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_2046(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 626  values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* tcp-addresses in k987 in k983 in k979 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_1980(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1980,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1984,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 617  ##sys#tcp-port->fileno */
t4=*((C_word*)lf[78]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k1982 in tcp-addresses in k987 in k983 in k979 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_1984(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1984,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1991,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=t1;
t4=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t5=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,(C_word)stub87(t4,t3),C_fix(0));}

/* k1989 in k1982 in tcp-addresses in k987 in k983 in k979 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_1991(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1991,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1994,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=t2;
f_1994(2,t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2019,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2023,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t5=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}}

/* k2021 in k1989 in k1982 in tcp-addresses in k987 in k983 in k979 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_2023(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 620  ##sys#string-append */
t2=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[82],t1);}

/* k2017 in k1989 in k1982 in tcp-addresses in k987 in k983 in k979 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_2019(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 620  ##sys#signal-hook */
t2=*((C_word*)lf[13]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[14],lf[80],t1,((C_word*)t0)[2]);}

/* k1992 in k1989 in k1982 in tcp-addresses in k987 in k983 in k979 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_1994(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1994,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1998,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[2];
t4=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t5=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,(C_word)stub100(t4,t3),C_fix(0));}

/* k1996 in k1992 in k1989 in k1982 in tcp-addresses in k987 in k983 in k979 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_1998(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1998,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2001,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=t2;
f_2001(2,t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2008,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2012,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t5=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}}

/* k2010 in k1996 in k1992 in k1989 in k1982 in tcp-addresses in k987 in k983 in k979 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_2012(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 622  ##sys#string-append */
t2=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[81],t1);}

/* k2006 in k1996 in k1992 in k1989 in k1982 in tcp-addresses in k987 in k983 in k979 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_2008(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 622  ##sys#signal-hook */
t2=*((C_word*)lf[13]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[14],lf[80],t1,((C_word*)t0)[2]);}

/* k1999 in k1996 in k1992 in k1989 in k1982 in tcp-addresses in k987 in k983 in k979 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_2001(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 618  values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* ##sys#tcp-port->fileno in k987 in k983 in k979 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_1970(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1970,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1978,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* tcp.scm: 614  ##sys#port-data */
t4=*((C_word*)lf[79]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k1976 in ##sys#tcp-port->fileno in k987 in k983 in k979 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_1978(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_slot(t1,C_fix(0)));}

/* tcp-connect in k987 in k983 in k979 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_1730(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr3rv,(void*)f_1730r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_1730r(t0,t1,t2,t3);}}

static void C_ccall f_1730r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(9);
t4=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t5=(C_word)C_vemptyp(t3);
t6=(C_truep(t5)?C_SCHEME_FALSE:(C_word)C_slot(t3,C_fix(0)));
t7=t6;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1737,a[2]=t1,a[3]=t8,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* tcp.scm: 565  tcp-connect-timeout */
t10=*((C_word*)lf[38]+1);
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,t9);}

/* k1735 in tcp-connect in k987 in k983 in k979 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_1737(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1737,2,t0,t1);}
t2=(C_word)C_i_check_string(((C_word*)((C_word*)t0)[4])[1]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1743,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)((C_word*)t0)[3])[1])){
t4=t3;
f_1743(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1939,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1947,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1953,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 568  ##sys#call-with-values */
C_u_call_with_values(4,0,t4,t5,t6);}}

/* a1952 in k1735 in tcp-connect in k987 in k983 in k979 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_1953(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1953,4,t0,t1,t2,t3);}
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t5=C_mutate(((C_word *)((C_word*)t0)[2])+1,t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}

/* a1946 in k1735 in tcp-connect in k987 in k983 in k979 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_1947(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1947,2,t0,t1);}
/* tcp.scm: 568  ##net#parse-host */
t2=lf[12];
f_618(t2,t1,((C_word*)((C_word*)t0)[2])[1],lf[77]);}

/* k1937 in k1735 in tcp-connect in k987 in k983 in k979 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_1939(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t2=((C_word*)t0)[3];
f_1743(2,t2,C_SCHEME_UNDEFINED);}
else{
/* tcp.scm: 569  ##sys#signal-hook */
t2=*((C_word*)lf[13]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[14],lf[15],lf[76],((C_word*)((C_word*)t0)[2])[1]);}}

/* k1741 in k1735 in tcp-connect in k987 in k983 in k979 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_1743(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1743,2,t0,t1);}
t2=(C_word)C_i_check_exact(((C_word*)((C_word*)t0)[5])[1]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1749,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* tcp.scm: 571  make-string */
t4=*((C_word*)lf[23]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,C_fix((C_word)sizeof(struct sockaddr_in)));}

/* k1747 in k1741 in k1735 in tcp-connect in k987 in k983 in k979 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_1749(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1749,2,t0,t1);}
t2=f_476(C_fix((C_word)AF_INET),C_fix((C_word)SOCK_STREAM),C_fix(0));
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1754,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1775,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=((C_word*)t0)[2],a[6]=t1,a[7]=((C_word*)t0)[3],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
t5=(C_word)C_eqp(C_fix(-1),t2);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1925,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* tcp.scm: 580  ##sys#update-errno */
t7=*((C_word*)lf[19]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t6=t4;
f_1775(2,t6,C_SCHEME_UNDEFINED);}}

/* k1923 in k1747 in k1741 in k1735 in tcp-connect in k987 in k983 in k979 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_1925(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1925,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1932,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1936,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k1934 in k1923 in k1747 in k1741 in k1735 in tcp-connect in k987 in k983 in k979 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_1936(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 581  ##sys#string-append */
t2=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[75],t1);}

/* k1930 in k1923 in k1747 in k1741 in k1735 in tcp-connect in k987 in k983 in k979 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_1932(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 581  ##sys#signal-hook */
t2=*((C_word*)lf[13]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[4],lf[14],lf[15],t1,((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1]);}

/* k1773 in k1747 in k1741 in k1735 in tcp-connect in k987 in k983 in k979 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_1775(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1775,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1778,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1916,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 582  ##net#gethostaddr */
f_583(t3,((C_word*)t0)[6],((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1]);}

/* k1914 in k1773 in k1747 in k1741 in k1735 in tcp-connect in k987 in k983 in k979 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_1916(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_1778(2,t2,C_SCHEME_UNDEFINED);}
else{
/* tcp.scm: 583  ##sys#signal-hook */
t2=*((C_word*)lf[13]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[14],lf[15],lf[74],((C_word*)((C_word*)t0)[2])[1]);}}

/* k1776 in k1773 in k1747 in k1741 in k1735 in tcp-connect in k987 in k983 in k979 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_1778(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1778,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1781,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=f_533(((C_word*)t0)[6]);
if(C_truep(t3)){
t4=t2;
f_1781(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1902,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* tcp.scm: 585  ##sys#update-errno */
t5=*((C_word*)lf[19]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k1900 in k1776 in k1773 in k1747 in k1741 in k1735 in tcp-connect in k987 in k983 in k979 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_1902(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1902,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1909,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1913,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k1911 in k1900 in k1776 in k1773 in k1747 in k1741 in k1735 in tcp-connect in k987 in k983 in k979 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_1913(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 586  ##sys#string-append */
t2=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[73],t1);}

/* k1907 in k1900 in k1776 in k1773 in k1747 in k1741 in k1735 in tcp-connect in k987 in k983 in k979 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_1909(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 586  ##sys#signal-hook */
t2=*((C_word*)lf[13]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[14],lf[15],t1);}

/* k1779 in k1776 in k1773 in k1747 in k1741 in k1735 in tcp-connect in k987 in k983 in k979 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_1781(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1781,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1784,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[4];
t4=C_fix((C_word)sizeof(struct sockaddr_in));
t5=(C_truep(t3)?t3:C_SCHEME_FALSE);
t6=(C_word)stub61(C_SCHEME_UNDEFINED,((C_word*)t0)[6],t5,t4);
t7=(C_word)C_eqp(C_fix(-1),t6);
if(C_truep(t7)){
t8=(C_word)C_eqp(C_fix((C_word)errno),C_fix((C_word)EINPROGRESS));
if(C_truep(t8)){
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1838,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t10,a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp));
t12=((C_word*)t10)[1];
f_1838(t12,t2);}
else{
/* tcp.scm: 605  fail */
t9=((C_word*)t0)[2];
f_1754(t9,t2);}}
else{
t8=t2;
f_1784(2,t8,C_SCHEME_UNDEFINED);}}

/* loop in k1779 in k1776 in k1773 in k1747 in k1741 in k1735 in tcp-connect in k987 in k983 in k979 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_fcall f_1838(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1838,NULL,2,t0,t1);}
t2=(C_word)stub121(C_SCHEME_UNDEFINED,((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1845,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_eqp(t2,C_fix(-1));
if(C_truep(t4)){
/* tcp.scm: 591  fail */
t5=((C_word*)t0)[2];
f_1754(t5,t3);}
else{
t5=t3;
f_1845(2,t5,C_SCHEME_UNDEFINED);}}

/* k1843 in loop in k1779 in k1776 in k1773 in k1747 in k1741 in k1735 in tcp-connect in k987 in k983 in k979 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_1845(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1845,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[6],C_fix(1));
if(C_truep(t2)){
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1854,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
t4=(C_word)C_fudge(C_fix(16));
t5=(C_word)C_u_fixnum_plus(t4,((C_word*)t0)[2]);
/* tcp.scm: 594  ##sys#thread-block-for-timeout! */
t6=*((C_word*)lf[45]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,*((C_word*)lf[9]+1),t5);}
else{
t4=t3;
f_1854(2,t4,C_SCHEME_UNDEFINED);}}}

/* k1852 in k1843 in loop in k1779 in k1776 in k1773 in k1747 in k1741 in k1735 in tcp-connect in k987 in k983 in k979 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_1854(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1854,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1857,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* tcp.scm: 597  ##sys#thread-block-for-i/o! */
t3=*((C_word*)lf[44]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,*((C_word*)lf[9]+1),((C_word*)t0)[2],lf[72]);}

/* k1855 in k1852 in k1843 in loop in k1779 in k1776 in k1773 in k1747 in k1741 in k1735 in tcp-connect in k987 in k983 in k979 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_1857(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1857,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1860,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* tcp.scm: 598  yield */
f_597(t2);}

/* k1858 in k1855 in k1852 in k1843 in loop in k1779 in k1776 in k1773 in k1747 in k1741 in k1735 in tcp-connect in k987 in k983 in k979 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_1860(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1860,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1863,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_slot(*((C_word*)lf[9]+1),C_fix(13)))){
/* tcp.scm: 600  ##sys#signal-hook */
t3=*((C_word*)lf[13]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,lf[14],lf[15],lf[71],((C_word*)t0)[2]);}
else{
t3=t2;
f_1863(2,t3,C_SCHEME_UNDEFINED);}}

/* k1861 in k1858 in k1855 in k1852 in k1843 in loop in k1779 in k1776 in k1773 in k1747 in k1741 in k1735 in tcp-connect in k987 in k983 in k979 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_1863(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 604  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_1838(t2,((C_word*)t0)[2]);}

/* k1782 in k1779 in k1776 in k1773 in k1747 in k1741 in k1735 in tcp-connect in k987 in k983 in k979 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_1784(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[24],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1784,2,t0,t1);}
t2=(C_word)stub342(C_SCHEME_UNDEFINED,((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1790,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_eqp(t2,C_fix(-1));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1803,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1807,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t7=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}
else{
if(C_truep((C_word)C_fixnum_greaterp(t2,C_fix(0)))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1820,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1824,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t8=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,(C_word)stub346(t7,t2),C_fix(0));}
else{
t5=t3;
f_1790(2,t5,C_SCHEME_UNDEFINED);}}}

/* k1822 in k1782 in k1779 in k1776 in k1773 in k1747 in k1741 in k1735 in tcp-connect in k987 in k983 in k979 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_1824(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 610  ##sys#string-append */
t2=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[70],t1);}

/* k1818 in k1782 in k1779 in k1776 in k1773 in k1747 in k1741 in k1735 in tcp-connect in k987 in k983 in k979 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_1820(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 610  ##sys#signal-hook */
t2=*((C_word*)lf[13]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[14],lf[15],t1);}

/* k1805 in k1782 in k1779 in k1776 in k1773 in k1747 in k1741 in k1735 in tcp-connect in k987 in k983 in k979 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_1807(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 608  ##sys#string-append */
t2=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[69],t1);}

/* k1801 in k1782 in k1779 in k1776 in k1773 in k1747 in k1741 in k1735 in tcp-connect in k987 in k983 in k979 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_1803(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 608  ##sys#signal-hook */
t2=*((C_word*)lf[13]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[14],lf[15],t1);}

/* k1788 in k1782 in k1779 in k1776 in k1773 in k1747 in k1741 in k1735 in tcp-connect in k987 in k983 in k979 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_1790(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 611  ##net#io-ports */
t2=lf[42];
f_991(t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* fail in k1747 in k1741 in k1735 in tcp-connect in k987 in k983 in k979 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_fcall f_1754(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1754,NULL,2,t0,t1);}
t2=f_506(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1761,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* tcp.scm: 575  ##sys#update-errno */
t4=*((C_word*)lf[19]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k1759 in fail in k1747 in k1741 in k1735 in tcp-connect in k987 in k983 in k979 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_1761(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1761,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1768,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1772,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k1770 in k1759 in fail in k1747 in k1741 in k1735 in tcp-connect in k987 in k983 in k979 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_1772(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 577  ##sys#string-append */
t2=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[68],t1);}

/* k1766 in k1759 in fail in k1747 in k1741 in k1735 in tcp-connect in k987 in k983 in k979 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_1768(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 576  ##sys#signal-hook */
t2=*((C_word*)lf[13]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[4],lf[14],lf[15],t1,((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1]);}

/* tcp-accept-ready? in k987 in k983 in k979 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_1685(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1685,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[29],lf[66]);
t4=(C_word)C_slot(t2,C_fix(1));
t5=f_577(t4);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1695,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_eqp(C_fix(-1),t5);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1704,a[2]=t2,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 547  ##sys#update-errno */
t9=*((C_word*)lf[19]+1);
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}
else{
t8=t6;
f_1695(2,t8,C_SCHEME_UNDEFINED);}}

/* k1702 in tcp-accept-ready? in k987 in k983 in k979 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_1704(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1704,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1711,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1715,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k1713 in k1702 in tcp-accept-ready? in k987 in k983 in k979 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_1715(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 549  ##sys#string-append */
t2=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[67],t1);}

/* k1709 in k1702 in tcp-accept-ready? in k987 in k983 in k979 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_1711(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 548  ##sys#signal-hook */
t2=*((C_word*)lf[13]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[14],lf[66],t1,((C_word*)t0)[2]);}

/* k1693 in tcp-accept-ready? in k987 in k983 in k979 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_1695(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_eqp(C_fix(1),((C_word*)t0)[2]));}

/* tcp-accept in k987 in k983 in k979 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_1599(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1599,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[29]);
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1609,a[2]=t1,a[3]=t2,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* tcp.scm: 519  tcp-accept-timeout */
t6=*((C_word*)lf[39]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}

/* k1607 in tcp-accept in k987 in k983 in k979 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_1609(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1609,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1614,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_1614(t5,((C_word*)t0)[2]);}

/* loop in k1607 in tcp-accept in k987 in k983 in k979 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_fcall f_1614(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1614,NULL,2,t0,t1);}
t2=f_577(((C_word*)t0)[5]);
t3=(C_word)C_eqp(C_fix(1),t2);
if(C_truep(t3)){
t4=(C_word)stub27(C_SCHEME_UNDEFINED,((C_word*)t0)[5],C_SCHEME_FALSE,C_SCHEME_FALSE);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1627,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_eqp(C_fix(-1),t4);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1636,a[2]=((C_word*)t0)[4],a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 524  ##sys#update-errno */
t8=*((C_word*)lf[19]+1);
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}
else{
t7=t5;
f_1627(2,t7,C_SCHEME_UNDEFINED);}}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1650,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
t5=(C_word)C_fudge(C_fix(16));
t6=(C_word)C_u_fixnum_plus(t5,((C_word*)t0)[2]);
/* tcp.scm: 531  ##sys#thread-block-for-timeout! */
t7=*((C_word*)lf[45]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t4,*((C_word*)lf[9]+1),t6);}
else{
t5=t4;
f_1650(2,t5,C_SCHEME_UNDEFINED);}}}

/* k1648 in loop in k1607 in tcp-accept in k987 in k983 in k979 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_1650(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1650,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1653,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* tcp.scm: 534  ##sys#thread-block-for-i/o! */
t3=*((C_word*)lf[44]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,*((C_word*)lf[9]+1),((C_word*)t0)[2],C_SCHEME_TRUE);}

/* k1651 in k1648 in loop in k1607 in tcp-accept in k987 in k983 in k979 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_1653(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1653,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1656,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* tcp.scm: 535  yield */
f_597(t2);}

/* k1654 in k1651 in k1648 in loop in k1607 in tcp-accept in k987 in k983 in k979 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_1656(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1656,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1659,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_slot(*((C_word*)lf[9]+1),C_fix(13)))){
/* tcp.scm: 537  ##sys#signal-hook */
t3=*((C_word*)lf[13]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,lf[14],lf[63],lf[65],((C_word*)t0)[2]);}
else{
t3=t2;
f_1659(2,t3,C_SCHEME_UNDEFINED);}}

/* k1657 in k1654 in k1651 in k1648 in loop in k1607 in tcp-accept in k987 in k983 in k979 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_1659(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 541  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_1614(t2,((C_word*)t0)[2]);}

/* k1634 in loop in k1607 in tcp-accept in k987 in k983 in k979 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_1636(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1636,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1643,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1647,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k1645 in k1634 in loop in k1607 in tcp-accept in k987 in k983 in k979 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_1647(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 526  ##sys#string-append */
t2=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[64],t1);}

/* k1641 in k1634 in loop in k1607 in tcp-accept in k987 in k983 in k979 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_1643(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 525  ##sys#signal-hook */
t2=*((C_word*)lf[13]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[14],lf[63],t1,((C_word*)t0)[2]);}

/* k1625 in loop in k1607 in tcp-accept in k987 in k983 in k979 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_1627(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 528  ##net#io-ports */
t2=lf[42];
f_991(t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##net#io-ports in k987 in k983 in k979 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_fcall f_991(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_991,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_995,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t4=f_533(t2);
if(C_truep(t4)){
t5=t3;
f_995(2,t5,C_SCHEME_UNDEFINED);}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1586,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* tcp.scm: 347  ##sys#update-errno */
t6=*((C_word*)lf[19]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}}

/* k1584 in ##net#io-ports in k987 in k983 in k979 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_1586(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1586,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1593,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1597,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k1595 in k1584 in ##net#io-ports in k987 in k983 in k979 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_1597(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 348  ##sys#string-append */
t2=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[62],t1);}

/* k1591 in k1584 in ##net#io-ports in k987 in k983 in k979 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_1593(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 348  ##sys#signal-hook */
t2=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[14],t1);}

/* k993 in ##net#io-ports in k987 in k983 in k979 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_995(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_995,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_998,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* tcp.scm: 349  make-string */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,C_fix(1024));}

/* k996 in k993 in ##net#io-ports in k987 in k983 in k979 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_998(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[24],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_998,2,t0,t1);}
t2=(C_word)C_a_i_vector(&a,3,((C_word*)t0)[6],C_SCHEME_FALSE,C_SCHEME_FALSE);
t3=C_fix(0);
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_fix(0);
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_FALSE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_FALSE;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_1004,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t8,a[5]=t10,a[6]=((C_word*)t0)[5],a[7]=t2,a[8]=t6,a[9]=t4,a[10]=t1,a[11]=((C_word*)t0)[6],tmp=(C_word)a,a+=12,tmp);
/* tcp.scm: 355  tbs */
t12=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,t11);}

/* k1002 in k996 in k993 in ##net#io-ports in k987 in k983 in k979 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_1004(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1004,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_1007,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
if(C_truep(t1)){
t3=(C_word)C_fixnum_greaterp(t1,C_fix(0));
t4=t2;
f_1007(t4,(C_truep(t3)?lf[61]:C_SCHEME_FALSE));}
else{
t3=t2;
f_1007(t3,C_SCHEME_FALSE);}}

/* k1005 in k1002 in k996 in k993 in ##net#io-ports in k987 in k983 in k979 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_fcall f_1007(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1007,NULL,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_1010,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t3,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
/* tcp.scm: 357  tcp-read-timeout */
t5=*((C_word*)lf[36]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* k1008 in k1005 in k1002 in k996 in k993 in ##net#io-ports in k987 in k983 in k979 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_1010(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1010,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_1013,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=t1,a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],tmp=(C_word)a,a+=15,tmp);
/* tcp.scm: 358  tcp-write-timeout */
t3=*((C_word*)lf[37]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k1011 in k1008 in k1005 in k1002 in k996 in k993 in ##net#io-ports in k987 in k983 in k979 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_1013(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[47],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1013,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1014,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[12],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[14],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1087,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=t1,a[10]=((C_word*)t0)[14],tmp=(C_word)a,a+=11,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1325,a[2]=t2,a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[10],tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1347,a[2]=((C_word*)t0)[14],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1382,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[14],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1425,a[2]=t2,a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[10],tmp=(C_word)a,a+=6,tmp);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1490,a[2]=t2,a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[10],tmp=(C_word)a,a+=6,tmp);
/* tcp.scm: 386  make-input-port */
t9=((C_word*)t0)[2];
((C_proc8)(void*)(*((C_word*)t9+1)))(8,t9,t3,t4,t5,t6,C_SCHEME_FALSE,t7,t8);}

/* a1489 in k1011 in k1008 in k1005 in k1002 in k996 in k993 in ##net#io-ports in k987 in k983 in k979 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_1490(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1490,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1496,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t5,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp));
t7=((C_word*)t5)[1];
f_1496(t7,t1,C_SCHEME_FALSE);}

/* loop in a1489 in k1011 in k1008 in k1005 in k1002 in k996 in k993 in ##net#io-ports in k987 in k983 in k979 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_fcall f_1496(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1496,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[7])[1],((C_word*)((C_word*)t0)[6])[1]))){
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1508,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
/* tcp.scm: 433  ##sys#scan-buffer-line */
t4=*((C_word*)lf[60]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t1,((C_word*)t0)[5],((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[7])[1],t3);}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1565,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* tcp.scm: 450  read-input */
t4=((C_word*)t0)[3];
f_1014(t4,t3);}}

/* k1563 in loop in a1489 in k1011 in k1008 in k1005 in k1002 in k996 in k993 in ##net#io-ports in k987 in k983 in k979 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_1565(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[5])[1]))){
/* tcp.scm: 452  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_1496(t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_FILE);}}

/* a1507 in loop in a1489 in k1011 in k1008 in k1005 in k1002 in k996 in k993 in ##net#io-ports in k987 in k983 in k979 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_1508(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1508,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_1512,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t3,a[9]=t2,a[10]=((C_word*)t0)[7],a[11]=((C_word*)t0)[8],tmp=(C_word)a,a+=12,tmp);
t5=(C_word)C_u_fixnum_difference(t2,((C_word*)((C_word*)t0)[7])[1]);
/* tcp.scm: 438  ##sys#make-string */
t6=*((C_word*)lf[59]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}

/* k1510 in a1507 in loop in a1489 in k1011 in k1008 in k1005 in k1002 in k996 in k993 in ##net#io-ports in k987 in k983 in k979 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_1512(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1512,2,t0,t1);}
t2=(C_word)C_substring_copy(((C_word*)t0)[11],t1,((C_word*)((C_word*)t0)[10])[1],((C_word*)t0)[9],C_fix(0));
t3=C_mutate(((C_word *)((C_word*)t0)[10])+1,((C_word*)t0)[8]);
t4=(C_word)C_eqp(((C_word*)t0)[9],((C_word*)t0)[8]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1522,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
/* tcp.scm: 442  read-input */
t6=((C_word*)t0)[3];
f_1014(t6,t5);}
else{
t5=(C_word)C_slot(((C_word*)t0)[2],C_fix(4));
t6=(C_word)C_u_fixnum_plus(t5,C_fix(1));
t7=(C_word)C_i_set_i_slot(((C_word*)t0)[2],C_fix(4),t6);
if(C_truep(((C_word*)t0)[6])){
/* tcp.scm: 448  ##sys#string-append */
t8=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,((C_word*)t0)[5],((C_word*)t0)[6],t1);}
else{
t8=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t1);}}}

/* k1520 in k1510 in a1507 in loop in a1489 in k1011 in k1008 in k1005 in k1002 in k996 in k993 in ##net#io-ports in k987 in k983 in k979 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_1522(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1522,2,t0,t1);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(((C_word*)((C_word*)t0)[7])[1],((C_word*)((C_word*)t0)[6])[1]))){
t2=((C_word*)t0)[5];
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?t2:lf[58]));}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1538,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[5])){
/* tcp.scm: 445  ##sys#string-append */
t3=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[5],((C_word*)t0)[2]);}
else{
t3=t2;
f_1538(2,t3,((C_word*)t0)[2]);}}}

/* k1536 in k1520 in k1510 in a1507 in loop in a1489 in k1011 in k1008 in k1005 in k1002 in k996 in k993 in ##net#io-ports in k987 in k983 in k979 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_1538(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 445  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_1496(t2,((C_word*)t0)[2],t1);}

/* a1424 in k1011 in k1008 in k1005 in k1002 in k996 in k993 in ##net#io-ports in k987 in k983 in k979 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_1425(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_1425,6,t0,t1,t2,t3,t4,t5);}
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1431,a[2]=((C_word*)t0)[2],a[3]=t7,a[4]=t4,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp));
t9=((C_word*)t7)[1];
f_1431(t9,t1,t3,C_fix(0),t5);}

/* loop in a1424 in k1011 in k1008 in k1005 in k1002 in k996 in k993 in ##net#io-ports in k987 in k983 in k979 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_fcall f_1431(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word *a;
loop:
a=C_alloc(8);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1431,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t3);}
else{
if(C_truep((C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[7])[1],((C_word*)((C_word*)t0)[6])[1]))){
t6=(C_word)C_u_fixnum_difference(((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[7])[1]);
t7=(C_word)C_fixnum_lessp(t2,t6);
t8=(C_truep(t7)?t2:t6);
t9=(C_word)C_u_fixnum_plus(((C_word*)((C_word*)t0)[7])[1],t8);
t10=(C_word)C_substring_copy(((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)((C_word*)t0)[7])[1],t9,t4);
t11=(C_word)C_u_fixnum_plus(((C_word*)((C_word*)t0)[7])[1],t8);
t12=C_mutate(((C_word *)((C_word*)t0)[7])+1,t11);
t13=(C_word)C_u_fixnum_difference(t2,t8);
t14=(C_word)C_u_fixnum_plus(t3,t8);
t15=(C_word)C_u_fixnum_plus(t4,t8);
/* tcp.scm: 424  loop */
t18=t1;
t19=t13;
t20=t14;
t21=t15;
t1=t18;
t2=t19;
t3=t20;
t4=t21;
goto loop;}
else{
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1479,a[2]=t4,a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* tcp.scm: 426  read-input */
t7=((C_word*)t0)[2];
f_1014(t7,t6);}}}

/* k1477 in loop in a1424 in k1011 in k1008 in k1005 in k1002 in k996 in k993 in ##net#io-ports in k987 in k983 in k979 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_1479(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(((C_word*)((C_word*)t0)[7])[1],C_fix(0));
if(C_truep(t2)){
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[5]);}
else{
/* tcp.scm: 429  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_1431(t3,((C_word*)t0)[6],((C_word*)t0)[3],((C_word*)t0)[5],((C_word*)t0)[2]);}}

/* a1381 in k1011 in k1008 in k1005 in k1002 in k996 in k993 in ##net#io-ports in k987 in k983 in k979 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_1382(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1382,2,t0,t1);}
if(C_truep(((C_word*)((C_word*)t0)[5])[1])){
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=C_set_block_item(((C_word*)t0)[5],0,C_SCHEME_TRUE);
t3=(C_truep((C_word)C_slot(((C_word*)t0)[4],C_fix(1)))?C_SCHEME_UNDEFINED:f_516(((C_word*)t0)[3],C_fix((C_word)SD_RECEIVE)));
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1396,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t5=f_506(((C_word*)t0)[3]);
t6=t4;
f_1396(t6,(C_word)C_eqp(C_fix(-1),t5));}
else{
t5=t4;
f_1396(t5,C_SCHEME_FALSE);}}}

/* k1394 in a1381 in k1011 in k1008 in k1005 in k1002 in k996 in k993 in ##net#io-ports in k987 in k983 in k979 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_fcall f_1396(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1396,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1399,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 410  ##sys#update-errno */
t3=*((C_word*)lf[19]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k1397 in k1394 in a1381 in k1011 in k1008 in k1005 in k1002 in k996 in k993 in ##net#io-ports in k987 in k983 in k979 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_1399(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1399,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1406,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1410,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k1408 in k1397 in k1394 in a1381 in k1011 in k1008 in k1005 in k1002 in k996 in k993 in ##net#io-ports in k987 in k983 in k979 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_1410(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 413  ##sys#string-append */
t2=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[57],t1);}

/* k1404 in k1397 in k1394 in a1381 in k1011 in k1008 in k1005 in k1002 in k996 in k993 in ##net#io-ports in k987 in k983 in k979 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_1406(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 411  ##sys#signal-hook */
t2=*((C_word*)lf[13]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[14],t1,((C_word*)t0)[2]);}

/* a1346 in k1011 in k1008 in k1005 in k1002 in k996 in k993 in ##net#io-ports in k987 in k983 in k979 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_1347(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1347,2,t0,t1);}
t2=(C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[4])[1],((C_word*)((C_word*)t0)[3])[1]);
if(C_truep(t2)){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=f_577(((C_word*)t0)[2]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1360,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_eqp(t3,C_fix(-1));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1369,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 399  ##sys#update-errno */
t7=*((C_word*)lf[19]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t6=t4;
f_1360(2,t6,C_SCHEME_UNDEFINED);}}}

/* k1367 in a1346 in k1011 in k1008 in k1005 in k1002 in k996 in k993 in ##net#io-ports in k987 in k983 in k979 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_1369(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1369,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1376,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1380,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k1378 in k1367 in a1346 in k1011 in k1008 in k1005 in k1002 in k996 in k993 in ##net#io-ports in k987 in k983 in k979 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_1380(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 402  ##sys#string-append */
t2=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[56],t1);}

/* k1374 in k1367 in a1346 in k1011 in k1008 in k1005 in k1002 in k996 in k993 in ##net#io-ports in k987 in k983 in k979 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_1376(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 400  ##sys#signal-hook */
t2=*((C_word*)lf[13]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[14],t1,((C_word*)t0)[2]);}

/* k1358 in a1346 in k1011 in k1008 in k1005 in k1002 in k996 in k993 in ##net#io-ports in k987 in k983 in k979 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_1360(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_eqp(((C_word*)t0)[2],C_fix(1)));}

/* a1324 in k1011 in k1008 in k1005 in k1002 in k996 in k993 in ##net#io-ports in k987 in k983 in k979 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_1325(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1325,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1329,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(((C_word*)((C_word*)t0)[5])[1],((C_word*)((C_word*)t0)[4])[1]))){
/* tcp.scm: 389  read-input */
t3=((C_word*)t0)[2];
f_1014(t3,t2);}
else{
t3=t2;
f_1329(2,t3,C_SCHEME_UNDEFINED);}}

/* k1327 in a1324 in k1011 in k1008 in k1005 in k1002 in k996 in k993 in ##net#io-ports in k987 in k983 in k979 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_1329(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(((C_word*)((C_word*)t0)[5])[1],((C_word*)((C_word*)t0)[4])[1]))){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_FILE);}
else{
t2=(C_word)C_subchar(((C_word*)t0)[2],((C_word*)((C_word*)t0)[5])[1]);
t3=(C_word)C_u_fixnum_plus(((C_word*)((C_word*)t0)[5])[1],C_fix(1));
t4=C_mutate(((C_word *)((C_word*)t0)[5])+1,t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t2);}}

/* k1085 in k1011 in k1008 in k1005 in k1002 in k996 in k993 in ##net#io-ports in k987 in k983 in k979 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_1087(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[29],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1087,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1088,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1183,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_truep(((C_word*)((C_word*)t0)[6])[1])?(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1289,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp):(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1309,a[2]=t2,tmp=(C_word)a,a+=3,tmp));
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1210,a[2]=t2,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
t6=(C_truep(((C_word*)((C_word*)t0)[6])[1])?(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1273,a[2]=t2,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp):C_SCHEME_FALSE);
/* tcp.scm: 482  make-output-port */
t7=((C_word*)t0)[2];
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t3,t4,t5,t6);}

/* f_1273 in k1085 in k1011 in k1008 in k1005 in k1002 in k996 in k993 in ##net#io-ports in k987 in k983 in k979 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_1273(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1273,2,t0,t1);}
t2=(C_word)C_block_size(((C_word*)((C_word*)t0)[3])[1]);
if(C_truep((C_word)C_fixnum_greaterp(t2,C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1283,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 506  output */
t4=((C_word*)t0)[2];
f_1088(t4,t3,((C_word*)((C_word*)t0)[3])[1]);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k1281 */
static void C_ccall f_1283(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,lf[55]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* a1209 in k1085 in k1011 in k1008 in k1005 in k1002 in k996 in k993 in ##net#io-ports in k987 in k983 in k979 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_1210(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1210,2,t0,t1);}
if(C_truep(((C_word*)((C_word*)t0)[7])[1])){
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=C_set_block_item(((C_word*)t0)[7],0,C_SCHEME_TRUE);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1218,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1257,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)((C_word*)t0)[3])[1])){
t5=(C_word)C_block_size(((C_word*)((C_word*)t0)[3])[1]);
t6=t4;
f_1257(t6,(C_word)C_fixnum_greaterp(t5,C_fix(0)));}
else{
t5=t4;
f_1257(t5,C_SCHEME_FALSE);}}}

/* k1255 in a1209 in k1085 in k1011 in k1008 in k1005 in k1002 in k996 in k993 in ##net#io-ports in k987 in k983 in k979 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_fcall f_1257(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1257,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1260,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 496  output */
t3=((C_word*)t0)[2];
f_1088(t3,t2,((C_word*)((C_word*)t0)[4])[1]);}
else{
t2=((C_word*)t0)[3];
f_1218(t2,C_SCHEME_UNDEFINED);}}

/* k1258 in k1255 in a1209 in k1085 in k1011 in k1008 in k1005 in k1002 in k996 in k993 in ##net#io-ports in k987 in k983 in k979 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_1260(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,lf[54]);
t3=((C_word*)t0)[2];
f_1218(t3,t2);}

/* k1216 in a1209 in k1085 in k1011 in k1008 in k1005 in k1002 in k996 in k993 in ##net#io-ports in k987 in k983 in k979 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_fcall f_1218(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1218,NULL,2,t0,t1);}
t2=(C_truep((C_word)C_slot(((C_word*)t0)[5],C_fix(2)))?C_SCHEME_UNDEFINED:f_516(((C_word*)t0)[4],C_fix((C_word)SD_SEND)));
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1227,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t4=f_506(((C_word*)t0)[4]);
t5=t3;
f_1227(t5,(C_word)C_eqp(C_fix(-1),t4));}
else{
t4=t3;
f_1227(t4,C_SCHEME_FALSE);}}

/* k1225 in k1216 in a1209 in k1085 in k1011 in k1008 in k1005 in k1002 in k996 in k993 in ##net#io-ports in k987 in k983 in k979 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_fcall f_1227(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1227,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1230,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 500  ##sys#update-errno */
t3=*((C_word*)lf[19]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k1228 in k1225 in k1216 in a1209 in k1085 in k1011 in k1008 in k1005 in k1002 in k996 in k993 in ##net#io-ports in k987 in k983 in k979 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_1230(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1230,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1237,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1241,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k1239 in k1228 in k1225 in k1216 in a1209 in k1085 in k1011 in k1008 in k1005 in k1002 in k996 in k993 in ##net#io-ports in k987 in k983 in k979 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_1241(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 502  ##sys#string-append */
t2=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[53],t1);}

/* k1235 in k1228 in k1225 in k1216 in a1209 in k1085 in k1011 in k1008 in k1005 in k1002 in k996 in k993 in ##net#io-ports in k987 in k983 in k979 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_1237(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 501  ##sys#signal-hook */
t2=*((C_word*)lf[13]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[14],t1,((C_word*)t0)[2]);}

/* f_1309 in k1085 in k1011 in k1008 in k1005 in k1002 in k996 in k993 in ##net#io-ports in k987 in k983 in k979 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_1309(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1309,3,t0,t1,t2);}
t3=(C_word)C_block_size(t2);
if(C_truep((C_word)C_fixnum_greaterp(t3,C_fix(0)))){
/* tcp.scm: 491  output */
t4=((C_word*)t0)[2];
f_1088(t4,t1,t2);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* f_1289 in k1085 in k1011 in k1008 in k1005 in k1002 in k996 in k993 in ##net#io-ports in k987 in k983 in k979 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_1289(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1289,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1294,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* tcp.scm: 485  ##sys#string-append */
t4=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)((C_word*)t0)[4])[1],t2);}

/* k1292 */
static void C_ccall f_1294(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1294,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=(C_word)C_block_size(((C_word*)((C_word*)t0)[5])[1]);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[4]))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1303,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 487  output */
t5=((C_word*)t0)[2];
f_1088(t5,t4,((C_word*)((C_word*)t0)[5])[1]);}
else{
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k1301 in k1292 */
static void C_ccall f_1303(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,lf[52]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k1181 in k1085 in k1011 in k1008 in k1005 in k1002 in k996 in k993 in ##net#io-ports in k987 in k983 in k979 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_1183(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[4],C_fix(3),lf[49]);
t3=(C_word)C_i_setslot(t1,C_fix(3),lf[50]);
t4=(C_word)C_i_setslot(((C_word*)t0)[4],C_fix(7),lf[51]);
t5=(C_word)C_i_setslot(t1,C_fix(7),lf[51]);
t6=(C_word)C_i_setslot(((C_word*)t0)[4],C_fix(9),((C_word*)t0)[3]);
t7=(C_word)C_i_setslot(t1,C_fix(9),((C_word*)t0)[3]);
/* tcp.scm: 514  values */
C_values(4,0,((C_word*)t0)[2],((C_word*)t0)[4],t1);}

/* output in k1085 in k1011 in k1008 in k1005 in k1002 in k996 in k993 in ##net#io-ports in k987 in k983 in k979 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_fcall f_1088(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1088,NULL,3,t0,t1,t2);}
t3=(C_word)C_block_size(t2);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1098,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=t2,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_1098(t7,t1,t3,C_fix(0));}

/* loop in output in k1085 in k1011 in k1008 in k1005 in k1002 in k996 in k993 in ##net#io-ports in k987 in k983 in k979 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_fcall f_1098(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word *a;
loop:
a=C_alloc(11);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1098,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_fixnum_min(C_fix(8192),t2);
t5=((C_word*)t0)[5];
t6=((C_word*)t0)[4];
t7=t3;
t8=(C_truep(t6)?t6:C_SCHEME_FALSE);
t9=(C_word)stub73(C_SCHEME_UNDEFINED,t5,t8,t7,t4,C_fix(0));
t10=(C_word)C_eqp(C_fix(-1),t9);
if(C_truep(t10)){
t11=(C_word)C_eqp(C_fix((C_word)errno),C_fix((C_word)EWOULDBLOCK));
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1120,a[2]=((C_word*)t0)[5],a[3]=t3,a[4]=t2,a[5]=t1,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[2])){
t13=(C_word)C_fudge(C_fix(16));
t14=(C_word)C_u_fixnum_plus(t13,((C_word*)t0)[2]);
/* tcp.scm: 463  ##sys#thread-block-for-timeout! */
t15=*((C_word*)lf[45]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t12,*((C_word*)lf[9]+1),t14);}
else{
t13=t12;
f_1120(2,t13,C_SCHEME_UNDEFINED);}}
else{
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1152,a[2]=((C_word*)t0)[5],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 474  ##sys#update-errno */
t13=*((C_word*)lf[19]+1);
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,t12);}}
else{
if(C_truep((C_word)C_fixnum_lessp(t9,t2))){
t11=(C_word)C_u_fixnum_difference(t2,t9);
t12=(C_word)C_u_fixnum_plus(t3,t9);
/* tcp.scm: 480  loop */
t19=t1;
t20=t11;
t21=t12;
t1=t19;
t2=t20;
t3=t21;
goto loop;}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_UNDEFINED);}}}

/* k1150 in loop in output in k1085 in k1011 in k1008 in k1005 in k1002 in k996 in k993 in ##net#io-ports in k987 in k983 in k979 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_1152(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1152,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1159,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1163,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k1161 in k1150 in loop in output in k1085 in k1011 in k1008 in k1005 in k1002 in k996 in k993 in ##net#io-ports in k987 in k983 in k979 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_1163(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 477  ##sys#string-append */
t2=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[48],t1);}

/* k1157 in k1150 in loop in output in k1085 in k1011 in k1008 in k1005 in k1002 in k996 in k993 in ##net#io-ports in k987 in k983 in k979 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_1159(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 475  ##sys#signal-hook */
t2=*((C_word*)lf[13]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[14],t1,((C_word*)t0)[2]);}

/* k1118 in loop in output in k1085 in k1011 in k1008 in k1005 in k1002 in k996 in k993 in ##net#io-ports in k987 in k983 in k979 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_1120(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1120,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1123,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* tcp.scm: 466  ##sys#thread-block-for-i/o! */
t3=*((C_word*)lf[44]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,*((C_word*)lf[9]+1),((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k1121 in k1118 in loop in output in k1085 in k1011 in k1008 in k1005 in k1002 in k996 in k993 in ##net#io-ports in k987 in k983 in k979 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_1123(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1123,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1126,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* tcp.scm: 467  yield */
f_597(t2);}

/* k1124 in k1121 in k1118 in loop in output in k1085 in k1011 in k1008 in k1005 in k1002 in k996 in k993 in ##net#io-ports in k987 in k983 in k979 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_1126(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1126,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1129,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_slot(*((C_word*)lf[9]+1),C_fix(13)))){
/* tcp.scm: 469  ##sys#signal-hook */
t3=*((C_word*)lf[13]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[14],lf[47],((C_word*)t0)[2]);}
else{
t3=t2;
f_1129(2,t3,C_SCHEME_UNDEFINED);}}

/* k1127 in k1124 in k1121 in k1118 in loop in output in k1085 in k1011 in k1008 in k1005 in k1002 in k996 in k993 in ##net#io-ports in k987 in k983 in k979 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_1129(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 472  loop */
t2=((C_word*)((C_word*)t0)[5])[1];
f_1098(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* read-input in k1011 in k1008 in k1005 in k1002 in k996 in k993 in ##net#io-ports in k987 in k983 in k979 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_fcall f_1014(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1014,NULL,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1020,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp));
t5=((C_word*)t3)[1];
f_1020(t5,t1);}

/* loop in read-input in k1011 in k1008 in k1005 in k1002 in k996 in k993 in ##net#io-ports in k987 in k983 in k979 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_fcall f_1020(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1020,NULL,2,t0,t1);}
t2=((C_word*)t0)[7];
t3=((C_word*)t0)[6];
t4=(C_truep(t3)?t3:C_SCHEME_FALSE);
t5=(C_word)stub44(C_SCHEME_UNDEFINED,t2,t4,C_fix(1024),C_fix(0));
t6=(C_word)C_eqp(C_fix(-1),t5);
if(C_truep(t6)){
t7=(C_word)C_eqp(C_fix((C_word)errno),C_fix((C_word)EWOULDBLOCK));
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1039,a[2]=((C_word*)t0)[7],a[3]=t1,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[4])){
t9=(C_word)C_fudge(C_fix(16));
t10=(C_word)C_u_fixnum_plus(t9,((C_word*)t0)[4]);
/* tcp.scm: 366  ##sys#thread-block-for-timeout! */
t11=*((C_word*)lf[45]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t8,*((C_word*)lf[9]+1),t10);}
else{
t9=t8;
f_1039(2,t9,C_SCHEME_UNDEFINED);}}
else{
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1071,a[2]=((C_word*)t0)[7],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 377  ##sys#update-errno */
t9=*((C_word*)lf[19]+1);
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}}
else{
t7=C_mutate(((C_word *)((C_word*)t0)[3])+1,t5);
t8=C_set_block_item(((C_word*)t0)[2],0,C_fix(0));
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}}

/* k1069 in loop in read-input in k1011 in k1008 in k1005 in k1002 in k996 in k993 in ##net#io-ports in k987 in k983 in k979 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_1071(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1071,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1078,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1082,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k1080 in k1069 in loop in read-input in k1011 in k1008 in k1005 in k1002 in k996 in k993 in ##net#io-ports in k987 in k983 in k979 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_1082(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 380  ##sys#string-append */
t2=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[46],t1);}

/* k1076 in k1069 in loop in read-input in k1011 in k1008 in k1005 in k1002 in k996 in k993 in ##net#io-ports in k987 in k983 in k979 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_1078(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 378  ##sys#signal-hook */
t2=*((C_word*)lf[13]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[14],t1,((C_word*)t0)[2]);}

/* k1037 in loop in read-input in k1011 in k1008 in k1005 in k1002 in k996 in k993 in ##net#io-ports in k987 in k983 in k979 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_1039(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1039,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1042,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* tcp.scm: 369  ##sys#thread-block-for-i/o! */
t3=*((C_word*)lf[44]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,*((C_word*)lf[9]+1),((C_word*)t0)[2],C_SCHEME_TRUE);}

/* k1040 in k1037 in loop in read-input in k1011 in k1008 in k1005 in k1002 in k996 in k993 in ##net#io-ports in k987 in k983 in k979 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_1042(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1042,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1045,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* tcp.scm: 370  yield */
f_597(t2);}

/* k1043 in k1040 in k1037 in loop in read-input in k1011 in k1008 in k1005 in k1002 in k996 in k993 in ##net#io-ports in k987 in k983 in k979 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_1045(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1045,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1048,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_slot(*((C_word*)lf[9]+1),C_fix(13)))){
/* tcp.scm: 372  ##sys#signal-hook */
t3=*((C_word*)lf[13]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[14],lf[43],((C_word*)t0)[2]);}
else{
t3=t2;
f_1048(2,t3,C_SCHEME_UNDEFINED);}}

/* k1046 in k1043 in k1040 in k1037 in loop in read-input in k1011 in k1008 in k1005 in k1002 in k996 in k993 in ##net#io-ports in k987 in k983 in k979 in k975 in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_1048(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 375  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_1020(t2,((C_word*)t0)[2]);}

/* check in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_fcall f_960(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_960,NULL,2,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_962,a[2]=t2,tmp=(C_word)a,a+=3,tmp));}

/* f_962 in check in k940 in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_962(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_962,3,t0,t1,t2);}
t3=(C_truep(t2)?(C_word)C_i_check_exact_2(t2,((C_word*)t0)[2]):C_SCHEME_UNDEFINED);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}

/* tcp-close in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_907(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_907,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[29]);
t4=(C_word)C_slot(t2,C_fix(1));
t5=f_506(t4);
t6=(C_word)C_eqp(C_fix(-1),t5);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_923,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 318  ##sys#update-errno */
t8=*((C_word*)lf[19]+1);
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}
else{
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_SCHEME_UNDEFINED);}}

/* k921 in tcp-close in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_923(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_923,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_930,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_934,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k932 in k921 in tcp-close in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_934(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 319  ##sys#string-append */
t2=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[33],t1);}

/* k928 in k921 in tcp-close in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_930(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 319  ##sys#signal-hook */
t2=*((C_word*)lf[13]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[14],lf[32],t1,((C_word*)t0)[2]);}

/* tcp-listener? in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_898(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_898,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep((C_word)C_blockp(t2))?(C_word)C_i_structurep(t2,lf[29]):C_SCHEME_FALSE));}

/* tcp-listen in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_803(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr3r,(void*)f_803r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_803r(t0,t1,t2,t3);}}

static void C_ccall f_803r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(9);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_805,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_848,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_853,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-w186204 */
t7=t6;
f_853(t7,t1);}
else{
t7=(C_word)C_u_i_car(t3);
t8=(C_word)C_slot(t3,C_fix(1));
if(C_truep((C_word)C_i_nullp(t8))){
/* def-host187202 */
t9=t5;
f_848(t9,t1,t7);}
else{
t9=(C_word)C_u_i_car(t8);
t10=(C_word)C_slot(t8,C_fix(1));
/* body184189 */
t11=t4;
f_805(t11,t1,t7,t9);}}}

/* def-w186 in tcp-listen in k556 in k472 in k469 in k466 in k463 */
static void C_fcall f_853(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_853,NULL,2,t0,t1);}
/* def-host187202 */
t2=((C_word*)t0)[2];
f_848(t2,t1,C_fix(10));}

/* def-host187 in tcp-listen in k556 in k472 in k469 in k466 in k463 */
static void C_fcall f_848(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_848,NULL,3,t0,t1,t2);}
/* body184189 */
t3=((C_word*)t0)[2];
f_805(t3,t1,t2,C_SCHEME_FALSE);}

/* body184 in tcp-listen in k556 in k472 in k469 in k466 in k463 */
static void C_fcall f_805(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_805,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_811,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_817,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t4,t5);}

/* a816 in body184 in tcp-listen in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_817(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_817,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact(((C_word*)t0)[3]);
t5=t2;
t6=((C_word*)t0)[3];
t7=(C_word)stub20(C_SCHEME_UNDEFINED,t5,t6);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_827,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t9=(C_word)C_eqp(C_fix(-1),t7);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_836,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t8,tmp=(C_word)a,a+=5,tmp);
/* tcp.scm: 306  ##sys#update-errno */
t11=*((C_word*)lf[19]+1);
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,t10);}
else{
t10=t8;
f_827(2,t10,C_SCHEME_UNDEFINED);}}

/* k834 in a816 in body184 in tcp-listen in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_836(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_836,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_843,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_847,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k845 in k834 in a816 in body184 in tcp-listen in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_847(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 307  ##sys#string-append */
t2=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[30],t1);}

/* k841 in k834 in a816 in body184 in tcp-listen in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_843(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 307  ##sys#signal-hook */
t2=*((C_word*)lf[13]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[4],lf[14],lf[20],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k825 in a816 in body184 in tcp-listen in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_827(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_827,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,2,lf[29],((C_word*)t0)[2]));}

/* a810 in body184 in tcp-listen in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_811(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_811,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=C_fix((C_word)SOCK_STREAM);
t4=((C_word*)t0)[2];
t5=(C_word)C_i_check_exact(t2);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_704,a[2]=t4,a[3]=t2,a[4]=t1,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_fixnum_lessp(t2,C_fix(0));
t8=(C_truep(t7)?t7:(C_word)C_fixnum_greater_or_equal_p(t2,C_fix(65535)));
if(C_truep(t8)){
/* tcp.scm: 275  ##sys#signal-hook */
t9=*((C_word*)lf[13]+1);
((C_proc6)(void*)(*((C_word*)t9+1)))(6,t9,t6,lf[27],lf[20],lf[28],t2);}
else{
t9=t6;
f_704(2,t9,C_SCHEME_UNDEFINED);}}

/* k702 in a810 in body184 in tcp-listen in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_704(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_704,2,t0,t1);}
t2=f_476(C_fix((C_word)AF_INET),((C_word*)t0)[5],C_fix(0));
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_710,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_eqp(C_fix((C_word)INVALID_SOCKET),t2);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_786,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* tcp.scm: 278  ##sys#update-errno */
t6=*((C_word*)lf[19]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t5=t3;
f_710(2,t5,C_SCHEME_UNDEFINED);}}

/* k784 in k702 in a810 in body184 in tcp-listen in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_786(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 279  ##sys#error */
t2=*((C_word*)lf[25]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],lf[26]);}

/* k708 in k702 in a810 in body184 in tcp-listen in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_710(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_710,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_713,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_778,a[2]=((C_word*)t0)[5],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_779,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[5]);}

/* f_779 in k708 in k702 in a810 in body184 in tcp-listen in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_779(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_779,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)stub167(C_SCHEME_UNDEFINED,t2));}

/* k776 in k708 in k702 in a810 in body184 in tcp-listen in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_778(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_778,2,t0,t1);}
t2=(C_word)C_eqp(C_fix(-1),t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_763,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 285  ##sys#update-errno */
t4=*((C_word*)lf[19]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=((C_word*)t0)[3];
f_713(2,t3,C_SCHEME_UNDEFINED);}}

/* k761 in k776 in k708 in k702 in a810 in body184 in tcp-listen in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_763(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_763,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_770,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_774,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k772 in k761 in k776 in k708 in k702 in a810 in body184 in tcp-listen in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_774(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 286  ##sys#string-append */
t2=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[24],t1);}

/* k768 in k761 in k776 in k708 in k702 in a810 in body184 in tcp-listen in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_770(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 286  ##sys#signal-hook */
t2=*((C_word*)lf[13]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[14],lf[20],t1,((C_word*)t0)[2]);}

/* k711 in k708 in k702 in a810 in body184 in tcp-listen in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_713(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_713,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_716,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* tcp.scm: 287  make-string */
t3=*((C_word*)lf[23]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,C_fix((C_word)sizeof(struct sockaddr_in)));}

/* k714 in k711 in k708 in k702 in a810 in body184 in tcp-listen in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_716(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_716,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_719,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_751,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* tcp.scm: 289  ##net#gethostaddr */
f_583(t3,t1,((C_word*)t0)[2],((C_word*)t0)[3]);}
else{
t3=t1;
t4=(C_truep(t3)?t3:C_SCHEME_FALSE);
t5=t2;
f_719(2,t5,(C_word)stub153(C_SCHEME_UNDEFINED,t4,((C_word*)t0)[3]));}}

/* k749 in k714 in k711 in k708 in k702 in a810 in body184 in tcp-listen in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_751(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_719(2,t2,C_SCHEME_UNDEFINED);}
else{
/* tcp.scm: 290  ##sys#signal-hook */
t2=*((C_word*)lf[13]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[4],lf[14],lf[20],lf[22],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k717 in k714 in k711 in k708 in k702 in a810 in body184 in tcp-listen in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_719(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_719,2,t0,t1);}
t2=((C_word*)t0)[5];
t3=C_fix((C_word)sizeof(struct sockaddr_in));
t4=(C_truep(t2)?t2:C_SCHEME_FALSE);
t5=(C_word)stub11(C_SCHEME_UNDEFINED,((C_word*)t0)[4],t4,t3);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_725,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_eqp(C_fix(-1),t5);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_734,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=t6,tmp=(C_word)a,a+=5,tmp);
/* tcp.scm: 294  ##sys#update-errno */
t9=*((C_word*)lf[19]+1);
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}
else{
t8=t6;
f_725(2,t8,C_SCHEME_UNDEFINED);}}

/* k732 in k717 in k714 in k711 in k708 in k702 in a810 in body184 in tcp-listen in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_734(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_734,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_741,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_745,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k743 in k732 in k717 in k714 in k711 in k708 in k702 in a810 in body184 in tcp-listen in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_745(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 295  ##sys#string-append */
t2=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[21],t1);}

/* k739 in k732 in k717 in k714 in k711 in k708 in k702 in a810 in body184 in tcp-listen in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_741(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 295  ##sys#signal-hook */
t2=*((C_word*)lf[13]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[4],lf[14],lf[20],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k723 in k717 in k714 in k711 in k708 in k702 in a810 in body184 in tcp-listen in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_725(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 296  values */
C_values(4,0,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##net#parse-host in k556 in k472 in k469 in k466 in k463 */
static void C_fcall f_618(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_618,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_block_size(t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_627,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,a[6]=t4,tmp=(C_word)a,a+=7,tmp));
t8=((C_word*)t6)[1];
f_627(t8,t1,C_fix(0));}

/* loop in ##net#parse-host in k556 in k472 in k469 in k466 in k463 */
static void C_fcall f_627(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(7);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_627,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[6]))){
/* tcp.scm: 246  values */
C_values(4,0,t1,((C_word*)t0)[5],C_SCHEME_FALSE);}
else{
t3=(C_word)C_subchar(((C_word*)t0)[5],t2);
t4=(C_word)C_eqp(t3,C_make_character(58));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_650,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t6=(C_word)C_u_fixnum_increase(t2);
/* tcp.scm: 250  substring */
t7=((C_word*)t0)[3];
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t5,((C_word*)t0)[5],t6,((C_word*)t0)[6]);}
else{
t5=(C_word)C_u_fixnum_plus(t2,C_fix(1));
/* tcp.scm: 259  loop */
t9=t1;
t10=t5;
t1=t9;
t2=t10;
goto loop;}}}

/* k648 in loop in ##net#parse-host in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_650(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_650,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_654,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* tcp.scm: 251  substring */
t3=((C_word*)t0)[4];
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[3],C_fix(0),((C_word*)t0)[2]);}

/* k652 in k648 in loop in ##net#parse-host in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_654(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_654,2,t0,t1);}
t2=t1;
t3=((C_word*)t0)[4];
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_565,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
/* ##sys#make-c-string */
t5=*((C_word*)lf[7]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}
else{
t5=t4;
f_565(2,t5,C_SCHEME_FALSE);}}

/* k563 in k652 in k648 in loop in ##net#parse-host in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_565(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_565,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_569,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[2])){
/* ##sys#make-c-string */
t3=*((C_word*)lf[7]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}
else{
t3=t2;
f_569(2,t3,C_SCHEME_FALSE);}}

/* k567 in k563 in k652 in k648 in loop in ##net#parse-host in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_569(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_569,2,t0,t1);}
t2=(C_word)stub108(C_SCHEME_UNDEFINED,((C_word*)t0)[5],t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_660,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_eqp(C_fix(0),t2);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_666,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 254  ##sys#update-errno */
t6=*((C_word*)lf[19]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t5=t3;
f_660(2,t5,C_SCHEME_UNDEFINED);}}

/* k664 in k567 in k563 in k652 in k648 in loop in ##net#parse-host in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_666(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_666,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_673,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_677,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k675 in k664 in k567 in k563 in k652 in k648 in loop in ##net#parse-host in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_677(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 256  ##sys#string-append */
t2=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[17],t1);}

/* k671 in k664 in k567 in k563 in k652 in k648 in loop in ##net#parse-host in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_673(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 255  ##sys#signal-hook */
t2=*((C_word*)lf[13]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[14],lf[15],t1,((C_word*)t0)[2]);}

/* k658 in k567 in k563 in k652 in k648 in loop in ##net#parse-host in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_660(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 249  values */
C_values(4,0,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* yield in k556 in k472 in k469 in k466 in k463 */
static void C_fcall f_597(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_597,NULL,1,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_603,tmp=(C_word)a,a+=2,tmp);
/* tcp.scm: 234  ##sys#call-with-current-continuation */
C_call_cc(3,0,t1,t2);}

/* a602 in yield in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_603(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_603,3,t0,t1,t2);}
t3=*((C_word*)lf[9]+1);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_612,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_i_setslot(t3,C_fix(1),t4);
/* tcp.scm: 238  ##sys#schedule */
t6=*((C_word*)lf[10]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t1);}

/* a611 in a602 in yield in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_612(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_612,2,t0,t1);}
/* tcp.scm: 237  return */
t2=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,C_SCHEME_UNDEFINED);}

/* ##net#gethostaddr in k556 in k472 in k469 in k466 in k463 */
static void C_fcall f_583(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_583,NULL,4,t1,t2,t3,t4);}
t5=(C_truep(t2)?t2:C_SCHEME_FALSE);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_592,a[2]=t4,a[3]=t5,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t3)){
/* ##sys#make-c-string */
t7=*((C_word*)lf[7]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t3);}
else{
t7=t6;
f_592(2,t7,C_SCHEME_FALSE);}}

/* k590 in ##net#gethostaddr in k556 in k472 in k469 in k466 in k463 */
static void C_ccall f_592(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub127(C_SCHEME_UNDEFINED,((C_word*)t0)[3],t1,((C_word*)t0)[2]));}

/* ##net#select in k556 in k472 in k469 in k466 in k463 */
static C_word C_fcall f_577(C_word t1){
C_word tmp;
C_word t2;
return((C_word)stub117(C_SCHEME_UNDEFINED,t1));}

/* ##net#getsockport in k472 in k469 in k466 in k463 */
static C_word C_fcall f_542(C_word t1){
C_word tmp;
C_word t2;
return((C_word)stub92(C_SCHEME_UNDEFINED,t1));}

/* ##net#make-nonblocking in k472 in k469 in k466 in k463 */
static C_word C_fcall f_533(C_word t1){
C_word tmp;
C_word t2;
return((C_word)stub83(C_SCHEME_UNDEFINED,t1));}

/* ##net#shutdown in k472 in k469 in k466 in k463 */
static C_word C_fcall f_516(C_word t1,C_word t2){
C_word tmp;
C_word t3;
return((C_word)stub54(C_SCHEME_UNDEFINED,t1,t2));}

/* ##net#close in k472 in k469 in k466 in k463 */
static C_word C_fcall f_506(C_word t1){
C_word tmp;
C_word t2;
return((C_word)stub37(C_SCHEME_UNDEFINED,t1));}

/* ##net#socket in k472 in k469 in k466 in k463 */
static C_word C_fcall f_476(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
return((C_word)stub3(C_SCHEME_UNDEFINED,t1,t2,t3));}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[213] = {
{"topleveltcp.scm",(void*)C_tcp_toplevel},
{"f_465tcp.scm",(void*)f_465},
{"f_468tcp.scm",(void*)f_468},
{"f_471tcp.scm",(void*)f_471},
{"f_474tcp.scm",(void*)f_474},
{"f_558tcp.scm",(void*)f_558},
{"f_942tcp.scm",(void*)f_942},
{"f_2142tcp.scm",(void*)f_2142},
{"f_977tcp.scm",(void*)f_977},
{"f_2138tcp.scm",(void*)f_2138},
{"f_981tcp.scm",(void*)f_981},
{"f_2134tcp.scm",(void*)f_2134},
{"f_985tcp.scm",(void*)f_985},
{"f_2130tcp.scm",(void*)f_2130},
{"f_989tcp.scm",(void*)f_989},
{"f_2119tcp.scm",(void*)f_2119},
{"f_2099tcp.scm",(void*)f_2099},
{"f_2103tcp.scm",(void*)f_2103},
{"f_2110tcp.scm",(void*)f_2110},
{"f_2070tcp.scm",(void*)f_2070},
{"f_2097tcp.scm",(void*)f_2097},
{"f_2093tcp.scm",(void*)f_2093},
{"f_2083tcp.scm",(void*)f_2083},
{"f_2025tcp.scm",(void*)f_2025},
{"f_2029tcp.scm",(void*)f_2029},
{"f_2068tcp.scm",(void*)f_2068},
{"f_2064tcp.scm",(void*)f_2064},
{"f_2039tcp.scm",(void*)f_2039},
{"f_2057tcp.scm",(void*)f_2057},
{"f_2053tcp.scm",(void*)f_2053},
{"f_2046tcp.scm",(void*)f_2046},
{"f_1980tcp.scm",(void*)f_1980},
{"f_1984tcp.scm",(void*)f_1984},
{"f_1991tcp.scm",(void*)f_1991},
{"f_2023tcp.scm",(void*)f_2023},
{"f_2019tcp.scm",(void*)f_2019},
{"f_1994tcp.scm",(void*)f_1994},
{"f_1998tcp.scm",(void*)f_1998},
{"f_2012tcp.scm",(void*)f_2012},
{"f_2008tcp.scm",(void*)f_2008},
{"f_2001tcp.scm",(void*)f_2001},
{"f_1970tcp.scm",(void*)f_1970},
{"f_1978tcp.scm",(void*)f_1978},
{"f_1730tcp.scm",(void*)f_1730},
{"f_1737tcp.scm",(void*)f_1737},
{"f_1953tcp.scm",(void*)f_1953},
{"f_1947tcp.scm",(void*)f_1947},
{"f_1939tcp.scm",(void*)f_1939},
{"f_1743tcp.scm",(void*)f_1743},
{"f_1749tcp.scm",(void*)f_1749},
{"f_1925tcp.scm",(void*)f_1925},
{"f_1936tcp.scm",(void*)f_1936},
{"f_1932tcp.scm",(void*)f_1932},
{"f_1775tcp.scm",(void*)f_1775},
{"f_1916tcp.scm",(void*)f_1916},
{"f_1778tcp.scm",(void*)f_1778},
{"f_1902tcp.scm",(void*)f_1902},
{"f_1913tcp.scm",(void*)f_1913},
{"f_1909tcp.scm",(void*)f_1909},
{"f_1781tcp.scm",(void*)f_1781},
{"f_1838tcp.scm",(void*)f_1838},
{"f_1845tcp.scm",(void*)f_1845},
{"f_1854tcp.scm",(void*)f_1854},
{"f_1857tcp.scm",(void*)f_1857},
{"f_1860tcp.scm",(void*)f_1860},
{"f_1863tcp.scm",(void*)f_1863},
{"f_1784tcp.scm",(void*)f_1784},
{"f_1824tcp.scm",(void*)f_1824},
{"f_1820tcp.scm",(void*)f_1820},
{"f_1807tcp.scm",(void*)f_1807},
{"f_1803tcp.scm",(void*)f_1803},
{"f_1790tcp.scm",(void*)f_1790},
{"f_1754tcp.scm",(void*)f_1754},
{"f_1761tcp.scm",(void*)f_1761},
{"f_1772tcp.scm",(void*)f_1772},
{"f_1768tcp.scm",(void*)f_1768},
{"f_1685tcp.scm",(void*)f_1685},
{"f_1704tcp.scm",(void*)f_1704},
{"f_1715tcp.scm",(void*)f_1715},
{"f_1711tcp.scm",(void*)f_1711},
{"f_1695tcp.scm",(void*)f_1695},
{"f_1599tcp.scm",(void*)f_1599},
{"f_1609tcp.scm",(void*)f_1609},
{"f_1614tcp.scm",(void*)f_1614},
{"f_1650tcp.scm",(void*)f_1650},
{"f_1653tcp.scm",(void*)f_1653},
{"f_1656tcp.scm",(void*)f_1656},
{"f_1659tcp.scm",(void*)f_1659},
{"f_1636tcp.scm",(void*)f_1636},
{"f_1647tcp.scm",(void*)f_1647},
{"f_1643tcp.scm",(void*)f_1643},
{"f_1627tcp.scm",(void*)f_1627},
{"f_991tcp.scm",(void*)f_991},
{"f_1586tcp.scm",(void*)f_1586},
{"f_1597tcp.scm",(void*)f_1597},
{"f_1593tcp.scm",(void*)f_1593},
{"f_995tcp.scm",(void*)f_995},
{"f_998tcp.scm",(void*)f_998},
{"f_1004tcp.scm",(void*)f_1004},
{"f_1007tcp.scm",(void*)f_1007},
{"f_1010tcp.scm",(void*)f_1010},
{"f_1013tcp.scm",(void*)f_1013},
{"f_1490tcp.scm",(void*)f_1490},
{"f_1496tcp.scm",(void*)f_1496},
{"f_1565tcp.scm",(void*)f_1565},
{"f_1508tcp.scm",(void*)f_1508},
{"f_1512tcp.scm",(void*)f_1512},
{"f_1522tcp.scm",(void*)f_1522},
{"f_1538tcp.scm",(void*)f_1538},
{"f_1425tcp.scm",(void*)f_1425},
{"f_1431tcp.scm",(void*)f_1431},
{"f_1479tcp.scm",(void*)f_1479},
{"f_1382tcp.scm",(void*)f_1382},
{"f_1396tcp.scm",(void*)f_1396},
{"f_1399tcp.scm",(void*)f_1399},
{"f_1410tcp.scm",(void*)f_1410},
{"f_1406tcp.scm",(void*)f_1406},
{"f_1347tcp.scm",(void*)f_1347},
{"f_1369tcp.scm",(void*)f_1369},
{"f_1380tcp.scm",(void*)f_1380},
{"f_1376tcp.scm",(void*)f_1376},
{"f_1360tcp.scm",(void*)f_1360},
{"f_1325tcp.scm",(void*)f_1325},
{"f_1329tcp.scm",(void*)f_1329},
{"f_1087tcp.scm",(void*)f_1087},
{"f_1273tcp.scm",(void*)f_1273},
{"f_1283tcp.scm",(void*)f_1283},
{"f_1210tcp.scm",(void*)f_1210},
{"f_1257tcp.scm",(void*)f_1257},
{"f_1260tcp.scm",(void*)f_1260},
{"f_1218tcp.scm",(void*)f_1218},
{"f_1227tcp.scm",(void*)f_1227},
{"f_1230tcp.scm",(void*)f_1230},
{"f_1241tcp.scm",(void*)f_1241},
{"f_1237tcp.scm",(void*)f_1237},
{"f_1309tcp.scm",(void*)f_1309},
{"f_1289tcp.scm",(void*)f_1289},
{"f_1294tcp.scm",(void*)f_1294},
{"f_1303tcp.scm",(void*)f_1303},
{"f_1183tcp.scm",(void*)f_1183},
{"f_1088tcp.scm",(void*)f_1088},
{"f_1098tcp.scm",(void*)f_1098},
{"f_1152tcp.scm",(void*)f_1152},
{"f_1163tcp.scm",(void*)f_1163},
{"f_1159tcp.scm",(void*)f_1159},
{"f_1120tcp.scm",(void*)f_1120},
{"f_1123tcp.scm",(void*)f_1123},
{"f_1126tcp.scm",(void*)f_1126},
{"f_1129tcp.scm",(void*)f_1129},
{"f_1014tcp.scm",(void*)f_1014},
{"f_1020tcp.scm",(void*)f_1020},
{"f_1071tcp.scm",(void*)f_1071},
{"f_1082tcp.scm",(void*)f_1082},
{"f_1078tcp.scm",(void*)f_1078},
{"f_1039tcp.scm",(void*)f_1039},
{"f_1042tcp.scm",(void*)f_1042},
{"f_1045tcp.scm",(void*)f_1045},
{"f_1048tcp.scm",(void*)f_1048},
{"f_960tcp.scm",(void*)f_960},
{"f_962tcp.scm",(void*)f_962},
{"f_907tcp.scm",(void*)f_907},
{"f_923tcp.scm",(void*)f_923},
{"f_934tcp.scm",(void*)f_934},
{"f_930tcp.scm",(void*)f_930},
{"f_898tcp.scm",(void*)f_898},
{"f_803tcp.scm",(void*)f_803},
{"f_853tcp.scm",(void*)f_853},
{"f_848tcp.scm",(void*)f_848},
{"f_805tcp.scm",(void*)f_805},
{"f_817tcp.scm",(void*)f_817},
{"f_836tcp.scm",(void*)f_836},
{"f_847tcp.scm",(void*)f_847},
{"f_843tcp.scm",(void*)f_843},
{"f_827tcp.scm",(void*)f_827},
{"f_811tcp.scm",(void*)f_811},
{"f_704tcp.scm",(void*)f_704},
{"f_786tcp.scm",(void*)f_786},
{"f_710tcp.scm",(void*)f_710},
{"f_779tcp.scm",(void*)f_779},
{"f_778tcp.scm",(void*)f_778},
{"f_763tcp.scm",(void*)f_763},
{"f_774tcp.scm",(void*)f_774},
{"f_770tcp.scm",(void*)f_770},
{"f_713tcp.scm",(void*)f_713},
{"f_716tcp.scm",(void*)f_716},
{"f_751tcp.scm",(void*)f_751},
{"f_719tcp.scm",(void*)f_719},
{"f_734tcp.scm",(void*)f_734},
{"f_745tcp.scm",(void*)f_745},
{"f_741tcp.scm",(void*)f_741},
{"f_725tcp.scm",(void*)f_725},
{"f_618tcp.scm",(void*)f_618},
{"f_627tcp.scm",(void*)f_627},
{"f_650tcp.scm",(void*)f_650},
{"f_654tcp.scm",(void*)f_654},
{"f_565tcp.scm",(void*)f_565},
{"f_569tcp.scm",(void*)f_569},
{"f_666tcp.scm",(void*)f_666},
{"f_677tcp.scm",(void*)f_677},
{"f_673tcp.scm",(void*)f_673},
{"f_660tcp.scm",(void*)f_660},
{"f_597tcp.scm",(void*)f_597},
{"f_603tcp.scm",(void*)f_603},
{"f_612tcp.scm",(void*)f_612},
{"f_583tcp.scm",(void*)f_583},
{"f_592tcp.scm",(void*)f_592},
{"f_577tcp.scm",(void*)f_577},
{"f_542tcp.scm",(void*)f_542},
{"f_533tcp.scm",(void*)f_533},
{"f_516tcp.scm",(void*)f_516},
{"f_506tcp.scm",(void*)f_506},
{"f_476tcp.scm",(void*)f_476},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
