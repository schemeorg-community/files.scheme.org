/* Generated from csi.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-04-30 11:58
   Version 3.1.10 - linux-unix-gnu-x86	[ manyargs dload ptables applyhook ]
   SVN rev. 10602	compiled 2008-04-30 on galinha (Linux)
   command line: csi.scm -quiet -no-trace -optimize-level 2 -include-path . -no-lambda-info -output-file csi.c -extend private-namespace.scm
   used units: library eval data_structures extras srfi_69 match srfi_69
*/

#include "chicken.h"

#if (defined(_MSC_VER) && defined(_WIN32)) || defined(HAVE_DIRECT_H)
# include <direct.h>
#else
# define _getcwd(buf, len)       NULL
#endif

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_69_toplevel)
C_externimport void C_ccall C_srfi_69_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_match_toplevel)
C_externimport void C_ccall C_match_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_69_toplevel)
C_externimport void C_ccall C_srfi_69_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[559];
static double C_possibly_force_alignment;


/* from k1495 */
static C_word C_fcall stub486(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub486(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_data_pointer_or_null(C_a0);
int t1=(int )C_unfix(C_a1);
C_r=C_mpointer(&C_a,(void*)_getcwd(t0,t1));
return C_r;}

C_noret_decl(C_toplevel)
C_externexport void C_ccall C_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1073)
static void C_ccall f_1073(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1076)
static void C_ccall f_1076(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1079)
static void C_ccall f_1079(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1082)
static void C_ccall f_1082(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1085)
static void C_ccall f_1085(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1088)
static void C_ccall f_1088(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1091)
static void C_ccall f_1091(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1094)
static void C_ccall f_1094(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8732)
static void C_ccall f_8732(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_8732)
static void C_ccall f_8732r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_8736)
static void C_ccall f_8736(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8739)
static void C_ccall f_8739(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8742)
static void C_ccall f_8742(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8748)
static void C_ccall f_8748(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8954)
static void C_ccall f_8954(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8934)
static void C_ccall f_8934(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8930)
static void C_ccall f_8930(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8910)
static void C_ccall f_8910(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8773)
static void C_fcall f_8773(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8783)
static void C_ccall f_8783(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8902)
static void C_ccall f_8902(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8786)
static void C_ccall f_8786(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8898)
static void C_ccall f_8898(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8789)
static void C_ccall f_8789(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8820)
static void C_fcall f_8820(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8800)
static void C_ccall f_8800(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8771)
static void C_ccall f_8771(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1097)
static void C_ccall f_1097(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8644)
static void C_ccall f_8644(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_8644)
static void C_ccall f_8644r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_8661)
static void C_ccall f_8661(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8664)
static void C_ccall f_8664(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8670)
static void C_fcall f_8670(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1100)
static void C_ccall f_1100(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8603)
static void C_ccall f_8603(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_8603)
static void C_ccall f_8603r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_8607)
static void C_ccall f_8607(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1103)
static void C_ccall f_1103(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8587)
static void C_ccall f_8587(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_8587)
static void C_ccall f_8587r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_8597)
static void C_ccall f_8597(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8595)
static void C_ccall f_8595(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1106)
static void C_ccall f_1106(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8510)
static void C_ccall f_8510(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8514)
static void C_ccall f_8514(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8582)
static void C_ccall f_8582(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8517)
static void C_ccall f_8517(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8526)
static void C_ccall f_8526(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8573)
static void C_ccall f_8573(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8540)
static void C_ccall f_8540(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8548)
static void C_ccall f_8548(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8550)
static void C_fcall f_8550(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8567)
static void C_ccall f_8567(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8532)
static void C_ccall f_8532(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8524)
static void C_ccall f_8524(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1109)
static void C_ccall f_1109(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8450)
static void C_ccall f_8450(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_8450)
static void C_ccall f_8450r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_8454)
static void C_fcall f_8454(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1112)
static void C_ccall f_1112(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8391)
static void C_ccall f_8391(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_8391)
static void C_ccall f_8391r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_8395)
static void C_ccall f_8395(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8422)
static void C_fcall f_8422(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1115)
static void C_ccall f_1115(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8217)
static void C_ccall f_8217(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_8217)
static void C_ccall f_8217r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_8221)
static void C_ccall f_8221(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8224)
static void C_ccall f_8224(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8385)
static void C_ccall f_8385(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8227)
static void C_ccall f_8227(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8379)
static void C_ccall f_8379(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8230)
static void C_ccall f_8230(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8377)
static void C_ccall f_8377(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8341)
static void C_ccall f_8341(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8355)
static void C_fcall f_8355(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8369)
static void C_ccall f_8369(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8349)
static void C_ccall f_8349(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8345)
static void C_ccall f_8345(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8237)
static void C_ccall f_8237(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8333)
static void C_ccall f_8333(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8309)
static void C_ccall f_8309(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8327)
static void C_ccall f_8327(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8317)
static void C_ccall f_8317(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8313)
static void C_ccall f_8313(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8305)
static void C_ccall f_8305(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8289)
static void C_ccall f_8289(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8265)
static void C_ccall f_8265(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8283)
static void C_ccall f_8283(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8273)
static void C_ccall f_8273(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8269)
static void C_ccall f_8269(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8261)
static void C_ccall f_8261(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1118)
static void C_ccall f_1118(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8122)
static void C_ccall f_8122(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_8122)
static void C_ccall f_8122r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_8158)
static void C_fcall f_8158(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8171)
static void C_ccall f_8171(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8129)
static void C_ccall f_8129(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1121)
static void C_ccall f_1121(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8012)
static void C_ccall f_8012(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_8012)
static void C_ccall f_8012r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_8016)
static void C_ccall f_8016(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8019)
static void C_ccall f_8019(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8022)
static void C_ccall f_8022(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8025)
static void C_ccall f_8025(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8116)
static void C_ccall f_8116(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8028)
static void C_ccall f_8028(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8110)
static void C_ccall f_8110(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8031)
static void C_ccall f_8031(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8104)
static void C_ccall f_8104(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8108)
static void C_ccall f_8108(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8038)
static void C_ccall f_8038(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8076)
static void C_ccall f_8076(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8074)
static void C_ccall f_8074(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1124)
static void C_ccall f_1124(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8002)
static void C_ccall f_8002(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_8002)
static void C_ccall f_8002r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1127)
static void C_ccall f_1127(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7988)
static void C_ccall f_7988(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_7988)
static void C_ccall f_7988r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1130)
static void C_ccall f_1130(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1204)
static void C_ccall f_1204(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1207)
static void C_ccall f_1207(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7726)
static void C_ccall f_7726(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7730)
static void C_ccall f_7730(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7739)
static void C_ccall f_7739(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7948)
static void C_fcall f_7948(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7961)
static void C_ccall f_7961(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7742)
static void C_ccall f_7742(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7938)
static void C_ccall f_7938(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7946)
static void C_ccall f_7946(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7745)
static void C_ccall f_7745(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7892)
static void C_fcall f_7892(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7925)
static void C_ccall f_7925(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7932)
static void C_ccall f_7932(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7908)
static void C_fcall f_7908(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7757)
static void C_ccall f_7757(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7886)
static void C_ccall f_7886(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7764)
static void C_ccall f_7764(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7766)
static void C_fcall f_7766(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7880)
static void C_ccall f_7880(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7800)
static void C_fcall f_7800(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7854)
static void C_ccall f_7854(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7831)
static void C_ccall f_7831(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7811)
static void C_ccall f_7811(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7786)
static void C_ccall f_7786(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7794)
static void C_ccall f_7794(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7784)
static void C_ccall f_7784(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7746)
static void C_ccall f_7746(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7686)
static void C_fcall f_7686(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7709)
static void C_ccall f_7709(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7713)
static void C_ccall f_7713(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7655)
static void C_fcall f_7655(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7676)
static void C_ccall f_7676(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1210)
static void C_ccall f_1210(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7604)
static void C_ccall f_7604(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7608)
static void C_ccall f_7608(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7619)
static void C_fcall f_7619(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7644)
static void C_ccall f_7644(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1213)
static void C_ccall f_1213(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7484)
static void C_ccall f_7484(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7488)
static void C_ccall f_7488(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7598)
static void C_ccall f_7598(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7596)
static void C_ccall f_7596(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7497)
static void C_ccall f_7497(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7584)
static void C_ccall f_7584(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7592)
static void C_ccall f_7592(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7500)
static void C_ccall f_7500(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7578)
static void C_ccall f_7578(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7520)
static void C_ccall f_7520(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7530)
static void C_ccall f_7530(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7550)
static void C_ccall f_7550(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7556)
static void C_ccall f_7556(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7564)
static void C_ccall f_7564(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7554)
static void C_ccall f_7554(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7528)
static void C_ccall f_7528(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7524)
static void C_ccall f_7524(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7501)
static void C_ccall f_7501(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1216)
static void C_ccall f_1216(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7463)
static void C_ccall f_7463(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7467)
static void C_ccall f_7467(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1219)
static void C_ccall f_1219(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7453)
static void C_ccall f_7453(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1225)
static void C_ccall f_1225(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1234)
static void C_fcall f_1234(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1250)
static void C_fcall f_1250(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1237)
static void C_ccall f_1237(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1298)
static void C_ccall f_1298(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7432)
static void C_ccall f_7432(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7436)
static void C_ccall f_7436(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1301)
static void C_ccall f_1301(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7316)
static void C_ccall f_7316(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7320)
static void C_ccall f_7320(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7329)
static void C_fcall f_7329(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7343)
static void C_fcall f_7343(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7407)
static void C_ccall f_7407(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7389)
static void C_ccall f_7389(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7372)
static void C_ccall f_7372(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1304)
static void C_ccall f_1304(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7217)
static void C_ccall f_7217(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7227)
static void C_ccall f_7227(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7240)
static void C_fcall f_7240(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7256)
static void C_ccall f_7256(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7294)
static void C_ccall f_7294(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7292)
static void C_ccall f_7292(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7284)
static void C_ccall f_7284(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7238)
static void C_ccall f_7238(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1307)
static void C_ccall f_1307(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7128)
static void C_ccall f_7128(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7138)
static void C_ccall f_7138(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7151)
static void C_fcall f_7151(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7167)
static void C_ccall f_7167(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7195)
static void C_ccall f_7195(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7149)
static void C_ccall f_7149(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1310)
static void C_ccall f_1310(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6842)
static void C_ccall f_6842(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_6842)
static void C_ccall f_6842r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_7039)
static void C_ccall f_7039(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7042)
static void C_ccall f_7042(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7045)
static void C_ccall f_7045(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7118)
static void C_ccall f_7118(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7126)
static void C_ccall f_7126(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7061)
static void C_ccall f_7061(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7064)
static void C_ccall f_7064(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7067)
static void C_ccall f_7067(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7070)
static void C_ccall f_7070(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7108)
static void C_ccall f_7108(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7116)
static void C_ccall f_7116(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7073)
static void C_ccall f_7073(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6853)
static void C_ccall f_6853(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6857)
static void C_ccall f_6857(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6861)
static void C_ccall f_6861(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6863)
static void C_fcall f_6863(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_6908)
static void C_ccall f_6908(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6920)
static void C_ccall f_6920(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6916)
static void C_ccall f_6916(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6884)
static void C_ccall f_6884(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7076)
static void C_ccall f_7076(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6936)
static void C_fcall f_6936(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7036)
static void C_ccall f_7036(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7000)
static void C_ccall f_7000(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6970)
static void C_ccall f_6970(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7079)
static void C_ccall f_7079(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7046)
static void C_fcall f_7046(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7058)
static void C_ccall f_7058(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7054)
static void C_ccall f_7054(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1313)
static void C_ccall f_1313(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6785)
static void C_ccall f_6785(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6789)
static void C_ccall f_6789(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1316)
static void C_ccall f_1316(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6779)
static void C_ccall f_6779(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1319)
static void C_ccall f_1319(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6626)
static void C_ccall f_6626(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_6626)
static void C_ccall f_6626r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_6630)
static void C_ccall f_6630(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6633)
static void C_ccall f_6633(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6636)
static void C_ccall f_6636(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6649)
static void C_fcall f_6649(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6699)
static void C_ccall f_6699(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6710)
static void C_ccall f_6710(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6647)
static void C_ccall f_6647(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1322)
static void C_ccall f_1322(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6350)
static void C_ccall f_6350(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6384)
static void C_ccall f_6384(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6387)
static void C_ccall f_6387(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6613)
static void C_ccall f_6613(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6623)
static void C_ccall f_6623(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6611)
static void C_ccall f_6611(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6390)
static void C_ccall f_6390(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6359)
static void C_fcall f_6359(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6373)
static void C_ccall f_6373(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6377)
static void C_ccall f_6377(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6393)
static void C_ccall f_6393(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6396)
static void C_ccall f_6396(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6399)
static void C_ccall f_6399(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6406)
static void C_ccall f_6406(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6420)
static void C_ccall f_6420(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6430)
static void C_ccall f_6430(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6434)
static void C_ccall f_6434(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6444)
static void C_fcall f_6444(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6460)
static void C_ccall f_6460(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6479)
static void C_fcall f_6479(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6535)
static void C_ccall f_6535(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6546)
static void C_ccall f_6546(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6464)
static void C_ccall f_6464(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6477)
static void C_ccall f_6477(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6450)
static void C_ccall f_6450(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6458)
static void C_ccall f_6458(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6448)
static void C_ccall f_6448(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6418)
static void C_ccall f_6418(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1325)
static void C_ccall f_1325(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6293)
static void C_ccall f_6293(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6293)
static void C_ccall f_6293r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6333)
static void C_ccall f_6333(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6303)
static void C_ccall f_6303(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1328)
static void C_ccall f_1328(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6217)
static void C_ccall f_6217(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_6217)
static void C_ccall f_6217r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_6221)
static void C_ccall f_6221(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6224)
static void C_ccall f_6224(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1331)
static void C_ccall f_1331(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6033)
static void C_ccall f_6033(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6033)
static void C_ccall f_6033r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6037)
static void C_ccall f_6037(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6040)
static void C_ccall f_6040(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6183)
static void C_ccall f_6183(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6179)
static void C_ccall f_6179(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6042)
static void C_ccall f_6042(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6130)
static void C_ccall f_6130(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6128)
static void C_ccall f_6128(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6098)
static void C_fcall f_6098(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6065)
static void C_fcall f_6065(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1334)
static void C_ccall f_1334(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5843)
static void C_ccall f_5843(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_5843)
static void C_ccall f_5843r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_5850)
static void C_ccall f_5850(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6024)
static void C_ccall f_6024(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6022)
static void C_ccall f_6022(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5875)
static void C_fcall f_5875(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5901)
static void C_fcall f_5901(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5929)
static void C_fcall f_5929(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5921)
static void C_ccall f_5921(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5913)
static void C_ccall f_5913(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5873)
static void C_ccall f_5873(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1337)
static void C_ccall f_1337(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5834)
static void C_ccall f_5834(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5838)
static void C_ccall f_5838(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1340)
static void C_ccall f_1340(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5815)
static void C_ccall f_5815(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5819)
static void C_ccall f_5819(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5828)
static void C_ccall f_5828(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5826)
static void C_ccall f_5826(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1343)
static void C_ccall f_1343(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5796)
static void C_ccall f_5796(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5800)
static void C_ccall f_5800(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5809)
static void C_ccall f_5809(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5807)
static void C_ccall f_5807(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1346)
static void C_ccall f_1346(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5668)
static void C_ccall f_5668(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5674)
static void C_fcall f_5674(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_5755)
static void C_ccall f_5755(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5684)
static void C_ccall f_5684(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5687)
static void C_ccall f_5687(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5693)
static void C_ccall f_5693(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5700)
static void C_ccall f_5700(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5716)
static void C_ccall f_5716(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1349)
static void C_ccall f_1349(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5525)
static void C_ccall f_5525(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5531)
static void C_fcall f_5531(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_5643)
static void C_ccall f_5643(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5616)
static void C_ccall f_5616(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5541)
static void C_ccall f_5541(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5544)
static void C_ccall f_5544(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5550)
static void C_ccall f_5550(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5561)
static void C_ccall f_5561(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5577)
static void C_ccall f_5577(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1352)
static void C_ccall f_1352(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5466)
static void C_ccall f_5466(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,...) C_noret;
C_noret_decl(f_5466)
static void C_ccall f_5466r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t7) C_noret;
C_noret_decl(f_1355)
static void C_ccall f_1355(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5295)
static void C_ccall f_5295(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5295)
static void C_ccall f_5295r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5301)
static void C_fcall f_5301(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_5375)
static void C_fcall f_5375(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5378)
static void C_ccall f_5378(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5451)
static void C_ccall f_5451(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5444)
static void C_ccall f_5444(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5436)
static void C_ccall f_5436(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5423)
static void C_ccall f_5423(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5402)
static void C_ccall f_5402(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5311)
static void C_fcall f_5311(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1358)
static void C_ccall f_1358(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5244)
static void C_ccall f_5244(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5244)
static void C_ccall f_5244r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1361)
static void C_ccall f_1361(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5184)
static void C_ccall f_5184(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5184)
static void C_ccall f_5184r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5194)
static void C_fcall f_5194(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5213)
static void C_ccall f_5213(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5197)
static void C_ccall f_5197(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1364)
static void C_ccall f_1364(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1367)
static void C_ccall f_1367(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1483)
static void C_ccall f_1483(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5178)
static void C_ccall f_5178(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1720)
static void C_ccall f_1720(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1749)
static void C_ccall f_1749(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3034)
static void C_ccall f_3034(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5170)
static void C_ccall f_5170(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5176)
static void C_ccall f_5176(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5173)
static void C_ccall f_5173(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4429)
static void C_ccall f_4429(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5164)
static void C_ccall f_5164(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4433)
static void C_ccall f_4433(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5160)
static void C_ccall f_5160(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4436)
static void C_ccall f_4436(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4439)
static void C_ccall f_4439(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4442)
static void C_ccall f_4442(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5156)
static void C_ccall f_5156(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5143)
static void C_ccall f_5143(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5103)
static void C_fcall f_5103(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5053)
static void C_ccall f_5053(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5056)
static void C_ccall f_5056(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5059)
static void C_ccall f_5059(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5062)
static void C_ccall f_5062(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5071)
static void C_ccall f_5071(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4445)
static void C_fcall f_4445(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4448)
static void C_ccall f_4448(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5047)
static void C_ccall f_5047(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4451)
static void C_fcall f_4451(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4454)
static void C_ccall f_4454(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5038)
static void C_ccall f_5038(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5034)
static void C_ccall f_5034(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4460)
static void C_ccall f_4460(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4612)
static void C_fcall f_4612(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5023)
static void C_ccall f_5023(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5026)
static void C_ccall f_5026(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4615)
static void C_ccall f_4615(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5014)
static void C_ccall f_5014(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5017)
static void C_ccall f_5017(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4618)
static void C_ccall f_4618(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5011)
static void C_ccall f_5011(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5004)
static void C_ccall f_5004(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4621)
static void C_ccall f_4621(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4991)
static void C_ccall f_4991(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4994)
static void C_ccall f_4994(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4624)
static void C_fcall f_4624(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4985)
static void C_ccall f_4985(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4627)
static void C_ccall f_4627(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4970)
static void C_ccall f_4970(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4973)
static void C_ccall f_4973(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4976)
static void C_ccall f_4976(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4630)
static void C_ccall f_4630(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4967)
static void C_ccall f_4967(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4633)
static void C_ccall f_4633(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4963)
static void C_ccall f_4963(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4636)
static void C_ccall f_4636(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4959)
static void C_ccall f_4959(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4947)
static void C_ccall f_4947(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4955)
static void C_ccall f_4955(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4951)
static void C_ccall f_4951(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4943)
static void C_ccall f_4943(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4640)
static void C_ccall f_4640(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4647)
static void C_ccall f_4647(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4650)
static void C_ccall f_4650(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4877)
static void C_ccall f_4877(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4509)
static void C_ccall f_4509(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4515)
static void C_ccall f_4515(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4537)
static void C_ccall f_4537(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4521)
static void C_ccall f_4521(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4524)
static void C_ccall f_4524(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4530)
static void C_ccall f_4530(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4653)
static void C_ccall f_4653(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4658)
static void C_fcall f_4658(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4810)
static void C_ccall f_4810(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4816)
static void C_fcall f_4816(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4831)
static void C_ccall f_4831(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4831)
static void C_ccall f_4831r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4842)
static void C_fcall f_4842(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4821)
static void C_ccall f_4821(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4829)
static void C_ccall f_4829(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4803)
static void C_ccall f_4803(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4803)
static void C_ccall f_4803r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4793)
static void C_ccall f_4793(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4777)
static void C_ccall f_4777(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4777)
static void C_ccall f_4777r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4767)
static void C_ccall f_4767(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4747)
static void C_ccall f_4747(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4731)
static void C_ccall f_4731(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4715)
static void C_ccall f_4715(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4686)
static void C_ccall f_4686(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4671)
static void C_ccall f_4671(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4542)
static void C_fcall f_4542(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4589)
static void C_ccall f_4589(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4546)
static void C_ccall f_4546(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4549)
static void C_ccall f_4549(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4556)
static void C_ccall f_4556(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4558)
static void C_fcall f_4558(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4581)
static void C_ccall f_4581(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4579)
static void C_ccall f_4579(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4568)
static void C_ccall f_4568(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4575)
static void C_ccall f_4575(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4462)
static void C_fcall f_4462(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4468)
static void C_fcall f_4468(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4495)
static void C_ccall f_4495(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4286)
static void C_fcall f_4286(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4292)
static void C_fcall f_4292(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4314)
static void C_fcall f_4314(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4371)
static void C_ccall f_4371(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4364)
static void C_ccall f_4364(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4330)
static void C_ccall f_4330(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4353)
static void C_ccall f_4353(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4343)
static void C_ccall f_4343(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4347)
static void C_ccall f_4347(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4403)
static C_word C_fcall f_4403(C_word t0);
C_noret_decl(f_4229)
static void C_fcall f_4229(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4235)
static void C_fcall f_4235(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4247)
static void C_fcall f_4247(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4170)
static void C_ccall f_4170(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4170)
static void C_ccall f_4170r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4174)
static void C_ccall f_4174(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4179)
static void C_fcall f_4179(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4208)
static void C_ccall f_4208(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4195)
static void C_ccall f_4195(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3961)
static void C_ccall f_3961(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_3993)
static void C_fcall f_3993(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4168)
static void C_ccall f_4168(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4003)
static void C_ccall f_4003(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4006)
static void C_ccall f_4006(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4078)
static void C_fcall f_4078(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4139)
static void C_ccall f_4139(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4161)
static void C_ccall f_4161(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4157)
static void C_ccall f_4157(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4142)
static void C_ccall f_4142(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4097)
static void C_ccall f_4097(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4115)
static void C_fcall f_4115(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4125)
static void C_ccall f_4125(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4009)
static void C_ccall f_4009(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4012)
static void C_ccall f_4012(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4027)
static void C_fcall f_4027(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4040)
static void C_ccall f_4040(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4043)
static void C_ccall f_4043(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4015)
static void C_ccall f_4015(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4018)
static void C_ccall f_4018(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3964)
static void C_fcall f_3964(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_3968)
static void C_ccall f_3968(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3984)
static void C_ccall f_3984(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3800)
static void C_ccall f_3800(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3800)
static void C_ccall f_3800r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3913)
static void C_fcall f_3913(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3908)
static void C_fcall f_3908(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3802)
static void C_fcall f_3802(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3827)
static void C_ccall f_3827(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3870)
static void C_fcall f_3870(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3880)
static void C_ccall f_3880(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3851)
static void C_ccall f_3851(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3834)
static void C_ccall f_3834(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3805)
static void C_fcall f_3805(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3794)
static void C_ccall f_3794(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3036)
static void C_ccall f_3036(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3036)
static void C_ccall f_3036r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3040)
static void C_ccall f_3040(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3773)
static void C_ccall f_3773(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3168)
static void C_ccall f_3168(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3267)
static void C_ccall f_3267(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3414)
static void C_ccall f_3414(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3442)
static void C_ccall f_3442(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3451)
static void C_ccall f_3451(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3545)
static void C_ccall f_3545(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3679)
static void C_ccall f_3679(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3694)
static void C_ccall f_3694(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3733)
static void C_ccall f_3733(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3722)
static void C_ccall f_3722(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3718)
static void C_ccall f_3718(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3701)
static void C_ccall f_3701(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3612)
static void C_ccall f_3612(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3617)
static void C_ccall f_3617(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3621)
static void C_ccall f_3621(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3630)
static void C_fcall f_3630(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3665)
static void C_ccall f_3665(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3657)
static void C_ccall f_3657(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3640)
static void C_ccall f_3640(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3576)
static void C_ccall f_3576(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3579)
static void C_ccall f_3579(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3584)
static void C_ccall f_3584(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3564)
static void C_ccall f_3564(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3551)
static void C_ccall f_3551(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3539)
static void C_ccall f_3539(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3458)
static void C_ccall f_3458(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3469)
static void C_fcall f_3469(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3433)
static void C_ccall f_3433(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3374)
static void C_fcall f_3374(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3388)
static void C_ccall f_3388(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3384)
static void C_ccall f_3384(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3330)
static void C_ccall f_3330(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3297)
static void C_ccall f_3297(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3310)
static void C_fcall f_3310(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3300)
static void C_ccall f_3300(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3307)
static void C_ccall f_3307(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3237)
static void C_ccall f_3237(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3243)
static void C_ccall f_3243(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3171)
static void C_ccall f_3171(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3042)
static void C_ccall f_3042(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_3165)
static void C_ccall f_3165(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3049)
static void C_ccall f_3049(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3054)
static void C_fcall f_3054(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3077)
static void C_ccall f_3077(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3086)
static void C_fcall f_3086(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3150)
static void C_ccall f_3150(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3096)
static void C_ccall f_3096(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3099)
static void C_ccall f_3099(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2840)
static void C_ccall f_2840(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2840)
static void C_ccall f_2840r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2848)
static void C_ccall f_2848(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2850)
static void C_ccall f_2850(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2854)
static void C_ccall f_2854(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2857)
static void C_ccall f_2857(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2860)
static void C_ccall f_2860(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2877)
static void C_ccall f_2877(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3020)
static void C_ccall f_3020(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3016)
static void C_ccall f_3016(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3012)
static void C_ccall f_3012(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2979)
static void C_ccall f_2979(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2983)
static void C_ccall f_2983(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2988)
static void C_ccall f_2988(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2996)
static void C_ccall f_2996(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2880)
static void C_ccall f_2880(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2908)
static void C_ccall f_2908(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2916)
static void C_ccall f_2916(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2920)
static void C_ccall f_2920(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2924)
static void C_ccall f_2924(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2928)
static void C_ccall f_2928(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2932)
static void C_ccall f_2932(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2883)
static void C_ccall f_2883(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2886)
static void C_ccall f_2886(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2889)
static void C_ccall f_2889(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2892)
static void C_ccall f_2892(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2862)
static void C_fcall f_2862(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2870)
static void C_ccall f_2870(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2737)
static void C_ccall f_2737(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2741)
static void C_ccall f_2741(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2771)
static void C_ccall f_2771(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2789)
static void C_ccall f_2789(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2828)
static void C_ccall f_2828(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2828)
static void C_ccall f_2828r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2834)
static void C_ccall f_2834(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2795)
static void C_ccall f_2795(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2803)
static void C_ccall f_2803(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2805)
static void C_fcall f_2805(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2822)
static void C_ccall f_2822(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2777)
static void C_ccall f_2777(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2783)
static void C_ccall f_2783(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2769)
static void C_ccall f_2769(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2766)
static void C_ccall f_2766(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2746)
static void C_ccall f_2746(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2756)
static void C_ccall f_2756(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2759)
static void C_ccall f_2759(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2713)
static void C_ccall f_2713(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2723)
static void C_ccall f_2723(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2717)
static void C_ccall f_2717(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2422)
static void C_ccall f_2422(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2427)
static void C_ccall f_2427(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2430)
static void C_ccall f_2430(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2433)
static void C_ccall f_2433(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2436)
static void C_ccall f_2436(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2447)
static void C_ccall f_2447(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2451)
static void C_ccall f_2451(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2439)
static void C_ccall f_2439(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2442)
static void C_ccall f_2442(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2399)
static void C_ccall f_2399(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2403)
static void C_ccall f_2403(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2407)
static void C_ccall f_2407(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2410)
static void C_ccall f_2410(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2413)
static void C_ccall f_2413(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2371)
static void C_ccall f_2371(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2375)
static void C_ccall f_2375(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2380)
static void C_fcall f_2380(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2390)
static void C_ccall f_2390(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2397)
static void C_ccall f_2397(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2330)
static void C_ccall f_2330(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2336)
static void C_fcall f_2336(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2352)
static void C_ccall f_2352(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2362)
static void C_ccall f_2362(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1792)
static void C_ccall f_1792(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1809)
static void C_fcall f_1809(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2311)
static void C_ccall f_2311(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2311)
static void C_ccall f_2311r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2315)
static void C_ccall f_2315(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2305)
static void C_ccall f_2305(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1815)
static void C_ccall f_1815(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2291)
static void C_ccall f_2291(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2267)
static void C_ccall f_2267(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2275)
static void C_ccall f_2275(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2270)
static void C_ccall f_2270(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2248)
static void C_ccall f_2248(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2251)
static void C_ccall f_2251(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2254)
static void C_ccall f_2254(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2225)
static void C_ccall f_2225(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2228)
static void C_ccall f_2228(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2235)
static void C_ccall f_2235(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2209)
static void C_ccall f_2209(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2181)
static void C_ccall f_2181(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2158)
static void C_ccall f_2158(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2171)
static void C_ccall f_2171(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2149)
static void C_ccall f_2149(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2145)
static void C_ccall f_2145(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2119)
static void C_ccall f_2119(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2115)
static void C_ccall f_2115(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2111)
static void C_ccall f_2111(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2684)
static void C_ccall f_2684(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2688)
static void C_ccall f_2688(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2707)
static void C_ccall f_2707(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2098)
static void C_ccall f_2098(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2094)
static void C_ccall f_2094(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2090)
static void C_ccall f_2090(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2616)
static void C_ccall f_2616(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2620)
static void C_ccall f_2620(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2665)
static void C_ccall f_2665(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2672)
static void C_ccall f_2672(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2626)
static void C_fcall f_2626(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2647)
static void C_ccall f_2647(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2647)
static void C_ccall f_2647r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2651)
static void C_ccall f_2651(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2603)
static void C_ccall f_2603(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2077)
static void C_ccall f_2077(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2073)
static void C_ccall f_2073(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2069)
static void C_ccall f_2069(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2562)
static void C_ccall f_2562(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2566)
static void C_ccall f_2566(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2585)
static void C_ccall f_2585(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2056)
static void C_ccall f_2056(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2052)
static void C_ccall f_2052(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2048)
static void C_ccall f_2048(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2481)
static void C_ccall f_2481(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2485)
static void C_ccall f_2485(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2524)
static void C_ccall f_2524(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2524)
static void C_ccall f_2524r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2528)
static void C_ccall f_2528(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2539)
static void C_ccall f_2539(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2539)
static void C_ccall f_2539r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2543)
static void C_ccall f_2543(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2533)
static void C_ccall f_2533(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2468)
static void C_ccall f_2468(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1995)
static void C_ccall f_1995(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2028)
static void C_ccall f_2028(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2028)
static void C_ccall f_2028r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2032)
static void C_ccall f_2032(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2000)
static void C_ccall f_2000(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2004)
static void C_ccall f_2004(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2015)
static void C_ccall f_2015(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2015)
static void C_ccall f_2015r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2026)
static void C_ccall f_2026(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2019)
static void C_ccall f_2019(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2009)
static void C_ccall f_2009(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1986)
static void C_ccall f_1986(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1961)
static void C_ccall f_1961(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1969)
static void C_ccall f_1969(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1975)
static void C_ccall f_1975(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1979)
static void C_ccall f_1979(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1964)
static void C_ccall f_1964(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1952)
static void C_ccall f_1952(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1942)
static void C_ccall f_1942(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1945)
static void C_ccall f_1945(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1903)
static void C_ccall f_1903(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1906)
static void C_ccall f_1906(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1909)
static void C_ccall f_1909(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1912)
static void C_ccall f_1912(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1888)
static void C_ccall f_1888(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1891)
static void C_ccall f_1891(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1873)
static void C_ccall f_1873(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1876)
static void C_ccall f_1876(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1855)
static void C_ccall f_1855(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1858)
static void C_ccall f_1858(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1861)
static void C_ccall f_1861(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1836)
static void C_ccall f_1836(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1846)
static void C_ccall f_1846(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1839)
static void C_ccall f_1839(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1821)
static void C_ccall f_1821(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1751)
static void C_ccall f_1751(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1751)
static void C_ccall f_1751r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1755)
static void C_ccall f_1755(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1735)
static void C_ccall f_1735(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1742)
static void C_ccall f_1742(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1722)
static void C_ccall f_1722(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1695)
static void C_ccall f_1695(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1656)
static void C_ccall f_1656(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1680)
static void C_ccall f_1680(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1666)
static void C_fcall f_1666(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1550)
static void C_ccall f_1550(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1554)
static void C_ccall f_1554(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1595)
static void C_ccall f_1595(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1601)
static void C_ccall f_1601(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1608)
static void C_ccall f_1608(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1610)
static void C_fcall f_1610(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1637)
static void C_ccall f_1637(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1620)
static void C_ccall f_1620(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1623)
static void C_ccall f_1623(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1578)
static void C_ccall f_1578(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1592)
static void C_ccall f_1592(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1588)
static void C_ccall f_1588(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1529)
static C_word C_fcall f_1529(C_word t0,C_word t1);
C_noret_decl(f_1502)
static void C_fcall f_1502(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1509)
static void C_ccall f_1509(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1512)
static void C_ccall f_1512(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1518)
static void C_ccall f_1518(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1452)
static void C_ccall f_1452(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1456)
static void C_ccall f_1456(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1440)
static C_word C_fcall f_1440(C_word t0);
C_noret_decl(f_1430)
static void C_ccall f_1430(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1438)
static void C_ccall f_1438(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1401)
static void C_ccall f_1401(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1418)
static void C_ccall f_1418(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1391)
static void C_ccall f_1391(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1399)
static void C_ccall f_1399(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1379)
static void C_ccall f_1379(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1383)
static void C_ccall f_1383(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1386)
static void C_ccall f_1386(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1131)
static void C_ccall f_1131(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1135)
static void C_ccall f_1135(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1172)
static void C_ccall f_1172(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1193)
static void C_ccall f_1193(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1191)
static void C_ccall f_1191(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_8773)
static void C_fcall trf_8773(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8773(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8773(t0,t1,t2,t3);}

C_noret_decl(trf_8820)
static void C_fcall trf_8820(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8820(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8820(t0,t1);}

C_noret_decl(trf_8670)
static void C_fcall trf_8670(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8670(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8670(t0,t1);}

C_noret_decl(trf_8550)
static void C_fcall trf_8550(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8550(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8550(t0,t1,t2,t3);}

C_noret_decl(trf_8454)
static void C_fcall trf_8454(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8454(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8454(t0,t1);}

C_noret_decl(trf_8422)
static void C_fcall trf_8422(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8422(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8422(t0,t1);}

C_noret_decl(trf_8355)
static void C_fcall trf_8355(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8355(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8355(t0,t1,t2);}

C_noret_decl(trf_8158)
static void C_fcall trf_8158(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8158(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8158(t0,t1,t2);}

C_noret_decl(trf_7948)
static void C_fcall trf_7948(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7948(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7948(t0,t1,t2,t3);}

C_noret_decl(trf_7892)
static void C_fcall trf_7892(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7892(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7892(t0,t1,t2,t3);}

C_noret_decl(trf_7908)
static void C_fcall trf_7908(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7908(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7908(t0,t1);}

C_noret_decl(trf_7766)
static void C_fcall trf_7766(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7766(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_7766(t0,t1,t2,t3,t4);}

C_noret_decl(trf_7800)
static void C_fcall trf_7800(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7800(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7800(t0,t1);}

C_noret_decl(trf_7686)
static void C_fcall trf_7686(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7686(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7686(t0,t1,t2,t3);}

C_noret_decl(trf_7655)
static void C_fcall trf_7655(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7655(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7655(t0,t1,t2,t3);}

C_noret_decl(trf_7619)
static void C_fcall trf_7619(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7619(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7619(t0,t1,t2);}

C_noret_decl(trf_1234)
static void C_fcall trf_1234(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1234(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1234(t0,t1);}

C_noret_decl(trf_1250)
static void C_fcall trf_1250(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1250(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1250(t0,t1);}

C_noret_decl(trf_7329)
static void C_fcall trf_7329(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7329(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7329(t0,t1);}

C_noret_decl(trf_7343)
static void C_fcall trf_7343(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7343(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7343(t0,t1,t2);}

C_noret_decl(trf_7240)
static void C_fcall trf_7240(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7240(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7240(t0,t1,t2);}

C_noret_decl(trf_7151)
static void C_fcall trf_7151(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7151(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7151(t0,t1,t2);}

C_noret_decl(trf_6863)
static void C_fcall trf_6863(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6863(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_6863(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_6936)
static void C_fcall trf_6936(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6936(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_6936(t0,t1,t2,t3,t4);}

C_noret_decl(trf_7046)
static void C_fcall trf_7046(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7046(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7046(t0,t1,t2);}

C_noret_decl(trf_6649)
static void C_fcall trf_6649(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6649(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6649(t0,t1,t2,t3);}

C_noret_decl(trf_6359)
static void C_fcall trf_6359(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6359(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6359(t0,t1,t2);}

C_noret_decl(trf_6444)
static void C_fcall trf_6444(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6444(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6444(t0,t1);}

C_noret_decl(trf_6479)
static void C_fcall trf_6479(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6479(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6479(t0,t1,t2,t3);}

C_noret_decl(trf_6098)
static void C_fcall trf_6098(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6098(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6098(t0,t1);}

C_noret_decl(trf_6065)
static void C_fcall trf_6065(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6065(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6065(t0,t1);}

C_noret_decl(trf_5875)
static void C_fcall trf_5875(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5875(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5875(t0,t1,t2,t3);}

C_noret_decl(trf_5901)
static void C_fcall trf_5901(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5901(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5901(t0,t1);}

C_noret_decl(trf_5929)
static void C_fcall trf_5929(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5929(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5929(t0,t1);}

C_noret_decl(trf_5674)
static void C_fcall trf_5674(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5674(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_5674(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_5531)
static void C_fcall trf_5531(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5531(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_5531(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_5301)
static void C_fcall trf_5301(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5301(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_5301(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_5375)
static void C_fcall trf_5375(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5375(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5375(t0,t1);}

C_noret_decl(trf_5311)
static void C_fcall trf_5311(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5311(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5311(t0,t1);}

C_noret_decl(trf_5194)
static void C_fcall trf_5194(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5194(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5194(t0,t1);}

C_noret_decl(trf_5103)
static void C_fcall trf_5103(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5103(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5103(t0,t1);}

C_noret_decl(trf_4445)
static void C_fcall trf_4445(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4445(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4445(t0,t1);}

C_noret_decl(trf_4451)
static void C_fcall trf_4451(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4451(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4451(t0,t1);}

C_noret_decl(trf_4612)
static void C_fcall trf_4612(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4612(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4612(t0,t1);}

C_noret_decl(trf_4624)
static void C_fcall trf_4624(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4624(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4624(t0,t1);}

C_noret_decl(trf_4658)
static void C_fcall trf_4658(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4658(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4658(t0,t1,t2);}

C_noret_decl(trf_4816)
static void C_fcall trf_4816(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4816(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4816(t0,t1);}

C_noret_decl(trf_4842)
static void C_fcall trf_4842(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4842(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4842(t0,t1);}

C_noret_decl(trf_4542)
static void C_fcall trf_4542(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4542(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4542(t0,t1,t2);}

C_noret_decl(trf_4558)
static void C_fcall trf_4558(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4558(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4558(t0,t1,t2);}

C_noret_decl(trf_4462)
static void C_fcall trf_4462(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4462(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4462(t0,t1,t2);}

C_noret_decl(trf_4468)
static void C_fcall trf_4468(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4468(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4468(t0,t1,t2);}

C_noret_decl(trf_4286)
static void C_fcall trf_4286(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4286(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4286(t0,t1);}

C_noret_decl(trf_4292)
static void C_fcall trf_4292(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4292(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4292(t0,t1,t2);}

C_noret_decl(trf_4314)
static void C_fcall trf_4314(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4314(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4314(t0,t1);}

C_noret_decl(trf_4229)
static void C_fcall trf_4229(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4229(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4229(t0,t1,t2);}

C_noret_decl(trf_4235)
static void C_fcall trf_4235(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4235(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4235(t0,t1,t2);}

C_noret_decl(trf_4247)
static void C_fcall trf_4247(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4247(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4247(t0,t1,t2);}

C_noret_decl(trf_4179)
static void C_fcall trf_4179(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4179(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4179(t0,t1,t2);}

C_noret_decl(trf_3993)
static void C_fcall trf_3993(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3993(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3993(t0,t1,t2);}

C_noret_decl(trf_4078)
static void C_fcall trf_4078(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4078(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4078(t0,t1,t2,t3);}

C_noret_decl(trf_4115)
static void C_fcall trf_4115(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4115(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4115(t0,t1,t2);}

C_noret_decl(trf_4027)
static void C_fcall trf_4027(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4027(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4027(t0,t1,t2,t3);}

C_noret_decl(trf_3964)
static void C_fcall trf_3964(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3964(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_3964(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_3913)
static void C_fcall trf_3913(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3913(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3913(t0,t1);}

C_noret_decl(trf_3908)
static void C_fcall trf_3908(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3908(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3908(t0,t1,t2);}

C_noret_decl(trf_3802)
static void C_fcall trf_3802(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3802(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3802(t0,t1,t2,t3);}

C_noret_decl(trf_3870)
static void C_fcall trf_3870(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3870(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3870(t0,t1);}

C_noret_decl(trf_3805)
static void C_fcall trf_3805(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3805(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3805(t0,t1,t2);}

C_noret_decl(trf_3630)
static void C_fcall trf_3630(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3630(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3630(t0,t1,t2);}

C_noret_decl(trf_3469)
static void C_fcall trf_3469(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3469(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3469(t0,t1);}

C_noret_decl(trf_3374)
static void C_fcall trf_3374(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3374(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3374(t0,t1);}

C_noret_decl(trf_3310)
static void C_fcall trf_3310(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3310(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3310(t0,t1);}

C_noret_decl(trf_3054)
static void C_fcall trf_3054(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3054(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3054(t0,t1,t2);}

C_noret_decl(trf_3086)
static void C_fcall trf_3086(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3086(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3086(t0,t1,t2,t3);}

C_noret_decl(trf_2862)
static void C_fcall trf_2862(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2862(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2862(t0,t1);}

C_noret_decl(trf_2805)
static void C_fcall trf_2805(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2805(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2805(t0,t1,t2,t3);}

C_noret_decl(trf_2380)
static void C_fcall trf_2380(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2380(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2380(t0,t1,t2);}

C_noret_decl(trf_2336)
static void C_fcall trf_2336(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2336(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2336(t0,t1,t2);}

C_noret_decl(trf_1809)
static void C_fcall trf_1809(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1809(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1809(t0,t1);}

C_noret_decl(trf_2626)
static void C_fcall trf_2626(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2626(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2626(t0,t1);}

C_noret_decl(trf_1666)
static void C_fcall trf_1666(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1666(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1666(t0,t1);}

C_noret_decl(trf_1610)
static void C_fcall trf_1610(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1610(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1610(t0,t1,t2);}

C_noret_decl(trf_1502)
static void C_fcall trf_1502(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1502(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1502(t0,t1);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr6r)
static void C_fcall tr6r(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6r(C_proc6 k){
int n;
C_word *a,t6;
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
n=C_rest_count(0);
a=C_alloc(n*3);
t6=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(tr5r)
static void C_fcall tr5r(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5r(C_proc5 k){
int n;
C_word *a,t5;
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
n=C_rest_count(0);
a=C_alloc(n*3);
t5=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr2rv)
static void C_fcall tr2rv(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2rv(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n+1);
t2=C_restore_rest_vector(a,n);
(k)(t0,t1,t2);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_main_entry_point
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("toplevel"));
C_resize_stack(131072);
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(4678)){
C_save(t1);
C_rereclaim2(4678*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,559);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[2]=C_h_intern(&lf[2],3,"map");
lf[3]=C_h_intern(&lf[3],6,"lambda");
lf[4]=C_h_intern(&lf[4],14,"\004coreundefined");
lf[5]=C_h_intern(&lf[5],20,"\003syscall-with-values");
lf[6]=C_h_intern(&lf[6],9,"\004coreset!");
lf[7]=C_h_intern(&lf[7],6,"gensym");
lf[8]=C_h_intern(&lf[8],16,"\003syscheck-syntax");
lf[9]=C_h_intern(&lf[9],25,"set!-values/define-values");
lf[10]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\006symbol\376\377\001\000\000\000\000");
lf[12]=C_decode_literal(C_heaptop,"\376B\000\000C\012CHICKEN\012(c)2008 The Chicken Team\012(c)2000-2007 Felix L. Winkelmann\012");
lf[13]=C_h_intern(&lf[13],19,"\003sysundefined-value");
lf[15]=C_decode_literal(C_heaptop,"\376B\000\000\006.csirc");
lf[16]=C_h_intern(&lf[16],27,"\003sysrepl-print-length-limit");
lf[17]=C_h_intern(&lf[17],4,"\000csi");
lf[18]=C_h_intern(&lf[18],12,"\003sysfeatures");
lf[19]=C_h_intern(&lf[19],15,"\003csiprint-usage");
lf[20]=C_h_intern(&lf[20],7,"display");
lf[21]=C_decode_literal(C_heaptop,"\376B\000\002\042\047\012    -b  -batch                  terminate after command-line processing\012 "
"   -w  -no-warnings            disable all warnings\012    -k  -keyword-style STYLE"
"    enable alternative keyword-syntax (none, prefix or suffix)\012    -s  -script P"
"ATHNAME        use interpreter for shell scripts\012        -ss PATHNAME           "
" shell script with `main\047 procedure\012    -R  -require-extension NAME require exte"
"nsion before executing code\012    -I  -include-path PATHNAME  add PATHNAME to incl"
"ude path\012    --                          ignore all following options\012\012");
lf[22]=C_decode_literal(C_heaptop,"\376B\000\002\257Usage: csi {FILENAME | OPTION}\012\012  where OPTION may be one of the following:"
"\012\012    -h  -help  --help           display this text and exit\012    -v  -version   "
"             display version and exit\012        -release                print rele"
"ase number and exit\012    -i  -case-insensitive       enable case-insensitive read"
"ing\012    -e  -eval EXPRESSION        evaluate given expression\012    -p  -print EXP"
"RESSION       evaluate and print result(s)\012    -P  -pretty-print EXPRESSION  eva"
"luate and print result(s) prettily\012    -D  -feature SYMBOL         register feat"
"ure identifier\012    -q  -quiet                  do not print banner\012    -n  -no-i"
"nit                do not load initialization file `");
lf[23]=C_h_intern(&lf[23],16,"\003csiprint-banner");
lf[24]=C_h_intern(&lf[24],5,"print");
lf[25]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[26]=C_h_intern(&lf[26],15,"chicken-version");
lf[27]=C_h_intern(&lf[27],9,"read-char");
lf[28]=C_h_intern(&lf[28],4,"read");
lf[29]=C_h_intern(&lf[29],18,"\003sysuser-read-hook");
lf[30]=C_h_intern(&lf[30],5,"quote");
lf[31]=C_h_intern(&lf[31],17,"\003csihistory-count");
lf[32]=C_h_intern(&lf[32],15,"\003csihistory-ref");
lf[33]=C_h_intern(&lf[33],21,"\003syssharp-number-hook");
lf[35]=C_h_intern(&lf[35],9,"substring");
lf[36]=C_h_intern(&lf[36],18,"\003csichop-separator");
lf[37]=C_h_intern(&lf[37],4,"sub1");
lf[38]=C_h_intern(&lf[38],1,"@");
lf[39]=C_h_intern(&lf[39],12,"file-exists\077");
lf[40]=C_h_intern(&lf[40],13,"string-append");
lf[41]=C_decode_literal(C_heaptop,"\376B\000\000\004.bat");
lf[42]=C_h_intern(&lf[42],22,"\003csilookup-script-file");
lf[43]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[44]=C_h_intern(&lf[44],25,"\003syspeek-nonnull-c-string");
lf[45]=C_h_intern(&lf[45],12,"string-split");
lf[46]=C_decode_literal(C_heaptop,"\376B\000\000\001;");
lf[47]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[48]=C_h_intern(&lf[48],6,"getenv");
lf[49]=C_decode_literal(C_heaptop,"\376B\000\000\004PATH");
lf[50]=C_h_intern(&lf[50],16,"\003csihistory-list");
lf[51]=C_h_intern(&lf[51],13,"vector-resize");
lf[52]=C_h_intern(&lf[52],15,"\003csihistory-add");
lf[53]=C_h_intern(&lf[53],9,"\003syserror");
lf[54]=C_decode_literal(C_heaptop,"\376B\000\000 history entry index out of range");
lf[55]=C_h_intern(&lf[55],14,"\003csitty-input\077");
lf[56]=C_h_intern(&lf[56],13,"\003systty-port\077");
lf[57]=C_h_intern(&lf[57],18,"\003sysstandard-input");
lf[58]=C_h_intern(&lf[58],18,"\003sysbreak-on-error");
lf[59]=C_h_intern(&lf[59],20,"\003sysread-prompt-hook");
lf[61]=C_h_intern(&lf[61],15,"hash-table-set!");
lf[62]=C_h_intern(&lf[62],16,"toplevel-command");
lf[63]=C_h_intern(&lf[63],4,"eval");
lf[64]=C_h_intern(&lf[64],12,"load-noisily");
lf[65]=C_h_intern(&lf[65],10,"singlestep");
lf[66]=C_h_intern(&lf[66],14,"hash-table-ref");
lf[67]=C_h_intern(&lf[67],15,"hash-table-walk");
lf[68]=C_h_intern(&lf[68],9,"read-line");
lf[69]=C_h_intern(&lf[69],6,"length");
lf[70]=C_h_intern(&lf[70],5,"write");
lf[71]=C_h_intern(&lf[71],6,"printf");
lf[72]=C_h_intern(&lf[72],12,"pretty-print");
lf[73]=C_h_intern(&lf[73],8,"integer\077");
lf[74]=C_h_intern(&lf[74],6,"values");
lf[75]=C_h_intern(&lf[75],18,"\003sysrepl-eval-hook");
lf[76]=C_h_intern(&lf[76],22,"\003csitrace-indent-level");
lf[77]=C_h_intern(&lf[77],4,"exit");
lf[78]=C_h_intern(&lf[78],1,"x");
lf[79]=C_h_intern(&lf[79],11,"macroexpand");
lf[80]=C_h_intern(&lf[80],1,"p");
lf[81]=C_h_intern(&lf[81],1,"d");
lf[82]=C_h_intern(&lf[82],12,"\003csidescribe");
lf[83]=C_h_intern(&lf[83],2,"du");
lf[84]=C_h_intern(&lf[84],8,"\003csidump");
lf[85]=C_h_intern(&lf[85],3,"dur");
lf[86]=C_h_intern(&lf[86],1,"r");
lf[87]=C_h_intern(&lf[87],10,"\003csireport");
lf[88]=C_h_intern(&lf[88],1,"q");
lf[89]=C_h_intern(&lf[89],1,"l");
lf[90]=C_h_intern(&lf[90],12,"\003sysfor-each");
lf[91]=C_h_intern(&lf[91],4,"load");
lf[92]=C_h_intern(&lf[92],2,"ln");
lf[93]=C_h_intern(&lf[93],6,"print*");
lf[94]=C_decode_literal(C_heaptop,"\376B\000\000\004==> ");
lf[95]=C_h_intern(&lf[95],8,"\000printer");
lf[96]=C_h_intern(&lf[96],1,"t");
lf[97]=C_h_intern(&lf[97],17,"\003sysdisplay-times");
lf[98]=C_h_intern(&lf[98],14,"\003sysstop-timer");
lf[99]=C_h_intern(&lf[99],15,"\003sysstart-timer");
lf[100]=C_h_intern(&lf[100],2,"tr");
lf[102]=C_h_intern(&lf[102],8,"\003syswarn");
lf[103]=C_decode_literal(C_heaptop,"\376B\000\000\030procedure already traced");
lf[105]=C_decode_literal(C_heaptop,"\376B\000\000 procedure already has breakpoint");
lf[106]=C_h_intern(&lf[106],25,"\003csitraced-procedure-exit");
lf[107]=C_h_intern(&lf[107],26,"\003csitraced-procedure-entry");
lf[108]=C_decode_literal(C_heaptop,"\376B\000\000\033can not trace non-procedure");
lf[109]=C_h_intern(&lf[109],7,"\003sysmap");
lf[110]=C_h_intern(&lf[110],14,"string->symbol");
lf[111]=C_h_intern(&lf[111],3,"utr");
lf[112]=C_h_intern(&lf[112],7,"\003csidel");
lf[113]=C_h_intern(&lf[113],3,"eq\077");
lf[114]=C_decode_literal(C_heaptop,"\376B\000\000\024procedure not traced");
lf[115]=C_h_intern(&lf[115],2,"br");
lf[116]=C_h_intern(&lf[116],1,"a");
lf[117]=C_h_intern(&lf[117],15,"\003sysbreak-entry");
lf[118]=C_decode_literal(C_heaptop,"\376B\000\000\047can not set breakpoint on non-procedure");
lf[119]=C_decode_literal(C_heaptop,"\376B\000\000\024un-tracing procedure");
lf[120]=C_h_intern(&lf[120],3,"ubr");
lf[121]=C_decode_literal(C_heaptop,"\376B\000\000\033procedure has no breakpoint");
lf[122]=C_h_intern(&lf[122],3,"uba");
lf[123]=C_h_intern(&lf[123],14,"do-unbreak-all");
lf[124]=C_h_intern(&lf[124],8,"breakall");
lf[125]=C_h_intern(&lf[125],19,"\003sysbreak-in-thread");
lf[126]=C_h_intern(&lf[126],9,"breakonly");
lf[127]=C_h_intern(&lf[127],4,"info");
lf[128]=C_decode_literal(C_heaptop,"\376B\000\000\021Breakpoints: ~s~%");
lf[129]=C_h_intern(&lf[129],3,"car");
lf[130]=C_decode_literal(C_heaptop,"\376B\000\000\014Traced: ~s~%");
lf[131]=C_h_intern(&lf[131],1,"c");
lf[132]=C_h_intern(&lf[132],19,"\003syslast-breakpoint");
lf[133]=C_h_intern(&lf[133],16,"\003sysbreak-resume");
lf[134]=C_decode_literal(C_heaptop,"\376B\000\000\026no breakpoint pending\012");
lf[135]=C_h_intern(&lf[135],3,"exn");
lf[136]=C_h_intern(&lf[136],18,"\003syslast-exception");
lf[137]=C_h_intern(&lf[137],4,"step");
lf[138]=C_h_intern(&lf[138],1,"s");
lf[139]=C_h_intern(&lf[139],6,"system");
lf[140]=C_h_intern(&lf[140],1,"\077");
lf[141]=C_decode_literal(C_heaptop,"\376B\000\000\002 ,");
lf[142]=C_decode_literal(C_heaptop,"\376B\000\004TToplevel commands:\012\012 ,\077                Show this text\012 ,p EXP            Pr"
"etty print evaluated expression EXP\012 ,d EXP            Describe result of evalua"
"ted expression EXP\012 ,du EXP           Dump data of expression EXP\012 ,dur EXP N   "
"     Dump range\012 ,q                Quit interpreter\012 ,l FILENAME ...   Load one "
"or more files\012 ,ln FILENAME ...  Load one or more files and print result of each"
" top-level expression\012 ,r                Show system information\012 ,s TEXT ...   "
"    Execute shell-command\012 ,tr NAME ...      Trace procedures\012 ,utr NAME ...    "
" Untrace procedures\012 ,br NAME ...      Set breakpoints\012 ,ubr NAME ...     Remove"
" breakpoints\012 ,uba              Remove all breakpoints\012 ,breakall         Break "
"in all threads (default)\012 ,breakonly THREAD Break only in specified thread\012 ,c  "
"              Continue from breakpoint\012 ,info             List traced procedures"
" and breakpoints\012 ,step EXPR        Execute EXPR in single-stepping mode\012 ,exn  "
"            Describe last exception\012 ,t EXP            Evaluate form and print e"
"lapsed time\012 ,x EXP            Pretty print macroexpanded expression EXP\012");
lf[143]=C_decode_literal(C_heaptop,"\376B\000\0005Undefined toplevel command ~s - enter `,\077\047 for help~%");
lf[144]=C_h_intern(&lf[144],22,"hash-table-ref/default");
lf[145]=C_h_intern(&lf[145],7,"unquote");
lf[146]=C_h_intern(&lf[146],16,"\003csitrace-indent");
lf[147]=C_h_intern(&lf[147],19,"\003syswrite-char/port");
lf[148]=C_h_intern(&lf[148],19,"\003sysstandard-output");
lf[149]=C_h_intern(&lf[149],12,"flush-output");
lf[150]=C_h_intern(&lf[150],16,"\003syswrite-char-0");
lf[151]=C_h_intern(&lf[151],4,"add1");
lf[152]=C_decode_literal(C_heaptop,"\376B\000\000\004 -> ");
lf[153]=C_h_intern(&lf[153],23,"\003csiparse-option-string");
lf[154]=C_h_intern(&lf[154],17,"get-output-string");
lf[155]=C_h_intern(&lf[155],18,"open-output-string");
lf[156]=C_decode_literal(C_heaptop,"\376B\000\000\025invalid option syntax");
lf[157]=C_h_intern(&lf[157],7,"reverse");
lf[158]=C_h_intern(&lf[158],22,"with-exception-handler");
lf[159]=C_h_intern(&lf[159],30,"call-with-current-continuation");
lf[160]=C_h_intern(&lf[160],17,"open-input-string");
lf[161]=C_h_intern(&lf[161],4,"chop");
lf[162]=C_h_intern(&lf[162],4,"sort");
lf[163]=C_h_intern(&lf[163],19,"with-output-to-port");
lf[164]=C_h_intern(&lf[164],19,"current-output-port");
lf[165]=C_h_intern(&lf[165],8,"truncate");
lf[166]=C_decode_literal(C_heaptop,"\376B\000\000\025symbol gc is enabled\012");
lf[167]=C_decode_literal(C_heaptop,"\376B\000\000\027interrupts are enabled\012");
lf[168]=C_decode_literal(C_heaptop,"\376B\000\000\010(64-bit)");
lf[169]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[170]=C_decode_literal(C_heaptop,"\376B\000\000\010 (fixed)");
lf[171]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[172]=C_decode_literal(C_heaptop,"\376B\000\000\010downward");
lf[173]=C_decode_literal(C_heaptop,"\376B\000\000\006upward");
lf[174]=C_decode_literal(C_heaptop,"\376B\000\001\374~%~\012                   Machine type:    \011~A ~A~%~\012                   Softwa"
"re type:   \011~A~%~\012                   Software version:\011~A~%~\012                   "
"Build platform:  \011~A~%~\012                   Include path:    \011~A~%~\012             "
"      Symbol-table load:\011~S~%  ~\012                     Avg bucket length:\011~S~%  ~"
"\012                     Total symbols:\011~S~%~\012                   Memory:\011heap size "
"is ~S bytes~A with ~S bytes currently in use~%~  \012                     nursery s"
"ize is ~S bytes, stack grows ~A~%");
lf[175]=C_h_intern(&lf[175],21,"\003sysinclude-pathnames");
lf[176]=C_h_intern(&lf[176],14,"build-platform");
lf[177]=C_h_intern(&lf[177],16,"software-version");
lf[178]=C_h_intern(&lf[178],13,"software-type");
lf[179]=C_h_intern(&lf[179],12,"machine-type");
lf[180]=C_decode_literal(C_heaptop,"\376B\000\000\004~a~a");
lf[181]=C_h_intern(&lf[181],11,"make-string");
lf[182]=C_decode_literal(C_heaptop,"\376B\000\000\003\012  ");
lf[183]=C_h_intern(&lf[183],8,"string<\077");
lf[184]=C_h_intern(&lf[184],15,"keyword->string");
lf[185]=C_decode_literal(C_heaptop,"\376B\000\000\011Features:");
lf[186]=C_h_intern(&lf[186],17,"memory-statistics");
lf[187]=C_h_intern(&lf[187],21,"\003syssymbol-table-info");
lf[188]=C_h_intern(&lf[188],2,"gc");
lf[189]=C_h_intern(&lf[189],19,"\003csibytevector-data");
lf[190]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010u8vector\376\003\000\000\002\376B\000\000\030vector of unsigned bytes\376\003\000\000\002\376\001\000\000\017u8vector-leng"
"th\376\003\000\000\002\376\001\000\000\014u8vector-ref\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010s8vector\376\003\000\000\002\376B\000\000\026vector of signed byt"
"es\376\003\000\000\002\376\001\000\000\017s8vector-length\376\003\000\000\002\376\001\000\000\014s8vector-ref\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011u16vector\376\003\000\000"
"\002\376B\000\000\037vector of unsigned 16-bit words\376\003\000\000\002\376\001\000\000\020u16vector-length\376\003\000\000\002\376\001\000\000\015u16vect"
"or-ref\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011s16vector\376\003\000\000\002\376B\000\000\035vector of signed 16-bit words\376\003\000\000\002\376\001\000"
"\000\020s16vector-length\376\003\000\000\002\376\001\000\000\015s16vector-ref\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011u32vector\376\003\000\000\002\376B\000\000\037ve"
"ctor of unsigned 32-bit words\376\003\000\000\002\376\001\000\000\020u32vector-length\376\003\000\000\002\376\001\000\000\015u32vector-ref\376\377"
"\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011s32vector\376\003\000\000\002\376B\000\000\035vector of signed 32-bit words\376\003\000\000\002\376\001\000\000\020s32vec"
"tor-length\376\003\000\000\002\376\001\000\000\015s32vector-ref\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011f32vector\376\003\000\000\002\376B\000\000\027vector of "
"32-bit floats\376\003\000\000\002\376\001\000\000\020f32vector-length\376\003\000\000\002\376\001\000\000\015f32vector-ref\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011"
"f64vector\376\003\000\000\002\376B\000\000\027vector of 64-bit floats\376\003\000\000\002\376\001\000\000\020f64vector-length\376\003\000\000\002\376\001\000\000\015f6"
"4vector-ref\376\377\016\376\377\016");
lf[192]=C_h_intern(&lf[192],7,"sprintf");
lf[193]=C_h_intern(&lf[193],7,"fprintf");
lf[194]=C_h_intern(&lf[194],8,"list-ref");
lf[195]=C_h_intern(&lf[195],10,"string-ref");
lf[196]=C_decode_literal(C_heaptop,"\376B\000\000 ~% (~A elements not displayed)~%");
lf[197]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[198]=C_decode_literal(C_heaptop,"\376B\000\000\001s");
lf[199]=C_decode_literal(C_heaptop,"\376B\000\000.\011(followed by ~A identical instance~a)~% ...~%");
lf[200]=C_h_intern(&lf[200],7,"newline");
lf[201]=C_decode_literal(C_heaptop,"\376B\000\000\007 ~S: ~S");
lf[202]=C_decode_literal(C_heaptop,"\376B\000\000\021~A of length ~S~%");
lf[203]=C_decode_literal(C_heaptop,"\376B\000\000$character ~S, code: ~S, #x~X, #o~O~%");
lf[204]=C_decode_literal(C_heaptop,"\376B\000\000\016boolean true~%");
lf[205]=C_decode_literal(C_heaptop,"\376B\000\000\017boolean false~%");
lf[206]=C_decode_literal(C_heaptop,"\376B\000\000\014empty list~%");
lf[207]=C_decode_literal(C_heaptop,"\376B\000\000\024end-of-file object~%");
lf[208]=C_decode_literal(C_heaptop,"\376B\000\000\024unspecified object~%");
lf[209]=C_decode_literal(C_heaptop,"\376B\000\000\016, character ~S");
lf[210]=C_decode_literal(C_heaptop,"\376B\000\000\042exact integer ~S, #x~X, #o~O, #b~B");
lf[211]=C_h_intern(&lf[211],28,"\003sysarbitrary-unbound-symbol");
lf[212]=C_decode_literal(C_heaptop,"\376B\000\000\017unbound value~%");
lf[213]=C_decode_literal(C_heaptop,"\376B\000\000\013number ~S~%");
lf[214]=C_decode_literal(C_heaptop,"\376B\000\000\006string");
lf[215]=C_h_intern(&lf[215],8,"\003syssize");
lf[216]=C_decode_literal(C_heaptop,"\376B\000\000\006vector");
lf[217]=C_h_intern(&lf[217],8,"\003sysslot");
lf[218]=C_decode_literal(C_heaptop,"\376B\000\000\025symbol with name ~S~%");
lf[219]=C_h_intern(&lf[219],18,"\003syssymbol->string");
lf[220]=C_decode_literal(C_heaptop,"\376B\000\000\010keyword ");
lf[221]=C_decode_literal(C_heaptop,"\376B\000\000\010unbound ");
lf[222]=C_h_intern(&lf[222],32,"\003syssymbol-has-toplevel-binding\077");
lf[223]=C_decode_literal(C_heaptop,"\376B\000\000\004list");
lf[224]=C_decode_literal(C_heaptop,"\376B\000\000\035pair with car ~S and cdr ~S~%");
lf[225]=C_h_intern(&lf[225],15,"describe-object");
lf[226]=C_decode_literal(C_heaptop,"\376B\000\000\036procedure with code pointer ~X");
lf[227]=C_h_intern(&lf[227],25,"\003syspeek-unsigned-integer");
lf[228]=C_h_intern(&lf[228],9,"\000tinyclos");
lf[229]=C_h_intern(&lf[229],19,"\010tinyclosentity-tag");
lf[230]=C_decode_literal(C_heaptop,"\376B\000\000\005input");
lf[231]=C_decode_literal(C_heaptop,"\376B\000\000\006output");
lf[232]=C_decode_literal(C_heaptop,"\376B\000\0005~A port of type ~A with name ~S and file pointer ~X~%");
lf[233]=C_decode_literal(C_heaptop,"\376B\000\000/locative~%  pointer ~X~%  index ~A~%  type ~A~%");
lf[234]=C_decode_literal(C_heaptop,"\376B\000\000\004slot");
lf[235]=C_decode_literal(C_heaptop,"\376B\000\000\004char");
lf[236]=C_decode_literal(C_heaptop,"\376B\000\000\010u8vector");
lf[237]=C_decode_literal(C_heaptop,"\376B\000\000\010s8vector");
lf[238]=C_decode_literal(C_heaptop,"\376B\000\000\011u16vector");
lf[239]=C_decode_literal(C_heaptop,"\376B\000\000\011s16vector");
lf[240]=C_decode_literal(C_heaptop,"\376B\000\000\011u32vector");
lf[241]=C_decode_literal(C_heaptop,"\376B\000\000\011s32vector");
lf[242]=C_decode_literal(C_heaptop,"\376B\000\000\011f32vector");
lf[243]=C_decode_literal(C_heaptop,"\376B\000\000\011f64vector");
lf[244]=C_decode_literal(C_heaptop,"\376B\000\000\024machine pointer ~X~%");
lf[245]=C_h_intern(&lf[245],11,"\003csihexdump");
lf[246]=C_h_intern(&lf[246],8,"\003sysbyte");
lf[247]=C_decode_literal(C_heaptop,"\376B\000\000\022blob of size ~S:~%");
lf[248]=C_decode_literal(C_heaptop,"\376B\000\000\030lambda information: ~s~%");
lf[249]=C_h_intern(&lf[249],23,"\003syslambda-info->string");
lf[250]=C_h_intern(&lf[250],10,"hash-table");
lf[251]=C_decode_literal(C_heaptop,"\376B\000\000\013 ~S\011-> ~S~%");
lf[252]=C_decode_literal(C_heaptop,"\376B\000\000\025  hash function: ~a~%");
lf[253]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[254]=C_decode_literal(C_heaptop,"\376B\000\000\001s");
lf[255]=C_decode_literal(C_heaptop,"\376B\000\000:hash-table with ~S element~a~%  comparison procedure: ~A~%");
lf[256]=C_h_intern(&lf[256],9,"condition");
lf[257]=C_decode_literal(C_heaptop,"\376B\000\000\011\011~s: ~s~%");
lf[258]=C_h_intern(&lf[258],4,"cdar");
lf[259]=C_h_intern(&lf[259],4,"caar");
lf[260]=C_decode_literal(C_heaptop,"\376B\000\000\005 ~s~%");
lf[261]=C_decode_literal(C_heaptop,"\376B\000\000\017condition: ~s~%");
lf[262]=C_h_intern(&lf[262],6,"unveil");
lf[263]=C_h_intern(&lf[263],6,"append");
lf[264]=C_decode_literal(C_heaptop,"\376B\000\000\031structure of type `~S\047:~%");
lf[265]=C_decode_literal(C_heaptop,"\376B\000\000\020unknown object~%");
lf[266]=C_h_intern(&lf[266],15,"meroon-instance");
lf[267]=C_h_intern(&lf[267],9,"provided\077");
lf[268]=C_h_intern(&lf[268],6,"meroon");
lf[269]=C_h_intern(&lf[269],15,"\003sysbytevector\077");
lf[270]=C_h_intern(&lf[270],13,"\003syslocative\077");
lf[271]=C_h_intern(&lf[271],9,"instance\077");
lf[272]=C_h_intern(&lf[272],5,"port\077");
lf[273]=C_h_intern(&lf[273],11,"\003sysnumber\077");
lf[274]=C_decode_literal(C_heaptop,"\376B\000\000\034statically allocated (0x~X) ");
lf[275]=C_h_intern(&lf[275],17,"\003sysblock-address");
lf[276]=C_h_intern(&lf[276],14,"set-describer!");
lf[277]=C_h_intern(&lf[277],3,"min");
lf[278]=C_h_intern(&lf[278],4,"dump");
lf[279]=C_decode_literal(C_heaptop,"\376B\000\000\035can not dump immediate object");
lf[280]=C_h_intern(&lf[280],13,"\003syspeek-byte");
lf[281]=C_decode_literal(C_heaptop,"\376B\000\000\023can not dump object");
lf[282]=C_h_intern(&lf[282],10,"write-char");
lf[283]=C_decode_literal(C_heaptop,"\376B\000\000\003   ");
lf[284]=C_h_intern(&lf[284],5,"fxmod");
lf[285]=C_h_intern(&lf[285],11,"\003csideldups");
lf[286]=C_h_intern(&lf[286],6,"equal\077");
lf[289]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000k\376\003\000\000\002\376\377\012\000\000s\376\003\000\000\002\376\377\012\000\000v\376\003\000\000\002\376\377\012\000\000h\376\003\000\000\002\376\377\012\000\000D\376\003\000\000\002\376\377\012\000\000e\376\003\000\000\002\376\377\012\000\000i\376\003\000"
"\000\002\376\377\012\000\000R\376\003\000\000\002\376\377\012\000\000b\376\003\000\000\002\376\377\012\000\000n\376\003\000\000\002\376\377\012\000\000q\376\003\000\000\002\376\377\012\000\000w\376\003\000\000\002\376\377\012\000\000-\376\003\000\000\002\376\377\012\000\000I\376\003\000\000\002\376"
"\377\012\000\000p\376\003\000\000\002\376\377\012\000\000P\376\377\016");
lf[291]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\016-keyword-style\376\003\000\000\002\376B\000\000\007-script\376\003\000\000\002\376B\000\000\010-version\376\003\000\000\002\376B\000\000\005-help\376\003\000\000\002\376"
"B\000\000\006--help\376\003\000\000\002\376B\000\000\002--\376\003\000\000\002\376B\000\000\010-feature\376\003\000\000\002\376B\000\000\005-eval\376\003\000\000\002\376B\000\000\021-case-insensiti"
"ve\376\003\000\000\002\376B\000\000\022-require-extension\376\003\000\000\002\376B\000\000\006-batch\376\003\000\000\002\376B\000\000\006-quiet\376\003\000\000\002\376B\000\000\014-no-warn"
"ings\376\003\000\000\002\376B\000\000\010-no-init\376\003\000\000\002\376B\000\000\015-include-path\376\003\000\000\002\376B\000\000\010-release\376\003\000\000\002\376B\000\000\003-ss\376\003\000\000"
"\002\376B\000\000\006-print\376\003\000\000\002\376B\000\000\015-pretty-print\376\377\016");
lf[293]=C_decode_literal(C_heaptop,"\376B\000\000\002-s");
lf[294]=C_decode_literal(C_heaptop,"\376B\000\000\003-ss");
lf[295]=C_decode_literal(C_heaptop,"\376B\000\000\007-script");
lf[296]=C_decode_literal(C_heaptop,"\376B\000\000\002--");
lf[297]=C_decode_literal(C_heaptop,"\376B\000\000\016invalid option");
lf[298]=C_h_intern(&lf[298],16,"\003sysstring->list");
lf[299]=C_h_intern(&lf[299],7,"\003csirun");
lf[300]=C_decode_literal(C_heaptop,"\376B\000\000\047missing argument to command-line option");
lf[301]=C_h_intern(&lf[301],8,"\003syslist");
lf[302]=C_h_intern(&lf[302],6,"\000match");
lf[303]=C_h_intern(&lf[303],4,"repl");
lf[304]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002--\376\003\000\000\002\376B\000\000\006-batch\376\003\000\000\002\376B\000\000\006-quiet\376\003\000\000\002\376B\000\000\010-no-init\376\003\000\000\002\376B\000\000\014-no-warn"
"ings\376\003\000\000\002\376B\000\000\007-script\376\003\000\000\002\376B\000\000\002-b\376\003\000\000\002\376B\000\000\002-q\376\003\000\000\002\376B\000\000\002-n\376\003\000\000\002\376B\000\000\002-w\376\003\000\000\002\376B\000\000\002-"
"s\376\003\000\000\002\376B\000\000\002-i\376\003\000\000\002\376B\000\000\021-case-insensitive\376\003\000\000\002\376B\000\000\003-ss\376\377\016");
lf[305]=C_decode_literal(C_heaptop,"\376B\000\000\010-feature");
lf[306]=C_decode_literal(C_heaptop,"\376B\000\000\015-include-path");
lf[307]=C_decode_literal(C_heaptop,"\376B\000\000\016-keyword-style");
lf[308]=C_decode_literal(C_heaptop,"\376B\000\000\002-D");
lf[309]=C_decode_literal(C_heaptop,"\376B\000\000\002-I");
lf[310]=C_decode_literal(C_heaptop,"\376B\000\000\002-k");
lf[311]=C_decode_literal(C_heaptop,"\376B\000\000\002-R");
lf[312]=C_decode_literal(C_heaptop,"\376B\000\000\022-require-extension");
lf[313]=C_h_intern(&lf[313],22,"\004corerequire-extension");
lf[314]=C_decode_literal(C_heaptop,"\376B\000\000\002-e");
lf[315]=C_decode_literal(C_heaptop,"\376B\000\000\005-eval");
lf[316]=C_decode_literal(C_heaptop,"\376B\000\000\002-p");
lf[317]=C_decode_literal(C_heaptop,"\376B\000\000\006-print");
lf[318]=C_h_intern(&lf[318],8,"for-each");
lf[319]=C_decode_literal(C_heaptop,"\376B\000\000\002-P");
lf[320]=C_decode_literal(C_heaptop,"\376B\000\000\015-pretty-print");
lf[321]=C_h_intern(&lf[321],4,"main");
lf[322]=C_h_intern(&lf[322],22,"command-line-arguments");
lf[323]=C_decode_literal(C_heaptop,"\376B\000\000\003-ss");
lf[324]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[325]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[326]=C_decode_literal(C_heaptop,"\376B\000\000\004HOME");
lf[327]=C_h_intern(&lf[327],17,"\003sysstring-append");
lf[328]=C_decode_literal(C_heaptop,"\376B\000\000\002./");
lf[329]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002-n\376\003\000\000\002\376B\000\000\010-no-init\376\377\016");
lf[330]=C_decode_literal(C_heaptop,"\376B\000\000\006prefix");
lf[331]=C_h_intern(&lf[331],13,"keyword-style");
lf[332]=C_h_intern(&lf[332],7,"\000prefix");
lf[333]=C_decode_literal(C_heaptop,"\376B\000\000\004none");
lf[334]=C_h_intern(&lf[334],5,"\000none");
lf[335]=C_decode_literal(C_heaptop,"\376B\000\000\006suffix");
lf[336]=C_h_intern(&lf[336],7,"\000suffix");
lf[337]=C_decode_literal(C_heaptop,"\376B\000\000+missing argument to `-keyword-style\047 option");
lf[338]=C_h_intern(&lf[338],7,"provide");
lf[339]=C_h_intern(&lf[339],5,"match");
lf[340]=C_h_intern(&lf[340],8,"string=\077");
lf[341]=C_decode_literal(C_heaptop,"\376B\000\000\002-I");
lf[342]=C_decode_literal(C_heaptop,"\376B\000\000\015-include-path");
lf[343]=C_h_intern(&lf[343],17,"register-feature!");
lf[344]=C_decode_literal(C_heaptop,"\376B\000\000\002-D");
lf[345]=C_decode_literal(C_heaptop,"\376B\000\000\010-feature");
lf[346]=C_h_intern(&lf[346],14,"case-sensitive");
lf[347]=C_h_intern(&lf[347],16,"case-insensitive");
lf[348]=C_decode_literal(C_heaptop,"\376B\000\000-Identifiers and symbols are case insensitive\012");
lf[349]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002-i\376\003\000\000\002\376B\000\000\021-case-insensitive\376\377\016");
lf[350]=C_h_intern(&lf[350],12,"load-verbose");
lf[351]=C_h_intern(&lf[351],20,"\003syswarnings-enabled");
lf[352]=C_decode_literal(C_heaptop,"\376B\000\000\026Warnings are disabled\012");
lf[353]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002-w\376\003\000\000\002\376B\000\000\014-no-warnings\376\377\016");
lf[354]=C_decode_literal(C_heaptop,"\376B\000\000\010-release");
lf[355]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002-v\376\003\000\000\002\376B\000\000\010-version\376\377\016");
lf[356]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002-h\376\003\000\000\002\376B\000\000\005-help\376\003\000\000\002\376B\000\000\006--help\376\377\016");
lf[357]=C_h_intern(&lf[357],20,"\003syseval-debug-level");
lf[358]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[359]=C_decode_literal(C_heaptop,"\376B\000\000\001;");
lf[360]=C_decode_literal(C_heaptop,"\376B\000\000\024CHICKEN_INCLUDE_PATH");
lf[361]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002-q\376\003\000\000\002\376B\000\000\006-quiet\376\377\016");
lf[362]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002-b\376\003\000\000\002\376B\000\000\006-batch\376\377\016");
lf[363]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002-e\376\003\000\000\002\376B\000\000\002-p\376\003\000\000\002\376B\000\000\002-P\376\003\000\000\002\376B\000\000\005-eval\376\003\000\000\002\376B\000\000\006-print\376\003\000\000\002\376B\000\000\015-pr"
"etty-print\376\377\016");
lf[364]=C_h_intern(&lf[364],20,"\003syswindows-platform");
lf[365]=C_h_intern(&lf[365],6,"script");
lf[366]=C_h_intern(&lf[366],12,"program-name");
lf[367]=C_decode_literal(C_heaptop,"\376B\000\000\042missing or invalid script argument");
lf[368]=C_decode_literal(C_heaptop,"\376B\000\000\002--");
lf[369]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002-s\376\003\000\000\002\376B\000\000\003-ss\376\003\000\000\002\376B\000\000\007-script\376\377\016");
lf[370]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002-k\376\003\000\000\002\376B\000\000\016-keyword-style\376\377\016");
lf[371]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[372]=C_decode_literal(C_heaptop,"\376B\000\000\013CSI_OPTIONS");
lf[373]=C_h_intern(&lf[373],25,"\003sysimplicit-exit-handler");
lf[374]=C_h_intern(&lf[374],15,"make-hash-table");
lf[375]=C_decode_literal(C_heaptop,"\376B\000\000\006#;~A> ");
lf[376]=C_h_intern(&lf[376],11,"repl-prompt");
lf[377]=C_h_intern(&lf[377],6,"srfi-8");
lf[378]=C_h_intern(&lf[378],7,"srfi-16");
lf[379]=C_h_intern(&lf[379],7,"srfi-26");
lf[380]=C_h_intern(&lf[380],7,"srfi-31");
lf[381]=C_h_intern(&lf[381],7,"srfi-15");
lf[382]=C_h_intern(&lf[382],7,"srfi-11");
lf[383]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\004void\376\377\016\376\377\016");
lf[384]=C_h_intern(&lf[384],25,"\003sysenable-runtime-macros");
lf[385]=C_h_intern(&lf[385],6,"define");
lf[386]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005begin\376\377\016");
lf[387]=C_h_intern(&lf[387],12,"syntax-error");
lf[388]=C_h_intern(&lf[388],17,"define-for-syntax");
lf[389]=C_decode_literal(C_heaptop,"\376B\000\000\022invalid identifier");
lf[390]=C_h_intern(&lf[390],18,"\003sysregister-macro");
lf[391]=C_h_intern(&lf[391],6,"letrec");
lf[392]=C_h_intern(&lf[392],3,"rec");
lf[393]=C_h_intern(&lf[393],22,"chicken-compile-shared");
lf[394]=C_h_intern(&lf[394],3,"not");
lf[395]=C_h_intern(&lf[395],9,"compiling");
lf[396]=C_h_intern(&lf[396],4,"unit");
lf[397]=C_h_intern(&lf[397],7,"declare");
lf[398]=C_h_intern(&lf[398],4,"else");
lf[399]=C_h_intern(&lf[399],11,"cond-expand");
lf[400]=C_h_intern(&lf[400],6,"export");
lf[401]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005begin\376\377\016");
lf[402]=C_h_intern(&lf[402],6,"static");
lf[403]=C_h_intern(&lf[403],5,"begin");
lf[404]=C_h_intern(&lf[404],7,"dynamic");
lf[405]=C_h_intern(&lf[405],16,"define-extension");
lf[406]=C_decode_literal(C_heaptop,"\376B\000\000\030invalid clause specifier");
lf[407]=C_decode_literal(C_heaptop,"\376B\000\000\025invalid clause syntax");
lf[408]=C_h_intern(&lf[408],22,"string-parse-start+end");
lf[409]=C_h_intern(&lf[409],7,"receive");
lf[410]=C_h_intern(&lf[410],28,"string-parse-final-start+end");
lf[411]=C_h_intern(&lf[411],20,"let-string-start+end");
lf[412]=C_h_intern(&lf[412],5,"apply");
lf[413]=C_h_intern(&lf[413],3,"let");
lf[414]=C_h_intern(&lf[414],10,"\003sysappend");
lf[415]=C_h_intern(&lf[415],2,"<>");
lf[416]=C_h_intern(&lf[416],5,"<...>");
lf[417]=C_h_intern(&lf[417],20,"\003sysregister-macro-2");
lf[418]=C_h_intern(&lf[418],4,"cute");
lf[419]=C_h_intern(&lf[419],3,"cut");
lf[420]=C_h_intern(&lf[420],3,"use");
lf[421]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[422]=C_h_intern(&lf[422],17,"require-extension");
lf[423]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[424]=C_h_intern(&lf[424],23,"\004corerequire-for-syntax");
lf[425]=C_h_intern(&lf[425],18,"require-for-syntax");
lf[426]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[427]=C_h_intern(&lf[427],18,"\003sysmake-structure");
lf[428]=C_h_intern(&lf[428],14,"\003sysstructure\077");
lf[429]=C_h_intern(&lf[429],15,"\000record-setters");
lf[430]=C_h_intern(&lf[430],19,"\003syscheck-structure");
lf[431]=C_h_intern(&lf[431],10,"\004corecheck");
lf[432]=C_h_intern(&lf[432],13,"\003sysblock-ref");
lf[433]=C_h_intern(&lf[433],18,"getter-with-setter");
lf[434]=C_h_intern(&lf[434],1,"y");
lf[435]=C_h_intern(&lf[435],14,"\003sysblock-set!");
lf[436]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010\003sysvoid\376\377\016");
lf[437]=C_h_intern(&lf[437],18,"define-record-type");
lf[438]=C_h_intern(&lf[438],3,"and");
lf[439]=C_h_intern(&lf[439],4,"memv");
lf[440]=C_h_intern(&lf[440],4,"cond");
lf[441]=C_h_intern(&lf[441],17,"handle-exceptions");
lf[442]=C_h_intern(&lf[442],10,"\003syssignal");
lf[443]=C_h_intern(&lf[443],14,"condition-case");
lf[444]=C_h_intern(&lf[444],9,"\003sysapply");
lf[445]=C_h_intern(&lf[445],10,"\003sysvalues");
lf[446]=C_h_intern(&lf[446],27,"\003sysregister-record-printer");
lf[447]=C_h_intern(&lf[447],21,"define-record-printer");
lf[448]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\006symbol\376\377\016\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[449]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[450]=C_h_intern(&lf[450],2,"if");
lf[451]=C_h_intern(&lf[451],9,"split-at!");
lf[452]=C_h_intern(&lf[452],4,"take");
lf[453]=C_h_intern(&lf[453],4,"list");
lf[454]=C_h_intern(&lf[454],3,"cdr");
lf[455]=C_h_intern(&lf[455],4,"fx>=");
lf[456]=C_h_intern(&lf[456],3,"fx=");
lf[457]=C_h_intern(&lf[457],11,"case-lambda");
lf[458]=C_h_intern(&lf[458],11,"lambda-list");
lf[459]=C_h_intern(&lf[459],25,"\003sysdecompose-lambda-list");
lf[460]=C_h_intern(&lf[460],10,"fold-right");
lf[461]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\012\004corecheck\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011\003syserror\376\003\000\000\002\376\003\000\000\002\376\001\000\000\016\004coreimmutable\376\003\000\000\002\376\003"
"\000\000\002\376\001\000\000\005quote\376\003\000\000\002\376B\000\0000no matching clause in call to \047case-lambda\047 form\376\377\016\376\377\016\376\377\016"
"\376\377\016");
lf[462]=C_h_intern(&lf[462],7,"require");
lf[463]=C_h_intern(&lf[463],6,"srfi-1");
lf[464]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[465]=C_h_intern(&lf[465],5,"null\077");
lf[466]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[467]=C_h_intern(&lf[467],14,"\004coreimmutable");
lf[468]=C_h_intern(&lf[468],14,"let-optionals*");
lf[469]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[470]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[471]=C_h_intern(&lf[471],8,"optional");
lf[472]=C_h_intern(&lf[472],9,":optional");
lf[473]=C_h_intern(&lf[473],14,"symbol->string");
lf[474]=C_h_intern(&lf[474],4,"let*");
lf[475]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[476]=C_decode_literal(C_heaptop,"\376B\000\000\004def-");
lf[477]=C_h_intern(&lf[477],5,"%rest");
lf[478]=C_h_intern(&lf[478],4,"body");
lf[479]=C_h_intern(&lf[479],4,"cadr");
lf[480]=C_decode_literal(C_heaptop,"\376B\000\000\001%");
lf[481]=C_h_intern(&lf[481],13,"let-optionals");
lf[482]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[483]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000");
lf[484]=C_h_intern(&lf[484],4,"eqv\077");
lf[485]=C_h_intern(&lf[485],6,"switch");
lf[486]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[487]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[488]=C_h_intern(&lf[488],2,"or");
lf[489]=C_h_intern(&lf[489],6,"select");
lf[490]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[491]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[492]=C_h_intern(&lf[492],21,"\003syssyntax-error-hook");
lf[493]=C_decode_literal(C_heaptop,"\376B\000\000\037syntax error in \047and-let*\047 form");
lf[494]=C_h_intern(&lf[494],8,"and-let*");
lf[495]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[496]=C_h_intern(&lf[496],20,"\004coredefine-constant");
lf[497]=C_h_intern(&lf[497],15,"define-constant");
lf[498]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[499]=C_h_intern(&lf[499],18,"\004coredefine-inline");
lf[500]=C_h_intern(&lf[500],13,"define-inline");
lf[501]=C_decode_literal(C_heaptop,"\376B\000\000*invalid substitution form - must be lambda");
lf[502]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[503]=C_h_intern(&lf[503],9,"nth-value");
lf[504]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[505]=C_h_intern(&lf[505],13,"letrec-values");
lf[506]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[507]=C_h_intern(&lf[507],10,"let-values");
lf[508]=C_h_intern(&lf[508],11,"let*-values");
lf[509]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[510]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[511]=C_h_intern(&lf[511],13,"define-values");
lf[512]=C_h_intern(&lf[512],11,"set!-values");
lf[513]=C_h_intern(&lf[513],6,"unless");
lf[514]=C_h_intern(&lf[514],4,"when");
lf[515]=C_h_intern(&lf[515],16,"\003sysdynamic-wind");
lf[516]=C_h_intern(&lf[516],12,"parameterize");
lf[517]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000");
lf[518]=C_h_intern(&lf[518],10,"\000compiling");
lf[519]=C_h_intern(&lf[519],19,"\004corecompiletimetoo");
lf[520]=C_h_intern(&lf[520],20,"\004corecompiletimeonly");
lf[521]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[522]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[523]=C_h_intern(&lf[523],8,"run-time");
lf[524]=C_h_intern(&lf[524],7,"compile");
lf[525]=C_h_intern(&lf[525],12,"compile-time");
lf[526]=C_decode_literal(C_heaptop,"\376B\000\000\033invalid situation specifier");
lf[527]=C_h_intern(&lf[527],9,"eval-when");
lf[528]=C_h_intern(&lf[528],8,"\003sysvoid");
lf[529]=C_h_intern(&lf[529],9,"fluid-let");
lf[530]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000");
lf[531]=C_h_intern(&lf[531],11,"\000type-error");
lf[532]=C_h_intern(&lf[532],15,"\003syssignal-hook");
lf[533]=C_decode_literal(C_heaptop,"\376B\000\000\033argument has incorrect type");
lf[534]=C_h_intern(&lf[534],6,"ensure");
lf[535]=C_decode_literal(C_heaptop,"\376B\000\000\020assertion failed");
lf[536]=C_h_intern(&lf[536],6,"assert");
lf[537]=C_h_intern(&lf[537],20,"with-input-from-file");
lf[538]=C_h_intern(&lf[538],27,"\003syscurrent-source-filename");
lf[539]=C_decode_literal(C_heaptop,"\376B\000\000\014; including ");
lf[540]=C_decode_literal(C_heaptop,"\376B\000\000\004 ...");
lf[541]=C_h_intern(&lf[541],28,"\003sysresolve-include-filename");
lf[542]=C_h_intern(&lf[542],7,"include");
lf[543]=C_h_intern(&lf[543],12,"\004coredeclare");
lf[544]=C_h_intern(&lf[544],4,"time");
lf[545]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\001_");
lf[546]=C_h_intern(&lf[546],3,"val");
lf[547]=C_h_intern(&lf[547],28,"\003sysstring->qualified-symbol");
lf[548]=C_decode_literal(C_heaptop,"\376B\000\000\001-");
lf[549]=C_decode_literal(C_heaptop,"\376B\000\000\001-");
lf[550]=C_decode_literal(C_heaptop,"\376B\000\000\005-set!");
lf[551]=C_decode_literal(C_heaptop,"\376B\000\000\001\077");
lf[552]=C_decode_literal(C_heaptop,"\376B\000\000\005make-");
lf[553]=C_h_intern(&lf[553],27,"\003sysqualified-symbol-prefix");
lf[554]=C_h_intern(&lf[554],13,"define-record");
lf[555]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\006symbol\376\377\001\000\000\000\000");
lf[556]=C_h_intern(&lf[556],6,"symbol");
lf[557]=C_h_intern(&lf[557],11,"\003sysprovide");
lf[558]=C_h_intern(&lf[558],19,"chicken-more-macros");
C_register_lf2(lf,559,create_ptable());
t2=C_mutate(&lf[0],lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1073,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t3);}

/* k1071 */
static void C_ccall f_1073(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1073,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1076,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1074 in k1071 */
static void C_ccall f_1076(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1076,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1079,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1077 in k1074 in k1071 */
static void C_ccall f_1079(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1079,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1082,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_1082(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1082,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1085,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_1085(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1085,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1088,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_match_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_1088(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1088,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1091,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_1091(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1091,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1094,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 44   ##sys#provide */
t3=C_retrieve(lf[557]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[558]);}

/* k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_1094(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1094,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1097,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=*((C_word*)lf[473]+1);
t4=*((C_word*)lf[110]+1);
t5=*((C_word*)lf[40]+1);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8732,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 44   ##sys#register-macro */
t7=C_retrieve(lf[390]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t2,lf[554],t6);}

/* a8731 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_8732(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3r,(void*)f_8732r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_8732r(t0,t1,t2,t3);}}

static void C_ccall f_8732r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(7);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8736,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t3,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* csi.scm: 44   ##sys#check-syntax */
t5=C_retrieve(lf[8]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,lf[554],t2,lf[556]);}

/* k8734 in a8731 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_8736(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8736,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8739,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* csi.scm: 44   ##sys#check-syntax */
t3=C_retrieve(lf[8]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[554],((C_word*)t0)[5],lf[555]);}

/* k8737 in k8734 in a8731 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_8739(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8739,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8742,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* csi.scm: 44   symbol->string */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[6]);}

/* k8740 in k8737 in k8734 in a8731 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_8742(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8742,2,t0,t1);}
t2=(C_word)C_i_memq(lf[429],C_retrieve(lf[18]));
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8748,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
/* csi.scm: 44   ##sys#qualified-symbol-prefix */
t4=C_retrieve(lf[553]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[6]);}

/* k8746 in k8740 in k8737 in k8734 in a8731 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_8748(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8748,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8934,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8954,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 44   string-append */
t4=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[552],((C_word*)t0)[3]);}

/* k8952 in k8746 in k8740 in k8737 in k8734 in a8731 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_8954(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 44   ##sys#string->qualified-symbol */
t2=C_retrieve(lf[547]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8932 in k8746 in k8740 in k8737 in k8734 in a8731 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_8934(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[45],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8934,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[30],((C_word*)t0)[9]);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[8]);
t4=(C_word)C_a_i_cons(&a,2,lf[427],t3);
t5=(C_word)C_a_i_list(&a,3,lf[3],((C_word*)t0)[8],t4);
t6=(C_word)C_a_i_list(&a,3,lf[385],t1,t5);
t7=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8910,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=t6,a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8930,a[2]=((C_word*)t0)[5],a[3]=t7,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 44   string-append */
t9=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t9))(4,t9,t8,((C_word*)t0)[3],lf[551]);}

/* k8928 in k8932 in k8746 in k8740 in k8737 in k8734 in a8731 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_8930(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 44   ##sys#string->qualified-symbol */
t2=C_retrieve(lf[547]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8908 in k8932 in k8746 in k8740 in k8737 in k8734 in a8731 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_8910(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[52],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8910,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,lf[78]);
t3=(C_word)C_a_i_list(&a,2,lf[30],((C_word*)t0)[10]);
t4=(C_word)C_a_i_list(&a,3,lf[428],lf[78],t3);
t5=(C_word)C_a_i_list(&a,3,lf[3],t2,t4);
t6=(C_word)C_a_i_list(&a,3,lf[385],t1,t5);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8771,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=t6,tmp=(C_word)a,a+=5,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8773,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t9,a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp));
t11=((C_word*)t9)[1];
f_8773(t11,t7,((C_word*)t0)[2],C_fix(1));}

/* mapslots in k8908 in k8932 in k8746 in k8740 in k8737 in k8734 in a8731 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_fcall f_8773(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8773,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t2);}
else{
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8783,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t2,a[8]=t1,a[9]=t3,a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp);
t6=(C_word)C_slot(t2,C_fix(0));
/* csi.scm: 44   symbol->string */
t7=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t7))(3,t7,t5,t6);}}

/* k8781 in mapslots in k8908 in k8932 in k8746 in k8740 in k8737 in k8734 in a8731 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_8783(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8783,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_8786,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8902,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 44   string-append */
t4=((C_word*)t0)[3];
((C_proc6)C_retrieve_proc(t4))(6,t4,t3,((C_word*)t0)[2],lf[549],t1,lf[550]);}

/* k8900 in k8781 in mapslots in k8908 in k8932 in k8746 in k8740 in k8737 in k8734 in a8731 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_8902(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 44   ##sys#string->qualified-symbol */
t2=C_retrieve(lf[547]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8784 in k8781 in mapslots in k8908 in k8932 in k8746 in k8740 in k8737 in k8734 in a8731 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_8786(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8786,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8789,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=t1,a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8898,a[2]=((C_word*)t0)[5],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 44   string-append */
t4=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[3],lf[548],((C_word*)t0)[2]);}

/* k8896 in k8784 in k8781 in mapslots in k8908 in k8932 in k8746 in k8740 in k8737 in k8734 in a8731 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_8898(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 44   ##sys#string->qualified-symbol */
t2=C_retrieve(lf[547]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8787 in k8784 in k8781 in mapslots in k8908 in k8932 in k8746 in k8740 in k8737 in k8734 in a8731 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_8789(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word ab[167],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8789,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[78],lf[546]);
t3=(C_word)C_a_i_list(&a,2,lf[30],((C_word*)t0)[8]);
t4=(C_word)C_a_i_list(&a,3,lf[430],lf[78],t3);
t5=(C_word)C_a_i_list(&a,2,lf[431],t4);
t6=(C_word)C_a_i_list(&a,4,lf[435],lf[78],((C_word*)t0)[7],lf[546]);
t7=(C_word)C_a_i_list(&a,4,lf[3],t2,t5,t6);
t8=(C_word)C_a_i_list(&a,3,lf[385],((C_word*)t0)[6],t7);
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8820,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t8,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[2])){
t10=(C_word)C_a_i_list(&a,1,lf[78]);
t11=(C_word)C_a_i_list(&a,2,lf[30],((C_word*)t0)[8]);
t12=(C_word)C_a_i_list(&a,3,lf[430],lf[78],t11);
t13=(C_word)C_a_i_list(&a,2,lf[431],t12);
t14=(C_word)C_a_i_list(&a,3,lf[432],lf[78],((C_word*)t0)[7]);
t15=(C_word)C_a_i_list(&a,4,lf[3],t10,t13,t14);
t16=t9;
f_8820(t16,(C_word)C_a_i_list(&a,3,lf[433],t15,((C_word*)t0)[6]));}
else{
t10=(C_word)C_a_i_list(&a,1,lf[78]);
t11=(C_word)C_a_i_list(&a,2,lf[30],((C_word*)t0)[8]);
t12=(C_word)C_a_i_list(&a,3,lf[430],lf[78],t11);
t13=(C_word)C_a_i_list(&a,2,lf[431],t12);
t14=(C_word)C_a_i_list(&a,3,lf[432],lf[78],((C_word*)t0)[7]);
t15=t9;
f_8820(t15,(C_word)C_a_i_list(&a,4,lf[3],t10,t13,t14));}}

/* k8818 in k8787 in k8784 in k8781 in mapslots in k8908 in k8932 in k8746 in k8740 in k8737 in k8734 in a8731 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_fcall f_8820(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8820,NULL,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,lf[385],((C_word*)t0)[7],t1);
t3=(C_word)C_a_i_list(&a,3,lf[403],((C_word*)t0)[6],t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8800,a[2]=t3,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t6=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* csi.scm: 44   mapslots */
t7=((C_word*)((C_word*)t0)[2])[1];
f_8773(t7,t4,t5,t6);}

/* k8798 in k8818 in k8787 in k8784 in k8781 in mapslots in k8908 in k8932 in k8746 in k8740 in k8737 in k8734 in a8731 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_8800(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8800,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k8769 in k8908 in k8932 in k8746 in k8740 in k8737 in k8734 in a8731 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_8771(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8771,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[403],t3));}

/* k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_1097(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1097,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1100,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8644,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   ##sys#register-macro */
t4=C_retrieve(lf[390]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[409],t3);}

/* a8643 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_8644(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+23)){
C_save_and_reclaim((void*)tr3r,(void*)f_8644r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_8644r(t0,t1,t2,t3);}}

static void C_ccall f_8644r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(23);
if(C_truep((C_word)C_i_nullp(t3))){
t4=(C_word)C_a_i_list(&a,3,lf[3],C_SCHEME_END_OF_LIST,t2);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,3,lf[5],t4,lf[301]));}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8661,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 44   ##sys#check-syntax */
t5=C_retrieve(lf[8]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,lf[409],t2,lf[458]);}}

/* k8659 in a8643 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_8661(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8661,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8664,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 44   ##sys#check-syntax */
t3=C_retrieve(lf[8]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[409],((C_word*)t0)[3],lf[545]);}

/* k8662 in k8659 in a8643 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_8664(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8664,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8670,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
t4=t2;
f_8670(t4,(C_word)C_i_nullp(t3));}
else{
t3=t2;
f_8670(t3,C_SCHEME_FALSE);}}

/* k8668 in k8662 in k8659 in a8643 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_fcall f_8670(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[39],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8670,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
t4=(C_word)C_a_i_list(&a,2,t2,t3);
t5=(C_word)C_a_i_list(&a,1,t4);
t6=(C_word)C_i_cdr(((C_word*)t0)[3]);
t7=(C_word)C_a_i_cons(&a,2,t5,t6);
t8=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,lf[413],t7));}
else{
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(C_word)C_a_i_list(&a,3,lf[3],C_SCHEME_END_OF_LIST,t2);
t4=(C_word)C_i_cdr(((C_word*)t0)[3]);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t4);
t6=(C_word)C_a_i_cons(&a,2,lf[3],t5);
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_list(&a,3,lf[5],t3,t6));}}

/* k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_1100(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1100,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1103,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_retrieve(lf[7]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8603,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 44   ##sys#register-macro */
t5=C_retrieve(lf[390]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t2,lf[544],t4);}

/* a8602 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_8603(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_8603r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_8603r(t0,t1,t2);}}

static void C_ccall f_8603r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8607,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 44   gensym */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[96]);}

/* k8605 in a8602 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_8607(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[57],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8607,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,lf[99]);
t3=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,((C_word*)t0)[3]);
t4=(C_word)C_a_i_cons(&a,2,lf[3],t3);
t5=(C_word)C_a_i_list(&a,1,lf[98]);
t6=(C_word)C_a_i_list(&a,2,lf[97],t5);
t7=(C_word)C_a_i_list(&a,3,lf[444],lf[445],t1);
t8=(C_word)C_a_i_list(&a,4,lf[3],t1,t6,t7);
t9=(C_word)C_a_i_list(&a,3,lf[5],t4,t8);
t10=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_list(&a,3,lf[403],t2,t9));}

/* k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_1103(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1103,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1106,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8587,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   ##sys#register-macro */
t4=C_retrieve(lf[390]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[397],t3);}

/* a8586 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_8587(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_8587r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_8587r(t0,t1,t2);}}

static void C_ccall f_8587r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8595,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8597,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   ##sys#map */
t5=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,t2);}

/* a8596 in a8586 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_8597(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8597,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[30],t2));}

/* k8593 in a8586 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_8595(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8595,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[543],t1));}

/* k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_1106(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1106,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1109,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_retrieve(lf[537]);
t4=*((C_word*)lf[28]+1);
t5=*((C_word*)lf[157]+1);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8510,a[2]=t3,a[3]=t4,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 44   ##sys#register-macro */
t7=C_retrieve(lf[390]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t2,lf[542],t6);}

/* a8509 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_8510(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8510,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8514,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 44   ##sys#resolve-include-filename */
t4=C_retrieve(lf[541]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,t2,C_SCHEME_TRUE);}

/* k8512 in a8509 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_8514(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8514,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8517,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8582,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 44   load-verbose */
t4=C_retrieve(lf[350]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k8580 in k8512 in a8509 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_8582(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* csi.scm: 44   print */
t2=*((C_word*)lf[24]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[539],((C_word*)t0)[2],lf[540]);}
else{
t2=((C_word*)t0)[3];
f_8517(2,t2,C_SCHEME_UNDEFINED);}}

/* k8515 in k8512 in a8509 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_8517(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8517,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8524,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8526,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 44   with-input-from-file */
t4=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,((C_word*)t0)[5],t3);}

/* a8525 in k8515 in k8512 in a8509 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_8526(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[16],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8526,2,t0,t1);}
t2=((C_word*)t0)[4];
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8532,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8540,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8573,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* ##sys#dynamic-wind */
t9=*((C_word*)lf[515]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,t1,t6,t7,t8);}

/* a8572 in a8525 in k8515 in k8512 in a8509 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_8573(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8573,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,C_retrieve(lf[538]));
t3=C_mutate((C_word*)lf[538]+1,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_retrieve(lf[13]));}

/* a8539 in a8525 in k8515 in k8512 in a8509 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_8540(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8540,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8548,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 44   read */
t3=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k8546 in a8539 in a8525 in k8515 in k8512 in a8509 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_8548(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8548,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8550,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_8550(t5,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* do38 in k8546 in a8539 in a8525 in k8515 in k8512 in a8509 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_fcall f_8550(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8550,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_eofp(t2))){
/* csi.scm: 44   reverse */
t4=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8567,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 44   read */
t5=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}}

/* k8565 in do38 in k8546 in a8539 in a8525 in k8515 in k8512 in a8509 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_8567(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8567,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[4]);
t3=((C_word*)((C_word*)t0)[3])[1];
f_8550(t3,((C_word*)t0)[2],t1,t2);}

/* a8531 in a8525 in k8515 in k8512 in a8509 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_8532(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8532,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,C_retrieve(lf[538]));
t3=C_mutate((C_word*)lf[538]+1,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_retrieve(lf[13]));}

/* k8522 in k8515 in k8512 in a8509 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_8524(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8524,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[403],t1));}

/* k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_1109(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1109,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1112,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8450,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   ##sys#register-macro */
t4=C_retrieve(lf[390]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[536],t3);}

/* a8449 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_8450(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+17)){
C_save_and_reclaim((void*)tr3r,(void*)f_8450r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_8450r(t0,t1,t2,t3);}}

static void C_ccall f_8450r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(17);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8454,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_eqp(C_SCHEME_END_OF_LIST,t3);
if(C_truep(t5)){
t6=(C_word)C_a_i_list(&a,2,lf[30],lf[535]);
t7=t4;
f_8454(t7,(C_word)C_a_i_list(&a,2,lf[467],t6));}
else{
t6=t4;
f_8454(t6,(C_word)C_slot(t3,C_fix(0)));}}

/* k8452 in a8449 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_fcall f_8454(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8454,NULL,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[431],((C_word*)t0)[4]);
t3=(C_word)C_a_i_list(&a,1,lf[4]);
t4=(C_word)C_a_i_list(&a,2,lf[30],((C_word*)t0)[4]);
t5=(C_word)C_i_length(((C_word*)t0)[3]);
t6=(C_word)C_fixnum_greaterp(t5,C_fix(1));
t7=(C_truep(t6)?(C_word)C_slot(((C_word*)t0)[3],C_fix(1)):C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,t4,t7);
t9=(C_word)C_a_i_cons(&a,2,t1,t8);
t10=(C_word)C_a_i_cons(&a,2,lf[53],t9);
t11=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_word)C_a_i_list(&a,4,lf[450],t2,t3,t10));}

/* k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_1112(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1112,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1115,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8391,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   ##sys#register-macro */
t4=C_retrieve(lf[390]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[534],t3);}

/* a8390 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_8391(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_8391r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_8391r(t0,t1,t2,t3,t4);}}

static void C_ccall f_8391r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8395,a[2]=t4,a[3]=t1,a[4]=t2,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 44   gensym */
t6=C_retrieve(lf[7]);
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}

/* k8393 in a8390 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_8395(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[54],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8395,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[5]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t1);
t5=(C_word)C_a_i_list(&a,2,lf[431],t4);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8422,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t7=t6;
f_8422(t7,((C_word*)t0)[2]);}
else{
t7=(C_word)C_a_i_list(&a,2,lf[30],lf[533]);
t8=(C_word)C_a_i_list(&a,2,lf[467],t7);
t9=(C_word)C_a_i_list(&a,2,lf[30],((C_word*)t0)[4]);
t10=t6;
f_8422(t10,(C_word)C_a_i_list(&a,3,t8,t1,t9));}}

/* k8420 in k8393 in a8390 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_fcall f_8422(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8422,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[531],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[532],t2);
t4=(C_word)C_a_i_list(&a,4,lf[450],((C_word*)t0)[5],((C_word*)t0)[4],t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,3,lf[413],((C_word*)t0)[2],t4));}

/* k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_1115(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1115,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1118,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_retrieve(lf[7]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8217,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 44   ##sys#register-macro */
t5=C_retrieve(lf[390]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t2,lf[529],t4);}

/* a8216 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_8217(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr3r,(void*)f_8217r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_8217r(t0,t1,t2,t3);}}

static void C_ccall f_8217r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(6);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8221,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 44   ##sys#check-syntax */
t5=C_retrieve(lf[8]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,lf[529],t2,lf[530]);}

/* k8219 in a8216 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_8221(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8221,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8224,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 44   ##sys#map */
t3=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[129]+1),((C_word*)t0)[3]);}

/* k8222 in k8219 in a8216 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_8224(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8224,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8227,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8385,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 44   ##sys#map */
t4=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[3]);}

/* a8384 in k8222 in k8219 in a8216 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_8385(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8385,3,t0,t1,t2);}
/* csi.scm: 44   gensym */
t3=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t3))(2,t3,t1);}

/* k8225 in k8222 in k8219 in a8216 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_8227(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8227,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8230,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8379,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 44   ##sys#map */
t4=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[3]);}

/* a8378 in k8225 in k8222 in k8219 in a8216 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_8379(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8379,3,t0,t1,t2);}
/* csi.scm: 44   gensym */
t3=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t3))(2,t3,t1);}

/* k8228 in k8225 in k8222 in k8219 in a8216 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_8230(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8230,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8237,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8341,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8377,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 44   ##sys#map */
t5=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,*((C_word*)lf[479]+1),((C_word*)t0)[2]);}

/* k8375 in k8228 in k8225 in k8222 in k8219 in a8216 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_8377(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 44   map */
t2=*((C_word*)lf[2]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],*((C_word*)lf[301]+1),((C_word*)t0)[2],t1);}

/* k8339 in k8228 in k8225 in k8222 in k8219 in a8216 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_8341(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8341,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8345,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8349,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_length(((C_word*)t0)[2]);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8355,a[2]=t6,tmp=(C_word)a,a+=3,tmp));
t8=((C_word*)t6)[1];
f_8355(t8,t3,t4);}

/* loop in k8339 in k8228 in k8225 in k8222 in k8219 in a8216 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_fcall f_8355(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
loop:
a=C_alloc(3);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_8355,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8369,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_fixnum_difference(t2,C_fix(1));
/* csi.scm: 44   loop */
t7=t4;
t8=t5;
t1=t7;
t2=t8;
goto loop;}}

/* k8367 in loop in k8339 in k8228 in k8225 in k8222 in k8219 in a8216 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_8369(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8369,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,t1));}

/* k8347 in k8339 in k8228 in k8225 in k8222 in k8219 in a8216 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_8349(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 44   map */
t2=*((C_word*)lf[2]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],*((C_word*)lf[301]+1),((C_word*)t0)[2],t1);}

/* k8343 in k8339 in k8228 in k8225 in k8222 in k8219 in a8216 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_8345(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[414]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8235 in k8228 in k8225 in k8222 in k8219 in a8216 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_8237(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8237,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8305,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8309,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8333,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   map */
t5=*((C_word*)lf[2]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,t4,((C_word*)t0)[3],((C_word*)t0)[4]);}

/* a8332 in k8235 in k8228 in k8225 in k8222 in k8219 in a8216 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_8333(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8333,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[6],t2,t3));}

/* k8307 in k8235 in k8228 in k8225 in k8222 in k8219 in a8216 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_8309(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8309,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8313,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8317,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8327,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   map */
t5=*((C_word*)lf[2]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,t4,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a8326 in k8307 in k8235 in k8228 in k8225 in k8222 in k8219 in a8216 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_8327(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8327,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[6],t2,t3));}

/* k8315 in k8307 in k8235 in k8228 in k8225 in k8222 in k8219 in a8216 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_8317(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8317,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,lf[528]);
t3=(C_word)C_a_i_list(&a,1,t2);
/* ##sys#append */
t4=*((C_word*)lf[414]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[2],t1,t3);}

/* k8311 in k8307 in k8235 in k8228 in k8225 in k8222 in k8219 in a8216 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_8313(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[414]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8303 in k8235 in k8228 in k8225 in k8222 in k8219 in a8216 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_8305(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8305,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_cons(&a,2,lf[3],t2);
t4=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,((C_word*)t0)[7]);
t5=(C_word)C_a_i_cons(&a,2,lf[3],t4);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8261,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t5,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8265,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t6,tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8289,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   map */
t9=*((C_word*)lf[2]+1);
((C_proc5)C_retrieve_proc(t9))(5,t9,t7,t8,((C_word*)t0)[2],((C_word*)t0)[4]);}

/* a8288 in k8303 in k8235 in k8228 in k8225 in k8222 in k8219 in a8216 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_8289(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8289,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[6],t2,t3));}

/* k8263 in k8303 in k8235 in k8228 in k8225 in k8222 in k8219 in a8216 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_8265(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8265,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8269,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8273,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8283,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   map */
t5=*((C_word*)lf[2]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,t4,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a8282 in k8263 in k8303 in k8235 in k8228 in k8225 in k8222 in k8219 in a8216 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_8283(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8283,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[6],t2,t3));}

/* k8271 in k8263 in k8303 in k8235 in k8228 in k8225 in k8222 in k8219 in a8216 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_8273(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8273,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,lf[528]);
t3=(C_word)C_a_i_list(&a,1,t2);
/* ##sys#append */
t4=*((C_word*)lf[414]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[2],t1,t3);}

/* k8267 in k8263 in k8303 in k8235 in k8228 in k8225 in k8222 in k8219 in a8216 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_8269(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[414]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8259 in k8303 in k8235 in k8228 in k8225 in k8222 in k8219 in a8216 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_8261(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8261,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_cons(&a,2,lf[3],t2);
t4=(C_word)C_a_i_list(&a,4,lf[515],((C_word*)t0)[5],((C_word*)t0)[4],t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,3,lf[413],((C_word*)t0)[2],t4));}

/* k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_1118(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1118,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1121,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8122,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   ##sys#register-macro */
t4=C_retrieve(lf[390]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[527],t3);}

/* a8121 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_8122(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+24)){
C_save_and_reclaim((void*)tr3r,(void*)f_8122r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_8122r(t0,t1,t2,t3);}}

static void C_ccall f_8122r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(24);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_FALSE;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=(C_word)C_a_i_cons(&a,2,lf[403],t3);
t11=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8129,a[2]=t5,a[3]=t10,a[4]=t1,a[5]=t9,a[6]=t7,tmp=(C_word)a,a+=7,tmp);
t12=C_SCHEME_UNDEFINED;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_set_block_item(t13,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8158,a[2]=t7,a[3]=t9,a[4]=t5,a[5]=t13,tmp=(C_word)a,a+=6,tmp));
t15=((C_word*)t13)[1];
f_8158(t15,t11,t2);}

/* loop in a8121 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_fcall f_8158(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8158,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8171,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_eqp(t3,lf[63]);
if(C_truep(t5)){
t6=C_set_block_item(((C_word*)t0)[4],0,C_SCHEME_TRUE);
t7=t4;
f_8171(2,t7,t6);}
else{
t6=(C_word)C_eqp(t3,lf[91]);
t7=(C_truep(t6)?t6:(C_word)C_eqp(t3,lf[523]));
if(C_truep(t7)){
t8=C_set_block_item(((C_word*)t0)[3],0,C_SCHEME_TRUE);
t9=t4;
f_8171(2,t9,t8);}
else{
t8=(C_word)C_eqp(t3,lf[524]);
t9=(C_truep(t8)?t8:(C_word)C_eqp(t3,lf[525]));
if(C_truep(t9)){
t10=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_TRUE);
t11=t4;
f_8171(2,t11,t10);}
else{
t10=(C_word)C_slot(t2,C_fix(0));
/* csi.scm: 44   ##sys#error */
t11=*((C_word*)lf[53]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t4,lf[526],t10);}}}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k8169 in loop in a8121 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_8171(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* csi.scm: 44   loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_8158(t3,((C_word*)t0)[2],t2);}

/* k8127 in a8121 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_8129(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8129,2,t0,t1);}
if(C_truep((C_word)C_i_memq(lf[518],C_retrieve(lf[18])))){
t2=(C_truep(((C_word*)((C_word*)t0)[6])[1])?((C_word*)((C_word*)t0)[5])[1]:C_SCHEME_FALSE);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?(C_word)C_a_i_list(&a,2,lf[519],((C_word*)t0)[3]):(C_truep(((C_word*)((C_word*)t0)[6])[1])?(C_word)C_a_i_list(&a,2,lf[520],((C_word*)t0)[3]):(C_truep(((C_word*)((C_word*)t0)[5])[1])?((C_word*)t0)[3]:lf[521]))));}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(((C_word*)((C_word*)t0)[2])[1])?((C_word*)t0)[3]:lf[522]));}}

/* k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_1121(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1121,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1124,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=*((C_word*)lf[129]+1);
t4=*((C_word*)lf[479]+1);
t5=*((C_word*)lf[2]+1);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8012,a[2]=t3,a[3]=t4,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 44   ##sys#register-macro */
t7=C_retrieve(lf[390]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t2,lf[516],t6);}

/* a8011 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_8012(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3r,(void*)f_8012r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_8012r(t0,t1,t2,t3);}}

static void C_ccall f_8012r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(8);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8016,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
/* csi.scm: 44   ##sys#check-syntax */
t5=C_retrieve(lf[8]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,lf[516],t2,lf[517]);}

/* k8014 in a8011 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_8016(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8016,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8019,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* csi.scm: 44   gensym */
t3=C_retrieve(lf[7]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k8017 in k8014 in a8011 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_8019(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8019,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8022,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* csi.scm: 44   ##sys#map */
t3=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k8020 in k8017 in k8014 in a8011 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_8022(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8022,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8025,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* csi.scm: 44   ##sys#map */
t3=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k8023 in k8020 in k8017 in k8014 in a8011 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_8025(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8025,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8028,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8116,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   ##sys#map */
t4=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a8115 in k8023 in k8020 in k8017 in k8014 in a8011 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_8116(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8116,3,t0,t1,t2);}
/* csi.scm: 44   gensym */
t3=C_retrieve(lf[7]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t1);}

/* k8026 in k8023 in k8020 in k8017 in k8014 in a8011 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_8028(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8028,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8031,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8110,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   ##sys#map */
t4=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a8109 in k8026 in k8023 in k8020 in k8017 in k8014 in a8011 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_8110(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8110,3,t0,t1,t2);}
/* csi.scm: 44   gensym */
t3=C_retrieve(lf[7]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t1);}

/* k8029 in k8026 in k8023 in k8020 in k8017 in k8014 in a8011 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_8031(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8031,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8038,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8104,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 44   map */
t4=((C_word*)t0)[5];
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,*((C_word*)lf[301]+1),((C_word*)t0)[4],((C_word*)t0)[2]);}

/* k8102 in k8029 in k8026 in k8023 in k8020 in k8017 in k8014 in a8011 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_8104(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8104,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8108,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 44   map */
t3=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,*((C_word*)lf[301]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k8106 in k8102 in k8029 in k8026 in k8023 in k8020 in k8017 in k8014 in a8011 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_8108(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 44   ##sys#append */
t2=*((C_word*)lf[414]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8036 in k8029 in k8026 in k8023 in k8020 in k8017 in k8014 in a8011 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_8038(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8038,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8074,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8076,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   map */
t4=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a8075 in k8036 in k8029 in k8026 in k8023 in k8020 in k8017 in k8014 in a8011 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_8076(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[39],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8076,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_list(&a,1,t2);
t5=(C_word)C_a_i_list(&a,2,lf[96],t4);
t6=(C_word)C_a_i_list(&a,1,t5);
t7=(C_word)C_a_i_list(&a,2,t2,t3);
t8=(C_word)C_a_i_list(&a,3,lf[6],t3,lf[96]);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_a_i_list(&a,4,lf[413],t6,t7,t8));}

/* k8072 in k8036 in k8029 in k8026 in k8023 in k8020 in k8017 in k8014 in a8011 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_8074(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[51],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8074,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_cons(&a,2,lf[3],t2);
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[5],t3);
t5=(C_word)C_a_i_list(&a,1,t4);
t6=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,((C_word*)t0)[4]);
t7=(C_word)C_a_i_cons(&a,2,lf[3],t6);
t8=(C_word)C_a_i_list(&a,4,lf[515],((C_word*)t0)[5],t7,((C_word*)t0)[5]);
t9=(C_word)C_a_i_list(&a,3,lf[413],t5,t8);
t10=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_list(&a,3,lf[413],((C_word*)t0)[2],t9));}

/* k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_1124(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1124,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1127,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8002,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   ##sys#register-macro */
t4=C_retrieve(lf[390]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[514],t3);}

/* a8001 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_8002(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr3r,(void*)f_8002r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_8002r(t0,t1,t2,t3);}}

static void C_ccall f_8002r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(12);
t4=(C_word)C_a_i_cons(&a,2,lf[403],t3);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,3,lf[450],t2,t4));}

/* k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_1127(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1127,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1130,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7988,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   ##sys#register-macro */
t4=C_retrieve(lf[390]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[513],t3);}

/* a7987 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_7988(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+18)){
C_save_and_reclaim((void*)tr3r,(void*)f_7988r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_7988r(t0,t1,t2,t3);}}

static void C_ccall f_7988r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(18);
t4=(C_word)C_a_i_list(&a,1,lf[4]);
t5=(C_word)C_a_i_cons(&a,2,lf[403],t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_list(&a,4,lf[450],t2,t4,t5));}

/* k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_1130(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1130,2,t0,t1);}
t2=*((C_word*)lf[2]+1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1131,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1204,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 44   ##sys#register-macro */
t5=C_retrieve(lf[390]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,lf[512],t3);}

/* k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_1204(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1204,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1207,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 44   ##sys#register-macro */
t3=C_retrieve(lf[390]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[511],((C_word*)t0)[2]);}

/* k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_1207(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1207,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1210,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7655,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t8=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7686,a[2]=t6,tmp=(C_word)a,a+=3,tmp));
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7726,a[2]=t4,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 44   ##sys#register-macro-2 */
t10=C_retrieve(lf[417]);
((C_proc4)C_retrieve_proc(t10))(4,t10,t2,lf[507],t9);}

/* a7653 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_7726(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7726,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7730,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 44   ##sys#check-syntax */
t4=C_retrieve(lf[8]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[507],t2,lf[510]);}

/* k7728 in a7653 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_7730(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7730,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7739,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* map */
t5=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,*((C_word*)lf[129]+1),t2);}

/* k7737 in k7728 in a7653 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_7739(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7739,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7742,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7948,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_7948(t6,t2,t1,C_SCHEME_END_OF_LIST);}

/* loop in k7737 in k7728 in a7653 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_fcall f_7948(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7948,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7961,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_listp(t4))){
/* csi.scm: 44   append */
t6=*((C_word*)lf[263]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,t4,t3);}
else{
if(C_truep((C_word)C_i_pairp(t4))){
/* csi.scm: 44   append* */
t6=((C_word*)((C_word*)t0)[2])[1];
f_7655(t6,t5,t4,t3);}
else{
t6=t5;
f_7961(2,t6,(C_word)C_a_i_cons(&a,2,t4,t3));}}}}

/* k7959 in loop in k7737 in k7728 in a7653 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_7961(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* csi.scm: 44   loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_7948(t3,((C_word*)t0)[2],t2,t1);}

/* k7740 in k7737 in k7728 in a7653 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_7742(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7742,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7745,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7938,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,t1);}

/* a7937 in k7740 in k7737 in k7728 in a7653 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_7938(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7938,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7946,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 44   gensym */
t4=C_retrieve(lf[7]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k7944 in a7937 in k7740 in k7737 in k7728 in a7653 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_7946(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7946,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k7743 in k7740 in k7737 in k7728 in a7653 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_7745(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7745,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7746,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7757,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7892,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t5,tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_7892(t7,t3,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);}

/* loop in k7743 in k7740 in k7737 in k7728 in a7653 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_fcall f_7892(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7892,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
/* csi.scm: 44   reverse */
t4=*((C_word*)lf[157]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}
else{
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7908,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(t4))){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7932,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 44   map* */
t7=((C_word*)((C_word*)t0)[3])[1];
f_7686(t7,t6,((C_word*)t0)[2],t4);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7925,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 44   lookup */
t7=((C_word*)t0)[2];
f_7746(3,t7,t6,t4);}}}

/* k7923 in loop in k7743 in k7740 in k7737 in k7728 in a7653 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_7925(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7925,2,t0,t1);}
t2=((C_word*)t0)[3];
f_7908(t2,(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[2]));}

/* k7930 in loop in k7743 in k7740 in k7737 in k7728 in a7653 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_7932(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7932,2,t0,t1);}
t2=((C_word*)t0)[3];
f_7908(t2,(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[2]));}

/* k7906 in loop in k7743 in k7740 in k7737 in k7728 in a7653 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_fcall f_7908(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* csi.scm: 44   loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_7892(t3,((C_word*)t0)[2],t2,t1);}

/* k7755 in k7743 in k7740 in k7737 in k7728 in a7653 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_7757(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7757,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7764,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7886,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a7885 in k7755 in k7743 in k7740 in k7737 in k7728 in a7653 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_7886(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7886,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_cadr(t2));}

/* k7762 in k7755 in k7743 in k7740 in k7737 in k7728 in a7653 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_7764(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7764,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7766,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_7766(t5,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* fold in k7762 in k7755 in k7743 in k7740 in k7737 in k7728 in a7653 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_fcall f_7766(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7766,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7784,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7786,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* map */
t7=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,((C_word*)t0)[3]);}
else{
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7800,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t2,a[5]=t1,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
t6=(C_word)C_i_car(t4);
if(C_truep((C_word)C_i_pairp(t6))){
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7880,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 44   cdar */
t8=*((C_word*)lf[258]+1);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t4);}
else{
t7=t5;
f_7800(t7,C_SCHEME_FALSE);}}}

/* k7878 in fold in k7762 in k7755 in k7743 in k7740 in k7737 in k7728 in a7653 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_7880(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_7800(t2,(C_word)C_i_nullp(t1));}

/* k7798 in fold in k7762 in k7755 in k7743 in k7740 in k7737 in k7728 in a7653 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_fcall f_7800(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7800,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7831,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* csi.scm: 44   caar */
t3=*((C_word*)lf[259]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[3]);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(C_word)C_a_i_list(&a,3,lf[3],C_SCHEME_END_OF_LIST,t2);
t4=(C_word)C_i_car(((C_word*)t0)[3]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7854,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_i_cdr(((C_word*)t0)[4]);
t7=(C_word)C_i_cdr(((C_word*)t0)[6]);
t8=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* csi.scm: 44   fold */
t9=((C_word*)((C_word*)t0)[2])[1];
f_7766(t9,t5,t6,t7,t8);}}

/* k7852 in k7798 in fold in k7762 in k7755 in k7743 in k7740 in k7737 in k7728 in a7653 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_7854(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7854,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,lf[3],((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,3,lf[5],((C_word*)t0)[2],t2));}

/* k7829 in k7798 in fold in k7762 in k7755 in k7743 in k7740 in k7737 in k7728 in a7653 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_7831(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7831,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(C_word)C_a_i_list(&a,2,t1,t2);
t4=(C_word)C_a_i_list(&a,1,t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7811,a[2]=t4,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(((C_word*)t0)[4]);
t7=(C_word)C_i_cdr(((C_word*)t0)[6]);
t8=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* csi.scm: 44   fold */
t9=((C_word*)((C_word*)t0)[2])[1];
f_7766(t9,t5,t6,t7,t8);}

/* k7809 in k7829 in k7798 in fold in k7762 in k7755 in k7743 in k7740 in k7737 in k7728 in a7653 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_7811(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7811,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[413],((C_word*)t0)[2],t1));}

/* a7785 in fold in k7762 in k7755 in k7743 in k7740 in k7737 in k7728 in a7653 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_7786(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7786,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7794,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 44   lookup */
t4=((C_word*)t0)[2];
f_7746(3,t4,t3,t2);}

/* k7792 in a7785 in fold in k7762 in k7755 in k7743 in k7740 in k7737 in k7728 in a7653 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_7794(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7794,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[2],t1));}

/* k7782 in fold in k7762 in k7755 in k7743 in k7740 in k7737 in k7728 in a7653 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_7784(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7784,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[413],t2));}

/* lookup in k7743 in k7740 in k7737 in k7728 in a7653 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_7746(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7746,3,t0,t1,t2);}
t3=(C_word)C_i_assq(t2,((C_word*)t0)[2]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_cdr(t3));}

/* map* in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_fcall f_7686(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7686,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
if(C_truep((C_word)C_i_pairp(t3))){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7709,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(t3);
/* csi.scm: 44   proc */
t6=t2;
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}
else{
/* csi.scm: 44   proc */
t4=t2;
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}}}

/* k7707 in map* in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_7709(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7709,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7713,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* csi.scm: 44   map* */
t4=((C_word*)((C_word*)t0)[3])[1];
f_7686(t4,t2,((C_word*)t0)[2],t3);}

/* k7711 in k7707 in map* in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_7713(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7713,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* append* in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_fcall f_7655(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(7);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_7655,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7676,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(t2);
/* csi.scm: 44   append* */
t8=t5;
t9=t6;
t10=t3;
t1=t8;
t2=t9;
t3=t10;
goto loop;}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,t2,t3));}}

/* k7674 in append* in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_7676(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7676,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_1210(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1210,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1213,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7604,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   ##sys#register-macro-2 */
t4=C_retrieve(lf[417]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[508],t3);}

/* a7603 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_7604(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7604,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7608,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 44   ##sys#check-syntax */
t4=C_retrieve(lf[8]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[508],t2,lf[509]);}

/* k7606 in a7603 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_7608(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7608,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7619,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_7619(t7,((C_word*)t0)[2],t2);}

/* fold in k7606 in a7603 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_fcall f_7619(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(13);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_7619,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,((C_word*)t0)[3]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[413],t3));}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_a_i_list(&a,1,t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7644,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(t2);
/* csi.scm: 44   fold */
t9=t5;
t10=t6;
t1=t9;
t2=t10;
goto loop;}}

/* k7642 in fold in k7606 in a7603 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_7644(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7644,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[507],((C_word*)t0)[2],t1));}

/* k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_1213(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1213,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1216,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7484,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   ##sys#register-macro-2 */
t4=C_retrieve(lf[417]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[505],t3);}

/* a7483 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_7484(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7484,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7488,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 44   ##sys#check-syntax */
t4=C_retrieve(lf[8]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[505],t2,lf[506]);}

/* k7486 in a7483 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_7488(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7488,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7497,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7596,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7598,tmp=(C_word)a,a+=2,tmp);
/* map */
t7=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,t2);}

/* a7597 in k7486 in a7483 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_7598(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7598,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_car(t2));}

/* k7594 in k7486 in a7483 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_7596(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],*((C_word*)lf[414]+1),t1);}

/* k7495 in k7486 in a7483 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_7497(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7497,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7500,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7584,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,t1);}

/* a7583 in k7495 in k7486 in a7483 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_7584(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7584,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7592,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 44   gensym */
t4=C_retrieve(lf[7]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k7590 in a7583 in k7495 in k7486 in a7483 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_7592(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7592,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k7498 in k7495 in k7486 in a7483 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_7500(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7500,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7501,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7520,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7578,tmp=(C_word)a,a+=2,tmp);
/* map */
t5=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a7577 in k7498 in k7495 in k7486 in a7483 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_7578(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7578,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,t2,lf[504]));}

/* k7518 in k7498 in k7495 in k7486 in a7483 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_7520(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7520,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7524,a[2]=((C_word*)t0)[5],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7528,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7530,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* map */
t5=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a7529 in k7518 in k7498 in k7495 in k7486 in a7483 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_7530(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7530,3,t0,t1,t2);}
t3=(C_word)C_i_cadr(t2);
t4=(C_word)C_a_i_list(&a,3,lf[3],C_SCHEME_END_OF_LIST,t3);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7550,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t4,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_i_car(t2);
/* map */
t7=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,((C_word*)t0)[2],t6);}

/* k7548 in a7529 in k7518 in k7498 in k7495 in k7486 in a7483 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_7550(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7550,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7554,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7556,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[2]);
/* map */
t5=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,t3,t4);}

/* a7555 in k7548 in a7529 in k7518 in k7498 in k7495 in k7486 in a7483 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_7556(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7556,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7564,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 44   lookup */
t4=((C_word*)t0)[2];
f_7501(3,t4,t3,t2);}

/* k7562 in a7555 in k7548 in a7529 in k7518 in k7498 in k7495 in k7486 in a7483 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_7564(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7564,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[6],((C_word*)t0)[2],t1));}

/* k7552 in k7548 in a7529 in k7518 in k7498 in k7495 in k7486 in a7483 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_7554(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7554,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[3],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[5],((C_word*)t0)[2],t3));}

/* k7526 in k7518 in k7498 in k7495 in k7486 in a7483 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_7528(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[414]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k7522 in k7518 in k7498 in k7495 in k7486 in a7483 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_7524(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7524,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[413],t2));}

/* lookup in k7498 in k7495 in k7486 in a7483 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_7501(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7501,3,t0,t1,t2);}
t3=(C_word)C_i_assq(t2,((C_word*)t0)[2]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_cdr(t3));}

/* k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_1216(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1216,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1219,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7463,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   ##sys#register-macro */
t4=C_retrieve(lf[390]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[503],t3);}

/* a7462 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_7463(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7463,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7467,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 44   gensym */
t5=C_retrieve(lf[7]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k7465 in a7462 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_7467(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7467,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,lf[3],C_SCHEME_END_OF_LIST,((C_word*)t0)[4]);
t3=(C_word)C_a_i_list(&a,3,lf[194],t1,((C_word*)t0)[3]);
t4=(C_word)C_a_i_list(&a,3,lf[3],t1,t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,3,lf[5],t2,t4));}

/* k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_1219(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1219,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1298,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7453,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   ##sys#register-macro-2 */
t4=C_retrieve(lf[417]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[500],t3);}

/* a7452 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_7453(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7453,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1225,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 44   ##sys#check-syntax */
t4=C_retrieve(lf[8]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[500],t2,lf[502]);}

/* k1223 in a7452 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_1225(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1225,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(C_word)C_i_pairp(t2);
t4=(C_truep(t3)?(C_word)C_i_car(t2):t2);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1234,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t6=(C_word)C_i_cdr(t2);
t7=(C_word)C_i_cdr(((C_word*)t0)[3]);
t8=(C_word)C_a_i_cons(&a,2,t6,t7);
t9=t5;
f_1234(t9,(C_word)C_a_i_cons(&a,2,lf[3],t8));}
else{
t6=t5;
f_1234(t6,(C_word)C_i_cadr(((C_word*)t0)[3]));}}

/* k1232 in k1223 in a7452 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_fcall f_1234(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1234,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1237,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_pairp(t1);
t4=(C_word)C_i_not(t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1250,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t4)){
t6=t5;
f_1250(t6,t4);}
else{
t6=(C_word)C_i_car(t1);
t7=(C_word)C_eqp(lf[3],t6);
t8=t5;
f_1250(t8,(C_word)C_i_not(t7));}}

/* k1248 in k1232 in k1223 in a7452 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_fcall f_1250(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* csi.scm: 44   syntax-error */
t2=C_retrieve(lf[387]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[500],lf[501],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_1237(2,t2,C_SCHEME_UNDEFINED);}}

/* k1235 in k1232 in k1223 in a7452 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_1237(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1237,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[30],((C_word*)t0)[4]);
t3=(C_word)C_a_i_list(&a,2,t2,((C_word*)t0)[3]);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[499],t3));}

/* k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_1298(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1298,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1301,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7432,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   ##sys#register-macro-2 */
t4=C_retrieve(lf[417]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[497],t3);}

/* a7431 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_7432(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7432,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7436,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 44   ##sys#check-syntax */
t4=C_retrieve(lf[8]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[497],t2,lf[498]);}

/* k7434 in a7431 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_7436(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7436,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(C_word)C_a_i_list(&a,2,lf[30],t2);
t4=(C_word)C_i_cadr(((C_word*)t0)[3]);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,3,lf[496],t3,t4));}

/* k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_1301(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1301,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1304,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7316,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   ##sys#register-macro-2 */
t4=C_retrieve(lf[417]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[494],t3);}

/* a7315 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_7316(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7316,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7320,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 44   ##sys#check-syntax */
t4=C_retrieve(lf[8]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[494],t2,lf[495]);}

/* k7318 in a7315 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_7320(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7320,2,t0,t1);}
t2=(C_word)C_i_listp(((C_word*)t0)[3]);
t3=(C_word)C_i_not(t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7329,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t3)){
t5=t4;
f_7329(t5,t3);}
else{
t5=(C_word)C_i_length(((C_word*)t0)[3]);
t6=t4;
f_7329(t6,(C_word)C_fixnum_lessp(t5,C_fix(2)));}}

/* k7327 in k7318 in a7315 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_fcall f_7329(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7329,NULL,2,t0,t1);}
if(C_truep(t1)){
/* csi.scm: 44   ##sys#syntax-error-hook */
t2=C_retrieve(lf[492]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],lf[493],((C_word*)t0)[2]);}
else{
t2=(C_word)C_slot(((C_word*)t0)[2],C_fix(0));
t3=(C_word)C_slot(((C_word*)t0)[2],C_fix(1));
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7343,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_7343(t7,((C_word*)t0)[3],t2);}}

/* fold in k7327 in k7318 in a7315 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_fcall f_7343(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
loop:
a=C_alloc(25);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_7343,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[403],((C_word*)t0)[3]));}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t2,C_fix(1));
if(C_truep((C_word)C_i_not_pair_p(t3))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7372,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 44   fold */
t15=t5;
t16=t4;
t1=t15;
t2=t16;
goto loop;}
else{
t5=(C_word)C_slot(t3,C_fix(1));
if(C_truep((C_word)C_i_nullp(t5))){
t6=(C_word)C_slot(t3,C_fix(0));
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7389,a[2]=t6,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 44   fold */
t15=t7;
t16=t4;
t1=t15;
t2=t16;
goto loop;}
else{
t6=(C_word)C_slot(t3,C_fix(0));
t7=(C_word)C_i_cadr(t3);
t8=(C_word)C_a_i_list(&a,2,t6,t7);
t9=(C_word)C_a_i_list(&a,1,t8);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7407,a[2]=t9,a[3]=t1,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 44   fold */
t15=t10;
t16=t4;
t1=t15;
t2=t16;
goto loop;}}}}

/* k7405 in fold in k7327 in k7318 in a7315 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_7407(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7407,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,4,lf[450],((C_word*)t0)[4],t1,C_SCHEME_FALSE);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,3,lf[413],((C_word*)t0)[2],t2));}

/* k7387 in fold in k7327 in k7318 in a7315 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_7389(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7389,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,4,lf[450],((C_word*)t0)[2],t1,C_SCHEME_FALSE));}

/* k7370 in fold in k7327 in k7318 in a7315 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_7372(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7372,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,4,lf[450],((C_word*)t0)[2],t1,C_SCHEME_FALSE));}

/* k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_1304(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1304,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1307,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_retrieve(lf[7]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7217,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 44   ##sys#register-macro-2 */
t5=C_retrieve(lf[417]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t2,lf[489],t4);}

/* a7216 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_7217(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7217,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7227,a[2]=t4,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 44   gensym */
t6=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}

/* k7225 in a7216 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_7227(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7227,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[4]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7238,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7240,a[2]=t1,a[3]=t6,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_7240(t8,t4,((C_word*)t0)[2]);}

/* expand in k7225 in a7216 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_fcall f_7240(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7240,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7256,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* csi.scm: 44   ##sys#check-syntax */
t6=C_retrieve(lf[8]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[489],t3,lf[490]);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[491]);}}

/* k7254 in expand in k7225 in a7216 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_7256(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7256,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(C_word)C_eqp(lf[398],t2);
if(C_truep(t3)){
t4=(C_word)C_i_cdr(((C_word*)t0)[6]);
t5=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,lf[403],t4));}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7292,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7294,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t6=(C_word)C_i_car(((C_word*)t0)[6]);
/* map */
t7=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t4,t5,t6);}}

/* a7293 in k7254 in expand in k7225 in a7216 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_7294(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7294,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,3,lf[484],((C_word*)t0)[2],t2));}

/* k7290 in k7254 in expand in k7225 in a7216 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_7292(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7292,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[488],t1);
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
t4=(C_word)C_a_i_cons(&a,2,lf[403],t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7284,a[2]=t4,a[3]=t2,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 44   expand */
t6=((C_word*)((C_word*)t0)[3])[1];
f_7240(t6,t5,((C_word*)t0)[2]);}

/* k7282 in k7290 in k7254 in expand in k7225 in a7216 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_7284(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7284,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,4,lf[450],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k7236 in k7225 in a7216 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_7238(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7238,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[413],((C_word*)t0)[2],t1));}

/* k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_1307(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1307,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1310,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_retrieve(lf[7]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7128,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 44   ##sys#register-macro-2 */
t5=C_retrieve(lf[417]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t2,lf[485],t4);}

/* a7127 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_7128(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7128,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7138,a[2]=t4,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 44   gensym */
t6=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}

/* k7136 in a7127 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_7138(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7138,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[4]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7149,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7151,a[2]=t6,a[3]=t1,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_7151(t8,t4,((C_word*)t0)[2]);}

/* expand in k7136 in a7127 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_fcall f_7151(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7151,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7167,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* csi.scm: 44   ##sys#check-syntax */
t6=C_retrieve(lf[8]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[485],t3,lf[486]);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[487]);}}

/* k7165 in expand in k7136 in a7127 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_7167(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7167,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(C_word)C_eqp(lf[398],t2);
if(C_truep(t3)){
t4=(C_word)C_i_cdr(((C_word*)t0)[6]);
t5=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,lf[403],t4));}
else{
t4=(C_word)C_i_car(((C_word*)t0)[6]);
t5=(C_word)C_a_i_list(&a,3,lf[484],((C_word*)t0)[4],t4);
t6=(C_word)C_i_cdr(((C_word*)t0)[6]);
t7=(C_word)C_a_i_cons(&a,2,lf[403],t6);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7195,a[2]=t7,a[3]=t5,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 44   expand */
t9=((C_word*)((C_word*)t0)[3])[1];
f_7151(t9,t8,((C_word*)t0)[2]);}}

/* k7193 in k7165 in expand in k7136 in a7127 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_7195(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7195,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,4,lf[450],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k7147 in k7136 in a7127 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_7149(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7149,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[413],((C_word*)t0)[2],t1));}

/* k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_1310(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1310,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1313,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6842,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   ##sys#register-macro */
t4=C_retrieve(lf[390]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[481],t3);}

/* a6841 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_6842(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_6842r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_6842r(t0,t1,t2,t3,t4);}}

static void C_ccall f_6842r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7039,a[2]=t3,a[3]=t1,a[4]=t4,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 44   ##sys#check-syntax */
t6=C_retrieve(lf[8]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[481],t3,lf[483]);}

/* k7037 in a6841 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_7039(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7039,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7042,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 44   ##sys#check-syntax */
t3=C_retrieve(lf[8]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[481],((C_word*)t0)[4],lf[482]);}

/* k7040 in k7037 in a6841 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_7042(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7042,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7045,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* map */
t3=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[129]+1),((C_word*)t0)[2]);}

/* k7043 in k7040 in k7037 in a6841 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_7045(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7045,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7046,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7061,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7118,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* map */
t5=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,t1);}

/* a7117 in k7043 in k7040 in k7037 in a6841 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_7118(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7118,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7126,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 44   prefix-sym */
f_7046(t3,lf[480],t2);}

/* k7124 in a7117 in k7043 in k7040 in k7037 in a6841 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_7126(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 44   gensym */
t2=C_retrieve(lf[7]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k7059 in k7043 in k7040 in k7037 in a6841 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_7061(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7061,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7064,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* map */
t3=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[479]+1),((C_word*)t0)[2]);}

/* k7062 in k7059 in k7043 in k7040 in k7037 in a6841 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_7064(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7064,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7067,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* csi.scm: 44   gensym */
t3=C_retrieve(lf[7]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[478]);}

/* k7065 in k7062 in k7059 in k7043 in k7040 in k7037 in a6841 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_7067(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7067,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7070,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* csi.scm: 44   gensym */
t3=C_retrieve(lf[7]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[477]);}

/* k7068 in k7065 in k7062 in k7059 in k7043 in k7040 in k7037 in a6841 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_7070(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7070,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7073,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7108,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* map */
t4=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[8]);}

/* a7107 in k7068 in k7065 in k7062 in k7059 in k7043 in k7040 in k7037 in a6841 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_7108(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7108,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7116,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 44   prefix-sym */
f_7046(t3,lf[476],t2);}

/* k7114 in a7107 in k7068 in k7065 in k7062 in k7059 in k7043 in k7040 in k7037 in a6841 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_7116(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 44   gensym */
t2=C_retrieve(lf[7]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k7071 in k7068 in k7065 in k7062 in k7059 in k7043 in k7040 in k7037 in a6841 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_7073(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7073,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7076,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t3=((C_word*)t0)[3];
t4=((C_word*)t0)[5];
t5=t1;
t6=((C_word*)t0)[2];
t7=C_retrieve(lf[7]);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6853,a[2]=t5,a[3]=t6,a[4]=t4,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 44   reverse */
t9=*((C_word*)lf[157]+1);
((C_proc3)C_retrieve_proc(t9))(3,t9,t8,t3);}

/* k6851 in k7071 in k7068 in k7065 in k7062 in k7059 in k7043 in k7040 in k7037 in a6841 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_6853(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6853,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6857,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 44   reverse */
t3=*((C_word*)lf[157]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k6855 in k6851 in k7071 in k7068 in k7065 in k7062 in k7059 in k7043 in k7040 in k7037 in a6841 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_6857(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6857,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6861,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 44   reverse */
t3=*((C_word*)lf[157]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k6859 in k6855 in k6851 in k7071 in k7068 in k7065 in k7062 in k7059 in k7043 in k7040 in k7037 in a6841 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_6861(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6861,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6863,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_6863(t5,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* recur in k6859 in k6855 in k6851 in k7071 in k7068 in k7065 in k7062 in k7059 in k7043 in k7040 in k7037 in a6841 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_fcall f_6863(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6863,NULL,6,t0,t1,t2,t3,t4,t5);}
if(C_truep((C_word)C_i_nullp(t2))){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_END_OF_LIST);}
else{
t6=(C_word)C_i_cdr(t2);
t7=(C_word)C_i_car(t3);
t8=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6908,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=t4,a[5]=t3,a[6]=t1,a[7]=t7,a[8]=t5,tmp=(C_word)a,a+=9,tmp);
/* csi.scm: 44   reverse */
t9=*((C_word*)lf[157]+1);
((C_proc3)C_retrieve_proc(t9))(3,t9,t8,t6);}}

/* k6906 in recur in k6859 in k6855 in k6851 in k7071 in k7068 in k7065 in k7062 in k7059 in k7043 in k7040 in k7037 in a6841 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_6908(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6908,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6916,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6920,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 44   reverse */
t4=*((C_word*)lf[157]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k6918 in k6906 in recur in k6859 in k6855 in k6851 in k7071 in k7068 in k7065 in k7062 in k7059 in k7043 in k7040 in k7037 in a6841 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_6920(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6920,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(C_word)C_a_i_list(&a,1,t2);
/* ##sys#append */
t4=*((C_word*)lf[414]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[2],t1,t3);}

/* k6914 in k6906 in recur in k6859 in k6855 in k6851 in k7071 in k7068 in k7065 in k7062 in k7059 in k7043 in k7040 in k7037 in a6841 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_6916(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6916,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t1);
t3=(C_word)C_a_i_list(&a,3,lf[3],((C_word*)t0)[8],t2);
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[7],t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6884,a[2]=t4,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(((C_word*)t0)[5]);
t7=(C_word)C_i_cdr(((C_word*)t0)[4]);
t8=(C_word)C_i_car(((C_word*)t0)[5]);
/* csi.scm: 44   recur */
t9=((C_word*)((C_word*)t0)[3])[1];
f_6863(t9,t5,((C_word*)t0)[2],t6,t7,t8);}

/* k6882 in k6914 in k6906 in recur in k6859 in k6855 in k6851 in k7071 in k7068 in k7065 in k7062 in k7059 in k7043 in k7040 in k7037 in a6841 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_6884(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6884,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k7074 in k7071 in k7068 in k7065 in k7062 in k7059 in k7043 in k7040 in k7037 in a6841 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_7076(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7076,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7079,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
t3=((C_word*)t0)[3];
t4=((C_word*)t0)[2];
t5=((C_word*)t0)[5];
t6=((C_word*)t0)[9];
t7=C_retrieve(lf[7]);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6936,a[2]=t9,a[3]=t5,a[4]=t6,tmp=(C_word)a,a+=5,tmp));
t11=((C_word*)t9)[1];
f_6936(t11,t2,t3,t4,C_SCHEME_END_OF_LIST);}

/* recur in k7074 in k7071 in k7068 in k7065 in k7062 in k7059 in k7043 in k7040 in k7037 in a6841 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_fcall f_6936(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6936,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
t5=(C_word)C_a_i_list(&a,2,lf[465],((C_word*)t0)[4]);
t6=(C_word)C_a_i_list(&a,2,lf[431],t5);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6970,a[2]=t6,a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 44   reverse */
t8=*((C_word*)lf[157]+1);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t4);}
else{
t5=(C_word)C_i_car(t2);
t6=(C_word)C_a_i_list(&a,2,lf[465],((C_word*)t0)[4]);
t7=(C_word)C_i_car(t3);
t8=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7036,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t3,a[5]=t2,a[6]=t6,a[7]=t1,a[8]=t5,a[9]=((C_word*)t0)[4],a[10]=t7,tmp=(C_word)a,a+=11,tmp);
/* csi.scm: 44   reverse */
t9=*((C_word*)lf[157]+1);
((C_proc3)C_retrieve_proc(t9))(3,t9,t8,t4);}}

/* k7034 in recur in k7074 in k7071 in k7068 in k7065 in k7062 in k7059 in k7043 in k7040 in k7037 in a6841 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_7036(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[42],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7036,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t1);
t3=(C_word)C_a_i_list(&a,2,lf[129],((C_word*)t0)[9]);
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[8],t3);
t5=(C_word)C_a_i_list(&a,2,lf[454],((C_word*)t0)[9]);
t6=(C_word)C_a_i_list(&a,2,((C_word*)t0)[9],t5);
t7=(C_word)C_a_i_list(&a,2,t4,t6);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7000,a[2]=t2,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=t7,tmp=(C_word)a,a+=6,tmp);
t9=(C_word)C_i_cdr(((C_word*)t0)[5]);
t10=(C_word)C_i_cdr(((C_word*)t0)[4]);
t11=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],((C_word*)t0)[3]);
/* csi.scm: 44   recur */
t12=((C_word*)((C_word*)t0)[2])[1];
f_6936(t12,t8,t9,t10,t11);}

/* k6998 in k7034 in recur in k7074 in k7071 in k7068 in k7065 in k7062 in k7059 in k7043 in k7040 in k7037 in a6841 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_7000(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7000,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,lf[413],((C_word*)t0)[5],t1);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,4,lf[450],((C_word*)t0)[3],((C_word*)t0)[2],t2));}

/* k6968 in recur in k7074 in k7071 in k7068 in k7065 in k7062 in k7059 in k7043 in k7040 in k7037 in a6841 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_6970(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6970,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_list(&a,2,lf[30],lf[475]);
t4=(C_word)C_a_i_list(&a,2,lf[467],t3);
t5=(C_word)C_a_i_list(&a,3,lf[53],t4,((C_word*)t0)[4]);
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_list(&a,4,lf[450],((C_word*)t0)[2],t2,t5));}

/* k7077 in k7074 in k7071 in k7068 in k7065 in k7062 in k7059 in k7043 in k7040 in k7037 in a6841 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_7079(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7079,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[8],((C_word*)t0)[7]);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],((C_word*)t0)[5]);
t4=(C_word)C_a_i_cons(&a,2,lf[3],t3);
t5=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,((C_word*)t0)[3]);
t7=(C_word)C_a_i_cons(&a,2,t2,t6);
t8=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_list(&a,3,lf[474],t7,t1));}

/* prefix-sym in k7043 in k7040 in k7037 in a6841 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_fcall f_7046(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7046,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7054,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7058,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 44   symbol->string */
t6=*((C_word*)lf[473]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t3);}

/* k7056 in prefix-sym in k7043 in k7040 in k7037 in a6841 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_7058(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 44   string-append */
t2=*((C_word*)lf[40]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7052 in prefix-sym in k7043 in k7040 in k7037 in a6841 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_7054(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 44   string->symbol */
t2=*((C_word*)lf[110]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_1313(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1313,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1316,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6785,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   ##sys#register-macro */
t4=C_retrieve(lf[390]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[471],t3);}

/* a6784 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_6785(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6785,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6789,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 44   gensym */
t5=C_retrieve(lf[7]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k6787 in a6784 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_6789(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[93],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6789,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[4]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(C_word)C_a_i_list(&a,2,lf[465],t1);
t5=(C_word)C_a_i_list(&a,2,lf[454],t1);
t6=(C_word)C_a_i_list(&a,2,lf[465],t5);
t7=(C_word)C_a_i_list(&a,2,lf[431],t6);
t8=(C_word)C_a_i_list(&a,2,lf[129],t1);
t9=(C_word)C_a_i_list(&a,2,lf[30],lf[1]);
t10=(C_word)C_a_i_list(&a,2,lf[467],t9);
t11=(C_word)C_a_i_list(&a,3,lf[53],t10,t1);
t12=(C_word)C_a_i_list(&a,4,lf[450],t7,t8,t11);
t13=(C_word)C_a_i_list(&a,4,lf[450],t4,((C_word*)t0)[3],t12);
t14=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,(C_word)C_a_i_list(&a,3,lf[413],t3,t13));}

/* k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_1316(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1316,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1319,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6779,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   ##sys#register-macro-2 */
t4=C_retrieve(lf[417]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[472],t3);}

/* a6778 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_6779(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6779,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[471],t2));}

/* k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_1319(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1319,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1322,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6626,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   ##sys#register-macro */
t4=C_retrieve(lf[390]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[468],t3);}

/* a6625 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_6626(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_6626r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_6626r(t0,t1,t2,t3,t4);}}

static void C_ccall f_6626r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6630,a[2]=t3,a[3]=t4,a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 44   ##sys#check-syntax */
t6=C_retrieve(lf[8]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[468],t3,lf[470]);}

/* k6628 in a6625 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_6630(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6630,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6633,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 44   ##sys#check-syntax */
t3=C_retrieve(lf[8]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[468],((C_word*)t0)[3],lf[469]);}

/* k6631 in k6628 in a6625 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_6633(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6633,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6636,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 44   gensym */
t3=C_retrieve(lf[7]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k6634 in k6631 in k6628 in a6625 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_6636(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6636,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[5]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6647,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6649,a[2]=t6,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_6649(t8,t4,t1,((C_word*)t0)[2]);}

/* loop in k6634 in k6631 in k6628 in a6625 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_fcall f_6649(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[73],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6649,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=(C_word)C_a_i_list(&a,2,lf[465],t2);
t5=(C_word)C_a_i_list(&a,2,lf[431],t4);
t6=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,((C_word*)t0)[3]);
t7=(C_word)C_a_i_cons(&a,2,lf[413],t6);
t8=(C_word)C_a_i_list(&a,2,lf[30],lf[466]);
t9=(C_word)C_a_i_list(&a,2,lf[467],t8);
t10=(C_word)C_a_i_list(&a,3,lf[53],t9,t2);
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_word)C_a_i_list(&a,4,lf[450],t5,t7,t10));}
else{
t4=(C_word)C_i_car(t3);
if(C_truep((C_word)C_i_pairp(t4))){
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6699,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t1,a[5]=t2,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
/* csi.scm: 44   gensym */
t6=C_retrieve(lf[7]);
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}
else{
t5=(C_word)C_a_i_list(&a,2,t4,t2);
t6=(C_word)C_a_i_list(&a,1,t5);
t7=(C_word)C_a_i_cons(&a,2,t6,((C_word*)t0)[3]);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,lf[413],t7));}}}

/* k6697 in loop in k6634 in k6631 in k6628 in a6625 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_6699(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[76],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6699,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(C_word)C_a_i_list(&a,2,lf[465],((C_word*)t0)[5]);
t4=(C_word)C_i_cadr(((C_word*)t0)[6]);
t5=(C_word)C_a_i_list(&a,2,lf[129],((C_word*)t0)[5]);
t6=(C_word)C_a_i_list(&a,4,lf[450],t3,t4,t5);
t7=(C_word)C_a_i_list(&a,2,t2,t6);
t8=(C_word)C_a_i_list(&a,2,lf[465],((C_word*)t0)[5]);
t9=(C_word)C_a_i_list(&a,2,lf[30],C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_list(&a,2,lf[454],((C_word*)t0)[5]);
t11=(C_word)C_a_i_list(&a,4,lf[450],t8,t9,t10);
t12=(C_word)C_a_i_list(&a,2,t1,t11);
t13=(C_word)C_a_i_list(&a,2,t7,t12);
t14=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6710,a[2]=t13,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t15=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* csi.scm: 44   loop */
t16=((C_word*)((C_word*)t0)[2])[1];
f_6649(t16,t14,t1,t15);}

/* k6708 in k6697 in loop in k6634 in k6631 in k6628 in a6625 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_6710(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6710,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[413],((C_word*)t0)[2],t1));}

/* k6645 in k6634 in k6631 in k6628 in a6625 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_6647(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6647,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[413],((C_word*)t0)[2],t1));}

/* k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_1322(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1322,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1325,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6350,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   ##sys#register-macro-2 */
t4=C_retrieve(lf[417]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[457],t3);}

/* a6349 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_6350(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6350,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6384,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 44   ##sys#check-syntax */
t4=C_retrieve(lf[8]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[457],t2,lf[464]);}

/* k6382 in a6349 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_6384(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6384,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6387,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 44   require */
t3=C_retrieve(lf[462]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[463]);}

/* k6385 in k6382 in a6349 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_6387(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6387,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6390,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6611,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6613,tmp=(C_word)a,a+=2,tmp);
/* map */
t5=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a6612 in k6385 in k6382 in a6349 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_6613(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[2],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6613,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6623,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   ##sys#decompose-lambda-list */
t5=C_retrieve(lf[459]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t3,t4);}

/* a6622 in a6612 in k6385 in k6382 in a6349 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_6623(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6623,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}

/* k6609 in k6385 in k6382 in a6349 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_6611(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],*((C_word*)lf[277]+1),t1);}

/* k6388 in k6385 in k6382 in a6349 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_6390(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6390,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6393,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=t1;
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6359,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_6359(t7,t2,C_fix(0));}

/* loop in k6388 in k6385 in k6382 in a6349 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_fcall f_6359(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6359,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[3]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6373,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 44   gensym */
t4=C_retrieve(lf[7]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}}

/* k6371 in loop in k6388 in k6385 in k6382 in a6349 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_6373(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6373,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6377,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* csi.scm: 44   loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_6359(t4,t2,t3);}

/* k6375 in k6371 in loop in k6388 in k6385 in k6382 in a6349 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_6377(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6377,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k6391 in k6388 in k6385 in k6382 in a6349 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_6393(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6393,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6396,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 44   gensym */
t3=C_retrieve(lf[7]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k6394 in k6391 in k6388 in k6385 in k6382 in a6349 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_6396(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6396,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6399,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* csi.scm: 44   gensym */
t3=C_retrieve(lf[7]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k6397 in k6394 in k6391 in k6388 in k6385 in k6382 in a6349 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_6399(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6399,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6406,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* csi.scm: 44   append */
t3=*((C_word*)lf[263]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[6]);}

/* k6404 in k6397 in k6394 in k6391 in k6388 in k6385 in k6382 in a6349 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_6406(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6406,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[69],((C_word*)t0)[7]);
t3=(C_word)C_a_i_list(&a,2,((C_word*)t0)[6],t2);
t4=(C_word)C_a_i_list(&a,1,t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6418,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6420,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 44   fold-right */
t7=C_retrieve(lf[460]);
((C_proc5)C_retrieve_proc(t7))(5,t7,t5,t6,lf[461],((C_word*)t0)[2]);}

/* a6419 in k6404 in k6397 in k6394 in k6391 in k6388 in k6385 in k6382 in a6349 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_6420(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6420,4,t0,t1,t2,t3);}
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6430,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=t3,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
/* csi.scm: 44   ##sys#decompose-lambda-list */
t6=C_retrieve(lf[459]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t1,t4,t5);}

/* a6429 in a6419 in k6404 in k6397 in k6394 in k6391 in k6388 in k6385 in k6382 in a6349 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_6430(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6430,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6434,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t4,a[6]=((C_word*)t0)[5],a[7]=t2,a[8]=((C_word*)t0)[6],a[9]=t1,a[10]=((C_word*)t0)[7],a[11]=t3,tmp=(C_word)a,a+=12,tmp);
t6=(C_word)C_i_car(((C_word*)t0)[4]);
/* csi.scm: 44   ##sys#check-syntax */
t7=C_retrieve(lf[8]);
((C_proc5)C_retrieve_proc(t7))(5,t7,t5,lf[457],t6,lf[458]);}

/* k6432 in a6429 in a6419 in k6404 in k6397 in k6394 in k6391 in k6388 in k6385 in k6382 in a6349 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_6434(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[29],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6434,2,t0,t1);}
t2=(C_word)C_fixnum_difference(((C_word*)t0)[11],((C_word*)t0)[10]);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6444,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
if(C_truep(((C_word*)t0)[5])){
t4=(C_word)C_i_zerop(t2);
t5=t3;
f_6444(t5,(C_truep(t4)?C_SCHEME_TRUE:(C_word)C_a_i_list(&a,3,lf[455],((C_word*)t0)[2],t2)));}
else{
t4=t3;
f_6444(t4,(C_word)C_a_i_list(&a,3,lf[456],((C_word*)t0)[2],t2));}}

/* k6442 in k6432 in a6429 in a6419 in k6404 in k6397 in k6394 in k6391 in k6388 in k6385 in k6382 in a6349 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_fcall f_6444(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6444,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6448,a[2]=((C_word*)t0)[9],a[3]=t1,a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6450,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6460,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 44   ##sys#call-with-values */
C_call_with_values(4,0,t2,t3,t4);}

/* a6459 in k6442 in k6432 in a6429 in a6419 in k6404 in k6397 in k6394 in k6391 in k6388 in k6385 in k6382 in a6349 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_6460(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6460,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6464,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6479,a[2]=t6,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_6479(t8,t4,t3,((C_word*)t0)[2]);}

/* build in a6459 in k6442 in k6432 in a6429 in a6419 in k6404 in k6397 in k6394 in k6391 in k6388 in k6385 in k6382 in a6349 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_fcall f_6479(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6479,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
if(C_truep(((C_word*)t0)[4])){
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t3);
t5=(C_word)C_a_i_list(&a,1,t4);
t6=(C_word)C_i_cdr(((C_word*)t0)[3]);
t7=(C_word)C_a_i_cons(&a,2,t5,t6);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,lf[413],t7));}
else{
t4=(C_word)C_i_cddr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_nullp(t4))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_i_cadr(((C_word*)t0)[3]));}
else{
t5=(C_word)C_i_cdr(((C_word*)t0)[3]);
t6=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t5);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_cons(&a,2,lf[413],t6));}}}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6535,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 44   gensym */
t5=C_retrieve(lf[7]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}}

/* k6533 in build in a6459 in k6442 in k6432 in a6429 in a6419 in k6404 in k6397 in k6394 in k6391 in k6388 in k6385 in k6382 in a6349 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_6535(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[34],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6535,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_a_i_list(&a,2,lf[129],((C_word*)t0)[4]);
t4=(C_word)C_a_i_list(&a,2,t2,t3);
t5=(C_word)C_a_i_list(&a,2,lf[454],((C_word*)t0)[4]);
t6=(C_word)C_a_i_list(&a,2,t1,t5);
t7=(C_word)C_a_i_list(&a,2,t4,t6);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6546,a[2]=t7,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t9=(C_word)C_i_cdr(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_pairp(t9))){
t10=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* csi.scm: 44   build */
t11=((C_word*)((C_word*)t0)[2])[1];
f_6479(t11,t8,t10,t1);}
else{
/* csi.scm: 44   build */
t10=((C_word*)((C_word*)t0)[2])[1];
f_6479(t10,t8,C_SCHEME_END_OF_LIST,t1);}}

/* k6544 in k6533 in build in a6459 in k6442 in k6432 in a6429 in a6419 in k6404 in k6397 in k6394 in k6391 in k6388 in k6385 in k6382 in a6349 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_6546(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6546,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[413],((C_word*)t0)[2],t1));}

/* k6462 in a6459 in k6442 in k6432 in a6429 in a6419 in k6404 in k6397 in k6394 in k6391 in k6388 in k6385 in k6382 in a6349 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_6464(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6464,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[4]))){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6477,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 44   map */
t3=*((C_word*)lf[2]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,*((C_word*)lf[453]+1),((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* k6475 in k6462 in a6459 in k6442 in k6432 in a6429 in a6419 in k6404 in k6397 in k6394 in k6391 in k6388 in k6385 in k6382 in a6349 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_6477(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6477,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[413],t1,((C_word*)t0)[2]));}

/* a6449 in k6442 in k6432 in a6429 in a6419 in k6404 in k6397 in k6394 in k6391 in k6388 in k6385 in k6382 in a6349 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_6450(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6450,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6458,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 44   take */
t3=C_retrieve(lf[452]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k6456 in a6449 in k6442 in k6432 in a6429 in a6419 in k6404 in k6397 in k6394 in k6391 in k6388 in k6385 in k6382 in a6349 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_6458(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 44   split-at! */
t2=C_retrieve(lf[451]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k6446 in k6442 in k6432 in a6429 in a6419 in k6404 in k6397 in k6394 in k6391 in k6388 in k6385 in k6382 in a6349 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_6448(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6448,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,4,lf[450],((C_word*)t0)[3],t1,((C_word*)t0)[2]));}

/* k6416 in k6404 in k6397 in k6394 in k6391 in k6388 in k6385 in k6382 in a6349 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_6418(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6418,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,lf[413],((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,3,lf[3],((C_word*)t0)[2],t2));}

/* k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_1325(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1325,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1328,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6293,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   ##sys#register-macro */
t4=C_retrieve(lf[390]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[447],t3);}

/* a6292 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_6293(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+16)){
C_save_and_reclaim((void*)tr3r,(void*)f_6293r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6293r(t0,t1,t2,t3);}}

static void C_ccall f_6293r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(16);
if(C_truep((C_word)C_i_pairp(t2))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6303,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_a_i_cons(&a,2,t2,t3);
/* csi.scm: 44   ##sys#check-syntax */
t6=C_retrieve(lf[8]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t4,lf[447],t5,lf[448]);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6333,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_a_i_cons(&a,2,t2,t3);
/* csi.scm: 44   ##sys#check-syntax */
t6=C_retrieve(lf[8]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t4,lf[447],t5,lf[449]);}}

/* k6331 in a6292 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_6333(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6333,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[30],((C_word*)t0)[4]);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[3]);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[446],t3));}

/* k6301 in a6292 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_6303(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6303,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(0));
t3=(C_word)C_a_i_list(&a,2,lf[30],t2);
t4=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t5=(C_word)C_a_i_cons(&a,2,t4,((C_word*)t0)[3]);
t6=(C_word)C_a_i_cons(&a,2,lf[3],t5);
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_list(&a,3,lf[446],t3,t6));}

/* k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_1328(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1328,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1331,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6217,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   ##sys#register-macro */
t4=C_retrieve(lf[390]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[441],t3);}

/* a6216 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_6217(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_6217r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_6217r(t0,t1,t2,t3,t4);}}

static void C_ccall f_6217r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6221,a[2]=t1,a[3]=t4,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 44   gensym */
t6=C_retrieve(lf[7]);
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}

/* k6219 in a6216 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_6221(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6221,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6224,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* csi.scm: 44   gensym */
t3=C_retrieve(lf[7]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k6222 in k6219 in a6216 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_6224(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[114],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6224,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[6]);
t3=(C_word)C_a_i_list(&a,1,((C_word*)t0)[5]);
t4=(C_word)C_a_i_list(&a,3,lf[3],C_SCHEME_END_OF_LIST,((C_word*)t0)[4]);
t5=(C_word)C_a_i_list(&a,2,((C_word*)t0)[6],t4);
t6=(C_word)C_a_i_list(&a,3,lf[3],t3,t5);
t7=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,((C_word*)t0)[3]);
t8=(C_word)C_a_i_cons(&a,2,lf[3],t7);
t9=(C_word)C_a_i_list(&a,3,lf[444],lf[445],t1);
t10=(C_word)C_a_i_list(&a,3,lf[3],C_SCHEME_END_OF_LIST,t9);
t11=(C_word)C_a_i_list(&a,2,((C_word*)t0)[6],t10);
t12=(C_word)C_a_i_list(&a,3,lf[3],t1,t11);
t13=(C_word)C_a_i_list(&a,3,lf[5],t8,t12);
t14=(C_word)C_a_i_list(&a,3,lf[3],C_SCHEME_END_OF_LIST,t13);
t15=(C_word)C_a_i_list(&a,3,lf[158],t6,t14);
t16=(C_word)C_a_i_list(&a,3,lf[3],t2,t15);
t17=(C_word)C_a_i_list(&a,2,lf[159],t16);
t18=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t18+1)))(2,t18,(C_word)C_a_i_list(&a,1,t17));}

/* k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_1331(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1331,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1334,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6033,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   ##sys#register-macro */
t4=C_retrieve(lf[390]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[443],t3);}

/* a6032 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_6033(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_6033r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6033r(t0,t1,t2,t3);}}

static void C_ccall f_6033r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6037,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 44   gensym */
t5=C_retrieve(lf[7]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k6035 in a6032 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_6037(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6037,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6040,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 44   gensym */
t3=C_retrieve(lf[7]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k6038 in k6035 in a6032 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_6040(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[56],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6040,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6042,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_a_i_list(&a,2,lf[30],lf[256]);
t4=(C_word)C_a_i_list(&a,3,lf[428],((C_word*)t0)[5],t3);
t5=(C_word)C_a_i_list(&a,3,lf[217],((C_word*)t0)[5],C_fix(1));
t6=(C_word)C_a_i_list(&a,3,lf[438],t4,t5);
t7=(C_word)C_a_i_list(&a,2,t1,t6);
t8=(C_word)C_a_i_list(&a,1,t7);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6179,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[4],a[5]=t8,tmp=(C_word)a,a+=6,tmp);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6183,a[2]=t9,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* map */
t11=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t10,t2,((C_word*)t0)[2]);}

/* k6181 in k6038 in k6035 in a6032 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_6183(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6183,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[442],((C_word*)t0)[3]);
t3=(C_word)C_a_i_list(&a,2,lf[398],t2);
t4=(C_word)C_a_i_list(&a,1,t3);
/* ##sys#append */
t5=*((C_word*)lf[414]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,((C_word*)t0)[2],t1,t4);}

/* k6177 in k6038 in k6035 in a6032 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_6179(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6179,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[440],t1);
t3=(C_word)C_a_i_list(&a,3,lf[413],((C_word*)t0)[5],t2);
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,4,lf[441],((C_word*)t0)[3],t3,((C_word*)t0)[2]));}

/* parse-clause in k6038 in k6035 in a6032 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_6042(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[34],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6042,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_symbolp(t3);
t5=(C_truep(t4)?(C_word)C_i_car(t2):C_SCHEME_FALSE);
t6=(C_truep(t5)?(C_word)C_i_cadr(t2):(C_word)C_i_car(t2));
t7=(C_truep(t5)?(C_word)C_i_cddr(t2):(C_word)C_i_cdr(t2));
if(C_truep((C_word)C_i_nullp(t6))){
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6065,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep(t5)){
t9=(C_word)C_a_i_list(&a,2,t5,((C_word*)t0)[3]);
t10=(C_word)C_a_i_list(&a,1,t9);
t11=(C_word)C_a_i_cons(&a,2,t10,t7);
t12=t8;
f_6065(t12,(C_word)C_a_i_cons(&a,2,lf[413],t11));}
else{
t9=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t7);
t10=t8;
f_6065(t10,(C_word)C_a_i_cons(&a,2,lf[413],t9));}}
else{
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6128,a[2]=t7,a[3]=((C_word*)t0)[3],a[4]=t5,a[5]=t1,a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6130,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* map */
t10=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t8,t9,t6);}}

/* a6129 in parse-clause in k6038 in k6035 in a6032 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_6130(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6130,3,t0,t1,t2);}
t3=(C_word)C_a_i_list(&a,2,lf[30],t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[439],t3,((C_word*)t0)[2]));}

/* k6126 in parse-clause in k6038 in k6035 in a6032 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_6128(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6128,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[438],t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6098,a[2]=t3,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[4])){
t5=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],((C_word*)t0)[3]);
t6=(C_word)C_a_i_list(&a,1,t5);
t7=(C_word)C_a_i_cons(&a,2,t6,((C_word*)t0)[2]);
t8=t4;
f_6098(t8,(C_word)C_a_i_cons(&a,2,lf[413],t7));}
else{
t5=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,((C_word*)t0)[2]);
t6=t4;
f_6098(t6,(C_word)C_a_i_cons(&a,2,lf[413],t5));}}

/* k6096 in k6126 in parse-clause in k6038 in k6035 in a6032 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_fcall f_6098(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6098,NULL,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[2],t1));}

/* k6063 in parse-clause in k6038 in k6035 in a6032 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_fcall f_6065(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6065,NULL,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,lf[398],t1));}

/* k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_1334(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1334,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1337,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5843,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   ##sys#register-macro */
t4=C_retrieve(lf[390]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[437],t3);}

/* a5842 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_5843(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(c<5) C_bad_min_argc_2(c,5,t0);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr5r,(void*)f_5843r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_5843r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_5843r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(8);
t6=(C_word)C_i_cdr(t3);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5850,a[2]=t6,a[3]=t5,a[4]=t1,a[5]=t4,a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* map */
t8=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,*((C_word*)lf[129]+1),t5);}

/* k5848 in a5842 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_5850(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5850,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[30],((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6022,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6024,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* map */
t5=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,t1);}

/* a6023 in k5848 in a5842 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_6024(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6024,3,t0,t1,t2);}
t3=(C_word)C_i_memq(t2,((C_word*)t0)[2]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?t2:lf[436]));}

/* k6020 in k5848 in a5842 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_6022(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[56],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6022,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[427],t2);
t4=(C_word)C_a_i_list(&a,3,lf[385],((C_word*)t0)[6],t3);
t5=(C_word)C_a_i_list(&a,2,((C_word*)t0)[5],lf[78]);
t6=(C_word)C_a_i_list(&a,2,lf[30],((C_word*)t0)[4]);
t7=(C_word)C_a_i_list(&a,3,lf[428],lf[78],t6);
t8=(C_word)C_a_i_list(&a,3,lf[385],t5,t7);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5873,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t8,tmp=(C_word)a,a+=5,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5875,a[2]=t11,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp));
t13=((C_word*)t11)[1];
f_5875(t13,t9,((C_word*)t0)[2],C_fix(1));}

/* loop in k6020 in k5848 in a5842 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_fcall f_5875(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word ab[112],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5875,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_memq(lf[429],C_retrieve(lf[18]));
t6=(C_word)C_i_cddr(t4);
t7=(C_word)C_i_pairp(t6);
t8=(C_word)C_a_i_list(&a,1,lf[78]);
t9=(C_word)C_a_i_list(&a,2,lf[30],((C_word*)t0)[3]);
t10=(C_word)C_a_i_list(&a,3,lf[430],lf[78],t9);
t11=(C_word)C_a_i_list(&a,2,lf[431],t10);
t12=(C_word)C_a_i_list(&a,3,lf[432],lf[78],t3);
t13=(C_word)C_a_i_list(&a,4,lf[3],t8,t11,t12);
t14=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5901,a[2]=t13,a[3]=t5,a[4]=t7,a[5]=t3,a[6]=((C_word*)t0)[2],a[7]=t2,a[8]=t1,a[9]=t4,tmp=(C_word)a,a+=10,tmp);
if(C_truep(t7)){
t15=(C_word)C_i_caddr(t4);
t16=(C_word)C_a_i_list(&a,3,t15,lf[78],lf[434]);
t17=(C_word)C_a_i_list(&a,2,lf[30],((C_word*)t0)[3]);
t18=(C_word)C_a_i_list(&a,3,lf[430],lf[78],t17);
t19=(C_word)C_a_i_list(&a,2,lf[431],t18);
t20=(C_word)C_a_i_list(&a,4,lf[435],lf[78],t3,lf[434]);
t21=(C_word)C_a_i_list(&a,4,lf[385],t16,t19,t20);
t22=t14;
f_5901(t22,(C_word)C_a_i_list(&a,1,t21));}
else{
t15=t14;
f_5901(t15,C_SCHEME_END_OF_LIST);}}}

/* k5899 in loop in k6020 in k5848 in a5842 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_fcall f_5901(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5901,NULL,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[9]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5929,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=t1,a[6]=((C_word*)t0)[8],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t4=(C_truep(((C_word*)t0)[4])?((C_word*)t0)[3]:C_SCHEME_FALSE);
if(C_truep(t4)){
t5=(C_word)C_i_caddr(((C_word*)t0)[9]);
t6=t3;
f_5929(t6,(C_word)C_a_i_list(&a,3,lf[433],((C_word*)t0)[2],t5));}
else{
t5=t3;
f_5929(t5,((C_word*)t0)[2]);}}

/* k5927 in k5899 in loop in k6020 in k5848 in a5842 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_fcall f_5929(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5929,NULL,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,lf[385],((C_word*)t0)[7],t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5913,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[4]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5921,a[2]=t4,a[3]=t3,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 44   add1 */
t6=*((C_word*)lf[151]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[2]);}

/* k5919 in k5927 in k5899 in loop in k6020 in k5848 in a5842 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_5921(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 44   loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_5875(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k5911 in k5927 in k5899 in loop in k6020 in k5848 in a5842 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_5913(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5913,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
/* ##sys#append */
t3=*((C_word*)lf[414]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k5871 in k6020 in k5848 in a5842 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_5873(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5873,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[403],t3));}

/* k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_1337(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1337,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1340,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5834,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   ##sys#register-macro-2 */
t4=C_retrieve(lf[417]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[425],t3);}

/* a5833 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_5834(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5834,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5838,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 44   ##sys#check-syntax */
t4=C_retrieve(lf[8]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[425],t2,lf[426]);}

/* k5836 in a5833 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_5838(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5838,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[424],((C_word*)t0)[2]));}

/* k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_1340(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1340,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1343,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5815,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   ##sys#register-macro-2 */
t4=C_retrieve(lf[417]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[422],t3);}

/* a5814 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_5815(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5815,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5819,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 44   ##sys#check-syntax */
t4=C_retrieve(lf[8]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[422],t2,lf[423]);}

/* k5817 in a5814 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_5819(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5819,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5826,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5828,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a5827 in k5817 in a5814 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_5828(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5828,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[30],t2));}

/* k5824 in k5817 in a5814 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_5826(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5826,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[313],t1));}

/* k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_1343(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1343,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1346,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5796,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   ##sys#register-macro-2 */
t4=C_retrieve(lf[417]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[420],t3);}

/* a5795 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_5796(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5796,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5800,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 44   ##sys#check-syntax */
t4=C_retrieve(lf[8]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[420],t2,lf[421]);}

/* k5798 in a5795 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_5800(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5800,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5807,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5809,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a5808 in k5798 in a5795 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_5809(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5809,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[30],t2));}

/* k5805 in k5798 in a5795 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_5807(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5807,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[313],t1));}

/* k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_1346(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1346,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1349,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5668,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   ##sys#register-macro-2 */
t4=C_retrieve(lf[417]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[419],t3);}

/* a5667 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_5668(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5668,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5674,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_5674(t6,t1,t2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_FALSE);}

/* loop in a5667 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_fcall f_5674(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word *a;
loop:
a=C_alloc(15);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5674,NULL,6,t0,t1,t2,t3,t4,t5);}
if(C_truep((C_word)C_i_nullp(t2))){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5684,a[2]=t4,a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 44   reverse */
t7=*((C_word*)lf[157]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t3);}
else{
t6=(C_word)C_i_car(t2);
t7=(C_word)C_eqp(t6,lf[415]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5755,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t4,a[5]=t3,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* csi.scm: 44   gensym */
t9=C_retrieve(lf[7]);
((C_proc2)C_retrieve_proc(t9))(2,t9,t8);}
else{
t8=(C_word)C_eqp(t6,lf[416]);
if(C_truep(t8)){
/* csi.scm: 44   loop */
t15=t1;
t16=C_SCHEME_END_OF_LIST;
t17=t3;
t18=t4;
t19=C_SCHEME_TRUE;
t1=t15;
t2=t16;
t3=t17;
t4=t18;
t5=t19;
goto loop;}
else{
t9=(C_word)C_i_cdr(t2);
t10=(C_word)C_i_car(t2);
t11=(C_word)C_a_i_cons(&a,2,t10,t4);
/* csi.scm: 44   loop */
t15=t1;
t16=t9;
t17=t3;
t18=t11;
t19=C_SCHEME_FALSE;
t1=t15;
t2=t16;
t3=t17;
t4=t18;
t5=t19;
goto loop;}}}}

/* k5753 in loop in a5667 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_5755(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5755,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[6]);
t3=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
t4=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[4]);
/* csi.scm: 44   loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_5674(t5,((C_word*)t0)[2],t2,t3,t4,C_SCHEME_FALSE);}

/* k5682 in loop in a5667 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_5684(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5684,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5687,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 44   reverse */
t3=*((C_word*)lf[157]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k5685 in k5682 in loop in a5667 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_5687(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5687,2,t0,t1);}
if(C_truep(((C_word*)t0)[4])){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5693,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 44   gensym */
t3=C_retrieve(lf[7]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}
else{
t2=(C_word)C_i_car(t1);
t3=(C_word)C_a_i_list(&a,2,lf[403],t2);
t4=(C_word)C_i_cdr(t1);
t5=(C_word)C_a_i_cons(&a,2,t3,t4);
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_list(&a,3,lf[3],((C_word*)t0)[2],t5));}}

/* k5691 in k5685 in k5682 in loop in a5667 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_5693(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5693,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5700,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* ##sys#append */
t3=*((C_word*)lf[414]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],t1);}

/* k5698 in k5691 in k5685 in k5682 in loop in a5667 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_5700(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5700,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5716,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[4]);
t5=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
/* ##sys#append */
t6=*((C_word*)lf[414]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}

/* k5714 in k5698 in k5691 in k5685 in k5682 in loop in a5667 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_5716(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5716,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[412],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[3],((C_word*)t0)[2],t3));}

/* k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_1349(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1349,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1352,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5525,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   ##sys#register-macro-2 */
t4=C_retrieve(lf[417]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[418],t3);}

/* a5524 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_5525(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5525,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5531,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_5531(t6,t1,t2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_FALSE);}

/* loop in a5524 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_fcall f_5531(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word *a;
loop:
a=C_alloc(22);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5531,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
if(C_truep((C_word)C_i_nullp(t2))){
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5541,a[2]=t5,a[3]=t4,a[4]=t1,a[5]=t6,tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 44   reverse */
t8=*((C_word*)lf[157]+1);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t3);}
else{
t7=(C_word)C_i_car(t2);
t8=(C_word)C_eqp(t7,lf[415]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5616,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t5,a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* csi.scm: 44   gensym */
t10=C_retrieve(lf[7]);
((C_proc2)C_retrieve_proc(t10))(2,t10,t9);}
else{
t9=(C_word)C_eqp(t7,lf[416]);
if(C_truep(t9)){
/* csi.scm: 44   loop */
t14=t1;
t15=C_SCHEME_END_OF_LIST;
t16=t3;
t17=t4;
t18=t5;
t19=C_SCHEME_TRUE;
t1=t14;
t2=t15;
t3=t16;
t4=t17;
t5=t18;
t6=t19;
goto loop;}
else{
t10=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5643,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t5,a[6]=t4,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* csi.scm: 44   gensym */
t11=C_retrieve(lf[7]);
((C_proc2)C_retrieve_proc(t11))(2,t11,t10);}}}}

/* k5641 in loop in a5524 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_5643(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5643,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
t3=(C_word)C_i_car(((C_word*)t0)[7]);
t4=(C_word)C_a_i_list(&a,2,t1,t3);
t5=(C_word)C_a_i_cons(&a,2,t4,((C_word*)t0)[6]);
t6=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
/* csi.scm: 44   loop */
t7=((C_word*)((C_word*)t0)[4])[1];
f_5531(t7,((C_word*)t0)[3],t2,((C_word*)t0)[2],t5,t6,C_SCHEME_FALSE);}

/* k5614 in loop in a5524 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_5616(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5616,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
t3=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[6]);
t4=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
/* csi.scm: 44   loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_5531(t5,((C_word*)t0)[3],t2,t3,((C_word*)t0)[2],t4,C_SCHEME_FALSE);}

/* k5539 in loop in a5524 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_5541(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5541,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5544,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 44   reverse */
t3=*((C_word*)lf[157]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k5542 in k5539 in loop in a5524 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_5544(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5544,2,t0,t1);}
if(C_truep(((C_word*)t0)[5])){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5550,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 44   gensym */
t3=C_retrieve(lf[7]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}
else{
t2=(C_word)C_i_car(t1);
t3=(C_word)C_i_cdr(t1);
t4=(C_word)C_a_i_cons(&a,2,t2,t3);
t5=(C_word)C_a_i_list(&a,3,lf[3],((C_word*)t0)[2],t4);
t6=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_list(&a,3,lf[413],((C_word*)t0)[3],t5));}}

/* k5548 in k5542 in k5539 in loop in a5524 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_5550(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5550,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5561,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* ##sys#append */
t3=*((C_word*)lf[414]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],t1);}

/* k5559 in k5548 in k5542 in k5539 in loop in a5524 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_5561(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5561,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5577,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[5]);
t5=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
/* ##sys#append */
t6=*((C_word*)lf[414]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}

/* k5575 in k5559 in k5548 in k5542 in k5539 in loop in a5524 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_5577(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5577,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[412],t2);
t4=(C_word)C_a_i_list(&a,3,lf[3],((C_word*)t0)[4],t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,3,lf[413],((C_word*)t0)[2],t4));}

/* k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_1352(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1352,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1355,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5466,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   ##sys#register-macro */
t4=C_retrieve(lf[390]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[411],t3);}

/* a5465 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_5466(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,...){
C_word tmp;
C_word t6;
va_list v;
C_word *a,c2=c;
C_save_rest(t5,c2,6);
if(c<6) C_bad_min_argc_2(c,6,t0);
if(!C_demand(c*C_SIZEOF_PAIR+51)){
C_save_and_reclaim((void*)tr6r,(void*)f_5466r,6,t0,t1,t2,t3,t4,t5);}
else{
a=C_alloc((c-6)*3);
t6=C_restore_rest(a,C_rest_count(0));
f_5466r(t0,t1,t2,t3,t4,t5,t6);}}

static void C_ccall f_5466r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word *a=C_alloc(51);
t7=(C_word)C_i_cddr(t2);
if(C_truep((C_word)C_i_pairp(t7))){
t8=(C_word)C_i_caddr(t2);
t9=(C_word)C_i_car(t2);
t10=(C_word)C_i_cadr(t2);
t11=(C_word)C_a_i_list(&a,3,t8,t9,t10);
t12=(C_word)C_a_i_list(&a,4,lf[408],t3,t4,t5);
t13=(C_word)C_a_i_cons(&a,2,t12,t6);
t14=(C_word)C_a_i_cons(&a,2,t11,t13);
t15=t1;
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,(C_word)C_a_i_cons(&a,2,lf[409],t14));}
else{
t8=(C_word)C_a_i_list(&a,4,lf[410],t3,t4,t5);
t9=(C_word)C_a_i_cons(&a,2,t8,t6);
t10=(C_word)C_a_i_cons(&a,2,t2,t9);
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_word)C_a_i_cons(&a,2,lf[409],t10));}}

/* k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_1355(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1355,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1358,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5295,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   ##sys#register-macro */
t4=C_retrieve(lf[390]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[405],t3);}

/* a5294 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_5295(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr3r,(void*)f_5295r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5295r(t0,t1,t2,t3);}}

static void C_ccall f_5295r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(6);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5301,a[2]=t5,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_5301(t7,t1,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,t3,C_SCHEME_FALSE);}

/* loop in a5294 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_fcall f_5301(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5301,NULL,6,t0,t1,t2,t3,t4,t5);}
if(C_truep((C_word)C_i_nullp(t4))){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5311,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t5)){
t7=(C_word)C_a_i_cons(&a,2,lf[400],t5);
t8=t6;
f_5311(t8,(C_word)C_a_i_list(&a,2,lf[397],t7));}
else{
t7=t6;
f_5311(t7,lf[401]);}}
else{
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5375,a[2]=t5,a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=t2,a[7]=t4,tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_i_pairp(t4))){
t7=(C_word)C_i_car(t4);
t8=t6;
f_5375(t8,(C_word)C_i_pairp(t7));}
else{
t7=t6;
f_5375(t7,C_SCHEME_FALSE);}}}

/* k5373 in loop in a5294 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_fcall f_5375(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5375,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5378,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* csi.scm: 44   caar */
t3=*((C_word*)lf[259]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[7]);}
else{
/* csi.scm: 44   syntax-error */
t2=C_retrieve(lf[387]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],lf[405],lf[407],((C_word*)t0)[7]);}}

/* k5376 in k5373 in loop in a5294 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_5378(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5378,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
t3=(C_word)C_eqp(lf[402],t1);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5402,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* csi.scm: 44   cdar */
t5=*((C_word*)lf[258]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[7]);}
else{
t4=(C_word)C_eqp(lf[404],t1);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5423,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[3],tmp=(C_word)a,a+=8,tmp);
/* csi.scm: 44   cdar */
t6=*((C_word*)lf[258]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[7]);}
else{
t5=(C_word)C_eqp(lf[400],t1);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5436,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t7=((C_word*)t0)[2];
t8=(C_truep(t7)?t7:C_SCHEME_END_OF_LIST);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5444,a[2]=t8,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 44   cdar */
t10=*((C_word*)lf[258]+1);
((C_proc3)C_retrieve_proc(t10))(3,t10,t9,((C_word*)t0)[7]);}
else{
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5451,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 44   caar */
t7=*((C_word*)lf[259]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[7]);}}}}

/* k5449 in k5376 in k5373 in loop in a5294 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_5451(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 44   syntax-error */
t2=C_retrieve(lf[387]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[405],lf[406],t1);}

/* k5442 in k5376 in k5373 in loop in a5294 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_5444(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 44   append */
t2=*((C_word*)lf[263]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k5434 in k5376 in k5373 in loop in a5294 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_5436(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 44   loop */
t2=((C_word*)((C_word*)t0)[6])[1];
f_5301(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k5421 in k5376 in k5373 in loop in a5294 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_5423(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5423,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[403],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[7]);
/* csi.scm: 44   loop */
t4=((C_word*)((C_word*)t0)[6])[1];
f_5301(t4,((C_word*)t0)[5],((C_word*)t0)[4],t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5400 in k5376 in k5373 in loop in a5294 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_5402(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5402,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[403],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[7]);
/* csi.scm: 44   loop */
t4=((C_word*)((C_word*)t0)[6])[1];
f_5301(t4,((C_word*)t0)[5],t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5309 in loop in a5294 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_fcall f_5311(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[63],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5311,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
t3=(C_word)C_a_i_cons(&a,2,lf[393],t2);
t4=(C_word)C_a_i_list(&a,2,lf[394],lf[395]);
t5=(C_word)C_a_i_cons(&a,2,t4,((C_word*)t0)[5]);
t6=(C_word)C_a_i_list(&a,2,lf[396],((C_word*)t0)[4]);
t7=(C_word)C_a_i_list(&a,2,lf[397],t6);
t8=(C_word)C_a_i_list(&a,2,lf[30],((C_word*)t0)[4]);
t9=(C_word)C_a_i_list(&a,2,lf[338],t8);
t10=(C_word)C_a_i_cons(&a,2,t9,((C_word*)t0)[3]);
t11=(C_word)C_a_i_cons(&a,2,t1,t10);
t12=(C_word)C_a_i_cons(&a,2,t7,t11);
t13=(C_word)C_a_i_cons(&a,2,lf[398],t12);
t14=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,(C_word)C_a_i_list(&a,4,lf[399],t3,t5,t13));}

/* k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_1358(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1358,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1361,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5244,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   ##sys#register-macro */
t4=C_retrieve(lf[390]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[392],t3);}

/* a5243 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_5244(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+39)){
C_save_and_reclaim((void*)tr3r,(void*)f_5244r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5244r(t0,t1,t2,t3);}}

static void C_ccall f_5244r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a=C_alloc(39);
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_cdr(t2);
t6=(C_word)C_a_i_cons(&a,2,t5,t3);
t7=(C_word)C_a_i_cons(&a,2,lf[3],t6);
t8=(C_word)C_a_i_list(&a,2,t4,t7);
t9=(C_word)C_a_i_list(&a,1,t8);
t10=(C_word)C_i_car(t2);
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_word)C_a_i_list(&a,3,lf[391],t9,t10));}
else{
t4=(C_word)C_a_i_cons(&a,2,t2,t3);
t5=(C_word)C_a_i_list(&a,1,t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_list(&a,3,lf[391],t5,t2));}}

/* k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_1361(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1361,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1364,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5184,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   ##sys#register-macro */
t4=C_retrieve(lf[390]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[388],t3);}

/* a5183 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_5184(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr3r,(void*)f_5184r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5184r(t0,t1,t2,t3);}}

static void C_ccall f_5184r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(10);
t4=(C_word)C_i_nullp(t3);
t5=(C_truep(t4)?lf[383]:t3);
t6=(C_word)C_i_pairp(t2);
t7=(C_truep(t6)?(C_word)C_i_car(t2):t2);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5194,a[2]=t7,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t9=(C_word)C_i_cdr(t2);
t10=(C_word)C_a_i_cons(&a,2,t9,t5);
t11=t8;
f_5194(t11,(C_word)C_a_i_cons(&a,2,lf[3],t10));}
else{
t9=t8;
f_5194(t9,(C_word)C_i_car(t5));}}

/* k5192 in a5183 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_fcall f_5194(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5194,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5197,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[2]))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5213,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 44   eval */
t4=C_retrieve(lf[63]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t1);}
else{
/* csi.scm: 44   syntax-error */
t3=C_retrieve(lf[387]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[388],lf[389],((C_word*)t0)[2]);}}

/* k5211 in k5192 in a5183 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_5213(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_5197(2,t2,(C_word)C_i_setslot(((C_word*)t0)[2],C_fix(0),t1));}

/* k5195 in k5192 in a5183 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_5197(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5197,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(C_retrieve(lf[384]))?(C_word)C_a_i_list(&a,3,lf[385],((C_word*)t0)[3],((C_word*)t0)[2]):lf[386]));}

/* k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_1364(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1364,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1367,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 44   register-feature! */
t3=C_retrieve(lf[343]);
((C_proc8)C_retrieve_proc(t3))(8,t3,t2,lf[377],lf[378],lf[379],lf[380],lf[381],lf[382]);}

/* k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_1367(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1367,2,t0,t1);}
t2=C_mutate(&lf[11],lf[12]);
t3=C_retrieve(lf[13]);
t4=C_mutate(&lf[14],lf[15]);
t5=C_set_block_item(lf[16],0,C_fix(2048));
t6=(C_word)C_a_i_cons(&a,2,lf[17],C_retrieve(lf[18]));
t7=C_mutate((C_word*)lf[18]+1,t6);
t8=C_mutate((C_word*)lf[19]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1379,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate((C_word*)lf[23]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1391,tmp=(C_word)a,a+=2,tmp));
t10=*((C_word*)lf[27]+1);
t11=*((C_word*)lf[28]+1);
t12=C_retrieve(lf[29]);
t13=C_mutate((C_word*)lf[29]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1401,a[2]=t12,tmp=(C_word)a,a+=3,tmp));
t14=C_mutate((C_word*)lf[33]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1430,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate(&lf[34],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1440,tmp=(C_word)a,a+=2,tmp));
t16=*((C_word*)lf[35]+1);
t17=C_mutate((C_word*)lf[36]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1452,a[2]=t16,tmp=(C_word)a,a+=3,tmp));
t18=C_set_block_item(lf[38],0,C_SCHEME_FALSE);
t19=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1483,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 144  make-string */
t20=*((C_word*)lf[181]+1);
((C_proc3)C_retrieve_proc(t20))(3,t20,t19,C_fix(256));}

/* k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_1483(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[50],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1483,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1502,tmp=(C_word)a,a+=2,tmp);
t3=C_mutate((C_word*)lf[42]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1550,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t4=C_SCHEME_UNDEFINED;
t5=(C_word)C_a_i_vector(&a,32,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4);
t6=C_mutate((C_word*)lf[50]+1,t5);
t7=C_set_block_item(lf[31],0,C_fix(1));
t8=C_retrieve(lf[51]);
t9=C_mutate((C_word*)lf[52]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1656,a[2]=t8,tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[32]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1695,tmp=(C_word)a,a+=2,tmp));
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1720,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t12=C_retrieve(lf[192]);
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5178,a[2]=t12,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 196  repl-prompt */
t14=C_retrieve(lf[376]);
((C_proc3)C_retrieve_proc(t14))(3,t14,t11,t13);}

/* a5177 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_5178(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5178,2,t0,t1);}
/* csi.scm: 199  sprintf */
t2=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,lf[375],C_retrieve(lf[31]));}

/* k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_1720(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1720,2,t0,t1);}
t2=C_mutate((C_word*)lf[55]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1722,tmp=(C_word)a,a+=2,tmp));
t3=C_set_block_item(lf[58],0,C_SCHEME_FALSE);
t4=C_retrieve(lf[59]);
t5=C_mutate((C_word*)lf[59]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1735,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1749,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 211  make-hash-table */
t7=C_retrieve(lf[374]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,*((C_word*)lf[113]+1));}

/* k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_1749(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word ab[38],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1749,2,t0,t1);}
t2=C_mutate(&lf[60],t1);
t3=C_retrieve(lf[61]);
t4=C_mutate((C_word*)lf[62]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1751,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=C_retrieve(lf[63]);
t6=C_retrieve(lf[64]);
t7=*((C_word*)lf[28]+1);
t8=C_retrieve(lf[65]);
t9=*((C_word*)lf[66]+1);
t10=C_retrieve(lf[67]);
t11=C_retrieve(lf[68]);
t12=*((C_word*)lf[69]+1);
t13=*((C_word*)lf[20]+1);
t14=*((C_word*)lf[70]+1);
t15=C_retrieve(lf[45]);
t16=C_retrieve(lf[71]);
t17=C_retrieve(lf[72]);
t18=*((C_word*)lf[73]+1);
t19=*((C_word*)lf[74]+1);
t20=C_mutate((C_word*)lf[75]+1,(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_1792,a[2]=t10,a[3]=t8,a[4]=t13,a[5]=t16,a[6]=t19,a[7]=t6,a[8]=t11,a[9]=t15,a[10]=t5,a[11]=t7,a[12]=t17,tmp=(C_word)a,a+=13,tmp));
t21=C_mutate((C_word*)lf[112]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2330,tmp=(C_word)a,a+=2,tmp));
t22=C_set_block_item(lf[76],0,C_fix(0));
t23=lf[101]=C_SCHEME_END_OF_LIST;;
t24=lf[104]=C_SCHEME_END_OF_LIST;;
t25=C_mutate((C_word*)lf[146]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2371,tmp=(C_word)a,a+=2,tmp));
t26=C_mutate((C_word*)lf[107]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2399,tmp=(C_word)a,a+=2,tmp));
t27=C_mutate((C_word*)lf[106]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2422,tmp=(C_word)a,a+=2,tmp));
t28=C_mutate((C_word*)lf[123]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2713,tmp=(C_word)a,a+=2,tmp));
t29=C_mutate((C_word*)lf[153]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2737,tmp=(C_word)a,a+=2,tmp));
t30=C_retrieve(lf[71]);
t31=C_retrieve(lf[161]);
t32=C_retrieve(lf[162]);
t33=C_retrieve(lf[163]);
t34=*((C_word*)lf[164]+1);
t35=C_mutate((C_word*)lf[87]+1,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2840,a[2]=t34,a[3]=t33,a[4]=t32,a[5]=t31,a[6]=t30,tmp=(C_word)a,a+=7,tmp));
t36=C_mutate((C_word*)lf[189]+1,lf[190]);
t37=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3034,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 574  make-hash-table */
t38=C_retrieve(lf[374]);
((C_proc3)C_retrieve_proc(t38))(3,t38,t37,*((C_word*)lf[113]+1));}

/* k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_3034(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3034,2,t0,t1);}
t2=C_mutate(&lf[191],t1);
t3=C_retrieve(lf[192]);
t4=C_retrieve(lf[71]);
t5=C_retrieve(lf[193]);
t6=*((C_word*)lf[69]+1);
t7=*((C_word*)lf[194]+1);
t8=*((C_word*)lf[195]+1);
t9=C_retrieve(lf[144]);
t10=C_retrieve(lf[67]);
t11=C_mutate((C_word*)lf[82]+1,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3036,a[2]=t9,a[3]=t10,a[4]=t3,a[5]=t7,a[6]=t6,a[7]=t8,a[8]=t5,tmp=(C_word)a,a+=9,tmp));
t12=C_retrieve(lf[61]);
t13=C_mutate((C_word*)lf[276]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3794,a[2]=t12,tmp=(C_word)a,a+=3,tmp));
t14=C_mutate((C_word*)lf[84]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3800,tmp=(C_word)a,a+=2,tmp));
t15=*((C_word*)lf[20]+1);
t16=*((C_word*)lf[40]+1);
t17=*((C_word*)lf[181]+1);
t18=*((C_word*)lf[282]+1);
t19=C_mutate((C_word*)lf[245]+1,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3961,a[2]=t15,a[3]=t18,a[4]=t17,a[5]=t16,tmp=(C_word)a,a+=6,tmp));
t20=C_mutate((C_word*)lf[285]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4170,tmp=(C_word)a,a+=2,tmp));
t21=C_mutate(&lf[287],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4229,tmp=(C_word)a,a+=2,tmp));
t22=C_mutate(&lf[288],lf[289]);
t23=C_mutate(&lf[290],lf[291]);
t24=C_mutate(&lf[292],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4286,tmp=(C_word)a,a+=2,tmp));
t25=C_mutate((C_word*)lf[299]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4429,tmp=(C_word)a,a+=2,tmp));
t26=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5170,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 955  run */
t27=C_retrieve(lf[299]);
((C_proc2)C_retrieve_proc(t27))(2,t27,t26);}

/* k5168 in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_5170(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5170,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5173,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5176,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#implicit-exit-handler */
t4=C_retrieve(lf[373]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k5174 in k5168 in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_5176(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k5171 in k5168 in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_5173(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* ##csi#run in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_4429(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4429,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4433,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5164,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 827  getenv */
t4=C_retrieve(lf[48]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[372]);}

/* k5162 in ##csi#run in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_5164(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?t1:lf[371]);
/* csi.scm: 827  parse-option-string */
t3=C_retrieve(lf[153]);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],t2);}

/* k4431 in ##csi#run in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_4433(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4433,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4436,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5160,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 828  command-line-arguments */
t4=C_retrieve(lf[322]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k5158 in k4431 in ##csi#run in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_5160(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 828  canonicalize-args */
f_4286(((C_word*)t0)[2],t1);}

/* k4434 in k4431 in ##csi#run in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_4436(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4436,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4439,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 829  member* */
f_4229(t4,lf[370],((C_word*)t3)[1]);}

/* k4437 in k4434 in k4431 in ##csi#run in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_4439(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4439,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4442,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 830  member* */
f_4229(t2,lf[369],((C_word*)((C_word*)t0)[4])[1]);}

/* k4440 in k4437 in k4434 in k4431 in ##csi#run in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_4442(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4442,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4445,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5053,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cdr(t1);
t5=(C_word)C_i_pairp(t4);
t6=(C_word)C_i_not(t5);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5103,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep(t6)){
t8=t7;
f_5103(t8,t6);}
else{
t8=(C_word)C_i_cadr(t1);
t9=(C_word)C_i_string_length(t8);
t10=(C_word)C_i_zerop(t9);
if(C_truep(t10)){
t11=t7;
f_5103(t11,t10);}
else{
t11=(C_word)C_i_cadr(t1);
t12=(C_word)C_i_string_ref(t11,C_fix(0));
t13=t7;
f_5103(t13,(C_word)C_eqp(C_make_character(45),t12));}}}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5143,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5156,a[2]=((C_word*)t0)[5],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 844  canonicalize-args */
f_4286(t4,((C_word*)t0)[2]);}}

/* k5154 in k4440 in k4437 in k4434 in k4431 in ##csi#run in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_5156(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 844  append */
t2=*((C_word*)lf[263]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)((C_word*)t0)[2])[1]);}

/* k5141 in k4440 in k4437 in k4434 in k4431 in ##csi#run in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_5143(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=(C_word)C_i_member(lf[368],((C_word*)((C_word*)t0)[3])[1]);
t4=((C_word*)t0)[2];
f_4445(t4,(C_truep(t3)?(C_word)C_i_set_cdr(t3,C_SCHEME_END_OF_LIST):C_SCHEME_FALSE));}

/* k5101 in k4440 in k4437 in k4434 in k4431 in ##csi#run in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_fcall f_5103(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* csi.scm: 835  ##sys#error */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],lf[367]);}
else{
t2=((C_word*)t0)[2];
f_5053(2,t2,C_SCHEME_UNDEFINED);}}

/* k5051 in k4440 in k4437 in k4434 in k4431 in ##csi#run in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_5053(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5053,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5056,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[3]);
/* csi.scm: 836  program-name */
t4=C_retrieve(lf[366]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}

/* k5054 in k5051 in k4440 in k4437 in k4434 in k4431 in ##csi#run in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_5056(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5056,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5059,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cddr(((C_word*)t0)[3]);
/* csi.scm: 837  command-line-arguments */
t4=C_retrieve(lf[322]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}

/* k5057 in k5054 in k5051 in k4440 in k4437 in k4434 in k4431 in ##csi#run in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_5059(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5059,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5062,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 838  register-feature! */
t3=C_retrieve(lf[343]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[365]);}

/* k5060 in k5057 in k5054 in k5051 in k4440 in k4437 in k4434 in k4431 in ##csi#run in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_5062(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5062,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
t3=(C_word)C_i_set_cdr(t2,C_SCHEME_END_OF_LIST);
if(C_truep(*((C_word*)lf[364]+1))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5071,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_cadr(((C_word*)t0)[3]);
/* csi.scm: 841  lookup-script-file */
t6=C_retrieve(lf[42]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}
else{
t4=((C_word*)t0)[2];
f_4445(t4,C_SCHEME_UNDEFINED);}}

/* k5069 in k5060 in k5057 in k5054 in k5051 in k4440 in k4437 in k4434 in k4431 in ##csi#run in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_5071(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
f_4445(t3,(C_word)C_i_set_car(t2,t1));}
else{
t2=((C_word*)t0)[2];
f_4445(t2,C_SCHEME_FALSE);}}

/* k4443 in k4440 in k4437 in k4434 in k4431 in ##csi#run in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_fcall f_4445(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4445,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4448,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 847  member* */
f_4229(t2,lf[363],((C_word*)((C_word*)t0)[4])[1]);}

/* k4446 in k4443 in k4440 in k4437 in k4434 in k4431 in ##csi#run in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_4448(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4448,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4451,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[5])){
t3=t2;
f_4451(t3,((C_word*)t0)[5]);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5047,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 848  member* */
f_4229(t3,lf[362],((C_word*)((C_word*)t0)[4])[1]);}}

/* k5045 in k4446 in k4443 in k4440 in k4437 in k4434 in k4431 in ##csi#run in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_5047(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_4451(t2,(C_truep(t1)?t1:((C_word*)t0)[2]));}

/* k4449 in k4446 in k4443 in k4440 in k4437 in k4434 in k4431 in ##csi#run in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_fcall f_4451(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4451,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4454,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* csi.scm: 849  member* */
f_4229(t2,lf[361],((C_word*)((C_word*)t0)[4])[1]);}

/* k4452 in k4449 in k4446 in k4443 in k4440 in k4437 in k4434 in k4431 in ##csi#run in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_4454(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4454,2,t0,t1);}
t2=(C_truep(((C_word*)t0)[7])?((C_word*)t0)[7]:(C_truep(t1)?t1:((C_word*)t0)[6]));
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4460,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5034,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5038,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 851  getenv */
t6=C_retrieve(lf[48]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,lf[360]);}

/* k5036 in k4452 in k4449 in k4446 in k4443 in k4440 in k4437 in k4434 in k4431 in ##csi#run in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_5038(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?t1:lf[358]);
/* csi.scm: 851  string-split */
t3=C_retrieve(lf[45]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[2],t2,lf[359]);}

/* k5032 in k4452 in k4449 in k4446 in k4443 in k4440 in k4437 in k4434 in k4431 in ##csi#run in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_5034(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve(lf[36]),t1);}

/* k4458 in k4452 in k4449 in k4446 in k4443 in k4440 in k4437 in k4434 in k4431 in ##csi#run in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_4460(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4460,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4462,a[2]=((C_word*)t0)[8],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4542,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4612,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=t3,a[10]=((C_word*)t0)[7],tmp=(C_word)a,a+=11,tmp);
if(C_truep(((C_word*)t0)[2])){
t5=C_set_block_item(lf[357],0,C_fix(0));
t6=t4;
f_4612(t6,t5);}
else{
t5=t4;
f_4612(t5,C_SCHEME_UNDEFINED);}}

/* k4610 in k4458 in k4452 in k4449 in k4446 in k4443 in k4440 in k4437 in k4434 in k4431 in ##csi#run in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_fcall f_4612(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4612,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4615,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5023,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 874  member* */
f_4229(t3,lf[356],((C_word*)((C_word*)t0)[6])[1]);}

/* k5021 in k4610 in k4458 in k4452 in k4449 in k4446 in k4443 in k4440 in k4437 in k4434 in k4431 in ##csi#run in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_5023(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5023,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5026,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 875  print-usage */
t3=C_retrieve(lf[19]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}
else{
t2=((C_word*)t0)[2];
f_4615(2,t2,C_SCHEME_UNDEFINED);}}

/* k5024 in k5021 in k4610 in k4458 in k4452 in k4449 in k4446 in k4443 in k4440 in k4437 in k4434 in k4431 in ##csi#run in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_5026(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 876  exit */
t2=C_retrieve(lf[77]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_fix(0));}

/* k4613 in k4610 in k4458 in k4452 in k4449 in k4446 in k4443 in k4440 in k4437 in k4434 in k4431 in ##csi#run in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_4615(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4615,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4618,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5014,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 877  member* */
f_4229(t3,lf[355],((C_word*)((C_word*)t0)[6])[1]);}

/* k5012 in k4613 in k4610 in k4458 in k4452 in k4449 in k4446 in k4443 in k4440 in k4437 in k4434 in k4431 in ##csi#run in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_5014(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5014,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5017,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 878  print-banner */
t3=C_retrieve(lf[23]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}
else{
t2=((C_word*)t0)[2];
f_4618(2,t2,C_SCHEME_UNDEFINED);}}

/* k5015 in k5012 in k4613 in k4610 in k4458 in k4452 in k4449 in k4446 in k4443 in k4440 in k4437 in k4434 in k4431 in ##csi#run in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_5017(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 879  exit */
t2=C_retrieve(lf[77]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_fix(0));}

/* k4616 in k4613 in k4610 in k4458 in k4452 in k4449 in k4446 in k4443 in k4440 in k4437 in k4434 in k4431 in ##csi#run in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_4618(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4618,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4621,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
if(C_truep((C_word)C_i_member(lf[354],((C_word*)((C_word*)t0)[6])[1]))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5004,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5011,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 881  chicken-version */
t5=C_retrieve(lf[26]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}
else{
t3=t2;
f_4621(2,t3,C_SCHEME_UNDEFINED);}}

/* k5009 in k4616 in k4613 in k4610 in k4458 in k4452 in k4449 in k4446 in k4443 in k4440 in k4437 in k4434 in k4431 in ##csi#run in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_5011(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 881  print */
t2=*((C_word*)lf[24]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k5002 in k4616 in k4613 in k4610 in k4458 in k4452 in k4449 in k4446 in k4443 in k4440 in k4437 in k4434 in k4431 in ##csi#run in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_5004(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 882  exit */
t2=C_retrieve(lf[77]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_fix(0));}

/* k4619 in k4616 in k4613 in k4610 in k4458 in k4452 in k4449 in k4446 in k4443 in k4440 in k4437 in k4434 in k4431 in ##csi#run in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_4621(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4621,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4624,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4991,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 883  member* */
f_4229(t3,lf[353],((C_word*)((C_word*)t0)[6])[1]);}

/* k4989 in k4619 in k4616 in k4613 in k4610 in k4458 in k4452 in k4449 in k4446 in k4443 in k4440 in k4437 in k4434 in k4431 in ##csi#run in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_4991(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4991,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4994,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=t2;
f_4994(2,t3,C_SCHEME_UNDEFINED);}
else{
/* csi.scm: 884  display */
t3=*((C_word*)lf[20]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[352]);}}
else{
t2=((C_word*)t0)[3];
f_4624(t2,C_SCHEME_UNDEFINED);}}

/* k4992 in k4989 in k4619 in k4616 in k4613 in k4610 in k4458 in k4452 in k4449 in k4446 in k4443 in k4440 in k4437 in k4434 in k4431 in ##csi#run in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_4994(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_set_block_item(lf[351],0,C_SCHEME_FALSE);
t3=((C_word*)t0)[2];
f_4624(t3,t2);}

/* k4622 in k4619 in k4616 in k4613 in k4610 in k4458 in k4452 in k4449 in k4446 in k4443 in k4440 in k4437 in k4434 in k4431 in ##csi#run in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_fcall f_4624(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4624,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4627,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=t2;
f_4627(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4985,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 887  load-verbose */
t4=C_retrieve(lf[350]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_TRUE);}}

/* k4983 in k4622 in k4619 in k4616 in k4613 in k4610 in k4458 in k4452 in k4449 in k4446 in k4443 in k4440 in k4437 in k4434 in k4431 in ##csi#run in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_4985(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 888  print-banner */
t2=C_retrieve(lf[23]);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k4625 in k4622 in k4619 in k4616 in k4613 in k4610 in k4458 in k4452 in k4449 in k4446 in k4443 in k4440 in k4437 in k4434 in k4431 in ##csi#run in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_4627(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4627,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4630,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4970,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 889  member* */
f_4229(t3,lf[349],((C_word*)((C_word*)t0)[6])[1]);}

/* k4968 in k4625 in k4622 in k4619 in k4616 in k4613 in k4610 in k4458 in k4452 in k4449 in k4446 in k4443 in k4440 in k4437 in k4434 in k4431 in ##csi#run in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_4970(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4970,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4973,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=t2;
f_4973(2,t3,C_SCHEME_UNDEFINED);}
else{
/* csi.scm: 890  display */
t3=*((C_word*)lf[20]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[348]);}}
else{
t2=((C_word*)t0)[3];
f_4630(2,t2,C_SCHEME_UNDEFINED);}}

/* k4971 in k4968 in k4625 in k4622 in k4619 in k4616 in k4613 in k4610 in k4458 in k4452 in k4449 in k4446 in k4443 in k4440 in k4437 in k4434 in k4431 in ##csi#run in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_4973(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4973,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4976,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 891  register-feature! */
t3=C_retrieve(lf[343]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[347]);}

/* k4974 in k4971 in k4968 in k4625 in k4622 in k4619 in k4616 in k4613 in k4610 in k4458 in k4452 in k4449 in k4446 in k4443 in k4440 in k4437 in k4434 in k4431 in ##csi#run in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_4976(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 892  case-sensitive */
t2=C_retrieve(lf[346]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k4628 in k4625 in k4622 in k4619 in k4616 in k4613 in k4610 in k4458 in k4452 in k4449 in k4446 in k4443 in k4440 in k4437 in k4434 in k4431 in ##csi#run in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_4630(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4630,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4633,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4967,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 893  collect-options */
t4=((C_word*)t0)[2];
f_4462(t4,t3,lf[345]);}

/* k4965 in k4628 in k4625 in k4622 in k4619 in k4616 in k4613 in k4610 in k4458 in k4452 in k4449 in k4446 in k4443 in k4440 in k4437 in k4434 in k4431 in ##csi#run in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_4967(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[90]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve(lf[343]),t1);}

/* k4631 in k4628 in k4625 in k4622 in k4619 in k4616 in k4613 in k4610 in k4458 in k4452 in k4449 in k4446 in k4443 in k4440 in k4437 in k4434 in k4431 in ##csi#run in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_4633(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4633,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4636,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4963,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 894  collect-options */
t4=((C_word*)t0)[2];
f_4462(t4,t3,lf[344]);}

/* k4961 in k4631 in k4628 in k4625 in k4622 in k4619 in k4616 in k4613 in k4610 in k4458 in k4452 in k4449 in k4446 in k4443 in k4440 in k4437 in k4434 in k4431 in ##csi#run in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_4963(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[90]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve(lf[343]),t1);}

/* k4634 in k4631 in k4628 in k4625 in k4622 in k4619 in k4616 in k4613 in k4610 in k4458 in k4452 in k4449 in k4446 in k4443 in k4440 in k4437 in k4434 in k4431 in ##csi#run in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_4636(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4636,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4640,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4943,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4947,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4959,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 897  collect-options */
t6=((C_word*)t0)[2];
f_4462(t6,t5,lf[342]);}

/* k4957 in k4634 in k4631 in k4628 in k4625 in k4622 in k4619 in k4616 in k4613 in k4610 in k4458 in k4452 in k4449 in k4446 in k4443 in k4440 in k4437 in k4434 in k4431 in ##csi#run in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_4959(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve(lf[36]),t1);}

/* k4945 in k4634 in k4631 in k4628 in k4625 in k4622 in k4619 in k4616 in k4613 in k4610 in k4458 in k4452 in k4449 in k4446 in k4443 in k4440 in k4437 in k4434 in k4431 in ##csi#run in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_4947(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4947,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4951,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4955,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 898  collect-options */
t4=((C_word*)t0)[2];
f_4462(t4,t3,lf[341]);}

/* k4953 in k4945 in k4634 in k4631 in k4628 in k4625 in k4622 in k4619 in k4616 in k4613 in k4610 in k4458 in k4452 in k4449 in k4446 in k4443 in k4440 in k4437 in k4434 in k4431 in ##csi#run in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_4955(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve(lf[36]),t1);}

/* k4949 in k4945 in k4634 in k4631 in k4628 in k4625 in k4622 in k4619 in k4616 in k4613 in k4610 in k4458 in k4452 in k4449 in k4446 in k4443 in k4440 in k4437 in k4434 in k4431 in ##csi#run in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_4951(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 897  append */
t2=*((C_word*)lf[263]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,C_retrieve(lf[175]),((C_word*)t0)[2]);}

/* k4941 in k4634 in k4631 in k4628 in k4625 in k4622 in k4619 in k4616 in k4613 in k4610 in k4458 in k4452 in k4449 in k4446 in k4443 in k4440 in k4437 in k4434 in k4431 in ##csi#run in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_4943(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 896  deldups */
t2=C_retrieve(lf[285]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,*((C_word*)lf[340]+1));}

/* k4638 in k4634 in k4631 in k4628 in k4625 in k4622 in k4619 in k4616 in k4613 in k4610 in k4458 in k4452 in k4449 in k4446 in k4443 in k4440 in k4437 in k4434 in k4431 in ##csi#run in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_4640(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4640,2,t0,t1);}
t2=C_mutate((C_word*)lf[175]+1,t1);
t3=(C_word)C_a_i_cons(&a,2,lf[302],C_retrieve(lf[18]));
t4=C_mutate((C_word*)lf[18]+1,t3);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4647,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* csi.scm: 903  provide */
t6=C_retrieve(lf[338]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,lf[339]);}

/* k4645 in k4638 in k4634 in k4631 in k4628 in k4625 in k4622 in k4619 in k4616 in k4613 in k4610 in k4458 in k4452 in k4449 in k4446 in k4443 in k4440 in k4437 in k4434 in k4431 in ##csi#run in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_4647(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4647,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4650,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(C_word)C_i_cdr(((C_word*)t0)[2]);
if(C_truep((C_word)C_i_pairp(t3))){
t4=(C_word)C_i_cadr(((C_word*)t0)[2]);
if(C_truep((C_word)C_i_string_equal_p(lf[330],t4))){
/* csi.scm: 908  keyword-style */
t5=C_retrieve(lf[331]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t2,lf[332]);}
else{
t5=(C_word)C_i_cadr(((C_word*)t0)[2]);
if(C_truep((C_word)C_i_string_equal_p(lf[333],t5))){
/* csi.scm: 910  keyword-style */
t6=C_retrieve(lf[331]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t2,lf[334]);}
else{
t6=(C_word)C_i_cadr(((C_word*)t0)[2]);
if(C_truep((C_word)C_i_string_equal_p(lf[335],t6))){
/* csi.scm: 912  keyword-style */
t7=C_retrieve(lf[331]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t2,lf[336]);}
else{
t7=t2;
f_4650(2,t7,C_SCHEME_UNDEFINED);}}}}
else{
/* csi.scm: 906  ##sys#error */
t4=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,lf[337]);}}
else{
t3=t2;
f_4650(2,t3,C_SCHEME_UNDEFINED);}}

/* k4648 in k4645 in k4638 in k4634 in k4631 in k4628 in k4625 in k4622 in k4619 in k4616 in k4613 in k4610 in k4458 in k4452 in k4449 in k4446 in k4443 in k4440 in k4437 in k4434 in k4431 in ##csi#run in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_4650(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4650,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4653,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4877,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 913  member* */
f_4229(t3,lf[329],((C_word*)((C_word*)t0)[2])[1]);}

/* k4875 in k4648 in k4645 in k4638 in k4634 in k4631 in k4628 in k4625 in k4622 in k4619 in k4616 in k4613 in k4610 in k4458 in k4452 in k4449 in k4446 in k4443 in k4440 in k4437 in k4434 in k4431 in ##csi#run in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_4877(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4877,2,t0,t1);}
t2=(C_truep(t1)?t1:((C_word*)t0)[3]);
if(C_truep(t2)){
t3=((C_word*)t0)[2];
f_4653(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4509,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 861  ##sys#string-append */
t4=C_retrieve(lf[327]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[328],lf[14]);}}

/* k4507 in k4875 in k4648 in k4645 in k4638 in k4634 in k4631 in k4628 in k4625 in k4622 in k4619 in k4616 in k4613 in k4610 in k4458 in k4452 in k4449 in k4446 in k4443 in k4440 in k4437 in k4434 in k4431 in ##csi#run in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_4509(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4509,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4515,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 862  file-exists? */
t3=C_retrieve(lf[39]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k4513 in k4507 in k4875 in k4648 in k4645 in k4638 in k4634 in k4631 in k4628 in k4625 in k4622 in k4619 in k4616 in k4613 in k4610 in k4458 in k4452 in k4449 in k4446 in k4443 in k4440 in k4437 in k4434 in k4431 in ##csi#run in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_4515(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4515,2,t0,t1);}
if(C_truep(t1)){
/* csi.scm: 863  load */
t2=C_retrieve(lf[91]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4521,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4537,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 864  getenv */
t4=C_retrieve(lf[48]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[326]);}}

/* k4535 in k4513 in k4507 in k4875 in k4648 in k4645 in k4638 in k4634 in k4631 in k4628 in k4625 in k4622 in k4619 in k4616 in k4613 in k4610 in k4458 in k4452 in k4449 in k4446 in k4443 in k4440 in k4437 in k4434 in k4431 in ##csi#run in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_4537(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?t1:lf[325]);
/* csi.scm: 864  chop-separator */
t3=C_retrieve(lf[36]);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],t2);}

/* k4519 in k4513 in k4507 in k4875 in k4648 in k4645 in k4638 in k4634 in k4631 in k4628 in k4625 in k4622 in k4619 in k4616 in k4613 in k4610 in k4458 in k4452 in k4449 in k4446 in k4443 in k4440 in k4437 in k4434 in k4431 in ##csi#run in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_4521(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4521,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4524,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 865  string-append */
t3=*((C_word*)lf[40]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,t1,lf[324],lf[14]);}

/* k4522 in k4519 in k4513 in k4507 in k4875 in k4648 in k4645 in k4638 in k4634 in k4631 in k4628 in k4625 in k4622 in k4619 in k4616 in k4613 in k4610 in k4458 in k4452 in k4449 in k4446 in k4443 in k4440 in k4437 in k4434 in k4431 in ##csi#run in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_4524(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4524,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4530,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 866  file-exists? */
t3=C_retrieve(lf[39]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k4528 in k4522 in k4519 in k4513 in k4507 in k4875 in k4648 in k4645 in k4638 in k4634 in k4631 in k4628 in k4625 in k4622 in k4619 in k4616 in k4613 in k4610 in k4458 in k4452 in k4449 in k4446 in k4443 in k4440 in k4437 in k4434 in k4431 in ##csi#run in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_4530(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* csi.scm: 867  load */
t2=C_retrieve(lf[91]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_4653(2,t2,C_SCHEME_UNDEFINED);}}

/* k4651 in k4648 in k4645 in k4638 in k4634 in k4631 in k4628 in k4625 in k4622 in k4619 in k4616 in k4613 in k4610 in k4458 in k4452 in k4449 in k4446 in k4443 in k4440 in k4437 in k4434 in k4431 in ##csi#run in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_4653(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4653,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4658,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_4658(t5,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* do959 in k4651 in k4648 in k4645 in k4638 in k4634 in k4631 in k4628 in k4625 in k4622 in k4619 in k4616 in k4613 in k4610 in k4458 in k4452 in k4449 in k4446 in k4443 in k4440 in k4437 in k4434 in k4431 in ##csi#run in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_fcall f_4658(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word ab[43],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4658,NULL,3,t0,t1,t2);}
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
if(C_truep((C_word)C_i_nullp(((C_word*)t3)[1]))){
if(C_truep(((C_word*)t0)[5])){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4671,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 917  repl */
t5=C_retrieve(lf[303]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}}
else{
t4=(C_word)C_i_car(((C_word*)t3)[1]);
t5=(C_word)C_i_string_length(t4);
t6=(C_word)C_i_member(t4,lf[304]);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4686,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t6)){
t8=t7;
f_4686(2,t8,t6);}
else{
if(C_truep((C_truep((C_word)C_i_equalp(t4,lf[305]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t4,lf[306]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t4,lf[307]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t4,lf[308]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t4,lf[309]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t4,lf[310]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))))))){
t8=(C_word)C_i_cdr(((C_word*)t3)[1]);
t9=C_set_block_item(t3,0,t8);
t10=t7;
f_4686(2,t10,t9);}
else{
t8=(C_word)C_i_string_equal_p(lf[311],t4);
t9=(C_truep(t8)?t8:(C_word)C_i_string_equal_p(lf[312],t4));
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4715,a[2]=t7,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4731,a[2]=t10,tmp=(C_word)a,a+=3,tmp);
t12=(C_word)C_i_cadr(((C_word*)t3)[1]);
/* csi.scm: 930  string->symbol */
t13=*((C_word*)lf[110]+1);
((C_proc3)C_retrieve_proc(t13))(3,t13,t11,t12);}
else{
t10=(C_word)C_i_string_equal_p(lf[314],t4);
t11=(C_truep(t10)?t10:(C_word)C_i_string_equal_p(lf[315],t4));
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4747,a[2]=t7,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t13=(C_word)C_i_cadr(((C_word*)t3)[1]);
/* csi.scm: 933  evalstring */
f_4542(t12,t13,C_SCHEME_END_OF_LIST);}
else{
t12=(C_word)C_i_string_equal_p(lf[316],t4);
t13=(C_truep(t12)?t12:(C_word)C_i_string_equal_p(lf[317],t4));
if(C_truep(t13)){
t14=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4767,a[2]=t7,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t15=(C_word)C_i_cadr(((C_word*)t3)[1]);
t16=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4777,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 936  evalstring */
f_4542(t14,t15,(C_word)C_a_i_list(&a,1,t16));}
else{
t14=(C_word)C_i_string_equal_p(lf[319],t4);
t15=(C_truep(t14)?t14:(C_word)C_i_string_equal_p(lf[320],t4));
if(C_truep(t15)){
t16=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4793,a[2]=t7,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t17=(C_word)C_i_cadr(((C_word*)t3)[1]);
t18=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4803,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 941  evalstring */
f_4542(t16,t17,(C_word)C_a_i_list(&a,1,t18));}
else{
t16=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4810,a[2]=((C_word*)t0)[2],a[3]=t7,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 946  load */
t17=C_retrieve(lf[91]);
((C_proc3)C_retrieve_proc(t17))(3,t17,t16,t4);}}}}}}}}

/* k4808 in do959 in k4651 in k4648 in k4645 in k4638 in k4634 in k4631 in k4628 in k4625 in k4622 in k4619 in k4616 in k4613 in k4610 in k4458 in k4452 in k4449 in k4446 in k4443 in k4440 in k4437 in k4434 in k4431 in ##csi#run in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_4810(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4810,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4816,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(C_word)C_i_car(((C_word*)t0)[2]);
t4=t2;
f_4816(t4,(C_word)C_i_string_equal_p(lf[323],t3));}
else{
t3=t2;
f_4816(t3,C_SCHEME_FALSE);}}

/* k4814 in k4808 in do959 in k4651 in k4648 in k4645 in k4638 in k4634 in k4631 in k4628 in k4625 in k4622 in k4619 in k4616 in k4613 in k4610 in k4458 in k4452 in k4449 in k4446 in k4443 in k4440 in k4437 in k4434 in k4431 in ##csi#run in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_fcall f_4816(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4816,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4821,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4831,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 948  call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}
else{
t2=((C_word*)t0)[2];
f_4686(2,t2,C_SCHEME_UNDEFINED);}}

/* a4830 in k4814 in k4808 in do959 in k4651 in k4648 in k4645 in k4638 in k4634 in k4631 in k4628 in k4625 in k4622 in k4619 in k4616 in k4613 in k4610 in k4458 in k4452 in k4449 in k4446 in k4443 in k4440 in k4437 in k4434 in k4431 in ##csi#run in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_4831(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2rv,(void*)f_4831r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_4831r(t0,t1,t2);}}

static void C_ccall f_4831r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4842,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_notvemptyp(t2))){
t4=(C_word)C_i_vector_ref(t2,C_fix(0));
t5=t3;
f_4842(t5,(C_word)C_fixnump(t4));}
else{
t4=t3;
f_4842(t4,C_SCHEME_FALSE);}}

/* k4840 in a4830 in k4814 in k4808 in do959 in k4651 in k4648 in k4645 in k4638 in k4634 in k4631 in k4628 in k4625 in k4622 in k4619 in k4616 in k4613 in k4610 in k4458 in k4452 in k4449 in k4446 in k4443 in k4440 in k4437 in k4434 in k4431 in ##csi#run in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_fcall f_4842(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?(C_word)C_i_vector_ref(((C_word*)t0)[3],C_fix(0)):C_fix(0));
/* csi.scm: 950  exit */
t3=C_retrieve(lf[77]);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],t2);}

/* a4820 in k4814 in k4808 in do959 in k4651 in k4648 in k4645 in k4638 in k4634 in k4631 in k4628 in k4625 in k4622 in k4619 in k4616 in k4613 in k4610 in k4458 in k4452 in k4449 in k4446 in k4443 in k4440 in k4437 in k4434 in k4431 in ##csi#run in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_4821(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4821,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4829,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 948  command-line-arguments */
t3=C_retrieve(lf[322]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k4827 in a4820 in k4814 in k4808 in do959 in k4651 in k4648 in k4645 in k4638 in k4634 in k4631 in k4628 in k4625 in k4622 in k4619 in k4616 in k4613 in k4610 in k4458 in k4452 in k4449 in k4446 in k4443 in k4440 in k4437 in k4434 in k4431 in ##csi#run in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_4829(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* main */
t2=C_retrieve(lf[321]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* a4802 in do959 in k4651 in k4648 in k4645 in k4638 in k4634 in k4631 in k4628 in k4625 in k4622 in k4619 in k4616 in k4613 in k4610 in k4458 in k4452 in k4449 in k4446 in k4443 in k4440 in k4437 in k4434 in k4431 in ##csi#run in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_4803(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_4803r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4803r(t0,t1,t2);}}

static void C_ccall f_4803r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_apply(5,0,t1,*((C_word*)lf[318]+1),C_retrieve(lf[72]),t2);}

/* k4791 in do959 in k4651 in k4648 in k4645 in k4638 in k4634 in k4631 in k4628 in k4625 in k4622 in k4619 in k4616 in k4613 in k4610 in k4458 in k4452 in k4449 in k4446 in k4443 in k4440 in k4437 in k4434 in k4431 in ##csi#run in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_4793(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
f_4686(2,t4,t3);}

/* a4776 in do959 in k4651 in k4648 in k4645 in k4638 in k4634 in k4631 in k4628 in k4625 in k4622 in k4619 in k4616 in k4613 in k4610 in k4458 in k4452 in k4449 in k4446 in k4443 in k4440 in k4437 in k4434 in k4431 in ##csi#run in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_4777(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_4777r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4777r(t0,t1,t2);}}

static void C_ccall f_4777r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_apply(5,0,t1,*((C_word*)lf[318]+1),*((C_word*)lf[24]+1),t2);}

/* k4765 in do959 in k4651 in k4648 in k4645 in k4638 in k4634 in k4631 in k4628 in k4625 in k4622 in k4619 in k4616 in k4613 in k4610 in k4458 in k4452 in k4449 in k4446 in k4443 in k4440 in k4437 in k4434 in k4431 in ##csi#run in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_4767(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
f_4686(2,t4,t3);}

/* k4745 in do959 in k4651 in k4648 in k4645 in k4638 in k4634 in k4631 in k4628 in k4625 in k4622 in k4619 in k4616 in k4613 in k4610 in k4458 in k4452 in k4449 in k4446 in k4443 in k4440 in k4437 in k4434 in k4431 in ##csi#run in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_4747(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
f_4686(2,t4,t3);}

/* k4729 in do959 in k4651 in k4648 in k4645 in k4638 in k4634 in k4631 in k4628 in k4625 in k4622 in k4619 in k4616 in k4613 in k4610 in k4458 in k4452 in k4449 in k4446 in k4443 in k4440 in k4437 in k4434 in k4431 in ##csi#run in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_4731(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4731,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[30],t1);
t3=(C_word)C_a_i_list(&a,2,lf[313],t2);
/* csi.scm: 930  eval */
t4=C_retrieve(lf[63]);
((C_proc3)C_retrieve_proc(t4))(3,t4,((C_word*)t0)[2],t3);}

/* k4713 in do959 in k4651 in k4648 in k4645 in k4638 in k4634 in k4631 in k4628 in k4625 in k4622 in k4619 in k4616 in k4613 in k4610 in k4458 in k4452 in k4449 in k4446 in k4443 in k4440 in k4437 in k4434 in k4431 in ##csi#run in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_4715(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
f_4686(2,t4,t3);}

/* k4684 in do959 in k4651 in k4648 in k4645 in k4638 in k4634 in k4631 in k4628 in k4625 in k4622 in k4619 in k4616 in k4613 in k4610 in k4458 in k4452 in k4449 in k4446 in k4443 in k4440 in k4437 in k4434 in k4431 in ##csi#run in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_4686(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[4])[1]);
t3=((C_word*)((C_word*)t0)[3])[1];
f_4658(t3,((C_word*)t0)[2],t2);}

/* k4669 in do959 in k4651 in k4648 in k4645 in k4638 in k4634 in k4631 in k4628 in k4625 in k4622 in k4619 in k4616 in k4613 in k4610 in k4458 in k4452 in k4449 in k4446 in k4443 in k4440 in k4437 in k4434 in k4431 in ##csi#run in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_4671(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 918  ##sys#write-char-0 */
t2=C_retrieve(lf[150]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_make_character(10),*((C_word*)lf[148]+1));}

/* evalstring in k4458 in k4452 in k4449 in k4446 in k4443 in k4440 in k4437 in k4434 in k4431 in ##csi#run in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_fcall f_4542(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4542,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4546,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_4546(2,t5,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4589,tmp=(C_word)a,a+=2,tmp));}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_4546(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[53]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* f_4589 in evalstring in k4458 in k4452 in k4449 in k4446 in k4443 in k4440 in k4437 in k4434 in k4431 in ##csi#run in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_4589(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4589,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_retrieve(lf[13]));}

/* k4544 in evalstring in k4458 in k4452 in k4449 in k4446 in k4443 in k4440 in k4437 in k4434 in k4431 in ##csi#run in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_4546(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4546,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4549,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 869  open-input-string */
t3=C_retrieve(lf[160]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k4547 in k4544 in evalstring in k4458 in k4452 in k4449 in k4446 in k4443 in k4440 in k4437 in k4434 in k4431 in ##csi#run in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_4549(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4549,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4556,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 870  read */
t3=*((C_word*)lf[28]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k4554 in k4547 in k4544 in evalstring in k4458 in k4452 in k4449 in k4446 in k4443 in k4440 in k4437 in k4434 in k4431 in ##csi#run in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_4556(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4556,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4558,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_4558(t5,((C_word*)t0)[2],t1);}

/* do945 in k4554 in k4547 in k4544 in evalstring in k4458 in k4452 in k4449 in k4446 in k4443 in k4440 in k4437 in k4434 in k4431 in ##csi#run in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_fcall f_4558(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4558,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_eofp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4568,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4579,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4581,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 872  ##sys#call-with-values */
C_call_with_values(4,0,t4,t5,*((C_word*)lf[301]+1));}}

/* a4580 in do945 in k4554 in k4547 in k4544 in evalstring in k4458 in k4452 in k4449 in k4446 in k4443 in k4440 in k4437 in k4434 in k4431 in ##csi#run in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_4581(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4581,2,t0,t1);}
/* csi.scm: 872  eval */
t2=C_retrieve(lf[63]);
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* k4577 in do945 in k4554 in k4547 in k4544 in evalstring in k4458 in k4452 in k4449 in k4446 in k4443 in k4440 in k4437 in k4434 in k4431 in ##csi#run in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_4579(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 872  rec */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k4566 in do945 in k4554 in k4547 in k4544 in evalstring in k4458 in k4452 in k4449 in k4446 in k4443 in k4440 in k4437 in k4434 in k4431 in ##csi#run in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_4568(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4568,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4575,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 870  read */
t3=*((C_word*)lf[28]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k4573 in k4566 in do945 in k4554 in k4547 in k4544 in evalstring in k4458 in k4452 in k4449 in k4446 in k4443 in k4440 in k4437 in k4434 in k4431 in ##csi#run in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_4575(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[3])[1];
f_4558(t2,((C_word*)t0)[2],t1);}

/* collect-options in k4458 in k4452 in k4449 in k4446 in k4443 in k4440 in k4437 in k4434 in k4431 in ##csi#run in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_fcall f_4462(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4462,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4468,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_4468(t6,t1,((C_word*)((C_word*)t0)[2])[1]);}

/* loop in collect-options in k4458 in k4452 in k4449 in k4446 in k4443 in k4440 in k4437 in k4434 in k4431 in ##csi#run in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_fcall f_4468(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4468,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_member(((C_word*)t0)[3],t2);
if(C_truep(t3)){
t4=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t4))){
/* csi.scm: 857  ##sys#error */
t5=*((C_word*)lf[53]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,lf[300],((C_word*)t0)[3]);}
else{
t5=(C_word)C_i_cadr(t3);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4495,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_i_cddr(t3);
/* csi.scm: 858  loop */
t9=t6;
t10=t7;
t1=t9;
t2=t10;
goto loop;}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}}

/* k4493 in loop in collect-options in k4458 in k4452 in k4449 in k4446 in k4443 in k4440 in k4437 in k4434 in k4431 in ##csi#run in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_4495(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4495,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* canonicalize-args in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_fcall f_4286(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4286,NULL,2,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4292,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_4292(t6,t1,t2);}

/* loop in canonicalize-args in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_fcall f_4292(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4292,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_i_car(t2);
if(C_truep((C_truep((C_word)C_i_equalp(t3,lf[293]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t3,lf[294]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t3,lf[295]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t3,lf[296]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4314,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_block_size(t3);
if(C_truep((C_word)C_fixnum_greaterp(t5,C_fix(2)))){
t6=(C_word)C_eqp(C_make_character(45),(C_word)C_subchar(t3,C_fix(0)));
if(C_truep(t6)){
t7=(C_word)C_i_member(t3,lf[291]);
t8=t4;
f_4314(t8,(C_word)C_i_not(t7));}
else{
t7=t4;
f_4314(t7,C_SCHEME_FALSE);}}
else{
t6=t4;
f_4314(t6,C_SCHEME_FALSE);}}}}

/* k4312 in loop in canonicalize-args in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_fcall f_4314(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4314,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_eqp(C_make_character(58),(C_word)C_subchar(((C_word*)t0)[5],C_fix(1)));
if(C_truep(t2)){
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* csi.scm: 813  loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_4292(t4,((C_word*)t0)[2],t3);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4330,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4364,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 814  substring */
t5=*((C_word*)lf[35]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[5],C_fix(1));}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4371,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* csi.scm: 818  loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_4292(t4,t2,t3);}}

/* k4369 in k4312 in loop in canonicalize-args in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_4371(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4371,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k4362 in k4312 in loop in canonicalize-args in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_4364(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* string->list */
t2=C_retrieve(lf[298]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4328 in k4312 in loop in canonicalize-args in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_4330(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4330,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4403,tmp=(C_word)a,a+=2,tmp);
t4=f_4403(t2);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4343,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4353,tmp=(C_word)a,a+=2,tmp);
/* map */
t7=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,t1);}
else{
/* csi.scm: 817  ##sys#error */
t5=*((C_word*)lf[53]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,((C_word*)t0)[5],lf[297],((C_word*)t0)[2]);}}

/* a4352 in k4328 in k4312 in loop in canonicalize-args in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_4353(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4353,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_string(&a,2,C_make_character(45),t2));}

/* k4341 in k4328 in k4312 in loop in canonicalize-args in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_4343(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4343,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4347,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* csi.scm: 816  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_4292(t4,t2,t3);}

/* k4345 in k4341 in k4328 in k4312 in loop in canonicalize-args in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_4347(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 816  append */
t2=*((C_word*)lf[263]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* loop in k4328 in k4312 in loop in canonicalize-args in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static C_word C_fcall f_4403(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
loop:
C_stack_check;
t2=(C_word)C_i_nullp(t1);
if(C_truep(t2)){
return(t2);}
else{
t3=(C_word)C_i_car(t1);
if(C_truep((C_truep((C_word)C_eqp(t3,C_make_character(107)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(115)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(118)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(104)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(68)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(101)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(105)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(82)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(98)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(110)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(113)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(119)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(45)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(73)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(112)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(80)))?C_SCHEME_TRUE:C_SCHEME_FALSE)))))))))))))))))){
t4=(C_word)C_i_cdr(t1);
t6=t4;
t1=t6;
goto loop;}
else{
return(C_SCHEME_FALSE);}}}

/* member* in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_fcall f_4229(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4229,NULL,3,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4235,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_4235(t7,t1,t3);}

/* loop in member* in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_fcall f_4235(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4235,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4247,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_4247(t6,t1,((C_word*)t0)[2]);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* find in loop in member* in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_fcall f_4247(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
loop:
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4247,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* csi.scm: 788  loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_4235(t4,t1,t3);}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_car(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_equalp(t3,t4))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,((C_word*)t0)[4]);}
else{
t5=(C_word)C_i_cdr(t2);
/* csi.scm: 790  find */
t8=t1;
t9=t5;
t1=t8;
t2=t9;
goto loop;}}}

/* ##csi#deldups in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_4170(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_4170r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4170r(t0,t1,t2,t3);}}

static void C_ccall f_4170r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4174,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_4174(2,t5,*((C_word*)lf[286]+1));}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_4174(2,t6,(C_word)C_i_car(t3));}
else{
/* csi.scm: 776  ##sys#error */
t6=*((C_word*)lf[53]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k4172 in ##csi#deldups in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_4174(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4174,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4179,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_4179(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* recur in k4172 in ##csi#deldups in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_fcall f_4179(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4179,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4195,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4208,a[2]=t5,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 781  del */
t7=C_retrieve(lf[112]);
((C_proc5)C_retrieve_proc(t7))(5,t7,t6,t3,t4,((C_word*)t0)[2]);}}

/* k4206 in recur in k4172 in ##csi#deldups in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_4208(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 781  recur */
t2=((C_word*)((C_word*)t0)[3])[1];
f_4179(t2,((C_word*)t0)[2],t1);}

/* k4193 in recur in k4172 in ##csi#deldups in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_4195(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4195,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[5],t1);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?((C_word*)t0)[3]:(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1)));}

/* ##csi#hexdump in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_3961(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[16],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_3961,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3964,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3993,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=t4,a[6]=((C_word*)t0)[3],a[7]=t5,a[8]=t8,a[9]=t3,tmp=(C_word)a,a+=10,tmp));
t10=((C_word*)t8)[1];
f_3993(t10,t1,C_fix(0));}

/* do811 in ##csi#hexdump in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_fcall f_3993(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3993,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[9]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4003,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[7],a[9]=t1,a[10]=((C_word*)t0)[8],a[11]=t2,tmp=(C_word)a,a+=12,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4168,a[2]=((C_word*)t0)[7],a[3]=t3,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 749  justify */
t5=((C_word*)t0)[2];
f_3964(t5,t4,t2,C_fix(4),C_fix(10),C_make_character(32));}}

/* k4166 in do811 in ##csi#hexdump in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_4168(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 749  display */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4001 in do811 in ##csi#hexdump in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_4003(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4003,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4006,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
/* csi.scm: 750  write-char */
t3=((C_word*)t0)[6];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_make_character(58),((C_word*)t0)[8]);}

/* k4004 in k4001 in do811 in ##csi#hexdump in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_4006(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4006,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4009,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4078,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[2],a[6]=t4,a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[3],a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp));
t6=((C_word*)t4)[1];
f_4078(t6,t2,C_fix(0),((C_word*)t0)[11]);}

/* do821 in k4004 in k4001 in do811 in ##csi#hexdump in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_fcall f_4078(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4078,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_fixnum_greater_or_equal_p(t2,C_fix(16));
t5=(C_truep(t4)?t4:(C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[9]));
if(C_truep(t5)){
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[9]))){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4097,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 755  fxmod */
t7=*((C_word*)lf[284]+1);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,((C_word*)t0)[9],C_fix(16));}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}
else{
t6=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4139,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=t1,a[8]=((C_word*)t0)[6],a[9]=t3,a[10]=t2,tmp=(C_word)a,a+=11,tmp);
/* csi.scm: 760  write-char */
t7=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,C_make_character(32),((C_word*)t0)[7]);}}

/* k4137 in do821 in k4004 in k4001 in do811 in ##csi#hexdump in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_4139(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4139,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4142,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4157,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4161,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 761  ref */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[2],((C_word*)t0)[9]);}

/* k4159 in k4137 in do821 in k4004 in k4001 in do811 in ##csi#hexdump in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_4161(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 761  justify */
t2=((C_word*)t0)[3];
f_3964(t2,((C_word*)t0)[2],t1,C_fix(2),C_fix(16),C_make_character(48));}

/* k4155 in k4137 in do821 in k4004 in k4001 in do811 in ##csi#hexdump in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_4157(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 761  display */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4140 in k4137 in do821 in k4004 in k4001 in do811 in ##csi#hexdump in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_4142(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_4078(t4,((C_word*)t0)[2],t2,t3);}

/* k4095 in do821 in k4004 in k4001 in do811 in ##csi#hexdump in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_4097(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4097,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_eqp(t1,C_fix(0));
if(C_truep(t2)){
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=(C_word)C_fixnum_difference(C_fix(16),t1);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4115,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t5,tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_4115(t7,((C_word*)t0)[4],t3);}}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* do828 in k4095 in do821 in k4004 in k4001 in do811 in ##csi#hexdump in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_fcall f_4115(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4115,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4125,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 759  display */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,lf[283],((C_word*)t0)[2]);}}

/* k4123 in do828 in k4095 in do821 in k4004 in k4001 in do811 in ##csi#hexdump in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_4125(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_difference(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4115(t3,((C_word*)t0)[2],t2);}

/* k4007 in k4004 in k4001 in do811 in ##csi#hexdump in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_4009(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4009,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4012,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* csi.scm: 762  write-char */
t3=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_make_character(32),((C_word*)t0)[6]);}

/* k4010 in k4007 in k4004 in k4001 in do811 in ##csi#hexdump in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_4012(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4012,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4015,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4027,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],a[6]=t4,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp));
t6=((C_word*)t4)[1];
f_4027(t6,t2,C_fix(0),((C_word*)t0)[9]);}

/* do836 in k4010 in k4007 in k4004 in k4001 in do811 in ##csi#hexdump in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_fcall f_4027(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4027,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_fixnum_greater_or_equal_p(t2,C_fix(16));
t5=(C_truep(t4)?t4:(C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[7]));
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}
else{
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4040,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[6],a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* csi.scm: 766  ref */
t7=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,((C_word*)t0)[2],t3);}}

/* k4038 in do836 in k4010 in k4007 in k4004 in k4001 in do811 in ##csi#hexdump in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_4040(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4040,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4043,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_fixnum_greater_or_equal_p(t1,C_fix(32));
t4=(C_truep(t3)?(C_word)C_fixnum_lessp(t1,C_fix(128)):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=(C_word)C_make_character((C_word)C_unfix(t1));
/* csi.scm: 768  write-char */
t6=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t6))(4,t6,t2,t5,((C_word*)t0)[2]);}
else{
/* csi.scm: 769  write-char */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t2,C_make_character(46),((C_word*)t0)[2]);}}

/* k4041 in k4038 in do836 in k4010 in k4007 in k4004 in k4001 in do811 in ##csi#hexdump in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_4043(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_4027(t4,((C_word*)t0)[2],t2,t3);}

/* k4013 in k4010 in k4007 in k4004 in k4001 in do811 in ##csi#hexdump in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_4015(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4015,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4018,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 770  ##sys#write-char-0 */
t3=C_retrieve(lf[150]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_make_character(10),((C_word*)t0)[2]);}

/* k4016 in k4013 in k4010 in k4007 in k4004 in k4001 in do811 in ##csi#hexdump in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_4018(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(16));
t3=((C_word*)((C_word*)t0)[3])[1];
f_3993(t3,((C_word*)t0)[2],t2);}

/* justify in ##csi#hexdump in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_fcall f_3964(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3964,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3968,a[2]=t5,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* csi.scm: 741  number->string */
C_number_to_string(4,0,t6,t2,t4);}

/* k3966 in justify in ##csi#hexdump in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_3968(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3968,2,t0,t1);}
t2=(C_word)C_block_size(t1);
if(C_truep((C_word)C_fixnum_lessp(t2,((C_word*)t0)[6]))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3984,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_fixnum_difference(((C_word*)t0)[6],t2);
/* csi.scm: 744  make-string */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t4,((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}}

/* k3982 in k3966 in justify in ##csi#hexdump in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_3984(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 744  string-append */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* ##csi#dump in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_3800(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr3r,(void*)f_3800r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3800r(t0,t1,t2,t3);}}

static void C_ccall f_3800r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(9);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3802,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3908,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3913,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-len786798 */
t7=t6;
f_3913(t7,t1);}
else{
t7=(C_word)C_i_car(t3);
t8=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t8))){
/* def-out787796 */
t9=t5;
f_3908(t9,t1,t7);}
else{
t9=(C_word)C_i_car(t8);
t10=(C_word)C_i_cdr(t8);
if(C_truep((C_word)C_i_nullp(t10))){
/* body784789 */
t11=t4;
f_3802(t11,t1,t7,t9);}
else{
/* ##sys#error */
t11=*((C_word*)lf[53]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t1,lf[0],t10);}}}}

/* def-len786 in ##csi#dump in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_fcall f_3913(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3913,NULL,2,t0,t1);}
/* def-out787796 */
t2=((C_word*)t0)[2];
f_3908(t2,t1,C_SCHEME_FALSE);}

/* def-out787 in ##csi#dump in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_fcall f_3908(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3908,NULL,3,t0,t1,t2);}
/* body784789 */
t3=((C_word*)t0)[2];
f_3802(t3,t1,t2,*((C_word*)lf[148]+1));}

/* body784 in ##csi#dump in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_fcall f_3802(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3802,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3805,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_immp(((C_word*)t0)[2]))){
/* csi.scm: 723  ##sys#error */
t5=*((C_word*)lf[53]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,lf[278],lf[279],((C_word*)t0)[2]);}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3827,a[2]=t4,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 724  ##sys#bytevector? */
t6=*((C_word*)lf[269]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[2]);}}

/* k3825 in body784 in ##csi#dump in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_3827(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3827,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3834,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[4]);
/* csi.scm: 724  bestlen */
t4=((C_word*)t0)[2];
f_3805(t4,t2,t3);}
else{
if(C_truep((C_word)C_i_stringp(((C_word*)t0)[4]))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3851,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[4]);
/* csi.scm: 725  bestlen */
t4=((C_word*)t0)[2];
f_3805(t4,t2,t3);}
else{
t2=(C_word)C_immp(((C_word*)t0)[4]);
t3=(C_truep(t2)?C_SCHEME_FALSE:(C_word)C_pointerp(((C_word*)t0)[4]));
if(C_truep(t3)){
/* csi.scm: 727  hexdump */
t4=C_retrieve(lf[245]);
((C_proc6)C_retrieve_proc(t4))(6,t4,((C_word*)t0)[5],((C_word*)t0)[4],C_fix(32),*((C_word*)lf[280]+1),((C_word*)t0)[3]);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3870,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_structurep(((C_word*)t0)[4]))){
t5=(C_word)C_slot(((C_word*)t0)[4],C_fix(0));
t6=t4;
f_3870(t6,(C_word)C_i_assq(t5,C_retrieve(lf[189])));}
else{
t5=t4;
f_3870(t5,C_SCHEME_FALSE);}}}}}

/* k3868 in k3825 in body784 in ##csi#dump in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_fcall f_3870(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3870,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3880,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_block_size(t2);
/* csi.scm: 730  bestlen */
t5=((C_word*)t0)[2];
f_3805(t5,t3,t4);}
else{
/* csi.scm: 731  ##sys#error */
t2=*((C_word*)lf[53]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],lf[278],lf[281],((C_word*)t0)[5]);}}

/* k3878 in k3868 in k3825 in body784 in ##csi#dump in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_3880(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 730  hexdump */
t2=C_retrieve(lf[245]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,*((C_word*)lf[246]+1),((C_word*)t0)[2]);}

/* k3849 in k3825 in body784 in ##csi#dump in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_3851(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 725  hexdump */
t2=C_retrieve(lf[245]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,*((C_word*)lf[246]+1),((C_word*)t0)[2]);}

/* k3832 in k3825 in body784 in ##csi#dump in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_3834(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 724  hexdump */
t2=C_retrieve(lf[245]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,*((C_word*)lf[246]+1),((C_word*)t0)[2]);}

/* bestlen in body784 in ##csi#dump in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_fcall f_3805(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3805,NULL,3,t0,t1,t2);}
if(C_truep(((C_word*)t0)[2])){
/* csi.scm: 722  min */
t3=*((C_word*)lf[277]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,((C_word*)t0)[2],t2);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* set-describer! in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_3794(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3794,4,t0,t1,t2,t3);}
/* csi.scm: 712  hash-table-set! */
t4=((C_word*)t0)[2];
((C_proc5)C_retrieve_proc(t4))(5,t4,t1,C_retrieve2(lf[191],"describer-table"),t2,t3);}

/* ##csi#describe in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_3036(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+11)){
C_save_and_reclaim((void*)tr3r,(void*)f_3036r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3036r(t0,t1,t2,t3);}}

static void C_ccall f_3036r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(11);
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3040,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=t2,a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_3040(2,t5,*((C_word*)lf[148]+1));}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_3040(2,t6,(C_word)C_i_car(t3));}
else{
/* csi.scm: 586  ##sys#error */
t6=*((C_word*)lf[53]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k3038 in ##csi#describe in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_3040(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3040,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3042,a[2]=((C_word*)t0)[9],a[3]=t1,a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3168,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t2,a[9]=t1,a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[9],a[12]=((C_word*)t0)[8],tmp=(C_word)a,a+=13,tmp);
if(C_truep((C_word)C_permanentp(((C_word*)t0)[9]))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3773,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 610  ##sys#block-address */
t5=C_retrieve(lf[275]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[9]);}
else{
t4=t3;
f_3168(2,t4,C_SCHEME_UNDEFINED);}}

/* k3771 in k3038 in ##csi#describe in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_3773(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 610  fprintf */
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[274],t1);}

/* k3166 in k3038 in ##csi#describe in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_3168(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3168,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3171,a[2]=((C_word*)t0)[12],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_charp(((C_word*)t0)[11]))){
t3=(C_word)C_fix((C_word)C_character_code(((C_word*)t0)[11]));
/* csi.scm: 613  fprintf */
t4=((C_word*)t0)[10];
((C_proc8)C_retrieve_proc(t4))(8,t4,t2,((C_word*)t0)[9],lf[203],((C_word*)t0)[11],t3,t3,t3);}
else{
switch(((C_word*)t0)[11]){
case C_SCHEME_TRUE:
/* csi.scm: 614  fprintf */
t3=((C_word*)t0)[10];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[9],lf[204]);
case C_SCHEME_FALSE:
/* csi.scm: 615  fprintf */
t3=((C_word*)t0)[10];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[9],lf[205]);
default:
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[11]))){
/* csi.scm: 616  fprintf */
t3=((C_word*)t0)[10];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[9],lf[206]);}
else{
if(C_truep((C_word)C_eofp(((C_word*)t0)[11]))){
/* csi.scm: 617  fprintf */
t3=((C_word*)t0)[10];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[9],lf[207]);}
else{
t3=C_retrieve(lf[13]);
t4=(C_word)C_eqp(t3,((C_word*)t0)[11]);
if(C_truep(t4)){
/* csi.scm: 618  fprintf */
t5=((C_word*)t0)[10];
((C_proc4)C_retrieve_proc(t5))(4,t5,t2,((C_word*)t0)[9],lf[208]);}
else{
if(C_truep((C_word)C_fixnump(((C_word*)t0)[11]))){
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3237,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=t2,a[5]=((C_word*)t0)[11],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 620  fprintf */
t6=((C_word*)t0)[10];
((C_proc8)C_retrieve_proc(t6))(8,t6,t5,((C_word*)t0)[9],lf[210],((C_word*)t0)[11],((C_word*)t0)[11],((C_word*)t0)[11],((C_word*)t0)[11]);}
else{
t5=(C_word)C_slot(lf[211],C_fix(0));
t6=(C_word)C_eqp(((C_word*)t0)[11],t5);
if(C_truep(t6)){
/* csi.scm: 625  fprintf */
t7=((C_word*)t0)[10];
((C_proc4)C_retrieve_proc(t7))(4,t7,t2,((C_word*)t0)[9],lf[212]);}
else{
t7=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3267,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[9],a[11]=t2,a[12]=((C_word*)t0)[10],tmp=(C_word)a,a+=13,tmp);
/* csi.scm: 626  ##sys#number? */
t8=C_retrieve(lf[273]);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,((C_word*)t0)[11]);}}}}}}}}

/* k3265 in k3166 in k3038 in ##csi#describe in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_3267(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3267,2,t0,t1);}
if(C_truep(t1)){
/* csi.scm: 626  fprintf */
t2=((C_word*)t0)[12];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[11],((C_word*)t0)[10],lf[213],((C_word*)t0)[9]);}
else{
if(C_truep((C_word)C_i_stringp(((C_word*)t0)[9]))){
/* csi.scm: 627  descseq */
t2=((C_word*)t0)[8];
f_3042(6,t2,((C_word*)t0)[11],lf[214],*((C_word*)lf[215]+1),((C_word*)t0)[7],C_fix(0));}
else{
if(C_truep((C_word)C_i_vectorp(((C_word*)t0)[9]))){
/* csi.scm: 628  descseq */
t2=((C_word*)t0)[8];
f_3042(6,t2,((C_word*)t0)[11],lf[216],*((C_word*)lf[215]+1),*((C_word*)lf[217]+1),C_fix(0));}
else{
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[9]))){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3297,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[12],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3330,a[2]=((C_word*)t0)[10],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 630  ##sys#symbol-has-toplevel-binding? */
t4=C_retrieve(lf[222]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[9]);}
else{
if(C_truep((C_word)C_i_listp(((C_word*)t0)[9]))){
/* csi.scm: 634  descseq */
t2=((C_word*)t0)[8];
f_3042(6,t2,((C_word*)t0)[11],lf[223],((C_word*)t0)[6],((C_word*)t0)[5],C_fix(0));}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[9]))){
t2=(C_word)C_i_car(((C_word*)t0)[9]);
t3=(C_word)C_i_cdr(((C_word*)t0)[9]);
/* csi.scm: 635  fprintf */
t4=((C_word*)t0)[12];
((C_proc6)C_retrieve_proc(t4))(6,t4,((C_word*)t0)[11],((C_word*)t0)[10],lf[224],t2,t3);}
else{
if(C_truep((C_word)C_i_closurep(((C_word*)t0)[9]))){
t2=(C_word)C_block_size(((C_word*)t0)[9]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3374,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[11],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_greaterp(t2,C_fix(3)))){
if(C_truep((C_word)C_i_memq(lf[228],C_retrieve(lf[18])))){
t4=(C_word)C_fixnum_difference(t2,C_fix(1));
t5=(C_word)C_slot(((C_word*)t0)[9],t4);
t6=t3;
f_3374(t6,(C_word)C_eqp(C_retrieve(lf[229]),t5));}
else{
t4=t3;
f_3374(t4,C_SCHEME_FALSE);}}
else{
t4=t3;
f_3374(t4,C_SCHEME_FALSE);}}
else{
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3414,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[12],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
/* csi.scm: 645  port? */
t3=C_retrieve(lf[272]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[9]);}}}}}}}}

/* k3412 in k3265 in k3166 in k3038 in ##csi#describe in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_3414(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3414,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
t3=(C_truep(t2)?lf[230]:lf[231]);
t4=(C_word)C_slot(((C_word*)t0)[8],C_fix(7));
t5=(C_word)C_slot(((C_word*)t0)[8],C_fix(3));
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3433,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* csi.scm: 651  ##sys#peek-unsigned-integer */
t7=C_retrieve(lf[227]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,((C_word*)t0)[8],C_fix(0));}
else{
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3442,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_i_memq(lf[228],C_retrieve(lf[18])))){
/* csi.scm: 652  instance? */
t3=C_retrieve(lf[271]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[8]);}
else{
t3=t2;
f_3442(2,t3,C_SCHEME_FALSE);}}}

/* k3440 in k3412 in k3265 in k3166 in k3038 in ##csi#describe in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_3442(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3442,2,t0,t1);}
if(C_truep(t1)){
/* csi.scm: 653  describe-object */
t2=C_retrieve(lf[225]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6]);}
else{
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3451,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* csi.scm: 654  ##sys#locative? */
t3=C_retrieve(lf[270]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[7]);}}

/* k3449 in k3440 in k3412 in k3265 in k3166 in k3038 in ##csi#describe in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_3451(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3451,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3458,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 656  ##sys#peek-unsigned-integer */
t3=C_retrieve(lf[227]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[8],C_fix(0));}
else{
if(C_truep((C_word)C_pointerp(((C_word*)t0)[8]))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3539,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 669  ##sys#peek-unsigned-integer */
t3=C_retrieve(lf[227]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[8],C_fix(0));}
else{
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3545,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* csi.scm: 670  ##sys#bytevector? */
t3=*((C_word*)lf[269]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[8]);}}}

/* k3543 in k3449 in k3440 in k3412 in k3265 in k3166 in k3038 in ##csi#describe in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_3545(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[32],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3545,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_block_size(((C_word*)t0)[8]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3551,a[2]=((C_word*)t0)[6],a[3]=t2,a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 672  fprintf */
t4=((C_word*)t0)[5];
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[6],lf[247],t2);}
else{
if(C_truep((C_word)C_lambdainfop(((C_word*)t0)[8]))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3564,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 675  ##sys#lambda-info->string */
t3=C_retrieve(lf[249]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[8]);}
else{
if(C_truep((C_word)C_i_structurep(((C_word*)t0)[8],lf[250]))){
t2=(C_word)C_slot(((C_word*)t0)[8],C_fix(2));
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3576,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_eqp(t2,C_fix(1));
t5=(C_truep(t4)?lf[253]:lf[254]);
t6=(C_word)C_slot(((C_word*)t0)[8],C_fix(3));
/* csi.scm: 678  fprintf */
t7=((C_word*)t0)[5];
((C_proc7)C_retrieve_proc(t7))(7,t7,t3,((C_word*)t0)[6],lf[255],t2,t5,t6);}
else{
if(C_truep((C_word)C_i_structurep(((C_word*)t0)[8],lf[256]))){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3612,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
/* csi.scm: 685  fprintf */
t4=((C_word*)t0)[5];
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,((C_word*)t0)[6],lf[261],t3);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3679,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_i_structurep(((C_word*)t0)[8],lf[266]))){
/* csi.scm: 695  provided? */
t3=C_retrieve(lf[267]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[268]);}
else{
t3=t2;
f_3679(2,t3,C_SCHEME_FALSE);}}}}}}

/* k3677 in k3543 in k3449 in k3440 in k3412 in k3265 in k3166 in k3038 in ##csi#describe in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_3679(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3679,2,t0,t1);}
if(C_truep(t1)){
/* csi.scm: 696  unveil */
t2=C_retrieve(lf[262]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5]);}
else{
if(C_truep((C_word)C_structurep(((C_word*)t0)[6]))){
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(0));
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3694,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* csi.scm: 699  hash-table-ref/default */
t4=((C_word*)t0)[2];
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,C_retrieve2(lf[191],"describer-table"),t2,C_SCHEME_FALSE);}
else{
/* csi.scm: 706  fprintf */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[7],((C_word*)t0)[5],lf[265]);}}}

/* k3692 in k3677 in k3543 in k3449 in k3440 in k3412 in k3265 in k3166 in k3038 in ##csi#describe in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_3694(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3694,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3701,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[5],t1);}
else{
t2=(C_word)C_i_assq(((C_word*)t0)[4],C_retrieve(lf[189]));
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3718,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3722,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_i_cdr(t2);
/* map */
t6=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,C_retrieve(lf[63]),t5);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3733,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_slot(((C_word*)t0)[7],C_fix(0));
/* csi.scm: 704  fprintf */
t5=((C_word*)t0)[2];
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,((C_word*)t0)[6],lf[264],t4);}}}

/* k3731 in k3692 in k3677 in k3543 in k3449 in k3440 in k3412 in k3265 in k3166 in k3038 in ##csi#describe in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_3733(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 705  descseq */
t2=((C_word*)t0)[3];
f_3042(6,t2,((C_word*)t0)[2],C_SCHEME_FALSE,*((C_word*)lf[215]+1),*((C_word*)lf[217]+1),C_fix(1));}

/* k3720 in k3692 in k3677 in k3543 in k3449 in k3440 in k3412 in k3265 in k3166 in k3038 in ##csi#describe in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_3722(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3722,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,C_fix(0));
/* csi.scm: 702  append */
t3=*((C_word*)lf[263]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[2],t1,t2);}

/* k3716 in k3692 in k3677 in k3543 in k3449 in k3440 in k3412 in k3265 in k3166 in k3038 in ##csi#describe in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_3718(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* f_3701 in k3692 in k3677 in k3543 in k3449 in k3440 in k3412 in k3265 in k3166 in k3038 in ##csi#describe in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_3701(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3701,3,t0,t1,t2);}
/* g769770 */
t3=t2;
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3610 in k3543 in k3449 in k3440 in k3412 in k3265 in k3166 in k3038 in ##csi#describe in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_3612(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3612,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3617,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* for-each */
t4=*((C_word*)lf[90]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[2],t2,t3);}

/* a3616 in k3610 in k3543 in k3449 in k3440 in k3412 in k3265 in k3166 in k3038 in ##csi#describe in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_3617(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3617,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3621,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* csi.scm: 688  fprintf */
t4=((C_word*)t0)[3];
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[2],lf[260],t2);}

/* k3619 in a3616 in k3610 in k3543 in k3449 in k3440 in k3412 in k3265 in k3166 in k3038 in ##csi#describe in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_3621(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3621,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(2));
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3630,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t4,tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_3630(t6,((C_word*)t0)[2],t2);}

/* loop in k3619 in a3616 in k3610 in k3543 in k3449 in k3440 in k3412 in k3265 in k3166 in k3038 in ##csi#describe in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_fcall f_3630(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3630,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3640,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3665,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* csi.scm: 691  caar */
t5=*((C_word*)lf[259]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}}

/* k3663 in loop in k3619 in a3616 in k3610 in k3543 in k3449 in k3440 in k3412 in k3265 in k3166 in k3038 in ##csi#describe in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_3665(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3665,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[6],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3657,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 692  cdar */
t4=*((C_word*)lf[258]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[5]);}
else{
t3=((C_word*)t0)[3];
f_3640(2,t3,C_SCHEME_UNDEFINED);}}

/* k3655 in k3663 in loop in k3619 in a3616 in k3610 in k3543 in k3449 in k3440 in k3412 in k3265 in k3166 in k3038 in ##csi#describe in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_3657(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* csi.scm: 692  fprintf */
t3=((C_word*)t0)[4];
((C_proc6)C_retrieve_proc(t3))(6,t3,((C_word*)t0)[3],((C_word*)t0)[2],lf[257],t1,t2);}

/* k3638 in loop in k3619 in a3616 in k3610 in k3543 in k3449 in k3440 in k3412 in k3265 in k3166 in k3038 in ##csi#describe in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_3640(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cddr(((C_word*)t0)[4]);
/* csi.scm: 693  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_3630(t3,((C_word*)t0)[2],t2);}

/* k3574 in k3543 in k3449 in k3440 in k3412 in k3265 in k3166 in k3038 in ##csi#describe in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_3576(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3576,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3579,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_slot(((C_word*)t0)[2],C_fix(4));
/* csi.scm: 680  fprintf */
t4=((C_word*)t0)[6];
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,((C_word*)t0)[5],lf[252],t3);}

/* k3577 in k3574 in k3543 in k3449 in k3440 in k3412 in k3265 in k3166 in k3038 in ##csi#describe in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_3579(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3579,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3584,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 681  hash-table-walk */
t3=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* a3583 in k3577 in k3574 in k3543 in k3449 in k3440 in k3412 in k3265 in k3166 in k3038 in ##csi#describe in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_3584(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3584,4,t0,t1,t2,t3);}
/* csi.scm: 683  fprintf */
t4=((C_word*)t0)[3];
((C_proc6)C_retrieve_proc(t4))(6,t4,t1,((C_word*)t0)[2],lf[251],t2,t3);}

/* k3562 in k3543 in k3449 in k3440 in k3412 in k3265 in k3166 in k3038 in ##csi#describe in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_3564(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 675  fprintf */
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[248],t1);}

/* k3549 in k3543 in k3449 in k3440 in k3412 in k3265 in k3166 in k3038 in ##csi#describe in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_3551(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 673  hexdump */
t2=C_retrieve(lf[245]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],*((C_word*)lf[246]+1),((C_word*)t0)[2]);}

/* k3537 in k3449 in k3440 in k3412 in k3265 in k3166 in k3038 in ##csi#describe in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_3539(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 669  fprintf */
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[244],t1);}

/* k3456 in k3449 in k3440 in k3412 in k3265 in k3166 in k3038 in ##csi#describe in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_3458(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3458,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_slot(((C_word*)t0)[5],C_fix(2));
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3469,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
switch(t3){
case C_fix(0):
t5=t4;
f_3469(t5,lf[234]);
case C_fix(1):
t5=t4;
f_3469(t5,lf[235]);
case C_fix(2):
t5=t4;
f_3469(t5,lf[236]);
case C_fix(3):
t5=t4;
f_3469(t5,lf[237]);
case C_fix(4):
t5=t4;
f_3469(t5,lf[238]);
case C_fix(5):
t5=t4;
f_3469(t5,lf[239]);
case C_fix(6):
t5=t4;
f_3469(t5,lf[240]);
case C_fix(7):
t5=t4;
f_3469(t5,lf[241]);
case C_fix(8):
t5=t4;
f_3469(t5,lf[242]);
default:
t5=(C_word)C_eqp(t3,C_fix(9));
t6=t4;
f_3469(t6,(C_truep(t5)?lf[243]:C_SCHEME_UNDEFINED));}}

/* k3467 in k3456 in k3449 in k3440 in k3412 in k3265 in k3166 in k3038 in ##csi#describe in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_fcall f_3469(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 655  fprintf */
t2=((C_word*)t0)[6];
((C_proc7)C_retrieve_proc(t2))(7,t2,((C_word*)t0)[5],((C_word*)t0)[4],lf[233],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3431 in k3412 in k3265 in k3166 in k3038 in ##csi#describe in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_3433(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 646  fprintf */
t2=((C_word*)t0)[7];
((C_proc8)C_retrieve_proc(t2))(8,t2,((C_word*)t0)[6],((C_word*)t0)[5],lf[232],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3372 in k3265 in k3166 in k3038 in ##csi#describe in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_fcall f_3374(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3374,NULL,2,t0,t1);}
if(C_truep(t1)){
/* csi.scm: 641  describe-object */
t2=C_retrieve(lf[225]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3384,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3388,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 643  ##sys#peek-unsigned-integer */
t4=C_retrieve(lf[227]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[5],C_fix(0));}}

/* k3386 in k3372 in k3265 in k3166 in k3038 in ##csi#describe in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_3388(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 643  sprintf */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[226],t1);}

/* k3382 in k3372 in k3265 in k3166 in k3038 in ##csi#describe in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_3384(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 642  descseq */
t2=((C_word*)t0)[3];
f_3042(6,t2,((C_word*)t0)[2],t1,*((C_word*)lf[215]+1),*((C_word*)lf[217]+1),C_fix(1));}

/* k3328 in k3265 in k3166 in k3038 in ##csi#describe in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_3330(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_3297(2,t2,C_SCHEME_UNDEFINED);}
else{
/* csi.scm: 630  display */
t2=*((C_word*)lf[20]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],lf[221],((C_word*)t0)[2]);}}

/* k3295 in k3265 in k3166 in k3038 in ##csi#describe in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_3297(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3297,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3300,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3310,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[2]))){
t4=(C_word)C_slot(((C_word*)t0)[2],C_fix(1));
t5=(C_word)C_subbyte(t4,C_fix(0));
t6=t3;
f_3310(t6,(C_word)C_eqp(C_fix(0),t5));}
else{
t4=t3;
f_3310(t4,C_SCHEME_FALSE);}}

/* k3308 in k3295 in k3265 in k3166 in k3038 in ##csi#describe in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_fcall f_3310(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* csi.scm: 632  display */
t2=*((C_word*)lf[20]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],lf[220],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_3300(2,t2,C_SCHEME_UNDEFINED);}}

/* k3298 in k3295 in k3265 in k3166 in k3038 in ##csi#describe in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_3300(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3300,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3307,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 633  ##sys#symbol->string */
t3=C_retrieve(lf[219]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k3305 in k3298 in k3295 in k3265 in k3166 in k3038 in ##csi#describe in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_3307(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 633  fprintf */
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[218],t1);}

/* k3235 in k3166 in k3038 in ##csi#describe in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_3237(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3237,2,t0,t1);}
t2=(C_word)C_make_character((C_word)C_unfix(((C_word*)t0)[5]));
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3243,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(65536)))){
/* csi.scm: 622  fprintf */
t4=((C_word*)t0)[3];
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[2],lf[209],t2);}
else{
t4=t3;
f_3243(2,t4,C_SCHEME_UNDEFINED);}}

/* k3241 in k3235 in k3166 in k3038 in ##csi#describe in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_3243(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 623  ##sys#write-char-0 */
t2=C_retrieve(lf[150]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_make_character(10),*((C_word*)lf[148]+1));}

/* k3169 in k3166 in k3038 in ##csi#describe in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_3171(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_retrieve(lf[13]));}

/* descseq in k3038 in ##csi#describe in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_3042(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_3042,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3165,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t4,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=t5,tmp=(C_word)a,a+=9,tmp);
/* csi.scm: 589  plen */
t7=t3;
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[2]);}

/* k3163 in descseq in k3038 in ##csi#describe in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_3165(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3165,2,t0,t1);}
t2=(C_word)C_fixnum_difference(t1,((C_word*)t0)[8]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3049,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)t0)[2])){
/* csi.scm: 590  fprintf */
t4=((C_word*)t0)[7];
((C_proc6)C_retrieve_proc(t4))(6,t4,t3,((C_word*)t0)[6],lf[202],((C_word*)t0)[2],t2);}
else{
t4=t3;
f_3049(2,t4,C_SCHEME_UNDEFINED);}}

/* k3047 in k3163 in descseq in k3038 in ##csi#describe in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_3049(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3049,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3054,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp));
t5=((C_word*)t3)[1];
f_3054(t5,((C_word*)t0)[2],C_fix(0));}

/* loop1 in k3047 in k3163 in descseq in k3038 in ##csi#describe in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_fcall f_3054(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3054,NULL,3,t0,t1,t2);}
t3=(C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[8]);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,C_fix(40)))){
t4=(C_word)C_fixnum_difference(((C_word*)t0)[8],t2);
/* csi.scm: 594  fprintf */
t5=((C_word*)t0)[7];
((C_proc5)C_retrieve_proc(t5))(5,t5,t1,((C_word*)t0)[6],lf[196],t4);}
else{
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3077,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[8],a[9]=t2,a[10]=((C_word*)t0)[5],tmp=(C_word)a,a+=11,tmp);
t5=(C_word)C_fixnum_plus(((C_word*)t0)[5],t2);
/* csi.scm: 596  pref */
t6=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,((C_word*)t0)[2],t5);}}}

/* k3075 in loop1 in k3047 in k3163 in descseq in k3038 in ##csi#describe in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_3077(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3077,2,t0,t1);}
t2=(C_word)C_fixnum_plus(((C_word*)t0)[10],C_fix(1));
t3=(C_word)C_fixnum_plus(((C_word*)t0)[9],t2);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3086,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t5,a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp));
t7=((C_word*)t5)[1];
f_3086(t7,((C_word*)t0)[2],C_fix(1),t3);}

/* loop2 in k3075 in loop1 in k3047 in k3163 in descseq in k3038 in ##csi#describe in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_fcall f_3086(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3086,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[10]))){
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3096,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t1,a[5]=((C_word*)t0)[8],a[6]=t2,a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
/* csi.scm: 599  fprintf */
t5=((C_word*)t0)[7];
((C_proc6)C_retrieve_proc(t5))(6,t5,t4,((C_word*)t0)[6],lf[201],((C_word*)t0)[9],((C_word*)t0)[5]);}
else{
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3150,a[2]=((C_word*)t0)[10],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=t2,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
/* csi.scm: 606  pref */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[2],t3);}}

/* k3148 in loop2 in k3075 in loop1 in k3047 in k3163 in descseq in k3038 in ##csi#describe in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_3150(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_eqp(((C_word*)t0)[7],t1);
if(C_truep(t2)){
t3=(C_word)C_fixnum_plus(((C_word*)t0)[6],C_fix(1));
t4=(C_word)C_fixnum_plus(((C_word*)t0)[5],C_fix(1));
/* csi.scm: 606  loop2 */
t5=((C_word*)((C_word*)t0)[4])[1];
f_3086(t5,((C_word*)t0)[3],t3,t4);}
else{
/* csi.scm: 607  loop2 */
t3=((C_word*)((C_word*)t0)[4])[1];
f_3086(t3,((C_word*)t0)[3],((C_word*)t0)[6],((C_word*)t0)[2]);}}

/* k3094 in loop2 in k3075 in loop1 in k3047 in k3163 in descseq in k3038 in ##csi#describe in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_3096(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3096,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3099,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_greaterp(((C_word*)t0)[6],C_fix(1)))){
t3=(C_word)C_fixnum_difference(((C_word*)t0)[6],C_fix(1));
t4=(C_word)C_eqp(((C_word*)t0)[6],C_fix(2));
t5=(C_truep(t4)?lf[197]:lf[198]);
/* csi.scm: 601  fprintf */
t6=((C_word*)t0)[3];
((C_proc6)C_retrieve_proc(t6))(6,t6,t2,((C_word*)t0)[2],lf[199],t3,t5);}
else{
/* csi.scm: 604  newline */
t3=*((C_word*)lf[200]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}}

/* k3097 in k3094 in loop2 in k3075 in loop1 in k3047 in k3163 in descseq in k3038 in ##csi#describe in k3032 in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_3099(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[5],((C_word*)t0)[4]);
/* csi.scm: 605  loop1 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_3054(t3,((C_word*)t0)[2],t2);}

/* ##csi#report in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_2840(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr2rv,(void*)f_2840r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_2840r(t0,t1,t2);}}

static void C_ccall f_2840r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(7);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2848,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_notvemptyp(t2))){
t4=t3;
f_2848(2,t4,(C_word)C_i_vector_ref(t2,C_fix(0)));}
else{
/* csi.scm: 514  current-output-port */
t4=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}}

/* k2846 in ##csi#report in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_2848(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2848,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2850,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 514  with-output-to-port */
t3=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[2],t1,t2);}

/* a2849 in k2846 in ##csi#report in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_2850(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2850,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2854,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 516  gc */
t3=C_retrieve(lf[188]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k2852 in a2849 in k2846 in ##csi#report in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_2854(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2854,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2857,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 517  ##sys#symbol-table-info */
t3=C_retrieve(lf[187]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k2855 in k2852 in a2849 in k2846 in ##csi#report in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_2857(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2857,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2860,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* csi.scm: 518  memory-statistics */
t3=C_retrieve(lf[186]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k2858 in k2855 in k2852 in a2849 in k2846 in ##csi#report in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_2860(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2860,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2862,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2877,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=t1,a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
/* csi.scm: 520  printf */
t4=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[185]);}

/* k2875 in k2858 in k2855 in k2852 in a2849 in k2846 in ##csi#report in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_2877(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2877,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2880,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2979,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3012,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3016,a[2]=t4,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3020,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* map */
t7=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,C_retrieve(lf[184]),C_retrieve(lf[18]));}

/* k3018 in k2875 in k2858 in k2855 in k2852 in a2849 in k2846 in ##csi#report in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_3020(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 528  sort */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,*((C_word*)lf[183]+1));}

/* k3014 in k2875 in k2858 in k2855 in k2852 in a2849 in k2846 in ##csi#report in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_3016(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 528  chop */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_fix(5));}

/* k3010 in k2875 in k2858 in k2855 in k2852 in a2849 in k2846 in ##csi#report in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_3012(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[90]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2978 in k2875 in k2858 in k2855 in k2852 in a2849 in k2846 in ##csi#report in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_2979(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2979,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2983,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 523  display */
t4=*((C_word*)lf[20]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[182]);}

/* k2981 in a2978 in k2875 in k2858 in k2855 in k2852 in a2849 in k2846 in ##csi#report in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_2983(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2983,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2988,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* for-each */
t3=*((C_word*)lf[90]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a2987 in k2981 in a2978 in k2875 in k2858 in k2855 in k2852 in a2849 in k2846 in ##csi#report in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_2988(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2988,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2996,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_string_length(t2);
t5=(C_word)C_fixnum_difference(C_fix(16),t4);
t6=(C_word)C_i_fixnum_max(C_fix(1),t5);
/* csi.scm: 526  make-string */
t7=*((C_word*)lf[181]+1);
((C_proc4)C_retrieve_proc(t7))(4,t7,t3,t6,C_make_character(32));}

/* k2994 in a2987 in k2981 in a2978 in k2875 in k2858 in k2855 in k2852 in a2849 in k2846 in ##csi#report in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_2996(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 526  printf */
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[180],((C_word*)t0)[2],t1);}

/* k2878 in k2875 in k2858 in k2855 in k2852 in a2849 in k2846 in ##csi#report in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_2880(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2880,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2883,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2908,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* csi.scm: 540  machine-type */
t4=C_retrieve(lf[179]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k2906 in k2878 in k2875 in k2858 in k2855 in k2852 in a2849 in k2846 in ##csi#report in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_2908(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2908,2,t0,t1);}
t2=(C_word)C_fudge(C_fix(3));
t3=(C_truep(t2)?lf[168]:lf[169]);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2916,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
/* csi.scm: 542  software-type */
t5=C_retrieve(lf[178]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k2914 in k2906 in k2878 in k2875 in k2858 in k2855 in k2852 in a2849 in k2846 in ##csi#report in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_2916(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2916,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2920,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* csi.scm: 543  software-version */
t3=C_retrieve(lf[177]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k2918 in k2914 in k2906 in k2878 in k2875 in k2858 in k2855 in k2852 in a2849 in k2846 in ##csi#report in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_2920(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2920,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2924,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* csi.scm: 544  build-platform */
t3=C_retrieve(lf[176]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k2922 in k2918 in k2914 in k2906 in k2878 in k2875 in k2858 in k2855 in k2852 in a2849 in k2846 in ##csi#report in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_2924(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2924,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2928,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
t3=(C_word)C_i_vector_ref(((C_word*)t0)[10],C_fix(0));
/* csi.scm: 546  shorten */
f_2862(t2,t3);}

/* k2926 in k2922 in k2918 in k2914 in k2906 in k2878 in k2875 in k2858 in k2855 in k2852 in a2849 in k2846 in ##csi#report in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_2928(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2928,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2932,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
t3=(C_word)C_i_vector_ref(((C_word*)t0)[11],C_fix(1));
/* csi.scm: 547  shorten */
f_2862(t2,t3);}

/* k2930 in k2926 in k2922 in k2918 in k2914 in k2906 in k2878 in k2875 in k2858 in k2855 in k2852 in a2849 in k2846 in ##csi#report in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_2932(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
t2=(C_word)C_i_vector_ref(((C_word*)t0)[11],C_fix(2));
t3=(C_word)C_i_vector_ref(((C_word*)t0)[10],C_fix(0));
t4=(C_word)C_fudge(C_fix(17));
t5=(C_truep(t4)?lf[170]:lf[171]);
t6=(C_word)C_i_vector_ref(((C_word*)t0)[10],C_fix(1));
t7=(C_word)C_i_vector_ref(((C_word*)t0)[10],C_fix(2));
t8=(C_word)C_fudge(C_fix(18));
t9=(C_word)C_i_nequalp(C_fix(1),t8);
t10=(C_truep(t9)?lf[172]:lf[173]);
/* csi.scm: 529  printf */
t11=((C_word*)t0)[9];
((C_proc17)C_retrieve_proc(t11))(17,t11,((C_word*)t0)[8],lf[174],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],C_retrieve(lf[175]),((C_word*)t0)[2],t1,t2,t3,t5,t6,t7,t10);}

/* k2881 in k2878 in k2875 in k2858 in k2855 in k2852 in a2849 in k2846 in ##csi#report in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_2883(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2883,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2886,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 554  ##sys#write-char-0 */
t3=C_retrieve(lf[150]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_make_character(10),*((C_word*)lf[148]+1));}

/* k2884 in k2881 in k2878 in k2875 in k2858 in k2855 in k2852 in a2849 in k2846 in ##csi#report in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_2886(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2886,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2889,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_fudge(C_fix(14)))){
/* csi.scm: 555  display */
t3=*((C_word*)lf[20]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[167]);}
else{
t3=t2;
f_2889(2,t3,C_SCHEME_UNDEFINED);}}

/* k2887 in k2884 in k2881 in k2878 in k2875 in k2858 in k2855 in k2852 in a2849 in k2846 in ##csi#report in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_2889(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2889,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2892,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_fudge(C_fix(15)))){
/* csi.scm: 556  display */
t3=*((C_word*)lf[20]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[166]);}
else{
t3=t2;
f_2892(2,t3,C_SCHEME_UNDEFINED);}}

/* k2890 in k2887 in k2884 in k2881 in k2878 in k2875 in k2858 in k2855 in k2852 in a2849 in k2846 in ##csi#report in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_2892(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* shorten in k2858 in k2855 in k2852 in a2849 in k2846 in ##csi#report in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_fcall f_2862(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2862,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2870,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_a_i_times(&a,2,t2,C_fix(100));
/* csi.scm: 519  truncate */
t5=*((C_word*)lf[165]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* k2868 in shorten in k2858 in k2855 in k2852 in a2849 in k2846 in ##csi#report in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_2870(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2870,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_divide(&a,2,t1,C_fix(100)));}

/* ##csi#parse-option-string in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_2737(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2737,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2741,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 492  open-input-string */
t4=C_retrieve(lf[160]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k2739 in ##csi#parse-option-string in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_2741(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2741,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2746,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2766,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2769,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2771,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 499  call-with-current-continuation */
t6=*((C_word*)lf[159]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}

/* a2770 in k2739 in ##csi#parse-option-string in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_2771(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2771,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2777,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2789,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 499  with-exception-handler */
t5=C_retrieve(lf[158]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t3,t4);}

/* a2788 in a2770 in k2739 in ##csi#parse-option-string in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_2789(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2789,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2795,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2828,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 499  ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a2827 in a2788 in a2770 in k2739 in ##csi#parse-option-string in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_2828(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_2828r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2828r(t0,t1,t2);}}

static void C_ccall f_2828r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2834,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 499  g679 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a2833 in a2827 in a2788 in a2770 in k2739 in ##csi#parse-option-string in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_2834(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2834,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a2794 in a2788 in a2770 in k2739 in ##csi#parse-option-string in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_2795(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2795,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2803,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 500  read */
t3=*((C_word*)lf[28]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k2801 in a2794 in a2788 in a2770 in k2739 in ##csi#parse-option-string in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_2803(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2803,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2805,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_2805(t5,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* do683 in k2801 in a2794 in a2788 in a2770 in k2739 in ##csi#parse-option-string in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_fcall f_2805(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2805,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_eofp(t2))){
/* csi.scm: 502  reverse */
t4=*((C_word*)lf[157]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2822,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 500  read */
t5=*((C_word*)lf[28]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[2]);}}

/* k2820 in do683 in k2801 in a2794 in a2788 in a2770 in k2739 in ##csi#parse-option-string in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_2822(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2822,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[4]);
t3=((C_word*)((C_word*)t0)[3])[1];
f_2805(t3,((C_word*)t0)[2],t1,t2);}

/* a2776 in a2770 in k2739 in ##csi#parse-option-string in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_2777(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2777,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2783,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 499  g679 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a2782 in a2776 in a2770 in k2739 in ##csi#parse-option-string in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_2783(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2783,2,t0,t1);}
/* csi.scm: 499  ##sys#error */
t2=*((C_word*)lf[53]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[156],((C_word*)t0)[2]);}

/* k2767 in k2739 in ##csi#parse-option-string in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_2769(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k2764 in k2739 in ##csi#parse-option-string in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_2766(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2745 in k2739 in ##csi#parse-option-string in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_2746(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2746,3,t0,t1,t2);}
if(C_truep((C_word)C_i_stringp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2756,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 496  open-output-string */
t4=C_retrieve(lf[155]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}}

/* k2754 in a2745 in k2739 in ##csi#parse-option-string in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_2756(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2756,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2759,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 497  write */
t3=*((C_word*)lf[70]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],t1);}

/* k2757 in k2754 in a2745 in k2739 in ##csi#parse-option-string in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_2759(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 498  get-output-string */
t2=C_retrieve(lf[154]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* do-unbreak-all in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_2713(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2713,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2717,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2723,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[90]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_retrieve2(lf[104],"broken-procedures"));}

/* a2722 in do-unbreak-all in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_2723(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2723,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_i_setslot(t3,C_fix(0),t4));}

/* k2715 in do-unbreak-all in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_2717(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=lf[104]=C_SCHEME_END_OF_LIST;;
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_retrieve(lf[13]));}

/* ##csi#traced-procedure-exit in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_2422(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2422,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2427,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 396  sub1 */
t5=*((C_word*)lf[37]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,C_retrieve(lf[76]));}

/* k2425 in ##csi#traced-procedure-exit in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_2427(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2427,2,t0,t1);}
t2=C_mutate((C_word*)lf[76]+1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2430,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 397  trace-indent */
t4=C_retrieve(lf[146]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k2428 in k2425 in ##csi#traced-procedure-exit in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_2430(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2430,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2433,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 398  write */
t3=*((C_word*)lf[70]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k2431 in k2428 in k2425 in ##csi#traced-procedure-exit in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_2433(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2433,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2436,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 399  display */
t3=*((C_word*)lf[20]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[152]);}

/* k2434 in k2431 in k2428 in k2425 in ##csi#traced-procedure-exit in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_2436(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2436,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2439,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2447,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[90]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a2446 in k2434 in k2431 in k2428 in k2425 in ##csi#traced-procedure-exit in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_2447(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2447,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2451,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 402  write */
t4=*((C_word*)lf[70]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k2449 in a2446 in k2434 in k2431 in k2428 in k2425 in ##csi#traced-procedure-exit in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_2451(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* write-char/port */
t2=C_retrieve(lf[147]);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_make_character(32),*((C_word*)lf[148]+1));}

/* k2437 in k2434 in k2431 in k2428 in k2425 in ##csi#traced-procedure-exit in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_2439(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2439,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2442,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 405  ##sys#write-char-0 */
t3=C_retrieve(lf[150]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_make_character(10),*((C_word*)lf[148]+1));}

/* k2440 in k2437 in k2434 in k2431 in k2428 in k2425 in ##csi#traced-procedure-exit in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_2442(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 406  flush-output */
t2=*((C_word*)lf[149]+1);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* ##csi#traced-procedure-entry in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_2399(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2399,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2403,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 388  trace-indent */
t5=C_retrieve(lf[146]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k2401 in ##csi#traced-procedure-entry in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_2403(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2403,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2407,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 389  add1 */
t3=*((C_word*)lf[151]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_retrieve(lf[76]));}

/* k2405 in k2401 in ##csi#traced-procedure-entry in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_2407(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2407,2,t0,t1);}
t2=C_mutate((C_word*)lf[76]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2410,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]);
/* csi.scm: 390  write */
t5=*((C_word*)lf[70]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* k2408 in k2405 in k2401 in ##csi#traced-procedure-entry in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_2410(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2410,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2413,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 391  ##sys#write-char-0 */
t3=C_retrieve(lf[150]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_make_character(10),*((C_word*)lf[148]+1));}

/* k2411 in k2408 in k2405 in k2401 in ##csi#traced-procedure-entry in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_2413(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 392  flush-output */
t2=*((C_word*)lf[149]+1);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* ##csi#trace-indent in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_2371(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2371,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2375,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* write-char/port */
t3=C_retrieve(lf[147]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(124),*((C_word*)lf[148]+1));}

/* k2373 in ##csi#trace-indent in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_2375(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2375,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2380,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_2380(t5,((C_word*)t0)[2],C_retrieve(lf[76]));}

/* do617 in k2373 in ##csi#trace-indent in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_fcall f_2380(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2380,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_less_or_equalp(t2,C_fix(0)))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2390,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* write-char/port */
t4=C_retrieve(lf[147]);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_make_character(32),*((C_word*)lf[148]+1));}}

/* k2388 in do617 in k2373 in ##csi#trace-indent in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_2390(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2390,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2397,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 382  sub1 */
t3=*((C_word*)lf[37]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k2395 in k2388 in do617 in k2373 in ##csi#trace-indent in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_2397(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[3])[1];
f_2380(t2,((C_word*)t0)[2],t1);}

/* ##csi#del in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_2330(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2330,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2336,a[2]=t2,a[3]=t4,a[4]=t6,tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_2336(t8,t1,t3);}

/* loop in ##csi#del in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_fcall f_2336(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2336,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2352,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 371  tst */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[2],t3);}}

/* k2350 in loop in ##csi#del in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_2352(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2352,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_cdr(((C_word*)t0)[4]));}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2362,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* csi.scm: 373  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_2336(t4,t2,t3);}}

/* k2360 in k2350 in loop in ##csi#del in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_2362(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2362,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* ##sys#repl-eval-hook in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_1792(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1792,3,t0,t1,t2);}
t3=C_set_block_item(lf[76],0,C_fix(0));
if(C_truep((C_word)C_eofp(t2))){
/* csi.scm: 239  exit */
t4=C_retrieve(lf[77]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t1);}
else{
t4=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_1809,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=t1,a[14]=t2,tmp=(C_word)a,a+=15,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t5=(C_word)C_slot(t2,C_fix(0));
t6=t4;
f_1809(t6,(C_word)C_eqp(lf[145],t5));}
else{
t5=t4;
f_1809(t5,C_SCHEME_FALSE);}}}

/* k1807 in ##sys#repl-eval-hook in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_fcall f_1809(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1809,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[14]);
t3=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_1815,a[2]=((C_word*)t0)[14],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=t2,a[15]=((C_word*)t0)[13],tmp=(C_word)a,a+=16,tmp);
if(C_truep((C_word)C_i_symbolp(t2))){
/* csi.scm: 243  hash-table-ref/default */
t4=C_retrieve(lf[144]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,C_retrieve2(lf[60],"command-table"),t2,C_SCHEME_FALSE);}
else{
t4=t3;
f_1815(2,t4,C_SCHEME_FALSE);}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2305,a[2]=((C_word*)t0)[14],a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2311,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 359  ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[13],t2,t3);}}

/* a2310 in k1807 in ##sys#repl-eval-hook in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_2311(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_2311r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2311r(t0,t1,t2);}}

static void C_ccall f_2311r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2315,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 360  history-add */
t4=C_retrieve(lf[52]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k2313 in a2310 in k1807 in ##sys#repl-eval-hook in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_2315(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a2304 in k1807 in ##sys#repl-eval-hook in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_2305(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2305,2,t0,t1);}
/* csi.scm: 359  eval */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* k1813 in k1807 in ##sys#repl-eval-hook in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_1815(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word ab[123],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1815,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1821,a[2]=((C_word*)t0)[15],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(t1);
t4=t3;
((C_proc2)C_retrieve_proc(t4))(2,t4,t2);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[14],lf[78]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1836,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[15],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 250  read */
t4=((C_word*)t0)[12];
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[14],lf[80]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1855,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[15],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 254  read */
t5=((C_word*)t0)[12];
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[14],lf[81]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1873,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[15],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 259  read */
t6=((C_word*)t0)[12];
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[14],lf[83]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1888,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[15],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 263  read */
t7=((C_word*)t0)[12];
((C_proc2)C_retrieve_proc(t7))(2,t7,t6);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[14],lf[85]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1903,a[2]=((C_word*)t0)[12],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[15],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 267  read */
t8=((C_word*)t0)[12];
((C_proc2)C_retrieve_proc(t8))(2,t8,t7);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[14],lf[86]);
if(C_truep(t7)){
/* csi.scm: 272  report */
t8=C_retrieve(lf[87]);
((C_proc2)C_retrieve_proc(t8))(2,t8,((C_word*)t0)[15]);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[14],lf[88]);
if(C_truep(t8)){
/* csi.scm: 273  exit */
t9=C_retrieve(lf[77]);
((C_proc2)C_retrieve_proc(t9))(2,t9,((C_word*)t0)[15]);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[14],lf[89]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1942,a[2]=((C_word*)t0)[15],tmp=(C_word)a,a+=3,tmp);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1952,a[2]=t10,a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 275  read-line */
t12=((C_word*)t0)[9];
((C_proc2)C_retrieve_proc(t12))(2,t12,t11);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[14],lf[92]);
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1961,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[15],tmp=(C_word)a,a+=5,tmp);
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1986,a[2]=t11,a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 279  read-line */
t13=((C_word*)t0)[9];
((C_proc2)C_retrieve_proc(t13))(2,t13,t12);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[14],lf[96]);
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1995,a[2]=((C_word*)t0)[15],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[11],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 283  read */
t13=((C_word*)t0)[12];
((C_proc2)C_retrieve_proc(t13))(2,t13,t12);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[14],lf[100]);
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2048,a[2]=((C_word*)t0)[15],tmp=(C_word)a,a+=3,tmp);
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2052,a[2]=t13,tmp=(C_word)a,a+=3,tmp);
t15=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2056,a[2]=t14,a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 287  read-line */
t16=((C_word*)t0)[9];
((C_proc2)C_retrieve_proc(t16))(2,t16,t15);}
else{
t13=(C_word)C_eqp(((C_word*)t0)[14],lf[111]);
if(C_truep(t13)){
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2069,a[2]=((C_word*)t0)[15],tmp=(C_word)a,a+=3,tmp);
t15=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2073,a[2]=t14,tmp=(C_word)a,a+=3,tmp);
t16=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2077,a[2]=t15,a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 288  read-line */
t17=((C_word*)t0)[9];
((C_proc2)C_retrieve_proc(t17))(2,t17,t16);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[14],lf[115]);
if(C_truep(t14)){
t15=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2090,a[2]=((C_word*)t0)[15],tmp=(C_word)a,a+=3,tmp);
t16=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2094,a[2]=t15,tmp=(C_word)a,a+=3,tmp);
t17=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2098,a[2]=t16,a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 289  read-line */
t18=((C_word*)t0)[9];
((C_proc2)C_retrieve_proc(t18))(2,t18,t17);}
else{
t15=(C_word)C_eqp(((C_word*)t0)[14],lf[120]);
if(C_truep(t15)){
t16=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2111,a[2]=((C_word*)t0)[15],tmp=(C_word)a,a+=3,tmp);
t17=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2115,a[2]=t16,tmp=(C_word)a,a+=3,tmp);
t18=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2119,a[2]=t17,a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 290  read-line */
t19=((C_word*)t0)[9];
((C_proc2)C_retrieve_proc(t19))(2,t19,t18);}
else{
t16=(C_word)C_eqp(((C_word*)t0)[14],lf[122]);
if(C_truep(t16)){
/* csi.scm: 291  do-unbreak-all */
t17=C_retrieve(lf[123]);
((C_proc2)C_retrieve_proc(t17))(2,t17,((C_word*)t0)[15]);}
else{
t17=(C_word)C_eqp(((C_word*)t0)[14],lf[124]);
if(C_truep(t17)){
t18=C_set_block_item(lf[125],0,C_SCHEME_FALSE);
t19=((C_word*)t0)[15];
((C_proc2)(void*)(*((C_word*)t19+1)))(2,t19,t18);}
else{
t18=(C_word)C_eqp(((C_word*)t0)[14],lf[126]);
if(C_truep(t18)){
t19=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2145,a[2]=((C_word*)t0)[15],tmp=(C_word)a,a+=3,tmp);
t20=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2149,a[2]=t19,a[3]=((C_word*)t0)[11],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 295  read */
t21=((C_word*)t0)[12];
((C_proc2)C_retrieve_proc(t21))(2,t21,t20);}
else{
t19=(C_word)C_eqp(((C_word*)t0)[14],lf[127]);
if(C_truep(t19)){
t20=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2158,a[2]=((C_word*)t0)[15],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(C_retrieve2(lf[101],"traced-procedures")))){
t21=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2181,a[2]=t20,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* map */
t22=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t22+1)))(4,t22,t21,*((C_word*)lf[129]+1),C_retrieve2(lf[101],"traced-procedures"));}
else{
t21=t20;
f_2158(2,t21,C_SCHEME_UNDEFINED);}}
else{
t20=(C_word)C_eqp(((C_word*)t0)[14],lf[131]);
if(C_truep(t20)){
if(C_truep(C_retrieve(lf[132]))){
t21=C_retrieve(lf[132]);
t22=C_set_block_item(lf[132],0,C_SCHEME_FALSE);
/* csi.scm: 305  ##sys#break-resume */
t23=C_retrieve(lf[133]);
((C_proc3)C_retrieve_proc(t23))(3,t23,((C_word*)t0)[15],t21);}
else{
/* csi.scm: 306  display */
t21=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t21))(3,t21,((C_word*)t0)[15],lf[134]);}}
else{
t21=(C_word)C_eqp(((C_word*)t0)[14],lf[135]);
if(C_truep(t21)){
if(C_truep(C_retrieve(lf[136]))){
t22=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2209,a[2]=((C_word*)t0)[15],tmp=(C_word)a,a+=3,tmp);
t23=(C_word)C_a_i_list(&a,1,C_retrieve(lf[136]));
/* csi.scm: 309  history-add */
t24=C_retrieve(lf[52]);
((C_proc3)C_retrieve_proc(t24))(3,t24,t22,t23);}
else{
t22=((C_word*)t0)[15];
((C_proc2)(void*)(*((C_word*)t22+1)))(2,t22,C_SCHEME_UNDEFINED);}}
else{
t22=(C_word)C_eqp(((C_word*)t0)[14],lf[137]);
if(C_truep(t22)){
t23=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2225,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[15],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 312  read */
t24=((C_word*)t0)[12];
((C_proc2)C_retrieve_proc(t24))(2,t24,t23);}
else{
t23=(C_word)C_eqp(((C_word*)t0)[14],lf[138]);
if(C_truep(t23)){
t24=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2248,a[2]=((C_word*)t0)[15],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 316  read-line */
t25=((C_word*)t0)[9];
((C_proc2)C_retrieve_proc(t25))(2,t25,t24);}
else{
t24=(C_word)C_eqp(((C_word*)t0)[14],lf[140]);
if(C_truep(t24)){
t25=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2267,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[15],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 321  display */
t26=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t26))(3,t26,t25,lf[142]);}
else{
t25=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2291,a[2]=((C_word*)t0)[15],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 356  printf */
t26=((C_word*)t0)[6];
((C_proc4)C_retrieve_proc(t26))(4,t26,t25,lf[143],((C_word*)t0)[2]);}}}}}}}}}}}}}}}}}}}}}}}}}

/* k2289 in k1813 in k1807 in ##sys#repl-eval-hook in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_2291(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_retrieve(lf[13]));}

/* k2265 in k1813 in k1807 in ##sys#repl-eval-hook in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_2267(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2267,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2270,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2275,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 347  hash-table-walk */
t4=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,C_retrieve2(lf[60],"command-table"),t3);}

/* a2274 in k2265 in k1813 in k1807 in ##sys#repl-eval-hook in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_2275(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2275,4,t0,t1,t2,t3);}
t4=(C_word)C_i_cdr(t3);
if(C_truep(t4)){
/* csi.scm: 352  print */
t5=*((C_word*)lf[24]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,C_make_character(32),t4);}
else{
/* csi.scm: 353  print */
t5=*((C_word*)lf[24]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,lf[141],t2);}}

/* k2268 in k2265 in k1813 in k1807 in ##sys#repl-eval-hook in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_2270(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_retrieve(lf[13]));}

/* k2246 in k1813 in k1807 in ##sys#repl-eval-hook in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_2248(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2248,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2251,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 317  system */
t3=C_retrieve(lf[139]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k2249 in k2246 in k1813 in k1807 in ##sys#repl-eval-hook in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_2251(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2251,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2254,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_a_i_list(&a,1,t1);
/* csi.scm: 318  history-add */
t4=C_retrieve(lf[52]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}

/* k2252 in k2249 in k2246 in k1813 in k1807 in ##sys#repl-eval-hook in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_2254(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k2223 in k1813 in k1807 in ##sys#repl-eval-hook in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_2225(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2225,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2228,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 313  read-line */
t3=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k2226 in k2223 in k1813 in k1807 in ##sys#repl-eval-hook in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_2228(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2228,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2235,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_a_i_list(&a,3,lf[3],C_SCHEME_END_OF_LIST,((C_word*)t0)[3]);
/* csi.scm: 314  eval */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}

/* k2233 in k2226 in k2223 in k1813 in k1807 in ##sys#repl-eval-hook in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_2235(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 314  singlestep */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2207 in k1813 in k1807 in ##sys#repl-eval-hook in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_2209(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 310  describe */
t2=C_retrieve(lf[82]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_retrieve(lf[136]));}

/* k2179 in k1813 in k1807 in ##sys#repl-eval-hook in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_2181(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 298  printf */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[130],t1);}

/* k2156 in k1813 in k1807 in ##sys#repl-eval-hook in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_2158(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2158,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(C_retrieve2(lf[104],"broken-procedures")))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2171,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* map */
t3=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[129]+1),C_retrieve2(lf[104],"broken-procedures"));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k2169 in k2156 in k1813 in k1807 in ##sys#repl-eval-hook in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_2171(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 300  printf */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[128],t1);}

/* k2147 in k1813 in k1807 in ##sys#repl-eval-hook in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_2149(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 295  eval */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2143 in k1813 in k1807 in ##sys#repl-eval-hook in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_2145(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[125]+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2117 in k1813 in k1807 in ##sys#repl-eval-hook in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_2119(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 290  string-split */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2113 in k1813 in k1807 in ##sys#repl-eval-hook in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_2115(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],*((C_word*)lf[110]+1),t1);}

/* k2109 in k1813 in k1807 in ##sys#repl-eval-hook in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_2111(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2111,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2684,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[90]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,t1);}

/* a2683 in k2109 in k1813 in k1807 in ##sys#repl-eval-hook in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_2684(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2684,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2688,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 473  macroexpand */
t4=C_retrieve(lf[79]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k2686 in a2683 in k2109 in k1813 in k1807 in ##sys#repl-eval-hook in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_2688(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2688,2,t0,t1);}
t2=(C_word)C_i_assq(t1,C_retrieve2(lf[104],"broken-procedures"));
if(C_truep(t2)){
t3=(C_word)C_i_cdr(t2);
t4=(C_word)C_i_setslot(t1,C_fix(0),t3);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2707,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 478  del */
t6=C_retrieve(lf[112]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,t2,C_retrieve2(lf[104],"broken-procedures"),*((C_word*)lf[113]+1));}
else{
/* csi.scm: 475  ##sys#warn */
t3=C_retrieve(lf[102]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[2],lf[121],t1);}}

/* k2705 in k2686 in a2683 in k2109 in k1813 in k1807 in ##sys#repl-eval-hook in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_2707(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[104],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2096 in k1813 in k1807 in ##sys#repl-eval-hook in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_2098(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 289  string-split */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2092 in k1813 in k1807 in ##sys#repl-eval-hook in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_2094(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],*((C_word*)lf[110]+1),t1);}

/* k2088 in k1813 in k1807 in ##sys#repl-eval-hook in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_2090(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2090,2,t0,t1);}
t2=((C_word*)t0)[2];
if(C_truep((C_word)C_i_nullp(t1))){
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2603,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[90]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_retrieve2(lf[104],"broken-procedures"));}
else{
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2616,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[90]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,t1);}}

/* a2615 in k2088 in k1813 in k1807 in ##sys#repl-eval-hook in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_2616(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2616,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2620,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 452  macroexpand */
t4=C_retrieve(lf[79]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k2618 in a2615 in k2088 in k1813 in k1807 in ##sys#repl-eval-hook in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_2620(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2620,2,t0,t1);}
t2=(C_word)C_i_assq(t1,C_retrieve2(lf[101],"traced-procedures"));
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2626,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t2)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2665,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 455  ##sys#warn */
t5=C_retrieve(lf[102]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,lf[119],t1);}
else{
t4=t3;
f_2626(t4,C_SCHEME_UNDEFINED);}}

/* k2663 in k2618 in a2615 in k2088 in k1813 in k1807 in ##sys#repl-eval-hook in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_2665(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2665,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
t3=(C_word)C_i_setslot(((C_word*)t0)[3],C_fix(0),t2);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2672,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 457  del */
t5=C_retrieve(lf[112]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,((C_word*)t0)[4],C_retrieve2(lf[101],"traced-procedures"),*((C_word*)lf[113]+1));}

/* k2670 in k2663 in k2618 in a2615 in k2088 in k1813 in k1807 in ##sys#repl-eval-hook in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_2672(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[101],t1);
t3=((C_word*)t0)[2];
f_2626(t3,t2);}

/* k2624 in k2618 in a2615 in k2088 in k1813 in k1807 in ##sys#repl-eval-hook in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_fcall f_2626(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2626,NULL,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(0));
if(C_truep((C_word)C_i_closurep(t2))){
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_retrieve2(lf[104],"broken-procedures"));
t5=C_mutate(&lf[104],t4);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2647,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_i_setslot(((C_word*)t0)[3],C_fix(0),t6));}
else{
/* csi.scm: 459  ##sys#error */
t3=*((C_word*)lf[53]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],lf[118],((C_word*)t0)[3]);}}

/* a2646 in k2624 in k2618 in a2615 in k2088 in k1813 in k1807 in ##sys#repl-eval-hook in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_2647(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_2647r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2647r(t0,t1,t2);}}

static void C_ccall f_2647r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2651,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 465  ##sys#break-entry */
t4=C_retrieve(lf[117]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[2],t2);}

/* k2649 in a2646 in k2624 in k2618 in a2615 in k2088 in k1813 in k1807 in ##sys#repl-eval-hook in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_2651(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a2602 in k2088 in k1813 in k1807 in ##sys#repl-eval-hook in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_2603(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2603,3,t0,t1,t2);}
t3=(C_word)C_i_car(C_retrieve(lf[116]));
/* csi.scm: 449  print */
t4=*((C_word*)lf[24]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* k2075 in k1813 in k1807 in ##sys#repl-eval-hook in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_2077(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 288  string-split */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2071 in k1813 in k1807 in ##sys#repl-eval-hook in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_2073(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],*((C_word*)lf[110]+1),t1);}

/* k2067 in k1813 in k1807 in ##sys#repl-eval-hook in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_2069(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2069,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2562,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[90]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,t1);}

/* a2561 in k2067 in k1813 in k1807 in ##sys#repl-eval-hook in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_2562(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2562,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2566,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 438  macroexpand */
t4=C_retrieve(lf[79]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k2564 in a2561 in k2067 in k1813 in k1807 in ##sys#repl-eval-hook in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_2566(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2566,2,t0,t1);}
t2=(C_word)C_i_assq(t1,C_retrieve2(lf[101],"traced-procedures"));
if(C_truep(t2)){
t3=(C_word)C_i_cdr(t2);
t4=(C_word)C_i_setslot(t1,C_fix(0),t3);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2585,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 443  del */
t6=C_retrieve(lf[112]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,t2,C_retrieve2(lf[101],"traced-procedures"),*((C_word*)lf[113]+1));}
else{
/* csi.scm: 440  ##sys#warn */
t3=C_retrieve(lf[102]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[2],lf[114],t1);}}

/* k2583 in k2564 in a2561 in k2067 in k1813 in k1807 in ##sys#repl-eval-hook in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_2585(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[101],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2054 in k1813 in k1807 in ##sys#repl-eval-hook in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_2056(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 287  string-split */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2050 in k1813 in k1807 in ##sys#repl-eval-hook in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_2052(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],*((C_word*)lf[110]+1),t1);}

/* k2046 in k1813 in k1807 in ##sys#repl-eval-hook in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_2048(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2048,2,t0,t1);}
t2=((C_word*)t0)[2];
if(C_truep((C_word)C_i_nullp(t1))){
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2468,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[90]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_retrieve2(lf[101],"traced-procedures"));}
else{
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2481,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[90]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,t1);}}

/* a2480 in k2046 in k1813 in k1807 in ##sys#repl-eval-hook in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_2481(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2481,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2485,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 414  macroexpand */
t4=C_retrieve(lf[79]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k2483 in a2480 in k2046 in k1813 in k1807 in ##sys#repl-eval-hook in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_2485(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2485,2,t0,t1);}
if(C_truep((C_word)C_i_assq(t1,C_retrieve2(lf[101],"traced-procedures")))){
/* csi.scm: 416  ##sys#warn */
t2=C_retrieve(lf[102]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[103],t1);}
else{
if(C_truep((C_word)C_i_assq(t1,C_retrieve2(lf[104],"broken-procedures")))){
/* csi.scm: 418  ##sys#warn */
t2=C_retrieve(lf[102]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[105]);}
else{
t2=(C_word)C_slot(t1,C_fix(0));
if(C_truep((C_word)C_i_closurep(t2))){
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_retrieve2(lf[101],"traced-procedures"));
t5=C_mutate(&lf[101],t4);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2524,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_i_setslot(t1,C_fix(0),t6));}
else{
/* csi.scm: 421  ##sys#error */
t3=*((C_word*)lf[53]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],lf[108],t1);}}}}

/* a2523 in k2483 in a2480 in k2046 in k1813 in k1807 in ##sys#repl-eval-hook in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_2524(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr2r,(void*)f_2524r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2524r(t0,t1,t2);}}

static void C_ccall f_2524r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(6);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2528,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 427  traced-procedure-entry */
t4=C_retrieve(lf[107]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[2],t2);}

/* k2526 in a2523 in k2483 in a2480 in k2046 in k1813 in k1807 in ##sys#repl-eval-hook in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_2528(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2528,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2533,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2539,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 428  call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a2538 in k2526 in a2523 in k2483 in a2480 in k2046 in k1813 in k1807 in ##sys#repl-eval-hook in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_2539(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_2539r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2539r(t0,t1,t2);}}

static void C_ccall f_2539r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2543,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 430  traced-procedure-exit */
t4=C_retrieve(lf[106]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[2],t2);}

/* k2541 in a2538 in k2526 in a2523 in k2483 in a2480 in k2046 in k1813 in k1807 in ##sys#repl-eval-hook in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_2543(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a2532 in k2526 in a2523 in k2483 in a2480 in k2046 in k1813 in k1807 in ##sys#repl-eval-hook in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_2533(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2533,2,t0,t1);}
C_apply(4,0,t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a2467 in k2046 in k1813 in k1807 in ##sys#repl-eval-hook in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_2468(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2468,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
/* csi.scm: 411  print */
t4=*((C_word*)lf[24]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* k1993 in k1813 in k1807 in ##sys#repl-eval-hook in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_1995(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1995,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2000,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2028,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a2027 in k1993 in k1813 in k1807 in ##sys#repl-eval-hook in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_2028(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_2028r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2028r(t0,t1,t2);}}

static void C_ccall f_2028r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2032,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 285  history-add */
t4=C_retrieve(lf[52]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k2030 in a2027 in k1993 in k1813 in k1807 in ##sys#repl-eval-hook in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_2032(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a1999 in k1993 in k1813 in k1807 in ##sys#repl-eval-hook in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_2000(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2000,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2004,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* ##sys#start-timer */
t3=*((C_word*)lf[99]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2002 in a1999 in k1993 in k1813 in k1807 in ##sys#repl-eval-hook in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_2004(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2004,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2009,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2015,tmp=(C_word)a,a+=2,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a2014 in k2002 in a1999 in k1993 in k1813 in k1807 in ##sys#repl-eval-hook in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_2015(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr2r,(void*)f_2015r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2015r(t0,t1,t2);}}

static void C_ccall f_2015r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(7);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2019,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2026,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* ##sys#stop-timer */
t5=*((C_word*)lf[98]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* k2024 in a2014 in k2002 in a1999 in k1993 in k1813 in k1807 in ##sys#repl-eval-hook in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_2026(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#display-times */
t2=C_retrieve(lf[97]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2017 in a2014 in k2002 in a1999 in k1993 in k1813 in k1807 in ##sys#repl-eval-hook in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_2019(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a2008 in k2002 in a1999 in k1993 in k1813 in k1807 in ##sys#repl-eval-hook in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_2009(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2009,2,t0,t1);}
/* csi.scm: 284  eval */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* k1984 in k1813 in k1807 in ##sys#repl-eval-hook in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_1986(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 279  string-split */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1959 in k1813 in k1807 in ##sys#repl-eval-hook in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_1961(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1961,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1964,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1969,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t4=*((C_word*)lf[90]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,t1);}

/* a1968 in k1959 in k1813 in k1807 in ##sys#repl-eval-hook in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_1969(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1969,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1975,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* load-noisily542 */
t4=((C_word*)t0)[2];
((C_proc5)C_retrieve_proc(t4))(5,t4,t1,t2,lf[95],t3);}

/* a1974 in a1968 in k1959 in k1813 in k1807 in ##sys#repl-eval-hook in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_1975(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1975,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1979,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 280  pretty-print */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k1977 in a1974 in a1968 in k1959 in k1813 in k1807 in ##sys#repl-eval-hook in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_1979(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 280  print* */
t2=*((C_word*)lf[93]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[94]);}

/* k1962 in k1959 in k1813 in k1807 in ##sys#repl-eval-hook in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_1964(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_retrieve(lf[13]));}

/* k1950 in k1813 in k1807 in ##sys#repl-eval-hook in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_1952(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 275  string-split */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1940 in k1813 in k1807 in ##sys#repl-eval-hook in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_1942(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1942,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1945,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* for-each */
t3=*((C_word*)lf[90]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_retrieve(lf[91]),t1);}

/* k1943 in k1940 in k1813 in k1807 in ##sys#repl-eval-hook in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_1945(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_retrieve(lf[13]));}

/* k1901 in k1813 in k1807 in ##sys#repl-eval-hook in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_1903(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1903,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1906,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 268  read */
t3=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k1904 in k1901 in k1813 in k1807 in ##sys#repl-eval-hook in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_1906(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1906,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1909,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 269  eval */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k1907 in k1904 in k1901 in k1813 in k1807 in ##sys#repl-eval-hook in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_1909(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1909,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1912,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 270  eval */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k1910 in k1907 in k1904 in k1901 in k1813 in k1807 in ##sys#repl-eval-hook in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_1912(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 271  dump */
t2=C_retrieve(lf[84]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1886 in k1813 in k1807 in ##sys#repl-eval-hook in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_1888(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1888,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1891,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 264  eval */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k1889 in k1886 in k1813 in k1807 in ##sys#repl-eval-hook in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_1891(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 265  dump */
t2=C_retrieve(lf[84]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1871 in k1813 in k1807 in ##sys#repl-eval-hook in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_1873(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1873,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1876,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 260  eval */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k1874 in k1871 in k1813 in k1807 in ##sys#repl-eval-hook in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_1876(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 261  describe */
t2=C_retrieve(lf[82]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1853 in k1813 in k1807 in ##sys#repl-eval-hook in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_1855(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1855,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1858,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 255  eval */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k1856 in k1853 in k1813 in k1807 in ##sys#repl-eval-hook in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_1858(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1858,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1861,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 256  pretty-print */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k1859 in k1856 in k1853 in k1813 in k1807 in ##sys#repl-eval-hook in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_1861(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_retrieve(lf[13]));}

/* k1834 in k1813 in k1807 in ##sys#repl-eval-hook in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_1836(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1836,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1839,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1846,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 251  macroexpand */
t4=C_retrieve(lf[79]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t1);}

/* k1844 in k1834 in k1813 in k1807 in ##sys#repl-eval-hook in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_1846(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 251  pretty-print */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1837 in k1834 in k1813 in k1807 in ##sys#repl-eval-hook in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_1839(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_retrieve(lf[13]));}

/* k1819 in k1813 in k1807 in ##sys#repl-eval-hook in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_1821(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_retrieve(lf[13]));}

/* toplevel-command in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_1751(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_1751r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_1751r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1751r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(6);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1755,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_1755(2,t6,C_SCHEME_FALSE);}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_1755(2,t7,(C_word)C_i_car(t4));}
else{
/* ##sys#error */
t7=*((C_word*)lf[53]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* k1753 in toplevel-command in k1747 in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_1755(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1755,2,t0,t1);}
t2=(C_word)C_i_check_symbol_2(((C_word*)t0)[5],lf[62]);
t3=(C_truep(t1)?(C_word)C_i_check_string_2(t1,lf[62]):C_SCHEME_UNDEFINED);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
/* csi.scm: 218  hash-table-set! */
t5=((C_word*)t0)[3];
((C_proc5)C_retrieve_proc(t5))(5,t5,((C_word*)t0)[2],C_retrieve2(lf[60],"command-table"),((C_word*)t0)[5],t4);}

/* ##sys#read-prompt-hook in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_1735(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1735,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1742,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 209  tty-input? */
t3=C_retrieve(lf[55]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k1740 in ##sys#read-prompt-hook in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_1742(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* csi.scm: 209  old */
t2=((C_word*)t0)[3];
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* ##csi#tty-input? in k1718 in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_1722(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1722,2,t0,t1);}
t2=(C_word)C_fudge(C_fix(12));
if(C_truep(t2)){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
/* csi.scm: 202  ##sys#tty-port? */
t3=C_retrieve(lf[56]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,*((C_word*)lf[57]+1));}}

/* ##csi#history-ref in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_1695(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1695,3,t0,t1,t2);}
t3=(C_word)C_i_inexact_to_exact(t2);
t4=(C_word)C_fixnum_greaterp(t3,C_fix(0));
t5=(C_truep(t4)?(C_word)C_fixnum_less_or_equal_p(t3,C_retrieve(lf[31])):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_i_vector_ref(C_retrieve(lf[50]),t3));}
else{
/* csi.scm: 194  ##sys#error */
t6=*((C_word*)lf[53]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t1,lf[54],t2);}}

/* ##csi#history-add in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_1656(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1656,3,t0,t1,t2);}
t3=(C_word)C_i_nullp(t2);
t4=(C_truep(t3)?C_retrieve(lf[13]):(C_word)C_slot(t2,C_fix(0)));
t5=(C_word)C_block_size(C_retrieve(lf[50]));
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1666,a[2]=t1,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(C_retrieve(lf[31]),t5))){
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1680,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_fixnum_times(C_fix(2),t5);
/* csi.scm: 185  vector-resize */
t9=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t9))(4,t9,t7,C_retrieve(lf[50]),t8);}
else{
t7=t6;
f_1666(t7,C_SCHEME_UNDEFINED);}}

/* k1678 in ##csi#history-add in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_1680(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[50]+1,t1);
t3=((C_word*)t0)[2];
f_1666(t3,t2);}

/* k1664 in ##csi#history-add in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_fcall f_1666(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_i_vector_set(C_retrieve(lf[50]),C_retrieve(lf[31]),((C_word*)t0)[3]);
t3=(C_word)C_fixnum_plus(C_retrieve(lf[31]),C_fix(1));
t4=C_mutate((C_word*)lf[31]+1,t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,((C_word*)t0)[3]);}

/* ##csi#lookup-script-file in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_1550(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1550,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1554,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 158  getenv */
t4=C_retrieve(lf[48]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[49]);}

/* k1552 in ##csi#lookup-script-file in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_1554(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1554,2,t0,t1);}
t2=(C_word)C_block_size(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_greaterp(t2,C_fix(0)))){
t3=(C_word)C_i_string_ref(((C_word*)t0)[5],C_fix(0));
t4=f_1440(t3);
if(C_truep(t4)){
/* csi.scm: 160  addext */
f_1502(((C_word*)t0)[3],((C_word*)t0)[5]);}
else{
t5=((C_word*)t0)[5];
t6=(C_word)C_block_size(t5);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1529,a[2]=t5,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t8=f_1529(t7,C_fix(0));
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1578,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t10=((C_word*)t0)[2];
t11=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t12=(C_truep(t10)?(C_word)C_i_foreign_block_argumentp(t10):C_SCHEME_FALSE);
t13=(C_word)C_i_foreign_fixnum_argumentp(C_fix(256));
t14=(C_word)stub486(t11,t12,t13);
/* ##sys#peek-nonnull-c-string */
t15=*((C_word*)lf[44]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t9,t14,C_fix(0));}
else{
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1595,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 164  addext */
f_1502(t9,((C_word*)t0)[5]);}}}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k1593 in k1552 in ##csi#lookup-script-file in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_1595(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1595,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1601,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 166  string-append */
t3=*((C_word*)lf[40]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[47],((C_word*)t0)[2]);}}

/* k1599 in k1593 in k1552 in ##csi#lookup-script-file in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_1601(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1601,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1608,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 167  string-split */
t3=C_retrieve(lf[45]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],lf[46]);}

/* k1606 in k1599 in k1593 in k1552 in ##csi#lookup-script-file in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_1608(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1608,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1610,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_1610(t5,((C_word*)t0)[2],t1);}

/* loop in k1606 in k1599 in k1593 in k1552 in ##csi#lookup-script-file in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_fcall f_1610(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1610,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1620,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1637,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_slot(t2,C_fix(0));
/* csi.scm: 169  chop-separator */
t6=C_retrieve(lf[36]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k1635 in loop in k1606 in k1599 in k1593 in k1552 in ##csi#lookup-script-file in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_1637(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 169  string-append */
t2=*((C_word*)lf[40]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k1618 in loop in k1606 in k1599 in k1593 in k1552 in ##csi#lookup-script-file in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_1620(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1620,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1623,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 170  addext */
f_1502(t2,t1);}

/* k1621 in k1618 in loop in k1606 in k1599 in k1593 in k1552 in ##csi#lookup-script-file in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_1623(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* csi.scm: 171  loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_1610(t3,((C_word*)t0)[4],t2);}}

/* k1576 in k1552 in ##csi#lookup-script-file in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_1578(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1578,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1588,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1592,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 163  chop-separator */
t4=C_retrieve(lf[36]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t1);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k1590 in k1576 in k1552 in ##csi#lookup-script-file in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_1592(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 163  string-append */
t2=*((C_word*)lf[40]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],t1,lf[43],((C_word*)t0)[2]);}

/* k1586 in k1576 in k1552 in ##csi#lookup-script-file in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_1588(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 163  addext */
f_1502(((C_word*)t0)[2],t1);}

/* loop in k1552 in ##csi#lookup-script-file in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static C_word C_fcall f_1529(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
loop:
C_stack_check;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[3]))){
return(C_SCHEME_FALSE);}
else{
t2=f_1440((C_word)C_subchar(((C_word*)t0)[2],t1));
if(C_truep(t2)){
return(t1);}
else{
t3=(C_word)C_fixnum_plus(t1,C_fix(1));
t5=t3;
t1=t5;
goto loop;}}}

/* addext in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_fcall f_1502(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1502,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1509,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 147  file-exists? */
t4=C_retrieve(lf[39]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k1507 in addext in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_1509(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1509,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1512,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 149  string-append */
t3=*((C_word*)lf[40]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],lf[41]);}}

/* k1510 in k1507 in addext in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_1512(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1512,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1518,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 150  file-exists? */
t3=C_retrieve(lf[39]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k1516 in k1510 in k1507 in addext in k1481 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_1518(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?((C_word*)t0)[2]:C_SCHEME_FALSE));}

/* ##csi#chop-separator in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_1452(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1452,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1456,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_block_size(t2);
/* csi.scm: 132  sub1 */
t5=*((C_word*)lf[37]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* k1454 in ##csi#chop-separator in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_1456(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_string_ref(((C_word*)t0)[4],t1);
t3=(C_truep((C_word)C_fixnum_greaterp(t1,C_fix(0)))?f_1440(t2):C_SCHEME_FALSE);
if(C_truep(t3)){
/* csi.scm: 135  substring */
t4=((C_word*)t0)[3];
((C_proc5)C_retrieve_proc(t4))(5,t4,((C_word*)t0)[2],((C_word*)t0)[4],C_fix(0),t1);}
else{
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[4]);}}

/* dirseparator? in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static C_word C_fcall f_1440(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_eqp(t1,C_make_character(92));
return((C_truep(t2)?t2:(C_word)C_eqp(t1,C_make_character(47))));}

/* ##sys#sharp-number-hook in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_1430(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1430,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1438,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 121  history-ref */
t5=C_retrieve(lf[32]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t3);}

/* k1436 in ##sys#sharp-number-hook in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_1438(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1438,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,lf[30],t1));}

/* ##sys#user-read-hook in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_1401(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1401,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(C_make_character(41),t2);
t5=(C_truep(t4)?t4:(C_word)C_u_i_char_whitespacep(t2));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1418,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t7=(C_word)C_fixnum_difference(C_retrieve(lf[31]),C_fix(1));
/* csi.scm: 116  history-ref */
t8=C_retrieve(lf[32]);
((C_proc3)C_retrieve_proc(t8))(3,t8,t6,t7);}
else{
/* csi.scm: 117  old-hook */
t6=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t6))(4,t6,t1,t2,t3);}}

/* k1416 in ##sys#user-read-hook in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_1418(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1418,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,lf[30],t1));}

/* ##csi#print-banner in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_1391(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1391,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1399,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 105  chicken-version */
t3=C_retrieve(lf[26]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_SCHEME_TRUE);}

/* k1397 in ##csi#print-banner in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_1399(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 105  print */
t2=*((C_word*)lf[24]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[12],t1,lf[25]);}

/* ##csi#print-usage in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_1379(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1379,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1383,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 75   display */
t3=*((C_word*)lf[20]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[22]);}

/* k1381 in ##csi#print-usage in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_1383(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1383,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1386,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 90   display */
t3=*((C_word*)lf[20]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[14]);}

/* k1384 in k1381 in ##csi#print-usage in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in k1347 in k1344 in k1341 in k1338 in k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 in k1217 in k1214 in k1211 in k1208 in k1205 in k1202 in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_1386(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 91   display */
t2=*((C_word*)lf[20]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[21]);}

/* assign in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_1131(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1131,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1135,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 44   ##sys#check-syntax */
t5=C_retrieve(lf[8]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,lf[9],t2,lf[10]);}

/* k1133 in assign in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_1135(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[45],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1135,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[5]))){
t2=(C_word)C_a_i_list(&a,3,lf[3],C_SCHEME_END_OF_LIST,((C_word*)t0)[4]);
t3=(C_word)C_a_i_list(&a,1,lf[4]);
t4=(C_word)C_a_i_list(&a,3,lf[3],C_SCHEME_END_OF_LIST,t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,3,lf[5],t2,t4));}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_i_car(((C_word*)t0)[5]);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[6],t3,((C_word*)t0)[4]));}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1172,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 44   map */
t4=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_retrieve(lf[7]),((C_word*)t0)[5]);}}}

/* k1170 in k1133 in assign in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_1172(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1172,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,lf[3],C_SCHEME_END_OF_LIST,((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1191,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1193,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 44   map */
t5=((C_word*)t0)[3];
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,t4,((C_word*)t0)[2],t1);}

/* a1192 in k1170 in k1133 in assign in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_1193(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1193,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[6],t2,t3));}

/* k1189 in k1170 in k1133 in assign in k1128 in k1125 in k1122 in k1119 in k1116 in k1113 in k1110 in k1107 in k1104 in k1101 in k1098 in k1095 in k1092 in k1089 in k1086 in k1083 in k1080 in k1077 in k1074 in k1071 */
static void C_ccall f_1191(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1191,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[3],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[5],((C_word*)t0)[2],t3));}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[767] = {
{"toplevelcsi.scm",(void*)C_toplevel},
{"f_1073csi.scm",(void*)f_1073},
{"f_1076csi.scm",(void*)f_1076},
{"f_1079csi.scm",(void*)f_1079},
{"f_1082csi.scm",(void*)f_1082},
{"f_1085csi.scm",(void*)f_1085},
{"f_1088csi.scm",(void*)f_1088},
{"f_1091csi.scm",(void*)f_1091},
{"f_1094csi.scm",(void*)f_1094},
{"f_8732csi.scm",(void*)f_8732},
{"f_8736csi.scm",(void*)f_8736},
{"f_8739csi.scm",(void*)f_8739},
{"f_8742csi.scm",(void*)f_8742},
{"f_8748csi.scm",(void*)f_8748},
{"f_8954csi.scm",(void*)f_8954},
{"f_8934csi.scm",(void*)f_8934},
{"f_8930csi.scm",(void*)f_8930},
{"f_8910csi.scm",(void*)f_8910},
{"f_8773csi.scm",(void*)f_8773},
{"f_8783csi.scm",(void*)f_8783},
{"f_8902csi.scm",(void*)f_8902},
{"f_8786csi.scm",(void*)f_8786},
{"f_8898csi.scm",(void*)f_8898},
{"f_8789csi.scm",(void*)f_8789},
{"f_8820csi.scm",(void*)f_8820},
{"f_8800csi.scm",(void*)f_8800},
{"f_8771csi.scm",(void*)f_8771},
{"f_1097csi.scm",(void*)f_1097},
{"f_8644csi.scm",(void*)f_8644},
{"f_8661csi.scm",(void*)f_8661},
{"f_8664csi.scm",(void*)f_8664},
{"f_8670csi.scm",(void*)f_8670},
{"f_1100csi.scm",(void*)f_1100},
{"f_8603csi.scm",(void*)f_8603},
{"f_8607csi.scm",(void*)f_8607},
{"f_1103csi.scm",(void*)f_1103},
{"f_8587csi.scm",(void*)f_8587},
{"f_8597csi.scm",(void*)f_8597},
{"f_8595csi.scm",(void*)f_8595},
{"f_1106csi.scm",(void*)f_1106},
{"f_8510csi.scm",(void*)f_8510},
{"f_8514csi.scm",(void*)f_8514},
{"f_8582csi.scm",(void*)f_8582},
{"f_8517csi.scm",(void*)f_8517},
{"f_8526csi.scm",(void*)f_8526},
{"f_8573csi.scm",(void*)f_8573},
{"f_8540csi.scm",(void*)f_8540},
{"f_8548csi.scm",(void*)f_8548},
{"f_8550csi.scm",(void*)f_8550},
{"f_8567csi.scm",(void*)f_8567},
{"f_8532csi.scm",(void*)f_8532},
{"f_8524csi.scm",(void*)f_8524},
{"f_1109csi.scm",(void*)f_1109},
{"f_8450csi.scm",(void*)f_8450},
{"f_8454csi.scm",(void*)f_8454},
{"f_1112csi.scm",(void*)f_1112},
{"f_8391csi.scm",(void*)f_8391},
{"f_8395csi.scm",(void*)f_8395},
{"f_8422csi.scm",(void*)f_8422},
{"f_1115csi.scm",(void*)f_1115},
{"f_8217csi.scm",(void*)f_8217},
{"f_8221csi.scm",(void*)f_8221},
{"f_8224csi.scm",(void*)f_8224},
{"f_8385csi.scm",(void*)f_8385},
{"f_8227csi.scm",(void*)f_8227},
{"f_8379csi.scm",(void*)f_8379},
{"f_8230csi.scm",(void*)f_8230},
{"f_8377csi.scm",(void*)f_8377},
{"f_8341csi.scm",(void*)f_8341},
{"f_8355csi.scm",(void*)f_8355},
{"f_8369csi.scm",(void*)f_8369},
{"f_8349csi.scm",(void*)f_8349},
{"f_8345csi.scm",(void*)f_8345},
{"f_8237csi.scm",(void*)f_8237},
{"f_8333csi.scm",(void*)f_8333},
{"f_8309csi.scm",(void*)f_8309},
{"f_8327csi.scm",(void*)f_8327},
{"f_8317csi.scm",(void*)f_8317},
{"f_8313csi.scm",(void*)f_8313},
{"f_8305csi.scm",(void*)f_8305},
{"f_8289csi.scm",(void*)f_8289},
{"f_8265csi.scm",(void*)f_8265},
{"f_8283csi.scm",(void*)f_8283},
{"f_8273csi.scm",(void*)f_8273},
{"f_8269csi.scm",(void*)f_8269},
{"f_8261csi.scm",(void*)f_8261},
{"f_1118csi.scm",(void*)f_1118},
{"f_8122csi.scm",(void*)f_8122},
{"f_8158csi.scm",(void*)f_8158},
{"f_8171csi.scm",(void*)f_8171},
{"f_8129csi.scm",(void*)f_8129},
{"f_1121csi.scm",(void*)f_1121},
{"f_8012csi.scm",(void*)f_8012},
{"f_8016csi.scm",(void*)f_8016},
{"f_8019csi.scm",(void*)f_8019},
{"f_8022csi.scm",(void*)f_8022},
{"f_8025csi.scm",(void*)f_8025},
{"f_8116csi.scm",(void*)f_8116},
{"f_8028csi.scm",(void*)f_8028},
{"f_8110csi.scm",(void*)f_8110},
{"f_8031csi.scm",(void*)f_8031},
{"f_8104csi.scm",(void*)f_8104},
{"f_8108csi.scm",(void*)f_8108},
{"f_8038csi.scm",(void*)f_8038},
{"f_8076csi.scm",(void*)f_8076},
{"f_8074csi.scm",(void*)f_8074},
{"f_1124csi.scm",(void*)f_1124},
{"f_8002csi.scm",(void*)f_8002},
{"f_1127csi.scm",(void*)f_1127},
{"f_7988csi.scm",(void*)f_7988},
{"f_1130csi.scm",(void*)f_1130},
{"f_1204csi.scm",(void*)f_1204},
{"f_1207csi.scm",(void*)f_1207},
{"f_7726csi.scm",(void*)f_7726},
{"f_7730csi.scm",(void*)f_7730},
{"f_7739csi.scm",(void*)f_7739},
{"f_7948csi.scm",(void*)f_7948},
{"f_7961csi.scm",(void*)f_7961},
{"f_7742csi.scm",(void*)f_7742},
{"f_7938csi.scm",(void*)f_7938},
{"f_7946csi.scm",(void*)f_7946},
{"f_7745csi.scm",(void*)f_7745},
{"f_7892csi.scm",(void*)f_7892},
{"f_7925csi.scm",(void*)f_7925},
{"f_7932csi.scm",(void*)f_7932},
{"f_7908csi.scm",(void*)f_7908},
{"f_7757csi.scm",(void*)f_7757},
{"f_7886csi.scm",(void*)f_7886},
{"f_7764csi.scm",(void*)f_7764},
{"f_7766csi.scm",(void*)f_7766},
{"f_7880csi.scm",(void*)f_7880},
{"f_7800csi.scm",(void*)f_7800},
{"f_7854csi.scm",(void*)f_7854},
{"f_7831csi.scm",(void*)f_7831},
{"f_7811csi.scm",(void*)f_7811},
{"f_7786csi.scm",(void*)f_7786},
{"f_7794csi.scm",(void*)f_7794},
{"f_7784csi.scm",(void*)f_7784},
{"f_7746csi.scm",(void*)f_7746},
{"f_7686csi.scm",(void*)f_7686},
{"f_7709csi.scm",(void*)f_7709},
{"f_7713csi.scm",(void*)f_7713},
{"f_7655csi.scm",(void*)f_7655},
{"f_7676csi.scm",(void*)f_7676},
{"f_1210csi.scm",(void*)f_1210},
{"f_7604csi.scm",(void*)f_7604},
{"f_7608csi.scm",(void*)f_7608},
{"f_7619csi.scm",(void*)f_7619},
{"f_7644csi.scm",(void*)f_7644},
{"f_1213csi.scm",(void*)f_1213},
{"f_7484csi.scm",(void*)f_7484},
{"f_7488csi.scm",(void*)f_7488},
{"f_7598csi.scm",(void*)f_7598},
{"f_7596csi.scm",(void*)f_7596},
{"f_7497csi.scm",(void*)f_7497},
{"f_7584csi.scm",(void*)f_7584},
{"f_7592csi.scm",(void*)f_7592},
{"f_7500csi.scm",(void*)f_7500},
{"f_7578csi.scm",(void*)f_7578},
{"f_7520csi.scm",(void*)f_7520},
{"f_7530csi.scm",(void*)f_7530},
{"f_7550csi.scm",(void*)f_7550},
{"f_7556csi.scm",(void*)f_7556},
{"f_7564csi.scm",(void*)f_7564},
{"f_7554csi.scm",(void*)f_7554},
{"f_7528csi.scm",(void*)f_7528},
{"f_7524csi.scm",(void*)f_7524},
{"f_7501csi.scm",(void*)f_7501},
{"f_1216csi.scm",(void*)f_1216},
{"f_7463csi.scm",(void*)f_7463},
{"f_7467csi.scm",(void*)f_7467},
{"f_1219csi.scm",(void*)f_1219},
{"f_7453csi.scm",(void*)f_7453},
{"f_1225csi.scm",(void*)f_1225},
{"f_1234csi.scm",(void*)f_1234},
{"f_1250csi.scm",(void*)f_1250},
{"f_1237csi.scm",(void*)f_1237},
{"f_1298csi.scm",(void*)f_1298},
{"f_7432csi.scm",(void*)f_7432},
{"f_7436csi.scm",(void*)f_7436},
{"f_1301csi.scm",(void*)f_1301},
{"f_7316csi.scm",(void*)f_7316},
{"f_7320csi.scm",(void*)f_7320},
{"f_7329csi.scm",(void*)f_7329},
{"f_7343csi.scm",(void*)f_7343},
{"f_7407csi.scm",(void*)f_7407},
{"f_7389csi.scm",(void*)f_7389},
{"f_7372csi.scm",(void*)f_7372},
{"f_1304csi.scm",(void*)f_1304},
{"f_7217csi.scm",(void*)f_7217},
{"f_7227csi.scm",(void*)f_7227},
{"f_7240csi.scm",(void*)f_7240},
{"f_7256csi.scm",(void*)f_7256},
{"f_7294csi.scm",(void*)f_7294},
{"f_7292csi.scm",(void*)f_7292},
{"f_7284csi.scm",(void*)f_7284},
{"f_7238csi.scm",(void*)f_7238},
{"f_1307csi.scm",(void*)f_1307},
{"f_7128csi.scm",(void*)f_7128},
{"f_7138csi.scm",(void*)f_7138},
{"f_7151csi.scm",(void*)f_7151},
{"f_7167csi.scm",(void*)f_7167},
{"f_7195csi.scm",(void*)f_7195},
{"f_7149csi.scm",(void*)f_7149},
{"f_1310csi.scm",(void*)f_1310},
{"f_6842csi.scm",(void*)f_6842},
{"f_7039csi.scm",(void*)f_7039},
{"f_7042csi.scm",(void*)f_7042},
{"f_7045csi.scm",(void*)f_7045},
{"f_7118csi.scm",(void*)f_7118},
{"f_7126csi.scm",(void*)f_7126},
{"f_7061csi.scm",(void*)f_7061},
{"f_7064csi.scm",(void*)f_7064},
{"f_7067csi.scm",(void*)f_7067},
{"f_7070csi.scm",(void*)f_7070},
{"f_7108csi.scm",(void*)f_7108},
{"f_7116csi.scm",(void*)f_7116},
{"f_7073csi.scm",(void*)f_7073},
{"f_6853csi.scm",(void*)f_6853},
{"f_6857csi.scm",(void*)f_6857},
{"f_6861csi.scm",(void*)f_6861},
{"f_6863csi.scm",(void*)f_6863},
{"f_6908csi.scm",(void*)f_6908},
{"f_6920csi.scm",(void*)f_6920},
{"f_6916csi.scm",(void*)f_6916},
{"f_6884csi.scm",(void*)f_6884},
{"f_7076csi.scm",(void*)f_7076},
{"f_6936csi.scm",(void*)f_6936},
{"f_7036csi.scm",(void*)f_7036},
{"f_7000csi.scm",(void*)f_7000},
{"f_6970csi.scm",(void*)f_6970},
{"f_7079csi.scm",(void*)f_7079},
{"f_7046csi.scm",(void*)f_7046},
{"f_7058csi.scm",(void*)f_7058},
{"f_7054csi.scm",(void*)f_7054},
{"f_1313csi.scm",(void*)f_1313},
{"f_6785csi.scm",(void*)f_6785},
{"f_6789csi.scm",(void*)f_6789},
{"f_1316csi.scm",(void*)f_1316},
{"f_6779csi.scm",(void*)f_6779},
{"f_1319csi.scm",(void*)f_1319},
{"f_6626csi.scm",(void*)f_6626},
{"f_6630csi.scm",(void*)f_6630},
{"f_6633csi.scm",(void*)f_6633},
{"f_6636csi.scm",(void*)f_6636},
{"f_6649csi.scm",(void*)f_6649},
{"f_6699csi.scm",(void*)f_6699},
{"f_6710csi.scm",(void*)f_6710},
{"f_6647csi.scm",(void*)f_6647},
{"f_1322csi.scm",(void*)f_1322},
{"f_6350csi.scm",(void*)f_6350},
{"f_6384csi.scm",(void*)f_6384},
{"f_6387csi.scm",(void*)f_6387},
{"f_6613csi.scm",(void*)f_6613},
{"f_6623csi.scm",(void*)f_6623},
{"f_6611csi.scm",(void*)f_6611},
{"f_6390csi.scm",(void*)f_6390},
{"f_6359csi.scm",(void*)f_6359},
{"f_6373csi.scm",(void*)f_6373},
{"f_6377csi.scm",(void*)f_6377},
{"f_6393csi.scm",(void*)f_6393},
{"f_6396csi.scm",(void*)f_6396},
{"f_6399csi.scm",(void*)f_6399},
{"f_6406csi.scm",(void*)f_6406},
{"f_6420csi.scm",(void*)f_6420},
{"f_6430csi.scm",(void*)f_6430},
{"f_6434csi.scm",(void*)f_6434},
{"f_6444csi.scm",(void*)f_6444},
{"f_6460csi.scm",(void*)f_6460},
{"f_6479csi.scm",(void*)f_6479},
{"f_6535csi.scm",(void*)f_6535},
{"f_6546csi.scm",(void*)f_6546},
{"f_6464csi.scm",(void*)f_6464},
{"f_6477csi.scm",(void*)f_6477},
{"f_6450csi.scm",(void*)f_6450},
{"f_6458csi.scm",(void*)f_6458},
{"f_6448csi.scm",(void*)f_6448},
{"f_6418csi.scm",(void*)f_6418},
{"f_1325csi.scm",(void*)f_1325},
{"f_6293csi.scm",(void*)f_6293},
{"f_6333csi.scm",(void*)f_6333},
{"f_6303csi.scm",(void*)f_6303},
{"f_1328csi.scm",(void*)f_1328},
{"f_6217csi.scm",(void*)f_6217},
{"f_6221csi.scm",(void*)f_6221},
{"f_6224csi.scm",(void*)f_6224},
{"f_1331csi.scm",(void*)f_1331},
{"f_6033csi.scm",(void*)f_6033},
{"f_6037csi.scm",(void*)f_6037},
{"f_6040csi.scm",(void*)f_6040},
{"f_6183csi.scm",(void*)f_6183},
{"f_6179csi.scm",(void*)f_6179},
{"f_6042csi.scm",(void*)f_6042},
{"f_6130csi.scm",(void*)f_6130},
{"f_6128csi.scm",(void*)f_6128},
{"f_6098csi.scm",(void*)f_6098},
{"f_6065csi.scm",(void*)f_6065},
{"f_1334csi.scm",(void*)f_1334},
{"f_5843csi.scm",(void*)f_5843},
{"f_5850csi.scm",(void*)f_5850},
{"f_6024csi.scm",(void*)f_6024},
{"f_6022csi.scm",(void*)f_6022},
{"f_5875csi.scm",(void*)f_5875},
{"f_5901csi.scm",(void*)f_5901},
{"f_5929csi.scm",(void*)f_5929},
{"f_5921csi.scm",(void*)f_5921},
{"f_5913csi.scm",(void*)f_5913},
{"f_5873csi.scm",(void*)f_5873},
{"f_1337csi.scm",(void*)f_1337},
{"f_5834csi.scm",(void*)f_5834},
{"f_5838csi.scm",(void*)f_5838},
{"f_1340csi.scm",(void*)f_1340},
{"f_5815csi.scm",(void*)f_5815},
{"f_5819csi.scm",(void*)f_5819},
{"f_5828csi.scm",(void*)f_5828},
{"f_5826csi.scm",(void*)f_5826},
{"f_1343csi.scm",(void*)f_1343},
{"f_5796csi.scm",(void*)f_5796},
{"f_5800csi.scm",(void*)f_5800},
{"f_5809csi.scm",(void*)f_5809},
{"f_5807csi.scm",(void*)f_5807},
{"f_1346csi.scm",(void*)f_1346},
{"f_5668csi.scm",(void*)f_5668},
{"f_5674csi.scm",(void*)f_5674},
{"f_5755csi.scm",(void*)f_5755},
{"f_5684csi.scm",(void*)f_5684},
{"f_5687csi.scm",(void*)f_5687},
{"f_5693csi.scm",(void*)f_5693},
{"f_5700csi.scm",(void*)f_5700},
{"f_5716csi.scm",(void*)f_5716},
{"f_1349csi.scm",(void*)f_1349},
{"f_5525csi.scm",(void*)f_5525},
{"f_5531csi.scm",(void*)f_5531},
{"f_5643csi.scm",(void*)f_5643},
{"f_5616csi.scm",(void*)f_5616},
{"f_5541csi.scm",(void*)f_5541},
{"f_5544csi.scm",(void*)f_5544},
{"f_5550csi.scm",(void*)f_5550},
{"f_5561csi.scm",(void*)f_5561},
{"f_5577csi.scm",(void*)f_5577},
{"f_1352csi.scm",(void*)f_1352},
{"f_5466csi.scm",(void*)f_5466},
{"f_1355csi.scm",(void*)f_1355},
{"f_5295csi.scm",(void*)f_5295},
{"f_5301csi.scm",(void*)f_5301},
{"f_5375csi.scm",(void*)f_5375},
{"f_5378csi.scm",(void*)f_5378},
{"f_5451csi.scm",(void*)f_5451},
{"f_5444csi.scm",(void*)f_5444},
{"f_5436csi.scm",(void*)f_5436},
{"f_5423csi.scm",(void*)f_5423},
{"f_5402csi.scm",(void*)f_5402},
{"f_5311csi.scm",(void*)f_5311},
{"f_1358csi.scm",(void*)f_1358},
{"f_5244csi.scm",(void*)f_5244},
{"f_1361csi.scm",(void*)f_1361},
{"f_5184csi.scm",(void*)f_5184},
{"f_5194csi.scm",(void*)f_5194},
{"f_5213csi.scm",(void*)f_5213},
{"f_5197csi.scm",(void*)f_5197},
{"f_1364csi.scm",(void*)f_1364},
{"f_1367csi.scm",(void*)f_1367},
{"f_1483csi.scm",(void*)f_1483},
{"f_5178csi.scm",(void*)f_5178},
{"f_1720csi.scm",(void*)f_1720},
{"f_1749csi.scm",(void*)f_1749},
{"f_3034csi.scm",(void*)f_3034},
{"f_5170csi.scm",(void*)f_5170},
{"f_5176csi.scm",(void*)f_5176},
{"f_5173csi.scm",(void*)f_5173},
{"f_4429csi.scm",(void*)f_4429},
{"f_5164csi.scm",(void*)f_5164},
{"f_4433csi.scm",(void*)f_4433},
{"f_5160csi.scm",(void*)f_5160},
{"f_4436csi.scm",(void*)f_4436},
{"f_4439csi.scm",(void*)f_4439},
{"f_4442csi.scm",(void*)f_4442},
{"f_5156csi.scm",(void*)f_5156},
{"f_5143csi.scm",(void*)f_5143},
{"f_5103csi.scm",(void*)f_5103},
{"f_5053csi.scm",(void*)f_5053},
{"f_5056csi.scm",(void*)f_5056},
{"f_5059csi.scm",(void*)f_5059},
{"f_5062csi.scm",(void*)f_5062},
{"f_5071csi.scm",(void*)f_5071},
{"f_4445csi.scm",(void*)f_4445},
{"f_4448csi.scm",(void*)f_4448},
{"f_5047csi.scm",(void*)f_5047},
{"f_4451csi.scm",(void*)f_4451},
{"f_4454csi.scm",(void*)f_4454},
{"f_5038csi.scm",(void*)f_5038},
{"f_5034csi.scm",(void*)f_5034},
{"f_4460csi.scm",(void*)f_4460},
{"f_4612csi.scm",(void*)f_4612},
{"f_5023csi.scm",(void*)f_5023},
{"f_5026csi.scm",(void*)f_5026},
{"f_4615csi.scm",(void*)f_4615},
{"f_5014csi.scm",(void*)f_5014},
{"f_5017csi.scm",(void*)f_5017},
{"f_4618csi.scm",(void*)f_4618},
{"f_5011csi.scm",(void*)f_5011},
{"f_5004csi.scm",(void*)f_5004},
{"f_4621csi.scm",(void*)f_4621},
{"f_4991csi.scm",(void*)f_4991},
{"f_4994csi.scm",(void*)f_4994},
{"f_4624csi.scm",(void*)f_4624},
{"f_4985csi.scm",(void*)f_4985},
{"f_4627csi.scm",(void*)f_4627},
{"f_4970csi.scm",(void*)f_4970},
{"f_4973csi.scm",(void*)f_4973},
{"f_4976csi.scm",(void*)f_4976},
{"f_4630csi.scm",(void*)f_4630},
{"f_4967csi.scm",(void*)f_4967},
{"f_4633csi.scm",(void*)f_4633},
{"f_4963csi.scm",(void*)f_4963},
{"f_4636csi.scm",(void*)f_4636},
{"f_4959csi.scm",(void*)f_4959},
{"f_4947csi.scm",(void*)f_4947},
{"f_4955csi.scm",(void*)f_4955},
{"f_4951csi.scm",(void*)f_4951},
{"f_4943csi.scm",(void*)f_4943},
{"f_4640csi.scm",(void*)f_4640},
{"f_4647csi.scm",(void*)f_4647},
{"f_4650csi.scm",(void*)f_4650},
{"f_4877csi.scm",(void*)f_4877},
{"f_4509csi.scm",(void*)f_4509},
{"f_4515csi.scm",(void*)f_4515},
{"f_4537csi.scm",(void*)f_4537},
{"f_4521csi.scm",(void*)f_4521},
{"f_4524csi.scm",(void*)f_4524},
{"f_4530csi.scm",(void*)f_4530},
{"f_4653csi.scm",(void*)f_4653},
{"f_4658csi.scm",(void*)f_4658},
{"f_4810csi.scm",(void*)f_4810},
{"f_4816csi.scm",(void*)f_4816},
{"f_4831csi.scm",(void*)f_4831},
{"f_4842csi.scm",(void*)f_4842},
{"f_4821csi.scm",(void*)f_4821},
{"f_4829csi.scm",(void*)f_4829},
{"f_4803csi.scm",(void*)f_4803},
{"f_4793csi.scm",(void*)f_4793},
{"f_4777csi.scm",(void*)f_4777},
{"f_4767csi.scm",(void*)f_4767},
{"f_4747csi.scm",(void*)f_4747},
{"f_4731csi.scm",(void*)f_4731},
{"f_4715csi.scm",(void*)f_4715},
{"f_4686csi.scm",(void*)f_4686},
{"f_4671csi.scm",(void*)f_4671},
{"f_4542csi.scm",(void*)f_4542},
{"f_4589csi.scm",(void*)f_4589},
{"f_4546csi.scm",(void*)f_4546},
{"f_4549csi.scm",(void*)f_4549},
{"f_4556csi.scm",(void*)f_4556},
{"f_4558csi.scm",(void*)f_4558},
{"f_4581csi.scm",(void*)f_4581},
{"f_4579csi.scm",(void*)f_4579},
{"f_4568csi.scm",(void*)f_4568},
{"f_4575csi.scm",(void*)f_4575},
{"f_4462csi.scm",(void*)f_4462},
{"f_4468csi.scm",(void*)f_4468},
{"f_4495csi.scm",(void*)f_4495},
{"f_4286csi.scm",(void*)f_4286},
{"f_4292csi.scm",(void*)f_4292},
{"f_4314csi.scm",(void*)f_4314},
{"f_4371csi.scm",(void*)f_4371},
{"f_4364csi.scm",(void*)f_4364},
{"f_4330csi.scm",(void*)f_4330},
{"f_4353csi.scm",(void*)f_4353},
{"f_4343csi.scm",(void*)f_4343},
{"f_4347csi.scm",(void*)f_4347},
{"f_4403csi.scm",(void*)f_4403},
{"f_4229csi.scm",(void*)f_4229},
{"f_4235csi.scm",(void*)f_4235},
{"f_4247csi.scm",(void*)f_4247},
{"f_4170csi.scm",(void*)f_4170},
{"f_4174csi.scm",(void*)f_4174},
{"f_4179csi.scm",(void*)f_4179},
{"f_4208csi.scm",(void*)f_4208},
{"f_4195csi.scm",(void*)f_4195},
{"f_3961csi.scm",(void*)f_3961},
{"f_3993csi.scm",(void*)f_3993},
{"f_4168csi.scm",(void*)f_4168},
{"f_4003csi.scm",(void*)f_4003},
{"f_4006csi.scm",(void*)f_4006},
{"f_4078csi.scm",(void*)f_4078},
{"f_4139csi.scm",(void*)f_4139},
{"f_4161csi.scm",(void*)f_4161},
{"f_4157csi.scm",(void*)f_4157},
{"f_4142csi.scm",(void*)f_4142},
{"f_4097csi.scm",(void*)f_4097},
{"f_4115csi.scm",(void*)f_4115},
{"f_4125csi.scm",(void*)f_4125},
{"f_4009csi.scm",(void*)f_4009},
{"f_4012csi.scm",(void*)f_4012},
{"f_4027csi.scm",(void*)f_4027},
{"f_4040csi.scm",(void*)f_4040},
{"f_4043csi.scm",(void*)f_4043},
{"f_4015csi.scm",(void*)f_4015},
{"f_4018csi.scm",(void*)f_4018},
{"f_3964csi.scm",(void*)f_3964},
{"f_3968csi.scm",(void*)f_3968},
{"f_3984csi.scm",(void*)f_3984},
{"f_3800csi.scm",(void*)f_3800},
{"f_3913csi.scm",(void*)f_3913},
{"f_3908csi.scm",(void*)f_3908},
{"f_3802csi.scm",(void*)f_3802},
{"f_3827csi.scm",(void*)f_3827},
{"f_3870csi.scm",(void*)f_3870},
{"f_3880csi.scm",(void*)f_3880},
{"f_3851csi.scm",(void*)f_3851},
{"f_3834csi.scm",(void*)f_3834},
{"f_3805csi.scm",(void*)f_3805},
{"f_3794csi.scm",(void*)f_3794},
{"f_3036csi.scm",(void*)f_3036},
{"f_3040csi.scm",(void*)f_3040},
{"f_3773csi.scm",(void*)f_3773},
{"f_3168csi.scm",(void*)f_3168},
{"f_3267csi.scm",(void*)f_3267},
{"f_3414csi.scm",(void*)f_3414},
{"f_3442csi.scm",(void*)f_3442},
{"f_3451csi.scm",(void*)f_3451},
{"f_3545csi.scm",(void*)f_3545},
{"f_3679csi.scm",(void*)f_3679},
{"f_3694csi.scm",(void*)f_3694},
{"f_3733csi.scm",(void*)f_3733},
{"f_3722csi.scm",(void*)f_3722},
{"f_3718csi.scm",(void*)f_3718},
{"f_3701csi.scm",(void*)f_3701},
{"f_3612csi.scm",(void*)f_3612},
{"f_3617csi.scm",(void*)f_3617},
{"f_3621csi.scm",(void*)f_3621},
{"f_3630csi.scm",(void*)f_3630},
{"f_3665csi.scm",(void*)f_3665},
{"f_3657csi.scm",(void*)f_3657},
{"f_3640csi.scm",(void*)f_3640},
{"f_3576csi.scm",(void*)f_3576},
{"f_3579csi.scm",(void*)f_3579},
{"f_3584csi.scm",(void*)f_3584},
{"f_3564csi.scm",(void*)f_3564},
{"f_3551csi.scm",(void*)f_3551},
{"f_3539csi.scm",(void*)f_3539},
{"f_3458csi.scm",(void*)f_3458},
{"f_3469csi.scm",(void*)f_3469},
{"f_3433csi.scm",(void*)f_3433},
{"f_3374csi.scm",(void*)f_3374},
{"f_3388csi.scm",(void*)f_3388},
{"f_3384csi.scm",(void*)f_3384},
{"f_3330csi.scm",(void*)f_3330},
{"f_3297csi.scm",(void*)f_3297},
{"f_3310csi.scm",(void*)f_3310},
{"f_3300csi.scm",(void*)f_3300},
{"f_3307csi.scm",(void*)f_3307},
{"f_3237csi.scm",(void*)f_3237},
{"f_3243csi.scm",(void*)f_3243},
{"f_3171csi.scm",(void*)f_3171},
{"f_3042csi.scm",(void*)f_3042},
{"f_3165csi.scm",(void*)f_3165},
{"f_3049csi.scm",(void*)f_3049},
{"f_3054csi.scm",(void*)f_3054},
{"f_3077csi.scm",(void*)f_3077},
{"f_3086csi.scm",(void*)f_3086},
{"f_3150csi.scm",(void*)f_3150},
{"f_3096csi.scm",(void*)f_3096},
{"f_3099csi.scm",(void*)f_3099},
{"f_2840csi.scm",(void*)f_2840},
{"f_2848csi.scm",(void*)f_2848},
{"f_2850csi.scm",(void*)f_2850},
{"f_2854csi.scm",(void*)f_2854},
{"f_2857csi.scm",(void*)f_2857},
{"f_2860csi.scm",(void*)f_2860},
{"f_2877csi.scm",(void*)f_2877},
{"f_3020csi.scm",(void*)f_3020},
{"f_3016csi.scm",(void*)f_3016},
{"f_3012csi.scm",(void*)f_3012},
{"f_2979csi.scm",(void*)f_2979},
{"f_2983csi.scm",(void*)f_2983},
{"f_2988csi.scm",(void*)f_2988},
{"f_2996csi.scm",(void*)f_2996},
{"f_2880csi.scm",(void*)f_2880},
{"f_2908csi.scm",(void*)f_2908},
{"f_2916csi.scm",(void*)f_2916},
{"f_2920csi.scm",(void*)f_2920},
{"f_2924csi.scm",(void*)f_2924},
{"f_2928csi.scm",(void*)f_2928},
{"f_2932csi.scm",(void*)f_2932},
{"f_2883csi.scm",(void*)f_2883},
{"f_2886csi.scm",(void*)f_2886},
{"f_2889csi.scm",(void*)f_2889},
{"f_2892csi.scm",(void*)f_2892},
{"f_2862csi.scm",(void*)f_2862},
{"f_2870csi.scm",(void*)f_2870},
{"f_2737csi.scm",(void*)f_2737},
{"f_2741csi.scm",(void*)f_2741},
{"f_2771csi.scm",(void*)f_2771},
{"f_2789csi.scm",(void*)f_2789},
{"f_2828csi.scm",(void*)f_2828},
{"f_2834csi.scm",(void*)f_2834},
{"f_2795csi.scm",(void*)f_2795},
{"f_2803csi.scm",(void*)f_2803},
{"f_2805csi.scm",(void*)f_2805},
{"f_2822csi.scm",(void*)f_2822},
{"f_2777csi.scm",(void*)f_2777},
{"f_2783csi.scm",(void*)f_2783},
{"f_2769csi.scm",(void*)f_2769},
{"f_2766csi.scm",(void*)f_2766},
{"f_2746csi.scm",(void*)f_2746},
{"f_2756csi.scm",(void*)f_2756},
{"f_2759csi.scm",(void*)f_2759},
{"f_2713csi.scm",(void*)f_2713},
{"f_2723csi.scm",(void*)f_2723},
{"f_2717csi.scm",(void*)f_2717},
{"f_2422csi.scm",(void*)f_2422},
{"f_2427csi.scm",(void*)f_2427},
{"f_2430csi.scm",(void*)f_2430},
{"f_2433csi.scm",(void*)f_2433},
{"f_2436csi.scm",(void*)f_2436},
{"f_2447csi.scm",(void*)f_2447},
{"f_2451csi.scm",(void*)f_2451},
{"f_2439csi.scm",(void*)f_2439},
{"f_2442csi.scm",(void*)f_2442},
{"f_2399csi.scm",(void*)f_2399},
{"f_2403csi.scm",(void*)f_2403},
{"f_2407csi.scm",(void*)f_2407},
{"f_2410csi.scm",(void*)f_2410},
{"f_2413csi.scm",(void*)f_2413},
{"f_2371csi.scm",(void*)f_2371},
{"f_2375csi.scm",(void*)f_2375},
{"f_2380csi.scm",(void*)f_2380},
{"f_2390csi.scm",(void*)f_2390},
{"f_2397csi.scm",(void*)f_2397},
{"f_2330csi.scm",(void*)f_2330},
{"f_2336csi.scm",(void*)f_2336},
{"f_2352csi.scm",(void*)f_2352},
{"f_2362csi.scm",(void*)f_2362},
{"f_1792csi.scm",(void*)f_1792},
{"f_1809csi.scm",(void*)f_1809},
{"f_2311csi.scm",(void*)f_2311},
{"f_2315csi.scm",(void*)f_2315},
{"f_2305csi.scm",(void*)f_2305},
{"f_1815csi.scm",(void*)f_1815},
{"f_2291csi.scm",(void*)f_2291},
{"f_2267csi.scm",(void*)f_2267},
{"f_2275csi.scm",(void*)f_2275},
{"f_2270csi.scm",(void*)f_2270},
{"f_2248csi.scm",(void*)f_2248},
{"f_2251csi.scm",(void*)f_2251},
{"f_2254csi.scm",(void*)f_2254},
{"f_2225csi.scm",(void*)f_2225},
{"f_2228csi.scm",(void*)f_2228},
{"f_2235csi.scm",(void*)f_2235},
{"f_2209csi.scm",(void*)f_2209},
{"f_2181csi.scm",(void*)f_2181},
{"f_2158csi.scm",(void*)f_2158},
{"f_2171csi.scm",(void*)f_2171},
{"f_2149csi.scm",(void*)f_2149},
{"f_2145csi.scm",(void*)f_2145},
{"f_2119csi.scm",(void*)f_2119},
{"f_2115csi.scm",(void*)f_2115},
{"f_2111csi.scm",(void*)f_2111},
{"f_2684csi.scm",(void*)f_2684},
{"f_2688csi.scm",(void*)f_2688},
{"f_2707csi.scm",(void*)f_2707},
{"f_2098csi.scm",(void*)f_2098},
{"f_2094csi.scm",(void*)f_2094},
{"f_2090csi.scm",(void*)f_2090},
{"f_2616csi.scm",(void*)f_2616},
{"f_2620csi.scm",(void*)f_2620},
{"f_2665csi.scm",(void*)f_2665},
{"f_2672csi.scm",(void*)f_2672},
{"f_2626csi.scm",(void*)f_2626},
{"f_2647csi.scm",(void*)f_2647},
{"f_2651csi.scm",(void*)f_2651},
{"f_2603csi.scm",(void*)f_2603},
{"f_2077csi.scm",(void*)f_2077},
{"f_2073csi.scm",(void*)f_2073},
{"f_2069csi.scm",(void*)f_2069},
{"f_2562csi.scm",(void*)f_2562},
{"f_2566csi.scm",(void*)f_2566},
{"f_2585csi.scm",(void*)f_2585},
{"f_2056csi.scm",(void*)f_2056},
{"f_2052csi.scm",(void*)f_2052},
{"f_2048csi.scm",(void*)f_2048},
{"f_2481csi.scm",(void*)f_2481},
{"f_2485csi.scm",(void*)f_2485},
{"f_2524csi.scm",(void*)f_2524},
{"f_2528csi.scm",(void*)f_2528},
{"f_2539csi.scm",(void*)f_2539},
{"f_2543csi.scm",(void*)f_2543},
{"f_2533csi.scm",(void*)f_2533},
{"f_2468csi.scm",(void*)f_2468},
{"f_1995csi.scm",(void*)f_1995},
{"f_2028csi.scm",(void*)f_2028},
{"f_2032csi.scm",(void*)f_2032},
{"f_2000csi.scm",(void*)f_2000},
{"f_2004csi.scm",(void*)f_2004},
{"f_2015csi.scm",(void*)f_2015},
{"f_2026csi.scm",(void*)f_2026},
{"f_2019csi.scm",(void*)f_2019},
{"f_2009csi.scm",(void*)f_2009},
{"f_1986csi.scm",(void*)f_1986},
{"f_1961csi.scm",(void*)f_1961},
{"f_1969csi.scm",(void*)f_1969},
{"f_1975csi.scm",(void*)f_1975},
{"f_1979csi.scm",(void*)f_1979},
{"f_1964csi.scm",(void*)f_1964},
{"f_1952csi.scm",(void*)f_1952},
{"f_1942csi.scm",(void*)f_1942},
{"f_1945csi.scm",(void*)f_1945},
{"f_1903csi.scm",(void*)f_1903},
{"f_1906csi.scm",(void*)f_1906},
{"f_1909csi.scm",(void*)f_1909},
{"f_1912csi.scm",(void*)f_1912},
{"f_1888csi.scm",(void*)f_1888},
{"f_1891csi.scm",(void*)f_1891},
{"f_1873csi.scm",(void*)f_1873},
{"f_1876csi.scm",(void*)f_1876},
{"f_1855csi.scm",(void*)f_1855},
{"f_1858csi.scm",(void*)f_1858},
{"f_1861csi.scm",(void*)f_1861},
{"f_1836csi.scm",(void*)f_1836},
{"f_1846csi.scm",(void*)f_1846},
{"f_1839csi.scm",(void*)f_1839},
{"f_1821csi.scm",(void*)f_1821},
{"f_1751csi.scm",(void*)f_1751},
{"f_1755csi.scm",(void*)f_1755},
{"f_1735csi.scm",(void*)f_1735},
{"f_1742csi.scm",(void*)f_1742},
{"f_1722csi.scm",(void*)f_1722},
{"f_1695csi.scm",(void*)f_1695},
{"f_1656csi.scm",(void*)f_1656},
{"f_1680csi.scm",(void*)f_1680},
{"f_1666csi.scm",(void*)f_1666},
{"f_1550csi.scm",(void*)f_1550},
{"f_1554csi.scm",(void*)f_1554},
{"f_1595csi.scm",(void*)f_1595},
{"f_1601csi.scm",(void*)f_1601},
{"f_1608csi.scm",(void*)f_1608},
{"f_1610csi.scm",(void*)f_1610},
{"f_1637csi.scm",(void*)f_1637},
{"f_1620csi.scm",(void*)f_1620},
{"f_1623csi.scm",(void*)f_1623},
{"f_1578csi.scm",(void*)f_1578},
{"f_1592csi.scm",(void*)f_1592},
{"f_1588csi.scm",(void*)f_1588},
{"f_1529csi.scm",(void*)f_1529},
{"f_1502csi.scm",(void*)f_1502},
{"f_1509csi.scm",(void*)f_1509},
{"f_1512csi.scm",(void*)f_1512},
{"f_1518csi.scm",(void*)f_1518},
{"f_1452csi.scm",(void*)f_1452},
{"f_1456csi.scm",(void*)f_1456},
{"f_1440csi.scm",(void*)f_1440},
{"f_1430csi.scm",(void*)f_1430},
{"f_1438csi.scm",(void*)f_1438},
{"f_1401csi.scm",(void*)f_1401},
{"f_1418csi.scm",(void*)f_1418},
{"f_1391csi.scm",(void*)f_1391},
{"f_1399csi.scm",(void*)f_1399},
{"f_1379csi.scm",(void*)f_1379},
{"f_1383csi.scm",(void*)f_1383},
{"f_1386csi.scm",(void*)f_1386},
{"f_1131csi.scm",(void*)f_1131},
{"f_1135csi.scm",(void*)f_1135},
{"f_1172csi.scm",(void*)f_1172},
{"f_1193csi.scm",(void*)f_1193},
{"f_1191csi.scm",(void*)f_1191},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
