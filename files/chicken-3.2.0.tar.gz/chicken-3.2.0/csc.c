/* Generated from csc.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-04-30 11:58
   Version 3.1.10 - linux-unix-gnu-x86	[ manyargs dload ptables applyhook ]
   SVN rev. 10602	compiled 2008-04-30 on galinha (Linux)
   command line: csc.scm -quiet -no-trace -optimize-level 2 -include-path . -no-lambda-info -output-file csc.c
   used units: library eval data_structures extras srfi_69 data_structures srfi_1 srfi_13 utils extras
*/

#include "chicken.h"


#ifndef C_TARGET_CC
# define C_TARGET_CC  C_INSTALL_CC
#endif

#ifndef C_TARGET_CXX
# define C_TARGET_CXX  C_INSTALL_CXX
#endif

#ifndef C_TARGET_CFLAGS
# define C_TARGET_CFLAGS  C_INSTALL_CFLAGS
#endif

#ifndef C_TARGET_LDFLAGS
# define C_TARGET_LDFLAGS  C_INSTALL_LDFLAGS
#endif

#ifndef C_TARGET_BIN_HOME
# define C_TARGET_BIN_HOME  C_INSTALL_BIN_HOME
#endif

#ifndef C_TARGET_LIB_HOME
# define C_TARGET_LIB_HOME  C_INSTALL_LIB_HOME
#endif

#ifndef C_TARGET_STATIC_LIB_HOME
# define C_TARGET_STATIC_LIB_HOME  C_INSTALL_STATIC_LIB_HOME
#endif

#ifndef C_TARGET_INCLUDE_HOME
# define C_TARGET_INCLUDE_HOME  C_INSTALL_INCLUDE_HOME
#endif

#ifndef C_TARGET_SHARE_HOME
# define C_TARGET_SHARE_HOME  C_INSTALL_SHARE_HOME
#endif

#ifndef C_TARGET_RUN_LIB_HOME
# define C_TARGET_RUN_LIB_HOME    C_TARGET_LIB_HOME
#endif

#ifndef C_CHICKEN_PROGRAM
# define C_CHICKEN_PROGRAM     "chicken"
#endif


static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_69_toplevel)
C_externimport void C_ccall C_srfi_69_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_1_toplevel)
C_externimport void C_ccall C_srfi_1_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_13_toplevel)
C_externimport void C_ccall C_srfi_13_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_utils_toplevel)
C_externimport void C_ccall C_utils_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[370];
static double C_possibly_force_alignment;


C_noret_decl(C_toplevel)
C_externexport void C_ccall C_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_383)
static void C_ccall f_383(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_386)
static void C_ccall f_386(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_389)
static void C_ccall f_389(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_392)
static void C_ccall f_392(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_395)
static void C_ccall f_395(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_398)
static void C_ccall f_398(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_401)
static void C_ccall f_401(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_404)
static void C_ccall f_404(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_407)
static void C_ccall f_407(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_410)
static void C_ccall f_410(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3327)
static void C_ccall f_3327(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3323)
static void C_ccall f_3323(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3319)
static void C_ccall f_3319(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3315)
static void C_ccall f_3315(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3311)
static void C_ccall f_3311(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_426)
static void C_fcall f_426(C_word t0,C_word t1) C_noret;
C_noret_decl(f_443)
static void C_ccall f_443(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_447)
static void C_ccall f_447(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3295)
static void C_ccall f_3295(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3291)
static void C_ccall f_3291(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_484)
static void C_ccall f_484(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3277)
static void C_ccall f_3277(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3281)
static void C_ccall f_3281(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3273)
static void C_ccall f_3273(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3269)
static void C_ccall f_3269(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_488)
static void C_ccall f_488(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3259)
static void C_ccall f_3259(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_492)
static void C_ccall f_492(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3249)
static void C_ccall f_3249(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_496)
static void C_ccall f_496(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3236)
static void C_ccall f_3236(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_500)
static void C_ccall f_500(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3223)
static void C_ccall f_3223(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_504)
static void C_ccall f_504(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_535)
static void C_ccall f_535(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_539)
static void C_ccall f_539(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3192)
static void C_ccall f_3192(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_547)
static void C_ccall f_547(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3182)
static void C_ccall f_3182(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_552)
static void C_ccall f_552(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_578)
static void C_ccall f_578(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_582)
static void C_ccall f_582(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3156)
static void C_ccall f_3156(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3160)
static void C_ccall f_3160(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3152)
static void C_ccall f_3152(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3148)
static void C_ccall f_3148(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3144)
static void C_ccall f_3144(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3140)
static void C_ccall f_3140(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_590)
static void C_fcall f_590(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3123)
static void C_ccall f_3123(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3127)
static void C_ccall f_3127(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3119)
static void C_ccall f_3119(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3115)
static void C_ccall f_3115(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3111)
static void C_ccall f_3111(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3107)
static void C_ccall f_3107(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_598)
static void C_fcall f_598(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3094)
static void C_ccall f_3094(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_607)
static void C_ccall f_607(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3071)
static void C_ccall f_3071(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3067)
static void C_ccall f_3067(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3063)
static void C_ccall f_3063(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3037)
static void C_ccall f_3037(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3053)
static void C_ccall f_3053(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3049)
static void C_ccall f_3049(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3045)
static void C_ccall f_3045(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3041)
static void C_ccall f_3041(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3024)
static void C_ccall f_3024(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3020)
static void C_ccall f_3020(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3016)
static void C_ccall f_3016(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3012)
static void C_ccall f_3012(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2996)
static void C_ccall f_2996(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2992)
static void C_ccall f_2992(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2988)
static void C_ccall f_2988(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2984)
static void C_ccall f_2984(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_622)
static void C_fcall f_622(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2971)
static void C_ccall f_2971(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2967)
static void C_ccall f_2967(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2963)
static void C_ccall f_2963(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_720)
static void C_fcall f_720(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_894)
static void C_ccall f_894(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1379)
static void C_fcall f_1379(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1620)
static void C_fcall f_1620(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1623)
static void C_fcall f_1623(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1626)
static void C_fcall f_1626(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2008)
static void C_ccall f_2008(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1677)
static void C_fcall f_1677(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1686)
static void C_fcall f_1686(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1863)
static void C_ccall f_1863(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1971)
static void C_ccall f_1971(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1977)
static void C_ccall f_1977(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1874)
static void C_ccall f_1874(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1885)
static void C_ccall f_1885(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1961)
static void C_ccall f_1961(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1953)
static void C_ccall f_1953(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1936)
static void C_ccall f_1936(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1912)
static void C_fcall f_1912(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1917)
static void C_ccall f_1917(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1899)
static void C_ccall f_1899(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1868)
static void C_ccall f_1868(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1833)
static void C_ccall f_1833(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1764)
static void C_fcall f_1764(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1816)
static void C_ccall f_1816(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1812)
static void C_ccall f_1812(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1797)
static void C_ccall f_1797(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1795)
static void C_ccall f_1795(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1791)
static void C_ccall f_1791(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1768)
static void C_ccall f_1768(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1754)
static void C_ccall f_1754(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1741)
static void C_ccall f_1741(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1724)
static void C_ccall f_1724(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1710)
static void C_ccall f_1710(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1696)
static void C_ccall f_1696(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1658)
static void C_ccall f_1658(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1664)
static void C_ccall f_1664(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1667)
static void C_ccall f_1667(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1613)
static void C_ccall f_1613(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1617)
static void C_ccall f_1617(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1567)
static void C_ccall f_1567(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1597)
static void C_ccall f_1597(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1589)
static void C_ccall f_1589(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1577)
static void C_ccall f_1577(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1556)
static void C_ccall f_1556(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1531)
static void C_ccall f_1531(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1543)
static void C_ccall f_1543(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1535)
static void C_ccall f_1535(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1518)
static void C_ccall f_1518(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1492)
static void C_ccall f_1492(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1504)
static void C_ccall f_1504(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1496)
static void C_ccall f_1496(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1471)
static void C_ccall f_1471(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1475)
static void C_ccall f_1475(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1454)
static void C_ccall f_1454(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1437)
static void C_ccall f_1437(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1420)
static void C_ccall f_1420(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1403)
static void C_ccall f_1403(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1362)
static void C_ccall f_1362(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1352)
static void C_ccall f_1352(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1342)
static void C_ccall f_1342(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1332)
static void C_ccall f_1332(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1322)
static void C_ccall f_1322(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1312)
static void C_ccall f_1312(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1291)
static void C_ccall f_1291(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1267)
static void C_ccall f_1267(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1278)
static void C_ccall f_1278(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1270)
static void C_fcall f_1270(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1254)
static void C_ccall f_1254(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1243)
static void C_ccall f_1243(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1203)
static void C_ccall f_1203(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1207)
static void C_ccall f_1207(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1210)
static void C_ccall f_1210(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1112)
static void C_ccall f_1112(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1130)
static void C_ccall f_1130(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1115)
static void C_fcall f_1115(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1055)
static void C_ccall f_1055(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1043)
static void C_ccall f_1043(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1031)
static void C_ccall f_1031(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1019)
static void C_ccall f_1019(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_986)
static void C_ccall f_986(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_975)
static void C_ccall f_975(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_944)
static void C_ccall f_944(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_937)
static void C_ccall f_937(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_928)
static void C_ccall f_928(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_921)
static void C_ccall f_921(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_909)
static void C_ccall f_909(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_897)
static void C_ccall f_897(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_885)
static void C_ccall f_885(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_852)
static void C_ccall f_852(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_878)
static void C_ccall f_878(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_855)
static void C_ccall f_855(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_871)
static void C_ccall f_871(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_858)
static void C_ccall f_858(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_861)
static void C_ccall f_861(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_730)
static void C_ccall f_730(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_815)
static void C_fcall f_815(C_word t0,C_word t1) C_noret;
C_noret_decl(f_825)
static void C_ccall f_825(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_818)
static void C_fcall f_818(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2086)
static void C_ccall f_2086(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2090)
static void C_ccall f_2090(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2337)
static void C_ccall f_2337(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2340)
static void C_ccall f_2340(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2331)
static void C_fcall f_2331(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2093)
static void C_ccall f_2093(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2096)
static void C_ccall f_2096(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2268)
static void C_ccall f_2268(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2310)
static void C_ccall f_2310(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2276)
static void C_fcall f_2276(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2291)
static void C_fcall f_2291(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2296)
static void C_ccall f_2296(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2280)
static void C_ccall f_2280(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2288)
static void C_ccall f_2288(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2284)
static void C_ccall f_2284(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2272)
static void C_ccall f_2272(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2264)
static void C_ccall f_2264(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2260)
static void C_ccall f_2260(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2256)
static void C_ccall f_2256(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2099)
static void C_ccall f_2099(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2103)
static void C_ccall f_2103(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2107)
static void C_ccall f_2107(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2113)
static void C_ccall f_2113(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2121)
static void C_ccall f_2121(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2125)
static void C_ccall f_2125(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2238)
static void C_ccall f_2238(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2130)
static void C_ccall f_2130(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2199)
static void C_fcall f_2199(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2206)
static void C_ccall f_2206(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2186)
static void C_ccall f_2186(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2132)
static void C_fcall f_2132(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2116)
static void C_ccall f_2116(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2078)
static void C_ccall f_2078(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_777)
static void C_ccall f_777(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_780)
static void C_ccall f_780(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_787)
static void C_ccall f_787(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_733)
static void C_ccall f_733(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2371)
static void C_ccall f_2371(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2375)
static void C_ccall f_2375(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2412)
static void C_ccall f_2412(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2424)
static void C_ccall f_2424(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2416)
static void C_ccall f_2416(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2420)
static void C_ccall f_2420(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2400)
static void C_ccall f_2400(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2396)
static void C_ccall f_2396(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2378)
static void C_ccall f_2378(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2355)
static void C_ccall f_2355(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2369)
static void C_ccall f_2369(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2359)
static void C_ccall f_2359(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_739)
static void C_ccall f_739(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_754)
static void C_ccall f_754(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_771)
static void C_ccall f_771(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_767)
static void C_ccall f_767(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_745)
static void C_ccall f_745(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2572)
static void C_ccall f_2572(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2572)
static void C_ccall f_2572r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2566)
static void C_ccall f_2566(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2564)
static void C_ccall f_2564(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2560)
static void C_ccall f_2560(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2451)
static void C_ccall f_2451(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2454)
static void C_ccall f_2454(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2548)
static void C_ccall f_2548(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2552)
static void C_ccall f_2552(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2556)
static void C_ccall f_2556(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2540)
static void C_ccall f_2540(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2532)
static void C_ccall f_2532(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2528)
static void C_ccall f_2528(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2524)
static void C_ccall f_2524(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2457)
static void C_ccall f_2457(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2469)
static void C_fcall f_2469(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2502)
static void C_ccall f_2502(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2498)
static void C_ccall f_2498(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2494)
static void C_ccall f_2494(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2490)
static void C_ccall f_2490(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2486)
static void C_ccall f_2486(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2482)
static void C_ccall f_2482(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2460)
static void C_ccall f_2460(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_691)
static void C_fcall f_691(C_word t0,C_word t1) C_noret;
C_noret_decl(f_696)
static void C_ccall f_696(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_700)
static void C_ccall f_700(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_652)
static void C_fcall f_652(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_670)
static void C_ccall f_670(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_645)
static void C_fcall f_645(C_word t0,C_word t1) C_noret;
C_noret_decl(f_650)
static void C_ccall f_650(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2953)
static void C_ccall f_2953(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2959)
static void C_ccall f_2959(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2956)
static void C_ccall f_2956(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2937)
static void C_ccall f_2937(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2941)
static void C_ccall f_2941(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2905)
static void C_ccall f_2905(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2909)
static void C_ccall f_2909(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2932)
static void C_ccall f_2932(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2913)
static void C_fcall f_2913(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2916)
static void C_ccall f_2916(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2876)
static void C_ccall f_2876(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2902)
static void C_ccall f_2902(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2888)
static void C_ccall f_2888(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2883)
static void C_ccall f_2883(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2827)
static void C_ccall f_2827(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2829)
static void C_fcall f_2829(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2859)
static void C_fcall f_2859(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2866)
static void C_ccall f_2866(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2852)
static void C_ccall f_2852(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2823)
static void C_ccall f_2823(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2809)
static void C_ccall f_2809(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2819)
static void C_ccall f_2819(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2727)
static void C_fcall f_2727(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2731)
static void C_ccall f_2731(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2779)
static void C_ccall f_2779(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2779)
static void C_ccall f_2779r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2773)
static void C_ccall f_2773(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2742)
static void C_ccall f_2742(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2738)
static void C_ccall f_2738(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2675)
static void C_fcall f_2675(C_word t0) C_noret;
C_noret_decl(f_2721)
static void C_ccall f_2721(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2721)
static void C_ccall f_2721r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2715)
static void C_ccall f_2715(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2713)
static void C_ccall f_2713(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2709)
static void C_ccall f_2709(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2683)
static void C_ccall f_2683(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2578)
static void C_fcall f_2578(C_word t0) C_noret;
C_noret_decl(f_2582)
static void C_ccall f_2582(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2588)
static void C_fcall f_2588(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2593)
static void C_fcall f_2593(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2614)
static void C_ccall f_2614(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2652)
static void C_ccall f_2652(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2634)
static void C_fcall f_2634(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2638)
static void C_fcall f_2638(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2607)
static void C_ccall f_2607(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2611)
static void C_ccall f_2611(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2426)
static void C_fcall f_2426(C_word t0) C_noret;
C_noret_decl(f_2438)
static void C_ccall f_2438(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2434)
static void C_ccall f_2434(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3202)
static void C_ccall f_3202(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3207)
static void C_ccall f_3207(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_470)
static void C_fcall f_470(C_word t0,C_word t1) C_noret;
C_noret_decl(f_477)
static void C_ccall f_477(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_457)
static void C_fcall f_457(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_428)
static void C_fcall f_428(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_439)
static void C_ccall f_439(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_432)
static void C_ccall f_432(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_426)
static void C_fcall trf_426(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_426(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_426(t0,t1);}

C_noret_decl(trf_590)
static void C_fcall trf_590(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_590(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_590(t0,t1);}

C_noret_decl(trf_598)
static void C_fcall trf_598(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_598(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_598(t0,t1);}

C_noret_decl(trf_622)
static void C_fcall trf_622(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_622(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_622(t0,t1);}

C_noret_decl(trf_720)
static void C_fcall trf_720(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_720(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_720(t0,t1,t2);}

C_noret_decl(trf_1379)
static void C_fcall trf_1379(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1379(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1379(t0,t1);}

C_noret_decl(trf_1620)
static void C_fcall trf_1620(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1620(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1620(t0,t1);}

C_noret_decl(trf_1623)
static void C_fcall trf_1623(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1623(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1623(t0,t1);}

C_noret_decl(trf_1626)
static void C_fcall trf_1626(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1626(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1626(t0,t1);}

C_noret_decl(trf_1677)
static void C_fcall trf_1677(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1677(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1677(t0,t1);}

C_noret_decl(trf_1686)
static void C_fcall trf_1686(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1686(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1686(t0,t1);}

C_noret_decl(trf_1912)
static void C_fcall trf_1912(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1912(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1912(t0,t1);}

C_noret_decl(trf_1764)
static void C_fcall trf_1764(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1764(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1764(t0,t1);}

C_noret_decl(trf_1270)
static void C_fcall trf_1270(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1270(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1270(t0,t1);}

C_noret_decl(trf_1115)
static void C_fcall trf_1115(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1115(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1115(t0,t1);}

C_noret_decl(trf_815)
static void C_fcall trf_815(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_815(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_815(t0,t1);}

C_noret_decl(trf_818)
static void C_fcall trf_818(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_818(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_818(t0,t1);}

C_noret_decl(trf_2331)
static void C_fcall trf_2331(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2331(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2331(t0,t1);}

C_noret_decl(trf_2276)
static void C_fcall trf_2276(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2276(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2276(t0,t1);}

C_noret_decl(trf_2291)
static void C_fcall trf_2291(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2291(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2291(t0,t1);}

C_noret_decl(trf_2199)
static void C_fcall trf_2199(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2199(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2199(t0,t1);}

C_noret_decl(trf_2132)
static void C_fcall trf_2132(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2132(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2132(t0,t1);}

C_noret_decl(trf_2469)
static void C_fcall trf_2469(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2469(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2469(t0,t1);}

C_noret_decl(trf_691)
static void C_fcall trf_691(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_691(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_691(t0,t1);}

C_noret_decl(trf_652)
static void C_fcall trf_652(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_652(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_652(t0,t1,t2,t3);}

C_noret_decl(trf_645)
static void C_fcall trf_645(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_645(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_645(t0,t1);}

C_noret_decl(trf_2913)
static void C_fcall trf_2913(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2913(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2913(t0,t1);}

C_noret_decl(trf_2829)
static void C_fcall trf_2829(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2829(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2829(t0,t1,t2);}

C_noret_decl(trf_2859)
static void C_fcall trf_2859(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2859(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2859(t0,t1);}

C_noret_decl(trf_2727)
static void C_fcall trf_2727(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2727(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2727(t0,t1);}

C_noret_decl(trf_2675)
static void C_fcall trf_2675(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2675(void *dummy){
C_word t0=C_pick(0);
C_adjust_stack(-1);
f_2675(t0);}

C_noret_decl(trf_2578)
static void C_fcall trf_2578(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2578(void *dummy){
C_word t0=C_pick(0);
C_adjust_stack(-1);
f_2578(t0);}

C_noret_decl(trf_2588)
static void C_fcall trf_2588(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2588(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2588(t0,t1);}

C_noret_decl(trf_2593)
static void C_fcall trf_2593(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2593(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_2593(t0,t1,t2,t3,t4);}

C_noret_decl(trf_2634)
static void C_fcall trf_2634(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2634(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2634(t0,t1);}

C_noret_decl(trf_2638)
static void C_fcall trf_2638(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2638(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2638(t0,t1);}

C_noret_decl(trf_2426)
static void C_fcall trf_2426(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2426(void *dummy){
C_word t0=C_pick(0);
C_adjust_stack(-1);
f_2426(t0);}

C_noret_decl(trf_470)
static void C_fcall trf_470(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_470(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_470(t0,t1);}

C_noret_decl(trf_457)
static void C_fcall trf_457(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_457(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_457(t0,t1,t2,t3);}

C_noret_decl(trf_428)
static void C_fcall trf_428(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_428(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_428(t0,t1,t2);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr2rv)
static void C_fcall tr2rv(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2rv(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n+1);
t2=C_restore_rest_vector(a,n);
(k)(t0,t1,t2);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_main_entry_point
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("toplevel"));
C_resize_stack(131072);
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(2488)){
C_save(t1);
C_rereclaim2(2488*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,370);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[2]=C_h_intern(&lf[2],7,"mingw32");
lf[4]=C_h_intern(&lf[4],4,"msvc");
lf[6]=C_h_intern(&lf[6],6,"macosx");
lf[10]=C_h_intern(&lf[10],4,"exit");
lf[11]=C_h_intern(&lf[11],7,"fprintf");
lf[12]=C_decode_literal(C_heaptop,"\376B\000\000\011csc: ~\077~%");
lf[13]=C_h_intern(&lf[13],18,"current-error-port");
lf[16]=C_decode_literal(C_heaptop,"\376B\000\000\005-host");
lf[20]=C_h_intern(&lf[20],13,"make-pathname");
lf[22]=C_h_intern(&lf[22],13,"string-append");
lf[23]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[24]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[25]=C_h_intern(&lf[25],10,"string-any");
lf[26]=C_h_intern(&lf[26],16,"char-whitespace\077");
lf[33]=C_decode_literal(C_heaptop,"\376B\000\000\003obj");
lf[34]=C_decode_literal(C_heaptop,"\376B\000\000\001o");
lf[36]=C_decode_literal(C_heaptop,"\376B\000\000\003lib");
lf[37]=C_decode_literal(C_heaptop,"\376B\000\000\001a");
lf[39]=C_decode_literal(C_heaptop,"\376B\000\000\005-out:");
lf[40]=C_decode_literal(C_heaptop,"\376B\000\000\003-o ");
lf[42]=C_decode_literal(C_heaptop,"\376B\000\000\003exe");
lf[43]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[45]=C_decode_literal(C_heaptop,"\376B\000\000\003-Fo");
lf[46]=C_decode_literal(C_heaptop,"\376B\000\000\003-o ");
lf[49]=C_h_intern(&lf[49],26,"\003sysload-dynamic-extension");
lf[50]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\005-DPIC\376\377\016");
lf[51]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\005-fPIC\376\003\000\000\002\376B\000\000\005-DPIC\376\377\016");
lf[84]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\006-quiet\376\377\016");
lf[85]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\014/usr/include\376\003\000\000\002\376B\000\000\000\376\377\016");
lf[87]=C_decode_literal(C_heaptop,"\376B\000\000\002-I");
lf[105]=C_h_intern(&lf[105],18,"string-intersperse");
lf[106]=C_h_intern(&lf[106],7,"\003sysmap");
lf[108]=C_h_intern(&lf[108],6,"append");
lf[110]=C_h_intern(&lf[110],7,"reverse");
lf[111]=C_h_intern(&lf[111],6,"static");
lf[112]=C_h_intern(&lf[112],14,"static-options");
lf[113]=C_h_intern(&lf[113],21,"extension-information");
lf[114]=C_h_intern(&lf[114],15,"repository-path");
lf[116]=C_decode_literal(C_heaptop,"\376B\000\000\010 -static");
lf[117]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[119]=C_h_intern(&lf[119],9,"\003syserror");
lf[121]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000\134\376\003\000\000\002\376\377\012\000\000#\376\377\016");
lf[122]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[123]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[124]=C_h_intern(&lf[124],17,"string-translate*");
lf[125]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376B\000\000\001\042\376B\000\000\002\134\042\376\377\016");
lf[126]=C_h_intern(&lf[126],16,"\003syslist->string");
lf[127]=C_h_intern(&lf[127],5,"cons*");
lf[128]=C_h_intern(&lf[128],16,"\003sysstring->list");
lf[129]=C_h_intern(&lf[129],3,"any");
lf[132]=C_h_intern(&lf[132],6,"printf");
lf[133]=C_decode_literal(C_heaptop,"\376B\000\0006*** Shell command terminated with exit status ~S: ~A~%");
lf[134]=C_h_intern(&lf[134],6,"system");
lf[135]=C_h_intern(&lf[135],5,"print");
lf[137]=C_h_intern(&lf[137],11,"delete-file");
lf[138]=C_decode_literal(C_heaptop,"\376B\000\000\003rm ");
lf[139]=C_h_intern(&lf[139],25,"\003sysimplicit-exit-handler");
lf[140]=C_decode_literal(C_heaptop,"\376B\000\000#not enough arguments to option `~A\047");
lf[141]=C_decode_literal(C_heaptop,"\376B\000\000\013-dynamiclib");
lf[142]=C_decode_literal(C_heaptop,"\376B\000\000\007-bundle");
lf[143]=C_decode_literal(C_heaptop,"\376B\000\000\004-dll");
lf[144]=C_decode_literal(C_heaptop,"\376B\000\000\007-shared");
lf[145]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\012-DC_SHARED\376\377\016");
lf[146]=C_decode_literal(C_heaptop,"\376B\000\000\010-feature");
lf[147]=C_decode_literal(C_heaptop,"\376B\000\000\026chicken-compile-shared");
lf[148]=C_h_intern(&lf[148],12,"\003sysfor-each");
lf[149]=C_decode_literal(C_heaptop,"\376B\000\000+install_name_tool -change libchicken.dylib ");
lf[150]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[151]=C_decode_literal(C_heaptop,"\376B\000\000\020libchicken.dylib");
lf[152]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[153]=C_decode_literal(C_heaptop,"\376B\000\000\003lib");
lf[154]=C_h_intern(&lf[154],17,"\003syspeek-c-string");
lf[155]=C_h_intern(&lf[155],7,"sprintf");
lf[156]=C_decode_literal(C_heaptop,"\376B\000\000\014mv ~A ~A.old");
lf[157]=C_decode_literal(C_heaptop,"\376B\000\000TWarning: output file will overwrite source file `~A\047 - renaming source to `"
"~A.old\047~%");
lf[158]=C_decode_literal(C_heaptop,"\376B\000\000\002-c");
lf[159]=C_h_intern(&lf[159],26,"pathname-replace-extension");
lf[160]=C_h_intern(&lf[160],4,"last");
lf[161]=C_decode_literal(C_heaptop,"\376B\000\000\031no source files specified");
lf[162]=C_h_intern(&lf[162],5,"error");
lf[163]=C_decode_literal(C_heaptop,"\376B\000\000!invalid entry in csc control file");
lf[164]=C_h_intern(&lf[164],12,"post-process");
lf[165]=C_h_intern(&lf[165],9,"c-options");
lf[166]=C_h_intern(&lf[166],12,"link-options");
lf[167]=C_h_intern(&lf[167],9,"read-file");
lf[168]=C_h_intern(&lf[168],9,"read-line");
lf[169]=C_h_intern(&lf[169],20,"with-input-from-file");
lf[170]=C_h_intern(&lf[170],12,"file-exists\077");
lf[171]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[172]=C_h_intern(&lf[172],4,"conc");
lf[173]=C_decode_literal(C_heaptop,"\376B\000\000\006-uses ");
lf[174]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\012-to-stdout\376\377\016");
lf[175]=C_decode_literal(C_heaptop,"\376B\000\000\014-output-file");
lf[176]=C_decode_literal(C_heaptop,"\376B\000\000\003cpp");
lf[177]=C_decode_literal(C_heaptop,"\376B\000\000\001m");
lf[178]=C_decode_literal(C_heaptop,"\376B\000\000\001c");
lf[179]=C_decode_literal(C_heaptop,"\376B\000\000\005#%eof");
lf[180]=C_decode_literal(C_heaptop,"\376B\000\000\003csc");
lf[181]=C_decode_literal(C_heaptop,"\376B\000\000\010-dynamic");
lf[182]=C_h_intern(&lf[182],7,"newline");
lf[183]=C_h_intern(&lf[183],6,"print*");
lf[184]=C_h_intern(&lf[184],5,"-help");
lf[185]=C_h_intern(&lf[185],6,"--help");
lf[186]=C_h_intern(&lf[186],7,"display");
lf[187]=C_decode_literal(C_heaptop,"\376B\000\036\343Usage: csc FILENAME | OPTION ...\012\012  `csc\047 is a driver program for the CHICK"
"EN compiler. Any Scheme, C or object\012  files and all libraries given on the comm"
"and line are translated, compiled or\012  linked as needed.\012\012  General options:\012\012  "
"  -h  -help                   display this text and exit\012    -v                 "
"         show intermediate compilation stages\012    -v2  -verbose               di"
"splay information about translation progress\012    -v3                         dis"
"play information about all compilation stages\012    -V  -version                di"
"splay Scheme compiler version and exit\012    -release                    display r"
"elease number and exit\012\012  File and pathname options:\012\012    -o -output-file FILENA"
"ME    specifies target executable name\012    -I -include-path PATHNAME   specifies"
" alternative path for included files\012    -to-stdout                  write compi"
"ler to stdout (implies -t)\012    -s -shared -dynamic         generate dynamically "
"loadable shared object file\012\012  Language options:\012\012    -D  -DSYMBOL  -feature SYM"
"BOL \012                                register feature identifier\012    -c++       "
"                 Compile via a C++ source file (.cpp) \012    -objc                "
"       Compile via Objective-C source file (.m)\012\012  Syntax related options:\012\012    "
"-i -case-insensitive        don\047t preserve case of read symbols    \012    -K -keyw"
"ord-style STYLE     allow alternative keyword syntax (prefix, suffix or none)\012  "
"  -run-time-macros            macros are made available at run-time\012\012  Translati"
"on options:\012\012    -x  -explicit-use           do not use units `library\047 and `eva"
"l\047 by default\012    -P  -check-syntax           stop compilation after macro-expan"
"sion\012    -A  -analyze-only           stop compilation after first analysis pass\012"
"\012  Debugging options:\012\012    -w  -no-warnings            disable warnings\012    -dis"
"able-warning CLASS      disable specific class of warnings\012    -d0 -d1 -d2 -debu"
"g-level NUMBER\012                                set level of available debugging "
"information\012    -no-trace                   disable rudimentary debugging inform"
"ation\012    -profile                    executable emits profiling information \012  "
"  -accumulate-profile         executable emits profiling information in append m"
"ode\012    -profile-name FILENAME      name of the generated profile information fi"
"le\012    -emit-debug-info            emit additional debug-information\012    -emit-e"
"xports FILENAME      write exported toplevel variables to FILENAME\012    -G  -chec"
"k-imports          look for undefined toplevel variables\012    -import FILENAME   "
"         read externally exported symbols from FILENAME\012\012  Optimization options:"
"\012\012    -O -O1 -O2 -O3 -optimize-level NUMBER\012\011\011\011        enable certain sets of op"
"timization options\012    -optimize-leaf-routines     enable leaf routine optimizat"
"ion\012    -N  -no-usual-integrations  standard procedures may be redefined\012    -u "
" -unsafe                 disable safety checks\012    -b  -block                  e"
"nable block-compilation\012    -disable-interrupts         disable interrupts in co"
"mpiled code\012    -f  -fixnum-arithmetic      assume all numbers are fixnums\012    -"
"Ob  -benchmark-mode        equivalent to \047-block -optimize-level 3 \012            "
"                     -debug-level 0 -fixnum-arithmetic -lambda-lift \012           "
"                      -disable-interrupts\047\012    -lambda-lift                perfo"
"rm lambda-lifting\012    -unsafe-libraries           link with unsafe runtime syste"
"m\012    -disable-stack-overflow-checks  disables detection of stack-overflows\012    "
"-inline                     enable inlining\012    -inline-limit               set "
"inlining threshold\012    -disable-compiler-macros    disable expansion of compiler"
" macros\012\012  Configuration options:\012\012    -unit NAME                  compile file "
"as a library unit\012    -uses NAME                  declare library unit as used.\012"
"    -heap-size NUMBER           specifies heap-size of compiled executable\012    -"
"heap-initial-size NUMBER   specifies heap-size at startup time\012    -heap-growth "
"PERCENTAGE     specifies growth-rate of expanding heap\012    -heap-shrinkage PERCE"
"NTAGE  specifies shrink-rate of contracting heap\012    -nursery NUMBER  -stack-siz"
"e NUMBER\012\011\011                specifies nursery size of compiled executable\012    -X "
"-extend FILENAME         load file before compilation commences\012    -prelude EXP"
"RESSION         add expression to beginning of source file\012    -postlude EXPRESS"
"ION        add expression to end of source file\012    -prologue FILENAME          "
"include file before main source file\012    -epilogue FILENAME          include fil"
"e after main source file\012\012    -e  -embedded               compile as embedded (d"
"on\047t generate `main()\047)\012    -W  -windows                compile as Windows GUI a"
"pplication (MSVC only)\012    -R  -require-extension NAME require extension in comp"
"iled code\012    -E  -extension              compile as extension (dynamic or stati"
"c)\012    -dll -library               compile multiple units into a dynamic library"
"\012\012  Options to other passes:\012\012    -C OPTION                   pass option to C c"
"ompiler\012    -L OPTION                   pass option to linker\012    -I<DIR>       "
"              pass \042-I<DIR>\042 to C compiler (add include path)\012    -L<DIR>       "
"              pass \042-L<DIR>\042 to linker (add library path)\012    -k                "
"          keep intermediate files\012    -c                          stop after com"
"pilation to object files\012    -t                          stop after translation "
"to C\012    -cc COMPILER                select other C compiler than the default on"
"e\012    -cxx COMPILER               select other C++ compiler than the default one"
"\012    -ld COMPILER                select other linker than the default one\012    -l"
"LIBNAME                   link with given library (`libLIBNAME\047 on UNIX,\012       "
"                          `LIBNAME.lib\047 on Windows)                             "
"   \012    -static-libs                link with static CHICKEN libraries\012    -stat"
"ic                     generate completely statically linked executable\012    -sta"
"tic-extensions          link with static extensions (if available)\012    -F<DIR>  "
"                   pass \042-F<DIR>\042 to C compiler (add framework \012                "
"                 header path on Mac OS X)\012    -framework NAME             passed"
" to linker on Mac OS X\012    -rpath PATHNAME             add directory to runtime "
"library search path\012    -Wl,...                     pass linker options\012    -str"
"ip                      strip resulting binary\012\012  Inquiry options:\012\012    -home   "
"                    show home-directory (where support files go)\012    -cflags    "
"                 show required C-compiler flags and exit\012    -ldflags           "
"         show required linker flags and exit\012    -libs                       sho"
"w required libraries and exit\012    -cc-name                    show name of defau"
"lt C compiler used\012    -cxx-name                   show name of default C++ comp"
"iler used\012    -ld-name                    show name of default linker used\012    -"
"dry-run                    just show commands executed, don\047t run them \012        "
"                         (implies `-v\047)\012\012  Obscure options:\012\012    -debug MODES   "
"             display debugging output for the given modes\012    -compiler PATHNAME"
"          use other compiler than default `chicken\047\012    -disable-c-syntax-checks"
"    disable syntax checks of C code fragments\012    -raw                        do"
" not generate implicit init- and exit code\011\011\011       \012    -emit-external-prototyp"
"es-first  emit protoypes for callbacks before foreign\012                          "
"       declarations\012    -keep-shadowed-macros       do not remove shadowed macro"
"\012    -host                       compile for host when configured for cross-comp"
"iling\012\012  Options can be collapsed if unambiguous, so\012\012    -vkfO\012\012  is the same a"
"s\012\012    -v -k -fixnum-arithmetic -optimize\012\012  The contents of the environment var"
"iable CSC_OPTIONS are implicitly\012  passed to every invocation of `csc\047.\012");
lf[188]=C_h_intern(&lf[188],8,"-release");
lf[189]=C_h_intern(&lf[189],15,"chicken-version");
lf[190]=C_h_intern(&lf[190],8,"-version");
lf[191]=C_decode_literal(C_heaptop,"\376B\000\000\011 -version");
lf[192]=C_h_intern(&lf[192],4,"-c++");
lf[193]=C_decode_literal(C_heaptop,"\376B\000\000\017-no-cpp-precomp");
lf[194]=C_h_intern(&lf[194],5,"-objc");
lf[195]=C_h_intern(&lf[195],7,"-static");
lf[196]=C_decode_literal(C_heaptop,"\376B\000\000\010-feature");
lf[197]=C_decode_literal(C_heaptop,"\376B\000\000\026chicken-compile-static");
lf[198]=C_h_intern(&lf[198],12,"-static-libs");
lf[199]=C_decode_literal(C_heaptop,"\376B\000\000\010-feature");
lf[200]=C_decode_literal(C_heaptop,"\376B\000\000\026chicken-compile-static");
lf[201]=C_h_intern(&lf[201],18,"-static-extensions");
lf[202]=C_h_intern(&lf[202],7,"-cflags");
lf[203]=C_h_intern(&lf[203],8,"-ldflags");
lf[204]=C_h_intern(&lf[204],8,"-cc-name");
lf[205]=C_h_intern(&lf[205],9,"-cxx-name");
lf[206]=C_h_intern(&lf[206],8,"-ld-name");
lf[207]=C_h_intern(&lf[207],5,"-home");
lf[208]=C_h_intern(&lf[208],5,"-libs");
lf[209]=C_h_intern(&lf[209],2,"-v");
lf[210]=C_h_intern(&lf[210],3,"-v2");
lf[211]=C_h_intern(&lf[211],8,"-verbose");
lf[212]=C_decode_literal(C_heaptop,"\376B\000\000\010-verbose");
lf[213]=C_h_intern(&lf[213],2,"-w");
lf[214]=C_h_intern(&lf[214],12,"-no-warnings");
lf[215]=C_decode_literal(C_heaptop,"\376B\000\000\002-w");
lf[216]=C_decode_literal(C_heaptop,"\376B\000\000\014-no-warnings");
lf[217]=C_h_intern(&lf[217],3,"-v3");
lf[218]=C_decode_literal(C_heaptop,"\376B\000\000\010-VERBOSE");
lf[219]=C_decode_literal(C_heaptop,"\376B\000\000\002-v");
lf[220]=C_decode_literal(C_heaptop,"\376B\000\000\002-v");
lf[221]=C_decode_literal(C_heaptop,"\376B\000\000\002-Q");
lf[222]=C_decode_literal(C_heaptop,"\376B\000\000\010-verbose");
lf[223]=C_h_intern(&lf[223],2,"-A");
lf[224]=C_h_intern(&lf[224],13,"-analyze-only");
lf[225]=C_decode_literal(C_heaptop,"\376B\000\000\015-analyze-only");
lf[226]=C_h_intern(&lf[226],2,"-P");
lf[227]=C_h_intern(&lf[227],13,"-check-syntax");
lf[228]=C_decode_literal(C_heaptop,"\376B\000\000\015-check-syntax");
lf[229]=C_h_intern(&lf[229],2,"-k");
lf[230]=C_h_intern(&lf[230],2,"-c");
lf[231]=C_h_intern(&lf[231],2,"-t");
lf[232]=C_h_intern(&lf[232],2,"-e");
lf[233]=C_h_intern(&lf[233],9,"-embedded");
lf[234]=C_decode_literal(C_heaptop,"\376B\000\000\014-DC_EMBEDDED");
lf[235]=C_h_intern(&lf[235],18,"-require-extension");
lf[236]=C_h_intern(&lf[236],2,"-R");
lf[237]=C_decode_literal(C_heaptop,"\376B\000\000\022-require-extension");
lf[238]=C_h_intern(&lf[238],8,"-windows");
lf[239]=C_h_intern(&lf[239],2,"-W");
lf[240]=C_decode_literal(C_heaptop,"\376B\000\000\017-DC_WINDOWS_GUI");
lf[241]=C_decode_literal(C_heaptop,"\376B\000\000\012-lkernel32");
lf[242]=C_decode_literal(C_heaptop,"\376B\000\000\010-luser32");
lf[243]=C_decode_literal(C_heaptop,"\376B\000\000\007-lgdi32");
lf[244]=C_decode_literal(C_heaptop,"\376B\000\000\011-mwindows");
lf[245]=C_decode_literal(C_heaptop,"\376B\000\000\017-DC_WINDOWS_GUI");
lf[246]=C_decode_literal(C_heaptop,"\376B\000\000\014kernel32.lib");
lf[247]=C_decode_literal(C_heaptop,"\376B\000\000\012user32.lib");
lf[248]=C_decode_literal(C_heaptop,"\376B\000\000\011gdi32.lib");
lf[249]=C_h_intern(&lf[249],10,"-framework");
lf[250]=C_decode_literal(C_heaptop,"\376B\000\000\012-framework");
lf[251]=C_h_intern(&lf[251],2,"-o");
lf[252]=C_h_intern(&lf[252],2,"-O");
lf[253]=C_h_intern(&lf[253],3,"-O1");
lf[254]=C_decode_literal(C_heaptop,"\376B\000\000\017-optimize-level");
lf[255]=C_decode_literal(C_heaptop,"\376B\000\000\0011");
lf[256]=C_h_intern(&lf[256],3,"-O2");
lf[257]=C_decode_literal(C_heaptop,"\376B\000\000\017-optimize-level");
lf[258]=C_decode_literal(C_heaptop,"\376B\000\000\0012");
lf[259]=C_h_intern(&lf[259],3,"-O3");
lf[260]=C_decode_literal(C_heaptop,"\376B\000\000\017-optimize-level");
lf[261]=C_decode_literal(C_heaptop,"\376B\000\000\0013");
lf[262]=C_h_intern(&lf[262],3,"-d0");
lf[263]=C_decode_literal(C_heaptop,"\376B\000\000\014-debug-level");
lf[264]=C_decode_literal(C_heaptop,"\376B\000\000\0010");
lf[265]=C_h_intern(&lf[265],3,"-d1");
lf[266]=C_decode_literal(C_heaptop,"\376B\000\000\014-debug-level");
lf[267]=C_decode_literal(C_heaptop,"\376B\000\000\0011");
lf[268]=C_h_intern(&lf[268],3,"-d2");
lf[269]=C_decode_literal(C_heaptop,"\376B\000\000\014-debug-level");
lf[270]=C_decode_literal(C_heaptop,"\376B\000\000\0012");
lf[271]=C_h_intern(&lf[271],8,"-dry-run");
lf[272]=C_h_intern(&lf[272],2,"-s");
lf[273]=C_h_intern(&lf[273],4,"-dll");
lf[274]=C_h_intern(&lf[274],8,"-library");
lf[275]=C_h_intern(&lf[275],9,"-compiler");
lf[276]=C_h_intern(&lf[276],3,"-cc");
lf[277]=C_h_intern(&lf[277],4,"-cxx");
lf[278]=C_h_intern(&lf[278],3,"-ld");
lf[279]=C_h_intern(&lf[279],2,"-I");
lf[280]=C_decode_literal(C_heaptop,"\376B\000\000\015-include-path");
lf[281]=C_h_intern(&lf[281],2,"-C");
lf[282]=C_h_intern(&lf[282],12,"string-split");
lf[283]=C_h_intern(&lf[283],6,"-strip");
lf[284]=C_decode_literal(C_heaptop,"\376B\000\000\002-s");
lf[285]=C_h_intern(&lf[285],2,"-L");
lf[286]=C_h_intern(&lf[286],17,"-unsafe-libraries");
lf[287]=C_h_intern(&lf[287],6,"-rpath");
lf[288]=C_h_intern(&lf[288],3,"gnu");
lf[289]=C_decode_literal(C_heaptop,"\376B\000\000\006-Wl,-R");
lf[290]=C_h_intern(&lf[290],14,"build-platform");
lf[291]=C_h_intern(&lf[291],5,"-host");
lf[292]=C_h_intern(&lf[292],1,"-");
lf[293]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\001-\376\377\016");
lf[294]=C_decode_literal(C_heaptop,"\376B\000\000\001a");
lf[295]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-h\376\003\000\000\002\376B\000\000\005-help\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-s\376\003\000\000\002\376B\000\000\007-shared\376\377\016\376\003\000\000\002\376\003\000"
"\000\002\376\001\000\000\002-E\376\003\000\000\002\376B\000\000\012-extension\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-P\376\003\000\000\002\376B\000\000\015-check-syntax\376\377\016\376\003\000\000\002"
"\376\003\000\000\002\376\001\000\000\002-V\376\003\000\000\002\376B\000\000\010-version\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\003-Ob\376\003\000\000\002\376B\000\000\017-benchmark-mode\376\377\016\376"
"\003\000\000\002\376\003\000\000\002\376\001\000\000\002-f\376\003\000\000\002\376B\000\000\022-fixnum-arithmetic\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-D\376\003\000\000\002\376B\000\000\010-featu"
"re\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-i\376\003\000\000\002\376B\000\000\021-case-insensitive\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-K\376\003\000\000\002\376B\000\000\016-"
"keyword-style\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-X\376\003\000\000\002\376B\000\000\007-extend\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-N\376\003\000\000\002\376B\000\000\026"
"-no-usual-integrations\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-G\376\003\000\000\002\376B\000\000\016-check-imports\376\377\016\376\003\000\000\002\376\003\000\000\002\376"
"\001\000\000\002-x\376\003\000\000\002\376B\000\000\015-explicit-use\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-u\376\003\000\000\002\376B\000\000\007-unsafe\376\377\016\376\003\000\000\002\376\003\000\000\002\376"
"\001\000\000\002-b\376\003\000\000\002\376B\000\000\006-block\376\377\016\376\377\016");
lf[296]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\015-explicit-use\376\003\000\000\002\376\001\000\000\011-no-trace\376\003\000\000\002\376\001\000\000\014-no-warnings\376\003\000\000\002\376\001\000\000\026-no-us"
"ual-integrations\376\003\000\000\002\376\001\000\000\027-optimize-leaf-routines\376\003\000\000\002\376\001\000\000\007-unsafe\376\003\000\000\002\376\001\000\000\006-blo"
"ck\376\003\000\000\002\376\001\000\000\023-disable-interrupts\376\003\000\000\002\376\001\000\000\022-fixnum-arithmetic\376\003\000\000\002\376\001\000\000\012-to-stdout\376"
"\003\000\000\002\376\001\000\000\010-profile\376\003\000\000\002\376\001\000\000\004-raw\376\003\000\000\002\376\001\000\000\023-accumulate-profile\376\003\000\000\002\376\001\000\000\015-check-syn"
"tax\376\003\000\000\002\376\001\000\000\021-case-insensitive\376\003\000\000\002\376\001\000\000\017-benchmark-mode\376\003\000\000\002\376\001\000\000\007-shared\376\003\000\000\002\376\001\000"
"\000\020-run-time-macros\376\003\000\000\002\376\001\000\000\017-no-lambda-info\376\003\000\000\002\376\001\000\000\014-lambda-lift\376\003\000\000\002\376\001\000\000\010-dyna"
"mic\376\003\000\000\002\376\001\000\000\036-disable-stack-overflow-checks\376\003\000\000\002\376\001\000\000\020-emit-debug-info\376\003\000\000\002\376\001\000\000\016-"
"check-imports\376\003\000\000\002\376\001\000\000\037-emit-external-prototypes-first\376\003\000\000\002\376\001\000\000\007-inline\376\003\000\000\002\376\001\000\000"
"\012-extension\376\003\000\000\002\376\001\000\000\010-release\376\003\000\000\002\376\001\000\000\022-static-extensions\376\003\000\000\002\376\001\000\000\015-analyze-only"
"\376\003\000\000\002\376\001\000\000\025-keep-shadowed-macros\376\003\000\000\002\376\001\000\000\030-disable-compiler-macros\376\377\016");
lf[297]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006-debug\376\003\000\000\002\376\001\000\000\014-output-file\376\003\000\000\002\376\001\000\000\012-heap-size\376\003\000\000\002\376\001\000\000\010-nursery\376\003\000\000"
"\002\376\001\000\000\013-stack-size\376\003\000\000\002\376\001\000\000\011-compiler\376\003\000\000\002\376\001\000\000\005-unit\376\003\000\000\002\376\001\000\000\005-uses\376\003\000\000\002\376\001\000\000\016-key"
"word-style\376\003\000\000\002\376\001\000\000\017-optimize-level\376\003\000\000\002\376\001\000\000\015-include-path\376\003\000\000\002\376\001\000\000\016-database-si"
"ze\376\003\000\000\002\376\001\000\000\007-extend\376\003\000\000\002\376\001\000\000\010-prelude\376\003\000\000\002\376\001\000\000\011-postlude\376\003\000\000\002\376\001\000\000\011-prologue\376\003\000\000\002"
"\376\001\000\000\011-epilogue\376\003\000\000\002\376\001\000\000\015-inline-limit\376\003\000\000\002\376\001\000\000\015-profile-name\376\003\000\000\002\376\001\000\000\020-disable-w"
"arning\376\003\000\000\002\376\001\000\000\007-import\376\003\000\000\002\376\001\000\000\031-require-static-extension\376\003\000\000\002\376\001\000\000\010-feature\376\003\000\000"
"\002\376\001\000\000\014-debug-level\376\003\000\000\002\376\001\000\000\014-heap-growth\376\003\000\000\002\376\001\000\000\017-heap-shrinkage\376\003\000\000\002\376\001\000\000\022-heap"
"-initial-size\376\003\000\000\002\376\001\000\000\015-emit-exports\376\003\000\000\002\376\001\000\000\022-compress-literals\376\377\016");
lf[298]=C_decode_literal(C_heaptop,"\376B\000\000\010-feature");
lf[299]=C_h_intern(&lf[299],9,"substring");
lf[300]=C_decode_literal(C_heaptop,"\376B\000\000\001-");
lf[301]=C_decode_literal(C_heaptop,"\376B\000\000\023invalid option `~A\047");
lf[302]=C_h_intern(&lf[302],15,"lset-difference");
lf[303]=C_h_intern(&lf[303],6,"char=\077");
lf[304]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000P\376\003\000\000\002\376\377\012\000\000H\376\003\000\000\002\376\377\012\000\000h\376\003\000\000\002\376\377\012\000\000s\376\003\000\000\002\376\377\012\000\000f\376\003\000\000\002\376\377\012\000\000i\376\003\000\000\002\376\377\012\000\000E\376\003\000"
"\000\002\376\377\012\000\000N\376\003\000\000\002\376\377\012\000\000x\376\003\000\000\002\376\377\012\000\000u\376\003\000\000\002\376\377\012\000\000b\376\003\000\000\002\376\377\012\000\000v\376\003\000\000\002\376\377\012\000\000w\376\003\000\000\002\376\377\012\000\000A\376\003\000\000\002\376"
"\377\012\000\000O\376\003\000\000\002\376\377\012\000\000e\376\003\000\000\002\376\377\012\000\000W\376\003\000\000\002\376\377\012\000\000k\376\003\000\000\002\376\377\012\000\000c\376\003\000\000\002\376\377\012\000\000t\376\003\000\000\002\376\377\012\000\000g\376\003\000\000\002\376\377\012\000"
"\000G\376\377\016");
lf[305]=C_decode_literal(C_heaptop,"\376B\000\000\023invalid option `~A\047");
lf[306]=C_decode_literal(C_heaptop,"\376B\000\000\004-Wl,");
lf[307]=C_h_intern(&lf[307],18,"decompose-pathname");
lf[308]=C_decode_literal(C_heaptop,"\376B\000\000\001h");
lf[309]=C_decode_literal(C_heaptop,"\376B\000\000\001c");
lf[310]=C_decode_literal(C_heaptop,"\376B\000\000\003cpp");
lf[311]=C_decode_literal(C_heaptop,"\376B\000\000\001C");
lf[312]=C_decode_literal(C_heaptop,"\376B\000\000\002cc");
lf[313]=C_decode_literal(C_heaptop,"\376B\000\000\003cxx");
lf[314]=C_decode_literal(C_heaptop,"\376B\000\000\003hpp");
lf[315]=C_decode_literal(C_heaptop,"\376B\000\000\017-no-cpp-precomp");
lf[316]=C_decode_literal(C_heaptop,"\376B\000\000\001m");
lf[317]=C_decode_literal(C_heaptop,"\376B\000\000\001M");
lf[318]=C_decode_literal(C_heaptop,"\376B\000\000\002mm");
lf[319]=C_decode_literal(C_heaptop,"\376B\000\000\030file `~A\047 does not exist");
lf[320]=C_decode_literal(C_heaptop,"\376B\000\000\004.scm");
lf[321]=C_decode_literal(C_heaptop,"\376B\000\000\002-:");
lf[322]=C_h_intern(&lf[322],15,"-optimize-level");
lf[323]=C_h_intern(&lf[323],15,"-benchmark-mode");
lf[324]=C_h_intern(&lf[324],10,"-to-stdout");
lf[325]=C_h_intern(&lf[325],7,"-unsafe");
lf[326]=C_h_intern(&lf[326],7,"-shared");
lf[327]=C_h_intern(&lf[327],8,"-dynamic");
lf[328]=C_h_intern(&lf[328],14,"string->symbol");
lf[329]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[330]=C_h_intern(&lf[330],6,"getenv");
lf[331]=C_decode_literal(C_heaptop,"\376B\000\000\013CSC_OPTIONS");
lf[332]=C_decode_literal(C_heaptop,"\376B\000\000\002-L");
lf[333]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[334]=C_decode_literal(C_heaptop,"\376B\000\000\003lib");
lf[335]=C_decode_literal(C_heaptop,"\376B\000\000\011-LIBPATH:");
lf[336]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[337]=C_decode_literal(C_heaptop,"\376B\000\000\003lib");
lf[338]=C_decode_literal(C_heaptop,"\376B\000\000\007 -Wl,-R");
lf[339]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[340]=C_decode_literal(C_heaptop,"\376B\000\000\003lib");
lf[341]=C_decode_literal(C_heaptop,"\376B\000\000\002-L");
lf[342]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[343]=C_decode_literal(C_heaptop,"\376B\000\000\003lib");
lf[344]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[345]=C_decode_literal(C_heaptop,"\376B\000\000\007include");
lf[346]=C_decode_literal(C_heaptop,"\376B\000\000\014libuchicken.");
lf[347]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\012-luchicken\376\377\016");
lf[348]=C_decode_literal(C_heaptop,"\376B\000\000\003lib");
lf[349]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[350]=C_decode_literal(C_heaptop,"\376B\000\000\013libchicken.");
lf[351]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\011-lchicken\376\377\016");
lf[352]=C_decode_literal(C_heaptop,"\376B\000\000\003lib");
lf[353]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[354]=C_decode_literal(C_heaptop,"\376B\000\000\023libuchicken-static.");
lf[355]=C_decode_literal(C_heaptop,"\376B\000\000\014libuchicken.");
lf[356]=C_decode_literal(C_heaptop,"\376B\000\000\022libchicken-static.");
lf[357]=C_decode_literal(C_heaptop,"\376B\000\000\013libchicken.");
lf[358]=C_decode_literal(C_heaptop,"\376B\000\000\004link");
lf[359]=C_decode_literal(C_heaptop,"\376B\000\000\004link");
lf[360]=C_decode_literal(C_heaptop,"\376B\000\000\007chicken");
lf[361]=C_decode_literal(C_heaptop,"\376B\000\000\003bin");
lf[362]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[363]=C_decode_literal(C_heaptop,"\376B\000\000\005share");
lf[364]=C_h_intern(&lf[364],22,"command-line-arguments");
lf[365]=C_decode_literal(C_heaptop,"\376B\000\000\016CHICKEN_PREFIX");
lf[366]=C_h_intern(&lf[366],4,"hpux");
lf[367]=C_h_intern(&lf[367],4,"hppa");
lf[368]=C_h_intern(&lf[368],12,"machine-type");
lf[369]=C_h_intern(&lf[369],16,"software-version");
C_register_lf2(lf,370,create_ptable());
t2=C_mutate(&lf[0],lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_383,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t3);}

/* k381 */
static void C_ccall f_383(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_383,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_386,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k384 in k381 */
static void C_ccall f_386(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_386,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_389,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k387 in k384 in k381 */
static void C_ccall f_389(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_389,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_392,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k390 in k387 in k384 in k381 */
static void C_ccall f_392(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_392,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_395,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_395(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_395,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_398,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_398(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_398,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_401,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_1_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_401(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_401,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_404,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_13_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_404(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_404,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_407,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_utils_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_407(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_407,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_410,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_410(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_410,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3327,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 106  build-platform */
t3=C_retrieve(lf[290]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_3327(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3327,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[2]);
t3=C_mutate(&lf[3],t2);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3323,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 107  build-platform */
t5=C_retrieve(lf[290]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_3323(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3323,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[4]);
t3=C_mutate(&lf[5],t2);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3319,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 108  software-version */
t5=C_retrieve(lf[369]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_3319(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3319,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[6]);
t3=C_mutate(&lf[7],t2);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_426,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3315,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 109  software-version */
t6=C_retrieve(lf[369]);
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}

/* k3313 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_3315(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3315,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[366]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3311,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 110  machine-type */
t4=C_retrieve(lf[368]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}
else{
t3=((C_word*)t0)[2];
f_426(t3,C_SCHEME_FALSE);}}

/* k3309 in k3313 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_3311(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_426(t2,(C_word)C_eqp(t1,lf[367]));}

/* k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_fcall f_426(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_426,NULL,2,t0,t1);}
t2=C_mutate(&lf[8],t1);
t3=C_mutate(&lf[9],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_428,tmp=(C_word)a,a+=2,tmp));
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_443,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 116  getenv */
t5=C_retrieve(lf[330]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[365]);}

/* k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_443(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_443,2,t0,t1);}
t2=C_mutate(&lf[14],t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_447,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 117  command-line-arguments */
t4=C_retrieve(lf[364]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_447(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_447,2,t0,t1);}
t2=C_mutate(&lf[15],t1);
t3=(C_word)C_i_member(lf[16],C_retrieve2(lf[15],"arguments"));
t4=C_mutate(&lf[17],t3);
t5=(C_word)C_fudge(C_fix(39));
t6=C_mutate(&lf[18],t5);
t7=C_mutate(&lf[19],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_457,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate(&lf[21],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_470,tmp=(C_word)a,a+=2,tmp));
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_484,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3291,a[2]=t9,tmp=(C_word)a,a+=3,tmp);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3295,a[2]=t10,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[17],"host-mode"))){
/* ##sys#peek-c-string */
t12=*((C_word*)lf[154]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t11,C_mpointer(&a,(void*)C_INSTALL_SHARE_HOME),C_fix(0));}
else{
/* ##sys#peek-c-string */
t12=*((C_word*)lf[154]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t11,C_mpointer(&a,(void*)C_TARGET_SHARE_HOME),C_fix(0));}}

/* k3293 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_3295(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 133  prefix */
f_457(((C_word*)t0)[2],lf[362],lf[363],t1);}

/* k3289 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_3291(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 132  quotewrap */
f_470(((C_word*)t0)[2],t1);}

/* k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_484(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_484,2,t0,t1);}
t2=C_mutate(&lf[27],t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_488,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3269,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3273,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3277,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[17],"host-mode"))){
/* ##sys#peek-c-string */
t7=*((C_word*)lf[154]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,C_mpointer(&a,(void*)C_INSTALL_BIN_HOME),C_fix(0));}
else{
/* ##sys#peek-c-string */
t7=*((C_word*)lf[154]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,C_mpointer(&a,(void*)C_TARGET_BIN_HOME),C_fix(0));}}

/* k3275 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_3277(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3277,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3281,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* ##sys#peek-c-string */
t3=*((C_word*)lf[154]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_CHICKEN_PROGRAM),C_fix(0));}

/* k3279 in k3275 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_3281(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 138  make-pathname */
t2=C_retrieve(lf[20]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3271 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_3273(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 137  prefix */
f_457(((C_word*)t0)[2],lf[360],lf[361],t1);}

/* k3267 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_3269(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 136  quotewrap */
f_470(((C_word*)t0)[2],t1);}

/* k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_488(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_488,2,t0,t1);}
t2=C_mutate(&lf[28],t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_492,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3259,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[17],"host-mode"))){
/* ##sys#peek-c-string */
t5=*((C_word*)lf[154]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_INSTALL_CC),C_fix(0));}
else{
/* ##sys#peek-c-string */
t5=*((C_word*)lf[154]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_TARGET_CC),C_fix(0));}}

/* k3257 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_3259(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 142  quotewrap */
f_470(((C_word*)t0)[2],t1);}

/* k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_492(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_492,2,t0,t1);}
t2=C_mutate(&lf[29],t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_496,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3249,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[17],"host-mode"))){
/* ##sys#peek-c-string */
t5=*((C_word*)lf[154]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_INSTALL_CXX),C_fix(0));}
else{
/* ##sys#peek-c-string */
t5=*((C_word*)lf[154]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_TARGET_CXX),C_fix(0));}}

/* k3247 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_3249(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 143  quotewrap */
f_470(((C_word*)t0)[2],t1);}

/* k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_496(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_496,2,t0,t1);}
t2=C_mutate(&lf[30],t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_500,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3236,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[5],"msvc"))){
t5=t4;
f_3236(2,t5,lf[359]);}
else{
if(C_truep(C_retrieve2(lf[17],"host-mode"))){
/* ##sys#peek-c-string */
t5=*((C_word*)lf[154]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_INSTALL_CC),C_fix(0));}
else{
/* ##sys#peek-c-string */
t5=*((C_word*)lf[154]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_TARGET_CC),C_fix(0));}}}

/* k3234 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_3236(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 144  quotewrap */
f_470(((C_word*)t0)[2],t1);}

/* k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_500(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_500,2,t0,t1);}
t2=C_mutate(&lf[31],t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_504,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3223,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[5],"msvc"))){
t5=t4;
f_3223(2,t5,lf[358]);}
else{
if(C_truep(C_retrieve2(lf[17],"host-mode"))){
/* ##sys#peek-c-string */
t5=*((C_word*)lf[154]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_INSTALL_CXX),C_fix(0));}
else{
/* ##sys#peek-c-string */
t5=*((C_word*)lf[154]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_TARGET_CXX),C_fix(0));}}}

/* k3221 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_3223(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 145  quotewrap */
f_470(((C_word*)t0)[2],t1);}

/* k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_504(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_504,2,t0,t1);}
t2=C_mutate(&lf[32],t1);
t3=(C_truep(C_retrieve2(lf[5],"msvc"))?lf[33]:lf[34]);
t4=C_mutate(&lf[35],t3);
t5=(C_truep(C_retrieve2(lf[5],"msvc"))?lf[36]:lf[37]);
t6=C_mutate(&lf[38],t5);
t7=(C_truep(C_retrieve2(lf[5],"msvc"))?lf[39]:lf[40]);
t8=C_mutate(&lf[41],t7);
t9=(C_truep(C_retrieve2(lf[5],"msvc"))?lf[42]:lf[43]);
t10=C_mutate(&lf[44],t9);
t11=(C_truep(C_retrieve2(lf[5],"msvc"))?lf[45]:lf[46]);
t12=C_mutate(&lf[47],t11);
t13=C_mutate(&lf[48],C_retrieve(lf[49]));
t14=(C_truep(lf[3])?lf[3]:C_retrieve2(lf[5],"msvc"));
t15=(C_truep(t14)?lf[50]:lf[51]);
t16=C_mutate(&lf[52],t15);
t17=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_535,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t18=(C_truep(C_retrieve2(lf[5],"msvc"))?lf[356]:lf[357]);
/* csc.scm: 156  string-append */
t19=*((C_word*)lf[22]+1);
((C_proc4)C_retrieve_proc(t19))(4,t19,t17,t18,C_retrieve2(lf[38],"library-extension"));}

/* k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_535(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_535,2,t0,t1);}
t2=C_mutate(&lf[53],t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_539,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(C_truep(C_retrieve2(lf[5],"msvc"))?lf[354]:lf[355]);
/* csc.scm: 159  string-append */
t5=*((C_word*)lf[22]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t4,C_retrieve2(lf[38],"library-extension"));}

/* k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_539(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_539,2,t0,t1);}
t2=C_mutate(&lf[54],t1);
t3=(C_truep(lf[3])?(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3207,tmp=(C_word)a,a+=2,tmp):(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3202,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate(&lf[55],t3);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_547,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3192,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[17],"host-mode"))){
/* ##sys#peek-c-string */
t7=*((C_word*)lf[154]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,C_mpointer(&a,(void*)C_INSTALL_CFLAGS),C_fix(0));}
else{
/* ##sys#peek-c-string */
t7=*((C_word*)lf[154]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,C_mpointer(&a,(void*)C_TARGET_CFLAGS),C_fix(0));}}

/* k3190 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_3192(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 168  string-split */
t2=C_retrieve(lf[282]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_547(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_547,2,t0,t1);}
t2=C_mutate(&lf[56],t1);
t3=C_mutate(&lf[57],C_retrieve2(lf[56],"default-compilation-optimization-options"));
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_552,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3182,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[17],"host-mode"))){
/* ##sys#peek-c-string */
t6=*((C_word*)lf[154]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,C_mpointer(&a,(void*)C_INSTALL_LDFLAGS),C_fix(0));}
else{
/* ##sys#peek-c-string */
t6=*((C_word*)lf[154]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,C_mpointer(&a,(void*)C_TARGET_LDFLAGS),C_fix(0));}}

/* k3180 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_3182(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 170  string-split */
t2=C_retrieve(lf[282]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_552(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_552,2,t0,t1);}
t2=C_mutate(&lf[58],t1);
t3=C_mutate(&lf[59],C_retrieve2(lf[58],"default-linking-optimization-options"));
t4=lf[60]=C_SCHEME_END_OF_LIST;;
t5=lf[61]=C_SCHEME_END_OF_LIST;;
t6=lf[62]=C_SCHEME_END_OF_LIST;;
t7=lf[63]=C_SCHEME_END_OF_LIST;;
t8=lf[64]=C_SCHEME_END_OF_LIST;;
t9=lf[65]=C_SCHEME_FALSE;;
t10=lf[66]=C_SCHEME_FALSE;;
t11=lf[67]=C_SCHEME_FALSE;;
t12=lf[68]=C_SCHEME_FALSE;;
t13=lf[69]=C_SCHEME_FALSE;;
t14=lf[70]=C_SCHEME_FALSE;;
t15=lf[71]=C_SCHEME_FALSE;;
t16=lf[72]=C_SCHEME_FALSE;;
t17=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_578,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[17],"host-mode"))){
/* ##sys#peek-c-string */
t18=*((C_word*)lf[154]+1);
((C_proc4)(void*)(*((C_word*)t18+1)))(4,t18,t17,C_mpointer(&a,(void*)C_INSTALL_MORE_STATIC_LIBS),C_fix(0));}
else{
/* ##sys#peek-c-string */
t18=*((C_word*)lf[154]+1);
((C_proc4)(void*)(*((C_word*)t18+1)))(4,t18,t17,C_mpointer(&a,(void*)C_TARGET_MORE_STATIC_LIBS),C_fix(0));}}

/* k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_578(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_578,2,t0,t1);}
t2=C_mutate(&lf[73],t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_582,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[17],"host-mode"))){
/* ##sys#peek-c-string */
t4=*((C_word*)lf[154]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)C_INSTALL_MORE_LIBS),C_fix(0));}
else{
/* ##sys#peek-c-string */
t4=*((C_word*)lf[154]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)C_TARGET_MORE_LIBS),C_fix(0));}}

/* k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_582(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_582,2,t0,t1);}
t2=C_mutate(&lf[74],t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3144,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3148,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3152,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3156,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[17],"host-mode"))){
/* ##sys#peek-c-string */
t7=*((C_word*)lf[154]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,C_mpointer(&a,(void*)C_INSTALL_LIB_HOME),C_fix(0));}
else{
/* ##sys#peek-c-string */
t7=*((C_word*)lf[154]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,C_mpointer(&a,(void*)C_TARGET_LIB_HOME),C_fix(0));}}

/* k3154 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_3156(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3156,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3160,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 241  string-append */
t3=*((C_word*)lf[22]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[353],C_retrieve2(lf[53],"default-library"));}

/* k3158 in k3154 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_3160(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 239  string-append */
t2=*((C_word*)lf[22]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3150 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_3152(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 238  prefix */
f_457(((C_word*)t0)[2],C_retrieve2(lf[53],"default-library"),lf[352],t1);}

/* k3146 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_3148(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 237  quotewrap */
f_470(((C_word*)t0)[2],t1);}

/* k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_3144(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3144,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=C_mutate(&lf[75],t2);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_590,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[5],"msvc"))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3140,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 243  string-append */
t6=*((C_word*)lf[22]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,lf[350],C_retrieve2(lf[38],"library-extension"));}
else{
t5=t4;
f_590(t5,lf[351]);}}

/* k3138 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_3140(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3140,2,t0,t1);}
t2=((C_word*)t0)[2];
f_590(t2,(C_word)C_a_i_list(&a,1,t1));}

/* k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_fcall f_590(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_590,NULL,2,t0,t1);}
t2=C_mutate(&lf[76],t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3111,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3115,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3119,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3123,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[17],"host-mode"))){
/* ##sys#peek-c-string */
t7=*((C_word*)lf[154]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,C_mpointer(&a,(void*)C_INSTALL_LIB_HOME),C_fix(0));}
else{
/* ##sys#peek-c-string */
t7=*((C_word*)lf[154]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,C_mpointer(&a,(void*)C_TARGET_LIB_HOME),C_fix(0));}}

/* k3121 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_3123(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3123,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3127,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 251  string-append */
t3=*((C_word*)lf[22]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[349],C_retrieve2(lf[54],"default-unsafe-library"));}

/* k3125 in k3121 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_3127(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 249  string-append */
t2=*((C_word*)lf[22]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3117 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_3119(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 248  prefix */
f_457(((C_word*)t0)[2],C_retrieve2(lf[54],"default-unsafe-library"),lf[348],t1);}

/* k3113 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_3115(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 247  quotewrap */
f_470(((C_word*)t0)[2],t1);}

/* k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_3111(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3111,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=C_mutate(&lf[77],t2);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_598,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[5],"msvc"))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3107,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 253  string-append */
t6=*((C_word*)lf[22]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,lf[346],C_retrieve2(lf[38],"library-extension"));}
else{
t5=t4;
f_598(t5,lf[347]);}}

/* k3105 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_3107(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3107,2,t0,t1);}
t2=((C_word*)t0)[2];
f_598(t2,(C_word)C_a_i_list(&a,1,t1));}

/* k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_fcall f_598(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_598,NULL,2,t0,t1);}
t2=C_mutate(&lf[78],t1);
t3=C_mutate(&lf[79],C_retrieve2(lf[75],"default-library-files"));
t4=C_mutate(&lf[80],C_retrieve2(lf[76],"default-shared-library-files"));
t5=C_mutate(&lf[81],C_retrieve2(lf[75],"default-library-files"));
t6=C_mutate(&lf[82],C_retrieve2(lf[76],"default-shared-library-files"));
t7=C_mutate(&lf[83],lf[84]);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_607,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3094,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[17],"host-mode"))){
/* ##sys#peek-c-string */
t10=*((C_word*)lf[154]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t9,C_mpointer(&a,(void*)C_INSTALL_INCLUDE_HOME),C_fix(0));}
else{
/* ##sys#peek-c-string */
t10=*((C_word*)lf[154]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t9,C_mpointer(&a,(void*)C_TARGET_INCLUDE_HOME),C_fix(0));}}

/* k3092 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_3094(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 263  prefix */
f_457(((C_word*)t0)[2],lf[344],lf[345],t1);}

/* k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_607(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word ab[63],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_607,2,t0,t1);}
t2=(C_word)C_i_member(t1,lf[85]);
t3=(C_truep(t2)?C_SCHEME_FALSE:t1);
t4=C_mutate(&lf[86],t3);
t5=(C_truep(C_retrieve2(lf[86],"include-dir"))?(C_word)C_a_i_list(&a,2,lf[87],C_retrieve2(lf[86],"include-dir")):C_SCHEME_END_OF_LIST);
t6=C_mutate(&lf[88],t5);
t7=C_mutate(&lf[89],C_retrieve2(lf[56],"default-compilation-optimization-options"));
t8=C_mutate(&lf[90],C_retrieve2(lf[58],"default-linking-optimization-options"));
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_622,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t10=(C_truep(C_retrieve2(lf[7],"osx"))?C_retrieve2(lf[7],"osx"):(C_truep(C_retrieve2(lf[8],"hpux-hppa"))?C_retrieve2(lf[8],"hpux-hppa"):lf[3]));
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2984,a[2]=t9,tmp=(C_word)a,a+=3,tmp);
t12=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2988,a[2]=t11,tmp=(C_word)a,a+=3,tmp);
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2992,a[2]=t12,tmp=(C_word)a,a+=3,tmp);
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2996,a[2]=t13,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[17],"host-mode"))){
/* ##sys#peek-c-string */
t15=*((C_word*)lf[154]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t14,C_mpointer(&a,(void*)C_INSTALL_LIB_HOME),C_fix(0));}
else{
/* ##sys#peek-c-string */
t15=*((C_word*)lf[154]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t14,C_mpointer(&a,(void*)C_TARGET_LIB_HOME),C_fix(0));}}
else{
if(C_truep(C_retrieve2(lf[5],"msvc"))){
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3012,a[2]=t9,tmp=(C_word)a,a+=3,tmp);
t12=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3016,a[2]=t11,tmp=(C_word)a,a+=3,tmp);
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3020,a[2]=t12,tmp=(C_word)a,a+=3,tmp);
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3024,a[2]=t13,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[17],"host-mode"))){
/* ##sys#peek-c-string */
t15=*((C_word*)lf[154]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t14,C_mpointer(&a,(void*)C_INSTALL_LIB_HOME),C_fix(0));}
else{
/* ##sys#peek-c-string */
t15=*((C_word*)lf[154]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t14,C_mpointer(&a,(void*)C_TARGET_LIB_HOME),C_fix(0));}}
else{
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3037,a[2]=t9,tmp=(C_word)a,a+=3,tmp);
t12=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3063,a[2]=t11,tmp=(C_word)a,a+=3,tmp);
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3067,a[2]=t12,tmp=(C_word)a,a+=3,tmp);
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3071,a[2]=t13,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[17],"host-mode"))){
/* ##sys#peek-c-string */
t15=*((C_word*)lf[154]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t14,C_mpointer(&a,(void*)C_INSTALL_LIB_HOME),C_fix(0));}
else{
/* ##sys#peek-c-string */
t15=*((C_word*)lf[154]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t14,C_mpointer(&a,(void*)C_TARGET_LIB_HOME),C_fix(0));}}}}

/* k3069 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_3071(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 291  prefix */
f_457(((C_word*)t0)[2],lf[342],lf[343],t1);}

/* k3065 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_3067(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 291  quotewrap */
f_470(((C_word*)t0)[2],t1);}

/* k3061 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_3063(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 291  conc */
t2=C_retrieve(lf[172]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[341],t1);}

/* k3035 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_3037(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3037,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3041,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3045,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3049,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3053,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[17],"host-mode"))){
/* ##sys#peek-c-string */
t6=*((C_word*)lf[154]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,C_mpointer(&a,(void*)C_INSTALL_LIB_HOME),C_fix(0));}
else{
/* ##sys#peek-c-string */
t6=*((C_word*)lf[154]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,C_mpointer(&a,(void*)C_TARGET_RUN_LIB_HOME),C_fix(0));}}

/* k3051 in k3035 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_3053(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 295  prefix */
f_457(((C_word*)t0)[2],lf[339],lf[340],t1);}

/* k3047 in k3035 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_3049(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 295  quotewrap */
f_470(((C_word*)t0)[2],t1);}

/* k3043 in k3035 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_3045(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 295  conc */
t2=C_retrieve(lf[172]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[338],t1);}

/* k3039 in k3035 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_3041(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3041,2,t0,t1);}
t2=((C_word*)t0)[3];
f_622(t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[2],t1));}

/* k3022 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_3024(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 285  prefix */
f_457(((C_word*)t0)[2],lf[336],lf[337],t1);}

/* k3018 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_3020(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 284  quotewrap */
f_470(((C_word*)t0)[2],t1);}

/* k3014 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_3016(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 284  conc */
t2=C_retrieve(lf[172]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[335],t1);}

/* k3010 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_3012(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3012,2,t0,t1);}
t2=((C_word*)t0)[2];
f_622(t2,(C_word)C_a_i_list(&a,1,t1));}

/* k2994 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_2996(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 279  prefix */
f_457(((C_word*)t0)[2],lf[333],lf[334],t1);}

/* k2990 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_2992(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 278  quotewrap */
f_470(((C_word*)t0)[2],t1);}

/* k2986 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_2988(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 278  conc */
t2=C_retrieve(lf[172]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[332],t1);}

/* k2982 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_2984(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2984,2,t0,t1);}
t2=((C_word*)t0)[2];
f_622(t2,(C_word)C_a_i_list(&a,1,t1));}

/* k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_fcall f_622(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word ab[26],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_622,NULL,2,t0,t1);}
t2=C_mutate(&lf[91],t1);
t3=lf[92]=C_SCHEME_FALSE;;
t4=lf[93]=C_SCHEME_FALSE;;
t5=lf[94]=C_SCHEME_FALSE;;
t6=lf[95]=C_SCHEME_FALSE;;
t7=lf[96]=C_SCHEME_FALSE;;
t8=lf[97]=C_SCHEME_FALSE;;
t9=lf[98]=C_SCHEME_FALSE;;
t10=lf[99]=C_SCHEME_FALSE;;
t11=lf[100]=C_SCHEME_FALSE;;
t12=lf[101]=C_SCHEME_FALSE;;
t13=lf[102]=C_SCHEME_END_OF_LIST;;
t14=lf[103]=C_SCHEME_FALSE;;
t15=C_mutate(&lf[104],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2426,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate(&lf[109],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2578,tmp=(C_word)a,a+=2,tmp));
t17=C_mutate(&lf[115],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2675,tmp=(C_word)a,a+=2,tmp));
t18=C_mutate(&lf[118],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2727,tmp=(C_word)a,a+=2,tmp));
t19=C_mutate(&lf[120],lf[121]);
t20=C_mutate(&lf[107],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2876,tmp=(C_word)a,a+=2,tmp));
t21=lf[130]=C_SCHEME_FALSE;;
t22=C_mutate(&lf[131],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2905,tmp=(C_word)a,a+=2,tmp));
t23=C_mutate(&lf[136],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2937,tmp=(C_word)a,a+=2,tmp));
t24=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2953,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t25=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2963,a[2]=t24,tmp=(C_word)a,a+=3,tmp);
t26=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2967,a[2]=t25,tmp=(C_word)a,a+=3,tmp);
t27=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2971,a[2]=t26,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 952  getenv */
t28=C_retrieve(lf[330]);
((C_proc3)C_retrieve_proc(t28))(3,t28,t27,lf[331]);}

/* k2969 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_2971(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?t1:lf[329]);
/* csc.scm: 952  string-split */
t3=C_retrieve(lf[282]);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],t2);}

/* k2965 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_2967(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 952  append */
t2=*((C_word*)lf[108]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_retrieve2(lf[15],"arguments"));}

/* k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_2963(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2963,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_645,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_652,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_691,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_720,a[2]=t4,a[3]=t3,a[4]=t2,a[5]=t6,tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_720(t8,((C_word*)t0)[2],t1);}

/* loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_fcall f_720(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[20],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_720,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_730,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[68],"inquiry-only"))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_852,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[69],"show-cflags"))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_885,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 501  compiler-options */
f_2426(t5);}
else{
t5=t4;
f_852(2,t5,C_SCHEME_UNDEFINED);}}
else{
t4=t3;
f_730(2,t4,C_SCHEME_UNDEFINED);}}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=t4;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_894,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t6,a[7]=t1,a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
/* csc.scm: 539  string->symbol */
t8=*((C_word*)lf[328]+1);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t3);}}

/* k892 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_894(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word t98;
C_word t99;
C_word t100;
C_word t101;
C_word ab[117],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_894,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_897,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_eqp(t1,lf[184]);
t4=(C_truep(t3)?t3:(C_word)C_eqp(t1,lf[185]));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_909,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 317  display */
t6=*((C_word*)lf[186]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,lf[187]);}
else{
t5=(C_word)C_eqp(t1,lf[188]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_921,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_928,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 545  chicken-version */
t8=C_retrieve(lf[189]);
((C_proc2)C_retrieve_proc(t8))(2,t8,t7);}
else{
t6=(C_word)C_eqp(t1,lf[190]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_937,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_944,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 548  sprintf */
t9=C_retrieve(lf[155]);
((C_proc4)C_retrieve_proc(t9))(4,t9,t8,C_retrieve2(lf[28],"translator"),lf[191]);}
else{
t7=(C_word)C_eqp(t1,lf[192]);
if(C_truep(t7)){
t8=lf[65]=C_SCHEME_TRUE;;
if(C_truep(C_retrieve2(lf[7],"osx"))){
t9=(C_word)C_a_i_cons(&a,2,lf[193],C_retrieve2(lf[88],"compile-options"));
t10=C_mutate(&lf[88],t9);
t11=t2;
f_897(2,t11,t10);}
else{
t9=t2;
f_897(2,t9,C_SCHEME_UNDEFINED);}}
else{
t8=(C_word)C_eqp(t1,lf[194]);
if(C_truep(t8)){
t9=lf[66]=C_SCHEME_TRUE;;
t10=t2;
f_897(2,t10,t9);}
else{
t9=(C_word)C_eqp(t1,lf[195]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_975,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 556  cons* */
t11=C_retrieve(lf[127]);
((C_proc5)C_retrieve_proc(t11))(5,t11,t10,lf[196],lf[197],C_retrieve2(lf[83],"translate-options"));}
else{
t10=(C_word)C_eqp(t1,lf[198]);
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_986,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 559  cons* */
t12=C_retrieve(lf[127]);
((C_proc5)C_retrieve_proc(t12))(5,t12,t11,lf[199],lf[200],C_retrieve2(lf[83],"translate-options"));}
else{
t11=(C_word)C_eqp(t1,lf[201]);
if(C_truep(t11)){
t12=lf[101]=C_SCHEME_TRUE;;
t13=t2;
f_897(2,t13,t12);}
else{
t12=(C_word)C_eqp(t1,lf[202]);
if(C_truep(t12)){
t13=lf[68]=C_SCHEME_TRUE;;
t14=lf[69]=C_SCHEME_TRUE;;
t15=t2;
f_897(2,t15,t14);}
else{
t13=(C_word)C_eqp(t1,lf[203]);
if(C_truep(t13)){
t14=lf[68]=C_SCHEME_TRUE;;
t15=lf[70]=C_SCHEME_TRUE;;
t16=t2;
f_897(2,t16,t15);}
else{
t14=(C_word)C_eqp(t1,lf[204]);
if(C_truep(t14)){
t15=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1019,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 569  print */
t16=*((C_word*)lf[135]+1);
((C_proc3)C_retrieve_proc(t16))(3,t16,t15,C_retrieve2(lf[29],"compiler"));}
else{
t15=(C_word)C_eqp(t1,lf[205]);
if(C_truep(t15)){
t16=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1031,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 570  print */
t17=*((C_word*)lf[135]+1);
((C_proc3)C_retrieve_proc(t17))(3,t17,t16,C_retrieve2(lf[30],"c++-compiler"));}
else{
t16=(C_word)C_eqp(t1,lf[206]);
if(C_truep(t16)){
t17=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1043,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 571  print */
t18=*((C_word*)lf[135]+1);
((C_proc3)C_retrieve_proc(t18))(3,t18,t17,C_retrieve2(lf[31],"linker"));}
else{
t17=(C_word)C_eqp(t1,lf[207]);
if(C_truep(t17)){
t18=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1055,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 572  print */
t19=*((C_word*)lf[135]+1);
((C_proc3)C_retrieve_proc(t19))(3,t19,t18,C_retrieve2(lf[27],"home"));}
else{
t18=(C_word)C_eqp(t1,lf[208]);
if(C_truep(t18)){
t19=lf[68]=C_SCHEME_TRUE;;
t20=lf[71]=C_SCHEME_TRUE;;
t21=t2;
f_897(2,t21,t20);}
else{
t19=(C_word)C_eqp(t1,lf[209]);
if(C_truep(t19)){
t20=lf[93]=C_SCHEME_TRUE;;
t21=t2;
f_897(2,t21,t20);}
else{
t20=(C_word)C_eqp(t1,lf[210]);
t21=(C_truep(t20)?t20:(C_word)C_eqp(t1,lf[211]));
if(C_truep(t21)){
t22=lf[93]=C_SCHEME_TRUE;;
/* csc.scm: 580  t-options */
f_645(t2,(C_word)C_a_i_list(&a,1,lf[212]));}
else{
t22=(C_word)C_eqp(t1,lf[213]);
t23=(C_truep(t22)?t22:(C_word)C_eqp(t1,lf[214]));
if(C_truep(t23)){
t24=(C_word)C_a_i_cons(&a,2,lf[215],C_retrieve2(lf[88],"compile-options"));
t25=C_mutate(&lf[88],t24);
/* csc.scm: 583  t-options */
f_645(t2,(C_word)C_a_i_list(&a,1,lf[216]));}
else{
t24=(C_word)C_eqp(t1,lf[217]);
if(C_truep(t24)){
t25=lf[93]=C_SCHEME_TRUE;;
t26=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1112,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 586  t-options */
f_645(t26,(C_word)C_a_i_list(&a,1,lf[222]));}
else{
t25=(C_word)C_eqp(t1,lf[223]);
t26=(C_truep(t25)?t25:(C_word)C_eqp(t1,lf[224]));
if(C_truep(t26)){
t27=lf[95]=C_SCHEME_TRUE;;
/* csc.scm: 592  t-options */
f_645(t2,(C_word)C_a_i_list(&a,1,lf[225]));}
else{
t27=(C_word)C_eqp(t1,lf[226]);
t28=(C_truep(t27)?t27:(C_word)C_eqp(t1,lf[227]));
if(C_truep(t28)){
t29=lf[95]=C_SCHEME_TRUE;;
/* csc.scm: 595  t-options */
f_645(t2,(C_word)C_a_i_list(&a,1,lf[228]));}
else{
t29=(C_word)C_eqp(t1,lf[229]);
if(C_truep(t29)){
t30=lf[94]=C_SCHEME_TRUE;;
t31=t2;
f_897(2,t31,t30);}
else{
t30=(C_word)C_eqp(t1,lf[230]);
if(C_truep(t30)){
t31=lf[96]=C_SCHEME_TRUE;;
t32=t2;
f_897(2,t32,t31);}
else{
t31=(C_word)C_eqp(t1,lf[231]);
if(C_truep(t31)){
t32=lf[95]=C_SCHEME_TRUE;;
t33=t2;
f_897(2,t33,t32);}
else{
t32=(C_word)C_eqp(t1,lf[232]);
t33=(C_truep(t32)?t32:(C_word)C_eqp(t1,lf[233]));
if(C_truep(t33)){
t34=lf[67]=C_SCHEME_TRUE;;
t35=(C_word)C_a_i_cons(&a,2,lf[234],C_retrieve2(lf[88],"compile-options"));
t36=C_mutate(&lf[88],t35);
t37=t2;
f_897(2,t37,t36);}
else{
t34=(C_word)C_eqp(t1,lf[235]);
t35=(C_truep(t34)?t34:(C_word)C_eqp(t1,lf[236]));
if(C_truep(t35)){
t36=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1203,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* csc.scm: 603  check */
f_652(t36,t1,((C_word*)((C_word*)t0)[6])[1],C_SCHEME_END_OF_LIST);}
else{
t36=(C_word)C_eqp(t1,lf[238]);
t37=(C_truep(t36)?t36:(C_word)C_eqp(t1,lf[239]));
if(C_truep(t37)){
t38=lf[103]=C_SCHEME_TRUE;;
if(C_truep(lf[3])){
t39=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1243,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 612  cons* */
t40=C_retrieve(lf[127]);
((C_proc7)C_retrieve_proc(t40))(7,t40,t39,lf[241],lf[242],lf[243],lf[244],C_retrieve2(lf[91],"link-options"));}
else{
if(C_truep(C_retrieve2(lf[5],"msvc"))){
t39=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1254,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 617  cons* */
t40=C_retrieve(lf[127]);
((C_proc6)C_retrieve_proc(t40))(6,t40,t39,lf[246],lf[247],lf[248],C_retrieve2(lf[91],"link-options"));}
else{
t39=t2;
f_897(2,t39,C_SCHEME_UNDEFINED);}}}
else{
t38=(C_word)C_eqp(t1,lf[249]);
if(C_truep(t38)){
t39=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1267,a[2]=t2,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 620  check */
f_652(t39,t1,((C_word*)((C_word*)t0)[6])[1],C_SCHEME_END_OF_LIST);}
else{
t39=(C_word)C_eqp(t1,lf[251]);
if(C_truep(t39)){
t40=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1291,a[2]=t2,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 625  check */
f_652(t40,t1,((C_word*)((C_word*)t0)[6])[1],C_SCHEME_END_OF_LIST);}
else{
t40=(C_word)C_eqp(t1,lf[252]);
t41=(C_truep(t40)?t40:(C_word)C_eqp(t1,lf[253]));
if(C_truep(t41)){
t42=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1312,a[2]=t2,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 629  cons* */
t43=C_retrieve(lf[127]);
((C_proc5)C_retrieve_proc(t43))(5,t43,t42,lf[254],lf[255],((C_word*)((C_word*)t0)[6])[1]);}
else{
t42=(C_word)C_eqp(t1,lf[256]);
if(C_truep(t42)){
t43=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1322,a[2]=t2,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 630  cons* */
t44=C_retrieve(lf[127]);
((C_proc5)C_retrieve_proc(t44))(5,t44,t43,lf[257],lf[258],((C_word*)((C_word*)t0)[6])[1]);}
else{
t43=(C_word)C_eqp(t1,lf[259]);
if(C_truep(t43)){
t44=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1332,a[2]=t2,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 631  cons* */
t45=C_retrieve(lf[127]);
((C_proc5)C_retrieve_proc(t45))(5,t45,t44,lf[260],lf[261],((C_word*)((C_word*)t0)[6])[1]);}
else{
t44=(C_word)C_eqp(t1,lf[262]);
if(C_truep(t44)){
t45=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1342,a[2]=t2,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 632  cons* */
t46=C_retrieve(lf[127]);
((C_proc5)C_retrieve_proc(t46))(5,t46,t45,lf[263],lf[264],((C_word*)((C_word*)t0)[6])[1]);}
else{
t45=(C_word)C_eqp(t1,lf[265]);
if(C_truep(t45)){
t46=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1352,a[2]=t2,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 633  cons* */
t47=C_retrieve(lf[127]);
((C_proc5)C_retrieve_proc(t47))(5,t47,t46,lf[266],lf[267],((C_word*)((C_word*)t0)[6])[1]);}
else{
t46=(C_word)C_eqp(t1,lf[268]);
if(C_truep(t46)){
t47=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1362,a[2]=t2,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 634  cons* */
t48=C_retrieve(lf[127]);
((C_proc5)C_retrieve_proc(t48))(5,t48,t47,lf[269],lf[270],((C_word*)((C_word*)t0)[6])[1]);}
else{
t47=(C_word)C_eqp(t1,lf[271]);
if(C_truep(t47)){
t48=lf[93]=C_SCHEME_TRUE;;
t49=lf[72]=C_SCHEME_TRUE;;
t50=t2;
f_897(2,t50,t49);}
else{
t48=(C_word)C_eqp(t1,lf[272]);
t49=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1379,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=t2,a[8]=((C_word*)t0)[3],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t48)){
t50=t49;
f_1379(t50,t48);}
else{
t50=(C_word)C_eqp(t1,lf[326]);
t51=t49;
f_1379(t51,(C_truep(t50)?t50:(C_word)C_eqp(t1,lf[327])));}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}

/* k1377 in k892 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_fcall f_1379(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word ab[55],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1379,NULL,2,t0,t1);}
if(C_truep(t1)){
/* csc.scm: 639  shared-build */
f_691(((C_word*)t0)[7],C_SCHEME_FALSE);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[6],lf[273]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(((C_word*)t0)[6],lf[274]));
if(C_truep(t3)){
/* csc.scm: 641  shared-build */
f_691(((C_word*)t0)[7],C_SCHEME_TRUE);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[6],lf[275]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1403,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 643  check */
f_652(t5,((C_word*)t0)[6],((C_word*)((C_word*)t0)[5])[1],C_SCHEME_END_OF_LIST);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[6],lf[276]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1420,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 647  check */
f_652(t6,((C_word*)t0)[6],((C_word*)((C_word*)t0)[5])[1],C_SCHEME_END_OF_LIST);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[6],lf[277]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1437,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 651  check */
f_652(t7,((C_word*)t0)[6],((C_word*)((C_word*)t0)[5])[1],C_SCHEME_END_OF_LIST);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[6],lf[278]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1454,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 655  check */
f_652(t8,((C_word*)t0)[6],((C_word*)((C_word*)t0)[5])[1],C_SCHEME_END_OF_LIST);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[6],lf[279]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1471,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 659  check */
f_652(t9,((C_word*)t0)[6],((C_word*)((C_word*)t0)[5])[1],C_SCHEME_END_OF_LIST);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[6],lf[281]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1492,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 662  check */
f_652(t10,((C_word*)t0)[6],((C_word*)((C_word*)t0)[5])[1],C_SCHEME_END_OF_LIST);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[6],lf[283]);
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1518,a[2]=((C_word*)t0)[7],tmp=(C_word)a,a+=3,tmp);
t12=(C_word)C_a_i_list(&a,1,lf[284]);
/* csc.scm: 666  append */
t13=*((C_word*)lf[108]+1);
((C_proc4)C_retrieve_proc(t13))(4,t13,t11,C_retrieve2(lf[91],"link-options"),t12);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[6],lf[285]);
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1531,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 668  check */
f_652(t12,((C_word*)t0)[6],((C_word*)((C_word*)t0)[5])[1],C_SCHEME_END_OF_LIST);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[6],lf[286]);
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1556,a[2]=((C_word*)t0)[7],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 672  t-options */
f_645(t13,(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]));}
else{
t13=(C_word)C_eqp(((C_word*)t0)[6],lf[287]);
if(C_truep(t13)){
t14=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1567,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 676  check */
f_652(t14,((C_word*)t0)[6],((C_word*)((C_word*)t0)[5])[1],C_SCHEME_END_OF_LIST);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[6],lf[291]);
if(C_truep(t14)){
t15=((C_word*)t0)[7];
f_897(2,t15,C_SCHEME_FALSE);}
else{
t15=(C_word)C_eqp(((C_word*)t0)[6],lf[292]);
if(C_truep(t15)){
t16=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1613,a[2]=((C_word*)t0)[7],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 682  make-pathname */
t17=C_retrieve(lf[20]);
((C_proc5)C_retrieve_proc(t17))(5,t17,t16,C_SCHEME_FALSE,lf[294],C_retrieve2(lf[44],"executable-extension"));}
else{
t16=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1620,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t17=((C_word*)t0)[6];
if(C_truep((C_truep((C_word)C_eqp(t17,lf[325]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t17,lf[323]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
t18=(C_word)C_eqp(((C_word*)t0)[6],lf[323]);
if(C_truep(t18)){
t19=C_mutate(&lf[81],C_retrieve2(lf[77],"unsafe-library-files"));
t20=C_mutate(&lf[82],C_retrieve2(lf[78],"unsafe-shared-library-files"));
t21=t16;
f_1620(t21,t20);}
else{
t19=t16;
f_1620(t19,C_SCHEME_UNDEFINED);}}
else{
t18=t16;
f_1620(t18,C_SCHEME_UNDEFINED);}}}}}}}}}}}}}}}}

/* k1618 in k1377 in k892 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_fcall f_1620(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1620,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1623,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[7],lf[324]);
if(C_truep(t3)){
t4=lf[97]=C_SCHEME_TRUE;;
t5=lf[95]=C_SCHEME_TRUE;;
t6=t2;
f_1623(t6,t5);}
else{
t4=t2;
f_1623(t4,C_SCHEME_UNDEFINED);}}

/* k1621 in k1618 in k1377 in k892 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_fcall f_1623(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1623,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1626,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=((C_word*)t0)[7];
if(C_truep((C_truep((C_word)C_eqp(t3,lf[322]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,lf[323]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
t4=C_mutate(&lf[89],C_retrieve2(lf[57],"best-compilation-optimization-options"));
t5=C_mutate(&lf[90],C_retrieve2(lf[59],"best-linking-optimization-options"));
t6=t2;
f_1626(t6,t5);}
else{
t4=t2;
f_1626(t4,C_SCHEME_UNDEFINED);}}

/* k1624 in k1621 in k1618 in k1377 in k892 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_fcall f_1626(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[22],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1626,NULL,2,t0,t1);}
t2=(C_word)C_i_assq(((C_word*)t0)[7],lf[295]);
if(C_truep(t2)){
t3=(C_word)C_i_cadr(t2);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)((C_word*)t0)[6])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[6])+1,t4);
t6=((C_word*)t0)[5];
f_897(2,t6,t5);}
else{
if(C_truep((C_word)C_i_memq(((C_word*)t0)[7],lf[296]))){
/* csc.scm: 696  t-options */
f_645(((C_word*)t0)[5],(C_word)C_a_i_list(&a,1,((C_word*)t0)[3]));}
else{
if(C_truep((C_word)C_i_memq(((C_word*)t0)[7],lf[297]))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1658,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* csc.scm: 698  check */
f_652(t3,((C_word*)t0)[7],((C_word*)((C_word*)t0)[6])[1],C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1677,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_i_string_length(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_greaterp(t4,C_fix(2)))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2008,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 703  substring */
t6=*((C_word*)lf[299]+1);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,((C_word*)t0)[3],C_fix(0),C_fix(2));}
else{
t5=t3;
f_1677(t5,C_SCHEME_FALSE);}}}}}

/* k2006 in k1624 in k1621 in k1618 in k1377 in k892 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_2008(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_1677(t2,(C_word)C_i_string_equal_p(lf[321],t1));}

/* k1675 in k1624 in k1621 in k1618 in k1377 in k892 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_fcall f_1677(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1677,NULL,2,t0,t1);}
if(C_truep(t1)){
/* csc.scm: 704  t-options */
f_645(((C_word*)t0)[5],(C_word)C_a_i_list(&a,1,((C_word*)t0)[4]));}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1686,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_string_length(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_greaterp(t3,C_fix(1)))){
t4=(C_word)C_i_string_ref(((C_word*)t0)[4],C_fix(0));
t5=t2;
f_1686(t5,(C_word)C_eqp(C_make_character(45),t4));}
else{
t4=t2;
f_1686(t4,C_SCHEME_FALSE);}}}

/* k1684 in k1675 in k1624 in k1621 in k1618 in k1377 in k892 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_fcall f_1686(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word ab[42],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1686,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_string_ref(((C_word*)t0)[6],C_fix(1));
t3=(C_word)C_eqp(C_make_character(108),t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1696,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_a_i_list(&a,1,((C_word*)t0)[6]);
/* csc.scm: 708  append */
t6=*((C_word*)lf[108]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,C_retrieve2(lf[91],"link-options"),t5);}
else{
t4=(C_word)C_i_string_ref(((C_word*)t0)[6],C_fix(1));
t5=(C_word)C_eqp(C_make_character(76),t4);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1710,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t7=(C_word)C_a_i_list(&a,1,((C_word*)t0)[6]);
/* csc.scm: 710  append */
t8=*((C_word*)lf[108]+1);
((C_proc4)C_retrieve_proc(t8))(4,t8,t6,C_retrieve2(lf[91],"link-options"),t7);}
else{
t6=(C_word)C_i_string_ref(((C_word*)t0)[6],C_fix(1));
t7=(C_word)C_eqp(C_make_character(73),t6);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1724,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t9=(C_word)C_a_i_list(&a,1,((C_word*)t0)[6]);
/* csc.scm: 712  append */
t10=*((C_word*)lf[108]+1);
((C_proc4)C_retrieve_proc(t10))(4,t10,t8,C_retrieve2(lf[88],"compile-options"),t9);}
else{
t8=(C_word)C_i_string_ref(((C_word*)t0)[6],C_fix(1));
t9=(C_word)C_eqp(C_make_character(68),t8);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1741,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 714  substring */
t11=*((C_word*)lf[299]+1);
((C_proc4)C_retrieve_proc(t11))(4,t11,t10,((C_word*)t0)[6],C_fix(2));}
else{
t10=(C_word)C_i_string_ref(((C_word*)t0)[6],C_fix(1));
t11=(C_word)C_eqp(C_make_character(70),t10);
if(C_truep(t11)){
if(C_truep(C_retrieve2(lf[7],"osx"))){
t12=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1754,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t13=(C_word)C_a_i_list(&a,1,((C_word*)t0)[6]);
/* csc.scm: 717  append */
t14=*((C_word*)lf[108]+1);
((C_proc4)C_retrieve_proc(t14))(4,t14,t12,C_retrieve2(lf[88],"compile-options"),t13);}
else{
t12=((C_word*)t0)[5];
f_897(2,t12,C_SCHEME_UNDEFINED);}}
else{
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1764,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t13=(C_word)C_i_string_length(((C_word*)t0)[6]);
if(C_truep((C_word)C_i_greaterp(t13,C_fix(3)))){
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1833,a[2]=t12,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 718  substring */
t15=*((C_word*)lf[299]+1);
((C_proc5)C_retrieve_proc(t15))(5,t15,t14,((C_word*)t0)[6],C_fix(0),C_fix(4));}
else{
t14=t12;
f_1764(t14,C_SCHEME_FALSE);}}}}}}}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1863,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* csc.scm: 727  file-exists? */
t3=C_retrieve(lf[170]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[6]);}}

/* k1861 in k1684 in k1675 in k1624 in k1621 in k1618 in k1377 in k892 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_1863(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1863,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1868,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1874,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 728  ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[3],t2,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1971,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* csc.scm: 744  string-append */
t3=*((C_word*)lf[22]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[4],lf[320]);}}

/* k1969 in k1861 in k1684 in k1675 in k1624 in k1621 in k1618 in k1377 in k892 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_1971(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1971,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1977,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* csc.scm: 745  file-exists? */
t3=C_retrieve(lf[170]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k1975 in k1969 in k1861 in k1684 in k1675 in k1624 in k1621 in k1618 in k1377 in k892 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_1977(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1977,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)((C_word*)t0)[4])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[4])+1,t2);
t4=((C_word*)t0)[3];
f_897(2,t4,t3);}
else{
/* csc.scm: 747  quit */
f_428(((C_word*)t0)[3],lf[319],(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]));}}

/* a1873 in k1861 in k1684 in k1675 in k1624 in k1621 in k1618 in k1377 in k892 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_1874(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word ab[37],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1874,5,t0,t1,t2,t3,t4);}
t5=t4;
if(C_truep(t5)){
t6=t4;
if(C_truep((C_truep((C_word)C_i_equalp(t6,lf[308]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t6,lf[309]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1899,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
/* csc.scm: 731  append */
t9=*((C_word*)lf[108]+1);
((C_proc4)C_retrieve_proc(t9))(4,t9,t7,C_retrieve2(lf[61],"c-files"),t8);}
else{
t7=t4;
if(C_truep((C_truep((C_word)C_i_equalp(t7,lf[310]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t7,lf[311]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t7,lf[312]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t7,lf[313]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t7,lf[314]))?C_SCHEME_TRUE:C_SCHEME_FALSE))))))){
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1912,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[7],"osx"))){
t9=(C_word)C_a_i_cons(&a,2,lf[315],C_retrieve2(lf[88],"compile-options"));
t10=C_mutate(&lf[88],t9);
t11=t8;
f_1912(t11,t10);}
else{
t9=t8;
f_1912(t9,C_SCHEME_UNDEFINED);}}
else{
t8=t4;
if(C_truep((C_truep((C_word)C_i_equalp(t8,lf[316]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t8,lf[317]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t8,lf[318]))?C_SCHEME_TRUE:C_SCHEME_FALSE))))){
t9=lf[66]=C_SCHEME_TRUE;;
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1936,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t11=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
/* csc.scm: 738  append */
t12=*((C_word*)lf[108]+1);
((C_proc4)C_retrieve_proc(t12))(4,t12,t10,C_retrieve2(lf[61],"c-files"),t11);}
else{
t9=(C_word)C_i_string_equal_p(t4,C_retrieve2(lf[35],"object-extension"));
t10=(C_truep(t9)?t9:(C_word)C_i_string_equal_p(t4,C_retrieve2(lf[38],"library-extension")));
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1953,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t12=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
/* csc.scm: 741  append */
t13=*((C_word*)lf[108]+1);
((C_proc4)C_retrieve_proc(t13))(4,t13,t11,C_retrieve2(lf[63],"object-files"),t12);}
else{
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1961,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t12=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
/* csc.scm: 742  append */
t13=*((C_word*)lf[108]+1);
((C_proc4)C_retrieve_proc(t13))(4,t13,t11,C_retrieve2(lf[60],"scheme-files"),t12);}}}}}
else{
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1885,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t7=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
/* csc.scm: 729  append */
t8=*((C_word*)lf[108]+1);
((C_proc4)C_retrieve_proc(t8))(4,t8,t6,C_retrieve2(lf[60],"scheme-files"),t7);}}

/* k1883 in a1873 in k1861 in k1684 in k1675 in k1624 in k1621 in k1618 in k1377 in k892 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_1885(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[60],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k1959 in a1873 in k1861 in k1684 in k1675 in k1624 in k1621 in k1618 in k1377 in k892 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_1961(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[60],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k1951 in a1873 in k1861 in k1684 in k1675 in k1624 in k1621 in k1618 in k1377 in k892 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_1953(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[63],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k1934 in a1873 in k1861 in k1684 in k1675 in k1624 in k1621 in k1618 in k1377 in k892 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_1936(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[61],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k1910 in a1873 in k1861 in k1684 in k1675 in k1624 in k1621 in k1618 in k1377 in k892 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_fcall f_1912(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1912,NULL,2,t0,t1);}
t2=lf[65]=C_SCHEME_TRUE;;
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1917,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
/* csc.scm: 735  append */
t5=*((C_word*)lf[108]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,C_retrieve2(lf[61],"c-files"),t4);}

/* k1915 in k1910 in a1873 in k1861 in k1684 in k1675 in k1624 in k1621 in k1618 in k1377 in k892 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_1917(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[61],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k1897 in a1873 in k1861 in k1684 in k1675 in k1624 in k1621 in k1618 in k1377 in k892 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_1899(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[61],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* a1867 in k1861 in k1684 in k1675 in k1624 in k1621 in k1618 in k1377 in k892 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_1868(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1868,2,t0,t1);}
/* csc.scm: 728  decompose-pathname */
t2=C_retrieve(lf[307]);
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* k1831 in k1684 in k1675 in k1624 in k1621 in k1618 in k1377 in k892 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_1833(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_1764(t2,(C_word)C_i_string_equal_p(lf[306],t1));}

/* k1762 in k1684 in k1675 in k1624 in k1621 in k1618 in k1377 in k892 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_fcall f_1764(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1764,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1768,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_a_i_list(&a,1,((C_word*)t0)[4]);
/* csc.scm: 719  append */
t4=*((C_word*)lf[108]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,C_retrieve2(lf[91],"link-options"),t3);}
else{
t2=(C_word)C_i_string_length(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_greaterp(t2,C_fix(2)))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1816,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* string->list */
t4=C_retrieve(lf[128]);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[4]);}
else{
/* csc.scm: 726  quit */
f_428(((C_word*)t0)[5],lf[305],(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]));}}}

/* k1814 in k1762 in k1684 in k1675 in k1624 in k1621 in k1618 in k1377 in k892 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_1816(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1816,2,t0,t1);}
t2=(C_word)C_i_cdr(t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1812,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* csc.scm: 722  lset-difference */
t4=C_retrieve(lf[302]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,*((C_word*)lf[303]+1),t2,lf[304]);}

/* k1810 in k1814 in k1762 in k1684 in k1675 in k1624 in k1621 in k1618 in k1377 in k892 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_1812(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1812,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1791,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1795,a[2]=((C_word*)t0)[5],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1797,tmp=(C_word)a,a+=2,tmp);
/* map */
t5=*((C_word*)lf[106]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[3]);}
else{
/* csc.scm: 725  quit */
f_428(((C_word*)t0)[4],lf[301],(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]));}}

/* a1796 in k1810 in k1814 in k1762 in k1684 in k1675 in k1624 in k1621 in k1618 in k1377 in k892 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_1797(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1797,3,t0,t1,t2);}
t3=(C_word)C_a_i_string(&a,1,t2);
/* csc.scm: 724  string-append */
t4=*((C_word*)lf[22]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,lf[300],t3);}

/* k1793 in k1810 in k1814 in k1762 in k1684 in k1675 in k1624 in k1621 in k1618 in k1377 in k892 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_1795(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 724  append */
t2=*((C_word*)lf[108]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)((C_word*)t0)[2])[1]);}

/* k1789 in k1810 in k1814 in k1762 in k1684 in k1675 in k1624 in k1621 in k1618 in k1377 in k892 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_1791(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_897(2,t3,t2);}

/* k1766 in k1762 in k1684 in k1675 in k1624 in k1621 in k1618 in k1377 in k892 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_1768(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[91],t1);
t3=((C_word*)t0)[2];
f_897(2,t3,t2);}

/* k1752 in k1684 in k1675 in k1624 in k1621 in k1618 in k1377 in k892 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_1754(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[88],t1);
t3=((C_word*)t0)[2];
f_897(2,t3,t2);}

/* k1739 in k1684 in k1675 in k1624 in k1621 in k1618 in k1377 in k892 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_1741(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1741,2,t0,t1);}
/* csc.scm: 714  t-options */
f_645(((C_word*)t0)[2],(C_word)C_a_i_list(&a,2,lf[298],t1));}

/* k1722 in k1684 in k1675 in k1624 in k1621 in k1618 in k1377 in k892 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_1724(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[88],t1);
t3=((C_word*)t0)[2];
f_897(2,t3,t2);}

/* k1708 in k1684 in k1675 in k1624 in k1621 in k1618 in k1377 in k892 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_1710(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[91],t1);
t3=((C_word*)t0)[2];
f_897(2,t3,t2);}

/* k1694 in k1684 in k1675 in k1624 in k1621 in k1618 in k1377 in k892 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_1696(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[91],t1);
t3=((C_word*)t0)[2];
f_897(2,t3,t2);}

/* k1656 in k1624 in k1621 in k1618 in k1377 in k892 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_1658(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1658,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)((C_word*)t0)[5])[1]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1664,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* csc.scm: 700  string->number */
C_string_to_number(3,0,t3,t2);}

/* k1662 in k1656 in k1624 in k1621 in k1618 in k1377 in k892 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_1664(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1664,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1667,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 701  t-options */
f_645(t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]));}

/* k1665 in k1662 in k1656 in k1624 in k1621 in k1618 in k1377 in k892 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_1667(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
f_897(2,t4,t3);}

/* k1611 in k1377 in k892 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_1613(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1613,2,t0,t1);}
t2=C_mutate(&lf[92],t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1617,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 683  append */
t4=*((C_word*)lf[108]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_retrieve2(lf[60],"scheme-files"),lf[293]);}

/* k1615 in k1611 in k1377 in k892 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_1617(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[60],t1);
t3=((C_word*)t0)[2];
f_897(2,t3,t2);}

/* k1565 in k1377 in k892 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_1567(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1567,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1597,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 677  build-platform */
t3=C_retrieve(lf[290]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k1595 in k1565 in k1377 in k892 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_1597(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1597,2,t0,t1);}
t2=(C_word)C_eqp(lf[288],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1577,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1589,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_i_car(((C_word*)((C_word*)t0)[3])[1]);
/* csc.scm: 678  string-append */
t6=*((C_word*)lf[22]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,lf[289],t5);}
else{
t3=((C_word*)t0)[2];
f_897(2,t3,C_SCHEME_UNDEFINED);}}

/* k1587 in k1595 in k1565 in k1377 in k892 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_1589(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1589,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* csc.scm: 678  append */
t3=*((C_word*)lf[108]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[2],C_retrieve2(lf[91],"link-options"),t2);}

/* k1575 in k1595 in k1565 in k1377 in k892 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_1577(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(&lf[91],t1);
t3=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=((C_word*)t0)[2];
f_897(2,t5,t4);}

/* k1554 in k1377 in k892 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_1556(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(&lf[81],C_retrieve2(lf[77],"unsafe-library-files"));
t3=C_mutate(&lf[82],C_retrieve2(lf[78],"unsafe-shared-library-files"));
t4=((C_word*)t0)[2];
f_897(2,t4,t3);}

/* k1529 in k1377 in k892 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_1531(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1531,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1535,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1543,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_car(((C_word*)((C_word*)t0)[3])[1]);
/* csc.scm: 669  string-split */
t5=C_retrieve(lf[282]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* k1541 in k1529 in k1377 in k892 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_1543(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 669  append */
t2=*((C_word*)lf[108]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_retrieve2(lf[91],"link-options"),t1);}

/* k1533 in k1529 in k1377 in k892 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_1535(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(&lf[91],t1);
t3=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=((C_word*)t0)[2];
f_897(2,t5,t4);}

/* k1516 in k1377 in k892 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_1518(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[91],t1);
t3=((C_word*)t0)[2];
f_897(2,t3,t2);}

/* k1490 in k1377 in k892 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_1492(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1492,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1496,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1504,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_car(((C_word*)((C_word*)t0)[3])[1]);
/* csc.scm: 663  string-split */
t5=C_retrieve(lf[282]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* k1502 in k1490 in k1377 in k892 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_1504(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 663  append */
t2=*((C_word*)lf[108]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_retrieve2(lf[88],"compile-options"),t1);}

/* k1494 in k1490 in k1377 in k892 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_1496(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(&lf[88],t1);
t3=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=((C_word*)t0)[2];
f_897(2,t5,t4);}

/* k1469 in k1377 in k892 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_1471(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1471,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1475,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)((C_word*)t0)[3])[1]);
t4=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
/* csc.scm: 660  cons* */
t5=C_retrieve(lf[127]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t2,lf[280],t3,t4);}

/* k1473 in k1469 in k1377 in k892 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_1475(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_897(2,t3,t2);}

/* k1452 in k1377 in k892 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_1454(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_word)C_i_car(((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(&lf[31],t2);
t4=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[3])+1,t4);
t6=((C_word*)t0)[2];
f_897(2,t6,t5);}

/* k1435 in k1377 in k892 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_1437(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_word)C_i_car(((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(&lf[30],t2);
t4=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[3])+1,t4);
t6=((C_word*)t0)[2];
f_897(2,t6,t5);}

/* k1418 in k1377 in k892 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_1420(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_word)C_i_car(((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(&lf[29],t2);
t4=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[3])+1,t4);
t6=((C_word*)t0)[2];
f_897(2,t6,t5);}

/* k1401 in k1377 in k892 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_1403(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_word)C_i_car(((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(&lf[28],t2);
t4=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[3])+1,t4);
t6=((C_word*)t0)[2];
f_897(2,t6,t5);}

/* k1360 in k892 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_1362(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_897(2,t3,t2);}

/* k1350 in k892 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_1352(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_897(2,t3,t2);}

/* k1340 in k892 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_1342(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_897(2,t3,t2);}

/* k1330 in k892 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_1332(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_897(2,t3,t2);}

/* k1320 in k892 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_1322(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_897(2,t3,t2);}

/* k1310 in k892 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_1312(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_897(2,t3,t2);}

/* k1289 in k892 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_1291(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_word)C_i_car(((C_word*)((C_word*)t0)[3])[1]);
t3=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=C_mutate(&lf[92],t2);
t6=((C_word*)t0)[2];
f_897(2,t6,t5);}

/* k1265 in k892 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_1267(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1267,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1270,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[7],"osx"))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1278,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_car(((C_word*)((C_word*)t0)[3])[1]);
/* csc.scm: 622  cons* */
t5=C_retrieve(lf[127]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,lf[250],t4,C_retrieve2(lf[91],"link-options"));}
else{
t3=t2;
f_1270(t3,C_SCHEME_UNDEFINED);}}

/* k1276 in k1265 in k892 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_1278(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[91],t1);
t3=((C_word*)t0)[2];
f_1270(t3,t2);}

/* k1268 in k1265 in k892 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_fcall f_1270(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
f_897(2,t4,t3);}

/* k1252 in k892 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_1254(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1254,2,t0,t1);}
t2=C_mutate(&lf[91],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[245],C_retrieve2(lf[88],"compile-options"));
t4=C_mutate(&lf[88],t3);
t5=((C_word*)t0)[2];
f_897(2,t5,t4);}

/* k1241 in k892 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_1243(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1243,2,t0,t1);}
t2=C_mutate(&lf[91],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[240],C_retrieve2(lf[88],"compile-options"));
t4=C_mutate(&lf[88],t3);
t5=((C_word*)t0)[2];
f_897(2,t5,t4);}

/* k1201 in k892 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_1203(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1203,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1207,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_car(((C_word*)((C_word*)t0)[4])[1]);
t4=(C_word)C_a_i_list(&a,1,t3);
/* csc.scm: 604  append */
t5=*((C_word*)lf[108]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t2,C_retrieve2(lf[102],"required-extensions"),t4);}

/* k1205 in k1201 in k892 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_1207(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1207,2,t0,t1);}
t2=C_mutate(&lf[102],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1210,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_car(((C_word*)((C_word*)t0)[4])[1]);
/* csc.scm: 605  t-options */
f_645(t3,(C_word)C_a_i_list(&a,2,lf[237],t4));}

/* k1208 in k1205 in k1201 in k892 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_1210(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
f_897(2,t4,t3);}

/* k1110 in k892 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_1112(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1112,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1115,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[5],"msvc"))){
t3=t2;
f_1115(t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1130,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 588  cons* */
t4=C_retrieve(lf[127]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[220],lf[221],C_retrieve2(lf[88],"compile-options"));}}

/* k1128 in k1110 in k892 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_1130(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[88],t1);
t3=((C_word*)t0)[2];
f_1115(t3,t2);}

/* k1113 in k1110 in k892 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_fcall f_1115(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1115,NULL,2,t0,t1);}
t2=(C_truep(C_retrieve2(lf[5],"msvc"))?lf[218]:lf[219]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_retrieve2(lf[91],"link-options"));
t4=C_mutate(&lf[91],t3);
t5=((C_word*)t0)[2];
f_897(2,t5,t4);}

/* k1053 in k892 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_1055(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 572  exit */
t2=C_retrieve(lf[10]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_fix(0));}

/* k1041 in k892 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_1043(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 571  exit */
t2=C_retrieve(lf[10]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_fix(0));}

/* k1029 in k892 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_1031(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 570  exit */
t2=C_retrieve(lf[10]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_fix(0));}

/* k1017 in k892 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_1019(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 569  exit */
t2=C_retrieve(lf[10]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_fix(0));}

/* k984 in k892 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_986(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(&lf[83],t1);
t3=lf[100]=C_SCHEME_TRUE;;
t4=((C_word*)t0)[2];
f_897(2,t4,t3);}

/* k973 in k892 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_975(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(&lf[83],t1);
t3=lf[99]=C_SCHEME_TRUE;;
t4=((C_word*)t0)[2];
f_897(2,t4,t3);}

/* k942 in k892 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_944(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 548  system */
t2=C_retrieve(lf[134]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k935 in k892 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_937(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 549  exit */
t2=C_retrieve(lf[10]);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k926 in k892 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_928(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 545  print */
t2=*((C_word*)lf[135]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k919 in k892 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_921(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 546  exit */
t2=C_retrieve(lf[10]);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k907 in k892 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_909(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 543  exit */
t2=C_retrieve(lf[10]);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k895 in k892 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_897(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 748  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_720(t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* k883 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_885(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 501  print* */
t2=*((C_word*)lf[183]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_make_character(32));}

/* k850 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_852(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_852,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_855,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[70],"show-ldflags"))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_878,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 502  linker-options */
f_2675(t3);}
else{
t3=t2;
f_855(2,t3,C_SCHEME_UNDEFINED);}}

/* k876 in k850 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_878(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 502  print* */
t2=*((C_word*)lf[183]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_make_character(32));}

/* k853 in k850 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_855(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_855,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_858,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[71],"show-libs"))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_871,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 503  linker-libraries */
f_2727(t3,(C_word)C_a_i_list(&a,1,C_SCHEME_TRUE));}
else{
t3=t2;
f_858(2,t3,C_SCHEME_UNDEFINED);}}

/* k869 in k853 in k850 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_871(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 503  print* */
t2=*((C_word*)lf[183]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_make_character(32));}

/* k856 in k853 in k850 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_858(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_858,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_861,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 504  newline */
t3=*((C_word*)lf[182]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k859 in k856 in k853 in k850 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_861(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 505  exit */
t2=C_retrieve(lf[10]);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k728 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_730(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_730,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_733,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(C_retrieve2(lf[60],"scheme-files")))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_777,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_nullp(C_retrieve2(lf[61],"c-files"));
t5=(C_truep(t4)?(C_word)C_i_nullp(C_retrieve2(lf[63],"object-files")):C_SCHEME_FALSE);
if(C_truep(t5)){
/* csc.scm: 511  quit */
f_428(t3,lf[161],C_SCHEME_END_OF_LIST);}
else{
t6=t3;
f_777(2,t6,C_SCHEME_UNDEFINED);}}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_815,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_truep(C_retrieve2(lf[98],"shared"))?(C_word)C_i_not(C_retrieve2(lf[67],"embedded")):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=(C_word)C_a_i_cons(&a,2,lf[181],C_retrieve2(lf[83],"translate-options"));
t6=C_mutate(&lf[83],t5);
t7=t3;
f_815(t7,t6);}
else{
t5=t3;
f_815(t5,C_SCHEME_UNDEFINED);}}}

/* k813 in k728 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_fcall f_815(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_815,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_818,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[92],"target-filename"))){
t3=t2;
f_818(t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_825,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[98],"shared"))){
t4=(C_word)C_i_car(C_retrieve2(lf[60],"scheme-files"));
/* csc.scm: 524  pathname-replace-extension */
t5=C_retrieve(lf[159]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t4,C_retrieve2(lf[48],"shared-library-extension"));}
else{
t4=(C_word)C_i_car(C_retrieve2(lf[60],"scheme-files"));
/* csc.scm: 525  pathname-replace-extension */
t5=C_retrieve(lf[159]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t4,C_retrieve2(lf[44],"executable-extension"));}}}

/* k823 in k813 in k728 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_825(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[92],t1);
t3=((C_word*)t0)[2];
f_818(t3,t2);}

/* k816 in k813 in k728 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_fcall f_818(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_818,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2078,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2086,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[148]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_retrieve2(lf[60],"scheme-files"));}

/* a2085 in k816 in k813 in k728 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_2086(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2086,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2090,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 756  pathname-replace-extension */
t4=C_retrieve(lf[159]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,t2,lf[180]);}

/* k2088 in a2085 in k816 in k813 in k728 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_2090(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2090,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2093,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2331,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2337,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 757  file-exists? */
t5=C_retrieve(lf[170]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t1);}

/* k2335 in k2088 in a2085 in k816 in k813 in k728 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_2337(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2337,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2340,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 758  with-input-from-file */
t3=C_retrieve(lf[169]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],C_retrieve(lf[168]));}
else{
t2=((C_word*)t0)[3];
f_2331(t2,C_SCHEME_FALSE);}}

/* k2338 in k2335 in k2088 in a2085 in k816 in k813 in k728 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_2340(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eofp(t1);
t3=((C_word*)t0)[2];
f_2331(t3,(C_truep(t2)?t2:(C_word)C_i_string_equal_p(lf[179],t1)));}

/* k2329 in k2088 in a2085 in k816 in k813 in k728 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_fcall f_2331(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* csc.scm: 760  $delete-file */
t2=C_retrieve2(lf[136],"$delete-file");
f_2937(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_2093(2,t2,C_SCHEME_UNDEFINED);}}

/* k2091 in k2088 in a2085 in k816 in k813 in k728 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_2093(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2093,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2096,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_length(C_retrieve2(lf[60],"scheme-files"));
t4=(C_word)C_i_nequalp(C_fix(1),t3);
t5=(C_truep(t4)?C_retrieve2(lf[92],"target-filename"):((C_word*)t0)[2]);
t6=(C_truep(C_retrieve2(lf[65],"cpp-mode"))?lf[176]:(C_truep(C_retrieve2(lf[66],"objc-mode"))?lf[177]:lf[178]));
/* csc.scm: 761  pathname-replace-extension */
t7=C_retrieve(lf[159]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t2,t5,t6);}

/* k2094 in k2091 in k2088 in a2085 in k816 in k813 in k728 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_2096(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2096,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2099,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2256,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2260,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2264,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2268,a[2]=t1,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 771  cleanup-filename */
t7=C_retrieve2(lf[55],"cleanup-filename");
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[2]);}

/* k2266 in k2094 in k2091 in k2088 in a2085 in k816 in k813 in k728 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_2268(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2268,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2272,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2276,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[97],"to-stdout"))){
t4=t3;
f_2276(t4,lf[174]);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2310,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 775  cleanup-filename */
t5=C_retrieve2(lf[55],"cleanup-filename");
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[2]);}}

/* k2308 in k2266 in k2094 in k2091 in k2088 in a2085 in k816 in k813 in k728 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_2310(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2310,2,t0,t1);}
t2=((C_word*)t0)[2];
f_2276(t2,(C_word)C_a_i_list(&a,2,lf[175],t1));}

/* k2274 in k2266 in k2094 in k2091 in k2088 in a2085 in k816 in k813 in k728 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_fcall f_2276(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2276,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2280,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=C_retrieve2(lf[99],"static");
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2291,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(t3)){
t5=t4;
f_2291(t5,t3);}
else{
t5=C_retrieve2(lf[100],"static-libs");
t6=t4;
f_2291(t6,(C_truep(t5)?t5:C_retrieve2(lf[101],"static-extensions")));}}

/* k2289 in k2274 in k2266 in k2094 in k2091 in k2088 in a2085 in k816 in k813 in k728 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_fcall f_2291(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2291,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2296,tmp=(C_word)a,a+=2,tmp);
/* map */
t3=*((C_word*)lf[106]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t2,C_retrieve2(lf[102],"required-extensions"));}
else{
t2=((C_word*)t0)[2];
f_2280(2,t2,C_SCHEME_END_OF_LIST);}}

/* a2295 in k2289 in k2274 in k2266 in k2094 in k2091 in k2088 in a2085 in k816 in k813 in k728 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_2296(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2296,3,t0,t1,t2);}
/* csc.scm: 777  conc */
t3=C_retrieve(lf[172]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,lf[173],t2);}

/* k2278 in k2274 in k2266 in k2094 in k2091 in k2088 in a2085 in k816 in k813 in k728 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_2280(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2280,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2284,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2288,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 779  append */
t4=*((C_word*)lf[108]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_retrieve2(lf[83],"translate-options"),C_SCHEME_END_OF_LIST);}

/* k2286 in k2278 in k2274 in k2266 in k2094 in k2091 in k2088 in a2085 in k816 in k813 in k728 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_2288(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[106]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve2(lf[107],"quote-option"),t1);}

/* k2282 in k2278 in k2274 in k2266 in k2094 in k2091 in k2088 in a2085 in k816 in k813 in k728 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_2284(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 772  append */
t2=*((C_word*)lf[108]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2270 in k2266 in k2094 in k2091 in k2088 in a2085 in k816 in k813 in k728 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_2272(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 771  cons* */
t2=C_retrieve(lf[127]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],C_retrieve2(lf[28],"translator"),((C_word*)t0)[2],t1);}

/* k2262 in k2094 in k2091 in k2088 in a2085 in k816 in k813 in k728 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_2264(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 770  string-intersperse */
t2=C_retrieve(lf[105]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,lf[171]);}

/* k2258 in k2094 in k2091 in k2088 in a2085 in k816 in k813 in k728 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_2260(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 769  $system */
t2=C_retrieve2(lf[131],"$system");
f_2905(3,t2,((C_word*)t0)[2],t1);}

/* k2254 in k2094 in k2091 in k2088 in a2085 in k816 in k813 in k728 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_2256(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_zerop(t1))){
t2=((C_word*)t0)[2];
f_2099(2,t2,C_SCHEME_UNDEFINED);}
else{
/* csc.scm: 781  exit */
t2=C_retrieve(lf[10]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_retrieve2(lf[130],"last-exit-code"));}}

/* k2097 in k2094 in k2091 in k2088 in a2085 in k816 in k813 in k728 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_2099(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2099,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2103,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
/* csc.scm: 782  append */
t4=*((C_word*)lf[108]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,t3,C_retrieve2(lf[61],"c-files"));}

/* k2101 in k2097 in k2094 in k2091 in k2088 in a2085 in k816 in k813 in k728 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_2103(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2103,2,t0,t1);}
t2=C_mutate(&lf[61],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2107,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
/* csc.scm: 783  append */
t5=*((C_word*)lf[108]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t4,C_retrieve2(lf[62],"generated-c-files"));}

/* k2105 in k2101 in k2097 in k2094 in k2091 in k2088 in a2085 in k816 in k813 in k728 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_2107(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2107,2,t0,t1);}
t2=C_mutate(&lf[62],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2113,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 784  file-exists? */
t4=C_retrieve(lf[170]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k2111 in k2105 in k2101 in k2097 in k2094 in k2091 in k2088 in a2085 in k816 in k813 in k728 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_2113(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2113,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2116,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2121,tmp=(C_word)a,a+=2,tmp);
/* csc.scm: 785  with-input-from-file */
t4=C_retrieve(lf[169]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,((C_word*)t0)[2],t3);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* a2120 in k2111 in k2105 in k2101 in k2097 in k2094 in k2091 in k2088 in a2085 in k816 in k813 in k728 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_2121(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2121,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2125,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 787  read-line */
t3=C_retrieve(lf[168]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k2123 in a2120 in k2111 in k2105 in k2101 in k2097 in k2094 in k2091 in k2088 in a2085 in k816 in k813 in k728 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_2125(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2125,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2130,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2238,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 797  read-file */
t4=C_retrieve(lf[167]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k2236 in k2123 in a2120 in k2111 in k2105 in k2101 in k2097 in k2094 in k2091 in k2088 in a2085 in k816 in k813 in k728 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_2238(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[148]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2129 in k2123 in a2120 in k2111 in k2105 in k2101 in k2097 in k2094 in k2091 in k2088 in a2085 in k816 in k813 in k728 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_2130(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2130,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2132,tmp=(C_word)a,a+=2,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_car(t2);
t5=(C_word)C_eqp(t4,lf[164]);
if(C_truep(t5)){
t6=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_listp(t6))){
t7=(C_word)C_i_cdr(t2);
/* for-each */
t8=*((C_word*)lf[148]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t1,C_retrieve2(lf[131],"$system"),t7);}
else{
/* g190192 */
f_2132(t1,t2);}}
else{
t6=(C_word)C_i_car(t2);
t7=(C_word)C_eqp(t6,lf[165]);
if(C_truep(t7)){
t8=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_listp(t8))){
t9=(C_word)C_i_cdr(t2);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2186,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* append */
t11=*((C_word*)lf[108]+1);
((C_proc4)C_retrieve_proc(t11))(4,t11,t10,C_retrieve2(lf[88],"compile-options"),t9);}
else{
/* g190192 */
f_2132(t1,t2);}}
else{
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2199,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t9=(C_word)C_i_car(t2);
t10=(C_word)C_eqp(t9,lf[166]);
if(C_truep(t10)){
t11=(C_word)C_i_cdr(t2);
t12=t8;
f_2199(t12,(C_word)C_i_listp(t11));}
else{
t11=t8;
f_2199(t11,C_SCHEME_FALSE);}}}}
else{
/* g190192 */
f_2132(t1,t2);}}

/* k2197 in a2129 in k2123 in a2120 in k2111 in k2105 in k2101 in k2097 in k2094 in k2091 in k2088 in a2085 in k816 in k813 in k728 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_fcall f_2199(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2199,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2206,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* append */
t4=*((C_word*)lf[108]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_retrieve2(lf[91],"link-options"),t2);}
else{
/* g190192 */
f_2132(((C_word*)t0)[3],((C_word*)t0)[4]);}}

/* k2204 in k2197 in a2129 in k2123 in a2120 in k2111 in k2105 in k2101 in k2097 in k2094 in k2091 in k2088 in a2085 in k816 in k813 in k728 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_2206(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[91],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2184 in a2129 in k2123 in a2120 in k2111 in k2105 in k2101 in k2097 in k2094 in k2091 in k2088 in a2085 in k816 in k813 in k728 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_2186(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[88],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* g190 in a2129 in k2123 in a2120 in k2111 in k2105 in k2101 in k2097 in k2094 in k2091 in k2088 in a2085 in k816 in k813 in k728 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_fcall f_2132(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2132,NULL,2,t1,t2);}
/* csc.scm: 796  error */
t3=*((C_word*)lf[162]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,lf[163],t2);}

/* k2114 in k2111 in k2105 in k2101 in k2097 in k2094 in k2091 in k2088 in a2085 in k816 in k813 in k728 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_2116(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 798  $delete-file */
t2=C_retrieve2(lf[136],"$delete-file");
f_2937(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2076 in k816 in k813 in k728 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_2078(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(C_retrieve2(lf[94],"keep-files"))){
t2=((C_word*)t0)[2];
f_733(2,t2,C_SCHEME_UNDEFINED);}
else{
/* for-each */
t2=*((C_word*)lf[148]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve2(lf[136],"$delete-file"),C_SCHEME_END_OF_LIST);}}

/* k775 in k728 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_777(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_777,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_780,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_nullp(C_retrieve2(lf[61],"c-files"));
t4=(C_truep(t3)?C_retrieve2(lf[63],"object-files"):C_retrieve2(lf[61],"c-files"));
/* csc.scm: 512  last */
t5=C_retrieve(lf[160]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t2,t4);}

/* k778 in k775 in k728 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_780(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_780,2,t0,t1);}
if(C_truep(C_retrieve2(lf[92],"target-filename"))){
t2=((C_word*)t0)[2];
f_733(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_787,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[98],"shared"))){
/* csc.scm: 516  pathname-replace-extension */
t3=C_retrieve(lf[159]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,t1,C_retrieve2(lf[48],"shared-library-extension"));}
else{
/* csc.scm: 517  pathname-replace-extension */
t3=C_retrieve(lf[159]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,t1,C_retrieve2(lf[44],"executable-extension"));}}}

/* k785 in k778 in k775 in k728 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_787(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[92],t1);
t3=((C_word*)t0)[2];
f_733(2,t3,t2);}

/* k731 in k728 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_733(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_733,2,t0,t1);}
if(C_truep(C_retrieve2(lf[95],"translate-only"))){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_739,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2355,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2371,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* for-each */
t7=*((C_word*)lf[148]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,C_retrieve2(lf[61],"c-files"));}}

/* a2370 in k731 in k728 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_2371(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2371,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2375,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* csc.scm: 809  pathname-replace-extension */
t4=C_retrieve(lf[159]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,t2,C_retrieve2(lf[35],"object-extension"));}

/* k2373 in a2370 in k731 in k728 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_2375(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2375,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2378,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2396,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2400,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(C_truep(C_retrieve2(lf[65],"cpp-mode"))?C_retrieve2(lf[30],"c++-compiler"):C_retrieve2(lf[29],"compiler"));
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2412,a[2]=t1,a[3]=t4,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* csc.scm: 815  cleanup-filename */
t7=C_retrieve2(lf[55],"cleanup-filename");
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[2]);}

/* k2410 in k2373 in a2370 in k731 in k728 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_2412(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2412,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2416,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2424,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 816  cleanup-filename */
t4=C_retrieve2(lf[55],"cleanup-filename");
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k2422 in k2410 in k2373 in a2370 in k731 in k728 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_2424(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 816  string-append */
t2=*((C_word*)lf[22]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_retrieve2(lf[47],"compile-output-flag"),t1);}

/* k2414 in k2410 in k2373 in a2370 in k731 in k728 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_2416(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2416,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2420,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* csc.scm: 818  compiler-options */
f_2426(t2);}

/* k2418 in k2414 in k2410 in k2373 in a2370 in k731 in k728 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_2420(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2420,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,5,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],lf[158],t1);
/* csc.scm: 812  string-intersperse */
t3=C_retrieve(lf[105]);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],t2);}

/* k2398 in k2373 in a2370 in k731 in k728 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_2400(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 811  $system */
t2=C_retrieve2(lf[131],"$system");
f_2905(3,t2,((C_word*)t0)[2],t1);}

/* k2394 in k2373 in a2370 in k731 in k728 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_2396(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_zerop(t1))){
t2=((C_word*)t0)[2];
f_2378(2,t2,C_SCHEME_UNDEFINED);}
else{
/* csc.scm: 819  exit */
t2=C_retrieve(lf[10]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_retrieve2(lf[130],"last-exit-code"));}}

/* k2376 in k2373 in a2370 in k731 in k728 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_2378(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2378,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_retrieve2(lf[64],"generated-object-files"));
t3=C_mutate(&lf[64],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[3])+1,t4);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}

/* k2353 in k731 in k728 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_2355(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2355,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2359,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2369,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 823  reverse */
t4=*((C_word*)lf[110]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)((C_word*)t0)[2])[1]);}

/* k2367 in k2353 in k731 in k728 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_2369(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 823  append */
t2=*((C_word*)lf[108]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_retrieve2(lf[63],"object-files"));}

/* k2357 in k2353 in k731 in k728 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_2359(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[63],t1);
if(C_truep(C_retrieve2(lf[94],"keep-files"))){
t3=((C_word*)t0)[2];
f_739(2,t3,C_SCHEME_UNDEFINED);}
else{
/* for-each */
t3=*((C_word*)lf[148]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],C_retrieve2(lf[136],"$delete-file"),C_retrieve2(lf[62],"generated-c-files"));}}

/* k737 in k731 in k728 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_739(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_739,2,t0,t1);}
if(C_truep(C_retrieve2(lf[96],"compile-only"))){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_745,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_member(C_retrieve2(lf[92],"target-filename"),C_retrieve2(lf[60],"scheme-files")))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_754,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 531  printf */
t4=C_retrieve(lf[132]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[157],C_retrieve2(lf[92],"target-filename"),C_retrieve2(lf[92],"target-filename"));}
else{
t3=t2;
f_745(2,t3,C_SCHEME_UNDEFINED);}}}

/* k752 in k737 in k731 in k728 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_754(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_754,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_767,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_771,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 533  sprintf */
t4=C_retrieve(lf[155]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[156],C_retrieve2(lf[92],"target-filename"),C_retrieve2(lf[92],"target-filename"));}

/* k769 in k752 in k737 in k731 in k728 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_771(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 533  $system */
t2=C_retrieve2(lf[131],"$system");
f_2905(3,t2,((C_word*)t0)[2],t1);}

/* k765 in k752 in k737 in k731 in k728 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_767(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_zerop(t1))){
t2=((C_word*)t0)[2];
f_745(2,t2,C_SCHEME_UNDEFINED);}
else{
/* csc.scm: 534  exit */
t2=C_retrieve(lf[10]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_retrieve2(lf[130],"last-exit-code"));}}

/* k743 in k737 in k731 in k728 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_745(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_745,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2451,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2560,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2564,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2566,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2572,tmp=(C_word)a,a+=2,tmp);
/* csc.scm: 840  ##sys#call-with-values */
C_call_with_values(4,0,t5,t6,t7);}

/* a2571 in k743 in k737 in k731 in k728 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_2572(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2rv,(void*)f_2572r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_2572r(t0,t1,t2);}}

static void C_ccall f_2572r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_vector_ref(t2,C_fix(0)));}

/* a2565 in k743 in k737 in k731 in k728 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_2566(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2566,2,t0,t1);}
/* csc.scm: 840  static-extension-info */
f_2578(t1);}

/* k2562 in k743 in k737 in k731 in k728 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_2564(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 839  append */
t2=*((C_word*)lf[108]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_retrieve2(lf[63],"object-files"),t1);}

/* k2558 in k743 in k737 in k731 in k728 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_2560(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[106]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve2(lf[55],"cleanup-filename"),t1);}

/* k2449 in k743 in k737 in k731 in k728 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_2451(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2451,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2454,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 841  cleanup-filename */
t3=C_retrieve2(lf[55],"cleanup-filename");
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_retrieve2(lf[92],"target-filename"));}

/* k2452 in k2449 in k743 in k737 in k731 in k728 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_2454(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[21],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2454,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2457,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2524,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2528,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2532,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(C_truep(C_retrieve2(lf[65],"cpp-mode"))?C_retrieve2(lf[32],"c++-linker"):C_retrieve2(lf[31],"linker"));
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2540,a[2]=t6,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2548,a[2]=((C_word*)t0)[2],a[3]=t7,tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 849  string-append */
t9=*((C_word*)lf[22]+1);
((C_proc4)C_retrieve_proc(t9))(4,t9,t8,C_retrieve2(lf[41],"link-output-flag"),t1);}

/* k2546 in k2452 in k2449 in k743 in k737 in k731 in k728 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_2548(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2548,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2552,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* csc.scm: 850  linker-options */
f_2675(t2);}

/* k2550 in k2546 in k2452 in k2449 in k743 in k737 in k731 in k728 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_2552(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2552,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2556,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* csc.scm: 851  linker-libraries */
f_2727(t2,(C_word)C_a_i_list(&a,1,C_SCHEME_FALSE));}

/* k2554 in k2550 in k2546 in k2452 in k2449 in k743 in k737 in k731 in k728 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_2556(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2556,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,((C_word*)t0)[5],((C_word*)t0)[4],t1);
/* csc.scm: 847  append */
t3=*((C_word*)lf[108]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k2538 in k2452 in k2449 in k743 in k737 in k731 in k728 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_2540(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 845  cons* */
t2=C_retrieve(lf[127]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2530 in k2452 in k2449 in k743 in k737 in k731 in k728 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_2532(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 844  string-intersperse */
t2=C_retrieve(lf[105]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2526 in k2452 in k2449 in k743 in k737 in k731 in k728 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_2528(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 843  $system */
t2=C_retrieve2(lf[131],"$system");
f_2905(3,t2,((C_word*)t0)[2],t1);}

/* k2522 in k2452 in k2449 in k743 in k737 in k731 in k728 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_2524(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_zerop(t1))){
t2=((C_word*)t0)[2];
f_2457(2,t2,C_SCHEME_UNDEFINED);}
else{
/* csc.scm: 852  exit */
t2=C_retrieve(lf[10]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_retrieve2(lf[130],"last-exit-code"));}}

/* k2455 in k2452 in k2449 in k743 in k737 in k731 in k728 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_2457(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2457,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2460,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2469,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[7],"osx"))){
t4=(C_word)C_i_not(C_retrieve2(lf[18],"cross-chicken"));
t5=t3;
f_2469(t5,(C_truep(t4)?t4:C_retrieve2(lf[17],"host-mode")));}
else{
t4=t3;
f_2469(t4,C_SCHEME_FALSE);}}

/* k2467 in k2455 in k2452 in k2449 in k743 in k737 in k731 in k728 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_fcall f_2469(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[25],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2469,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2482,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2486,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2490,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2494,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2498,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2502,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[17],"host-mode"))){
/* ##sys#peek-c-string */
t8=*((C_word*)lf[154]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,C_mpointer(&a,(void*)C_INSTALL_LIB_HOME),C_fix(0));}
else{
/* ##sys#peek-c-string */
t8=*((C_word*)lf[154]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,C_mpointer(&a,(void*)C_TARGET_RUN_LIB_HOME),C_fix(0));}}
else{
t2=((C_word*)t0)[3];
f_2460(2,t2,C_SCHEME_UNDEFINED);}}

/* k2500 in k2467 in k2455 in k2452 in k2449 in k743 in k737 in k731 in k728 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_2502(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 859  prefix */
f_457(((C_word*)t0)[2],lf[152],lf[153],t1);}

/* k2496 in k2467 in k2455 in k2452 in k2449 in k743 in k737 in k731 in k728 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_2498(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 858  make-pathname */
t2=C_retrieve(lf[20]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,lf[151]);}

/* k2492 in k2467 in k2455 in k2452 in k2449 in k743 in k737 in k731 in k728 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_2494(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 857  quotewrap */
f_470(((C_word*)t0)[2],t1);}

/* k2488 in k2467 in k2455 in k2452 in k2449 in k743 in k737 in k731 in k728 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_2490(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 855  string-append */
t2=*((C_word*)lf[22]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],lf[149],t1,lf[150],((C_word*)t0)[2]);}

/* k2484 in k2467 in k2455 in k2452 in k2449 in k743 in k737 in k731 in k728 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_2486(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 854  $system */
t2=C_retrieve2(lf[131],"$system");
f_2905(3,t2,((C_word*)t0)[2],t1);}

/* k2480 in k2467 in k2455 in k2452 in k2449 in k743 in k737 in k731 in k728 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_2482(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_zerop(t1))){
t2=((C_word*)t0)[2];
f_2460(2,t2,C_SCHEME_UNDEFINED);}
else{
/* csc.scm: 866  exit */
t2=C_retrieve(lf[10]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_retrieve2(lf[130],"last-exit-code"));}}

/* k2458 in k2455 in k2452 in k2449 in k743 in k737 in k731 in k728 in loop in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_2460(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(C_retrieve2(lf[94],"keep-files"))){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
/* for-each */
t2=*((C_word*)lf[148]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve2(lf[136],"$delete-file"),C_retrieve2(lf[64],"generated-object-files"));}}

/* shared-build in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_fcall f_691(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_691,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_696,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 489  cons* */
t4=C_retrieve(lf[127]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[146],lf[147],C_retrieve2(lf[83],"translate-options"));}

/* k694 in shared-build in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_696(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_696,2,t0,t1);}
t2=C_mutate(&lf[83],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_700,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 490  append */
t4=*((C_word*)lf[108]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,C_retrieve2(lf[52],"pic-options"),lf[145],C_retrieve2(lf[88],"compile-options"));}

/* k698 in k694 in shared-build in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_700(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_700,2,t0,t1);}
t2=C_mutate(&lf[88],t1);
t3=(C_truep(C_retrieve2(lf[7],"osx"))?(C_truep(((C_word*)t0)[3])?lf[141]:lf[142]):(C_truep(C_retrieve2(lf[5],"msvc"))?lf[143]:lf[144]));
t4=(C_word)C_a_i_cons(&a,2,t3,C_retrieve2(lf[91],"link-options"));
t5=C_mutate(&lf[91],t4);
t6=lf[98]=C_SCHEME_TRUE;;
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}

/* check in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_fcall f_652(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_652,NULL,4,t1,t2,t3,t4);}
t5=(C_word)C_i_length(t3);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_670,a[2]=t2,a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t7=t6;
f_670(2,t7,C_fix(1));}
else{
t7=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t7))){
t8=t6;
f_670(2,t8,(C_word)C_i_car(t4));}
else{
/* csc.scm: 485  ##sys#error */
t8=*((C_word*)lf[119]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,lf[0],t4);}}}

/* k668 in check in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_670(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_670,2,t0,t1);}
if(C_truep((C_word)C_i_greater_or_equalp(((C_word*)t0)[4],t1))){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
/* csc.scm: 486  quit */
f_428(((C_word*)t0)[3],lf[140],(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]));}}

/* t-options in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_fcall f_645(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_645,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_650,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 482  append */
t4=*((C_word*)lf[108]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_retrieve2(lf[83],"translate-options"),t2);}

/* k648 in t-options in k2961 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_650(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[83],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2951 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_2953(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2953,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2956,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2959,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#implicit-exit-handler */
t4=C_retrieve(lf[139]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k2957 in k2951 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_2959(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k2954 in k2951 in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_2956(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* $delete-file in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_2937(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2937,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2941,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[93],"verbose"))){
/* csc.scm: 946  print */
t4=*((C_word*)lf[135]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[138],t2);}
else{
t4=t3;
f_2941(2,t4,C_SCHEME_UNDEFINED);}}

/* k2939 in $delete-file in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_2941(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(C_retrieve2(lf[72],"dry-run"))){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
/* csc.scm: 947  delete-file */
t2=C_retrieve(lf[137]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* $system in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_2905(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2905,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2909,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[93],"verbose"))){
/* csc.scm: 933  print */
t4=*((C_word*)lf[135]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}
else{
t4=t3;
f_2909(2,t4,C_SCHEME_UNDEFINED);}}

/* k2907 in $system in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_2909(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2909,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2913,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[72],"dry-run"))){
t3=t2;
f_2913(t3,C_fix(0));}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2932,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 937  system */
t4=C_retrieve(lf[134]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}}

/* k2930 in k2907 in $system in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_2932(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_zerop(t1);
t3=((C_word*)t0)[2];
f_2913(t3,(C_truep(t2)?C_fix(0):C_fix(1)));}

/* k2911 in k2907 in $system in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_fcall f_2913(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2913,NULL,2,t0,t1);}
t2=C_mutate(&lf[130],t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2916,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_zerop(C_retrieve2(lf[130],"last-exit-code")))){
t4=t3;
f_2916(2,t4,C_SCHEME_UNDEFINED);}
else{
/* csc.scm: 941  printf */
t4=C_retrieve(lf[132]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[133],C_retrieve2(lf[130],"last-exit-code"),((C_word*)t0)[2]);}}

/* k2914 in k2911 in k2907 in $system in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_2916(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_retrieve2(lf[130],"last-exit-code"));}

/* quote-option in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_2876(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2876,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2883,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2888,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2902,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* string->list */
t6=C_retrieve(lf[128]);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k2900 in quote-option in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_2902(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 924  any */
t2=C_retrieve(lf[129]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2887 in quote-option in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_2888(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2888,3,t0,t1,t2);}
t3=(C_word)C_u_i_char_whitespacep(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?t3:(C_word)C_i_memq(t2,lf[120])));}

/* k2881 in quote-option in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_2883(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2883,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[2];
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2809,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2823,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2827,a[2]=t7,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* string->list */
t9=C_retrieve(lf[128]);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t3);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* k2825 in k2881 in quote-option in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_2827(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2827,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2829,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_2829(t5,((C_word*)t0)[2],t1);}

/* fold in k2825 in k2881 in quote-option in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_fcall f_2829(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(10);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2829,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_memq(t3,lf[120]))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2852,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_cdr(t2);
/* csc.scm: 915  fold */
t9=t4;
t10=t5;
t1=t9;
t2=t10;
goto loop;}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2859,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_u_i_char_whitespacep(t3))){
t5=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_TRUE);
t6=t4;
f_2859(t6,t5);}
else{
t5=t4;
f_2859(t5,C_SCHEME_UNDEFINED);}}}}

/* k2857 in fold in k2825 in k2881 in quote-option in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_fcall f_2859(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2859,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2866,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* csc.scm: 918  fold */
t4=((C_word*)((C_word*)t0)[2])[1];
f_2829(t4,t2,t3);}

/* k2864 in k2857 in fold in k2825 in k2881 in quote-option in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_2866(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2866,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k2850 in fold in k2825 in k2881 in quote-option in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_2852(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 915  cons* */
t2=C_retrieve(lf[127]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],C_make_character(92),((C_word*)t0)[2],t1);}

/* k2821 in k2881 in quote-option in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_2823(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* list->string */
t2=C_retrieve(lf[126]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2807 in k2881 in quote-option in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_2809(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2809,2,t0,t1);}
if(C_truep(((C_word*)((C_word*)t0)[3])[1])){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2819,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 920  string-translate* */
t3=C_retrieve(lf[124]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,t1,lf[125]);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}}

/* k2817 in k2807 in k2881 in quote-option in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_2819(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 920  string-append */
t2=*((C_word*)lf[22]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[122],t1,lf[123]);}

/* linker-libraries in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_fcall f_2727(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2727,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2731,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
t4=t3;
f_2731(2,t4,C_SCHEME_FALSE);}
else{
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t4))){
t5=t3;
f_2731(2,t5,(C_word)C_i_car(t2));}
else{
/* ##sys#error */
t5=*((C_word*)lf[119]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,lf[0],t2);}}}

/* k2729 in linker-libraries in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_2731(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2731,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2738,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2742,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2773,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2779,tmp=(C_word)a,a+=2,tmp);
/* csc.scm: 895  ##sys#call-with-values */
C_call_with_values(4,0,t3,t4,t5);}
else{
t4=t3;
f_2742(2,t4,C_SCHEME_END_OF_LIST);}}

/* a2778 in k2729 in linker-libraries in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_2779(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2rv,(void*)f_2779r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_2779r(t0,t1,t2);}}

static void C_ccall f_2779r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_vector_ref(t2,C_fix(0)));}

/* a2772 in k2729 in linker-libraries in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_2773(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2773,2,t0,t1);}
/* csc.scm: 895  static-extension-info */
f_2578(t1);}

/* k2740 in k2729 in linker-libraries in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_2742(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2742,2,t0,t1);}
t2=C_retrieve2(lf[99],"static");
t3=(C_truep(t2)?t2:C_retrieve2(lf[100],"static-libs"));
t4=(C_truep(t3)?(C_truep(C_retrieve2(lf[103],"gui"))?C_retrieve2(lf[79],"gui-library-files"):C_retrieve2(lf[81],"library-files")):(C_truep(C_retrieve2(lf[103],"gui"))?C_retrieve2(lf[80],"gui-shared-library-files"):C_retrieve2(lf[82],"shared-library-files")));
t5=C_retrieve2(lf[99],"static");
t6=(C_truep(t5)?t5:C_retrieve2(lf[100],"static-libs"));
t7=(C_truep(t6)?(C_word)C_a_i_list(&a,1,C_retrieve2(lf[73],"extra-libraries")):(C_word)C_a_i_list(&a,1,C_retrieve2(lf[74],"extra-shared-libraries")));
/* csc.scm: 894  append */
t8=*((C_word*)lf[108]+1);
((C_proc5)C_retrieve_proc(t8))(5,t8,((C_word*)t0)[2],t1,t4,t7);}

/* k2736 in k2729 in linker-libraries in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_2738(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 893  string-intersperse */
t2=C_retrieve(lf[105]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* linker-options in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_fcall f_2675(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2675,NULL,1,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2683,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2709,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2713,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2715,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2721,tmp=(C_word)a,a+=2,tmp);
/* csc.scm: 889  ##sys#call-with-values */
C_call_with_values(4,0,t4,t5,t6);}

/* a2720 in linker-options in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_2721(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2rv,(void*)f_2721r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_2721r(t0,t1,t2);}}

static void C_ccall f_2721r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_vector_ref(t2,C_fix(1)));}

/* a2714 in linker-options in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_2715(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2715,2,t0,t1);}
/* csc.scm: 889  static-extension-info */
f_2578(t1);}

/* k2711 in linker-options in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_2713(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 888  append */
t2=*((C_word*)lf[108]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],C_retrieve2(lf[90],"linking-optimization-options"),C_retrieve2(lf[91],"link-options"),t1);}

/* k2707 in linker-options in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_2709(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 887  string-intersperse */
t2=C_retrieve(lf[105]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2681 in linker-options in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_2683(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_truep(C_retrieve2(lf[99],"static"))?(C_truep(lf[3])?C_SCHEME_FALSE:(C_truep(C_retrieve2(lf[5],"msvc"))?C_SCHEME_FALSE:(C_word)C_i_not(C_retrieve2(lf[7],"osx")))):C_SCHEME_FALSE);
t3=(C_truep(t2)?lf[116]:lf[117]);
/* csc.scm: 886  string-append */
t4=*((C_word*)lf[22]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,((C_word*)t0)[2],t1,t3);}

/* static-extension-info in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_fcall f_2578(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2578,NULL,1,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2582,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 870  repository-path */
t3=C_retrieve(lf[114]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k2580 in static-extension-info in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_2582(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2582,2,t0,t1);}
t2=C_retrieve2(lf[99],"static");
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2588,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t2)){
t4=t3;
f_2588(t4,t2);}
else{
t4=C_retrieve2(lf[100],"static-libs");
t5=t3;
f_2588(t5,(C_truep(t4)?t4:C_retrieve2(lf[101],"static-extensions")));}}

/* k2586 in k2580 in static-extension-info in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_fcall f_2588(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2588,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2593,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_2593(t5,((C_word*)t0)[2],C_retrieve2(lf[102],"required-extensions"),C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}
else{
/* csc.scm: 883  values */
C_values(4,0,((C_word*)t0)[2],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}}

/* loop in k2586 in k2580 in static-extension-info in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_fcall f_2593(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2593,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2607,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 874  reverse */
t6=*((C_word*)lf[110]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t3);}
else{
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2614,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t4,a[5]=t1,a[6]=((C_word*)t0)[3],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t6=(C_word)C_i_car(t2);
/* csc.scm: 875  extension-information */
t7=C_retrieve(lf[113]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t5,t6);}}

/* k2612 in loop in k2586 in k2580 in static-extension-info in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_2614(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2614,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_assq(lf[111],t1);
t3=(C_word)C_i_assq(lf[112],t1);
t4=(C_word)C_i_cdr(((C_word*)t0)[7]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2634,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=t4,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t2)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2652,a[2]=((C_word*)t0)[3],a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_i_cadr(t2);
/* csc.scm: 880  make-pathname */
t8=C_retrieve(lf[20]);
((C_proc4)C_retrieve_proc(t8))(4,t8,t6,((C_word*)t0)[2],t7);}
else{
t6=t5;
f_2634(t6,((C_word*)t0)[3]);}}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
/* csc.scm: 882  loop */
t3=((C_word*)((C_word*)t0)[6])[1];
f_2593(t3,((C_word*)t0)[5],t2,((C_word*)t0)[3],((C_word*)t0)[4]);}}

/* k2650 in k2612 in loop in k2586 in k2580 in static-extension-info in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_2652(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2652,2,t0,t1);}
t2=((C_word*)t0)[3];
f_2634(t2,(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[2]));}

/* k2632 in k2612 in loop in k2586 in k2580 in static-extension-info in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_fcall f_2634(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2634,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2638,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=(C_word)C_i_cadr(((C_word*)t0)[3]);
t4=t2;
f_2638(t4,(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[2]));}
else{
t3=t2;
f_2638(t3,((C_word*)t0)[2]);}}

/* k2636 in k2632 in k2612 in loop in k2586 in k2580 in static-extension-info in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_fcall f_2638(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 879  loop */
t2=((C_word*)((C_word*)t0)[5])[1];
f_2593(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2605 in loop in k2586 in k2580 in static-extension-info in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_2607(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2607,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2611,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 874  reverse */
t3=*((C_word*)lf[110]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k2609 in k2605 in loop in k2586 in k2580 in static-extension-info in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_2611(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 874  values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* compiler-options in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_fcall f_2426(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2426,NULL,1,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2434,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2438,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=C_retrieve2(lf[99],"static");
t5=(C_truep(t4)?t4:C_retrieve2(lf[100],"static-libs"));
t6=(C_truep(t5)?C_SCHEME_END_OF_LIST:C_SCHEME_END_OF_LIST);
/* csc.scm: 829  append */
t7=*((C_word*)lf[108]+1);
((C_proc5)C_retrieve_proc(t7))(5,t7,t3,t6,C_retrieve2(lf[89],"compilation-optimization-options"),C_retrieve2(lf[88],"compile-options"));}

/* k2436 in compiler-options in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_2438(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[106]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve2(lf[107],"quote-option"),t1);}

/* k2432 in compiler-options in k620 in k605 in k596 in k3109 in k588 in k3142 in k580 in k576 in k550 in k545 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_2434(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 827  string-intersperse */
t2=C_retrieve(lf[105]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* f_3202 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_3202(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3202,3,t0,t1,t2);}
/* csc.scm: 165  quotewrap */
f_470(t1,t2);}

/* f_3207 in k537 in k533 in k502 in k498 in k494 in k490 in k486 in k482 in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_3207(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3207,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* quotewrap in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_fcall f_470(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_470,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_477,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 127  string-any */
t4=C_retrieve(lf[25]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,*((C_word*)lf[26]+1),t2);}

/* k475 in quotewrap in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_477(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* csc.scm: 128  string-append */
t2=*((C_word*)lf[22]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[23],((C_word*)t0)[2],lf[24]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* prefix in k445 in k441 in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_fcall f_457(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_457,NULL,4,t1,t2,t3,t4);}
if(C_truep(C_retrieve2(lf[14],"chicken-prefix"))){
t5=(C_word)C_a_i_list(&a,2,C_retrieve2(lf[14],"chicken-prefix"),t3);
/* csc.scm: 123  make-pathname */
t6=C_retrieve(lf[20]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t1,t5,t2);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* quit in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_fcall f_428(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_428,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_432,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_439,a[2]=t3,a[3]=t2,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* csc.scm: 113  current-error-port */
t6=C_retrieve(lf[13]);
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}

/* k437 in quit in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_439(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 113  fprintf */
t2=C_retrieve(lf[11]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[4],t1,lf[12],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k430 in quit in k424 in k3317 in k3321 in k3325 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 */
static void C_ccall f_432(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 114  exit */
t2=C_retrieve(lf[10]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_fix(64));}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[316] = {
{"toplevelcsc.scm",(void*)C_toplevel},
{"f_383csc.scm",(void*)f_383},
{"f_386csc.scm",(void*)f_386},
{"f_389csc.scm",(void*)f_389},
{"f_392csc.scm",(void*)f_392},
{"f_395csc.scm",(void*)f_395},
{"f_398csc.scm",(void*)f_398},
{"f_401csc.scm",(void*)f_401},
{"f_404csc.scm",(void*)f_404},
{"f_407csc.scm",(void*)f_407},
{"f_410csc.scm",(void*)f_410},
{"f_3327csc.scm",(void*)f_3327},
{"f_3323csc.scm",(void*)f_3323},
{"f_3319csc.scm",(void*)f_3319},
{"f_3315csc.scm",(void*)f_3315},
{"f_3311csc.scm",(void*)f_3311},
{"f_426csc.scm",(void*)f_426},
{"f_443csc.scm",(void*)f_443},
{"f_447csc.scm",(void*)f_447},
{"f_3295csc.scm",(void*)f_3295},
{"f_3291csc.scm",(void*)f_3291},
{"f_484csc.scm",(void*)f_484},
{"f_3277csc.scm",(void*)f_3277},
{"f_3281csc.scm",(void*)f_3281},
{"f_3273csc.scm",(void*)f_3273},
{"f_3269csc.scm",(void*)f_3269},
{"f_488csc.scm",(void*)f_488},
{"f_3259csc.scm",(void*)f_3259},
{"f_492csc.scm",(void*)f_492},
{"f_3249csc.scm",(void*)f_3249},
{"f_496csc.scm",(void*)f_496},
{"f_3236csc.scm",(void*)f_3236},
{"f_500csc.scm",(void*)f_500},
{"f_3223csc.scm",(void*)f_3223},
{"f_504csc.scm",(void*)f_504},
{"f_535csc.scm",(void*)f_535},
{"f_539csc.scm",(void*)f_539},
{"f_3192csc.scm",(void*)f_3192},
{"f_547csc.scm",(void*)f_547},
{"f_3182csc.scm",(void*)f_3182},
{"f_552csc.scm",(void*)f_552},
{"f_578csc.scm",(void*)f_578},
{"f_582csc.scm",(void*)f_582},
{"f_3156csc.scm",(void*)f_3156},
{"f_3160csc.scm",(void*)f_3160},
{"f_3152csc.scm",(void*)f_3152},
{"f_3148csc.scm",(void*)f_3148},
{"f_3144csc.scm",(void*)f_3144},
{"f_3140csc.scm",(void*)f_3140},
{"f_590csc.scm",(void*)f_590},
{"f_3123csc.scm",(void*)f_3123},
{"f_3127csc.scm",(void*)f_3127},
{"f_3119csc.scm",(void*)f_3119},
{"f_3115csc.scm",(void*)f_3115},
{"f_3111csc.scm",(void*)f_3111},
{"f_3107csc.scm",(void*)f_3107},
{"f_598csc.scm",(void*)f_598},
{"f_3094csc.scm",(void*)f_3094},
{"f_607csc.scm",(void*)f_607},
{"f_3071csc.scm",(void*)f_3071},
{"f_3067csc.scm",(void*)f_3067},
{"f_3063csc.scm",(void*)f_3063},
{"f_3037csc.scm",(void*)f_3037},
{"f_3053csc.scm",(void*)f_3053},
{"f_3049csc.scm",(void*)f_3049},
{"f_3045csc.scm",(void*)f_3045},
{"f_3041csc.scm",(void*)f_3041},
{"f_3024csc.scm",(void*)f_3024},
{"f_3020csc.scm",(void*)f_3020},
{"f_3016csc.scm",(void*)f_3016},
{"f_3012csc.scm",(void*)f_3012},
{"f_2996csc.scm",(void*)f_2996},
{"f_2992csc.scm",(void*)f_2992},
{"f_2988csc.scm",(void*)f_2988},
{"f_2984csc.scm",(void*)f_2984},
{"f_622csc.scm",(void*)f_622},
{"f_2971csc.scm",(void*)f_2971},
{"f_2967csc.scm",(void*)f_2967},
{"f_2963csc.scm",(void*)f_2963},
{"f_720csc.scm",(void*)f_720},
{"f_894csc.scm",(void*)f_894},
{"f_1379csc.scm",(void*)f_1379},
{"f_1620csc.scm",(void*)f_1620},
{"f_1623csc.scm",(void*)f_1623},
{"f_1626csc.scm",(void*)f_1626},
{"f_2008csc.scm",(void*)f_2008},
{"f_1677csc.scm",(void*)f_1677},
{"f_1686csc.scm",(void*)f_1686},
{"f_1863csc.scm",(void*)f_1863},
{"f_1971csc.scm",(void*)f_1971},
{"f_1977csc.scm",(void*)f_1977},
{"f_1874csc.scm",(void*)f_1874},
{"f_1885csc.scm",(void*)f_1885},
{"f_1961csc.scm",(void*)f_1961},
{"f_1953csc.scm",(void*)f_1953},
{"f_1936csc.scm",(void*)f_1936},
{"f_1912csc.scm",(void*)f_1912},
{"f_1917csc.scm",(void*)f_1917},
{"f_1899csc.scm",(void*)f_1899},
{"f_1868csc.scm",(void*)f_1868},
{"f_1833csc.scm",(void*)f_1833},
{"f_1764csc.scm",(void*)f_1764},
{"f_1816csc.scm",(void*)f_1816},
{"f_1812csc.scm",(void*)f_1812},
{"f_1797csc.scm",(void*)f_1797},
{"f_1795csc.scm",(void*)f_1795},
{"f_1791csc.scm",(void*)f_1791},
{"f_1768csc.scm",(void*)f_1768},
{"f_1754csc.scm",(void*)f_1754},
{"f_1741csc.scm",(void*)f_1741},
{"f_1724csc.scm",(void*)f_1724},
{"f_1710csc.scm",(void*)f_1710},
{"f_1696csc.scm",(void*)f_1696},
{"f_1658csc.scm",(void*)f_1658},
{"f_1664csc.scm",(void*)f_1664},
{"f_1667csc.scm",(void*)f_1667},
{"f_1613csc.scm",(void*)f_1613},
{"f_1617csc.scm",(void*)f_1617},
{"f_1567csc.scm",(void*)f_1567},
{"f_1597csc.scm",(void*)f_1597},
{"f_1589csc.scm",(void*)f_1589},
{"f_1577csc.scm",(void*)f_1577},
{"f_1556csc.scm",(void*)f_1556},
{"f_1531csc.scm",(void*)f_1531},
{"f_1543csc.scm",(void*)f_1543},
{"f_1535csc.scm",(void*)f_1535},
{"f_1518csc.scm",(void*)f_1518},
{"f_1492csc.scm",(void*)f_1492},
{"f_1504csc.scm",(void*)f_1504},
{"f_1496csc.scm",(void*)f_1496},
{"f_1471csc.scm",(void*)f_1471},
{"f_1475csc.scm",(void*)f_1475},
{"f_1454csc.scm",(void*)f_1454},
{"f_1437csc.scm",(void*)f_1437},
{"f_1420csc.scm",(void*)f_1420},
{"f_1403csc.scm",(void*)f_1403},
{"f_1362csc.scm",(void*)f_1362},
{"f_1352csc.scm",(void*)f_1352},
{"f_1342csc.scm",(void*)f_1342},
{"f_1332csc.scm",(void*)f_1332},
{"f_1322csc.scm",(void*)f_1322},
{"f_1312csc.scm",(void*)f_1312},
{"f_1291csc.scm",(void*)f_1291},
{"f_1267csc.scm",(void*)f_1267},
{"f_1278csc.scm",(void*)f_1278},
{"f_1270csc.scm",(void*)f_1270},
{"f_1254csc.scm",(void*)f_1254},
{"f_1243csc.scm",(void*)f_1243},
{"f_1203csc.scm",(void*)f_1203},
{"f_1207csc.scm",(void*)f_1207},
{"f_1210csc.scm",(void*)f_1210},
{"f_1112csc.scm",(void*)f_1112},
{"f_1130csc.scm",(void*)f_1130},
{"f_1115csc.scm",(void*)f_1115},
{"f_1055csc.scm",(void*)f_1055},
{"f_1043csc.scm",(void*)f_1043},
{"f_1031csc.scm",(void*)f_1031},
{"f_1019csc.scm",(void*)f_1019},
{"f_986csc.scm",(void*)f_986},
{"f_975csc.scm",(void*)f_975},
{"f_944csc.scm",(void*)f_944},
{"f_937csc.scm",(void*)f_937},
{"f_928csc.scm",(void*)f_928},
{"f_921csc.scm",(void*)f_921},
{"f_909csc.scm",(void*)f_909},
{"f_897csc.scm",(void*)f_897},
{"f_885csc.scm",(void*)f_885},
{"f_852csc.scm",(void*)f_852},
{"f_878csc.scm",(void*)f_878},
{"f_855csc.scm",(void*)f_855},
{"f_871csc.scm",(void*)f_871},
{"f_858csc.scm",(void*)f_858},
{"f_861csc.scm",(void*)f_861},
{"f_730csc.scm",(void*)f_730},
{"f_815csc.scm",(void*)f_815},
{"f_825csc.scm",(void*)f_825},
{"f_818csc.scm",(void*)f_818},
{"f_2086csc.scm",(void*)f_2086},
{"f_2090csc.scm",(void*)f_2090},
{"f_2337csc.scm",(void*)f_2337},
{"f_2340csc.scm",(void*)f_2340},
{"f_2331csc.scm",(void*)f_2331},
{"f_2093csc.scm",(void*)f_2093},
{"f_2096csc.scm",(void*)f_2096},
{"f_2268csc.scm",(void*)f_2268},
{"f_2310csc.scm",(void*)f_2310},
{"f_2276csc.scm",(void*)f_2276},
{"f_2291csc.scm",(void*)f_2291},
{"f_2296csc.scm",(void*)f_2296},
{"f_2280csc.scm",(void*)f_2280},
{"f_2288csc.scm",(void*)f_2288},
{"f_2284csc.scm",(void*)f_2284},
{"f_2272csc.scm",(void*)f_2272},
{"f_2264csc.scm",(void*)f_2264},
{"f_2260csc.scm",(void*)f_2260},
{"f_2256csc.scm",(void*)f_2256},
{"f_2099csc.scm",(void*)f_2099},
{"f_2103csc.scm",(void*)f_2103},
{"f_2107csc.scm",(void*)f_2107},
{"f_2113csc.scm",(void*)f_2113},
{"f_2121csc.scm",(void*)f_2121},
{"f_2125csc.scm",(void*)f_2125},
{"f_2238csc.scm",(void*)f_2238},
{"f_2130csc.scm",(void*)f_2130},
{"f_2199csc.scm",(void*)f_2199},
{"f_2206csc.scm",(void*)f_2206},
{"f_2186csc.scm",(void*)f_2186},
{"f_2132csc.scm",(void*)f_2132},
{"f_2116csc.scm",(void*)f_2116},
{"f_2078csc.scm",(void*)f_2078},
{"f_777csc.scm",(void*)f_777},
{"f_780csc.scm",(void*)f_780},
{"f_787csc.scm",(void*)f_787},
{"f_733csc.scm",(void*)f_733},
{"f_2371csc.scm",(void*)f_2371},
{"f_2375csc.scm",(void*)f_2375},
{"f_2412csc.scm",(void*)f_2412},
{"f_2424csc.scm",(void*)f_2424},
{"f_2416csc.scm",(void*)f_2416},
{"f_2420csc.scm",(void*)f_2420},
{"f_2400csc.scm",(void*)f_2400},
{"f_2396csc.scm",(void*)f_2396},
{"f_2378csc.scm",(void*)f_2378},
{"f_2355csc.scm",(void*)f_2355},
{"f_2369csc.scm",(void*)f_2369},
{"f_2359csc.scm",(void*)f_2359},
{"f_739csc.scm",(void*)f_739},
{"f_754csc.scm",(void*)f_754},
{"f_771csc.scm",(void*)f_771},
{"f_767csc.scm",(void*)f_767},
{"f_745csc.scm",(void*)f_745},
{"f_2572csc.scm",(void*)f_2572},
{"f_2566csc.scm",(void*)f_2566},
{"f_2564csc.scm",(void*)f_2564},
{"f_2560csc.scm",(void*)f_2560},
{"f_2451csc.scm",(void*)f_2451},
{"f_2454csc.scm",(void*)f_2454},
{"f_2548csc.scm",(void*)f_2548},
{"f_2552csc.scm",(void*)f_2552},
{"f_2556csc.scm",(void*)f_2556},
{"f_2540csc.scm",(void*)f_2540},
{"f_2532csc.scm",(void*)f_2532},
{"f_2528csc.scm",(void*)f_2528},
{"f_2524csc.scm",(void*)f_2524},
{"f_2457csc.scm",(void*)f_2457},
{"f_2469csc.scm",(void*)f_2469},
{"f_2502csc.scm",(void*)f_2502},
{"f_2498csc.scm",(void*)f_2498},
{"f_2494csc.scm",(void*)f_2494},
{"f_2490csc.scm",(void*)f_2490},
{"f_2486csc.scm",(void*)f_2486},
{"f_2482csc.scm",(void*)f_2482},
{"f_2460csc.scm",(void*)f_2460},
{"f_691csc.scm",(void*)f_691},
{"f_696csc.scm",(void*)f_696},
{"f_700csc.scm",(void*)f_700},
{"f_652csc.scm",(void*)f_652},
{"f_670csc.scm",(void*)f_670},
{"f_645csc.scm",(void*)f_645},
{"f_650csc.scm",(void*)f_650},
{"f_2953csc.scm",(void*)f_2953},
{"f_2959csc.scm",(void*)f_2959},
{"f_2956csc.scm",(void*)f_2956},
{"f_2937csc.scm",(void*)f_2937},
{"f_2941csc.scm",(void*)f_2941},
{"f_2905csc.scm",(void*)f_2905},
{"f_2909csc.scm",(void*)f_2909},
{"f_2932csc.scm",(void*)f_2932},
{"f_2913csc.scm",(void*)f_2913},
{"f_2916csc.scm",(void*)f_2916},
{"f_2876csc.scm",(void*)f_2876},
{"f_2902csc.scm",(void*)f_2902},
{"f_2888csc.scm",(void*)f_2888},
{"f_2883csc.scm",(void*)f_2883},
{"f_2827csc.scm",(void*)f_2827},
{"f_2829csc.scm",(void*)f_2829},
{"f_2859csc.scm",(void*)f_2859},
{"f_2866csc.scm",(void*)f_2866},
{"f_2852csc.scm",(void*)f_2852},
{"f_2823csc.scm",(void*)f_2823},
{"f_2809csc.scm",(void*)f_2809},
{"f_2819csc.scm",(void*)f_2819},
{"f_2727csc.scm",(void*)f_2727},
{"f_2731csc.scm",(void*)f_2731},
{"f_2779csc.scm",(void*)f_2779},
{"f_2773csc.scm",(void*)f_2773},
{"f_2742csc.scm",(void*)f_2742},
{"f_2738csc.scm",(void*)f_2738},
{"f_2675csc.scm",(void*)f_2675},
{"f_2721csc.scm",(void*)f_2721},
{"f_2715csc.scm",(void*)f_2715},
{"f_2713csc.scm",(void*)f_2713},
{"f_2709csc.scm",(void*)f_2709},
{"f_2683csc.scm",(void*)f_2683},
{"f_2578csc.scm",(void*)f_2578},
{"f_2582csc.scm",(void*)f_2582},
{"f_2588csc.scm",(void*)f_2588},
{"f_2593csc.scm",(void*)f_2593},
{"f_2614csc.scm",(void*)f_2614},
{"f_2652csc.scm",(void*)f_2652},
{"f_2634csc.scm",(void*)f_2634},
{"f_2638csc.scm",(void*)f_2638},
{"f_2607csc.scm",(void*)f_2607},
{"f_2611csc.scm",(void*)f_2611},
{"f_2426csc.scm",(void*)f_2426},
{"f_2438csc.scm",(void*)f_2438},
{"f_2434csc.scm",(void*)f_2434},
{"f_3202csc.scm",(void*)f_3202},
{"f_3207csc.scm",(void*)f_3207},
{"f_470csc.scm",(void*)f_470},
{"f_477csc.scm",(void*)f_477},
{"f_457csc.scm",(void*)f_457},
{"f_428csc.scm",(void*)f_428},
{"f_439csc.scm",(void*)f_439},
{"f_432csc.scm",(void*)f_432},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
