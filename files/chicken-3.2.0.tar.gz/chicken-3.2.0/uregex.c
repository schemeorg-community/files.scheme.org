/* Generated from regex.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-04-30 11:32
   Version 3.1.10 - linux-unix-gnu-x86	[ manyargs dload ptables applyhook ]
   SVN rev. 10602	compiled 2008-04-30 on galinha (Linux)
   command line: regex.scm -quiet -no-trace -optimize-level 2 -include-path . -explicit-use -include-path pcre -unsafe -no-lambda-info -output-file uregex.c
   unit: regex
*/

#include "chicken.h"

#include "pcre.h"

static const char *C_regex_error;
static int C_regex_error_offset;


#define OVECTOR_LENGTH_MULTIPLE 3
#define STATIC_OVECTOR_LEN 256
static int C_regex_ovector[OVECTOR_LENGTH_MULTIPLE * STATIC_OVECTOR_LEN];


static C_PTABLE_ENTRY *create_ptable(void);

static C_TLS C_word lf[100];
static double C_possibly_force_alignment;


/* from k1310 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub195(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub195(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
const pcre *code=(const pcre *)C_c_pointer_nn(C_a0);
const pcre_extra *extra=(const pcre_extra *)C_c_pointer_or_null(C_a1);
int cc;pcre_fullinfo(code, extra, PCRE_INFO_CAPTURECOUNT, &cc);return(cc + 1);
C_ret:
#undef return

return C_r;}

/* from k1296 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub183(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4,C_word C_a5) C_regparm;
C_regparm static C_word C_fcall stub183(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4,C_word C_a5){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
const pcre *code=(const pcre *)C_c_pointer_nn(C_a0);
const pcre_extra *extra=(const pcre_extra *)C_c_pointer_or_null(C_a1);
void * str=(void * )C_data_pointer(C_a2);
int start=(int )C_unfix(C_a3);
int range=(int )C_unfix(C_a4);
unsigned int options=(unsigned int )C_num_to_unsigned_int(C_a5);
return(pcre_exec(code, extra, str, start + range, start, options, C_regex_ovector, STATIC_OVECTOR_LEN * OVECTOR_LENGTH_MULTIPLE));
C_ret:
#undef return

return C_r;}

/* from ovector-end-ref */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub162(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub162(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int i=(int )C_unfix(C_a0);
return(C_regex_ovector[(i * 2) + 1]);
C_ret:
#undef return

return C_r;}

/* from ovector-start-ref */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub158(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub158(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int i=(int )C_unfix(C_a0);
return(C_regex_ovector[i * 2]);
C_ret:
#undef return

return C_r;}

/* from k1152 */
#define return(x) C_cblock C_r = (C_mpointer_or_false(&C_a,(void*)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub145(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub145(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
const pcre *code=(const pcre *)C_c_pointer_nn(C_a0);
return(pcre_study(code, 0, &C_regex_error));
C_ret:
#undef return

return C_r;}

/* from k978 */
#define return(x) C_cblock C_r = (C_mpointer_or_false(&C_a,(void*)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub98(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub98(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
char * patt=(char * )C_c_string(C_a0);
unsigned int options=(unsigned int )C_num_to_unsigned_int(C_a1);
const unsigned C_char *tables=(const unsigned C_char *)C_c_pointer_or_null(C_a2);
return(pcre_compile(patt, options, &C_regex_error, &C_regex_error_offset, tables));
C_ret:
#undef return

return C_r;}

/* from re-maketables */
#define return(x) C_cblock C_r = (C_mpointer_or_false(&C_a,(void*)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub72(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub72(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
return (pcre_maketables ());
C_ret:
#undef return

return C_r;}

/* from k873 */
static C_word C_fcall stub51(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub51(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_c_pointer_or_null(C_a0);
pcre_free(t0);
return C_r;}

C_noret_decl(C_regex_toplevel)
C_externexport void C_ccall C_regex_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_496)
static void C_ccall f_496(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2438)
static void C_ccall f_2438(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2438)
static void C_ccall f_2438r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2490)
static void C_fcall f_2490(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2485)
static void C_fcall f_2485(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2440)
static void C_fcall f_2440(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2464)
static void C_ccall f_2464(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2478)
static void C_ccall f_2478(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2467)
static void C_ccall f_2467(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2382)
static void C_ccall f_2382(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2389)
static void C_ccall f_2389(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2397)
static void C_fcall f_2397(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2429)
static void C_ccall f_2429(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2416)
static void C_ccall f_2416(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2419)
static void C_ccall f_2419(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2342)
static void C_ccall f_2342(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2351)
static void C_fcall f_2351(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2370)
static void C_ccall f_2370(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2377)
static void C_ccall f_2377(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2074)
static void C_ccall f_2074(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2089)
static void C_ccall f_2089(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2091)
static void C_fcall f_2091(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2337)
static void C_ccall f_2337(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2326)
static void C_ccall f_2326(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2149)
static void C_fcall f_2149(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2231)
static void C_fcall f_2231(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2255)
static void C_ccall f_2255(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2210)
static void C_ccall f_2210(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2181)
static void C_ccall f_2181(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2151)
static void C_fcall f_2151(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2159)
static void C_ccall f_2159(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2147)
static void C_ccall f_2147(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2134)
static void C_ccall f_2134(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2121)
static void C_ccall f_2121(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2085)
static void C_ccall f_2085(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1989)
static void C_ccall f_1989(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2002)
static void C_fcall f_2002(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2021)
static void C_fcall f_2021(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1937)
static void C_ccall f_1937(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1937)
static void C_ccall f_1937r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1952)
static void C_fcall f_1952(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1969)
static void C_ccall f_1969(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1694)
static void C_ccall f_1694(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_1694)
static void C_ccall f_1694r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_1830)
static void C_fcall f_1830(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1834)
static void C_ccall f_1834(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1925)
static void C_ccall f_1925(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1921)
static void C_ccall f_1921(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1892)
static void C_ccall f_1892(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1874)
static void C_ccall f_1874(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1867)
static void C_ccall f_1867(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1724)
static void C_fcall f_1724(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1730)
static void C_fcall f_1730(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1797)
static void C_ccall f_1797(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1785)
static void C_ccall f_1785(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1744)
static void C_ccall f_1744(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1709)
static C_word C_fcall f_1709(C_word *a,C_word t0,C_word t1);
C_noret_decl(f_1512)
static void C_ccall f_1512(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1512)
static void C_ccall f_1512r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1676)
static void C_ccall f_1676(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1650)
static void C_ccall f_1650(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1675)
static void C_ccall f_1675(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1630)
static void C_ccall f_1630(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1531)
static void C_fcall f_1531(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1539)
static void C_fcall f_1539(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1543)
static void C_ccall f_1543(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1604)
static void C_ccall f_1604(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1585)
static void C_ccall f_1585(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1619)
static void C_ccall f_1619(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1614)
static void C_ccall f_1614(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1502)
static void C_ccall f_1502(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1502)
static void C_ccall f_1502r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1510)
static void C_ccall f_1510(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1492)
static void C_ccall f_1492(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1492)
static void C_ccall f_1492r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1500)
static void C_ccall f_1500(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1446)
static void C_fcall f_1446(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1459)
static void C_fcall f_1459(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1428)
static void C_ccall f_1428(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1428)
static void C_ccall f_1428r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1436)
static void C_ccall f_1436(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1418)
static void C_ccall f_1418(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1418)
static void C_ccall f_1418r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1426)
static void C_ccall f_1426(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1375)
static void C_fcall f_1375(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1392)
static void C_ccall f_1392(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1317)
static void C_fcall f_1317(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_1321)
static void C_ccall f_1321(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1330)
static void C_ccall f_1330(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1268)
static void C_fcall f_1268(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1272)
static void C_ccall f_1272(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1280)
static void C_ccall f_1280(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1196)
static void C_fcall f_1196(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1214)
static void C_fcall f_1214(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1248)
static void C_fcall f_1248(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1252)
static void C_ccall f_1252(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1234)
static void C_ccall f_1234(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1156)
static void C_ccall f_1156(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1169)
static void C_ccall f_1169(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1178)
static void C_ccall f_1178(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1070)
static void C_ccall f_1070(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1070)
static void C_ccall f_1070r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1104)
static void C_fcall f_1104(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1099)
static void C_fcall f_1099(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1072)
static void C_fcall f_1072(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1082)
static void C_ccall f_1082(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1095)
static void C_ccall f_1095(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1085)
static void C_ccall f_1085(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1088)
static void C_ccall f_1088(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1000)
static void C_ccall f_1000(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1000)
static void C_ccall f_1000r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1068)
static void C_ccall f_1068(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1058)
static void C_ccall f_1058(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1061)
static void C_ccall f_1061(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1002)
static void C_fcall f_1002(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1023)
static void C_fcall f_1023(C_word t0,C_word t1) C_noret;
C_noret_decl(f_985)
static void C_fcall f_985(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_976)
static void C_ccall f_976(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_957)
static void C_fcall f_957(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_969)
static void C_ccall f_969(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_965)
static void C_ccall f_965(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_951)
static void C_ccall f_951(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_903)
static void C_ccall f_903(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_903)
static void C_ccall f_903r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_931)
static void C_ccall f_931(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_934)
static void C_ccall f_934(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_898)
static void C_fcall f_898(C_word t0,C_word t1) C_noret;
C_noret_decl(f_902)
static void C_ccall f_902(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_880)
static void C_ccall f_880(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_870)
static void C_ccall f_870(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_498)
static void C_fcall f_498(C_word t0,C_word t1) C_noret;
C_noret_decl(f_508)
static void C_fcall f_508(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_533)
static void C_ccall f_533(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_483)
static void C_ccall f_483(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_490)
static void C_ccall f_490(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_2490)
static void C_fcall trf_2490(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2490(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2490(t0,t1);}

C_noret_decl(trf_2485)
static void C_fcall trf_2485(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2485(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2485(t0,t1,t2);}

C_noret_decl(trf_2440)
static void C_fcall trf_2440(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2440(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2440(t0,t1,t2,t3);}

C_noret_decl(trf_2397)
static void C_fcall trf_2397(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2397(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2397(t0,t1,t2);}

C_noret_decl(trf_2351)
static void C_fcall trf_2351(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2351(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2351(t0,t1,t2);}

C_noret_decl(trf_2091)
static void C_fcall trf_2091(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2091(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2091(t0,t1,t2);}

C_noret_decl(trf_2149)
static void C_fcall trf_2149(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2149(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2149(t0,t1,t2);}

C_noret_decl(trf_2231)
static void C_fcall trf_2231(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2231(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2231(t0,t1);}

C_noret_decl(trf_2151)
static void C_fcall trf_2151(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2151(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2151(t0,t1,t2,t3);}

C_noret_decl(trf_2002)
static void C_fcall trf_2002(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2002(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2002(t0,t1,t2);}

C_noret_decl(trf_2021)
static void C_fcall trf_2021(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2021(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2021(t0,t1);}

C_noret_decl(trf_1952)
static void C_fcall trf_1952(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1952(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1952(t0,t1,t2,t3);}

C_noret_decl(trf_1830)
static void C_fcall trf_1830(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1830(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1830(t0,t1,t2,t3);}

C_noret_decl(trf_1724)
static void C_fcall trf_1724(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1724(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1724(t0,t1,t2);}

C_noret_decl(trf_1730)
static void C_fcall trf_1730(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1730(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1730(t0,t1,t2,t3);}

C_noret_decl(trf_1531)
static void C_fcall trf_1531(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1531(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1531(t0,t1);}

C_noret_decl(trf_1539)
static void C_fcall trf_1539(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1539(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1539(t0,t1,t2,t3);}

C_noret_decl(trf_1446)
static void C_fcall trf_1446(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1446(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1446(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1459)
static void C_fcall trf_1459(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1459(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1459(t0,t1);}

C_noret_decl(trf_1375)
static void C_fcall trf_1375(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1375(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1375(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1317)
static void C_fcall trf_1317(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1317(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_1317(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_1268)
static void C_fcall trf_1268(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1268(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1268(t0,t1,t2,t3);}

C_noret_decl(trf_1196)
static void C_fcall trf_1196(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1196(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1196(t0,t1);}

C_noret_decl(trf_1214)
static void C_fcall trf_1214(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1214(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1214(t0,t1,t2);}

C_noret_decl(trf_1248)
static void C_fcall trf_1248(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1248(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1248(t0,t1);}

C_noret_decl(trf_1104)
static void C_fcall trf_1104(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1104(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1104(t0,t1);}

C_noret_decl(trf_1099)
static void C_fcall trf_1099(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1099(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1099(t0,t1,t2);}

C_noret_decl(trf_1072)
static void C_fcall trf_1072(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1072(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1072(t0,t1,t2,t3);}

C_noret_decl(trf_1002)
static void C_fcall trf_1002(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1002(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1002(t0,t1);}

C_noret_decl(trf_1023)
static void C_fcall trf_1023(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1023(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1023(t0,t1);}

C_noret_decl(trf_985)
static void C_fcall trf_985(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_985(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_985(t0,t1,t2,t3);}

C_noret_decl(trf_957)
static void C_fcall trf_957(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_957(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_957(t0,t1,t2,t3,t4);}

C_noret_decl(trf_898)
static void C_fcall trf_898(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_898(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_898(t0,t1);}

C_noret_decl(trf_498)
static void C_fcall trf_498(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_498(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_498(t0,t1);}

C_noret_decl(trf_508)
static void C_fcall trf_508(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_508(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_508(t0,t1,t2,t3);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr2rv)
static void C_fcall tr2rv(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2rv(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n+1);
t2=C_restore_rest_vector(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr5rv)
static void C_fcall tr5rv(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5rv(C_proc5 k){
int n;
C_word *a,t5;
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
n=C_rest_count(0);
a=C_alloc(n+1);
t5=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr4rv)
static void C_fcall tr4rv(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4rv(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n+1);
t4=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_regex_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_regex_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("regex_toplevel"));
C_check_nursery_minimum(5);
if(!C_demand(5)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(770)){
C_save(t1);
C_rereclaim2(770*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(5);
C_initialize_lf(lf,100);
lf[0]=C_h_intern(&lf[0],23,"\003syscheck-chardef-table");
lf[1]=C_h_intern(&lf[1],9,"\003syserror");
lf[2]=C_decode_literal(C_heaptop,"\376B\000\000-invalid character definition tables structure");
lf[3]=C_h_intern(&lf[3],20,"regex-chardef-table\077");
lf[5]=C_h_intern(&lf[5],8,"caseless");
lf[6]=C_h_intern(&lf[6],9,"multiline");
lf[7]=C_h_intern(&lf[7],6,"dotall");
lf[8]=C_h_intern(&lf[8],8,"extended");
lf[9]=C_h_intern(&lf[9],8,"anchored");
lf[10]=C_h_intern(&lf[10],14,"dollar-endonly");
lf[11]=C_h_intern(&lf[11],5,"extra");
lf[12]=C_h_intern(&lf[12],6,"notbol");
lf[13]=C_h_intern(&lf[13],6,"noteol");
lf[14]=C_h_intern(&lf[14],8,"ungreedy");
lf[15]=C_h_intern(&lf[15],8,"notempty");
lf[16]=C_h_intern(&lf[16],4,"utf8");
lf[17]=C_h_intern(&lf[17],15,"no-auto-capture");
lf[18]=C_h_intern(&lf[18],13,"no-utf8-check");
lf[19]=C_h_intern(&lf[19],12,"auto-callout");
lf[20]=C_h_intern(&lf[20],7,"partial");
lf[21]=C_h_intern(&lf[21],12,"dfa-shortest");
lf[22]=C_h_intern(&lf[22],11,"dfa-restart");
lf[23]=C_h_intern(&lf[23],9,"firstline");
lf[24]=C_h_intern(&lf[24],8,"dupnames");
lf[25]=C_h_intern(&lf[25],10,"newline-cr");
lf[26]=C_h_intern(&lf[26],10,"newline-lf");
lf[27]=C_h_intern(&lf[27],12,"newline-crlf");
lf[28]=C_h_intern(&lf[28],11,"newline-any");
lf[29]=C_h_intern(&lf[29],15,"newline-anycrlf");
lf[30]=C_h_intern(&lf[30],11,"bsr-anycrlf");
lf[31]=C_h_intern(&lf[31],11,"bsr-unicode");
lf[32]=C_h_intern(&lf[32],5,"error");
lf[33]=C_decode_literal(C_heaptop,"\376B\000\000\024not a member of enum");
lf[34]=C_h_intern(&lf[34],11,"pcre-option");
lf[36]=C_h_intern(&lf[36],13,"chardef-table");
lf[37]=C_h_intern(&lf[37],23,"\003sysmake-tagged-pointer");
lf[38]=C_h_intern(&lf[38],19,"regex-chardef-table");
lf[39]=C_h_intern(&lf[39],15,"\003syssignal-hook");
lf[40]=C_h_intern(&lf[40],11,"\000type-error");
lf[41]=C_decode_literal(C_heaptop,"\376B\000\000!bad argument type - not a pointer");
lf[42]=C_h_intern(&lf[42],14,"set-finalizer!");
lf[43]=C_h_intern(&lf[43],14,"\003syserror-hook");
lf[44]=C_h_intern(&lf[44],7,"regexp\077");
lf[45]=C_h_intern(&lf[45],6,"regexp");
lf[46]=C_h_intern(&lf[46],13,"string-append");
lf[48]=C_decode_literal(C_heaptop,"\376B\000\000\003 - ");
lf[49]=C_h_intern(&lf[49],17,"\003syspeek-c-string");
lf[51]=C_decode_literal(C_heaptop,"\376B\000\000!cannot compile regular expression");
lf[52]=C_h_intern(&lf[52],17,"\003sysmake-c-string");
lf[53]=C_h_intern(&lf[53],7,"regexp*");
lf[54]=C_h_intern(&lf[54],15,"regexp-optimize");
lf[55]=C_decode_literal(C_heaptop,"\376B\000\000\042cannot optimize regular expression");
lf[57]=C_h_intern(&lf[57],9,"substring");
lf[59]=C_h_intern(&lf[59],7,"\003sysmap");
lf[61]=C_decode_literal(C_heaptop,"\376B\000\000\077bad argument type - not a string or compiled regular expression");
lf[62]=C_h_intern(&lf[62],19,"\003sysundefined-value");
lf[63]=C_h_intern(&lf[63],12,"string-match");
lf[64]=C_h_intern(&lf[64],22,"string-match-positions");
lf[65]=C_h_intern(&lf[65],21,"make-anchored-pattern");
lf[66]=C_h_intern(&lf[66],13,"string-search");
lf[67]=C_h_intern(&lf[67],23,"string-search-positions");
lf[68]=C_h_intern(&lf[68],7,"reverse");
lf[69]=C_h_intern(&lf[69],19,"string-split-fields");
lf[70]=C_h_intern(&lf[70],6,"\000infix");
lf[71]=C_h_intern(&lf[71],7,"\000suffix");
lf[72]=C_decode_literal(C_heaptop,"\376B\000\000\037record does not end with suffix");
lf[73]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[74]=C_h_intern(&lf[74],11,"make-string");
lf[75]=C_h_intern(&lf[75],17,"string-substitute");
lf[76]=C_decode_literal(C_heaptop,"\376B\000\000\030empty substitution match");
lf[77]=C_h_intern(&lf[77],21,"\003sysfragments->string");
lf[78]=C_h_intern(&lf[78],18,"string-substitute*");
lf[79]=C_h_intern(&lf[79],5,"glob\077");
lf[80]=C_h_intern(&lf[80],12,"list->string");
lf[81]=C_h_intern(&lf[81],12,"string->list");
lf[82]=C_h_intern(&lf[82],12,"glob->regexp");
lf[83]=C_decode_literal(C_heaptop,"\376B\000\000!unexpected end of character class");
lf[84]=C_h_intern(&lf[84],15,"\003sysmatch-error");
lf[85]=C_h_intern(&lf[85],4,"grep");
lf[86]=C_h_intern(&lf[86],18,"open-output-string");
lf[87]=C_h_intern(&lf[87],17,"get-output-string");
lf[88]=C_h_intern(&lf[88],13,"regexp-escape");
lf[89]=C_h_intern(&lf[89],16,"\003syswrite-char-0");
lf[90]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[91]=C_decode_literal(C_heaptop,"\376B\000\000\001^");
lf[92]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[93]=C_decode_literal(C_heaptop,"\376B\000\000\001$");
lf[94]=C_h_intern(&lf[94],10,"bitwise-or");
lf[95]=C_h_intern(&lf[95],7,"warning");
lf[96]=C_decode_literal(C_heaptop,"\376B\000\000<cannot select partial anchor for compiled regular expression");
lf[97]=C_h_intern(&lf[97],17,"register-feature!");
lf[98]=C_h_intern(&lf[98],5,"regex");
lf[99]=C_h_intern(&lf[99],4,"pcre");
C_register_lf2(lf,100,create_ptable());
t2=C_mutate((C_word*)lf[0]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_483,tmp=(C_word)a,a+=2,tmp));
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_496,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* regex.scm: 109  register-feature! */
t4=*((C_word*)lf[97]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,lf[98],lf[99]);}

/* k494 */
static void C_ccall f_496(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word ab[76],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_496,2,t0,t1);}
t2=C_mutate(&lf[4],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_498,tmp=(C_word)a,a+=2,tmp));
t3=C_mutate(&lf[35],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_870,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate((C_word*)lf[3]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_880,tmp=(C_word)a,a+=2,tmp));
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_898,tmp=(C_word)a,a+=2,tmp);
t6=C_mutate((C_word*)lf[38]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_903,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[44]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_951,tmp=(C_word)a,a+=2,tmp));
t8=*((C_word*)lf[46]+1);
t9=C_mutate(&lf[47],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_957,a[2]=t8,tmp=(C_word)a,a+=3,tmp));
t10=C_mutate(&lf[50],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_985,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate((C_word*)lf[45]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1000,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate((C_word*)lf[53]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1070,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate((C_word*)lf[54]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1156,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate(&lf[56],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1196,tmp=(C_word)a,a+=2,tmp));
t15=*((C_word*)lf[57]+1);
t16=C_mutate(&lf[58],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1268,a[2]=t15,tmp=(C_word)a,a+=3,tmp));
t17=C_mutate(&lf[60],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1317,tmp=(C_word)a,a+=2,tmp));
t18=*((C_word*)lf[62]+1);
t19=C_mutate((C_word*)lf[63]+1,t18);
t20=*((C_word*)lf[62]+1);
t21=C_mutate((C_word*)lf[64]+1,t20);
t22=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1375,tmp=(C_word)a,a+=2,tmp);
t23=C_mutate((C_word*)lf[63]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1418,a[2]=t22,tmp=(C_word)a,a+=3,tmp));
t24=C_mutate((C_word*)lf[64]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1428,a[2]=t22,tmp=(C_word)a,a+=3,tmp));
t25=*((C_word*)lf[62]+1);
t26=C_mutate((C_word*)lf[66]+1,t25);
t27=*((C_word*)lf[62]+1);
t28=C_mutate((C_word*)lf[67]+1,t27);
t29=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1446,tmp=(C_word)a,a+=2,tmp);
t30=C_mutate((C_word*)lf[66]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1492,a[2]=t29,tmp=(C_word)a,a+=3,tmp));
t31=C_mutate((C_word*)lf[67]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1502,a[2]=t29,tmp=(C_word)a,a+=3,tmp));
t32=*((C_word*)lf[68]+1);
t33=*((C_word*)lf[57]+1);
t34=*((C_word*)lf[67]+1);
t35=C_mutate((C_word*)lf[69]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1512,a[2]=t32,a[3]=t34,a[4]=t33,tmp=(C_word)a,a+=5,tmp));
t36=*((C_word*)lf[57]+1);
t37=*((C_word*)lf[68]+1);
t38=*((C_word*)lf[74]+1);
t39=*((C_word*)lf[67]+1);
t40=C_mutate((C_word*)lf[75]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1694,a[2]=t39,a[3]=t37,a[4]=t36,tmp=(C_word)a,a+=5,tmp));
t41=*((C_word*)lf[75]+1);
t42=C_mutate((C_word*)lf[78]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1937,a[2]=t41,tmp=(C_word)a,a+=3,tmp));
t43=C_mutate((C_word*)lf[79]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1989,tmp=(C_word)a,a+=2,tmp));
t44=*((C_word*)lf[80]+1);
t45=*((C_word*)lf[81]+1);
t46=C_mutate((C_word*)lf[82]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2074,a[2]=t45,a[3]=t44,tmp=(C_word)a,a+=4,tmp));
t47=*((C_word*)lf[66]+1);
t48=C_mutate((C_word*)lf[85]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2342,a[2]=t47,tmp=(C_word)a,a+=3,tmp));
t49=*((C_word*)lf[86]+1);
t50=*((C_word*)lf[87]+1);
t51=C_mutate((C_word*)lf[88]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2382,a[2]=t49,a[3]=t50,tmp=(C_word)a,a+=4,tmp));
t52=*((C_word*)lf[46]+1);
t53=C_mutate((C_word*)lf[65]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2438,a[2]=t52,tmp=(C_word)a,a+=3,tmp));
t54=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t54+1)))(2,t54,C_SCHEME_UNDEFINED);}

/* make-anchored-pattern in k494 */
static void C_ccall f_2438(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr3r,(void*)f_2438r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2438r(t0,t1,t2,t3);}}

static void C_ccall f_2438r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(10);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2440,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2485,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2490,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-nos421437 */
t7=t6;
f_2490(t7,t1);}
else{
t7=(C_word)C_u_i_car(t3);
t8=(C_word)C_slot(t3,C_fix(1));
if(C_truep((C_word)C_i_nullp(t8))){
/* def-noe422435 */
t9=t5;
f_2485(t9,t1,t7);}
else{
t9=(C_word)C_u_i_car(t8);
t10=(C_word)C_slot(t8,C_fix(1));
/* body419424 */
t11=t4;
f_2440(t11,t1,t7,t9);}}}

/* def-nos421 in make-anchored-pattern in k494 */
static void C_fcall f_2490(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2490,NULL,2,t0,t1);}
/* def-noe422435 */
t2=((C_word*)t0)[2];
f_2485(t2,t1,C_SCHEME_FALSE);}

/* def-noe422 in make-anchored-pattern in k494 */
static void C_fcall f_2485(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2485,NULL,3,t0,t1,t2);}
/* body419424 */
t3=((C_word*)t0)[2];
f_2440(t3,t1,t2,C_SCHEME_FALSE);}

/* body419 in make-anchored-pattern in k494 */
static void C_fcall f_2440(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2440,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_stringp(((C_word*)t0)[3]))){
t4=(C_truep(t2)?lf[90]:lf[91]);
t5=(C_truep(t3)?lf[92]:lf[93]);
/* regex.scm: 647  string-append */
t6=((C_word*)t0)[2];
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t1,t4,((C_word*)t0)[3],t5);}
else{
t4=(C_word)C_i_check_structure_2(((C_word*)t0)[3],lf[45],lf[65]);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2464,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t6=t2;
t7=(C_truep(t6)?t6:t3);
if(C_truep(t7)){
/* regex.scm: 651  warning */
t8=*((C_word*)lf[95]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t5,lf[65],lf[96]);}
else{
t8=t5;
f_2464(2,t8,C_SCHEME_UNDEFINED);}}}

/* k2462 in body419 in make-anchored-pattern in k494 */
static void C_ccall f_2464(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2464,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2467,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=*((C_word*)lf[45]+1);
t5=(C_word)C_slot(t4,C_fix(3));
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2478,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* regex.scm: 655  pcre-option->number */
f_498(t6,lf[9]);}

/* k2476 in k2462 in body419 in make-anchored-pattern in k494 */
static void C_ccall f_2478(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* regex.scm: 654  bitwise-or */
t2=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2465 in k2462 in body419 in make-anchored-pattern in k494 */
static void C_ccall f_2467(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[4],C_fix(3),t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[2]);}

/* regexp-escape in k494 */
static void C_ccall f_2382(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2382,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[88]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2389,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* regex.scm: 626  open-output-string */
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* k2387 in regexp-escape in k494 */
static void C_ccall f_2389(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2389,2,t0,t1);}
t2=(C_word)C_block_size(((C_word*)t0)[4]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2397,a[2]=t4,a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=t2,tmp=(C_word)a,a+=7,tmp));
t6=((C_word*)t4)[1];
f_2397(t6,((C_word*)t0)[2],C_fix(0));}

/* loop in k2387 in regexp-escape in k494 */
static void C_fcall f_2397(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2397,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[6]))){
/* regex.scm: 629  get-output-string */
t3=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,((C_word*)t0)[4]);}
else{
t3=(C_word)C_subchar(((C_word*)t0)[3],t2);
if(C_truep((C_truep((C_word)C_eqp(t3,C_make_character(46)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(92)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(63)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(42)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(43)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(94)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(36)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(40)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(41)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(91)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(93)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(124)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(123)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(125)))?C_SCHEME_TRUE:C_SCHEME_FALSE)))))))))))))))){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2416,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* regex.scm: 632  ##sys#write-char-0 */
t5=*((C_word*)lf[89]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_make_character(92),((C_word*)t0)[4]);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2429,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* regex.scm: 636  ##sys#write-char-0 */
t5=*((C_word*)lf[89]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,(C_word)C_subchar(((C_word*)t0)[3],t2),((C_word*)t0)[4]);}}}

/* k2427 in loop in k2387 in regexp-escape in k494 */
static void C_ccall f_2429(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* regex.scm: 637  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2397(t3,((C_word*)t0)[2],t2);}

/* k2414 in loop in k2387 in regexp-escape in k494 */
static void C_ccall f_2416(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2416,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2419,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* regex.scm: 633  ##sys#write-char-0 */
t3=*((C_word*)lf[89]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,(C_word)C_subchar(((C_word*)t0)[3],((C_word*)t0)[6]),((C_word*)t0)[2]);}

/* k2417 in k2414 in loop in k2387 in regexp-escape in k494 */
static void C_ccall f_2419(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* regex.scm: 634  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2397(t3,((C_word*)t0)[2],t2);}

/* grep in k494 */
static void C_ccall f_2342(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2342,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_list_2(t3,lf[85]);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2351,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t6,tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_2351(t8,t1,t3);}

/* loop in grep in k494 */
static void C_fcall f_2351(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2351,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2370,a[2]=t4,a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* regex.scm: 614  string-search */
t6=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,((C_word*)t0)[2],t3);}}

/* k2368 in loop in grep in k494 */
static void C_ccall f_2370(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2370,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2377,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* regex.scm: 615  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2351(t3,t2,((C_word*)t0)[2]);}
else{
/* regex.scm: 616  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_2351(t2,((C_word*)t0)[5],((C_word*)t0)[2]);}}

/* k2375 in k2368 in loop in grep in k494 */
static void C_ccall f_2377(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2377,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* glob->regexp in k494 */
static void C_ccall f_2074(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2074,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[82]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2085,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2089,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* regex.scm: 581  string->list */
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k2087 in glob->regexp in k494 */
static void C_ccall f_2089(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2089,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2091,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_2091(t5,((C_word*)t0)[2],t1);}

/* loop in k2087 in glob->regexp in k494 */
static void C_fcall f_2091(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a;
loop:
a=C_alloc(24);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2091,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_slot(t2,C_fix(1));
switch(t3){
case C_make_character(42):
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2121,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* regex.scm: 586  loop */
t16=t5;
t17=t4;
t1=t16;
t2=t17;
goto loop;
case C_make_character(63):
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2134,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* regex.scm: 587  loop */
t16=t5;
t17=t4;
t1=t16;
t2=t17;
goto loop;
case C_make_character(91):
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2147,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2149,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t7,tmp=(C_word)a,a+=5,tmp));
t9=((C_word*)t7)[1];
f_2149(t9,t5,t4);
default:
t5=(C_word)C_u_i_char_alphabeticp(t3);
t6=(C_truep(t5)?t5:(C_word)C_u_i_char_numericp(t3));
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2326,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* regex.scm: 599  loop */
t16=t7;
t17=t4;
t1=t16;
t2=t17;
goto loop;}
else{
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2337,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* regex.scm: 600  loop */
t16=t7;
t17=t4;
t1=t16;
t2=t17;
goto loop;}}}}

/* k2335 in loop in k2087 in glob->regexp in k494 */
static void C_ccall f_2337(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2337,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,C_make_character(92),t2));}

/* k2324 in loop in k2087 in glob->regexp in k494 */
static void C_ccall f_2326(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2326,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* loop2 in loop in k2087 in glob->regexp in k494 */
static void C_fcall f_2149(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word *a;
loop:
a=C_alloc(16);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2149,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2151,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_u_i_car(t2);
t5=(C_word)C_eqp(t4,C_make_character(93));
if(C_truep(t5)){
t6=(C_word)C_slot(t2,C_fix(1));
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2181,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* regex.scm: 593  loop */
t8=((C_word*)((C_word*)t0)[3])[1];
f_2091(t8,t7,t6);}
else{
t6=(C_word)C_u_i_car(t2);
t7=(C_word)C_eqp(t6,C_make_character(45));
if(C_truep(t7)){
t8=(C_word)C_slot(t2,C_fix(1));
if(C_truep((C_word)C_i_pairp(t8))){
t9=(C_word)C_u_i_cadr(t2);
t10=(C_word)C_u_i_cddr(t2);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2210,a[2]=t1,a[3]=t9,tmp=(C_word)a,a+=4,tmp);
/* loop2370 */
t22=t11;
t23=t10;
t1=t22;
t2=t23;
goto loop;}
else{
t9=(C_word)C_u_i_car(t2);
t10=(C_word)C_slot(t2,C_fix(1));
/* g376379 */
t11=t3;
f_2151(t11,t1,t9,t10);}}
else{
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2231,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t9=(C_word)C_slot(t2,C_fix(1));
if(C_truep((C_word)C_i_pairp(t9))){
t10=(C_word)C_u_i_cadr(t2);
t11=(C_word)C_eqp(t10,C_make_character(45));
if(C_truep(t11)){
t12=(C_word)C_u_i_cddr(t2);
t13=t8;
f_2231(t13,(C_word)C_i_pairp(t12));}
else{
t12=t8;
f_2231(t12,C_SCHEME_FALSE);}}
else{
t10=t8;
f_2231(t10,C_SCHEME_FALSE);}}}}
else{
if(C_truep((C_word)C_i_nullp(t2))){
/* error */
t4=*((C_word*)lf[32]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t1,lf[82],lf[83],((C_word*)t0)[2]);}
else{
/* ##sys#match-error */
t4=*((C_word*)lf[84]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t2);}}}

/* k2229 in loop2 in loop in k2087 in glob->regexp in k494 */
static void C_fcall f_2231(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2231,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_u_i_car(((C_word*)t0)[5]);
t3=(C_word)C_u_i_caddr(((C_word*)t0)[5]);
t4=(C_word)C_u_i_cdddr(((C_word*)t0)[5]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2255,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* loop2370 */
t6=((C_word*)((C_word*)t0)[3])[1];
f_2149(t6,t5,t4);}
else{
t2=(C_word)C_u_i_car(((C_word*)t0)[5]);
t3=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* g376379 */
t4=((C_word*)t0)[2];
f_2151(t4,((C_word*)t0)[4],t2,t3);}}

/* k2253 in k2229 in loop2 in loop in k2087 in glob->regexp in k494 */
static void C_ccall f_2255(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2255,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,C_make_character(45),t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* k2208 in loop2 in loop in k2087 in glob->regexp in k494 */
static void C_ccall f_2210(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2210,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,C_make_character(45),t2));}

/* k2179 in loop2 in loop in k2087 in glob->regexp in k494 */
static void C_ccall f_2181(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2181,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,C_make_character(93),t1));}

/* g376 in loop2 in loop in k2087 in glob->regexp in k494 */
static void C_fcall f_2151(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2151,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2159,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* regex.scm: 596  loop2 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_2149(t5,t4,t3);}

/* k2157 in g376 in loop2 in loop in k2087 in glob->regexp in k494 */
static void C_ccall f_2159(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2159,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k2145 in loop in k2087 in glob->regexp in k494 */
static void C_ccall f_2147(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2147,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,C_make_character(91),t1));}

/* k2132 in loop in k2087 in glob->regexp in k494 */
static void C_ccall f_2134(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2134,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,C_make_character(46),t1));}

/* k2119 in loop in k2087 in glob->regexp in k494 */
static void C_ccall f_2121(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2121,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_make_character(42),t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,C_make_character(46),t2));}

/* k2083 in glob->regexp in k494 */
static void C_ccall f_2085(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* regex.scm: 580  list->string */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* glob? in k494 */
static void C_ccall f_1989(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1989,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[79]);
t4=(C_word)C_fix((C_word)C_header_size(t2));
t5=(C_word)C_u_fixnum_difference(t4,C_fix(1));
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2002,a[2]=t7,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_2002(t9,t1,t5);}

/* loop in glob? in k494 */
static void C_fcall f_2002(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2002,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_less_or_equal_p(C_fix(0),t2))){
t3=(C_word)C_subchar(((C_word*)t0)[3],t2);
t4=(C_word)C_eqp(t3,C_make_character(42));
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2021,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t4)){
t6=t5;
f_2021(t6,t4);}
else{
t6=(C_word)C_eqp(t3,C_make_character(93));
t7=t5;
f_2021(t7,(C_truep(t6)?t6:(C_word)C_eqp(t3,C_make_character(63))));}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k2019 in loop in glob? in k494 */
static void C_fcall f_2021(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_eqp(C_fix(0),((C_word*)t0)[5]);
if(C_truep(t2)){
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(C_word)C_u_fixnum_difference(((C_word*)t0)[5],C_fix(1));
t4=(C_word)C_subchar(((C_word*)t0)[3],t3);
t5=(C_word)C_eqp(C_make_character(92),t4);
t6=(C_word)C_i_not(t5);
if(C_truep(t6)){
t7=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t7=(C_word)C_u_fixnum_difference(((C_word*)t0)[5],C_fix(2));
/* regex.scm: 571  loop */
t8=((C_word*)((C_word*)t0)[2])[1];
f_2002(t8,((C_word*)t0)[4],t7);}}}
else{
t2=(C_word)C_u_fixnum_difference(((C_word*)t0)[5],C_fix(1));
/* regex.scm: 573  loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_2002(t3,((C_word*)t0)[4],t2);}}

/* string-substitute* in k494 */
static void C_ccall f_1937(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr4rv,(void*)f_1937r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_1937r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1937r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(7);
t5=(C_word)C_i_check_string_2(t2,lf[78]);
t6=(C_word)C_i_check_list_2(t3,lf[78]);
t7=(C_word)C_notvemptyp(t4);
t8=(C_truep(t7)?(C_word)C_slot(t4,C_fix(0)):C_SCHEME_FALSE);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1952,a[2]=t8,a[3]=((C_word*)t0)[2],a[4]=t10,tmp=(C_word)a,a+=5,tmp));
t12=((C_word*)t10)[1];
f_1952(t12,t1,t2,t3);}

/* loop in string-substitute* in k494 */
static void C_fcall f_1952(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1952,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}
else{
t4=(C_word)C_u_i_car(t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1969,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_u_i_car(t4);
t7=(C_word)C_slot(t4,C_fix(1));
/* regex.scm: 556  string-substitute */
t8=((C_word*)t0)[3];
((C_proc6)(void*)(*((C_word*)t8+1)))(6,t8,t5,t6,t7,t2,((C_word*)t0)[2]);}}

/* k1967 in loop in string-substitute* in k494 */
static void C_ccall f_1969(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* regex.scm: 556  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1952(t3,((C_word*)t0)[2],t1,t2);}

/* string-substitute in k494 */
static void C_ccall f_1694(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(!C_demand(c*C_SIZEOF_PAIR+31)){
C_save_and_reclaim((void*)tr5rv,(void*)f_1694r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest_vector(a,C_rest_count(0));
f_1694r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_1694r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word *a=C_alloc(31);
t6=(C_word)C_i_check_string_2(t3,lf[75]);
t7=(C_word)C_notvemptyp(t5);
t8=(C_truep(t7)?(C_word)C_slot(t5,C_fix(0)):C_fix(1));
t9=(C_word)C_block_size(t3);
t10=(C_word)C_u_fixnum_difference(t9,C_fix(1));
t11=C_SCHEME_END_OF_LIST;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_fix(0);
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1709,a[2]=t14,a[3]=t12,tmp=(C_word)a,a+=4,tmp);
t16=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1724,a[2]=t4,a[3]=t9,a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=t15,a[7]=t10,tmp=(C_word)a,a+=8,tmp);
t17=C_SCHEME_UNDEFINED;
t18=(*a=C_VECTOR_TYPE|1,a[1]=t17,tmp=(C_word)a,a+=2,tmp);
t19=C_set_block_item(t18,0,(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_1830,a[2]=((C_word*)t0)[2],a[3]=t12,a[4]=((C_word*)t0)[3],a[5]=t14,a[6]=t4,a[7]=((C_word*)t0)[4],a[8]=t16,a[9]=t18,a[10]=t15,a[11]=t8,a[12]=t2,tmp=(C_word)a,a+=13,tmp));
t20=((C_word*)t18)[1];
f_1830(t20,t1,C_fix(0),C_fix(1));}

/* loop in string-substitute in k494 */
static void C_fcall f_1830(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1830,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_1834,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=t3,a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=t1,tmp=(C_word)a,a+=15,tmp);
/* regex.scm: 527  string-search-positions */
t5=((C_word*)t0)[2];
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,((C_word*)t0)[12],((C_word*)t0)[6],t2);}

/* k1832 in loop in string-substitute in k494 */
static void C_ccall f_1834(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1834,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_u_i_car(t1);
t3=(C_word)C_u_i_cadr(t2);
t4=(C_word)C_u_i_cadr(t2);
t5=(C_word)C_u_i_car(t2);
t6=(C_word)C_u_fixnum_difference(t4,t5);
t7=(C_word)C_eqp(C_fix(0),t6);
if(C_truep(t7)){
/* regex.scm: 532  ##sys#error */
t8=*((C_word*)lf[1]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,((C_word*)t0)[14],lf[75],lf[76],((C_word*)t0)[13]);}
else{
t8=(C_word)C_fixnump(((C_word*)t0)[12]);
t9=(C_word)C_i_not(t8);
t10=(C_truep(t9)?t9:(C_word)C_eqp(((C_word*)t0)[11],((C_word*)t0)[12]));
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1874,a[2]=t1,a[3]=((C_word*)t0)[8],a[4]=t3,a[5]=((C_word*)t0)[14],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
t12=(C_word)C_u_i_car(t2);
/* regex.scm: 536  substring */
t13=((C_word*)t0)[7];
((C_proc5)(void*)(*((C_word*)t13+1)))(5,t13,t11,((C_word*)t0)[6],((C_word*)t0)[5],t12);}
else{
t11=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1892,a[2]=t3,a[3]=((C_word*)t0)[14],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
/* regex.scm: 540  substring */
t12=((C_word*)t0)[7];
((C_proc5)(void*)(*((C_word*)t12+1)))(5,t12,t11,((C_word*)t0)[6],((C_word*)t0)[5],t3);}}}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1925,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[14],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[6]);
/* regex.scm: 543  substring */
t4=((C_word*)t0)[7];
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,((C_word*)t0)[6],((C_word*)t0)[5],t3);}}

/* k1923 in k1832 in loop in string-substitute in k494 */
static void C_ccall f_1925(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1925,2,t0,t1);}
t2=f_1709(C_a_i(&a,3),((C_word*)t0)[6],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1921,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* regex.scm: 544  reverse */
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)((C_word*)t0)[2])[1]);}

/* k1919 in k1923 in k1832 in loop in string-substitute in k494 */
static void C_ccall f_1921(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* regex.scm: 544  ##sys#fragments->string */
t2=*((C_word*)lf[77]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t1);}

/* k1890 in k1832 in loop in string-substitute in k494 */
static void C_ccall f_1892(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1892,2,t0,t1);}
t2=f_1709(C_a_i(&a,3),((C_word*)t0)[6],t1);
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[5],C_fix(1));
/* regex.scm: 541  loop */
t4=((C_word*)((C_word*)t0)[4])[1];
f_1830(t4,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* k1872 in k1832 in loop in string-substitute in k494 */
static void C_ccall f_1874(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1874,2,t0,t1);}
t2=f_1709(C_a_i(&a,3),((C_word*)t0)[7],t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1867,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* regex.scm: 537  substitute */
t4=((C_word*)t0)[3];
f_1724(t4,t3,((C_word*)t0)[2]);}

/* k1865 in k1872 in k1832 in loop in string-substitute in k494 */
static void C_ccall f_1867(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* regex.scm: 538  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_1830(t2,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}

/* substitute in string-substitute in k494 */
static void C_fcall f_1724(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1724,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1730,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp));
t6=((C_word*)t4)[1];
f_1730(t6,t1,C_fix(0),C_fix(0));}

/* loop in substitute in string-substitute in k494 */
static void C_fcall f_1730(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word *a;
loop:
a=C_alloc(14);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1730,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[9]))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1744,a[2]=((C_word*)t0)[8],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t5)){
t6=t4;
f_1744(2,t6,((C_word*)t0)[7]);}
else{
/* regex.scm: 514  substring */
t6=((C_word*)t0)[6];
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t4,((C_word*)t0)[7],t2,((C_word*)t0)[5]);}}
else{
t4=(C_word)C_subchar(((C_word*)t0)[7],t3);
t5=(C_word)C_u_fixnum_plus(t3,C_fix(1));
t6=(C_word)C_eqp(t4,C_make_character(92));
if(C_truep(t6)){
t7=(C_word)C_subchar(((C_word*)t0)[7],t5);
t8=(C_word)C_eqp(C_make_character(92),t7);
t9=(C_truep(t8)?C_SCHEME_FALSE:(C_word)C_u_i_char_numericp(t7));
if(C_truep(t9)){
t10=(C_word)C_fix((C_word)C_character_code(t7));
t11=(C_word)C_u_fixnum_difference(t10,C_fix(48));
t12=(C_word)C_u_i_list_ref(((C_word*)t0)[4],t11);
t13=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1797,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],a[4]=t12,a[5]=t5,a[6]=t1,a[7]=((C_word*)t0)[3],a[8]=t3,a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* regex.scm: 521  substring */
t14=((C_word*)t0)[6];
((C_proc5)(void*)(*((C_word*)t14+1)))(5,t14,t13,((C_word*)t0)[7],t2,t3);}
else{
t10=(C_word)C_u_fixnum_plus(t5,C_fix(1));
/* regex.scm: 524  loop */
t18=t1;
t19=t2;
t20=t10;
t1=t18;
t2=t19;
t3=t20;
goto loop;}}
else{
/* regex.scm: 525  loop */
t18=t1;
t19=t2;
t20=t5;
t1=t18;
t2=t19;
t3=t20;
goto loop;}}}

/* k1795 in loop in substitute in string-substitute in k494 */
static void C_ccall f_1797(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1797,2,t0,t1);}
t2=f_1709(C_a_i(&a,3),((C_word*)t0)[9],t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1785,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_u_i_car(((C_word*)t0)[4]);
t5=(C_word)C_u_i_cadr(((C_word*)t0)[4]);
/* regex.scm: 522  substring */
t6=((C_word*)t0)[3];
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t3,((C_word*)t0)[2],t4,t5);}

/* k1783 in k1795 in loop in substitute in string-substitute in k494 */
static void C_ccall f_1785(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1785,2,t0,t1);}
t2=f_1709(C_a_i(&a,3),((C_word*)t0)[6],t1);
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[5],C_fix(2));
/* regex.scm: 523  loop */
t4=((C_word*)((C_word*)t0)[4])[1];
f_1730(t4,((C_word*)t0)[3],t3,((C_word*)t0)[2]);}

/* k1742 in loop in substitute in string-substitute in k494 */
static void C_ccall f_1744(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1744,2,t0,t1);}
/* regex.scm: 514  push */
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,f_1709(C_a_i(&a,3),((C_word*)t0)[2],t1));}

/* push in string-substitute in k494 */
static C_word C_fcall f_1709(C_word *a,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=(C_word)C_block_size(t1);
t5=(C_word)C_u_fixnum_plus(((C_word*)((C_word*)t0)[2])[1],t4);
t6=C_mutate(((C_word *)((C_word*)t0)[2])+1,t5);
return(t6);}

/* string-split-fields in k494 */
static void C_ccall f_1512(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+25)){
C_save_and_reclaim((void*)tr4rv,(void*)f_1512r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_1512r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1512r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(25);
t5=(C_word)C_i_check_string_2(t3,lf[69]);
t6=(C_word)C_block_size(t4);
t7=(C_word)C_block_size(t3);
t8=(C_word)C_fixnum_greaterp(t6,C_fix(0));
t9=(C_truep(t8)?(C_word)C_slot(t4,C_fix(0)):C_SCHEME_TRUE);
t10=(C_word)C_fixnum_greaterp(t6,C_fix(1));
t11=(C_truep(t10)?(C_word)C_slot(t4,C_fix(1)):C_fix(0));
t12=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1531,a[2]=t11,a[3]=t1,a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=t7,a[7]=t3,a[8]=((C_word*)t0)[4],a[9]=t9,tmp=(C_word)a,a+=10,tmp);
t13=(C_word)C_eqp(t9,lf[71]);
if(C_truep(t13)){
t14=t12;
f_1531(t14,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1630,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=t7,tmp=(C_word)a,a+=6,tmp));}
else{
t14=(C_word)C_eqp(t9,lf[70]);
t15=t12;
f_1531(t15,(C_truep(t14)?(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1650,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],a[5]=t7,tmp=(C_word)a,a+=6,tmp):(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1676,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp)));}}

/* f_1676 in string-split-fields in k494 */
static void C_ccall f_1676(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1676,4,t0,t1,t2,t3);}
/* regex.scm: 476  reverse */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t2);}

/* f_1650 in string-split-fields in k494 */
static void C_ccall f_1650(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1650,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[5]))){
t4=(C_word)C_a_i_cons(&a,2,lf[73],t2);
/* regex.scm: 474  reverse */
t5=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t1,t4);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1675,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* regex.scm: 475  substring */
t5=((C_word*)t0)[3];
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,((C_word*)t0)[2],t3,((C_word*)t0)[5]);}}

/* k1673 */
static void C_ccall f_1675(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1675,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[4]);
/* regex.scm: 475  reverse */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t2);}

/* f_1630 in string-split-fields in k494 */
static void C_ccall f_1630(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1630,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_lessp(t3,((C_word*)t0)[5]))){
/* regex.scm: 468  ##sys#error */
t4=*((C_word*)lf[1]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t1,lf[69],lf[72],((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
/* regex.scm: 470  reverse */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t2);}}

/* k1529 in string-split-fields in k494 */
static void C_fcall f_1531(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1531,NULL,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[9],lf[70]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(((C_word*)t0)[9],lf[71]));
t4=(C_truep(t3)?(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1614,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp):(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1619,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp));
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1539,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t4,a[6]=t6,a[7]=t1,a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp));
t8=((C_word*)t6)[1];
f_1539(t8,((C_word*)t0)[3],C_SCHEME_END_OF_LIST,((C_word*)t0)[2]);}

/* loop in k1529 in string-split-fields in k494 */
static void C_fcall f_1539(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1539,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1543,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t3,a[5]=t2,a[6]=t1,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* regex.scm: 481  string-search-positions */
t5=((C_word*)t0)[4];
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* k1541 in loop in k1529 in string-split-fields in k494 */
static void C_ccall f_1543(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1543,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_u_i_car(t1);
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_u_i_cadr(t2);
t5=(C_word)C_eqp(t3,t4);
if(C_truep(t5)){
t6=(C_word)C_eqp(t4,((C_word*)t0)[8]);
if(C_truep(t6)){
/* regex.scm: 488  fini */
t7=((C_word*)t0)[7];
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1585,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t8=(C_word)C_u_fixnum_plus(t3,C_fix(1));
t9=(C_word)C_u_fixnum_plus(t4,C_fix(2));
/* regex.scm: 489  fetch */
t10=((C_word*)t0)[2];
((C_proc5)(void*)(*((C_word*)t10+1)))(5,t10,t7,((C_word*)t0)[4],t8,t9);}}
else{
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1604,a[2]=t4,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* regex.scm: 490  fetch */
t7=((C_word*)t0)[2];
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t6,((C_word*)t0)[4],t3,t4);}}
else{
/* regex.scm: 491  fini */
t2=((C_word*)t0)[7];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);}}

/* k1602 in k1541 in loop in k1529 in string-split-fields in k494 */
static void C_ccall f_1604(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1604,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
/* regex.scm: 490  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_1539(t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k1583 in k1541 in loop in k1529 in string-split-fields in k494 */
static void C_ccall f_1585(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1585,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* regex.scm: 489  loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1539(t4,((C_word*)t0)[2],t2,t3);}

/* f_1619 in k1529 in string-split-fields in k494 */
static void C_ccall f_1619(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1619,5,t0,t1,t2,t3,t4);}
/* regex.scm: 479  substring */
t5=((C_word*)t0)[3];
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,((C_word*)t0)[2],t3,t4);}

/* f_1614 in k1529 in string-split-fields in k494 */
static void C_ccall f_1614(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1614,5,t0,t1,t2,t3,t4);}
/* regex.scm: 478  substring */
t5=((C_word*)t0)[3];
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,((C_word*)t0)[2],t2,t3);}

/* string-search-positions in k494 */
static void C_ccall f_1502(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr4r,(void*)f_1502r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_1502r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1502r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(3);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1510,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* regex.scm: 449  prepare-search */
f_1446(t5,t2,t3,t4,lf[67]);}

/* k1508 in string-search-positions in k494 */
static void C_ccall f_1510(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* regex.scm: 449  gather-result-positions */
f_1196(((C_word*)t0)[2],t1);}

/* string-search in k494 */
static void C_ccall f_1492(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr4r,(void*)f_1492r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_1492r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1492r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1500,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* regex.scm: 445  prepare-search */
f_1446(t5,t2,t3,t4,lf[66]);}

/* k1498 in string-search in k494 */
static void C_ccall f_1500(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* regex.scm: 445  gather-results */
t2=lf[58];
f_1268(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* prepare-search in k494 */
static void C_fcall f_1446(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1446,NULL,5,t1,t2,t3,t4,t5);}
t6=(C_word)C_i_check_string_2(t3,t5);
t7=(C_word)C_i_pairp(t4);
t8=(C_truep(t7)?(C_word)C_slot(t4,C_fix(1)):C_SCHEME_FALSE);
t9=(C_truep(t8)?(C_word)C_u_i_car(t4):C_fix(0));
t10=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1459,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=t5,a[6]=t9,tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_pairp(t8))){
t11=t10;
f_1459(t11,(C_word)C_u_i_car(t8));}
else{
t11=(C_word)C_block_size(t3);
t12=t10;
f_1459(t12,(C_word)C_u_fixnum_difference(t11,t9));}}

/* k1457 in prepare-search in k494 */
static void C_fcall f_1459(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_check_exact_2(((C_word*)t0)[6],((C_word*)t0)[5]);
t3=(C_word)C_i_check_exact_2(t1,((C_word*)t0)[5]);
/* regex.scm: 441  perform-match */
f_1317(((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[6],t1,((C_word*)t0)[5]);}

/* string-match-positions in k494 */
static void C_ccall f_1428(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr4r,(void*)f_1428r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_1428r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1428r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(3);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1436,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* regex.scm: 422  prepare-match */
f_1375(t5,t2,t3,t4,lf[64]);}

/* k1434 in string-match-positions in k494 */
static void C_ccall f_1436(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* regex.scm: 422  gather-result-positions */
f_1196(((C_word*)t0)[2],t1);}

/* string-match in k494 */
static void C_ccall f_1418(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr4r,(void*)f_1418r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_1418r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1418r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1426,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* regex.scm: 418  prepare-match */
f_1375(t5,t2,t3,t4,lf[63]);}

/* k1424 in string-match in k494 */
static void C_ccall f_1426(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* regex.scm: 418  gather-results */
t2=lf[58];
f_1268(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* prepare-match in k494 */
static void C_fcall f_1375(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1375,NULL,5,t1,t2,t3,t4,t5);}
t6=(C_word)C_i_check_string_2(t3,t5);
t7=(C_word)C_i_pairp(t4);
t8=(C_truep(t7)?(C_word)C_u_i_car(t4):C_fix(0));
t9=(C_word)C_i_check_exact_2(t8,t5);
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1392,a[2]=t5,a[3]=t1,a[4]=t8,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_stringp(t2))){
t11=(C_word)C_fixnum_lessp(C_fix(0),t8);
/* regex.scm: 411  make-anchored-pattern */
t12=*((C_word*)lf[65]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t10,t2,t11);}
else{
t11=t10;
f_1392(2,t11,t2);}}

/* k1390 in prepare-match in k494 */
static void C_ccall f_1392(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_block_size(((C_word*)t0)[5]);
t3=(C_word)C_u_fixnum_difference(t2,((C_word*)t0)[4]);
/* regex.scm: 410  perform-match */
f_1317(((C_word*)t0)[3],t1,((C_word*)t0)[5],((C_word*)t0)[4],t3,((C_word*)t0)[2]);}

/* perform-match in k494 */
static void C_fcall f_1317(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1317,NULL,6,t1,t2,t3,t4,t5,t6);}
t7=C_SCHEME_FALSE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_fix(0);
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1321,a[2]=t2,a[3]=t1,a[4]=t10,a[5]=t5,a[6]=t4,a[7]=t3,a[8]=t8,tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_i_stringp(t2))){
/* regex.scm: 382  re-checked-compile */
f_985(t11,t2,C_fix(0),t6);}
else{
t12=t2;
if(C_truep((C_word)C_i_structurep(t12,lf[45]))){
t13=t2;
t14=(C_word)C_slot(t13,C_fix(2));
t15=C_set_block_item(t8,0,t14);
t16=t2;
t17=(C_word)C_slot(t16,C_fix(3));
t18=C_set_block_item(t10,0,t17);
t19=t2;
t20=t11;
f_1321(2,t20,(C_word)C_slot(t19,C_fix(1)));}
else{
/* regex.scm: 388  ##sys#signal-hook */
t13=*((C_word*)lf[39]+1);
((C_proc6)(void*)(*((C_word*)t13+1)))(6,t13,t11,lf[40],t6,lf[61],t2);}}}

/* k1319 in perform-match in k494 */
static void C_ccall f_1321(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1321,2,t0,t1);}
t2=t1;
t3=((C_word*)((C_word*)t0)[8])[1];
t4=(C_word)C_i_foreign_pointer_argumentp(t2);
t5=(C_truep(t3)?(C_word)C_i_foreign_pointer_argumentp(t3):C_SCHEME_FALSE);
t6=(C_word)stub195(C_SCHEME_UNDEFINED,t4,t5);
t7=t1;
t8=((C_word*)((C_word*)t0)[8])[1];
t9=((C_word*)t0)[7];
t10=((C_word*)t0)[6];
t11=((C_word*)t0)[5];
t12=((C_word*)((C_word*)t0)[4])[1];
t13=(C_word)C_i_foreign_pointer_argumentp(t7);
t14=(C_truep(t8)?(C_word)C_i_foreign_pointer_argumentp(t8):C_SCHEME_FALSE);
t15=(C_word)stub183(C_SCHEME_UNDEFINED,t13,t14,t9,t10,t11,t12);
t16=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1330,a[2]=t6,a[3]=t15,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_stringp(((C_word*)t0)[2]))){
/* regex.scm: 394  re-finalizer */
t17=lf[35];
f_870(3,t17,t16,t1);}
else{
t17=t16;
f_1330(2,t17,C_SCHEME_UNDEFINED);}}

/* k1328 in k1319 in perform-match in k494 */
static void C_ccall f_1330(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1330,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]));}

/* gather-results in k494 */
static void C_fcall f_1268(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1268,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1272,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* regex.scm: 358  gather-result-positions */
f_1196(t4,t3);}

/* k1270 in gather-results in k494 */
static void C_ccall f_1272(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1272,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1280,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* regex.scm: 360  ##sys#map */
t3=*((C_word*)lf[59]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t2,t1);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a1279 in k1270 in gather-results in k494 */
static void C_ccall f_1280(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1280,3,t0,t1,t2);}
if(C_truep(t2)){
C_apply(5,0,t1,((C_word*)t0)[3],((C_word*)t0)[2],t2);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* gather-result-positions in k494 */
static void C_fcall f_1196(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1196,NULL,2,t1,t2);}
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_u_i_cadr(t2);
if(C_truep((C_word)C_fixnum_greaterp(t3,C_fix(0)))){
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1214,a[2]=t6,a[3]=t3,a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_1214(t8,t1,C_fix(0));}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}

/* loop in gather-result-positions in k494 */
static void C_fcall f_1214(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(14);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1214,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[4]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[3]))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1234,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_u_fixnum_plus(t2,C_fix(1));
/* regex.scm: 348  loop */
t11=t3;
t12=t4;
t1=t11;
t2=t12;
goto loop;}
else{
t3=t2;
t4=(C_word)stub158(C_SCHEME_UNDEFINED,t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1248,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t4,C_fix(0)))){
t6=t2;
t7=(C_word)stub162(C_SCHEME_UNDEFINED,t6);
t8=t5;
f_1248(t8,(C_word)C_a_i_list(&a,2,t4,t7));}
else{
t6=t5;
f_1248(t6,C_SCHEME_FALSE);}}}}

/* k1246 in loop in gather-result-positions in k494 */
static void C_fcall f_1248(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1248,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1252,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* regex.scm: 353  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_1214(t4,t2,t3);}

/* k1250 in k1246 in loop in gather-result-positions in k494 */
static void C_ccall f_1252(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1252,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k1232 in loop in gather-result-positions in k494 */
static void C_ccall f_1234(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1234,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,t1));}

/* regexp-optimize in k494 */
static void C_ccall f_1156(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1156,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[45],lf[54]);
t4=t2;
t5=(C_word)C_slot(t4,C_fix(1));
t6=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t7=(C_word)C_i_foreign_pointer_argumentp(t5);
t8=(C_word)stub145(t6,t7);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1169,a[2]=t8,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* ##sys#peek-c-string */
t10=*((C_word*)lf[49]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t9,C_mpointer(&a,(void*)C_regex_error),C_fix(0));}

/* k1167 in regexp-optimize in k494 */
static void C_ccall f_1169(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1169,2,t0,t1);}
if(C_truep(t1)){
/* regex.scm: 309  re-error */
t2=lf[47];
f_957(t2,((C_word*)t0)[4],lf[54],lf[55],(C_word)C_a_i_list(&a,1,((C_word*)t0)[3]));}
else{
if(C_truep(((C_word*)t0)[2])){
t2=((C_word*)t0)[3];
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1178,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
/* set-finalizer! */
t4=*((C_word*)lf[42]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[2],lf[35]);}
else{
t4=t3;
f_1178(2,t4,C_SCHEME_UNDEFINED);}}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}}

/* k1176 in k1167 in regexp-optimize in k494 */
static void C_ccall f_1178(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[4],C_fix(2),((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_TRUE);}

/* regexp* in k494 */
static void C_ccall f_1070(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr3r,(void*)f_1070r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1070r(t0,t1,t2,t3);}}

static void C_ccall f_1070r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(9);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1072,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1099,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1104,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-options126139 */
t7=t6;
f_1104(t7,t1);}
else{
t7=(C_word)C_u_i_car(t3);
t8=(C_word)C_slot(t3,C_fix(1));
if(C_truep((C_word)C_i_nullp(t8))){
/* def-tables127137 */
t9=t5;
f_1099(t9,t1,t7);}
else{
t9=(C_word)C_u_i_car(t8);
t10=(C_word)C_slot(t8,C_fix(1));
/* body124129 */
t11=t4;
f_1072(t11,t1,t7,t9);}}}

/* def-options126 in regexp* in k494 */
static void C_fcall f_1104(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1104,NULL,2,t0,t1);}
/* def-tables127137 */
t2=((C_word*)t0)[2];
f_1099(t2,t1,C_SCHEME_END_OF_LIST);}

/* def-tables127 in regexp* in k494 */
static void C_fcall f_1099(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1099,NULL,3,t0,t1,t2);}
/* body124129 */
t3=((C_word*)t0)[2];
f_1072(t3,t1,t2,C_SCHEME_FALSE);}

/* body124 in regexp* in k494 */
static void C_fcall f_1072(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1072,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(((C_word*)t0)[2],lf[53]);
t5=(C_word)C_i_check_list_2(t2,lf[53]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1082,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t3)){
/* regex.scm: 290  ##sys#check-chardef-table */
t7=*((C_word*)lf[0]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,t3,lf[53]);}
else{
t7=t6;
f_1082(2,t7,C_SCHEME_UNDEFINED);}}

/* k1080 in body124 in regexp* in k494 */
static void C_ccall f_1082(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1082,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1085,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1095,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* regex.scm: 291  pcre-option->number */
f_498(t3,((C_word*)t0)[2]);}

/* k1093 in k1080 in body124 in regexp* in k494 */
static void C_ccall f_1095(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* regex.scm: 291  re-checked-compile */
f_985(((C_word*)t0)[3],((C_word*)t0)[2],t1,lf[53]);}

/* k1083 in k1080 in body124 in regexp* in k494 */
static void C_ccall f_1085(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1085,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1088,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* set-finalizer! */
t3=*((C_word*)lf[42]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,t1,lf[35]);}

/* k1086 in k1083 in k1080 in body124 in regexp* in k494 */
static void C_ccall f_1088(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1088,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[45],((C_word*)t0)[2],C_SCHEME_FALSE,C_fix(0)));}

/* regexp in k494 */
static void C_ccall f_1000(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr3r,(void*)f_1000r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1000r(t0,t1,t2,t3);}}

static void C_ccall f_1000r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(10);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1002,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1058,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1068,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* regex.scm: 282  options->integer */
t7=t4;
f_1002(t7,t6);}

/* k1066 in regexp in k494 */
static void C_ccall f_1068(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* regex.scm: 282  re-checked-compile */
f_985(((C_word*)t0)[3],((C_word*)t0)[2],t1,lf[45]);}

/* k1056 in regexp in k494 */
static void C_ccall f_1058(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1058,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1061,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* set-finalizer! */
t3=*((C_word*)lf[42]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,t1,lf[35]);}

/* k1059 in k1056 in regexp in k494 */
static void C_ccall f_1061(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1061,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[45],((C_word*)t0)[2],C_SCHEME_FALSE,C_fix(0)));}

/* options->integer in regexp in k494 */
static void C_fcall f_1002(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1002,NULL,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[2]))){
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}
else{
t2=(C_word)C_u_i_car(((C_word*)t0)[2]);
t3=(C_truep(t2)?C_unsigned_int_to_num(&a,PCRE_CASELESS):C_fix(0));
t4=(C_word)C_slot(((C_word*)t0)[2],C_fix(1));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1023,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_1023(t6,C_fix(0));}
else{
t6=(C_word)C_u_i_car(t4);
t7=(C_truep(t6)?C_unsigned_int_to_num(&a,PCRE_EXTENDED):C_fix(0));
t8=(C_word)C_slot(t4,C_fix(1));
t9=(C_word)C_i_pairp(t8);
t10=(C_truep(t9)?(C_word)C_u_i_car(t8):C_SCHEME_FALSE);
t11=(C_truep(t10)?C_unsigned_int_to_num(&a,PCRE_UTF8):C_fix(0));
t12=t5;
f_1023(t12,(C_word)C_a_i_plus(&a,2,t7,t11));}}}

/* k1021 in options->integer in regexp in k494 */
static void C_fcall f_1023(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1023,NULL,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_plus(&a,2,((C_word*)t0)[2],t1));}

/* re-checked-compile in k494 */
static void C_fcall f_985(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_985,NULL,4,t1,t2,t3,t4);}
t5=(C_word)C_i_check_string_2(t2,t4);
t6=t2;
t7=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_976,a[2]=t2,a[3]=t4,a[4]=t1,a[5]=t3,a[6]=t7,tmp=(C_word)a,a+=7,tmp);
/* ##sys#make-c-string */
t9=*((C_word*)lf[52]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t6);}

/* k974 in re-checked-compile in k494 */
static void C_ccall f_976(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_976,2,t0,t1);}
t2=(C_word)stub98(((C_word*)t0)[6],t1,((C_word*)t0)[5],C_SCHEME_FALSE);
if(C_truep(t2)){
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
/* regex.scm: 266  re-error */
t3=lf[47];
f_957(t3,((C_word*)t0)[4],((C_word*)t0)[3],lf[51],(C_word)C_a_i_list(&a,2,((C_word*)t0)[2],C_fix((C_word)C_regex_error_offset)));}}

/* re-error in k494 */
static void C_fcall f_957(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_957,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_965,a[2]=t4,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_969,a[2]=t3,a[3]=t5,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* ##sys#peek-c-string */
t7=*((C_word*)lf[49]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,C_mpointer(&a,(void*)C_regex_error),C_fix(0));}

/* k967 in re-error in k494 */
static void C_ccall f_969(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* regex.scm: 253  string-append */
t2=((C_word*)t0)[4];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[48],t1);}

/* k963 in re-error in k494 */
static void C_ccall f_965(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(6,0,((C_word*)t0)[4],*((C_word*)lf[1]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* regexp? in k494 */
static void C_ccall f_951(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_951,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[45]));}

/* regex-chardef-table in k494 */
static void C_ccall f_903(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr2rv,(void*)f_903r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_903r(t0,t1,t2);}}

static void C_ccall f_903r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(8);
t3=(C_word)C_vemptyp(t2);
t4=(C_truep(t3)?C_SCHEME_FALSE:(C_word)C_slot(t2,C_fix(0)));
if(C_truep(t4)){
if(C_truep((C_word)C_pointerp(t4))){
/* regex.scm: 222  re-make-chardef-table-type */
f_898(t1,t4);}
else{
/* regex.scm: 223  ##sys#signal-hook */
t5=*((C_word*)lf[39]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t1,lf[40],lf[38],lf[41],t4);}}
else{
t5=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t6=(C_word)stub72(t5);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_931,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* regex.scm: 228  re-make-chardef-table-type */
f_898(t7,t6);}
else{
/* regex.scm: 231  ##sys#error-hook */
t7=*((C_word*)lf[43]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t1,C_fix(6),lf[38]);}}}

/* k929 in regex-chardef-table in k494 */
static void C_ccall f_931(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_931,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_934,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* regex.scm: 229  set-finalizer! */
t3=*((C_word*)lf[42]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,t1,lf[35]);}

/* k932 in k929 in regex-chardef-table in k494 */
static void C_ccall f_934(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* re-make-chardef-table-type in k494 */
static void C_fcall f_898(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_898,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_902,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* ##sys#make-tagged-pointer */
t4=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[36]);}

/* k900 in re-make-chardef-table-type in k494 */
static void C_ccall f_902(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_copy_pointer(((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* regex-chardef-table? in k494 */
static void C_ccall f_880(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_880,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
if(C_truep((C_word)C_taggedpointerp(t2))){
t3=(C_word)C_slot(t2,C_fix(1));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_eqp(lf[36],t3));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* re-finalizer in k494 */
static void C_ccall f_870(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_870,3,t0,t1,t2);}
t3=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub51(C_SCHEME_UNDEFINED,t3));}

/* pcre-option->number in k494 */
static void C_fcall f_498(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_498,NULL,2,t1,t2);}
t3=(C_word)C_i_symbolp(t2);
t4=(C_truep(t3)?(C_word)C_a_i_list(&a,1,t2):t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_508,a[2]=t6,tmp=(C_word)a,a+=3,tmp));
t8=((C_word*)t6)[1];
f_508(t8,t1,t4,C_fix(0));}

/* loop in pcre-option->number in k494 */
static void C_fcall f_508(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word ab[114],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_508,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_u_i_car(t2);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_533,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_eqp(t5,lf[5]);
if(C_truep(t7)){
t8=t6;
f_533(2,t8,C_unsigned_int_to_num(&a,PCRE_CASELESS));}
else{
t8=(C_word)C_eqp(t5,lf[6]);
if(C_truep(t8)){
t9=t6;
f_533(2,t9,C_unsigned_int_to_num(&a,PCRE_MULTILINE));}
else{
t9=(C_word)C_eqp(t5,lf[7]);
if(C_truep(t9)){
t10=t6;
f_533(2,t10,C_unsigned_int_to_num(&a,PCRE_DOTALL));}
else{
t10=(C_word)C_eqp(t5,lf[8]);
if(C_truep(t10)){
t11=t6;
f_533(2,t11,C_unsigned_int_to_num(&a,PCRE_EXTENDED));}
else{
t11=(C_word)C_eqp(t5,lf[9]);
if(C_truep(t11)){
t12=t6;
f_533(2,t12,C_unsigned_int_to_num(&a,PCRE_ANCHORED));}
else{
t12=(C_word)C_eqp(t5,lf[10]);
if(C_truep(t12)){
t13=t6;
f_533(2,t13,C_unsigned_int_to_num(&a,PCRE_DOLLAR_ENDONLY));}
else{
t13=(C_word)C_eqp(t5,lf[11]);
if(C_truep(t13)){
t14=t6;
f_533(2,t14,C_unsigned_int_to_num(&a,PCRE_EXTRA));}
else{
t14=(C_word)C_eqp(t5,lf[12]);
if(C_truep(t14)){
t15=t6;
f_533(2,t15,C_unsigned_int_to_num(&a,PCRE_NOTBOL));}
else{
t15=(C_word)C_eqp(t5,lf[13]);
if(C_truep(t15)){
t16=t6;
f_533(2,t16,C_unsigned_int_to_num(&a,PCRE_NOTEOL));}
else{
t16=(C_word)C_eqp(t5,lf[14]);
if(C_truep(t16)){
t17=t6;
f_533(2,t17,C_unsigned_int_to_num(&a,PCRE_UNGREEDY));}
else{
t17=(C_word)C_eqp(t5,lf[15]);
if(C_truep(t17)){
t18=t6;
f_533(2,t18,C_unsigned_int_to_num(&a,PCRE_NOTEMPTY));}
else{
t18=(C_word)C_eqp(t5,lf[16]);
if(C_truep(t18)){
t19=t6;
f_533(2,t19,C_unsigned_int_to_num(&a,PCRE_UTF8));}
else{
t19=(C_word)C_eqp(t5,lf[17]);
if(C_truep(t19)){
t20=t6;
f_533(2,t20,C_unsigned_int_to_num(&a,PCRE_NO_AUTO_CAPTURE));}
else{
t20=(C_word)C_eqp(t5,lf[18]);
if(C_truep(t20)){
t21=t6;
f_533(2,t21,C_unsigned_int_to_num(&a,PCRE_NO_UTF8_CHECK));}
else{
t21=(C_word)C_eqp(t5,lf[19]);
if(C_truep(t21)){
t22=t6;
f_533(2,t22,C_unsigned_int_to_num(&a,PCRE_AUTO_CALLOUT));}
else{
t22=(C_word)C_eqp(t5,lf[20]);
if(C_truep(t22)){
t23=t6;
f_533(2,t23,C_unsigned_int_to_num(&a,PCRE_PARTIAL));}
else{
t23=(C_word)C_eqp(t5,lf[21]);
if(C_truep(t23)){
t24=t6;
f_533(2,t24,C_unsigned_int_to_num(&a,PCRE_DFA_SHORTEST));}
else{
t24=(C_word)C_eqp(t5,lf[22]);
if(C_truep(t24)){
t25=t6;
f_533(2,t25,C_unsigned_int_to_num(&a,PCRE_DFA_RESTART));}
else{
t25=(C_word)C_eqp(t5,lf[23]);
if(C_truep(t25)){
t26=t6;
f_533(2,t26,C_unsigned_int_to_num(&a,PCRE_FIRSTLINE));}
else{
t26=(C_word)C_eqp(t5,lf[24]);
if(C_truep(t26)){
t27=t6;
f_533(2,t27,C_unsigned_int_to_num(&a,PCRE_DUPNAMES));}
else{
t27=(C_word)C_eqp(t5,lf[25]);
if(C_truep(t27)){
t28=t6;
f_533(2,t28,C_unsigned_int_to_num(&a,PCRE_NEWLINE_CR));}
else{
t28=(C_word)C_eqp(t5,lf[26]);
if(C_truep(t28)){
t29=t6;
f_533(2,t29,C_unsigned_int_to_num(&a,PCRE_NEWLINE_LF));}
else{
t29=(C_word)C_eqp(t5,lf[27]);
if(C_truep(t29)){
t30=t6;
f_533(2,t30,C_unsigned_int_to_num(&a,PCRE_NEWLINE_CRLF));}
else{
t30=(C_word)C_eqp(t5,lf[28]);
if(C_truep(t30)){
t31=t6;
f_533(2,t31,C_unsigned_int_to_num(&a,PCRE_NEWLINE_ANY));}
else{
t31=(C_word)C_eqp(t5,lf[29]);
if(C_truep(t31)){
t32=t6;
f_533(2,t32,C_unsigned_int_to_num(&a,PCRE_NEWLINE_ANYCRLF));}
else{
t32=(C_word)C_eqp(t5,lf[30]);
if(C_truep(t32)){
t33=t6;
f_533(2,t33,C_unsigned_int_to_num(&a,PCRE_BSR_ANYCRLF));}
else{
t33=(C_word)C_eqp(t5,lf[31]);
if(C_truep(t33)){
t34=t6;
f_533(2,t34,C_unsigned_int_to_num(&a,PCRE_BSR_UNICODE));}
else{
/* regex.scm: 139  error */
t34=*((C_word*)lf[32]+1);
((C_proc5)(void*)(*((C_word*)t34+1)))(5,t34,t6,lf[33],t5,lf[34]);}}}}}}}}}}}}}}}}}}}}}}}}}}}}}

/* k531 in loop in pcre-option->number in k494 */
static void C_ccall f_533(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_533,2,t0,t1);}
t2=(C_word)C_a_i_bitwise_ior(&a,2,((C_word*)t0)[5],t1);
/* regex.scm: 139  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_508(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* ##sys#check-chardef-table */
static void C_ccall f_483(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_483,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_490,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* regex.scm: 90   regex-chardef-table? */
t5=*((C_word*)lf[3]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k488 in ##sys#check-chardef-table */
static void C_ccall f_490(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
/* regex.scm: 91   ##sys#error */
t2=*((C_word*)lf[1]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],lf[2],((C_word*)t0)[2]);}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[126] = {
{"toplevelregex.scm",(void*)C_regex_toplevel},
{"f_496regex.scm",(void*)f_496},
{"f_2438regex.scm",(void*)f_2438},
{"f_2490regex.scm",(void*)f_2490},
{"f_2485regex.scm",(void*)f_2485},
{"f_2440regex.scm",(void*)f_2440},
{"f_2464regex.scm",(void*)f_2464},
{"f_2478regex.scm",(void*)f_2478},
{"f_2467regex.scm",(void*)f_2467},
{"f_2382regex.scm",(void*)f_2382},
{"f_2389regex.scm",(void*)f_2389},
{"f_2397regex.scm",(void*)f_2397},
{"f_2429regex.scm",(void*)f_2429},
{"f_2416regex.scm",(void*)f_2416},
{"f_2419regex.scm",(void*)f_2419},
{"f_2342regex.scm",(void*)f_2342},
{"f_2351regex.scm",(void*)f_2351},
{"f_2370regex.scm",(void*)f_2370},
{"f_2377regex.scm",(void*)f_2377},
{"f_2074regex.scm",(void*)f_2074},
{"f_2089regex.scm",(void*)f_2089},
{"f_2091regex.scm",(void*)f_2091},
{"f_2337regex.scm",(void*)f_2337},
{"f_2326regex.scm",(void*)f_2326},
{"f_2149regex.scm",(void*)f_2149},
{"f_2231regex.scm",(void*)f_2231},
{"f_2255regex.scm",(void*)f_2255},
{"f_2210regex.scm",(void*)f_2210},
{"f_2181regex.scm",(void*)f_2181},
{"f_2151regex.scm",(void*)f_2151},
{"f_2159regex.scm",(void*)f_2159},
{"f_2147regex.scm",(void*)f_2147},
{"f_2134regex.scm",(void*)f_2134},
{"f_2121regex.scm",(void*)f_2121},
{"f_2085regex.scm",(void*)f_2085},
{"f_1989regex.scm",(void*)f_1989},
{"f_2002regex.scm",(void*)f_2002},
{"f_2021regex.scm",(void*)f_2021},
{"f_1937regex.scm",(void*)f_1937},
{"f_1952regex.scm",(void*)f_1952},
{"f_1969regex.scm",(void*)f_1969},
{"f_1694regex.scm",(void*)f_1694},
{"f_1830regex.scm",(void*)f_1830},
{"f_1834regex.scm",(void*)f_1834},
{"f_1925regex.scm",(void*)f_1925},
{"f_1921regex.scm",(void*)f_1921},
{"f_1892regex.scm",(void*)f_1892},
{"f_1874regex.scm",(void*)f_1874},
{"f_1867regex.scm",(void*)f_1867},
{"f_1724regex.scm",(void*)f_1724},
{"f_1730regex.scm",(void*)f_1730},
{"f_1797regex.scm",(void*)f_1797},
{"f_1785regex.scm",(void*)f_1785},
{"f_1744regex.scm",(void*)f_1744},
{"f_1709regex.scm",(void*)f_1709},
{"f_1512regex.scm",(void*)f_1512},
{"f_1676regex.scm",(void*)f_1676},
{"f_1650regex.scm",(void*)f_1650},
{"f_1675regex.scm",(void*)f_1675},
{"f_1630regex.scm",(void*)f_1630},
{"f_1531regex.scm",(void*)f_1531},
{"f_1539regex.scm",(void*)f_1539},
{"f_1543regex.scm",(void*)f_1543},
{"f_1604regex.scm",(void*)f_1604},
{"f_1585regex.scm",(void*)f_1585},
{"f_1619regex.scm",(void*)f_1619},
{"f_1614regex.scm",(void*)f_1614},
{"f_1502regex.scm",(void*)f_1502},
{"f_1510regex.scm",(void*)f_1510},
{"f_1492regex.scm",(void*)f_1492},
{"f_1500regex.scm",(void*)f_1500},
{"f_1446regex.scm",(void*)f_1446},
{"f_1459regex.scm",(void*)f_1459},
{"f_1428regex.scm",(void*)f_1428},
{"f_1436regex.scm",(void*)f_1436},
{"f_1418regex.scm",(void*)f_1418},
{"f_1426regex.scm",(void*)f_1426},
{"f_1375regex.scm",(void*)f_1375},
{"f_1392regex.scm",(void*)f_1392},
{"f_1317regex.scm",(void*)f_1317},
{"f_1321regex.scm",(void*)f_1321},
{"f_1330regex.scm",(void*)f_1330},
{"f_1268regex.scm",(void*)f_1268},
{"f_1272regex.scm",(void*)f_1272},
{"f_1280regex.scm",(void*)f_1280},
{"f_1196regex.scm",(void*)f_1196},
{"f_1214regex.scm",(void*)f_1214},
{"f_1248regex.scm",(void*)f_1248},
{"f_1252regex.scm",(void*)f_1252},
{"f_1234regex.scm",(void*)f_1234},
{"f_1156regex.scm",(void*)f_1156},
{"f_1169regex.scm",(void*)f_1169},
{"f_1178regex.scm",(void*)f_1178},
{"f_1070regex.scm",(void*)f_1070},
{"f_1104regex.scm",(void*)f_1104},
{"f_1099regex.scm",(void*)f_1099},
{"f_1072regex.scm",(void*)f_1072},
{"f_1082regex.scm",(void*)f_1082},
{"f_1095regex.scm",(void*)f_1095},
{"f_1085regex.scm",(void*)f_1085},
{"f_1088regex.scm",(void*)f_1088},
{"f_1000regex.scm",(void*)f_1000},
{"f_1068regex.scm",(void*)f_1068},
{"f_1058regex.scm",(void*)f_1058},
{"f_1061regex.scm",(void*)f_1061},
{"f_1002regex.scm",(void*)f_1002},
{"f_1023regex.scm",(void*)f_1023},
{"f_985regex.scm",(void*)f_985},
{"f_976regex.scm",(void*)f_976},
{"f_957regex.scm",(void*)f_957},
{"f_969regex.scm",(void*)f_969},
{"f_965regex.scm",(void*)f_965},
{"f_951regex.scm",(void*)f_951},
{"f_903regex.scm",(void*)f_903},
{"f_931regex.scm",(void*)f_931},
{"f_934regex.scm",(void*)f_934},
{"f_898regex.scm",(void*)f_898},
{"f_902regex.scm",(void*)f_902},
{"f_880regex.scm",(void*)f_880},
{"f_870regex.scm",(void*)f_870},
{"f_498regex.scm",(void*)f_498},
{"f_508regex.scm",(void*)f_508},
{"f_533regex.scm",(void*)f_533},
{"f_483regex.scm",(void*)f_483},
{"f_490regex.scm",(void*)f_490},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
