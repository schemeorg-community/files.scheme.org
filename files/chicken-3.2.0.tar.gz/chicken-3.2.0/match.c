/* Generated from match.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-04-30 11:21
   Version 3.1.10 - linux-unix-gnu-x86	[ manyargs dload ptables applyhook ]
   SVN rev. 10602	compiled 2008-04-30 on galinha (Linux)
   command line: match.scm -quiet -no-trace -optimize-level 2 -include-path . -explicit-use -output-file match.c
   unit: match
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);

static C_TLS C_word lf[150];
static double C_possibly_force_alignment;
static C_char C_TLS li0[] C_aligned={C_lihdr(0,0,24),40,35,35,109,97,116,99,104,35,101,118,101,114,121,32,102,110,48,32,108,115,116,49,41};
static C_char C_TLS li1[] C_aligned={C_lihdr(0,0,34),40,35,35,109,97,116,99,104,35,115,121,110,116,97,120,45,101,114,114,32,111,98,106,49,54,55,32,109,115,103,49,54,56,41,0,0,0,0,0,0};
static C_char C_TLS li2[] C_aligned={C_lihdr(0,0,24),40,35,35,109,97,116,99,104,35,115,101,116,45,101,114,114,111,114,32,118,49,54,57,41};
static C_char C_TLS li3[] C_aligned={C_lihdr(0,0,32),40,35,35,109,97,116,99,104,35,115,101,116,45,101,114,114,111,114,45,99,111,110,116,114,111,108,32,118,49,55,48,41};
static C_char C_TLS li4[] C_aligned={C_lihdr(0,0,12),40,97,55,51,56,52,32,120,54,51,56,41,0,0,0,0};
static C_char C_TLS li5[] C_aligned={C_lihdr(0,0,20),40,115,121,109,98,111,108,45,97,112,112,101,110,100,32,108,54,51,55,41,0,0,0,0};
static C_char C_TLS li6[] C_aligned={C_lihdr(0,0,18),40,103,101,116,116,101,114,32,101,54,51,50,32,112,54,51,51,41,0,0,0,0,0,0};
static C_char C_TLS li7[] C_aligned={C_lihdr(0,0,16),40,109,107,45,115,101,116,116,101,114,32,115,54,50,56,41};
static C_char C_TLS li8[] C_aligned={C_lihdr(0,0,18),40,115,101,116,116,101,114,32,101,54,50,53,32,112,54,50,54,41,0,0,0,0,0,0};
static C_char C_TLS li9[] C_aligned={C_lihdr(0,0,12),40,97,100,100,45,100,32,97,54,50,51,41,0,0,0,0};
static C_char C_TLS li10[] C_aligned={C_lihdr(0,0,12),40,97,100,100,45,97,32,97,54,50,49,41,0,0,0,0};
static C_char C_TLS li11[] C_aligned={C_lihdr(0,0,11),40,100,105,115,106,111,105,110,116,63,41,0,0,0,0,0};
static C_char C_TLS li12[] C_aligned={C_lihdr(0,0,20),40,101,113,117,97,108,45,116,101,115,116,63,32,116,115,116,54,49,56,41,0,0,0,0};
static C_char C_TLS li13[] C_aligned={C_lihdr(0,0,10),40,109,101,109,32,108,53,57,55,41,0,0,0,0,0,0};
static C_char C_TLS li14[] C_aligned={C_lihdr(0,0,10),40,109,101,109,32,108,54,48,55,41,0,0,0,0,0,0};
static C_char C_TLS li15[] C_aligned={C_lihdr(0,0,10),40,109,101,109,32,108,54,49,51,41,0,0,0,0,0,0};
static C_char C_TLS li16[] C_aligned={C_lihdr(0,0,14),40,105,110,32,101,53,56,54,32,108,53,56,55,41,0,0};
static C_char C_TLS li17[] C_aligned={C_lihdr(0,0,14),40,108,111,111,112,32,99,111,100,101,53,55,56,41,0,0};
static C_char C_TLS li18[] C_aligned={C_lihdr(0,0,25),40,103,117,97,114,97,110,116,101,101,115,32,99,111,100,101,53,55,51,32,120,53,55,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li19[] C_aligned={C_lihdr(0,0,23),40,97,115,115,109,32,116,115,116,53,54,53,32,102,53,54,54,32,115,53,54,55,41,0};
static C_char C_TLS li20[] C_aligned={C_lihdr(0,0,31),40,101,109,105,116,32,116,115,116,53,53,51,32,115,102,53,53,52,32,107,102,53,53,53,32,107,115,53,53,54,41,0};
static C_char C_TLS li21[] C_aligned={C_lihdr(0,0,17),40,100,111,116,45,100,111,116,45,107,63,32,115,50,53,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li22[] C_aligned={C_lihdr(0,0,10),40,118,97,108,32,120,52,54,51,41,0,0,0,0,0,0};
static C_char C_TLS li23[] C_aligned={C_lihdr(0,0,12),40,102,97,105,108,32,115,102,52,54,53,41,0,0,0,0};
static C_char C_TLS li24[] C_aligned={C_lihdr(0,0,15),40,115,117,99,99,101,115,115,32,115,102,52,54,55,41,0};
static C_char C_TLS li25[] C_aligned={C_lihdr(0,0,13),40,97,52,49,54,51,32,115,102,52,56,52,41,0,0,0};
static C_char C_TLS li26[] C_aligned={C_lihdr(0,0,17),40,108,111,111,112,32,112,52,56,50,32,115,102,52,56,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li27[] C_aligned={C_lihdr(0,0,13),40,97,52,50,48,54,32,115,102,52,57,48,41,0,0,0};
static C_char C_TLS li28[] C_aligned={C_lihdr(0,0,17),40,108,111,111,112,32,112,52,56,56,32,115,102,52,56,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li29[] C_aligned={C_lihdr(0,0,14),40,102,95,52,50,53,55,32,115,102,52,57,57,41,0,0};
static C_char C_TLS li30[] C_aligned={C_lihdr(0,0,12),40,114,108,111,111,112,32,110,52,57,56,41,0,0,0,0};
static C_char C_TLS li31[] C_aligned={C_lihdr(0,0,13),40,97,52,52,53,56,32,115,102,53,48,57,41,0,0,0};
static C_char C_TLS li32[] C_aligned={C_lihdr(0,0,13),40,97,52,52,54,49,32,115,102,53,49,48,41,0,0,0};
static C_char C_TLS li33[] C_aligned={C_lihdr(0,0,12),40,97,52,53,50,48,32,120,53,50,48,41,0,0,0,0};
static C_char C_TLS li34[] C_aligned={C_lihdr(0,0,12),40,97,52,53,51,56,32,120,53,49,57,41,0,0,0,0};
static C_char C_TLS li35[] C_aligned={C_lihdr(0,0,17),40,97,52,53,55,48,32,98,53,49,55,32,102,53,49,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li36[] C_aligned={C_lihdr(0,0,13),40,97,52,53,53,50,32,115,102,53,49,54,41,0,0,0};
static C_char C_TLS li37[] C_aligned={C_lihdr(0,0,10),40,107,115,32,115,102,53,48,54,41,0,0,0,0,0,0};
static C_char C_TLS li38[] C_aligned={C_lihdr(0,0,13),40,97,52,51,53,52,32,115,102,53,48,51,41,0,0,0};
static C_char C_TLS li39[] C_aligned={C_lihdr(0,0,13),40,97,52,54,54,54,32,115,102,53,50,53,41,0,0,0};
static C_char C_TLS li40[] C_aligned={C_lihdr(0,0,13),40,97,52,54,53,50,32,115,102,53,50,52,41,0,0,0};
static C_char C_TLS li41[] C_aligned={C_lihdr(0,0,12),40,97,52,56,48,56,32,120,53,52,49,41,0,0,0,0};
static C_char C_TLS li42[] C_aligned={C_lihdr(0,0,17),40,97,52,56,53,54,32,98,53,51,57,32,102,53,52,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li43[] C_aligned={C_lihdr(0,0,13),40,97,52,56,51,56,32,115,102,53,51,56,41,0,0,0};
static C_char C_TLS li44[] C_aligned={C_lihdr(0,0,14),40,102,95,52,55,50,57,32,115,102,53,51,51,41,0,0};
static C_char C_TLS li45[] C_aligned={C_lihdr(0,0,12),40,118,108,111,111,112,32,110,53,51,50,41,0,0,0,0};
static C_char C_TLS li46[] C_aligned={C_lihdr(0,0,13),40,97,52,55,48,53,32,115,102,53,51,48,41,0,0,0};
static C_char C_TLS li47[] C_aligned={C_lihdr(0,0,14),40,102,95,52,57,51,57,32,115,102,53,52,56,41,0,0};
static C_char C_TLS li48[] C_aligned={C_lihdr(0,0,12),40,118,108,111,111,112,32,110,53,52,55,41,0,0,0,0};
static C_char C_TLS li49[] C_aligned={C_lihdr(0,0,13),40,97,52,57,50,50,32,115,102,53,52,53,41,0,0,0};
static C_char C_TLS li50[] C_aligned={C_lihdr(0,0,34),40,110,101,120,116,32,112,52,55,52,32,101,52,55,53,32,115,102,52,55,54,32,107,102,52,55,55,32,107,115,52,55,56,41,0,0,0,0,0,0};
static C_char C_TLS li51[] C_aligned={C_lihdr(0,0,54),40,103,101,110,32,120,52,53,53,32,115,102,52,53,54,32,112,108,105,115,116,52,53,55,32,101,114,114,97,99,116,52,53,56,32,108,101,110,103,116,104,62,61,52,53,57,32,101,116,97,52,54,48,41,0,0};
static C_char C_TLS li52[] C_aligned={C_lihdr(0,0,8),40,99,111,110,115,116,63,41};
static C_char C_TLS li53[] C_aligned={C_lihdr(0,0,8),40,105,115,118,97,108,63,41};
static C_char C_TLS li54[] C_aligned={C_lihdr(0,0,8),40,115,109,97,108,108,63,41};
static C_char C_TLS li55[] C_aligned={C_lihdr(0,0,11),40,108,111,111,112,32,101,52,50,48,41,0,0,0,0,0};
static C_char C_TLS li56[] C_aligned={C_lihdr(0,0,11),40,108,111,111,112,32,101,52,49,52,41,0,0,0,0,0};
static C_char C_TLS li57[] C_aligned={C_lihdr(0,0,25),40,108,111,111,112,32,98,52,52,50,32,110,101,119,45,98,52,52,51,32,101,52,52,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li58[] C_aligned={C_lihdr(0,0,23),40,105,110,108,105,110,101,45,108,101,116,32,108,101,116,45,101,120,112,52,48,53,41,0};
static C_char C_TLS li59[] C_aligned={C_lihdr(0,0,13),40,97,51,52,51,54,32,120,49,51,57,54,41,0,0,0};
static C_char C_TLS li60[] C_aligned={C_lihdr(0,0,25),40,112,101,114,109,117,116,97,116,105,111,110,32,112,49,51,57,52,32,112,50,51,57,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li61[] C_aligned={C_lihdr(0,0,23),40,102,105,110,100,45,112,114,101,102,105,120,32,98,51,57,50,32,97,51,57,51,41,0};
static C_char C_TLS li62[] C_aligned={C_lihdr(0,0,18),40,97,50,55,53,52,32,112,50,51,52,53,32,97,51,52,54,41,0,0,0,0,0,0};
static C_char C_TLS li63[] C_aligned={C_lihdr(0,0,17),40,97,50,55,57,54,32,112,51,52,55,32,97,51,52,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li64[] C_aligned={C_lihdr(0,0,16),40,97,50,56,50,57,32,112,108,105,115,116,51,53,57,41};
static C_char C_TLS li65[] C_aligned={C_lihdr(0,0,16),40,97,50,56,55,53,32,99,100,114,45,112,51,53,54,41};
static C_char C_TLS li66[] C_aligned={C_lihdr(0,0,25),40,97,50,56,54,50,32,99,97,114,45,112,51,53,52,32,99,97,114,45,97,51,53,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li67[] C_aligned={C_lihdr(0,0,19),40,111,114,42,32,112,108,105,115,116,51,53,50,32,107,51,53,51,41,0,0,0,0,0};
static C_char C_TLS li68[] C_aligned={C_lihdr(0,0,29),40,97,50,56,49,57,32,102,105,114,115,116,45,112,51,52,57,32,102,105,114,115,116,45,97,51,53,48,41,0,0,0};
static C_char C_TLS li69[] C_aligned={C_lihdr(0,0,19),40,97,50,57,50,57,32,112,50,51,54,48,32,97,50,51,54,49,41,0,0,0,0,0};
static C_char C_TLS li70[] C_aligned={C_lihdr(0,0,12),40,97,51,48,48,50,32,95,51,54,54,41,0,0,0,0};
static C_char C_TLS li71[] C_aligned={C_lihdr(0,0,17),40,97,50,57,55,51,32,113,51,54,51,32,98,51,54,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li72[] C_aligned={C_lihdr(0,0,18),40,97,51,48,50,49,32,112,49,51,54,55,32,97,51,54,56,41,0,0,0,0,0,0};
static C_char C_TLS li73[] C_aligned={C_lihdr(0,0,21),40,97,51,49,50,50,32,99,100,114,45,112,51,55,49,32,97,51,55,50,41,0,0,0};
static C_char C_TLS li74[] C_aligned={C_lihdr(0,0,21),40,97,51,49,49,50,32,99,97,114,45,112,51,54,57,32,97,51,55,48,41,0,0,0};
static C_char C_TLS li75[] C_aligned={C_lihdr(0,0,18),40,97,51,49,52,53,32,112,108,51,55,51,32,97,51,55,52,41,0,0,0,0,0,0};
static C_char C_TLS li76[] C_aligned={C_lihdr(0,0,22),40,98,111,117,110,100,32,112,51,51,51,32,97,51,51,52,32,107,51,51,53,41,0,0};
static C_char C_TLS li77[] C_aligned={C_lihdr(0,0,6),40,103,49,49,53,41,0,0};
static C_char C_TLS li78[] C_aligned={C_lihdr(0,0,21),40,97,51,51,49,53,32,99,100,114,45,112,51,56,51,32,97,51,56,52,41,0,0,0};
static C_char C_TLS li79[] C_aligned={C_lihdr(0,0,21),40,97,51,51,48,57,32,99,97,114,45,112,51,56,49,32,97,51,56,50,41,0,0,0};
static C_char C_TLS li80[] C_aligned={C_lihdr(0,0,27),40,98,111,117,110,100,118,32,112,108,105,115,116,51,55,53,32,97,51,55,54,32,107,51,55,55,41,0,0,0,0,0};
static C_char C_TLS li81[] C_aligned={C_lihdr(0,0,21),40,97,51,51,57,48,32,99,100,114,45,112,51,57,48,32,97,51,57,49,41,0,0,0};
static C_char C_TLS li82[] C_aligned={C_lihdr(0,0,21),40,97,51,51,56,48,32,99,97,114,45,112,51,56,56,32,97,51,56,57,41,0,0,0};
static C_char C_TLS li83[] C_aligned={C_lihdr(0,0,27),40,98,111,117,110,100,42,32,112,108,105,115,116,51,56,53,32,97,51,56,54,32,107,51,56,55,41,0,0,0,0,0};
static C_char C_TLS li84[] C_aligned={C_lihdr(0,0,17),40,97,51,52,53,51,32,112,51,57,55,32,97,51,57,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li85[] C_aligned={C_lihdr(0,0,18),40,98,111,117,110,100,32,112,97,116,116,101,114,110,51,50,54,41,0,0,0,0,0,0};
static C_char C_TLS li86[] C_aligned={C_lihdr(0,0,19),40,112,97,116,116,101,114,110,45,118,97,114,63,32,120,50,53,53,41,0,0,0,0,0};
static C_char C_TLS li87[] C_aligned={C_lihdr(0,0,9),40,115,105,109,112,108,101,63,41,0,0,0,0,0,0,0};
static C_char C_TLS li88[] C_aligned={C_lihdr(0,0,15),40,103,56,56,32,120,50,56,52,32,121,50,56,53,41,0};
static C_char C_TLS li89[] C_aligned={C_lihdr(0,0,15),40,111,114,100,105,110,97,114,121,32,112,50,56,50,41,0};
static C_char C_TLS li90[] C_aligned={C_lihdr(0,0,16),40,103,49,48,57,32,120,51,48,56,32,121,51,48,57,41};
static C_char C_TLS li91[] C_aligned={C_lihdr(0,0,12),40,113,117,97,115,105,32,112,51,48,54,41,0,0,0,0};
static C_char C_TLS li92[] C_aligned={C_lihdr(0,0,14),40,111,114,100,108,105,115,116,32,112,51,50,49,41,0,0};
static C_char C_TLS li93[] C_aligned={C_lihdr(0,0,29),40,118,97,108,105,100,97,116,101,45,112,97,116,116,101,114,110,32,112,97,116,116,101,114,110,50,54,56,41,0,0,0};
static C_char C_TLS li94[] C_aligned={C_lihdr(0,0,12),40,97,49,52,55,56,32,120,50,54,55,41,0,0,0,0};
static C_char C_TLS li95[] C_aligned={C_lihdr(0,0,36),40,117,110,114,101,97,99,104,97,98,108,101,32,112,108,105,115,116,50,54,53,32,109,97,116,99,104,45,101,120,112,114,50,54,54,41,0,0,0,0};
static C_char C_TLS li96[] C_aligned={C_lihdr(0,0,12),40,97,49,52,48,54,32,120,50,54,48,41,0,0,0,0};
static C_char C_TLS li97[] C_aligned={C_lihdr(0,0,12),40,97,49,52,49,56,32,120,50,54,49,41,0,0,0,0};
static C_char C_TLS li98[] C_aligned={C_lihdr(0,0,12),40,97,49,52,52,51,32,120,50,54,52,41,0,0,0,0};
static C_char C_TLS li99[] C_aligned={C_lihdr(0,0,27),40,101,114,114,111,114,45,109,97,107,101,114,32,109,97,116,99,104,45,101,120,112,114,50,53,57,41,0,0,0,0,0};
static C_char C_TLS li100[] C_aligned={C_lihdr(0,0,11),40,97,56,50,52,32,99,50,48,52,41,0,0,0,0,0};
static C_char C_TLS li101[] C_aligned={C_lihdr(0,0,40),40,103,101,110,109,97,116,99,104,32,120,49,57,55,32,99,108,97,117,115,101,115,49,57,56,32,109,97,116,99,104,45,101,120,112,114,49,57,57,41};
static C_char C_TLS li102[] C_aligned={C_lihdr(0,0,17),40,97,49,48,54,54,32,118,50,51,51,32,103,50,51,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li103[] C_aligned={C_lihdr(0,0,12),40,97,49,48,55,50,32,118,50,51,50,41,0,0,0,0};
static C_char C_TLS li104[] C_aligned={C_lihdr(0,0,12),40,97,49,49,48,50,32,95,50,51,49,41,0,0,0,0};
static C_char C_TLS li105[] C_aligned={C_lihdr(0,0,47),40,103,101,110,108,101,116,114,101,99,32,112,97,116,50,49,54,32,101,120,112,50,49,55,32,98,111,100,121,50,49,56,32,109,97,116,99,104,45,101,120,112,114,50,49,57,41,0};
static C_char C_TLS li106[] C_aligned={C_lihdr(0,0,17),40,97,49,50,52,50,32,118,50,53,50,32,103,50,53,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li107[] C_aligned={C_lihdr(0,0,12),40,97,49,50,55,50,32,118,50,53,49,41,0,0,0,0};
static C_char C_TLS li108[] C_aligned={C_lihdr(0,0,12),40,97,49,50,55,56,32,95,50,53,48,41,0,0,0,0};
static C_char C_TLS li109[] C_aligned={C_lihdr(0,0,39),40,103,101,110,100,101,102,105,110,101,32,112,97,116,50,51,54,32,101,120,112,50,51,55,32,109,97,116,99,104,45,101,120,112,114,50,51,56,41,0};
static C_char C_TLS li110[] C_aligned={C_lihdr(0,0,5),40,114,97,99,41,0,0,0};
static C_char C_TLS li111[] C_aligned={C_lihdr(0,0,10),40,114,100,99,32,108,54,52,48,41,0,0,0,0,0,0};
static C_char C_TLS li112[] C_aligned={C_lihdr(0,0,30),40,109,97,116,99,104,45,101,114,114,111,114,45,99,111,110,116,114,111,108,32,46,32,97,114,103,54,54,55,41,0,0};
static C_char C_TLS li113[] C_aligned={C_lihdr(0,0,33),40,109,97,116,99,104,45,101,114,114,111,114,45,112,114,111,99,101,100,117,114,101,32,46,32,112,114,111,99,54,54,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li114[] C_aligned={C_lihdr(0,0,6),40,103,50,48,57,41,0,0};
static C_char C_TLS li115[] C_aligned={C_lihdr(0,0,15),40,97,55,52,57,52,32,97,114,103,115,49,54,50,41,0};
static C_char C_TLS li116[] C_aligned={C_lihdr(0,0,32),40,103,49,57,57,32,101,49,49,48,54,32,112,50,49,48,55,32,101,50,49,48,56,32,98,111,100,121,49,48,57,41};
static C_char C_TLS li117[] C_aligned={C_lihdr(0,0,6),40,103,49,57,53,41,0,0};
static C_char C_TLS li118[] C_aligned={C_lihdr(0,0,28),40,103,49,57,52,32,112,97,116,49,49,48,32,101,120,112,49,49,49,32,98,111,100,121,49,49,50,41,0,0,0,0};
static C_char C_TLS li119[] C_aligned={C_lihdr(0,0,28),40,103,49,56,54,32,112,97,116,49,49,51,32,101,120,112,49,49,52,32,98,111,100,121,49,49,53,41,0,0,0,0};
static C_char C_TLS li120[] C_aligned={C_lihdr(0,0,30),40,103,49,56,57,32,103,49,57,48,49,49,56,32,103,49,56,56,49,49,57,32,103,49,56,55,49,50,48,41,0,0};
static C_char C_TLS li121[] C_aligned={C_lihdr(0,0,30),40,103,49,56,57,32,103,49,57,48,49,50,51,32,103,49,56,56,49,50,52,32,103,49,56,55,49,50,53,41,0,0};
static C_char C_TLS li122[] C_aligned={C_lihdr(0,0,30),40,103,49,56,57,32,103,49,57,48,49,50,56,32,103,49,56,56,49,50,57,32,103,49,56,55,49,51,48,41,0,0};
static C_char C_TLS li123[] C_aligned={C_lihdr(0,0,30),40,103,49,56,57,32,103,49,57,48,49,51,51,32,103,49,56,56,49,51,52,32,103,49,56,55,49,51,53,41,0,0};
static C_char C_TLS li124[] C_aligned={C_lihdr(0,0,30),40,103,49,56,57,32,103,49,57,48,49,51,56,32,103,49,56,56,49,51,57,32,103,49,56,55,49,52,48,41,0,0};
static C_char C_TLS li125[] C_aligned={C_lihdr(0,0,15),40,97,56,51,53,56,32,103,50,48,54,49,49,54,41,0};
static C_char C_TLS li126[] C_aligned={C_lihdr(0,0,30),40,103,49,56,57,32,103,49,57,48,49,52,51,32,103,49,56,56,49,52,52,32,103,49,56,55,49,52,53,41,0,0};
static C_char C_TLS li127[] C_aligned={C_lihdr(0,0,30),40,103,49,56,57,32,103,49,57,48,49,52,56,32,103,49,56,56,49,52,57,32,103,49,56,55,49,53,48,41,0,0};
static C_char C_TLS li128[] C_aligned={C_lihdr(0,0,30),40,103,49,56,57,32,103,49,57,48,49,53,51,32,103,49,56,56,49,53,52,32,103,49,56,55,49,53,53,41,0,0};
static C_char C_TLS li129[] C_aligned={C_lihdr(0,0,30),40,103,49,56,57,32,103,49,57,48,49,53,56,32,103,49,56,56,49,53,57,32,103,49,56,55,49,54,48,41,0,0};
static C_char C_TLS li130[] C_aligned={C_lihdr(0,0,14),40,97,55,53,57,55,32,97,114,103,115,57,57,41,0,0};
static C_char C_TLS li131[] C_aligned={C_lihdr(0,0,6),40,103,49,55,54,41,0,0};
static C_char C_TLS li132[] C_aligned={C_lihdr(0,0,14),40,97,56,57,54,52,32,97,114,103,115,57,50,41,0,0};
static C_char C_TLS li133[] C_aligned={C_lihdr(0,0,19),40,103,49,53,56,32,101,120,112,50,50,32,98,111,100,121,50,51,41,0,0,0,0,0};
static C_char C_TLS li134[] C_aligned={C_lihdr(0,0,11),40,97,57,49,57,49,32,120,50,57,41,0,0,0,0,0};
static C_char C_TLS li135[] C_aligned={C_lihdr(0,0,25),40,103,49,53,52,32,112,97,116,50,52,32,101,120,112,50,53,32,98,111,100,121,50,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li136[] C_aligned={C_lihdr(0,0,6),40,103,49,52,54,41,0,0};
static C_char C_TLS li137[] C_aligned={C_lihdr(0,0,33),40,103,49,52,53,32,112,49,51,48,32,101,49,51,49,32,112,50,51,50,32,101,50,51,51,32,98,111,100,121,51,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li138[] C_aligned={C_lihdr(0,0,27),40,103,49,54,49,32,103,49,54,50,51,56,32,103,49,54,48,51,57,32,103,49,53,57,52,48,41,0,0,0,0,0};
static C_char C_TLS li139[] C_aligned={C_lihdr(0,0,27),40,103,49,52,57,32,103,49,53,48,52,56,32,103,49,52,56,52,57,32,103,49,52,55,53,48,41,0,0,0,0,0};
static C_char C_TLS li140[] C_aligned={C_lihdr(0,0,27),40,103,49,52,57,32,103,49,53,48,53,51,32,103,49,52,56,53,52,32,103,49,52,55,53,53,41,0,0,0,0,0};
static C_char C_TLS li141[] C_aligned={C_lihdr(0,0,27),40,103,49,52,57,32,103,49,53,48,53,56,32,103,49,52,56,53,57,32,103,49,52,55,54,48,41,0,0,0,0,0};
static C_char C_TLS li142[] C_aligned={C_lihdr(0,0,27),40,103,49,52,57,32,103,49,53,48,54,51,32,103,49,52,56,54,52,32,103,49,52,55,54,53,41,0,0,0,0,0};
static C_char C_TLS li143[] C_aligned={C_lihdr(0,0,27),40,103,49,52,57,32,103,49,53,48,54,56,32,103,49,52,56,54,57,32,103,49,52,55,55,48,41,0,0,0,0,0};
static C_char C_TLS li144[] C_aligned={C_lihdr(0,0,15),40,97,49,48,48,57,50,32,103,49,54,55,52,54,41,0};
static C_char C_TLS li145[] C_aligned={C_lihdr(0,0,27),40,103,49,52,57,32,103,49,53,48,55,51,32,103,49,52,56,55,52,32,103,49,52,55,55,53,41,0,0,0,0,0};
static C_char C_TLS li146[] C_aligned={C_lihdr(0,0,27),40,103,49,52,57,32,103,49,53,48,55,56,32,103,49,52,56,55,57,32,103,49,52,55,56,48,41,0,0,0,0,0};
static C_char C_TLS li147[] C_aligned={C_lihdr(0,0,27),40,103,49,52,57,32,103,49,53,48,56,51,32,103,49,52,56,56,52,32,103,49,52,55,56,53,41,0,0,0,0,0};
static C_char C_TLS li148[] C_aligned={C_lihdr(0,0,27),40,103,49,52,57,32,103,49,53,48,56,56,32,103,49,52,56,56,57,32,103,49,52,55,57,48,41,0,0,0,0,0};
static C_char C_TLS li149[] C_aligned={C_lihdr(0,0,14),40,97,57,49,53,50,32,97,114,103,115,49,53,41,0,0};
static C_char C_TLS li150[] C_aligned={C_lihdr(0,0,15),40,97,49,48,55,51,56,32,103,49,51,52,49,51,41,0};
static C_char C_TLS li151[] C_aligned={C_lihdr(0,0,15),40,97,49,48,55,48,50,32,97,114,103,115,49,50,41,0};
static C_char C_TLS li152[] C_aligned={C_lihdr(0,0,15),40,97,49,48,56,48,52,32,103,49,50,54,49,48,41,0};
static C_char C_TLS li153[] C_aligned={C_lihdr(0,0,14),40,97,49,48,55,54,52,32,97,114,103,115,57,41,0,0};
static C_char C_TLS li154[] C_aligned={C_lihdr(0,0,11),40,97,49,48,57,49,49,32,121,53,41,0,0,0,0,0};
static C_char C_TLS li155[] C_aligned={C_lihdr(0,0,14),40,97,49,48,56,51,48,32,97,114,103,115,52,41,0,0};
static C_char C_TLS li156[] C_aligned={C_lihdr(0,0,10),40,116,111,112,108,101,118,101,108,41,0,0,0,0,0,0};


C_noret_decl(C_match_toplevel)
C_externexport void C_ccall C_match_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10831)
static void C_ccall f_10831(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10912)
static void C_ccall f_10912(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10838)
static void C_ccall f_10838(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10847)
static void C_ccall f_10847(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10874)
static void C_ccall f_10874(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_717)
static void C_ccall f_717(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10765)
static void C_ccall f_10765(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10805)
static void C_ccall f_10805(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10812)
static void C_fcall f_10812(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10772)
static void C_ccall f_10772(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10775)
static void C_ccall f_10775(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_720)
static void C_ccall f_720(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10703)
static void C_ccall f_10703(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10739)
static void C_ccall f_10739(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10746)
static void C_fcall f_10746(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10710)
static void C_ccall f_10710(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10713)
static void C_ccall f_10713(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_723)
static void C_ccall f_723(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9153)
static void C_ccall f_9153(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10683)
static void C_ccall f_10683(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10679)
static void C_ccall f_10679(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10675)
static void C_ccall f_10675(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10143)
static void C_fcall f_10143(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10558)
static void C_fcall f_10558(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_10655)
static void C_ccall f_10655(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10651)
static void C_ccall f_10651(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10609)
static void C_fcall f_10609(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10632)
static void C_ccall f_10632(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10628)
static void C_ccall f_10628(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10571)
static void C_fcall f_10571(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10578)
static void C_ccall f_10578(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10582)
static void C_ccall f_10582(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10549)
static void C_ccall f_10549(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10545)
static void C_ccall f_10545(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10541)
static void C_ccall f_10541(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10537)
static void C_ccall f_10537(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10533)
static void C_ccall f_10533(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10525)
static void C_ccall f_10525(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10265)
static void C_fcall f_10265(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10396)
static void C_fcall f_10396(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_10493)
static void C_ccall f_10493(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10489)
static void C_ccall f_10489(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10447)
static void C_fcall f_10447(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10470)
static void C_ccall f_10470(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10466)
static void C_ccall f_10466(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10409)
static void C_fcall f_10409(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10416)
static void C_ccall f_10416(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10420)
static void C_ccall f_10420(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10271)
static void C_fcall f_10271(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10307)
static void C_fcall f_10307(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_10369)
static void C_ccall f_10369(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10365)
static void C_ccall f_10365(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10323)
static void C_fcall f_10323(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10346)
static void C_ccall f_10346(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10342)
static void C_ccall f_10342(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10278)
static void C_ccall f_10278(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10282)
static void C_ccall f_10282(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10286)
static void C_ccall f_10286(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10298)
static void C_ccall f_10298(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10155)
static void C_fcall f_10155(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10179)
static void C_fcall f_10179(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_10241)
static void C_ccall f_10241(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10237)
static void C_ccall f_10237(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10195)
static void C_fcall f_10195(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10218)
static void C_ccall f_10218(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10214)
static void C_ccall f_10214(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10162)
static void C_ccall f_10162(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10166)
static void C_ccall f_10166(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10093)
static void C_ccall f_10093(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10116)
static void C_ccall f_10116(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10100)
static void C_fcall f_10100(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9437)
static void C_ccall f_9437(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10087)
static void C_ccall f_10087(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10083)
static void C_ccall f_10083(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10079)
static void C_ccall f_10079(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9541)
static void C_fcall f_9541(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9956)
static void C_fcall f_9956(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_10053)
static void C_ccall f_10053(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10049)
static void C_ccall f_10049(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10007)
static void C_fcall f_10007(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10030)
static void C_ccall f_10030(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10026)
static void C_ccall f_10026(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9969)
static void C_fcall f_9969(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9976)
static void C_ccall f_9976(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9980)
static void C_ccall f_9980(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9947)
static void C_ccall f_9947(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9943)
static void C_ccall f_9943(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9939)
static void C_ccall f_9939(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9935)
static void C_ccall f_9935(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9931)
static void C_ccall f_9931(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9923)
static void C_ccall f_9923(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9663)
static void C_fcall f_9663(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9794)
static void C_fcall f_9794(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9891)
static void C_ccall f_9891(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9887)
static void C_ccall f_9887(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9845)
static void C_fcall f_9845(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9868)
static void C_ccall f_9868(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9864)
static void C_ccall f_9864(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9807)
static void C_fcall f_9807(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9814)
static void C_ccall f_9814(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9818)
static void C_ccall f_9818(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9669)
static void C_fcall f_9669(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9705)
static void C_fcall f_9705(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9767)
static void C_ccall f_9767(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9763)
static void C_ccall f_9763(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9721)
static void C_fcall f_9721(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9744)
static void C_ccall f_9744(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9740)
static void C_ccall f_9740(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9676)
static void C_ccall f_9676(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9680)
static void C_ccall f_9680(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9684)
static void C_ccall f_9684(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9696)
static void C_ccall f_9696(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9553)
static void C_fcall f_9553(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9577)
static void C_fcall f_9577(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9639)
static void C_ccall f_9639(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9635)
static void C_ccall f_9635(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9593)
static void C_fcall f_9593(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9616)
static void C_ccall f_9616(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9612)
static void C_ccall f_9612(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9560)
static void C_ccall f_9560(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9564)
static void C_ccall f_9564(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9443)
static void C_fcall f_9443(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9455)
static void C_fcall f_9455(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9517)
static void C_ccall f_9517(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9513)
static void C_ccall f_9513(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9471)
static void C_fcall f_9471(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9494)
static void C_ccall f_9494(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9490)
static void C_ccall f_9490(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9265)
static void C_fcall f_9265(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9274)
static void C_fcall f_9274(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9404)
static void C_ccall f_9404(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9400)
static void C_ccall f_9400(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9358)
static void C_fcall f_9358(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9381)
static void C_ccall f_9381(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9377)
static void C_ccall f_9377(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9287)
static void C_fcall f_9287(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9293)
static void C_ccall f_9293(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9296)
static void C_ccall f_9296(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9305)
static void C_ccall f_9305(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9206)
static void C_fcall f_9206(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_9210)
static void C_ccall f_9210(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9213)
static void C_ccall f_9213(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9197)
static void C_fcall f_9197(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9164)
static void C_fcall f_9164(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9192)
static void C_ccall f_9192(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9168)
static void C_ccall f_9168(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9171)
static void C_ccall f_9171(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9178)
static void C_ccall f_9178(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9155)
static C_word C_fcall f_9155(C_word *a,C_word t0,C_word t1,C_word t2);
C_noret_decl(f_726)
static void C_ccall f_726(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8965)
static void C_ccall f_8965(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9140)
static void C_ccall f_9140(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9136)
static void C_ccall f_9136(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9132)
static void C_ccall f_9132(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9128)
static void C_ccall f_9128(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9022)
static void C_fcall f_9022(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9025)
static void C_ccall f_9025(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9028)
static void C_ccall f_9028(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9031)
static void C_ccall f_9031(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9040)
static void C_ccall f_9040(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8993)
static void C_fcall f_8993(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8967)
static void C_fcall f_8967(C_word t0,C_word t1) C_noret;
C_noret_decl(f_729)
static void C_ccall f_729(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7598)
static void C_ccall f_7598(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8949)
static void C_ccall f_8949(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8945)
static void C_ccall f_8945(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8941)
static void C_ccall f_8941(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8409)
static void C_fcall f_8409(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8824)
static void C_fcall f_8824(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8921)
static void C_ccall f_8921(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8917)
static void C_ccall f_8917(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8875)
static void C_fcall f_8875(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8898)
static void C_ccall f_8898(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8894)
static void C_ccall f_8894(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8837)
static void C_fcall f_8837(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8844)
static void C_ccall f_8844(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8848)
static void C_ccall f_8848(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8815)
static void C_ccall f_8815(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8811)
static void C_ccall f_8811(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8807)
static void C_ccall f_8807(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8803)
static void C_ccall f_8803(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8799)
static void C_ccall f_8799(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8791)
static void C_ccall f_8791(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8531)
static void C_fcall f_8531(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8662)
static void C_fcall f_8662(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8759)
static void C_ccall f_8759(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8755)
static void C_ccall f_8755(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8713)
static void C_fcall f_8713(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8736)
static void C_ccall f_8736(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8732)
static void C_ccall f_8732(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8675)
static void C_fcall f_8675(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8682)
static void C_ccall f_8682(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8686)
static void C_ccall f_8686(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8537)
static void C_fcall f_8537(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8573)
static void C_fcall f_8573(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8635)
static void C_ccall f_8635(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8631)
static void C_ccall f_8631(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8589)
static void C_fcall f_8589(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8612)
static void C_ccall f_8612(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8608)
static void C_ccall f_8608(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8544)
static void C_ccall f_8544(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8548)
static void C_ccall f_8548(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8552)
static void C_ccall f_8552(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8564)
static void C_ccall f_8564(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8421)
static void C_fcall f_8421(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8445)
static void C_fcall f_8445(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8507)
static void C_ccall f_8507(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8503)
static void C_ccall f_8503(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8461)
static void C_fcall f_8461(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8484)
static void C_ccall f_8484(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8480)
static void C_ccall f_8480(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8428)
static void C_ccall f_8428(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8432)
static void C_ccall f_8432(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8359)
static void C_ccall f_8359(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8382)
static void C_ccall f_8382(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8366)
static void C_fcall f_8366(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7703)
static void C_ccall f_7703(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8353)
static void C_ccall f_8353(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8349)
static void C_ccall f_8349(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8345)
static void C_ccall f_8345(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7807)
static void C_fcall f_7807(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8222)
static void C_fcall f_8222(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8319)
static void C_ccall f_8319(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8315)
static void C_ccall f_8315(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8273)
static void C_fcall f_8273(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8296)
static void C_ccall f_8296(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8292)
static void C_ccall f_8292(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8235)
static void C_fcall f_8235(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8242)
static void C_ccall f_8242(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8246)
static void C_ccall f_8246(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8213)
static void C_ccall f_8213(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8209)
static void C_ccall f_8209(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8205)
static void C_ccall f_8205(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8201)
static void C_ccall f_8201(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8197)
static void C_ccall f_8197(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8189)
static void C_ccall f_8189(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7929)
static void C_fcall f_7929(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8060)
static void C_fcall f_8060(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8157)
static void C_ccall f_8157(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8153)
static void C_ccall f_8153(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8111)
static void C_fcall f_8111(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8134)
static void C_ccall f_8134(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8130)
static void C_ccall f_8130(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8073)
static void C_fcall f_8073(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8080)
static void C_ccall f_8080(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8084)
static void C_ccall f_8084(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7935)
static void C_fcall f_7935(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7971)
static void C_fcall f_7971(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8033)
static void C_ccall f_8033(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8029)
static void C_ccall f_8029(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7987)
static void C_fcall f_7987(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8010)
static void C_ccall f_8010(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8006)
static void C_ccall f_8006(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7942)
static void C_ccall f_7942(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7946)
static void C_ccall f_7946(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7950)
static void C_ccall f_7950(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7962)
static void C_ccall f_7962(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7819)
static void C_fcall f_7819(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7843)
static void C_fcall f_7843(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7905)
static void C_ccall f_7905(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7901)
static void C_ccall f_7901(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7859)
static void C_fcall f_7859(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7882)
static void C_ccall f_7882(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7878)
static void C_ccall f_7878(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7826)
static void C_ccall f_7826(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7830)
static void C_ccall f_7830(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7709)
static void C_fcall f_7709(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7721)
static void C_fcall f_7721(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7783)
static void C_ccall f_7783(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7779)
static void C_ccall f_7779(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7737)
static void C_fcall f_7737(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7760)
static void C_ccall f_7760(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7756)
static void C_ccall f_7756(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7662)
static void C_fcall f_7662(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7637)
static void C_fcall f_7637(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7657)
static void C_ccall f_7657(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7628)
static void C_fcall f_7628(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7603)
static C_word C_fcall f_7603(C_word *a,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4);
C_noret_decl(f_732)
static void C_ccall f_732(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7495)
static void C_ccall f_7495(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7520)
static void C_ccall f_7520(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7556)
static void C_fcall f_7556(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7526)
static void C_fcall f_7526(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7500)
static void C_fcall f_7500(C_word t0,C_word t1) C_noret;
C_noret_decl(f_735)
static void C_ccall f_735(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7493)
static void C_ccall f_7493(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7476)
static void C_ccall f_7476(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_7476)
static void C_ccall f_7476r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_7460)
static void C_ccall f_7460(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_7460)
static void C_ccall f_7460r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_7429)
static void C_fcall f_7429(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7447)
static void C_ccall f_7447(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7406)
static C_word C_fcall f_7406(C_word t0);
C_noret_decl(f_1125)
static void C_ccall f_1125(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1129)
static void C_ccall f_1129(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1132)
static void C_ccall f_1132(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1299)
static void C_ccall f_1299(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1135)
static void C_ccall f_1135(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1147)
static void C_ccall f_1147(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1153)
static void C_ccall f_1153(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1291)
static void C_ccall f_1291(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1156)
static void C_ccall f_1156(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1279)
static void C_ccall f_1279(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1159)
static void C_ccall f_1159(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1162)
static void C_ccall f_1162(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1273)
static void C_ccall f_1273(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1173)
static void C_ccall f_1173(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1243)
static void C_ccall f_1243(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1233)
static void C_ccall f_1233(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1229)
static void C_ccall f_1229(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1213)
static void C_ccall f_1213(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1181)
static void C_ccall f_1181(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1169)
static void C_ccall f_1169(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_969)
static void C_ccall f_969(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_973)
static void C_ccall f_973(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_976)
static void C_ccall f_976(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1123)
static void C_ccall f_1123(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_979)
static void C_ccall f_979(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_991)
static void C_ccall f_991(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_997)
static void C_ccall f_997(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1115)
static void C_ccall f_1115(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1000)
static void C_ccall f_1000(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1103)
static void C_ccall f_1103(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1003)
static void C_ccall f_1003(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1006)
static void C_ccall f_1006(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1073)
static void C_ccall f_1073(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1025)
static void C_ccall f_1025(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1067)
static void C_ccall f_1067(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1065)
static void C_ccall f_1065(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1061)
static void C_ccall f_1061(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1045)
static void C_ccall f_1045(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1021)
static void C_ccall f_1021(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_757)
static void C_ccall f_757(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_761)
static void C_ccall f_761(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_764)
static void C_ccall f_764(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_825)
static void C_ccall f_825(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_963)
static void C_ccall f_963(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_829)
static void C_ccall f_829(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_841)
static void C_ccall f_841(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_951)
static void C_ccall f_951(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_947)
static void C_ccall f_947(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_943)
static void C_ccall f_943(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_939)
static void C_ccall f_939(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_844)
static void C_ccall f_844(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_872)
static void C_ccall f_872(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_861)
static void C_ccall f_861(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_770)
static void C_ccall f_770(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_823)
static void C_ccall f_823(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_773)
static void C_ccall f_773(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_776)
static void C_ccall f_776(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1395)
static void C_fcall f_1395(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1432)
static void C_ccall f_1432(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1435)
static void C_ccall f_1435(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1444)
static void C_ccall f_1444(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1419)
static void C_ccall f_1419(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1407)
static void C_ccall f_1407(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1473)
static void C_fcall f_1473(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1479)
static void C_ccall f_1479(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1503)
static void C_fcall f_1503(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2528)
static void C_fcall f_2528(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2548)
static void C_ccall f_2548(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2552)
static void C_ccall f_2552(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2266)
static void C_ccall f_2266(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2484)
static void C_ccall f_2484(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2487)
static void C_ccall f_2487(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2497)
static void C_ccall f_2497(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2512)
static void C_ccall f_2512(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2494)
static void C_ccall f_2494(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2467)
static void C_ccall f_2467(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2463)
static void C_ccall f_2463(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2459)
static void C_ccall f_2459(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2350)
static void C_fcall f_2350(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2422)
static void C_ccall f_2422(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2389)
static void C_fcall f_2389(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2402)
static void C_ccall f_2402(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2365)
static void C_ccall f_2365(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2375)
static void C_ccall f_2375(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2379)
static void C_ccall f_2379(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2359)
static void C_ccall f_2359(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2313)
static void C_fcall f_2313(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2268)
static void C_fcall f_2268(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2276)
static void C_ccall f_2276(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2280)
static void C_ccall f_2280(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1536)
static void C_ccall f_1536(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1568)
static void C_ccall f_1568(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2212)
static void C_ccall f_2212(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2215)
static void C_ccall f_2215(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2225)
static void C_ccall f_2225(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2240)
static void C_ccall f_2240(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2222)
static void C_ccall f_2222(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2140)
static void C_ccall f_2140(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2107)
static void C_fcall f_2107(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2120)
static void C_ccall f_2120(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2052)
static void C_ccall f_2052(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2032)
static void C_fcall f_2032(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2005)
static void C_ccall f_2005(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1985)
static void C_fcall f_1985(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1921)
static void C_fcall f_1921(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1938)
static void C_ccall f_1938(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1874)
static void C_fcall f_1874(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1884)
static void C_ccall f_1884(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1827)
static void C_fcall f_1827(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1837)
static void C_ccall f_1837(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1780)
static void C_fcall f_1780(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1790)
static void C_ccall f_1790(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1720)
static void C_fcall f_1720(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1733)
static void C_ccall f_1733(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1666)
static void C_fcall f_1666(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1683)
static void C_ccall f_1683(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1629)
static void C_fcall f_1629(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1586)
static void C_fcall f_1586(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1538)
static void C_fcall f_1538(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1546)
static void C_ccall f_1546(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1550)
static void C_ccall f_1550(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1506)
static C_word C_fcall f_1506(C_word t0);
C_noret_decl(f_1301)
static void C_ccall f_1301(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1325)
static void C_ccall f_1325(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2568)
static void C_fcall f_2568(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3454)
static void C_ccall f_3454(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3462)
static void C_ccall f_3462(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3362)
static void C_fcall f_3362(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3381)
static void C_ccall f_3381(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3391)
static void C_ccall f_3391(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3269)
static void C_fcall f_3269(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3333)
static void C_ccall f_3333(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3287)
static void C_fcall f_3287(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3310)
static void C_ccall f_3310(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3316)
static void C_ccall f_3316(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3271)
static void C_fcall f_3271(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2572)
static void C_fcall f_2572(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2610)
static void C_fcall f_2610(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2619)
static void C_fcall f_2619(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2711)
static void C_fcall f_2711(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2788)
static void C_fcall f_2788(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2811)
static void C_fcall f_2811(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2900)
static void C_fcall f_2900(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2965)
static void C_ccall f_2965(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3013)
static void C_fcall f_3013(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3044)
static void C_fcall f_3044(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3074)
static void C_fcall f_3074(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3144)
static void C_ccall f_3144(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3146)
static void C_ccall f_3146(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3154)
static void C_ccall f_3154(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3113)
static void C_ccall f_3113(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3123)
static void C_ccall f_3123(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3022)
static void C_ccall f_3022(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2974)
static void C_ccall f_2974(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2978)
static void C_ccall f_2978(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2993)
static void C_ccall f_2993(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2997)
static void C_ccall f_2997(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3003)
static void C_ccall f_3003(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3001)
static void C_ccall f_3001(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2930)
static void C_ccall f_2930(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2951)
static void C_ccall f_2951(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2934)
static void C_ccall f_2934(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2820)
static void C_ccall f_2820(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2844)
static void C_fcall f_2844(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2863)
static void C_ccall f_2863(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2894)
static void C_ccall f_2894(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2867)
static void C_ccall f_2867(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2876)
static void C_ccall f_2876(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2830)
static void C_ccall f_2830(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2797)
static void C_ccall f_2797(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2720)
static void C_fcall f_2720(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2755)
static void C_ccall f_2755(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2723)
static void C_ccall f_2723(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2657)
static void C_fcall f_2657(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2660)
static void C_ccall f_2660(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2591)
static void C_ccall f_2591(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3401)
static void C_fcall f_3401(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3419)
static void C_ccall f_3419(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3425)
static void C_fcall f_3425(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3437)
static void C_ccall f_3437(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3464)
static void C_fcall f_3464(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3724)
static void C_fcall f_3724(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3753)
static void C_ccall f_3753(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3473)
static void C_fcall f_3473(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3487)
static void C_ccall f_3487(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3491)
static void C_ccall f_3491(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3756)
static void C_ccall f_3756(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3778)
static void C_fcall f_3778(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3513)
static void C_fcall f_3513(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3527)
static void C_ccall f_3527(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3531)
static void C_ccall f_3531(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3789)
static void C_ccall f_3789(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3744)
static void C_ccall f_3744(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3651)
static C_word C_fcall f_3651(C_word t0,C_word t1);
C_noret_decl(f_3629)
static C_word C_fcall f_3629(C_word t0,C_word t1);
C_noret_decl(f_3547)
static C_word C_fcall f_3547(C_word t0);
C_noret_decl(f_3848)
static void C_fcall f_3848(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7) C_noret;
C_noret_decl(f_3973)
static void C_ccall f_3973(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3975)
static void C_fcall f_3975(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_4086)
static void C_fcall f_4086(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4099)
static void C_fcall f_4099(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4115)
static void C_fcall f_4115(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4136)
static void C_fcall f_4136(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4178)
static void C_fcall f_4178(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4221)
static void C_fcall f_4221(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4234)
static void C_fcall f_4234(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4296)
static void C_fcall f_4296(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4321)
static void C_fcall f_4321(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4346)
static void C_ccall f_4346(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4685)
static void C_ccall f_4685(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4975)
static void C_ccall f_4975(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4978)
static void C_ccall f_4978(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4923)
static void C_ccall f_4923(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4937)
static void C_fcall f_4937(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4939)
static void C_ccall f_4939(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4964)
static void C_ccall f_4964(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4935)
static void C_ccall f_4935(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4691)
static void C_ccall f_4691(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4706)
static void C_ccall f_4706(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4718)
static void C_ccall f_4718(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4727)
static void C_fcall f_4727(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4729)
static void C_ccall f_4729(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4751)
static void C_ccall f_4751(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4839)
static void C_ccall f_4839(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4857)
static void C_ccall f_4857(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4865)
static void C_ccall f_4865(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4855)
static void C_ccall f_4855(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4776)
static void C_ccall f_4776(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4829)
static void C_ccall f_4829(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4780)
static void C_ccall f_4780(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4809)
static void C_ccall f_4809(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4807)
static void C_ccall f_4807(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4799)
static void C_ccall f_4799(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4725)
static void C_ccall f_4725(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4722)
static void C_ccall f_4722(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4653)
static void C_ccall f_4653(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4665)
static void C_ccall f_4665(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4667)
static void C_ccall f_4667(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4679)
static void C_ccall f_4679(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4355)
static void C_ccall f_4355(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4359)
static void C_ccall f_4359(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4360)
static void C_ccall f_4360(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4469)
static void C_fcall f_4469(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4553)
static void C_ccall f_4553(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4571)
static void C_ccall f_4571(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4579)
static void C_ccall f_4579(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4569)
static void C_ccall f_4569(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4488)
static void C_ccall f_4488(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4539)
static void C_ccall f_4539(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4537)
static void C_ccall f_4537(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4533)
static void C_ccall f_4533(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4492)
static void C_ccall f_4492(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4521)
static void C_ccall f_4521(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4519)
static void C_ccall f_4519(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4511)
static void C_ccall f_4511(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4462)
static void C_ccall f_4462(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4459)
static void C_ccall f_4459(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4382)
static void C_ccall f_4382(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4403)
static void C_fcall f_4403(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4385)
static void C_fcall f_4385(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4396)
static void C_ccall f_4396(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4400)
static void C_ccall f_4400(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4340)
static void C_ccall f_4340(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4315)
static void C_ccall f_4315(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4290)
static void C_ccall f_4290(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4255)
static void C_fcall f_4255(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4257)
static void C_ccall f_4257(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4282)
static void C_ccall f_4282(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4253)
static void C_ccall f_4253(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4187)
static void C_fcall f_4187(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4207)
static void C_ccall f_4207(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4145)
static void C_fcall f_4145(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4164)
static void C_ccall f_4164(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3877)
static void C_ccall f_3877(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3946)
static void C_ccall f_3946(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3939)
static void C_ccall f_3939(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3931)
static void C_ccall f_3931(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3868)
static void C_ccall f_3868(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3859)
static void C_ccall f_3859(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1327)
static void C_fcall f_1327(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1343)
static void C_ccall f_1343(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1385)
static void C_ccall f_1385(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1381)
static void C_ccall f_1381(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1370)
static void C_ccall f_1370(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1377)
static void C_ccall f_1377(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5121)
static void C_fcall f_5121(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_5128)
static void C_ccall f_5128(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5137)
static void C_ccall f_5137(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5259)
static void C_fcall f_5259(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5146)
static void C_fcall f_5146(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5152)
static void C_fcall f_5152(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5181)
static void C_ccall f_5181(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5155)
static void C_ccall f_5155(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5173)
static void C_ccall f_5173(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5158)
static void C_ccall f_5158(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5303)
static void C_fcall f_5303(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5322)
static void C_ccall f_5322(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5328)
static void C_fcall f_5328(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6127)
static void C_ccall f_6127(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6123)
static void C_ccall f_6123(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6119)
static void C_ccall f_6119(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6115)
static void C_ccall f_6115(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6107)
static void C_ccall f_6107(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6103)
static void C_ccall f_6103(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6095)
static void C_ccall f_6095(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6091)
static void C_ccall f_6091(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6087)
static void C_ccall f_6087(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6083)
static void C_ccall f_6083(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6079)
static void C_ccall f_6079(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6075)
static void C_ccall f_6075(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6071)
static void C_ccall f_6071(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6067)
static void C_ccall f_6067(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6063)
static void C_ccall f_6063(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6059)
static void C_ccall f_6059(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6051)
static void C_ccall f_6051(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6047)
static void C_ccall f_6047(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6039)
static void C_ccall f_6039(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6035)
static void C_ccall f_6035(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6031)
static void C_ccall f_6031(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6027)
static void C_ccall f_6027(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6023)
static void C_ccall f_6023(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6019)
static void C_ccall f_6019(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6015)
static void C_ccall f_6015(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6011)
static void C_ccall f_6011(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6007)
static void C_ccall f_6007(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6003)
static void C_ccall f_6003(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5999)
static void C_ccall f_5999(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5995)
static void C_ccall f_5995(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5991)
static void C_ccall f_5991(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5987)
static void C_ccall f_5987(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5983)
static void C_ccall f_5983(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5975)
static void C_ccall f_5975(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5971)
static void C_ccall f_5971(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5967)
static void C_ccall f_5967(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5963)
static void C_ccall f_5963(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5959)
static void C_ccall f_5959(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5955)
static void C_ccall f_5955(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5951)
static void C_ccall f_5951(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5947)
static void C_ccall f_5947(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5943)
static void C_ccall f_5943(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5939)
static void C_ccall f_5939(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5935)
static void C_ccall f_5935(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5927)
static void C_ccall f_5927(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5923)
static void C_ccall f_5923(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5915)
static void C_ccall f_5915(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5911)
static void C_ccall f_5911(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5907)
static void C_ccall f_5907(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5903)
static void C_ccall f_5903(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5899)
static void C_ccall f_5899(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5895)
static void C_ccall f_5895(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5891)
static void C_ccall f_5891(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5879)
static void C_ccall f_5879(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5875)
static void C_ccall f_5875(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5871)
static void C_ccall f_5871(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5867)
static void C_ccall f_5867(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5386)
static void C_fcall f_5386(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5450)
static void C_ccall f_5450(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5446)
static void C_ccall f_5446(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5442)
static void C_ccall f_5442(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5438)
static void C_ccall f_5438(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5395)
static void C_ccall f_5395(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5418)
static void C_ccall f_5418(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6197)
static void C_fcall f_6197(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6201)
static void C_ccall f_6201(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6204)
static void C_ccall f_6204(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6209)
static void C_fcall f_6209(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6276)
static void C_fcall f_6276(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6279)
static void C_ccall f_6279(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6240)
static void C_ccall f_6240(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6249)
static void C_ccall f_6249(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6328)
static void C_fcall f_6328(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6338)
static void C_fcall f_6338(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6353)
static void C_ccall f_6353(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6545)
static void C_fcall f_6545(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6558)
static void C_fcall f_6558(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6479)
static void C_fcall f_6479(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6492)
static void C_fcall f_6492(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6361)
static void C_fcall f_6361(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6374)
static void C_fcall f_6374(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6405)
static void C_ccall f_6405(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6386)
static void C_fcall f_6386(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6638)
static void C_fcall f_6638(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6678)
static void C_fcall f_6678(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6724)
static C_word C_fcall f_6724(C_word t0);
C_noret_decl(f_6734)
static void C_fcall f_6734(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6738)
static void C_fcall f_6738(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6767)
static void C_fcall f_6767(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6771)
static void C_fcall f_6771(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6801)
static void C_fcall f_6801(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7056)
static void C_ccall f_7056(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6995)
static void C_fcall f_6995(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7021)
static void C_ccall f_7021(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6803)
static void C_fcall f_6803(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7106)
static void C_fcall f_7106(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7275)
static void C_fcall f_7275(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7371)
static void C_fcall f_7371(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7385)
static void C_ccall f_7385(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7383)
static void C_ccall f_7383(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7379)
static void C_ccall f_7379(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_748)
static void C_ccall f_748(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_743)
static void C_ccall f_743(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_737)
static void C_ccall f_737(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_690)
static void C_ccall f_690(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_703)
static void C_ccall f_703(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_10812)
static void C_fcall trf_10812(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10812(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10812(t0,t1);}

C_noret_decl(trf_10746)
static void C_fcall trf_10746(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10746(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10746(t0,t1);}

C_noret_decl(trf_10143)
static void C_fcall trf_10143(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10143(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10143(t0,t1);}

C_noret_decl(trf_10558)
static void C_fcall trf_10558(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10558(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_10558(t0,t1,t2,t3,t4);}

C_noret_decl(trf_10609)
static void C_fcall trf_10609(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10609(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10609(t0,t1);}

C_noret_decl(trf_10571)
static void C_fcall trf_10571(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10571(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10571(t0,t1);}

C_noret_decl(trf_10265)
static void C_fcall trf_10265(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10265(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10265(t0,t1);}

C_noret_decl(trf_10396)
static void C_fcall trf_10396(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10396(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_10396(t0,t1,t2,t3,t4);}

C_noret_decl(trf_10447)
static void C_fcall trf_10447(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10447(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10447(t0,t1);}

C_noret_decl(trf_10409)
static void C_fcall trf_10409(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10409(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10409(t0,t1);}

C_noret_decl(trf_10271)
static void C_fcall trf_10271(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10271(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10271(t0,t1);}

C_noret_decl(trf_10307)
static void C_fcall trf_10307(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10307(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_10307(t0,t1,t2,t3,t4);}

C_noret_decl(trf_10323)
static void C_fcall trf_10323(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10323(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10323(t0,t1);}

C_noret_decl(trf_10155)
static void C_fcall trf_10155(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10155(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10155(t0,t1);}

C_noret_decl(trf_10179)
static void C_fcall trf_10179(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10179(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_10179(t0,t1,t2,t3,t4);}

C_noret_decl(trf_10195)
static void C_fcall trf_10195(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10195(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10195(t0,t1);}

C_noret_decl(trf_10100)
static void C_fcall trf_10100(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10100(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10100(t0,t1);}

C_noret_decl(trf_9541)
static void C_fcall trf_9541(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9541(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9541(t0,t1);}

C_noret_decl(trf_9956)
static void C_fcall trf_9956(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9956(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_9956(t0,t1,t2,t3,t4);}

C_noret_decl(trf_10007)
static void C_fcall trf_10007(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10007(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10007(t0,t1);}

C_noret_decl(trf_9969)
static void C_fcall trf_9969(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9969(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9969(t0,t1);}

C_noret_decl(trf_9663)
static void C_fcall trf_9663(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9663(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9663(t0,t1);}

C_noret_decl(trf_9794)
static void C_fcall trf_9794(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9794(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_9794(t0,t1,t2,t3,t4);}

C_noret_decl(trf_9845)
static void C_fcall trf_9845(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9845(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9845(t0,t1);}

C_noret_decl(trf_9807)
static void C_fcall trf_9807(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9807(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9807(t0,t1);}

C_noret_decl(trf_9669)
static void C_fcall trf_9669(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9669(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9669(t0,t1);}

C_noret_decl(trf_9705)
static void C_fcall trf_9705(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9705(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_9705(t0,t1,t2,t3,t4);}

C_noret_decl(trf_9721)
static void C_fcall trf_9721(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9721(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9721(t0,t1);}

C_noret_decl(trf_9553)
static void C_fcall trf_9553(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9553(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9553(t0,t1);}

C_noret_decl(trf_9577)
static void C_fcall trf_9577(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9577(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_9577(t0,t1,t2,t3,t4);}

C_noret_decl(trf_9593)
static void C_fcall trf_9593(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9593(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9593(t0,t1);}

C_noret_decl(trf_9443)
static void C_fcall trf_9443(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9443(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9443(t0,t1);}

C_noret_decl(trf_9455)
static void C_fcall trf_9455(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9455(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_9455(t0,t1,t2,t3,t4);}

C_noret_decl(trf_9471)
static void C_fcall trf_9471(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9471(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9471(t0,t1);}

C_noret_decl(trf_9265)
static void C_fcall trf_9265(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9265(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9265(t0,t1);}

C_noret_decl(trf_9274)
static void C_fcall trf_9274(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9274(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_9274(t0,t1,t2,t3,t4);}

C_noret_decl(trf_9358)
static void C_fcall trf_9358(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9358(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9358(t0,t1);}

C_noret_decl(trf_9287)
static void C_fcall trf_9287(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9287(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9287(t0,t1);}

C_noret_decl(trf_9206)
static void C_fcall trf_9206(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9206(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_9206(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_9197)
static void C_fcall trf_9197(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9197(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9197(t0,t1);}

C_noret_decl(trf_9164)
static void C_fcall trf_9164(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9164(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_9164(t0,t1,t2,t3);}

C_noret_decl(trf_9022)
static void C_fcall trf_9022(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9022(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9022(t0,t1);}

C_noret_decl(trf_8993)
static void C_fcall trf_8993(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8993(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8993(t0,t1);}

C_noret_decl(trf_8967)
static void C_fcall trf_8967(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8967(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8967(t0,t1);}

C_noret_decl(trf_8409)
static void C_fcall trf_8409(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8409(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8409(t0,t1);}

C_noret_decl(trf_8824)
static void C_fcall trf_8824(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8824(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_8824(t0,t1,t2,t3,t4);}

C_noret_decl(trf_8875)
static void C_fcall trf_8875(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8875(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8875(t0,t1);}

C_noret_decl(trf_8837)
static void C_fcall trf_8837(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8837(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8837(t0,t1);}

C_noret_decl(trf_8531)
static void C_fcall trf_8531(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8531(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8531(t0,t1);}

C_noret_decl(trf_8662)
static void C_fcall trf_8662(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8662(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_8662(t0,t1,t2,t3,t4);}

C_noret_decl(trf_8713)
static void C_fcall trf_8713(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8713(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8713(t0,t1);}

C_noret_decl(trf_8675)
static void C_fcall trf_8675(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8675(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8675(t0,t1);}

C_noret_decl(trf_8537)
static void C_fcall trf_8537(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8537(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8537(t0,t1);}

C_noret_decl(trf_8573)
static void C_fcall trf_8573(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8573(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_8573(t0,t1,t2,t3,t4);}

C_noret_decl(trf_8589)
static void C_fcall trf_8589(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8589(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8589(t0,t1);}

C_noret_decl(trf_8421)
static void C_fcall trf_8421(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8421(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8421(t0,t1);}

C_noret_decl(trf_8445)
static void C_fcall trf_8445(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8445(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_8445(t0,t1,t2,t3,t4);}

C_noret_decl(trf_8461)
static void C_fcall trf_8461(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8461(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8461(t0,t1);}

C_noret_decl(trf_8366)
static void C_fcall trf_8366(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8366(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8366(t0,t1);}

C_noret_decl(trf_7807)
static void C_fcall trf_7807(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7807(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7807(t0,t1);}

C_noret_decl(trf_8222)
static void C_fcall trf_8222(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8222(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_8222(t0,t1,t2,t3,t4);}

C_noret_decl(trf_8273)
static void C_fcall trf_8273(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8273(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8273(t0,t1);}

C_noret_decl(trf_8235)
static void C_fcall trf_8235(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8235(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8235(t0,t1);}

C_noret_decl(trf_7929)
static void C_fcall trf_7929(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7929(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7929(t0,t1);}

C_noret_decl(trf_8060)
static void C_fcall trf_8060(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8060(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_8060(t0,t1,t2,t3,t4);}

C_noret_decl(trf_8111)
static void C_fcall trf_8111(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8111(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8111(t0,t1);}

C_noret_decl(trf_8073)
static void C_fcall trf_8073(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8073(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8073(t0,t1);}

C_noret_decl(trf_7935)
static void C_fcall trf_7935(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7935(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7935(t0,t1);}

C_noret_decl(trf_7971)
static void C_fcall trf_7971(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7971(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_7971(t0,t1,t2,t3,t4);}

C_noret_decl(trf_7987)
static void C_fcall trf_7987(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7987(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7987(t0,t1);}

C_noret_decl(trf_7819)
static void C_fcall trf_7819(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7819(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7819(t0,t1);}

C_noret_decl(trf_7843)
static void C_fcall trf_7843(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7843(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_7843(t0,t1,t2,t3,t4);}

C_noret_decl(trf_7859)
static void C_fcall trf_7859(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7859(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7859(t0,t1);}

C_noret_decl(trf_7709)
static void C_fcall trf_7709(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7709(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7709(t0,t1);}

C_noret_decl(trf_7721)
static void C_fcall trf_7721(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7721(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_7721(t0,t1,t2,t3,t4);}

C_noret_decl(trf_7737)
static void C_fcall trf_7737(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7737(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7737(t0,t1);}

C_noret_decl(trf_7662)
static void C_fcall trf_7662(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7662(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7662(t0,t1,t2,t3);}

C_noret_decl(trf_7637)
static void C_fcall trf_7637(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7637(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7637(t0,t1,t2,t3);}

C_noret_decl(trf_7628)
static void C_fcall trf_7628(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7628(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7628(t0,t1);}

C_noret_decl(trf_7556)
static void C_fcall trf_7556(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7556(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7556(t0,t1);}

C_noret_decl(trf_7526)
static void C_fcall trf_7526(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7526(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7526(t0,t1);}

C_noret_decl(trf_7500)
static void C_fcall trf_7500(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7500(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7500(t0,t1);}

C_noret_decl(trf_7429)
static void C_fcall trf_7429(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7429(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7429(t0,t1,t2);}

C_noret_decl(trf_1395)
static void C_fcall trf_1395(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1395(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1395(t0,t1);}

C_noret_decl(trf_1473)
static void C_fcall trf_1473(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1473(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1473(t0,t1,t2);}

C_noret_decl(trf_1503)
static void C_fcall trf_1503(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1503(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1503(t0,t1,t2);}

C_noret_decl(trf_2528)
static void C_fcall trf_2528(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2528(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2528(t0,t1,t2);}

C_noret_decl(trf_2350)
static void C_fcall trf_2350(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2350(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2350(t0,t1);}

C_noret_decl(trf_2389)
static void C_fcall trf_2389(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2389(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2389(t0,t1);}

C_noret_decl(trf_2313)
static void C_fcall trf_2313(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2313(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2313(t0,t1);}

C_noret_decl(trf_2268)
static void C_fcall trf_2268(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2268(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2268(t0,t1,t2,t3);}

C_noret_decl(trf_2107)
static void C_fcall trf_2107(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2107(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2107(t0,t1);}

C_noret_decl(trf_2032)
static void C_fcall trf_2032(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2032(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2032(t0,t1);}

C_noret_decl(trf_1985)
static void C_fcall trf_1985(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1985(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1985(t0,t1);}

C_noret_decl(trf_1921)
static void C_fcall trf_1921(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1921(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1921(t0,t1);}

C_noret_decl(trf_1874)
static void C_fcall trf_1874(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1874(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1874(t0,t1);}

C_noret_decl(trf_1827)
static void C_fcall trf_1827(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1827(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1827(t0,t1);}

C_noret_decl(trf_1780)
static void C_fcall trf_1780(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1780(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1780(t0,t1);}

C_noret_decl(trf_1720)
static void C_fcall trf_1720(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1720(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1720(t0,t1);}

C_noret_decl(trf_1666)
static void C_fcall trf_1666(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1666(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1666(t0,t1);}

C_noret_decl(trf_1629)
static void C_fcall trf_1629(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1629(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1629(t0,t1);}

C_noret_decl(trf_1586)
static void C_fcall trf_1586(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1586(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1586(t0,t1);}

C_noret_decl(trf_1538)
static void C_fcall trf_1538(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1538(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1538(t0,t1,t2,t3);}

C_noret_decl(trf_2568)
static void C_fcall trf_2568(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2568(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2568(t0,t1,t2);}

C_noret_decl(trf_3362)
static void C_fcall trf_3362(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3362(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_3362(t0,t1,t2,t3,t4);}

C_noret_decl(trf_3269)
static void C_fcall trf_3269(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3269(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_3269(t0,t1,t2,t3,t4);}

C_noret_decl(trf_3287)
static void C_fcall trf_3287(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3287(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3287(t0,t1);}

C_noret_decl(trf_3271)
static void C_fcall trf_3271(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3271(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3271(t0,t1);}

C_noret_decl(trf_2572)
static void C_fcall trf_2572(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2572(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_2572(t0,t1,t2,t3,t4);}

C_noret_decl(trf_2610)
static void C_fcall trf_2610(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2610(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2610(t0,t1);}

C_noret_decl(trf_2619)
static void C_fcall trf_2619(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2619(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2619(t0,t1);}

C_noret_decl(trf_2711)
static void C_fcall trf_2711(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2711(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2711(t0,t1);}

C_noret_decl(trf_2788)
static void C_fcall trf_2788(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2788(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2788(t0,t1);}

C_noret_decl(trf_2811)
static void C_fcall trf_2811(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2811(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2811(t0,t1);}

C_noret_decl(trf_2900)
static void C_fcall trf_2900(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2900(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2900(t0,t1);}

C_noret_decl(trf_3013)
static void C_fcall trf_3013(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3013(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3013(t0,t1);}

C_noret_decl(trf_3044)
static void C_fcall trf_3044(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3044(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3044(t0,t1);}

C_noret_decl(trf_3074)
static void C_fcall trf_3074(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3074(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3074(t0,t1);}

C_noret_decl(trf_2844)
static void C_fcall trf_2844(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2844(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2844(t0,t1,t2,t3);}

C_noret_decl(trf_2720)
static void C_fcall trf_2720(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2720(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2720(t0,t1);}

C_noret_decl(trf_2657)
static void C_fcall trf_2657(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2657(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2657(t0,t1);}

C_noret_decl(trf_3401)
static void C_fcall trf_3401(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3401(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3401(t0,t1,t2,t3);}

C_noret_decl(trf_3425)
static void C_fcall trf_3425(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3425(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3425(t0,t1,t2);}

C_noret_decl(trf_3464)
static void C_fcall trf_3464(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3464(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3464(t0,t1);}

C_noret_decl(trf_3724)
static void C_fcall trf_3724(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3724(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_3724(t0,t1,t2,t3,t4);}

C_noret_decl(trf_3473)
static void C_fcall trf_3473(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3473(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3473(t0,t1,t2);}

C_noret_decl(trf_3778)
static void C_fcall trf_3778(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3778(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3778(t0,t1);}

C_noret_decl(trf_3513)
static void C_fcall trf_3513(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3513(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3513(t0,t1,t2);}

C_noret_decl(trf_3848)
static void C_fcall trf_3848(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3848(void *dummy){
C_word t7=C_pick(0);
C_word t6=C_pick(1);
C_word t5=C_pick(2);
C_word t4=C_pick(3);
C_word t3=C_pick(4);
C_word t2=C_pick(5);
C_word t1=C_pick(6);
C_word t0=C_pick(7);
C_adjust_stack(-8);
f_3848(t0,t1,t2,t3,t4,t5,t6,t7);}

C_noret_decl(trf_3975)
static void C_fcall trf_3975(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3975(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_3975(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_4086)
static void C_fcall trf_4086(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4086(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4086(t0,t1);}

C_noret_decl(trf_4099)
static void C_fcall trf_4099(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4099(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4099(t0,t1);}

C_noret_decl(trf_4115)
static void C_fcall trf_4115(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4115(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4115(t0,t1);}

C_noret_decl(trf_4136)
static void C_fcall trf_4136(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4136(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4136(t0,t1);}

C_noret_decl(trf_4178)
static void C_fcall trf_4178(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4178(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4178(t0,t1);}

C_noret_decl(trf_4221)
static void C_fcall trf_4221(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4221(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4221(t0,t1);}

C_noret_decl(trf_4234)
static void C_fcall trf_4234(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4234(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4234(t0,t1);}

C_noret_decl(trf_4296)
static void C_fcall trf_4296(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4296(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4296(t0,t1);}

C_noret_decl(trf_4321)
static void C_fcall trf_4321(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4321(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4321(t0,t1);}

C_noret_decl(trf_4937)
static void C_fcall trf_4937(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4937(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4937(t0,t1,t2);}

C_noret_decl(trf_4727)
static void C_fcall trf_4727(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4727(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4727(t0,t1,t2);}

C_noret_decl(trf_4469)
static void C_fcall trf_4469(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4469(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4469(t0,t1);}

C_noret_decl(trf_4403)
static void C_fcall trf_4403(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4403(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4403(t0,t1);}

C_noret_decl(trf_4385)
static void C_fcall trf_4385(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4385(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4385(t0,t1);}

C_noret_decl(trf_4255)
static void C_fcall trf_4255(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4255(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4255(t0,t1,t2);}

C_noret_decl(trf_4187)
static void C_fcall trf_4187(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4187(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4187(t0,t1,t2,t3);}

C_noret_decl(trf_4145)
static void C_fcall trf_4145(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4145(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4145(t0,t1,t2,t3);}

C_noret_decl(trf_1327)
static void C_fcall trf_1327(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1327(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1327(t0,t1);}

C_noret_decl(trf_5121)
static void C_fcall trf_5121(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5121(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_5121(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_5259)
static void C_fcall trf_5259(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5259(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5259(t0,t1);}

C_noret_decl(trf_5146)
static void C_fcall trf_5146(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5146(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5146(t0,t1);}

C_noret_decl(trf_5152)
static void C_fcall trf_5152(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5152(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5152(t0,t1);}

C_noret_decl(trf_5303)
static void C_fcall trf_5303(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5303(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_5303(t0,t1,t2,t3,t4);}

C_noret_decl(trf_5328)
static void C_fcall trf_5328(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5328(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5328(t0,t1);}

C_noret_decl(trf_5386)
static void C_fcall trf_5386(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5386(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5386(t0,t1);}

C_noret_decl(trf_6197)
static void C_fcall trf_6197(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6197(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6197(t0,t1,t2,t3);}

C_noret_decl(trf_6209)
static void C_fcall trf_6209(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6209(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6209(t0,t1,t2);}

C_noret_decl(trf_6276)
static void C_fcall trf_6276(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6276(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6276(t0,t1);}

C_noret_decl(trf_6328)
static void C_fcall trf_6328(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6328(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6328(t0,t1,t2,t3);}

C_noret_decl(trf_6338)
static void C_fcall trf_6338(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6338(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6338(t0,t1);}

C_noret_decl(trf_6545)
static void C_fcall trf_6545(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6545(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6545(t0,t1,t2);}

C_noret_decl(trf_6558)
static void C_fcall trf_6558(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6558(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6558(t0,t1);}

C_noret_decl(trf_6479)
static void C_fcall trf_6479(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6479(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6479(t0,t1,t2);}

C_noret_decl(trf_6492)
static void C_fcall trf_6492(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6492(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6492(t0,t1);}

C_noret_decl(trf_6361)
static void C_fcall trf_6361(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6361(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6361(t0,t1,t2);}

C_noret_decl(trf_6374)
static void C_fcall trf_6374(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6374(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6374(t0,t1);}

C_noret_decl(trf_6386)
static void C_fcall trf_6386(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6386(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6386(t0,t1);}

C_noret_decl(trf_6638)
static void C_fcall trf_6638(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6638(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6638(t0,t1);}

C_noret_decl(trf_6678)
static void C_fcall trf_6678(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6678(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6678(t0,t1);}

C_noret_decl(trf_6734)
static void C_fcall trf_6734(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6734(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6734(t0,t1,t2);}

C_noret_decl(trf_6738)
static void C_fcall trf_6738(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6738(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6738(t0,t1);}

C_noret_decl(trf_6767)
static void C_fcall trf_6767(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6767(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6767(t0,t1,t2);}

C_noret_decl(trf_6771)
static void C_fcall trf_6771(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6771(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6771(t0,t1);}

C_noret_decl(trf_6801)
static void C_fcall trf_6801(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6801(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6801(t0,t1,t2,t3);}

C_noret_decl(trf_6995)
static void C_fcall trf_6995(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6995(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6995(t0,t1);}

C_noret_decl(trf_6803)
static void C_fcall trf_6803(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6803(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6803(t0,t1,t2);}

C_noret_decl(trf_7106)
static void C_fcall trf_7106(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7106(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7106(t0,t1,t2,t3);}

C_noret_decl(trf_7275)
static void C_fcall trf_7275(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7275(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7275(t0,t1);}

C_noret_decl(trf_7371)
static void C_fcall trf_7371(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7371(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7371(t0,t1);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr2rv)
static void C_fcall tr2rv(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2rv(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n+1);
t2=C_restore_rest_vector(a,n);
(k)(t0,t1,t2);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_match_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_match_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("match_toplevel"));
C_check_nursery_minimum(9);
if(!C_demand(9)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(3329)){
C_save(t1);
C_rereclaim2(3329*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(9);
C_initialize_lf(lf,150);
lf[0]=C_h_intern(&lf[0],11,"\005matchevery");
lf[1]=C_h_intern(&lf[1],16,"\005matchsyntax-err");
lf[2]=C_h_intern(&lf[2],15,"\003syssignal-hook");
lf[3]=C_h_intern(&lf[3],13,"\000syntax-error");
lf[4]=C_h_intern(&lf[4],15,"\005matchset-error");
lf[5]=C_h_intern(&lf[5],15,"\003sysmatch-error");
lf[6]=C_h_intern(&lf[6],19,"\005matcherror-control");
lf[7]=C_h_intern(&lf[7],6,"\000error");
lf[8]=C_h_intern(&lf[8],23,"\005matchset-error-control");
lf[9]=C_h_intern(&lf[9],4,"null");
lf[10]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005pair\077\376\003\000\000\002\376\001\000\000\007symbol\077\376\003\000\000\002\376\001\000\000\010boolean\077\376\003\000\000\002\376\001\000\000\007number\077\376\003\000\000\002\376\001\000\000\007str"
"ing\077\376\003\000\000\002\376\001\000\000\005char\077\376\003\000\000\002\376\001\000\000\012procedure\077\376\003\000\000\002\376\001\000\000\007vector\077\376\377\016");
lf[11]=C_h_intern(&lf[11],25,"\005matchdisjoint-predicates");
lf[12]=C_h_intern(&lf[12],14,"string->symbol");
lf[13]=C_h_intern(&lf[13],13,"string-append");
lf[14]=C_h_intern(&lf[14],14,"symbol->string");
lf[15]=C_h_intern(&lf[15],7,"\003sysmap");
lf[16]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\004caar\376\003\000\000\002\376\001\000\000\003car\376\001\000\000\003car\376\003\000\000\002\376\003\000\000\002\376\001\000\000\004cadr\376\003\000\000\002\376\001\000\000\003cdr\376\001\000\000\003car"
"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\004cdar\376\003\000\000\002\376\001\000\000\003car\376\001\000\000\003cdr\376\003\000\000\002\376\003\000\000\002\376\001\000\000\004cddr\376\003\000\000\002\376\001\000\000\003cdr\376\001\000\000\003cdr"
"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\005caaar\376\003\000\000\002\376\001\000\000\004caar\376\001\000\000\003car\376\003\000\000\002\376\003\000\000\002\376\001\000\000\005caadr\376\003\000\000\002\376\001\000\000\004cadr\376\001\000\000"
"\003car\376\003\000\000\002\376\003\000\000\002\376\001\000\000\005cadar\376\003\000\000\002\376\001\000\000\004cdar\376\001\000\000\003car\376\003\000\000\002\376\003\000\000\002\376\001\000\000\005caddr\376\003\000\000\002\376\001\000\000\004cddr"
"\376\001\000\000\003car\376\003\000\000\002\376\003\000\000\002\376\001\000\000\005cdaar\376\003\000\000\002\376\001\000\000\004caar\376\001\000\000\003cdr\376\003\000\000\002\376\003\000\000\002\376\001\000\000\005cdadr\376\003\000\000\002\376\001\000\000\004"
"cadr\376\001\000\000\003cdr\376\003\000\000\002\376\003\000\000\002\376\001\000\000\005cddar\376\003\000\000\002\376\001\000\000\004cdar\376\001\000\000\003cdr\376\003\000\000\002\376\003\000\000\002\376\001\000\000\005cdddr\376\003\000\000\002\376"
"\001\000\000\004cddr\376\001\000\000\003cdr\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006caaaar\376\003\000\000\002\376\001\000\000\005caaar\376\001\000\000\003car\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006caaad"
"r\376\003\000\000\002\376\001\000\000\005caadr\376\001\000\000\003car\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006caadar\376\003\000\000\002\376\001\000\000\005cadar\376\001\000\000\003car\376\003\000\000\002\376\003\000\000\002\376\001"
"\000\000\006caaddr\376\003\000\000\002\376\001\000\000\005caddr\376\001\000\000\003car\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006cadaar\376\003\000\000\002\376\001\000\000\005cdaar\376\001\000\000\003car\376\003\000\000"
"\002\376\003\000\000\002\376\001\000\000\006cadadr\376\003\000\000\002\376\001\000\000\005cdadr\376\001\000\000\003car\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006caddar\376\003\000\000\002\376\001\000\000\005cddar\376\001\000\000"
"\003car\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006cadddr\376\003\000\000\002\376\001\000\000\005cdddr\376\001\000\000\003car\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006cdaaar\376\003\000\000\002\376\001\000\000\005c"
"aaar\376\001\000\000\003cdr\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006cdaadr\376\003\000\000\002\376\001\000\000\005caadr\376\001\000\000\003cdr\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006cdadar\376\003\000"
"\000\002\376\001\000\000\005cadar\376\001\000\000\003cdr\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006cdaddr\376\003\000\000\002\376\001\000\000\005caddr\376\001\000\000\003cdr\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006c"
"ddaar\376\003\000\000\002\376\001\000\000\005cdaar\376\001\000\000\003cdr\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006cddadr\376\003\000\000\002\376\001\000\000\005cdadr\376\001\000\000\003cdr\376\003\000\000\002\376\003\000"
"\000\002\376\001\000\000\006cdddar\376\003\000\000\002\376\001\000\000\005cddar\376\001\000\000\003cdr\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006cddddr\376\003\000\000\002\376\001\000\000\005cdddr\376\001\000\000\003cdr"
"\376\377\016");
lf[17]=C_h_intern(&lf[17],10,"vector-ref");
lf[18]=C_h_intern(&lf[18],1,"x");
lf[19]=C_h_intern(&lf[19],6,"lambda");
lf[20]=C_h_intern(&lf[20],3,"let");
lf[21]=C_h_intern(&lf[21],5,"unbox");
lf[22]=C_h_intern(&lf[22],3,"car");
lf[23]=C_h_intern(&lf[23],3,"cdr");
lf[24]=C_h_intern(&lf[24],13,"\003sysblock-ref");
lf[25]=C_decode_literal(C_heaptop,"\376B\000\000\025unnested get! pattern");
lf[26]=C_h_intern(&lf[26],4,"set-");
lf[27]=C_h_intern(&lf[27],1,"!");
lf[28]=C_h_intern(&lf[28],1,"y");
lf[29]=C_h_intern(&lf[29],11,"vector-set!");
lf[30]=C_h_intern(&lf[30],8,"set-box!");
lf[31]=C_h_intern(&lf[31],8,"set-car!");
lf[32]=C_h_intern(&lf[32],8,"set-cdr!");
lf[33]=C_h_intern(&lf[33],14,"\003sysblock-set!");
lf[34]=C_decode_literal(C_heaptop,"\376B\000\000\025unnested set! pattern");
lf[35]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\003car\376\003\000\000\002\376\001\000\000\004caar\376\001\000\000\004cdar\376\003\000\000\002\376\003\000\000\002\376\001\000\000\003cdr\376\003\000\000\002\376\001\000\000\004cadr\376\001\000\000\004cd"
"dr\376\003\000\000\002\376\003\000\000\002\376\001\000\000\004caar\376\003\000\000\002\376\001\000\000\005caaar\376\001\000\000\005cdaar\376\003\000\000\002\376\003\000\000\002\376\001\000\000\004cadr\376\003\000\000\002\376\001\000\000\005caadr"
"\376\001\000\000\005cdadr\376\003\000\000\002\376\003\000\000\002\376\001\000\000\004cdar\376\003\000\000\002\376\001\000\000\005cadar\376\001\000\000\005cddar\376\003\000\000\002\376\003\000\000\002\376\001\000\000\004cddr\376\003\000\000\002\376\001"
"\000\000\005caddr\376\001\000\000\005cdddr\376\003\000\000\002\376\003\000\000\002\376\001\000\000\005caaar\376\003\000\000\002\376\001\000\000\006caaaar\376\001\000\000\006cdaaar\376\003\000\000\002\376\003\000\000\002\376\001\000\000\005"
"caadr\376\003\000\000\002\376\001\000\000\006caaadr\376\001\000\000\006cdaadr\376\003\000\000\002\376\003\000\000\002\376\001\000\000\005cadar\376\003\000\000\002\376\001\000\000\006caadar\376\001\000\000\006cdadar\376"
"\003\000\000\002\376\003\000\000\002\376\001\000\000\005caddr\376\003\000\000\002\376\001\000\000\006caaddr\376\001\000\000\006cdaddr\376\003\000\000\002\376\003\000\000\002\376\001\000\000\005cdaar\376\003\000\000\002\376\001\000\000\006cada"
"ar\376\001\000\000\006cddaar\376\003\000\000\002\376\003\000\000\002\376\001\000\000\005cdadr\376\003\000\000\002\376\001\000\000\006cadadr\376\001\000\000\006cddadr\376\003\000\000\002\376\003\000\000\002\376\001\000\000\005cddar"
"\376\003\000\000\002\376\001\000\000\006caddar\376\001\000\000\006cdddar\376\003\000\000\002\376\003\000\000\002\376\001\000\000\005cdddr\376\003\000\000\002\376\001\000\000\006cadddr\376\001\000\000\006cddddr\376\377\016");
lf[36]=C_h_intern(&lf[36],6,"equal\077");
lf[37]=C_h_intern(&lf[37],7,"string\077");
lf[38]=C_h_intern(&lf[38],8,"boolean\077");
lf[39]=C_h_intern(&lf[39],5,"char\077");
lf[40]=C_h_intern(&lf[40],7,"number\077");
lf[41]=C_h_intern(&lf[41],7,"symbol\077");
lf[42]=C_h_intern(&lf[42],5,"quote");
lf[43]=C_h_intern(&lf[43],3,"not");
lf[44]=C_h_intern(&lf[44],5,"list\077");
lf[45]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005list\077\376\003\000\000\002\376\001\000\000\005pair\077\376\003\000\000\002\376\001\000\000\005null\077\376\377\016");
lf[46]=C_h_intern(&lf[46],5,"null\077");
lf[47]=C_h_intern(&lf[47],5,"pair\077");
lf[48]=C_h_intern(&lf[48],4,"cond");
lf[49]=C_h_intern(&lf[49],2,"if");
lf[50]=C_h_intern(&lf[50],3,"and");
lf[51]=C_h_intern(&lf[51],30,"call-with-current-continuation");
lf[52]=C_h_intern(&lf[52],6,"caddar");
lf[53]=C_h_intern(&lf[53],6,"cddadr");
lf[54]=C_h_intern(&lf[54],6,"caadar");
lf[55]=C_h_intern(&lf[55],6,"cadadr");
lf[56]=C_h_intern(&lf[56],5,"cadar");
lf[57]=C_h_intern(&lf[57],6,"cdddar");
lf[58]=C_h_intern(&lf[58],5,"cddar");
lf[59]=C_h_intern(&lf[59],6,"cdadar");
lf[60]=C_h_intern(&lf[60],4,"cdar");
lf[61]=C_h_intern(&lf[61],5,"cdadr");
lf[62]=C_h_intern(&lf[62],5,"caadr");
lf[63]=C_h_intern(&lf[63],4,"caar");
lf[64]=C_h_intern(&lf[64],12,"\000unspecified");
lf[65]=C_h_intern(&lf[65],5,"\000fail");
lf[66]=C_h_intern(&lf[66],6,"append");
lf[67]=C_h_intern(&lf[67],3,"...");
lf[68]=C_h_intern(&lf[68],3,"___");
lf[69]=C_h_intern(&lf[69],9,"substring");
lf[70]=C_h_intern(&lf[70],13,"char-numeric\077");
lf[71]=C_h_intern(&lf[71],16,"\003sysstring->list");
lf[72]=C_h_intern(&lf[72],1,"_");
lf[73]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005quote\376\003\000\000\002\376\377\016\376\377\016");
lf[74]=C_h_intern(&lf[74],1,"\077");
lf[75]=C_h_intern(&lf[75],3,"map");
lf[76]=C_h_intern(&lf[76],4,"cons");
lf[77]=C_h_intern(&lf[77],7,"reverse");
lf[78]=C_h_intern(&lf[78],7,"vector\077");
lf[79]=C_h_intern(&lf[79],13,"vector-length");
lf[80]=C_h_intern(&lf[80],2,">=");
lf[81]=C_h_intern(&lf[81],1,"-");
lf[82]=C_h_intern(&lf[82],1,">");
lf[83]=C_h_intern(&lf[83],9,"\003syserror");
lf[84]=C_decode_literal(C_heaptop,"\376B\000\000\022THIS NEVER HAPPENS");
lf[85]=C_h_intern(&lf[85],7,"newline");
lf[86]=C_h_intern(&lf[86],7,"display");
lf[87]=C_decode_literal(C_heaptop,"\376B\000\000\036FATAL ERROR IN PATTERN MATCHER");
lf[88]=C_h_intern(&lf[88],4,"get!");
lf[89]=C_h_intern(&lf[89],4,"set!");
lf[90]=C_h_intern(&lf[90],1,"$");
lf[91]=C_h_intern(&lf[91],2,"or");
lf[92]=C_h_intern(&lf[92],1,"=");
lf[93]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006lambda\376\003\000\000\002\376\001\000\000\005quote\376\003\000\000\002\376\001\000\000\014match-lambda\376\003\000\000\002\376\001\000\000\015match-lambda*\376\377\016");
lf[94]=C_decode_literal(C_heaptop,"\376B\000\000\035duplicate variable in pattern");
lf[95]=C_h_intern(&lf[95],6,"gensym");
lf[96]=C_decode_literal(C_heaptop,"\376B\000\000!variables of or-pattern differ in");
lf[97]=C_decode_literal(C_heaptop,"\376B\000\000\027no variables allowed in");
lf[98]=C_h_intern(&lf[98],12,"list->vector");
lf[99]=C_h_intern(&lf[99],12,"vector->list");
lf[100]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\012quasiquote\376\003\000\000\002\376\001\000\000\005quote\376\003\000\000\002\376\001\000\000\007unquote\376\003\000\000\002\376\001\000\000\020unquote-splicing\376\003"
"\000\000\002\376\001\000\000\001\077\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001$\376\003\000\000\002\376\001\000\000\001=\376\003\000\000\002\376\001\000\000\003and\376\003\000\000\002\376\001\000\000\002or\376\003\000\000\002\376\001\000\000\003not"
"\376\003\000\000\002\376\001\000\000\004set!\376\003\000\000\002\376\001\000\000\004get!\376\003\000\000\002\376\001\000\000\003...\376\003\000\000\002\376\001\000\000\003___\376\377\016");
lf[101]=C_h_intern(&lf[101],10,"quasiquote");
lf[102]=C_h_intern(&lf[102],7,"unquote");
lf[103]=C_h_intern(&lf[103],16,"unquote-splicing");
lf[104]=C_h_intern(&lf[104],6,"vector");
lf[105]=C_decode_literal(C_heaptop,"\376B\000\000\027syntax error in pattern");
lf[106]=C_decode_literal(C_heaptop,"\376B\000\000\027syntax error in pattern");
lf[107]=C_decode_literal(C_heaptop,"\376B\000\000*invalid use of unquote-splicing in pattern");
lf[108]=C_h_intern(&lf[108],8,"\003syswarn");
lf[109]=C_decode_literal(C_heaptop,"\376B\000\000\035Warning: unreachable pattern ");
lf[110]=C_h_intern(&lf[110],2,"in");
lf[111]=C_h_intern(&lf[111],12,"\003sysfor-each");
lf[112]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010\003sysvoid\376\377\016");
lf[113]=C_h_intern(&lf[113],6,"\000match");
lf[114]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\013unspecified\376\003\000\000\002\376\001\000\000\005error\376\003\000\000\002\376\001\000\000\004fail\376\003\000\000\002\376\001\000\000\005match\376\377\016");
lf[115]=C_decode_literal(C_heaptop,"\376B\000\0009invalid value for ##match#error-control, legal values are");
lf[116]=C_h_intern(&lf[116],1,"n");
lf[117]=C_h_intern(&lf[117],1,"l");
lf[118]=C_h_intern(&lf[118],6,"length");
lf[119]=C_h_intern(&lf[119],2,"=>");
lf[120]=C_h_intern(&lf[120],6,"letrec");
lf[121]=C_h_intern(&lf[121],10,"\003sysappend");
lf[122]=C_h_intern(&lf[122],5,"begin");
lf[123]=C_h_intern(&lf[123],8,"\003sysvoid");
lf[124]=C_h_intern(&lf[124],6,"define");
lf[125]=C_h_intern(&lf[125],15,"\005matchexpanders");
lf[126]=C_h_intern(&lf[126],19,"match-error-control");
lf[127]=C_h_intern(&lf[127],21,"match-error-procedure");
lf[128]=C_h_intern(&lf[128],17,"register-feature!");
lf[129]=C_h_intern(&lf[129],5,"match");
lf[130]=C_h_intern(&lf[130],12,"match-define");
lf[131]=C_decode_literal(C_heaptop,"\376B\000\000\017syntax error in");
lf[132]=C_h_intern(&lf[132],20,"\003sysregister-macro-2");
lf[133]=C_h_intern(&lf[133],12,"match-letrec");
lf[134]=C_decode_literal(C_heaptop,"\376B\000\000\017syntax error in");
lf[135]=C_h_intern(&lf[135],6,"cadaar");
lf[136]=C_h_intern(&lf[136],5,"caaar");
lf[137]=C_h_intern(&lf[137],6,"cddaar");
lf[138]=C_h_intern(&lf[138],5,"cdaar");
lf[139]=C_h_intern(&lf[139],10,"match-let*");
lf[140]=C_decode_literal(C_heaptop,"\376B\000\000\017syntax error in");
lf[141]=C_h_intern(&lf[141],4,"let*");
lf[142]=C_h_intern(&lf[142],4,"list");
lf[143]=C_h_intern(&lf[143],9,"match-let");
lf[144]=C_decode_literal(C_heaptop,"\376B\000\000\017syntax error in");
lf[145]=C_h_intern(&lf[145],13,"match-lambda*");
lf[146]=C_decode_literal(C_heaptop,"\376B\000\000\017syntax error in");
lf[147]=C_h_intern(&lf[147],12,"match-lambda");
lf[148]=C_decode_literal(C_heaptop,"\376B\000\000\017syntax error in");
lf[149]=C_decode_literal(C_heaptop,"\376B\000\000\017syntax error in");
C_register_lf2(lf,150,create_ptable());
t2=C_mutate((C_word*)lf[0]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_690,a[2]=((C_word)li0),tmp=(C_word)a,a+=3,tmp));
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_717,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10831,a[2]=((C_word)li155),tmp=(C_word)a,a+=3,tmp);
/* match.scm: 144  ##sys#register-macro-2 */
t5=*((C_word*)lf[132]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,lf[129],t4);}

/* a10830 */
static void C_ccall f_10831(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10831,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10838,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_listp(t2))){
t4=(C_word)C_i_length(t2);
if(C_truep((C_word)C_i_less_or_equalp(C_fix(1),t4))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10912,a[2]=((C_word)li154),tmp=(C_word)a,a+=3,tmp);
t6=(C_word)C_i_cdr(t2);
/* match.scm: 149  ##match#every */
t7=*((C_word*)lf[0]+1);
((C_proc4)C_retrieve_proc(t7))(4,t7,t3,t5,t6);}
else{
t5=t3;
f_10838(2,t5,C_SCHEME_FALSE);}}
else{
t4=t3;
f_10838(2,t4,C_SCHEME_FALSE);}}

/* a10911 in a10830 */
static void C_ccall f_10912(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10912,3,t0,t1,t2);}
if(C_truep((C_word)C_i_listp(t2))){
t3=(C_word)C_i_length(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_less_or_equalp(C_fix(2),t3));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k10836 in a10830 */
static void C_ccall f_10838(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10838,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10847,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_symbolp(t2))){
t5=t4;
f_10847(2,t5,t2);}
else{
/* match.scm: 153  gensym */
t5=*((C_word*)lf[95]+1);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}}
else{
t2=(C_word)C_a_i_cons(&a,2,lf[129],((C_word*)t0)[3]);
/* match.scm: 164  ##match#syntax-err */
t3=*((C_word*)lf[1]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[2],t2,lf[149]);}}

/* k10845 in k10836 in a10830 */
static void C_ccall f_10847(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10847,2,t0,t1);}
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[5]))){
t2=(C_word)C_a_i_cons(&a,2,lf[129],((C_word*)t0)[4]);
t3=(C_word)C_i_car(*((C_word*)lf[125]+1));
t4=t3;
((C_proc5)C_retrieve_proc(t4))(5,t4,((C_word*)t0)[3],t1,((C_word*)t0)[2],t2);}
else{
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[5]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10874,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_a_i_cons(&a,2,lf[129],((C_word*)t0)[4]);
t6=(C_word)C_i_car(*((C_word*)lf[125]+1));
t7=t6;
((C_proc5)C_retrieve_proc(t7))(5,t7,t4,t1,((C_word*)t0)[2],t5);}}

/* k10872 in k10845 in k10836 in a10830 */
static void C_ccall f_10874(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10874,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[20],((C_word*)t0)[2],t1));}

/* k715 */
static void C_ccall f_717(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_717,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_720,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10765,a[2]=((C_word)li153),tmp=(C_word)a,a+=3,tmp);
/* match.scm: 165  ##sys#register-macro-2 */
t4=*((C_word*)lf[132]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[147],t3);}

/* a10764 in k715 */
static void C_ccall f_10765(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10765,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10772,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_listp(t2))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10805,a[2]=((C_word)li152),tmp=(C_word)a,a+=3,tmp);
/* match.scm: 168  ##match#every */
t5=*((C_word*)lf[0]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t4,t2);}
else{
t4=t3;
f_10772(2,t4,C_SCHEME_FALSE);}}

/* a10804 in a10764 in k715 */
static void C_ccall f_10805(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10805,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10812,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_cdr(t2);
t5=t3;
f_10812(t5,(C_word)C_i_listp(t4));}
else{
t4=t3;
f_10812(t4,C_SCHEME_FALSE);}}

/* k10810 in a10804 in a10764 in k715 */
static void C_fcall f_10812(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_pairp(t2));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k10770 in a10764 in k715 */
static void C_ccall f_10772(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10772,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10775,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* match.scm: 175  gensym */
t3=*((C_word*)lf[95]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}
else{
t2=(C_word)C_a_i_cons(&a,2,lf[147],((C_word*)t0)[3]);
/* match.scm: 177  ##match#syntax-err */
t3=*((C_word*)lf[1]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[2],t2,lf[148]);}}

/* k10773 in k10770 in a10764 in k715 */
static void C_ccall f_10775(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10775,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[3]);
t4=(C_word)C_a_i_cons(&a,2,lf[129],t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,3,lf[19],t2,t4));}

/* k718 in k715 */
static void C_ccall f_720(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_720,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_723,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10703,a[2]=((C_word)li151),tmp=(C_word)a,a+=3,tmp);
/* match.scm: 180  ##sys#register-macro-2 */
t4=*((C_word*)lf[132]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[145],t3);}

/* a10702 in k718 in k715 */
static void C_ccall f_10703(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10703,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10710,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_listp(t2))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10739,a[2]=((C_word)li150),tmp=(C_word)a,a+=3,tmp);
/* match.scm: 183  ##match#every */
t5=*((C_word*)lf[0]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t4,t2);}
else{
t4=t3;
f_10710(2,t4,C_SCHEME_FALSE);}}

/* a10738 in a10702 in k718 in k715 */
static void C_ccall f_10739(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10739,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10746,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_cdr(t2);
t5=t3;
f_10746(t5,(C_word)C_i_listp(t4));}
else{
t4=t3;
f_10746(t4,C_SCHEME_FALSE);}}

/* k10744 in a10738 in a10702 in k718 in k715 */
static void C_fcall f_10746(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_pairp(t2));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k10708 in a10702 in k718 in k715 */
static void C_ccall f_10710(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10710,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10713,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* match.scm: 190  gensym */
t3=*((C_word*)lf[95]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}
else{
t2=(C_word)C_a_i_cons(&a,2,lf[145],((C_word*)t0)[3]);
/* match.scm: 192  ##match#syntax-err */
t3=*((C_word*)lf[1]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[2],t2,lf[146]);}}

/* k10711 in k10708 in a10702 in k718 in k715 */
static void C_ccall f_10713(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10713,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[3]);
t3=(C_word)C_a_i_cons(&a,2,lf[129],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[19],t1,t3));}

/* k721 in k718 in k715 */
static void C_ccall f_723(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_723,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_726,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9153,a[2]=((C_word)li149),tmp=(C_word)a,a+=3,tmp);
/* match.scm: 195  ##sys#register-macro-2 */
t4=*((C_word*)lf[132]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[143],t3);}

/* a9152 in k721 in k718 in k715 */
static void C_ccall f_9153(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[42],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9153,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9155,a[2]=((C_word)li133),tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9164,a[2]=((C_word)li135),tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9197,a[2]=t2,a[3]=((C_word)li136),tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9206,a[2]=((C_word)li137),tmp=(C_word)a,a+=3,tmp);
t7=(C_word)C_i_cadddr(*((C_word*)lf[125]+1));
if(C_truep((C_word)C_i_pairp(t2))){
t8=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_symbolp(t8))){
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9265,a[2]=t1,a[3]=t5,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t10=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_pairp(t10))){
t11=(C_word)C_i_cadr(t2);
t12=t9;
f_9265(t12,(C_word)C_i_listp(t11));}
else{
t11=t9;
f_9265(t11,C_SCHEME_FALSE);}}
else{
t9=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_listp(t9))){
t10=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9437,a[2]=t4,a[3]=t6,a[4]=t3,a[5]=t5,a[6]=t2,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10093,a[2]=t7,a[3]=((C_word)li144),tmp=(C_word)a,a+=4,tmp);
t12=(C_word)C_i_car(t2);
/* match.scm: 239  ##match#every */
t13=*((C_word*)lf[0]+1);
((C_proc4)C_retrieve_proc(t13))(4,t13,t10,t11,t12);}
else{
t10=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_pairp(t10))){
t11=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10143,a[2]=t4,a[3]=t6,a[4]=t5,a[5]=t3,a[6]=t1,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10683,a[2]=t2,a[3]=t11,tmp=(C_word)a,a+=4,tmp);
/* match.scm: 339  caar */
t13=*((C_word*)lf[63]+1);
((C_proc3)(void*)(*((C_word*)t13+1)))(3,t13,t12,t2);}
else{
/* match.scm: 417  g146 */
t11=t5;
f_9197(t11,t1);}}}}
else{
/* match.scm: 418  g146 */
t8=t5;
f_9197(t8,t1);}}

/* k10681 in a9152 in k721 in k718 in k715 */
static void C_ccall f_10683(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10683,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10679,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* match.scm: 340  cdaar */
t3=*((C_word*)lf[138]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_10143(t2,C_SCHEME_FALSE);}}

/* k10677 in k10681 in a9152 in k721 in k718 in k715 */
static void C_ccall f_10679(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10679,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10675,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* match.scm: 341  cddaar */
t3=*((C_word*)lf[137]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_10143(t2,C_SCHEME_FALSE);}}

/* k10673 in k10677 in k10681 in a9152 in k721 in k718 in k715 */
static void C_ccall f_10675(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_10143(t2,(C_word)C_i_nullp(t1));}

/* k10141 in a9152 in k721 in k718 in k715 */
static void C_fcall f_10143(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10143,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10549,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* match.scm: 342  cdar */
t3=*((C_word*)lf[60]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[7]);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[7]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10558,a[2]=t4,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[7],a[6]=((C_word)li148),tmp=(C_word)a,a+=7,tmp));
t6=((C_word*)t4)[1];
f_10558(t6,((C_word*)t0)[6],t2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}}

/* g149 in k10141 in a9152 in k721 in k718 in k715 */
static void C_fcall f_10558(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10558,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10571,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t6=(C_word)C_i_cdr(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_listp(t6))){
t7=(C_word)C_i_cdr(((C_word*)t0)[5]);
t8=t5;
f_10571(t8,(C_word)C_i_pairp(t7));}
else{
t7=t5;
f_10571(t7,C_SCHEME_FALSE);}}
else{
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10609,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t4,a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t6=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_pairp(t6))){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10655,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* match.scm: 411  cdar */
t8=*((C_word*)lf[60]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}
else{
t7=t5;
f_10609(t7,C_SCHEME_FALSE);}}}

/* k10653 in g149 in k10141 in a9152 in k721 in k718 in k715 */
static void C_ccall f_10655(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10655,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10651,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* match.scm: 412  cddar */
t3=*((C_word*)lf[58]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_10609(t2,C_SCHEME_FALSE);}}

/* k10649 in k10653 in g149 in k10141 in a9152 in k721 in k718 in k715 */
static void C_ccall f_10651(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_10609(t2,(C_word)C_i_nullp(t1));}

/* k10607 in g149 in k10141 in a9152 in k721 in k718 in k715 */
static void C_fcall f_10609(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10609,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10632,a[2]=((C_word*)t0)[7],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* match.scm: 414  cadar */
t4=*((C_word*)lf[56]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[7]);}
else{
/* match.scm: 416  g146 */
t2=((C_word*)t0)[2];
f_9197(t2,((C_word*)t0)[3]);}}

/* k10630 in k10607 in g149 in k10141 in a9152 in k721 in k718 in k715 */
static void C_ccall f_10632(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10632,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10628,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* match.scm: 415  caar */
t4=*((C_word*)lf[63]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k10626 in k10630 in k10607 in g149 in k10141 in a9152 in k721 in k718 in k715 */
static void C_ccall f_10628(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10628,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[6]);
/* match.scm: 413  g149 */
t3=((C_word*)((C_word*)t0)[5])[1];
f_10558(t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k10569 in g149 in k10141 in a9152 in k721 in k718 in k715 */
static void C_fcall f_10571(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10571,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10578,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* match.scm: 406  reverse */
t3=*((C_word*)lf[77]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}
else{
/* match.scm: 409  g146 */
t2=((C_word*)t0)[2];
f_9197(t2,((C_word*)t0)[5]);}}

/* k10576 in k10569 in g149 in k10141 in a9152 in k721 in k718 in k715 */
static void C_ccall f_10578(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10578,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10582,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* match.scm: 407  reverse */
t3=*((C_word*)lf[77]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k10580 in k10576 in k10569 in g149 in k10141 in a9152 in k721 in k718 in k715 */
static void C_ccall f_10582(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* match.scm: 406  g154 */
f_9164(((C_word*)t0)[3],((C_word*)t0)[2],t1,t2);}

/* k10547 in k10141 in a9152 in k721 in k718 in k715 */
static void C_ccall f_10549(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10549,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10155,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[7]);
if(C_truep((C_word)C_i_listp(t3))){
t4=(C_word)C_i_cdr(((C_word*)t0)[7]);
t5=t2;
f_10155(t5,(C_word)C_i_pairp(t4));}
else{
t4=t2;
f_10155(t4,C_SCHEME_FALSE);}}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10265,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10545,a[2]=((C_word*)t0)[7],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* match.scm: 359  cdar */
t4=*((C_word*)lf[60]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[7]);}}

/* k10543 in k10547 in k10141 in a9152 in k721 in k718 in k715 */
static void C_ccall f_10545(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10545,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10541,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* match.scm: 360  cadar */
t3=*((C_word*)lf[56]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_10265(t2,C_SCHEME_FALSE);}}

/* k10539 in k10543 in k10547 in k10141 in a9152 in k721 in k718 in k715 */
static void C_ccall f_10541(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10541,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10537,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* match.scm: 361  cdadar */
t3=*((C_word*)lf[59]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_10265(t2,C_SCHEME_FALSE);}}

/* k10535 in k10539 in k10543 in k10547 in k10141 in a9152 in k721 in k718 in k715 */
static void C_ccall f_10537(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10537,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10533,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* match.scm: 362  cdadar */
t3=*((C_word*)lf[59]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_10265(t2,C_SCHEME_FALSE);}}

/* k10531 in k10535 in k10539 in k10543 in k10547 in k10141 in a9152 in k721 in k718 in k715 */
static void C_ccall f_10533(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10533,2,t0,t1);}
t2=(C_word)C_i_cdr(t1);
if(C_truep((C_word)C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10525,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* match.scm: 363  cddar */
t4=*((C_word*)lf[58]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[3];
f_10265(t3,C_SCHEME_FALSE);}}

/* k10523 in k10531 in k10535 in k10539 in k10543 in k10547 in k10141 in a9152 in k721 in k718 in k715 */
static void C_ccall f_10525(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_10265(t2,(C_word)C_i_nullp(t1));}

/* k10263 in k10547 in k10141 in a9152 in k721 in k718 in k715 */
static void C_fcall f_10265(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10265,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10271,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[6]);
if(C_truep((C_word)C_i_listp(t3))){
t4=(C_word)C_i_cdr(((C_word*)t0)[6]);
t5=t2;
f_10271(t5,(C_word)C_i_pairp(t4));}
else{
t4=t2;
f_10271(t4,C_SCHEME_FALSE);}}
else{
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10396,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[6],a[6]=((C_word)li147),tmp=(C_word)a,a+=7,tmp));
t6=((C_word*)t4)[1];
f_10396(t6,((C_word*)t0)[4],t2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}}

/* g149 in k10263 in k10547 in k10141 in a9152 in k721 in k718 in k715 */
static void C_fcall f_10396(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10396,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10409,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t6=(C_word)C_i_cdr(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_listp(t6))){
t7=(C_word)C_i_cdr(((C_word*)t0)[5]);
t8=t5;
f_10409(t8,(C_word)C_i_pairp(t7));}
else{
t7=t5;
f_10409(t7,C_SCHEME_FALSE);}}
else{
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10447,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t4,a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t6=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_pairp(t6))){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10493,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* match.scm: 396  cdar */
t8=*((C_word*)lf[60]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}
else{
t7=t5;
f_10447(t7,C_SCHEME_FALSE);}}}

/* k10491 in g149 in k10263 in k10547 in k10141 in a9152 in k721 in k718 in k715 */
static void C_ccall f_10493(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10493,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10489,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* match.scm: 397  cddar */
t3=*((C_word*)lf[58]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_10447(t2,C_SCHEME_FALSE);}}

/* k10487 in k10491 in g149 in k10263 in k10547 in k10141 in a9152 in k721 in k718 in k715 */
static void C_ccall f_10489(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_10447(t2,(C_word)C_i_nullp(t1));}

/* k10445 in g149 in k10263 in k10547 in k10141 in a9152 in k721 in k718 in k715 */
static void C_fcall f_10447(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10447,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10470,a[2]=((C_word*)t0)[7],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* match.scm: 399  cadar */
t4=*((C_word*)lf[56]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[7]);}
else{
/* match.scm: 401  g146 */
t2=((C_word*)t0)[2];
f_9197(t2,((C_word*)t0)[3]);}}

/* k10468 in k10445 in g149 in k10263 in k10547 in k10141 in a9152 in k721 in k718 in k715 */
static void C_ccall f_10470(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10470,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10466,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* match.scm: 400  caar */
t4=*((C_word*)lf[63]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k10464 in k10468 in k10445 in g149 in k10263 in k10547 in k10141 in a9152 in k721 in k718 in k715 */
static void C_ccall f_10466(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10466,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[6]);
/* match.scm: 398  g149 */
t3=((C_word*)((C_word*)t0)[5])[1];
f_10396(t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k10407 in g149 in k10263 in k10547 in k10141 in a9152 in k721 in k718 in k715 */
static void C_fcall f_10409(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10409,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10416,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* match.scm: 391  reverse */
t3=*((C_word*)lf[77]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}
else{
/* match.scm: 394  g146 */
t2=((C_word*)t0)[2];
f_9197(t2,((C_word*)t0)[5]);}}

/* k10414 in k10407 in g149 in k10263 in k10547 in k10141 in a9152 in k721 in k718 in k715 */
static void C_ccall f_10416(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10416,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10420,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* match.scm: 392  reverse */
t3=*((C_word*)lf[77]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k10418 in k10414 in k10407 in g149 in k10263 in k10547 in k10141 in a9152 in k721 in k718 in k715 */
static void C_ccall f_10420(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* match.scm: 391  g154 */
f_9164(((C_word*)t0)[3],((C_word*)t0)[2],t1,t2);}

/* k10269 in k10263 in k10547 in k10141 in a9152 in k721 in k718 in k715 */
static void C_fcall f_10271(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10271,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10278,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* match.scm: 366  caaar */
t3=*((C_word*)lf[136]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10307,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=((C_word)li146),tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_10307(t6,((C_word*)t0)[3],t2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}}

/* g149 in k10269 in k10263 in k10547 in k10141 in a9152 in k721 in k718 in k715 */
static void C_fcall f_10307(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10307,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
/* match.scm: 375  g146 */
t5=((C_word*)t0)[3];
f_9197(t5,t1);}
else{
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10323,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t4,a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t6=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_pairp(t6))){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10369,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* match.scm: 377  cdar */
t8=*((C_word*)lf[60]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}
else{
t7=t5;
f_10323(t7,C_SCHEME_FALSE);}}}

/* k10367 in g149 in k10269 in k10263 in k10547 in k10141 in a9152 in k721 in k718 in k715 */
static void C_ccall f_10369(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10369,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10365,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* match.scm: 378  cddar */
t3=*((C_word*)lf[58]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_10323(t2,C_SCHEME_FALSE);}}

/* k10363 in k10367 in g149 in k10269 in k10263 in k10547 in k10141 in a9152 in k721 in k718 in k715 */
static void C_ccall f_10365(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_10323(t2,(C_word)C_i_nullp(t1));}

/* k10321 in g149 in k10269 in k10263 in k10547 in k10141 in a9152 in k721 in k718 in k715 */
static void C_fcall f_10323(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10323,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10346,a[2]=((C_word*)t0)[7],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* match.scm: 380  cadar */
t4=*((C_word*)lf[56]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[7]);}
else{
/* match.scm: 384  g146 */
t2=((C_word*)t0)[2];
f_9197(t2,((C_word*)t0)[3]);}}

/* k10344 in k10321 in g149 in k10269 in k10263 in k10547 in k10141 in a9152 in k721 in k718 in k715 */
static void C_ccall f_10346(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10346,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10342,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* match.scm: 382  caar */
t4=*((C_word*)lf[63]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k10340 in k10344 in k10321 in g149 in k10269 in k10263 in k10547 in k10141 in a9152 in k721 in k718 in k715 */
static void C_ccall f_10342(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10342,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[6]);
/* match.scm: 379  g149 */
t3=((C_word*)((C_word*)t0)[5])[1];
f_10307(t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k10276 in k10269 in k10263 in k10547 in k10141 in a9152 in k721 in k718 in k715 */
static void C_ccall f_10278(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10278,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10282,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* match.scm: 367  cadaar */
t3=*((C_word*)lf[135]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[4]);}

/* k10280 in k10276 in k10269 in k10263 in k10547 in k10141 in a9152 in k721 in k718 in k715 */
static void C_ccall f_10282(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10282,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10286,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* match.scm: 368  caadar */
t3=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}

/* k10284 in k10280 in k10276 in k10269 in k10263 in k10547 in k10141 in a9152 in k721 in k718 in k715 */
static void C_ccall f_10286(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10286,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10298,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* match.scm: 369  cdadar */
t3=*((C_word*)lf[59]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[6]);}

/* k10296 in k10284 in k10280 in k10276 in k10269 in k10263 in k10547 in k10141 in a9152 in k721 in k718 in k715 */
static void C_ccall f_10298(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_car(t1);
t3=(C_word)C_i_cdr(((C_word*)t0)[7]);
/* match.scm: 366  g145 */
f_9206(((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2,t3);}

/* k10153 in k10547 in k10141 in a9152 in k721 in k718 in k715 */
static void C_fcall f_10155(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10155,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10162,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* match.scm: 344  caaar */
t3=*((C_word*)lf[136]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10179,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=((C_word)li145),tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_10179(t6,((C_word*)t0)[4],t2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}}

/* g149 in k10153 in k10547 in k10141 in a9152 in k721 in k718 in k715 */
static void C_fcall f_10179(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10179,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
/* match.scm: 351  g146 */
t5=((C_word*)t0)[3];
f_9197(t5,t1);}
else{
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10195,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t4,a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t6=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_pairp(t6))){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10241,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* match.scm: 353  cdar */
t8=*((C_word*)lf[60]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}
else{
t7=t5;
f_10195(t7,C_SCHEME_FALSE);}}}

/* k10239 in g149 in k10153 in k10547 in k10141 in a9152 in k721 in k718 in k715 */
static void C_ccall f_10241(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10241,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10237,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* match.scm: 354  cddar */
t3=*((C_word*)lf[58]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_10195(t2,C_SCHEME_FALSE);}}

/* k10235 in k10239 in g149 in k10153 in k10547 in k10141 in a9152 in k721 in k718 in k715 */
static void C_ccall f_10237(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_10195(t2,(C_word)C_i_nullp(t1));}

/* k10193 in g149 in k10153 in k10547 in k10141 in a9152 in k721 in k718 in k715 */
static void C_fcall f_10195(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10195,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10218,a[2]=((C_word*)t0)[7],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* match.scm: 356  cadar */
t4=*((C_word*)lf[56]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[7]);}
else{
/* match.scm: 358  g146 */
t2=((C_word*)t0)[2];
f_9197(t2,((C_word*)t0)[3]);}}

/* k10216 in k10193 in g149 in k10153 in k10547 in k10141 in a9152 in k721 in k718 in k715 */
static void C_ccall f_10218(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10218,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10214,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* match.scm: 357  caar */
t4=*((C_word*)lf[63]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k10212 in k10216 in k10193 in g149 in k10153 in k10547 in k10141 in a9152 in k721 in k718 in k715 */
static void C_ccall f_10214(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10214,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[6]);
/* match.scm: 355  g149 */
t3=((C_word*)((C_word*)t0)[5])[1];
f_10179(t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k10160 in k10153 in k10547 in k10141 in a9152 in k721 in k718 in k715 */
static void C_ccall f_10162(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10162,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10166,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* match.scm: 345  cadaar */
t3=*((C_word*)lf[135]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[4]);}

/* k10164 in k10160 in k10153 in k10547 in k10141 in a9152 in k721 in k718 in k715 */
static void C_ccall f_10166(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10166,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* match.scm: 344  g158 */
t3=((C_word*)t0)[4];
((C_proc2)C_retrieve_proc(t3))(2,t3,f_9155(C_a_i(&a,12),((C_word*)t0)[2],t1,t2));}

/* a10092 in a9152 in k721 in k718 in k715 */
static void C_ccall f_10093(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10093,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10100,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10116,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_car(t2);
/* match.scm: 242  g136 */
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}
else{
t4=t3;
f_10100(t4,C_SCHEME_FALSE);}}

/* k10114 in a10092 in a9152 in k721 in k718 in k715 */
static void C_ccall f_10116(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
f_10100(t3,(C_word)C_i_pairp(t2));}
else{
t2=((C_word*)t0)[2];
f_10100(t2,C_SCHEME_FALSE);}}

/* k10098 in a10092 in a9152 in k721 in k718 in k715 */
static void C_fcall f_10100(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cddr(((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_nullp(t2));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k9435 in a9152 in k721 in k718 in k715 */
static void C_ccall f_9437(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9437,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9443,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[6]);
if(C_truep((C_word)C_i_listp(t3))){
t4=(C_word)C_i_cdr(((C_word*)t0)[6]);
t5=t2;
f_9443(t5,(C_word)C_i_pairp(t4));}
else{
t4=t2;
f_9443(t4,C_SCHEME_FALSE);}}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9541,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[6]);
if(C_truep((C_word)C_i_pairp(t3))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10087,a[2]=((C_word*)t0)[6],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* match.scm: 260  caar */
t5=*((C_word*)lf[63]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[6]);}
else{
t4=t2;
f_9541(t4,C_SCHEME_FALSE);}}}

/* k10085 in k9435 in a9152 in k721 in k718 in k715 */
static void C_ccall f_10087(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10087,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10083,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* match.scm: 261  cdaar */
t3=*((C_word*)lf[138]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_9541(t2,C_SCHEME_FALSE);}}

/* k10081 in k10085 in k9435 in a9152 in k721 in k718 in k715 */
static void C_ccall f_10083(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10083,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10079,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* match.scm: 262  cddaar */
t3=*((C_word*)lf[137]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_9541(t2,C_SCHEME_FALSE);}}

/* k10077 in k10081 in k10085 in k9435 in a9152 in k721 in k718 in k715 */
static void C_ccall f_10079(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_9541(t2,(C_word)C_i_nullp(t1));}

/* k9539 in k9435 in a9152 in k721 in k718 in k715 */
static void C_fcall f_9541(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9541,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9947,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* match.scm: 263  cdar */
t3=*((C_word*)lf[60]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[7]);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[7]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9956,a[2]=t4,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[7],a[6]=((C_word)li143),tmp=(C_word)a,a+=7,tmp));
t6=((C_word*)t4)[1];
f_9956(t6,((C_word*)t0)[6],t2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}}

/* g149 in k9539 in k9435 in a9152 in k721 in k718 in k715 */
static void C_fcall f_9956(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9956,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9969,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t6=(C_word)C_i_cdr(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_listp(t6))){
t7=(C_word)C_i_cdr(((C_word*)t0)[5]);
t8=t5;
f_9969(t8,(C_word)C_i_pairp(t7));}
else{
t7=t5;
f_9969(t7,C_SCHEME_FALSE);}}
else{
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10007,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t4,a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t6=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_pairp(t6))){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10053,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* match.scm: 332  cdar */
t8=*((C_word*)lf[60]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}
else{
t7=t5;
f_10007(t7,C_SCHEME_FALSE);}}}

/* k10051 in g149 in k9539 in k9435 in a9152 in k721 in k718 in k715 */
static void C_ccall f_10053(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10053,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10049,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* match.scm: 333  cddar */
t3=*((C_word*)lf[58]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_10007(t2,C_SCHEME_FALSE);}}

/* k10047 in k10051 in g149 in k9539 in k9435 in a9152 in k721 in k718 in k715 */
static void C_ccall f_10049(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_10007(t2,(C_word)C_i_nullp(t1));}

/* k10005 in g149 in k9539 in k9435 in a9152 in k721 in k718 in k715 */
static void C_fcall f_10007(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10007,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10030,a[2]=((C_word*)t0)[7],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* match.scm: 335  cadar */
t4=*((C_word*)lf[56]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[7]);}
else{
/* match.scm: 337  g146 */
t2=((C_word*)t0)[2];
f_9197(t2,((C_word*)t0)[3]);}}

/* k10028 in k10005 in g149 in k9539 in k9435 in a9152 in k721 in k718 in k715 */
static void C_ccall f_10030(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10030,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10026,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* match.scm: 336  caar */
t4=*((C_word*)lf[63]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k10024 in k10028 in k10005 in g149 in k9539 in k9435 in a9152 in k721 in k718 in k715 */
static void C_ccall f_10026(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10026,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[6]);
/* match.scm: 334  g149 */
t3=((C_word*)((C_word*)t0)[5])[1];
f_9956(t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k9967 in g149 in k9539 in k9435 in a9152 in k721 in k718 in k715 */
static void C_fcall f_9969(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9969,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9976,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* match.scm: 327  reverse */
t3=*((C_word*)lf[77]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}
else{
/* match.scm: 330  g146 */
t2=((C_word*)t0)[2];
f_9197(t2,((C_word*)t0)[5]);}}

/* k9974 in k9967 in g149 in k9539 in k9435 in a9152 in k721 in k718 in k715 */
static void C_ccall f_9976(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9976,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9980,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* match.scm: 328  reverse */
t3=*((C_word*)lf[77]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k9978 in k9974 in k9967 in g149 in k9539 in k9435 in a9152 in k721 in k718 in k715 */
static void C_ccall f_9980(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* match.scm: 327  g154 */
f_9164(((C_word*)t0)[3],((C_word*)t0)[2],t1,t2);}

/* k9945 in k9539 in k9435 in a9152 in k721 in k718 in k715 */
static void C_ccall f_9947(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9947,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9553,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[7]);
if(C_truep((C_word)C_i_listp(t3))){
t4=(C_word)C_i_cdr(((C_word*)t0)[7]);
t5=t2;
f_9553(t5,(C_word)C_i_pairp(t4));}
else{
t4=t2;
f_9553(t4,C_SCHEME_FALSE);}}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9663,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9943,a[2]=((C_word*)t0)[7],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* match.scm: 280  cdar */
t4=*((C_word*)lf[60]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[7]);}}

/* k9941 in k9945 in k9539 in k9435 in a9152 in k721 in k718 in k715 */
static void C_ccall f_9943(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9943,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9939,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* match.scm: 281  cadar */
t3=*((C_word*)lf[56]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_9663(t2,C_SCHEME_FALSE);}}

/* k9937 in k9941 in k9945 in k9539 in k9435 in a9152 in k721 in k718 in k715 */
static void C_ccall f_9939(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9939,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9935,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* match.scm: 282  cdadar */
t3=*((C_word*)lf[59]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_9663(t2,C_SCHEME_FALSE);}}

/* k9933 in k9937 in k9941 in k9945 in k9539 in k9435 in a9152 in k721 in k718 in k715 */
static void C_ccall f_9935(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9935,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9931,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* match.scm: 283  cdadar */
t3=*((C_word*)lf[59]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_9663(t2,C_SCHEME_FALSE);}}

/* k9929 in k9933 in k9937 in k9941 in k9945 in k9539 in k9435 in a9152 in k721 in k718 in k715 */
static void C_ccall f_9931(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9931,2,t0,t1);}
t2=(C_word)C_i_cdr(t1);
if(C_truep((C_word)C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9923,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* match.scm: 284  cddar */
t4=*((C_word*)lf[58]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[3];
f_9663(t3,C_SCHEME_FALSE);}}

/* k9921 in k9929 in k9933 in k9937 in k9941 in k9945 in k9539 in k9435 in a9152 in k721 in k718 in k715 */
static void C_ccall f_9923(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_9663(t2,(C_word)C_i_nullp(t1));}

/* k9661 in k9945 in k9539 in k9435 in a9152 in k721 in k718 in k715 */
static void C_fcall f_9663(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9663,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9669,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[6]);
if(C_truep((C_word)C_i_listp(t3))){
t4=(C_word)C_i_cdr(((C_word*)t0)[6]);
t5=t2;
f_9669(t5,(C_word)C_i_pairp(t4));}
else{
t4=t2;
f_9669(t4,C_SCHEME_FALSE);}}
else{
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9794,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[6],a[6]=((C_word)li142),tmp=(C_word)a,a+=7,tmp));
t6=((C_word*)t4)[1];
f_9794(t6,((C_word*)t0)[4],t2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}}

/* g149 in k9661 in k9945 in k9539 in k9435 in a9152 in k721 in k718 in k715 */
static void C_fcall f_9794(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9794,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9807,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t6=(C_word)C_i_cdr(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_listp(t6))){
t7=(C_word)C_i_cdr(((C_word*)t0)[5]);
t8=t5;
f_9807(t8,(C_word)C_i_pairp(t7));}
else{
t7=t5;
f_9807(t7,C_SCHEME_FALSE);}}
else{
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9845,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t4,a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t6=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_pairp(t6))){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9891,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* match.scm: 317  cdar */
t8=*((C_word*)lf[60]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}
else{
t7=t5;
f_9845(t7,C_SCHEME_FALSE);}}}

/* k9889 in g149 in k9661 in k9945 in k9539 in k9435 in a9152 in k721 in k718 in k715 */
static void C_ccall f_9891(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9891,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9887,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* match.scm: 318  cddar */
t3=*((C_word*)lf[58]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_9845(t2,C_SCHEME_FALSE);}}

/* k9885 in k9889 in g149 in k9661 in k9945 in k9539 in k9435 in a9152 in k721 in k718 in k715 */
static void C_ccall f_9887(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_9845(t2,(C_word)C_i_nullp(t1));}

/* k9843 in g149 in k9661 in k9945 in k9539 in k9435 in a9152 in k721 in k718 in k715 */
static void C_fcall f_9845(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9845,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9868,a[2]=((C_word*)t0)[7],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* match.scm: 320  cadar */
t4=*((C_word*)lf[56]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[7]);}
else{
/* match.scm: 322  g146 */
t2=((C_word*)t0)[2];
f_9197(t2,((C_word*)t0)[3]);}}

/* k9866 in k9843 in g149 in k9661 in k9945 in k9539 in k9435 in a9152 in k721 in k718 in k715 */
static void C_ccall f_9868(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9868,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9864,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* match.scm: 321  caar */
t4=*((C_word*)lf[63]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k9862 in k9866 in k9843 in g149 in k9661 in k9945 in k9539 in k9435 in a9152 in k721 in k718 in k715 */
static void C_ccall f_9864(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9864,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[6]);
/* match.scm: 319  g149 */
t3=((C_word*)((C_word*)t0)[5])[1];
f_9794(t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k9805 in g149 in k9661 in k9945 in k9539 in k9435 in a9152 in k721 in k718 in k715 */
static void C_fcall f_9807(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9807,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9814,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* match.scm: 312  reverse */
t3=*((C_word*)lf[77]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}
else{
/* match.scm: 315  g146 */
t2=((C_word*)t0)[2];
f_9197(t2,((C_word*)t0)[5]);}}

/* k9812 in k9805 in g149 in k9661 in k9945 in k9539 in k9435 in a9152 in k721 in k718 in k715 */
static void C_ccall f_9814(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9814,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9818,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* match.scm: 313  reverse */
t3=*((C_word*)lf[77]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k9816 in k9812 in k9805 in g149 in k9661 in k9945 in k9539 in k9435 in a9152 in k721 in k718 in k715 */
static void C_ccall f_9818(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* match.scm: 312  g154 */
f_9164(((C_word*)t0)[3],((C_word*)t0)[2],t1,t2);}

/* k9667 in k9661 in k9945 in k9539 in k9435 in a9152 in k721 in k718 in k715 */
static void C_fcall f_9669(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9669,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9676,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* match.scm: 287  caaar */
t3=*((C_word*)lf[136]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9705,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=((C_word)li141),tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_9705(t6,((C_word*)t0)[3],t2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}}

/* g149 in k9667 in k9661 in k9945 in k9539 in k9435 in a9152 in k721 in k718 in k715 */
static void C_fcall f_9705(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9705,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
/* match.scm: 296  g146 */
t5=((C_word*)t0)[3];
f_9197(t5,t1);}
else{
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9721,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t4,a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t6=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_pairp(t6))){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9767,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* match.scm: 298  cdar */
t8=*((C_word*)lf[60]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}
else{
t7=t5;
f_9721(t7,C_SCHEME_FALSE);}}}

/* k9765 in g149 in k9667 in k9661 in k9945 in k9539 in k9435 in a9152 in k721 in k718 in k715 */
static void C_ccall f_9767(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9767,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9763,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* match.scm: 299  cddar */
t3=*((C_word*)lf[58]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_9721(t2,C_SCHEME_FALSE);}}

/* k9761 in k9765 in g149 in k9667 in k9661 in k9945 in k9539 in k9435 in a9152 in k721 in k718 in k715 */
static void C_ccall f_9763(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_9721(t2,(C_word)C_i_nullp(t1));}

/* k9719 in g149 in k9667 in k9661 in k9945 in k9539 in k9435 in a9152 in k721 in k718 in k715 */
static void C_fcall f_9721(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9721,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9744,a[2]=((C_word*)t0)[7],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* match.scm: 301  cadar */
t4=*((C_word*)lf[56]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[7]);}
else{
/* match.scm: 305  g146 */
t2=((C_word*)t0)[2];
f_9197(t2,((C_word*)t0)[3]);}}

/* k9742 in k9719 in g149 in k9667 in k9661 in k9945 in k9539 in k9435 in a9152 in k721 in k718 in k715 */
static void C_ccall f_9744(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9744,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9740,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* match.scm: 303  caar */
t4=*((C_word*)lf[63]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k9738 in k9742 in k9719 in g149 in k9667 in k9661 in k9945 in k9539 in k9435 in a9152 in k721 in k718 in k715 */
static void C_ccall f_9740(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9740,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[6]);
/* match.scm: 300  g149 */
t3=((C_word*)((C_word*)t0)[5])[1];
f_9705(t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k9674 in k9667 in k9661 in k9945 in k9539 in k9435 in a9152 in k721 in k718 in k715 */
static void C_ccall f_9676(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9676,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9680,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* match.scm: 288  cadaar */
t3=*((C_word*)lf[135]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[4]);}

/* k9678 in k9674 in k9667 in k9661 in k9945 in k9539 in k9435 in a9152 in k721 in k718 in k715 */
static void C_ccall f_9680(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9680,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9684,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* match.scm: 289  caadar */
t3=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}

/* k9682 in k9678 in k9674 in k9667 in k9661 in k9945 in k9539 in k9435 in a9152 in k721 in k718 in k715 */
static void C_ccall f_9684(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9684,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9696,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* match.scm: 290  cdadar */
t3=*((C_word*)lf[59]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[6]);}

/* k9694 in k9682 in k9678 in k9674 in k9667 in k9661 in k9945 in k9539 in k9435 in a9152 in k721 in k718 in k715 */
static void C_ccall f_9696(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_car(t1);
t3=(C_word)C_i_cdr(((C_word*)t0)[7]);
/* match.scm: 287  g145 */
f_9206(((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2,t3);}

/* k9551 in k9945 in k9539 in k9435 in a9152 in k721 in k718 in k715 */
static void C_fcall f_9553(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9553,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9560,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* match.scm: 265  caaar */
t3=*((C_word*)lf[136]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9577,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=((C_word)li140),tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_9577(t6,((C_word*)t0)[4],t2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}}

/* g149 in k9551 in k9945 in k9539 in k9435 in a9152 in k721 in k718 in k715 */
static void C_fcall f_9577(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9577,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
/* match.scm: 272  g146 */
t5=((C_word*)t0)[3];
f_9197(t5,t1);}
else{
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9593,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t4,a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t6=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_pairp(t6))){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9639,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* match.scm: 274  cdar */
t8=*((C_word*)lf[60]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}
else{
t7=t5;
f_9593(t7,C_SCHEME_FALSE);}}}

/* k9637 in g149 in k9551 in k9945 in k9539 in k9435 in a9152 in k721 in k718 in k715 */
static void C_ccall f_9639(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9639,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9635,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* match.scm: 275  cddar */
t3=*((C_word*)lf[58]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_9593(t2,C_SCHEME_FALSE);}}

/* k9633 in k9637 in g149 in k9551 in k9945 in k9539 in k9435 in a9152 in k721 in k718 in k715 */
static void C_ccall f_9635(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_9593(t2,(C_word)C_i_nullp(t1));}

/* k9591 in g149 in k9551 in k9945 in k9539 in k9435 in a9152 in k721 in k718 in k715 */
static void C_fcall f_9593(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9593,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9616,a[2]=((C_word*)t0)[7],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* match.scm: 277  cadar */
t4=*((C_word*)lf[56]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[7]);}
else{
/* match.scm: 279  g146 */
t2=((C_word*)t0)[2];
f_9197(t2,((C_word*)t0)[3]);}}

/* k9614 in k9591 in g149 in k9551 in k9945 in k9539 in k9435 in a9152 in k721 in k718 in k715 */
static void C_ccall f_9616(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9616,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9612,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* match.scm: 278  caar */
t4=*((C_word*)lf[63]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k9610 in k9614 in k9591 in g149 in k9551 in k9945 in k9539 in k9435 in a9152 in k721 in k718 in k715 */
static void C_ccall f_9612(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9612,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[6]);
/* match.scm: 276  g149 */
t3=((C_word*)((C_word*)t0)[5])[1];
f_9577(t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k9558 in k9551 in k9945 in k9539 in k9435 in a9152 in k721 in k718 in k715 */
static void C_ccall f_9560(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9560,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9564,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* match.scm: 266  cadaar */
t3=*((C_word*)lf[135]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[4]);}

/* k9562 in k9558 in k9551 in k9945 in k9539 in k9435 in a9152 in k721 in k718 in k715 */
static void C_ccall f_9564(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9564,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* match.scm: 265  g158 */
t3=((C_word*)t0)[4];
((C_proc2)C_retrieve_proc(t3))(2,t3,f_9155(C_a_i(&a,12),((C_word*)t0)[2],t1,t2));}

/* k9441 in k9435 in a9152 in k721 in k718 in k715 */
static void C_fcall f_9443(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9443,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[20],((C_word*)t0)[3]));}
else{
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9455,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=((C_word)li139),tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_9455(t6,((C_word*)t0)[4],t2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}}

/* g149 in k9441 in k9435 in a9152 in k721 in k718 in k715 */
static void C_fcall f_9455(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9455,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
/* match.scm: 251  g146 */
t5=((C_word*)t0)[3];
f_9197(t5,t1);}
else{
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9471,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t4,a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t6=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_pairp(t6))){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9517,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* match.scm: 253  cdar */
t8=*((C_word*)lf[60]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}
else{
t7=t5;
f_9471(t7,C_SCHEME_FALSE);}}}

/* k9515 in g149 in k9441 in k9435 in a9152 in k721 in k718 in k715 */
static void C_ccall f_9517(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9517,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9513,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* match.scm: 254  cddar */
t3=*((C_word*)lf[58]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_9471(t2,C_SCHEME_FALSE);}}

/* k9511 in k9515 in g149 in k9441 in k9435 in a9152 in k721 in k718 in k715 */
static void C_ccall f_9513(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_9471(t2,(C_word)C_i_nullp(t1));}

/* k9469 in g149 in k9441 in k9435 in a9152 in k721 in k718 in k715 */
static void C_fcall f_9471(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9471,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9494,a[2]=((C_word*)t0)[7],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* match.scm: 256  cadar */
t4=*((C_word*)lf[56]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[7]);}
else{
/* match.scm: 258  g146 */
t2=((C_word*)t0)[2];
f_9197(t2,((C_word*)t0)[3]);}}

/* k9492 in k9469 in g149 in k9441 in k9435 in a9152 in k721 in k718 in k715 */
static void C_ccall f_9494(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9494,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9490,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* match.scm: 257  caar */
t4=*((C_word*)lf[63]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k9488 in k9492 in k9469 in g149 in k9441 in k9435 in a9152 in k721 in k718 in k715 */
static void C_ccall f_9490(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9490,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[6]);
/* match.scm: 255  g149 */
t3=((C_word*)((C_word*)t0)[5])[1];
f_9455(t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k9263 in a9152 in k721 in k718 in k715 */
static void C_fcall f_9265(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9265,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9274,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word)li138),tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_9274(t6,((C_word*)t0)[2],t2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}
else{
/* match.scm: 237  g146 */
t2=((C_word*)t0)[3];
f_9197(t2,((C_word*)t0)[2]);}}

/* g161 in k9263 in a9152 in k721 in k718 in k715 */
static void C_fcall f_9274(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9274,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9287,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t6=(C_word)C_i_cddr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_listp(t6))){
t7=(C_word)C_i_cddr(((C_word*)t0)[4]);
t8=t5;
f_9287(t8,(C_word)C_i_pairp(t7));}
else{
t7=t5;
f_9287(t7,C_SCHEME_FALSE);}}
else{
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9358,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t4,a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t6=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_pairp(t6))){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9404,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* match.scm: 231  cdar */
t8=*((C_word*)lf[60]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}
else{
t7=t5;
f_9358(t7,C_SCHEME_FALSE);}}}

/* k9402 in g161 in k9263 in a9152 in k721 in k718 in k715 */
static void C_ccall f_9404(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9404,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9400,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* match.scm: 232  cddar */
t3=*((C_word*)lf[58]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_9358(t2,C_SCHEME_FALSE);}}

/* k9398 in k9402 in g161 in k9263 in a9152 in k721 in k718 in k715 */
static void C_ccall f_9400(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_9358(t2,(C_word)C_i_nullp(t1));}

/* k9356 in g161 in k9263 in a9152 in k721 in k718 in k715 */
static void C_fcall f_9358(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9358,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9381,a[2]=((C_word*)t0)[7],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* match.scm: 234  cadar */
t4=*((C_word*)lf[56]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[7]);}
else{
/* match.scm: 236  g146 */
t2=((C_word*)t0)[2];
f_9197(t2,((C_word*)t0)[3]);}}

/* k9379 in k9356 in g161 in k9263 in a9152 in k721 in k718 in k715 */
static void C_ccall f_9381(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9381,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9377,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* match.scm: 235  caar */
t4=*((C_word*)lf[63]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k9375 in k9379 in k9356 in g161 in k9263 in a9152 in k721 in k718 in k715 */
static void C_ccall f_9377(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9377,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[6]);
/* match.scm: 233  g161 */
t3=((C_word*)((C_word*)t0)[5])[1];
f_9274(t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k9285 in g161 in k9263 in a9152 in k721 in k718 in k715 */
static void C_fcall f_9287(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9287,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9293,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* match.scm: 226  reverse */
t4=*((C_word*)lf[77]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[3]);}
else{
/* match.scm: 229  g146 */
t2=((C_word*)t0)[2];
f_9197(t2,((C_word*)t0)[5]);}}

/* k9291 in k9285 in g161 in k9263 in a9152 in k721 in k718 in k715 */
static void C_ccall f_9293(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9293,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9296,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* match.scm: 227  reverse */
t3=*((C_word*)lf[77]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k9294 in k9291 in k9285 in g161 in k9263 in a9152 in k721 in k718 in k715 */
static void C_ccall f_9296(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9296,2,t0,t1);}
t2=(C_word)C_i_cddr(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9305,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
t4=(C_word)C_i_cadddr(*((C_word*)lf[125]+1));
/* match.scm: 218  ##match#every */
t5=*((C_word*)lf[0]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t4,((C_word*)t0)[3]);}

/* k9303 in k9294 in k9291 in k9285 in g161 in k9263 in a9152 in k721 in k718 in k715 */
static void C_ccall f_9305(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9305,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[20],((C_word*)t0)[6]));}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[4]);
t3=(C_word)C_a_i_list(&a,2,lf[145],t2);
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t3);
t5=(C_word)C_a_i_list(&a,1,t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]);
t7=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_list(&a,3,lf[120],t5,t6));}}

/* g145 in a9152 in k721 in k718 in k715 */
static void C_fcall f_9206(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9206,NULL,6,t1,t2,t3,t4,t5,t6);}
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9210,a[2]=t1,a[3]=t6,a[4]=t4,a[5]=t2,a[6]=t5,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
/* match.scm: 207  gensym */
t8=*((C_word*)lf[95]+1);
((C_proc2)C_retrieve_proc(t8))(2,t8,t7);}

/* k9208 in g145 in a9152 in k721 in k718 in k715 */
static void C_ccall f_9210(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9210,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9213,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
/* match.scm: 207  gensym */
t3=*((C_word*)lf[95]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k9211 in k9208 in g145 in a9152 in k721 in k718 in k715 */
static void C_ccall f_9213(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[51],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9213,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[8],((C_word*)t0)[7]);
t3=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[6]);
t4=(C_word)C_a_i_list(&a,2,t2,t3);
t5=(C_word)C_a_i_list(&a,3,lf[76],((C_word*)t0)[8],t1);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[4]);
t7=(C_word)C_a_i_cons(&a,2,t6,((C_word*)t0)[3]);
t8=(C_word)C_a_i_list(&a,3,lf[129],t5,t7);
t9=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_a_i_list(&a,3,lf[20],t4,t8));}

/* g146 in a9152 in k721 in k718 in k715 */
static void C_fcall f_9197(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9197,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[143],((C_word*)t0)[2]);
/* match.scm: 205  ##match#syntax-err */
t3=*((C_word*)lf[1]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,lf[144]);}

/* g154 in a9152 in k721 in k718 in k715 */
static void C_fcall f_9164(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9164,NULL,4,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9168,a[2]=t2,a[3]=t3,a[4]=t1,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9192,a[2]=((C_word)li134),tmp=(C_word)a,a+=3,tmp);
/* map */
t7=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,t2);}

/* a9191 in g154 in a9152 in k721 in k718 in k715 */
static void C_ccall f_9192(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9192,3,t0,t1,t2);}
/* match.scm: 200  gensym */
t3=*((C_word*)lf[95]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,t1);}

/* k9166 in g154 in a9152 in k721 in k718 in k715 */
static void C_ccall f_9168(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9168,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9171,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* match.scm: 201  list->vector */
t3=*((C_word*)lf[98]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k9169 in k9166 in g154 in a9152 in k721 in k718 in k715 */
static void C_ccall f_9171(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9171,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9178,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* match.scm: 202  map */
t3=*((C_word*)lf[75]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,*((C_word*)lf[142]+1),((C_word*)t0)[5],((C_word*)t0)[2]);}

/* k9176 in k9169 in k9166 in g154 in a9152 in k721 in k718 in k715 */
static void C_ccall f_9178(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9178,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[104],((C_word*)t0)[5]);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)t0)[3]);
t4=(C_word)C_a_i_list(&a,3,lf[129],t2,t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,3,lf[20],t1,t4));}

/* g158 in a9152 in k721 in k718 in k715 */
static C_word C_fcall f_9155(C_word *a,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_stack_check;
t4=(C_word)C_a_i_cons(&a,2,t1,t3);
return((C_word)C_a_i_list(&a,3,lf[129],t2,t4));}

/* k724 in k721 in k718 in k715 */
static void C_ccall f_726(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_726,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_729,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8965,a[2]=((C_word)li132),tmp=(C_word)a,a+=3,tmp);
/* match.scm: 419  ##sys#register-macro-2 */
t4=*((C_word*)lf[132]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[139],t3);}

/* a8964 in k724 in k721 in k718 in k715 */
static void C_ccall f_8965(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[18],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8965,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8967,a[2]=t2,a[3]=((C_word)li131),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_nullp(t4))){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8993,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_listp(t6))){
t7=(C_word)C_i_cdr(t2);
t8=t5;
f_8993(t8,(C_word)C_i_pairp(t7));}
else{
t7=t5;
f_8993(t7,C_SCHEME_FALSE);}}
else{
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9022,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_pairp(t6))){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9140,a[2]=t5,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* match.scm: 429  caar */
t8=*((C_word*)lf[63]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}
else{
t7=t5;
f_9022(t7,C_SCHEME_FALSE);}}}
else{
/* match.scm: 444  g176 */
t4=t3;
f_8967(t4,t1);}}

/* k9138 in a8964 in k724 in k721 in k718 in k715 */
static void C_ccall f_9140(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9140,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9136,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* match.scm: 430  cdaar */
t3=*((C_word*)lf[138]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}
else{
t2=((C_word*)t0)[2];
f_9022(t2,C_SCHEME_FALSE);}}

/* k9134 in k9138 in a8964 in k724 in k721 in k718 in k715 */
static void C_ccall f_9136(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9136,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9132,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* match.scm: 431  cddaar */
t3=*((C_word*)lf[137]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}
else{
t2=((C_word*)t0)[2];
f_9022(t2,C_SCHEME_FALSE);}}

/* k9130 in k9134 in k9138 in a8964 in k724 in k721 in k718 in k715 */
static void C_ccall f_9132(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9132,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9128,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* match.scm: 432  cdar */
t3=*((C_word*)lf[60]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}
else{
t2=((C_word*)t0)[2];
f_9022(t2,C_SCHEME_FALSE);}}

/* k9126 in k9130 in k9134 in k9138 in a8964 in k724 in k721 in k718 in k715 */
static void C_ccall f_9128(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep((C_word)C_i_listp(t1))){
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_listp(t2))){
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
t4=((C_word*)t0)[2];
f_9022(t4,(C_word)C_i_pairp(t3));}
else{
t3=((C_word*)t0)[2];
f_9022(t3,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[2];
f_9022(t2,C_SCHEME_FALSE);}}

/* k9020 in a8964 in k724 in k721 in k718 in k715 */
static void C_fcall f_9022(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9022,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9025,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* match.scm: 439  caaar */
t3=*((C_word*)lf[136]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[4]);}
else{
/* match.scm: 443  g176 */
t2=((C_word*)t0)[2];
f_8967(t2,((C_word*)t0)[3]);}}

/* k9023 in k9020 in a8964 in k724 in k721 in k718 in k715 */
static void C_ccall f_9025(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9025,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9028,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* match.scm: 440  cadaar */
t3=*((C_word*)lf[135]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* k9026 in k9023 in k9020 in a8964 in k724 in k721 in k718 in k715 */
static void C_ccall f_9028(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9028,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9031,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* match.scm: 441  cdar */
t3=*((C_word*)lf[60]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[4]);}

/* k9029 in k9026 in k9023 in k9020 in a8964 in k724 in k721 in k718 in k715 */
static void C_ccall f_9031(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9031,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9040,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_i_cadddr(*((C_word*)lf[125]+1));
t5=t4;
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,((C_word*)t0)[4]);}

/* k9038 in k9029 in k9026 in k9023 in k9020 in a8964 in k724 in k721 in k718 in k715 */
static void C_ccall f_9040(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[45],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9040,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[6],((C_word*)t0)[5]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)t0)[3]);
t5=(C_word)C_a_i_cons(&a,2,lf[139],t4);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_list(&a,3,lf[20],t3,t5));}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)t0)[3]);
t3=(C_word)C_a_i_cons(&a,2,lf[139],t2);
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[6],t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,3,lf[129],((C_word*)t0)[5],t4));}}

/* k8991 in a8964 in k724 in k721 in k718 in k715 */
static void C_fcall f_8993(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8993,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[141],((C_word*)t0)[4]));}
else{
/* match.scm: 427  g176 */
t2=((C_word*)t0)[2];
f_8967(t2,((C_word*)t0)[3]);}}

/* g176 in a8964 in k724 in k721 in k718 in k715 */
static void C_fcall f_8967(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8967,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[139],((C_word*)t0)[2]);
/* match.scm: 422  ##match#syntax-err */
t3=*((C_word*)lf[1]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,lf[140]);}

/* k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_729(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_729,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_732,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7598,a[2]=((C_word)li130),tmp=(C_word)a,a+=3,tmp);
/* match.scm: 445  ##sys#register-macro-2 */
t4=*((C_word*)lf[132]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[133],t3);}

/* a7597 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_7598(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[37],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7598,3,t0,t1,t2);}
t3=(C_word)C_i_cadddr(*((C_word*)lf[125]+1));
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7603,a[2]=((C_word)li116),tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7628,a[2]=t2,a[3]=((C_word)li117),tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7637,a[2]=((C_word)li118),tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7662,a[2]=((C_word)li119),tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t8=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_listp(t8))){
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7703,a[2]=t6,a[3]=t4,a[4]=t7,a[5]=t5,a[6]=t2,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8359,a[2]=t3,a[3]=((C_word)li125),tmp=(C_word)a,a+=4,tmp);
t11=(C_word)C_i_car(t2);
/* match.scm: 466  ##match#every */
t12=*((C_word*)lf[0]+1);
((C_proc4)C_retrieve_proc(t12))(4,t12,t9,t10,t11);}
else{
t9=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_pairp(t9))){
t10=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8409,a[2]=t6,a[3]=t4,a[4]=t5,a[5]=t1,a[6]=t7,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8949,a[2]=t2,a[3]=t10,tmp=(C_word)a,a+=4,tmp);
/* match.scm: 560  caar */
t12=*((C_word*)lf[63]+1);
((C_proc3)(void*)(*((C_word*)t12+1)))(3,t12,t11,t2);}
else{
/* match.scm: 632  g195 */
t10=t5;
f_7628(t10,t1);}}}
else{
/* match.scm: 633  g195 */
t8=t5;
f_7628(t8,t1);}}

/* k8947 in a7597 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_8949(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8949,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8945,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* match.scm: 561  cdaar */
t3=*((C_word*)lf[138]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_8409(t2,C_SCHEME_FALSE);}}

/* k8943 in k8947 in a7597 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_8945(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8945,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8941,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* match.scm: 562  cddaar */
t3=*((C_word*)lf[137]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_8409(t2,C_SCHEME_FALSE);}}

/* k8939 in k8943 in k8947 in a7597 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_8941(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_8409(t2,(C_word)C_i_nullp(t1));}

/* k8407 in a7597 in k727 in k724 in k721 in k718 in k715 */
static void C_fcall f_8409(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8409,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8815,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* match.scm: 563  cdar */
t3=*((C_word*)lf[60]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[7]);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[7]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8824,a[2]=t4,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[7],a[6]=((C_word)li129),tmp=(C_word)a,a+=7,tmp));
t6=((C_word*)t4)[1];
f_8824(t6,((C_word*)t0)[5],t2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}}

/* g189 in k8407 in a7597 in k727 in k724 in k721 in k718 in k715 */
static void C_fcall f_8824(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8824,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8837,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t6=(C_word)C_i_cdr(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_listp(t6))){
t7=(C_word)C_i_cdr(((C_word*)t0)[5]);
t8=t5;
f_8837(t8,(C_word)C_i_pairp(t7));}
else{
t7=t5;
f_8837(t7,C_SCHEME_FALSE);}}
else{
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8875,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t4,a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t6=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_pairp(t6))){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8921,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* match.scm: 626  cdar */
t8=*((C_word*)lf[60]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}
else{
t7=t5;
f_8875(t7,C_SCHEME_FALSE);}}}

/* k8919 in g189 in k8407 in a7597 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_8921(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8921,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8917,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* match.scm: 627  cddar */
t3=*((C_word*)lf[58]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_8875(t2,C_SCHEME_FALSE);}}

/* k8915 in k8919 in g189 in k8407 in a7597 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_8917(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_8875(t2,(C_word)C_i_nullp(t1));}

/* k8873 in g189 in k8407 in a7597 in k727 in k724 in k721 in k718 in k715 */
static void C_fcall f_8875(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8875,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8898,a[2]=((C_word*)t0)[7],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* match.scm: 629  cadar */
t4=*((C_word*)lf[56]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[7]);}
else{
/* match.scm: 631  g195 */
t2=((C_word*)t0)[2];
f_7628(t2,((C_word*)t0)[3]);}}

/* k8896 in k8873 in g189 in k8407 in a7597 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_8898(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8898,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8894,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* match.scm: 630  caar */
t4=*((C_word*)lf[63]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k8892 in k8896 in k8873 in g189 in k8407 in a7597 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_8894(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8894,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[6]);
/* match.scm: 628  g189 */
t3=((C_word*)((C_word*)t0)[5])[1];
f_8824(t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k8835 in g189 in k8407 in a7597 in k727 in k724 in k721 in k718 in k715 */
static void C_fcall f_8837(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8837,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8844,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* match.scm: 621  reverse */
t3=*((C_word*)lf[77]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}
else{
/* match.scm: 624  g195 */
t2=((C_word*)t0)[2];
f_7628(t2,((C_word*)t0)[5]);}}

/* k8842 in k8835 in g189 in k8407 in a7597 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_8844(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8844,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8848,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* match.scm: 622  reverse */
t3=*((C_word*)lf[77]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k8846 in k8842 in k8835 in g189 in k8407 in a7597 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_8848(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* match.scm: 621  g194 */
f_7637(((C_word*)t0)[3],((C_word*)t0)[2],t1,t2);}

/* k8813 in k8407 in a7597 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_8815(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8815,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8421,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[7]);
if(C_truep((C_word)C_i_listp(t3))){
t4=(C_word)C_i_cdr(((C_word*)t0)[7]);
t5=t2;
f_8421(t5,(C_word)C_i_pairp(t4));}
else{
t4=t2;
f_8421(t4,C_SCHEME_FALSE);}}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8531,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8811,a[2]=((C_word*)t0)[7],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* match.scm: 578  cdar */
t4=*((C_word*)lf[60]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[7]);}}

/* k8809 in k8813 in k8407 in a7597 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_8811(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8811,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8807,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* match.scm: 579  cadar */
t3=*((C_word*)lf[56]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_8531(t2,C_SCHEME_FALSE);}}

/* k8805 in k8809 in k8813 in k8407 in a7597 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_8807(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8807,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8803,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* match.scm: 580  cdadar */
t3=*((C_word*)lf[59]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_8531(t2,C_SCHEME_FALSE);}}

/* k8801 in k8805 in k8809 in k8813 in k8407 in a7597 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_8803(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8803,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8799,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* match.scm: 581  cdadar */
t3=*((C_word*)lf[59]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_8531(t2,C_SCHEME_FALSE);}}

/* k8797 in k8801 in k8805 in k8809 in k8813 in k8407 in a7597 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_8799(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8799,2,t0,t1);}
t2=(C_word)C_i_cdr(t1);
if(C_truep((C_word)C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8791,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* match.scm: 582  cddar */
t4=*((C_word*)lf[58]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[3];
f_8531(t3,C_SCHEME_FALSE);}}

/* k8789 in k8797 in k8801 in k8805 in k8809 in k8813 in k8407 in a7597 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_8791(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_8531(t2,(C_word)C_i_nullp(t1));}

/* k8529 in k8813 in k8407 in a7597 in k727 in k724 in k721 in k718 in k715 */
static void C_fcall f_8531(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8531,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8537,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[6]);
if(C_truep((C_word)C_i_listp(t3))){
t4=(C_word)C_i_cdr(((C_word*)t0)[6]);
t5=t2;
f_8537(t5,(C_word)C_i_pairp(t4));}
else{
t4=t2;
f_8537(t4,C_SCHEME_FALSE);}}
else{
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8662,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[6],a[6]=((C_word)li128),tmp=(C_word)a,a+=7,tmp));
t6=((C_word*)t4)[1];
f_8662(t6,((C_word*)t0)[5],t2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}}

/* g189 in k8529 in k8813 in k8407 in a7597 in k727 in k724 in k721 in k718 in k715 */
static void C_fcall f_8662(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8662,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8675,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t6=(C_word)C_i_cdr(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_listp(t6))){
t7=(C_word)C_i_cdr(((C_word*)t0)[5]);
t8=t5;
f_8675(t8,(C_word)C_i_pairp(t7));}
else{
t7=t5;
f_8675(t7,C_SCHEME_FALSE);}}
else{
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8713,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t4,a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t6=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_pairp(t6))){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8759,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* match.scm: 612  cdar */
t8=*((C_word*)lf[60]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}
else{
t7=t5;
f_8713(t7,C_SCHEME_FALSE);}}}

/* k8757 in g189 in k8529 in k8813 in k8407 in a7597 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_8759(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8759,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8755,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* match.scm: 613  cddar */
t3=*((C_word*)lf[58]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_8713(t2,C_SCHEME_FALSE);}}

/* k8753 in k8757 in g189 in k8529 in k8813 in k8407 in a7597 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_8755(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_8713(t2,(C_word)C_i_nullp(t1));}

/* k8711 in g189 in k8529 in k8813 in k8407 in a7597 in k727 in k724 in k721 in k718 in k715 */
static void C_fcall f_8713(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8713,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8736,a[2]=((C_word*)t0)[7],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* match.scm: 615  cadar */
t4=*((C_word*)lf[56]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[7]);}
else{
/* match.scm: 617  g195 */
t2=((C_word*)t0)[2];
f_7628(t2,((C_word*)t0)[3]);}}

/* k8734 in k8711 in g189 in k8529 in k8813 in k8407 in a7597 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_8736(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8736,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8732,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* match.scm: 616  caar */
t4=*((C_word*)lf[63]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k8730 in k8734 in k8711 in g189 in k8529 in k8813 in k8407 in a7597 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_8732(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8732,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[6]);
/* match.scm: 614  g189 */
t3=((C_word*)((C_word*)t0)[5])[1];
f_8662(t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k8673 in g189 in k8529 in k8813 in k8407 in a7597 in k727 in k724 in k721 in k718 in k715 */
static void C_fcall f_8675(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8675,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8682,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* match.scm: 607  reverse */
t3=*((C_word*)lf[77]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}
else{
/* match.scm: 610  g195 */
t2=((C_word*)t0)[2];
f_7628(t2,((C_word*)t0)[5]);}}

/* k8680 in k8673 in g189 in k8529 in k8813 in k8407 in a7597 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_8682(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8682,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8686,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* match.scm: 608  reverse */
t3=*((C_word*)lf[77]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k8684 in k8680 in k8673 in g189 in k8529 in k8813 in k8407 in a7597 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_8686(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* match.scm: 607  g194 */
f_7637(((C_word*)t0)[3],((C_word*)t0)[2],t1,t2);}

/* k8535 in k8529 in k8813 in k8407 in a7597 in k727 in k724 in k721 in k718 in k715 */
static void C_fcall f_8537(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8537,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8544,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* match.scm: 584  caaar */
t3=*((C_word*)lf[136]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8573,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=((C_word)li127),tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_8573(t6,((C_word*)t0)[4],t2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}}

/* g189 in k8535 in k8529 in k8813 in k8407 in a7597 in k727 in k724 in k721 in k718 in k715 */
static void C_fcall f_8573(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8573,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
/* match.scm: 593  g195 */
t5=((C_word*)t0)[3];
f_7628(t5,t1);}
else{
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8589,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t4,a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t6=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_pairp(t6))){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8635,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* match.scm: 595  cdar */
t8=*((C_word*)lf[60]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}
else{
t7=t5;
f_8589(t7,C_SCHEME_FALSE);}}}

/* k8633 in g189 in k8535 in k8529 in k8813 in k8407 in a7597 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_8635(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8635,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8631,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* match.scm: 596  cddar */
t3=*((C_word*)lf[58]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_8589(t2,C_SCHEME_FALSE);}}

/* k8629 in k8633 in g189 in k8535 in k8529 in k8813 in k8407 in a7597 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_8631(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_8589(t2,(C_word)C_i_nullp(t1));}

/* k8587 in g189 in k8535 in k8529 in k8813 in k8407 in a7597 in k727 in k724 in k721 in k718 in k715 */
static void C_fcall f_8589(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8589,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8612,a[2]=((C_word*)t0)[7],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* match.scm: 598  cadar */
t4=*((C_word*)lf[56]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[7]);}
else{
/* match.scm: 600  g195 */
t2=((C_word*)t0)[2];
f_7628(t2,((C_word*)t0)[3]);}}

/* k8610 in k8587 in g189 in k8535 in k8529 in k8813 in k8407 in a7597 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_8612(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8612,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8608,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* match.scm: 599  caar */
t4=*((C_word*)lf[63]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k8606 in k8610 in k8587 in g189 in k8535 in k8529 in k8813 in k8407 in a7597 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_8608(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8608,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[6]);
/* match.scm: 597  g189 */
t3=((C_word*)((C_word*)t0)[5])[1];
f_8573(t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k8542 in k8535 in k8529 in k8813 in k8407 in a7597 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_8544(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8544,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8548,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* match.scm: 585  cadaar */
t3=*((C_word*)lf[135]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[4]);}

/* k8546 in k8542 in k8535 in k8529 in k8813 in k8407 in a7597 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_8548(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8548,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8552,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* match.scm: 586  caadar */
t3=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}

/* k8550 in k8546 in k8542 in k8535 in k8529 in k8813 in k8407 in a7597 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_8552(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8552,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8564,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* match.scm: 587  cdadar */
t3=*((C_word*)lf[59]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[6]);}

/* k8562 in k8550 in k8546 in k8542 in k8535 in k8529 in k8813 in k8407 in a7597 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_8564(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8564,2,t0,t1);}
t2=(C_word)C_i_car(t1);
t3=(C_word)C_i_cdr(((C_word*)t0)[7]);
/* match.scm: 584  g199 */
t4=((C_word*)t0)[6];
((C_proc2)C_retrieve_proc(t4))(2,t4,f_7603(C_a_i(&a,27),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2,t3));}

/* k8419 in k8813 in k8407 in a7597 in k727 in k724 in k721 in k718 in k715 */
static void C_fcall f_8421(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8421,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8428,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* match.scm: 565  caaar */
t3=*((C_word*)lf[136]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8445,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=((C_word)li126),tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_8445(t6,((C_word*)t0)[3],t2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}}

/* g189 in k8419 in k8813 in k8407 in a7597 in k727 in k724 in k721 in k718 in k715 */
static void C_fcall f_8445(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8445,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
/* match.scm: 570  g195 */
t5=((C_word*)t0)[3];
f_7628(t5,t1);}
else{
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8461,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t4,a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t6=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_pairp(t6))){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8507,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* match.scm: 572  cdar */
t8=*((C_word*)lf[60]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}
else{
t7=t5;
f_8461(t7,C_SCHEME_FALSE);}}}

/* k8505 in g189 in k8419 in k8813 in k8407 in a7597 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_8507(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8507,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8503,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* match.scm: 573  cddar */
t3=*((C_word*)lf[58]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_8461(t2,C_SCHEME_FALSE);}}

/* k8501 in k8505 in g189 in k8419 in k8813 in k8407 in a7597 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_8503(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_8461(t2,(C_word)C_i_nullp(t1));}

/* k8459 in g189 in k8419 in k8813 in k8407 in a7597 in k727 in k724 in k721 in k718 in k715 */
static void C_fcall f_8461(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8461,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8484,a[2]=((C_word*)t0)[7],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* match.scm: 575  cadar */
t4=*((C_word*)lf[56]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[7]);}
else{
/* match.scm: 577  g195 */
t2=((C_word*)t0)[2];
f_7628(t2,((C_word*)t0)[3]);}}

/* k8482 in k8459 in g189 in k8419 in k8813 in k8407 in a7597 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_8484(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8484,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8480,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* match.scm: 576  caar */
t4=*((C_word*)lf[63]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k8478 in k8482 in k8459 in g189 in k8419 in k8813 in k8407 in a7597 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_8480(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8480,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[6]);
/* match.scm: 574  g189 */
t3=((C_word*)((C_word*)t0)[5])[1];
f_8445(t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k8426 in k8419 in k8813 in k8407 in a7597 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_8428(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8428,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8432,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* match.scm: 565  cadaar */
t3=*((C_word*)lf[135]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[4]);}

/* k8430 in k8426 in k8419 in k8813 in k8407 in a7597 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_8432(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* match.scm: 565  g186 */
f_7662(((C_word*)t0)[3],((C_word*)t0)[2],t1,t2);}

/* a8358 in a7597 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_8359(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8359,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8366,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8382,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_car(t2);
/* match.scm: 469  g200 */
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}
else{
t4=t3;
f_8366(t4,C_SCHEME_FALSE);}}

/* k8380 in a8358 in a7597 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_8382(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
f_8366(t3,(C_word)C_i_pairp(t2));}
else{
t2=((C_word*)t0)[2];
f_8366(t2,C_SCHEME_FALSE);}}

/* k8364 in a8358 in a7597 in k727 in k724 in k721 in k718 in k715 */
static void C_fcall f_8366(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cddr(((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_nullp(t2));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k7701 in a7597 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_7703(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7703,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7709,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[6]);
if(C_truep((C_word)C_i_listp(t3))){
t4=(C_word)C_i_cdr(((C_word*)t0)[6]);
t5=t2;
f_7709(t5,(C_word)C_i_pairp(t4));}
else{
t4=t2;
f_7709(t4,C_SCHEME_FALSE);}}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7807,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[6]);
if(C_truep((C_word)C_i_pairp(t3))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8353,a[2]=((C_word*)t0)[6],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* match.scm: 487  caar */
t5=*((C_word*)lf[63]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[6]);}
else{
t4=t2;
f_7807(t4,C_SCHEME_FALSE);}}}

/* k8351 in k7701 in a7597 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_8353(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8353,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8349,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* match.scm: 488  cdaar */
t3=*((C_word*)lf[138]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_7807(t2,C_SCHEME_FALSE);}}

/* k8347 in k8351 in k7701 in a7597 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_8349(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8349,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8345,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* match.scm: 489  cddaar */
t3=*((C_word*)lf[137]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_7807(t2,C_SCHEME_FALSE);}}

/* k8343 in k8347 in k8351 in k7701 in a7597 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_8345(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_7807(t2,(C_word)C_i_nullp(t1));}

/* k7805 in k7701 in a7597 in k727 in k724 in k721 in k718 in k715 */
static void C_fcall f_7807(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7807,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8213,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* match.scm: 490  cdar */
t3=*((C_word*)lf[60]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[7]);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[7]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8222,a[2]=t4,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[7],a[6]=((C_word)li124),tmp=(C_word)a,a+=7,tmp));
t6=((C_word*)t4)[1];
f_8222(t6,((C_word*)t0)[5],t2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}}

/* g189 in k7805 in k7701 in a7597 in k727 in k724 in k721 in k718 in k715 */
static void C_fcall f_8222(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8222,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8235,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t6=(C_word)C_i_cdr(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_listp(t6))){
t7=(C_word)C_i_cdr(((C_word*)t0)[5]);
t8=t5;
f_8235(t8,(C_word)C_i_pairp(t7));}
else{
t7=t5;
f_8235(t7,C_SCHEME_FALSE);}}
else{
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8273,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t4,a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t6=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_pairp(t6))){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8319,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* match.scm: 553  cdar */
t8=*((C_word*)lf[60]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}
else{
t7=t5;
f_8273(t7,C_SCHEME_FALSE);}}}

/* k8317 in g189 in k7805 in k7701 in a7597 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_8319(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8319,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8315,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* match.scm: 554  cddar */
t3=*((C_word*)lf[58]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_8273(t2,C_SCHEME_FALSE);}}

/* k8313 in k8317 in g189 in k7805 in k7701 in a7597 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_8315(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_8273(t2,(C_word)C_i_nullp(t1));}

/* k8271 in g189 in k7805 in k7701 in a7597 in k727 in k724 in k721 in k718 in k715 */
static void C_fcall f_8273(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8273,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8296,a[2]=((C_word*)t0)[7],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* match.scm: 556  cadar */
t4=*((C_word*)lf[56]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[7]);}
else{
/* match.scm: 558  g195 */
t2=((C_word*)t0)[2];
f_7628(t2,((C_word*)t0)[3]);}}

/* k8294 in k8271 in g189 in k7805 in k7701 in a7597 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_8296(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8296,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8292,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* match.scm: 557  caar */
t4=*((C_word*)lf[63]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k8290 in k8294 in k8271 in g189 in k7805 in k7701 in a7597 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_8292(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8292,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[6]);
/* match.scm: 555  g189 */
t3=((C_word*)((C_word*)t0)[5])[1];
f_8222(t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k8233 in g189 in k7805 in k7701 in a7597 in k727 in k724 in k721 in k718 in k715 */
static void C_fcall f_8235(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8235,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8242,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* match.scm: 548  reverse */
t3=*((C_word*)lf[77]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}
else{
/* match.scm: 551  g195 */
t2=((C_word*)t0)[2];
f_7628(t2,((C_word*)t0)[5]);}}

/* k8240 in k8233 in g189 in k7805 in k7701 in a7597 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_8242(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8242,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8246,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* match.scm: 549  reverse */
t3=*((C_word*)lf[77]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k8244 in k8240 in k8233 in g189 in k7805 in k7701 in a7597 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_8246(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* match.scm: 548  g194 */
f_7637(((C_word*)t0)[3],((C_word*)t0)[2],t1,t2);}

/* k8211 in k7805 in k7701 in a7597 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_8213(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8213,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7819,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[7]);
if(C_truep((C_word)C_i_listp(t3))){
t4=(C_word)C_i_cdr(((C_word*)t0)[7]);
t5=t2;
f_7819(t5,(C_word)C_i_pairp(t4));}
else{
t4=t2;
f_7819(t4,C_SCHEME_FALSE);}}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7929,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8209,a[2]=((C_word*)t0)[7],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* match.scm: 505  cdar */
t4=*((C_word*)lf[60]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[7]);}}

/* k8207 in k8211 in k7805 in k7701 in a7597 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_8209(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8209,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8205,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* match.scm: 506  cadar */
t3=*((C_word*)lf[56]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_7929(t2,C_SCHEME_FALSE);}}

/* k8203 in k8207 in k8211 in k7805 in k7701 in a7597 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_8205(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8205,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8201,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* match.scm: 507  cdadar */
t3=*((C_word*)lf[59]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_7929(t2,C_SCHEME_FALSE);}}

/* k8199 in k8203 in k8207 in k8211 in k7805 in k7701 in a7597 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_8201(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8201,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8197,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* match.scm: 508  cdadar */
t3=*((C_word*)lf[59]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_7929(t2,C_SCHEME_FALSE);}}

/* k8195 in k8199 in k8203 in k8207 in k8211 in k7805 in k7701 in a7597 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_8197(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8197,2,t0,t1);}
t2=(C_word)C_i_cdr(t1);
if(C_truep((C_word)C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8189,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* match.scm: 509  cddar */
t4=*((C_word*)lf[58]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[3];
f_7929(t3,C_SCHEME_FALSE);}}

/* k8187 in k8195 in k8199 in k8203 in k8207 in k8211 in k7805 in k7701 in a7597 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_8189(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_7929(t2,(C_word)C_i_nullp(t1));}

/* k7927 in k8211 in k7805 in k7701 in a7597 in k727 in k724 in k721 in k718 in k715 */
static void C_fcall f_7929(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7929,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7935,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[6]);
if(C_truep((C_word)C_i_listp(t3))){
t4=(C_word)C_i_cdr(((C_word*)t0)[6]);
t5=t2;
f_7935(t5,(C_word)C_i_pairp(t4));}
else{
t4=t2;
f_7935(t4,C_SCHEME_FALSE);}}
else{
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8060,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[6],a[6]=((C_word)li123),tmp=(C_word)a,a+=7,tmp));
t6=((C_word*)t4)[1];
f_8060(t6,((C_word*)t0)[5],t2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}}

/* g189 in k7927 in k8211 in k7805 in k7701 in a7597 in k727 in k724 in k721 in k718 in k715 */
static void C_fcall f_8060(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8060,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8073,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t6=(C_word)C_i_cdr(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_listp(t6))){
t7=(C_word)C_i_cdr(((C_word*)t0)[5]);
t8=t5;
f_8073(t8,(C_word)C_i_pairp(t7));}
else{
t7=t5;
f_8073(t7,C_SCHEME_FALSE);}}
else{
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8111,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t4,a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t6=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_pairp(t6))){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8157,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* match.scm: 539  cdar */
t8=*((C_word*)lf[60]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}
else{
t7=t5;
f_8111(t7,C_SCHEME_FALSE);}}}

/* k8155 in g189 in k7927 in k8211 in k7805 in k7701 in a7597 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_8157(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8157,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8153,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* match.scm: 540  cddar */
t3=*((C_word*)lf[58]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_8111(t2,C_SCHEME_FALSE);}}

/* k8151 in k8155 in g189 in k7927 in k8211 in k7805 in k7701 in a7597 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_8153(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_8111(t2,(C_word)C_i_nullp(t1));}

/* k8109 in g189 in k7927 in k8211 in k7805 in k7701 in a7597 in k727 in k724 in k721 in k718 in k715 */
static void C_fcall f_8111(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8111,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8134,a[2]=((C_word*)t0)[7],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* match.scm: 542  cadar */
t4=*((C_word*)lf[56]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[7]);}
else{
/* match.scm: 544  g195 */
t2=((C_word*)t0)[2];
f_7628(t2,((C_word*)t0)[3]);}}

/* k8132 in k8109 in g189 in k7927 in k8211 in k7805 in k7701 in a7597 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_8134(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8134,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8130,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* match.scm: 543  caar */
t4=*((C_word*)lf[63]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k8128 in k8132 in k8109 in g189 in k7927 in k8211 in k7805 in k7701 in a7597 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_8130(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8130,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[6]);
/* match.scm: 541  g189 */
t3=((C_word*)((C_word*)t0)[5])[1];
f_8060(t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k8071 in g189 in k7927 in k8211 in k7805 in k7701 in a7597 in k727 in k724 in k721 in k718 in k715 */
static void C_fcall f_8073(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8073,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8080,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* match.scm: 534  reverse */
t3=*((C_word*)lf[77]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}
else{
/* match.scm: 537  g195 */
t2=((C_word*)t0)[2];
f_7628(t2,((C_word*)t0)[5]);}}

/* k8078 in k8071 in g189 in k7927 in k8211 in k7805 in k7701 in a7597 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_8080(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8080,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8084,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* match.scm: 535  reverse */
t3=*((C_word*)lf[77]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k8082 in k8078 in k8071 in g189 in k7927 in k8211 in k7805 in k7701 in a7597 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_8084(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* match.scm: 534  g194 */
f_7637(((C_word*)t0)[3],((C_word*)t0)[2],t1,t2);}

/* k7933 in k7927 in k8211 in k7805 in k7701 in a7597 in k727 in k724 in k721 in k718 in k715 */
static void C_fcall f_7935(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7935,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7942,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* match.scm: 511  caaar */
t3=*((C_word*)lf[136]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7971,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=((C_word)li122),tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_7971(t6,((C_word*)t0)[4],t2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}}

/* g189 in k7933 in k7927 in k8211 in k7805 in k7701 in a7597 in k727 in k724 in k721 in k718 in k715 */
static void C_fcall f_7971(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7971,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
/* match.scm: 520  g195 */
t5=((C_word*)t0)[3];
f_7628(t5,t1);}
else{
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7987,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t4,a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t6=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_pairp(t6))){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8033,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* match.scm: 522  cdar */
t8=*((C_word*)lf[60]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}
else{
t7=t5;
f_7987(t7,C_SCHEME_FALSE);}}}

/* k8031 in g189 in k7933 in k7927 in k8211 in k7805 in k7701 in a7597 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_8033(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8033,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8029,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* match.scm: 523  cddar */
t3=*((C_word*)lf[58]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_7987(t2,C_SCHEME_FALSE);}}

/* k8027 in k8031 in g189 in k7933 in k7927 in k8211 in k7805 in k7701 in a7597 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_8029(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_7987(t2,(C_word)C_i_nullp(t1));}

/* k7985 in g189 in k7933 in k7927 in k8211 in k7805 in k7701 in a7597 in k727 in k724 in k721 in k718 in k715 */
static void C_fcall f_7987(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7987,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8010,a[2]=((C_word*)t0)[7],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* match.scm: 525  cadar */
t4=*((C_word*)lf[56]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[7]);}
else{
/* match.scm: 527  g195 */
t2=((C_word*)t0)[2];
f_7628(t2,((C_word*)t0)[3]);}}

/* k8008 in k7985 in g189 in k7933 in k7927 in k8211 in k7805 in k7701 in a7597 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_8010(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8010,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8006,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* match.scm: 526  caar */
t4=*((C_word*)lf[63]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k8004 in k8008 in k7985 in g189 in k7933 in k7927 in k8211 in k7805 in k7701 in a7597 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_8006(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8006,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[6]);
/* match.scm: 524  g189 */
t3=((C_word*)((C_word*)t0)[5])[1];
f_7971(t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k7940 in k7933 in k7927 in k8211 in k7805 in k7701 in a7597 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_7942(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7942,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7946,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* match.scm: 512  cadaar */
t3=*((C_word*)lf[135]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[4]);}

/* k7944 in k7940 in k7933 in k7927 in k8211 in k7805 in k7701 in a7597 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_7946(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7946,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7950,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* match.scm: 513  caadar */
t3=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}

/* k7948 in k7944 in k7940 in k7933 in k7927 in k8211 in k7805 in k7701 in a7597 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_7950(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7950,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7962,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* match.scm: 514  cdadar */
t3=*((C_word*)lf[59]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[6]);}

/* k7960 in k7948 in k7944 in k7940 in k7933 in k7927 in k8211 in k7805 in k7701 in a7597 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_7962(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7962,2,t0,t1);}
t2=(C_word)C_i_car(t1);
t3=(C_word)C_i_cdr(((C_word*)t0)[7]);
/* match.scm: 511  g199 */
t4=((C_word*)t0)[6];
((C_proc2)C_retrieve_proc(t4))(2,t4,f_7603(C_a_i(&a,27),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2,t3));}

/* k7817 in k8211 in k7805 in k7701 in a7597 in k727 in k724 in k721 in k718 in k715 */
static void C_fcall f_7819(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7819,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7826,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* match.scm: 492  caaar */
t3=*((C_word*)lf[136]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7843,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=((C_word)li121),tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_7843(t6,((C_word*)t0)[3],t2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}}

/* g189 in k7817 in k8211 in k7805 in k7701 in a7597 in k727 in k724 in k721 in k718 in k715 */
static void C_fcall f_7843(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7843,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
/* match.scm: 497  g195 */
t5=((C_word*)t0)[3];
f_7628(t5,t1);}
else{
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7859,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t4,a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t6=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_pairp(t6))){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7905,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* match.scm: 499  cdar */
t8=*((C_word*)lf[60]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}
else{
t7=t5;
f_7859(t7,C_SCHEME_FALSE);}}}

/* k7903 in g189 in k7817 in k8211 in k7805 in k7701 in a7597 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_7905(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7905,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7901,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* match.scm: 500  cddar */
t3=*((C_word*)lf[58]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_7859(t2,C_SCHEME_FALSE);}}

/* k7899 in k7903 in g189 in k7817 in k8211 in k7805 in k7701 in a7597 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_7901(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_7859(t2,(C_word)C_i_nullp(t1));}

/* k7857 in g189 in k7817 in k8211 in k7805 in k7701 in a7597 in k727 in k724 in k721 in k718 in k715 */
static void C_fcall f_7859(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7859,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7882,a[2]=((C_word*)t0)[7],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* match.scm: 502  cadar */
t4=*((C_word*)lf[56]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[7]);}
else{
/* match.scm: 504  g195 */
t2=((C_word*)t0)[2];
f_7628(t2,((C_word*)t0)[3]);}}

/* k7880 in k7857 in g189 in k7817 in k8211 in k7805 in k7701 in a7597 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_7882(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7882,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7878,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* match.scm: 503  caar */
t4=*((C_word*)lf[63]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k7876 in k7880 in k7857 in g189 in k7817 in k8211 in k7805 in k7701 in a7597 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_7878(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7878,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[6]);
/* match.scm: 501  g189 */
t3=((C_word*)((C_word*)t0)[5])[1];
f_7843(t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k7824 in k7817 in k8211 in k7805 in k7701 in a7597 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_7826(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7826,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7830,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* match.scm: 492  cadaar */
t3=*((C_word*)lf[135]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[4]);}

/* k7828 in k7824 in k7817 in k8211 in k7805 in k7701 in a7597 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_7830(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* match.scm: 492  g186 */
f_7662(((C_word*)t0)[3],((C_word*)t0)[2],t1,t2);}

/* k7707 in k7701 in a7597 in k727 in k724 in k721 in k718 in k715 */
static void C_fcall f_7709(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7709,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[120],((C_word*)t0)[3]));}
else{
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7721,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=((C_word)li120),tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_7721(t6,((C_word*)t0)[4],t2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}}

/* g189 in k7707 in k7701 in a7597 in k727 in k724 in k721 in k718 in k715 */
static void C_fcall f_7721(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7721,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
/* match.scm: 478  g195 */
t5=((C_word*)t0)[3];
f_7628(t5,t1);}
else{
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7737,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t4,a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t6=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_pairp(t6))){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7783,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* match.scm: 480  cdar */
t8=*((C_word*)lf[60]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}
else{
t7=t5;
f_7737(t7,C_SCHEME_FALSE);}}}

/* k7781 in g189 in k7707 in k7701 in a7597 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_7783(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7783,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7779,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* match.scm: 481  cddar */
t3=*((C_word*)lf[58]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_7737(t2,C_SCHEME_FALSE);}}

/* k7777 in k7781 in g189 in k7707 in k7701 in a7597 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_7779(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_7737(t2,(C_word)C_i_nullp(t1));}

/* k7735 in g189 in k7707 in k7701 in a7597 in k727 in k724 in k721 in k718 in k715 */
static void C_fcall f_7737(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7737,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7760,a[2]=((C_word*)t0)[7],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* match.scm: 483  cadar */
t4=*((C_word*)lf[56]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[7]);}
else{
/* match.scm: 485  g195 */
t2=((C_word*)t0)[2];
f_7628(t2,((C_word*)t0)[3]);}}

/* k7758 in k7735 in g189 in k7707 in k7701 in a7597 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_7760(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7760,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7756,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* match.scm: 484  caar */
t4=*((C_word*)lf[63]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k7754 in k7758 in k7735 in g189 in k7707 in k7701 in a7597 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_7756(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7756,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[6]);
/* match.scm: 482  g189 */
t3=((C_word*)((C_word*)t0)[5])[1];
f_7721(t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* g186 in a7597 in k727 in k724 in k721 in k718 in k715 */
static void C_fcall f_7662(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7662,NULL,4,t1,t2,t3,t4);}
t5=(C_word)C_a_i_list(&a,2,t2,t3);
t6=(C_word)C_a_i_list(&a,1,t5);
t7=(C_word)C_a_i_cons(&a,2,t6,t4);
t8=(C_word)C_a_i_cons(&a,2,lf[133],t7);
t9=(C_word)C_i_cadr(*((C_word*)lf[125]+1));
t10=t9;
((C_proc6)C_retrieve_proc(t10))(6,t10,t1,t2,t3,t4,t8);}

/* g194 in a7597 in k727 in k724 in k721 in k718 in k715 */
static void C_fcall f_7637(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7637,NULL,4,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7657,a[2]=t1,a[3]=t4,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* match.scm: 456  list->vector */
t6=*((C_word*)lf[98]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k7655 in g194 in a7597 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_7657(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7657,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[104],((C_word*)t0)[4]);
t3=(C_word)C_a_i_list(&a,2,t1,t2);
t4=(C_word)C_a_i_list(&a,1,t3);
t5=(C_word)C_a_i_cons(&a,2,t4,((C_word*)t0)[3]);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[133],t5));}

/* g195 in a7597 in k727 in k724 in k721 in k718 in k715 */
static void C_fcall f_7628(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7628,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[133],((C_word*)t0)[2]);
/* match.scm: 451  ##match#syntax-err */
t3=*((C_word*)lf[1]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,lf[134]);}

/* g199 in a7597 in k727 in k724 in k721 in k718 in k715 */
static C_word C_fcall f_7603(C_word *a,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_stack_check;
t6=(C_word)C_a_i_cons(&a,2,t1,t3);
t7=(C_word)C_a_i_list(&a,3,lf[76],t2,t4);
t8=(C_word)C_a_i_list(&a,2,t6,t7);
t9=(C_word)C_a_i_list(&a,1,t8);
t10=(C_word)C_a_i_cons(&a,2,t9,t5);
return((C_word)C_a_i_cons(&a,2,lf[133],t10));}

/* k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_732(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_732,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_735,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7495,a[2]=((C_word)li115),tmp=(C_word)a,a+=3,tmp);
/* match.scm: 634  ##sys#register-macro-2 */
t4=*((C_word*)lf[132]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[130],t3);}

/* a7494 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_7495(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7495,3,t0,t1,t2);}
t3=(C_word)C_i_cadddr(*((C_word*)lf[125]+1));
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7500,a[2]=t2,a[3]=((C_word)li114),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7520,a[2]=t4,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_i_car(t2);
/* match.scm: 642  g210 */
t7=t3;
((C_proc3)C_retrieve_proc(t7))(3,t7,t5,t6);}
else{
/* match.scm: 655  g209 */
t5=t4;
f_7500(t5,t1);}}

/* k7518 in a7494 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_7520(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7520,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7526,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t3))){
t4=(C_word)C_i_cddr(((C_word*)t0)[4]);
t5=t2;
f_7526(t5,(C_word)C_i_nullp(t4));}
else{
t4=t2;
f_7526(t4,C_SCHEME_FALSE);}}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7556,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t3))){
t4=(C_word)C_i_cddr(((C_word*)t0)[4]);
t5=t2;
f_7556(t5,(C_word)C_i_nullp(t4));}
else{
t4=t2;
f_7556(t4,C_SCHEME_FALSE);}}}

/* k7554 in k7518 in a7494 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_fcall f_7556(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7556,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
t4=(C_word)C_a_i_cons(&a,2,lf[130],((C_word*)t0)[4]);
t5=(C_word)C_i_caddr(*((C_word*)lf[125]+1));
t6=t5;
((C_proc5)C_retrieve_proc(t6))(5,t6,((C_word*)t0)[3],t2,t3,t4);}
else{
/* match.scm: 654  g209 */
t2=((C_word*)t0)[2];
f_7500(t2,((C_word*)t0)[3]);}}

/* k7524 in k7518 in a7494 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_fcall f_7526(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7526,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_cons(&a,2,lf[124],((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[122],t2));}
else{
/* match.scm: 645  g209 */
t2=((C_word*)t0)[2];
f_7500(t2,((C_word*)t0)[3]);}}

/* g209 in a7494 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_fcall f_7500(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7500,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[130],((C_word*)t0)[2]);
/* match.scm: 638  ##match#syntax-err */
t3=*((C_word*)lf[1]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,lf[131]);}

/* k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_735(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word ab[155],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_735,2,t0,t1);}
t2=C_mutate((C_word*)lf[1]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_737,a[2]=((C_word)li1),tmp=(C_word)a,a+=3,tmp));
t3=C_mutate((C_word*)lf[4]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_743,a[2]=((C_word)li2),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[6]+1,lf[7]);
t5=C_mutate((C_word*)lf[8]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_748,a[2]=((C_word)li3),tmp=(C_word)a,a+=3,tmp));
t6=(C_word)C_a_i_cons(&a,2,lf[9],lf[10]);
t7=C_mutate((C_word*)lf[11]+1,t6);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7371,a[2]=((C_word)li5),tmp=(C_word)a,a+=3,tmp);
t9=lf[16];
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7106,a[2]=t9,a[3]=((C_word)li6),tmp=(C_word)a,a+=4,tmp);
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6801,a[2]=t9,a[3]=t8,a[4]=((C_word)li8),tmp=(C_word)a,a+=5,tmp);
t12=lf[35];
t13=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6767,a[2]=t12,a[3]=((C_word)li9),tmp=(C_word)a,a+=4,tmp);
t14=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6734,a[2]=t12,a[3]=((C_word)li10),tmp=(C_word)a,a+=4,tmp);
t15=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6724,a[2]=((C_word)li11),tmp=(C_word)a,a+=3,tmp);
t16=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6638,a[2]=((C_word)li12),tmp=(C_word)a,a+=3,tmp);
t17=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6328,a[2]=t15,a[3]=t16,a[4]=((C_word)li16),tmp=(C_word)a,a+=5,tmp);
t18=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6197,a[2]=t14,a[3]=t13,a[4]=((C_word)li18),tmp=(C_word)a,a+=5,tmp);
t19=C_SCHEME_UNDEFINED;
t20=(*a=C_VECTOR_TYPE|1,a[1]=t19,tmp=(C_word)a,a+=2,tmp);
t21=C_set_block_item(t20,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5303,a[2]=t18,a[3]=t20,a[4]=((C_word)li19),tmp=(C_word)a,a+=5,tmp));
t22=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5121,a[2]=t17,a[3]=t20,a[4]=((C_word)li20),tmp=(C_word)a,a+=5,tmp);
t23=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1327,a[2]=((C_word)li21),tmp=(C_word)a,a+=3,tmp);
t24=C_SCHEME_UNDEFINED;
t25=(*a=C_VECTOR_TYPE|1,a[1]=t24,tmp=(C_word)a,a+=2,tmp);
t26=C_set_block_item(t25,0,(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3848,a[2]=t14,a[3]=t13,a[4]=t23,a[5]=t20,a[6]=t10,a[7]=t11,a[8]=t8,a[9]=t22,a[10]=t25,a[11]=((C_word)li51),tmp=(C_word)a,a+=12,tmp));
t27=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3464,a[2]=((C_word)li58),tmp=(C_word)a,a+=3,tmp);
t28=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2568,a[2]=t23,a[3]=((C_word)li85),tmp=(C_word)a,a+=4,tmp);
t29=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1301,a[2]=t23,a[3]=((C_word)li86),tmp=(C_word)a,a+=4,tmp);
t30=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1503,a[2]=t23,a[3]=t29,a[4]=((C_word)li93),tmp=(C_word)a,a+=5,tmp);
t31=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1473,a[2]=((C_word)li95),tmp=(C_word)a,a+=3,tmp);
t32=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1395,a[2]=((C_word)li99),tmp=(C_word)a,a+=3,tmp);
t33=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_757,a[2]=t32,a[3]=t30,a[4]=t28,a[5]=t25,a[6]=t31,a[7]=t27,a[8]=((C_word)li101),tmp=(C_word)a,a+=9,tmp);
t34=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_969,a[2]=t32,a[3]=t30,a[4]=t28,a[5]=t25,a[6]=t31,a[7]=((C_word)li105),tmp=(C_word)a,a+=8,tmp);
t35=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1125,a[2]=t32,a[3]=t30,a[4]=t28,a[5]=t25,a[6]=t31,a[7]=t27,a[8]=((C_word)li109),tmp=(C_word)a,a+=9,tmp);
t36=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7406,a[2]=((C_word)li110),tmp=(C_word)a,a+=3,tmp);
t37=C_SCHEME_UNDEFINED;
t38=(*a=C_VECTOR_TYPE|1,a[1]=t37,tmp=(C_word)a,a+=2,tmp);
t39=C_set_block_item(t38,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7429,a[2]=t38,a[3]=((C_word)li111),tmp=(C_word)a,a+=4,tmp));
t40=(C_word)C_a_i_list(&a,4,t33,t34,t35,t29);
t41=C_mutate((C_word*)lf[125]+1,t40);
t42=C_mutate((C_word*)lf[126]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7460,a[2]=((C_word)li112),tmp=(C_word)a,a+=3,tmp));
t43=C_mutate((C_word*)lf[127]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7476,a[2]=((C_word)li113),tmp=(C_word)a,a+=3,tmp));
t44=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7493,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* match.scm: 2218 register-feature! */
t45=*((C_word*)lf[128]+1);
((C_proc3)C_retrieve_proc(t45))(3,t45,t44,lf[129]);}

/* k7491 in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_7493(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* match-error-procedure in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_7476(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2rv,(void*)f_7476r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_7476r(t0,t1,t2);}}

static void C_ccall f_7476r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
if(C_truep((C_word)C_notvemptyp(t2))){
t3=(C_word)C_i_vector_ref(t2,C_fix(0));
/* match.scm: 2215 ##match#set-error */
t4=*((C_word*)lf[4]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,*((C_word*)lf[5]+1));}}

/* match-error-control in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_7460(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2rv,(void*)f_7460r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_7460r(t0,t1,t2);}}

static void C_ccall f_7460r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
if(C_truep((C_word)C_notvemptyp(t2))){
t3=(C_word)C_i_vector_ref(t2,C_fix(0));
/* match.scm: 2210 ##match#set-error-control */
t4=*((C_word*)lf[8]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,*((C_word*)lf[6]+1));}}

/* rdc in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_fcall f_7429(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_7429,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7447,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(t2);
/* match.scm: 2205 rdc */
t8=t5;
t9=t6;
t1=t8;
t2=t9;
goto loop;}}

/* k7445 in rdc in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_7447(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7447,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* rac in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static C_word C_fcall f_7406(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
loop:
C_stack_check;
t2=(C_word)C_i_cdr(t1);
if(C_truep((C_word)C_i_nullp(t2))){
return((C_word)C_i_car(t1));}
else{
t3=(C_word)C_i_cdr(t1);
t5=t3;
t1=t5;
goto loop;}}

/* gendefine in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_1125(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1125,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_1129,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t4,a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=t3,a[11]=t1,tmp=(C_word)a,a+=12,tmp);
/* match.scm: 770  gensym */
t6=*((C_word*)lf[95]+1);
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}

/* k1127 in gendefine in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_1129(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1129,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_1132,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=t1,a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
/* match.scm: 771  error-maker */
f_1395(t2,((C_word*)t0)[7]);}

/* k1130 in k1127 in gendefine in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_1132(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1132,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1135,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=t1,a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1299,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* match.scm: 772  validate-pattern */
t4=((C_word*)t0)[3];
f_1503(t4,t3,((C_word*)t0)[2]);}

/* k1297 in k1130 in k1127 in gendefine in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_1299(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* match.scm: 772  bound */
t2=((C_word*)t0)[3];
f_2568(t2,((C_word*)t0)[2],t1);}

/* k1133 in k1130 in k1127 in gendefine in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_1135(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1135,2,t0,t1);}
t2=(C_word)C_i_car(t1);
t3=(C_word)C_i_cadr(t1);
t4=(C_word)C_i_caddr(t1);
t5=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_1147,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t4,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=t3,a[12]=t2,tmp=(C_word)a,a+=13,tmp);
/* match.scm: 776  gensym */
t6=*((C_word*)lf[95]+1);
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}

/* k1145 in k1133 in k1130 in k1127 in gendefine in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_1147(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[32],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1147,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,5,((C_word*)t0)[12],t1,((C_word*)t0)[11],C_SCHEME_FALSE,C_SCHEME_FALSE);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_1153,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=t1,a[11]=((C_word*)t0)[8],a[12]=((C_word*)t0)[9],a[13]=((C_word*)t0)[10],tmp=(C_word)a,a+=14,tmp);
/* match.scm: 778  gensym */
t5=*((C_word*)lf[95]+1);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k1151 in k1145 in k1133 in k1130 in k1127 in gendefine in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_1153(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1153,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_1156,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=t1,a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[8]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1291,a[2]=((C_word*)t0)[12],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=t2,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
/* match.scm: 784  gensym */
t5=*((C_word*)lf[95]+1);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k1289 in k1151 in k1145 in k1133 in k1130 in k1127 in gendefine in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_1291(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* match.scm: 779  gen */
t2=((C_word*)((C_word*)t0)[7])[1];
f_3848(t2,((C_word*)t0)[6],((C_word*)t0)[5],C_SCHEME_END_OF_LIST,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1154 in k1151 in k1145 in k1133 in k1130 in k1127 in gendefine in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_1156(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1156,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_1159,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],tmp=(C_word)a,a+=15,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1279,a[2]=((C_word)li108),tmp=(C_word)a,a+=3,tmp);
/* map */
t4=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[5]);}

/* a1278 in k1154 in k1151 in k1145 in k1133 in k1130 in k1127 in gendefine in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_1279(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1279,3,t0,t1,t2);}
/* match.scm: 785  gensym */
t3=*((C_word*)lf[95]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,t1);}

/* k1157 in k1154 in k1151 in k1145 in k1133 in k1130 in k1127 in gendefine in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_1159(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1159,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_1162,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=t1,a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[14],tmp=(C_word)a,a+=13,tmp);
/* match.scm: 786  unreachable */
f_1473(t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1160 in k1157 in k1154 in k1151 in k1145 in k1133 in k1130 in k1127 in gendefine in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_1162(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1162,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1169,a[2]=((C_word*)t0)[12],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_1173,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=t2,tmp=(C_word)a,a+=13,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1273,a[2]=((C_word)li107),tmp=(C_word)a,a+=3,tmp);
/* map */
t5=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a1272 in k1160 in k1157 in k1154 in k1151 in k1145 in k1133 in k1130 in k1127 in gendefine in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_1273(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1273,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,3,lf[124],t2,C_SCHEME_FALSE));}

/* k1171 in k1160 in k1157 in k1154 in k1151 in k1145 in k1133 in k1130 in k1127 in gendefine in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_1173(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[72],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1173,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1181,a[2]=t1,a[3]=((C_word*)t0)[12],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_a_i_list(&a,1,lf[116]);
t4=(C_word)C_a_i_list(&a,1,lf[117]);
t5=(C_word)C_a_i_list(&a,2,lf[118],lf[117]);
t6=(C_word)C_a_i_list(&a,3,lf[80],t5,lf[116]);
t7=(C_word)C_a_i_list(&a,3,lf[19],t4,t6);
t8=(C_word)C_a_i_list(&a,3,lf[19],t3,t7);
t9=(C_word)C_a_i_list(&a,2,((C_word*)t0)[11],t8);
t10=(C_word)C_a_i_list(&a,2,((C_word*)t0)[10],((C_word*)t0)[9]);
t11=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1229,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t9,a[8]=t10,a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp);
t12=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1233,a[2]=t11,tmp=(C_word)a,a+=3,tmp);
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1243,a[2]=((C_word)li106),tmp=(C_word)a,a+=3,tmp);
/* match.scm: 795  map */
t14=*((C_word*)lf[75]+1);
((C_proc5)(void*)(*((C_word*)t14+1)))(5,t14,t12,t13,((C_word*)t0)[2],((C_word*)t0)[8]);}

/* a1242 in k1171 in k1160 in k1157 in k1154 in k1151 in k1145 in k1133 in k1130 in k1127 in gendefine in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_1243(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1243,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[89],t2,t3));}

/* k1231 in k1171 in k1160 in k1157 in k1154 in k1151 in k1145 in k1133 in k1130 in k1127 in gendefine in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_1233(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1233,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,lf[123]);
t3=(C_word)C_a_i_list(&a,1,t2);
/* match.scm: 676  ##sys#append */
t4=*((C_word*)lf[121]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[2],t1,t3);}

/* k1227 in k1171 in k1160 in k1157 in k1154 in k1151 in k1145 in k1133 in k1130 in k1127 in gendefine in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_1229(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1229,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[19],t2);
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[9],t3);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1213,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=t4,tmp=(C_word)a,a+=8,tmp);
t6=(C_word)C_i_car(((C_word*)t0)[3]);
/* match.scm: 676  ##sys#append */
t7=*((C_word*)lf[121]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,((C_word*)t0)[2],t6);}

/* k1211 in k1227 in k1171 in k1160 in k1157 in k1154 in k1151 in k1145 in k1133 in k1130 in k1127 in gendefine in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_1213(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1213,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t3);
t5=(C_word)C_a_i_list(&a,3,lf[20],t4,((C_word*)t0)[4]);
/* match.scm: 788  inline-let */
f_3464(((C_word*)t0)[2],t5);}

/* k1179 in k1171 in k1160 in k1157 in k1154 in k1151 in k1145 in k1133 in k1130 in k1127 in gendefine in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_1181(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1181,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* match.scm: 676  ##sys#append */
t3=*((C_word*)lf[121]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k1167 in k1160 in k1157 in k1154 in k1151 in k1145 in k1133 in k1130 in k1127 in gendefine in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_1169(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1169,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[122],t1));}

/* genletrec in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_969(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_969,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_973,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t5,a[8]=((C_word*)t0)[6],a[9]=t4,a[10]=t3,a[11]=t1,tmp=(C_word)a,a+=12,tmp);
/* match.scm: 738  gensym */
t7=*((C_word*)lf[95]+1);
((C_proc2)C_retrieve_proc(t7))(2,t7,t6);}

/* k971 in genletrec in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_973(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_973,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_976,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=t1,tmp=(C_word)a,a+=12,tmp);
/* match.scm: 739  error-maker */
f_1395(t2,((C_word*)t0)[7]);}

/* k974 in k971 in genletrec in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_976(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_976,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_979,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=t1,a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1123,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* match.scm: 740  validate-pattern */
t4=((C_word*)t0)[3];
f_1503(t4,t3,((C_word*)t0)[2]);}

/* k1121 in k974 in k971 in genletrec in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_1123(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* match.scm: 740  bound */
t2=((C_word*)t0)[3];
f_2568(t2,((C_word*)t0)[2],t1);}

/* k977 in k974 in k971 in genletrec in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_979(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_979,2,t0,t1);}
t2=(C_word)C_i_car(t1);
t3=(C_word)C_i_cadr(t1);
t4=(C_word)C_i_caddr(t1);
t5=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_991,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t4,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=t3,a[12]=t2,tmp=(C_word)a,a+=13,tmp);
/* match.scm: 744  gensym */
t6=*((C_word*)lf[95]+1);
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}

/* k989 in k977 in k974 in k971 in genletrec in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_991(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[32],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_991,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,5,((C_word*)t0)[12],t1,((C_word*)t0)[11],C_SCHEME_FALSE,C_SCHEME_FALSE);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_997,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=t1,a[11]=((C_word*)t0)[8],a[12]=((C_word*)t0)[9],a[13]=((C_word*)t0)[10],tmp=(C_word)a,a+=14,tmp);
/* match.scm: 746  gensym */
t5=*((C_word*)lf[95]+1);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k995 in k989 in k977 in k974 in k971 in genletrec in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_997(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_997,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_1000,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=t1,a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[9]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1115,a[2]=((C_word*)t0)[13],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=t2,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
/* match.scm: 752  gensym */
t5=*((C_word*)lf[95]+1);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k1113 in k995 in k989 in k977 in k974 in k971 in genletrec in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_1115(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* match.scm: 747  gen */
t2=((C_word*)((C_word*)t0)[7])[1];
f_3848(t2,((C_word*)t0)[6],((C_word*)t0)[5],C_SCHEME_END_OF_LIST,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k998 in k995 in k989 in k977 in k974 in k971 in genletrec in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_1000(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1000,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_1003,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=t1,a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],tmp=(C_word)a,a+=15,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1103,a[2]=((C_word)li104),tmp=(C_word)a,a+=3,tmp);
/* map */
t4=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[5]);}

/* a1102 in k998 in k995 in k989 in k977 in k974 in k971 in genletrec in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_1103(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1103,3,t0,t1,t2);}
/* match.scm: 753  gensym */
t3=*((C_word*)lf[95]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,t1);}

/* k1001 in k998 in k995 in k989 in k977 in k974 in k971 in genletrec in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_1003(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1003,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_1006,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=t1,a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[14],tmp=(C_word)a,a+=13,tmp);
/* match.scm: 754  unreachable */
f_1473(t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1004 in k1001 in k998 in k995 in k989 in k977 in k974 in k971 in genletrec in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_1006(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[64],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1006,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,lf[116]);
t3=(C_word)C_a_i_list(&a,1,lf[117]);
t4=(C_word)C_a_i_list(&a,2,lf[118],lf[117]);
t5=(C_word)C_a_i_list(&a,3,lf[80],t4,lf[116]);
t6=(C_word)C_a_i_list(&a,3,lf[19],t3,t5);
t7=(C_word)C_a_i_list(&a,3,lf[19],t2,t6);
t8=(C_word)C_a_i_list(&a,2,((C_word*)t0)[12],t7);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1021,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],a[4]=t8,tmp=(C_word)a,a+=5,tmp);
t10=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1025,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t9,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1073,a[2]=((C_word)li103),tmp=(C_word)a,a+=3,tmp);
/* map */
t12=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t10,t11,((C_word*)t0)[2]);}

/* a1072 in k1004 in k1001 in k998 in k995 in k989 in k977 in k974 in k971 in genletrec in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_1073(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1073,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,t2,C_SCHEME_FALSE));}

/* k1023 in k1004 in k1001 in k998 in k995 in k989 in k977 in k974 in k971 in genletrec in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_1025(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1025,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[10],((C_word*)t0)[9]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1061,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1065,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1067,a[2]=((C_word)li102),tmp=(C_word)a,a+=3,tmp);
/* match.scm: 761  map */
t6=*((C_word*)lf[75]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t4,t5,((C_word*)t0)[2],((C_word*)t0)[8]);}

/* a1066 in k1023 in k1004 in k1001 in k998 in k995 in k989 in k977 in k974 in k971 in genletrec in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_1067(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1067,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[89],t2,t3));}

/* k1063 in k1023 in k1004 in k1001 in k998 in k995 in k989 in k977 in k974 in k971 in genletrec in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_1065(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* match.scm: 676  ##sys#append */
t2=*((C_word*)lf[121]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k1059 in k1023 in k1004 in k1001 in k998 in k995 in k989 in k977 in k974 in k971 in genletrec in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_1061(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1061,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[19],t2);
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[7],t3);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1045,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_i_car(((C_word*)t0)[3]);
/* match.scm: 676  ##sys#append */
t7=*((C_word*)lf[121]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,((C_word*)t0)[2],t6);}

/* k1043 in k1059 in k1023 in k1004 in k1001 in k998 in k995 in k989 in k977 in k974 in k971 in genletrec in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_1045(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1045,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
/* match.scm: 676  ##sys#append */
t4=*((C_word*)lf[121]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* k1019 in k1004 in k1001 in k998 in k995 in k989 in k977 in k974 in k971 in genletrec in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_1021(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1021,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,3,lf[120],t2,((C_word*)t0)[2]));}

/* genmatch in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_757(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_757,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_761,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t2,a[7]=((C_word*)t0)[5],a[8]=t4,a[9]=((C_word*)t0)[6],a[10]=t1,a[11]=((C_word*)t0)[7],tmp=(C_word)a,a+=12,tmp);
/* match.scm: 678  gensym */
t6=*((C_word*)lf[95]+1);
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}

/* k759 in genmatch in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_761(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_761,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_764,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=t1,tmp=(C_word)a,a+=12,tmp);
/* match.scm: 679  error-maker */
f_1395(t2,((C_word*)t0)[8]);}

/* k762 in k759 in genmatch in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_764(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_764,2,t0,t1);}
t2=(C_word)C_i_car(t1);
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_770,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t1,a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=t4,a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_825,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=((C_word)li100),tmp=(C_word)a,a+=6,tmp);
/* map */
t7=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,((C_word*)t0)[2]);}

/* a824 in k762 in k759 in genmatch in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_825(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_825,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_829,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_963,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_car(t2);
/* match.scm: 683  validate-pattern */
t6=((C_word*)t0)[2];
f_1503(t6,t4,t5);}

/* k961 in a824 in k762 in k759 in genmatch in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_963(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* match.scm: 682  bound */
t2=((C_word*)t0)[3];
f_2568(t2,((C_word*)t0)[2],t1);}

/* k827 in a824 in k762 in k759 in genmatch in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_829(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_829,2,t0,t1);}
t2=(C_word)C_i_car(t1);
t3=(C_word)C_i_cadr(t1);
t4=(C_word)C_i_caddr(t1);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_841,a[2]=t4,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t3,tmp=(C_word)a,a+=8,tmp);
/* match.scm: 688  gensym */
t6=*((C_word*)lf[95]+1);
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}

/* k839 in k827 in a824 in k762 in k759 in genmatch in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_841(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_841,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_844,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[6]);
if(C_truep((C_word)C_i_pairp(t3))){
t4=(C_word)C_i_cadr(((C_word*)t0)[6]);
if(C_truep((C_word)C_i_pairp(t4))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_951,a[2]=t2,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* match.scm: 693  caadr */
t6=*((C_word*)lf[62]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[6]);}
else{
t5=t2;
f_844(2,t5,C_SCHEME_FALSE);}}
else{
t4=t2;
f_844(2,t4,C_SCHEME_FALSE);}}

/* k949 in k839 in k827 in a824 in k762 in k759 in genmatch in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_951(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_951,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[119]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_947,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* match.scm: 697  cadadr */
t4=*((C_word*)lf[55]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[3]);}
else{
t3=((C_word*)t0)[2];
f_844(2,t3,C_SCHEME_FALSE);}}

/* k945 in k949 in k839 in k827 in a824 in k762 in k759 in genmatch in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_947(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_947,2,t0,t1);}
if(C_truep((C_word)C_i_symbolp(t1))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_943,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* match.scm: 699  cdadr */
t3=*((C_word*)lf[61]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}
else{
t2=((C_word*)t0)[2];
f_844(2,t2,C_SCHEME_FALSE);}}

/* k941 in k945 in k949 in k839 in k827 in a824 in k762 in k759 in genmatch in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_943(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_943,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_939,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* match.scm: 701  cddadr */
t3=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}
else{
t2=((C_word*)t0)[2];
f_844(2,t2,C_SCHEME_FALSE);}}

/* k937 in k941 in k945 in k949 in k839 in k827 in a824 in k762 in k759 in genmatch in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_939(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep((C_word)C_i_nullp(t1))){
t2=(C_word)C_i_cddr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t2))){
/* match.scm: 704  cadadr */
t3=*((C_word*)lf[55]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],((C_word*)t0)[3]);}
else{
t3=((C_word*)t0)[2];
f_844(2,t3,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[2];
f_844(2,t2,C_SCHEME_FALSE);}}

/* k842 in k839 in k827 in a824 in k762 in k759 in genmatch in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_844(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_844,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[8]):((C_word*)t0)[8]);
t3=(C_truep(t1)?(C_word)C_i_cddr(((C_word*)t0)[7]):(C_word)C_i_cdr(((C_word*)t0)[7]));
t4=(C_word)C_a_i_cons(&a,2,t2,t3);
t5=(C_word)C_a_i_cons(&a,2,lf[19],t4);
t6=(C_word)C_a_i_list(&a,2,((C_word*)t0)[6],t5);
t7=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_872,a[2]=t1,a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=t6,tmp=(C_word)a,a+=9,tmp);
/* match.scm: 715  append */
t8=*((C_word*)lf[66]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,((C_word*)t0)[2],((C_word*)((C_word*)t0)[5])[1]);}

/* k870 in k842 in k839 in k827 in a824 in k762 in k759 in genmatch in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_872(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_872,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
t3=C_mutate(((C_word *)((C_word*)t0)[7])+1,t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_861,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[2])){
/* match.scm: 721  gensym */
t5=*((C_word*)lf[95]+1);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}
else{
t5=t4;
f_861(2,t5,C_SCHEME_FALSE);}}

/* k859 in k870 in k842 in k839 in k827 in a824 in k762 in k759 in genmatch in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_861(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_861,2,t0,t1);}
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,5,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1,C_SCHEME_FALSE));}

/* k768 in k762 in k759 in genmatch in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_770(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_770,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_773,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_823,a[2]=((C_word*)t0)[10],a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=t2,a[7]=((C_word*)t0)[3],tmp=(C_word)a,a+=8,tmp);
/* match.scm: 729  gensym */
t5=*((C_word*)lf[95]+1);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k821 in k768 in k762 in k759 in genmatch in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_823(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* match.scm: 724  gen */
t2=((C_word*)((C_word*)t0)[7])[1];
f_3848(t2,((C_word*)t0)[6],((C_word*)t0)[5],C_SCHEME_END_OF_LIST,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k771 in k768 in k762 in k759 in genmatch in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_773(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_773,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_776,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t1,a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
/* match.scm: 730  unreachable */
f_1473(t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k774 in k771 in k768 in k762 in k759 in genmatch in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_776(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[57],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_776,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,lf[116]);
t3=(C_word)C_a_i_list(&a,1,lf[117]);
t4=(C_word)C_a_i_list(&a,2,lf[118],lf[117]);
t5=(C_word)C_a_i_list(&a,3,lf[80],t4,lf[116]);
t6=(C_word)C_a_i_list(&a,3,lf[19],t3,t5);
t7=(C_word)C_a_i_list(&a,3,lf[19],t2,t6);
t8=(C_word)C_a_i_list(&a,2,((C_word*)t0)[6],t7);
t9=(C_word)C_a_i_cons(&a,2,t8,((C_word*)((C_word*)t0)[5])[1]);
t10=(C_word)C_a_i_list(&a,3,lf[20],t9,((C_word*)t0)[4]);
/* match.scm: 731  inline-let */
f_3464(((C_word*)t0)[2],t10);}

/* error-maker in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_fcall f_1395(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1395,NULL,2,t1,t2);}
t3=(C_word)C_eqp(*((C_word*)lf[6]+1),lf[64]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1407,a[2]=((C_word)li96),tmp=(C_word)a,a+=3,tmp);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t4));}
else{
t4=*((C_word*)lf[6]+1);
if(C_truep((C_truep((C_word)C_eqp(t4,lf[7]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t4,lf[65]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1419,a[2]=((C_word)li97),tmp=(C_word)a,a+=3,tmp);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t5));}
else{
t5=(C_word)C_eqp(*((C_word*)lf[6]+1),lf[113]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1432,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* match.scm: 846  gensym */
t7=*((C_word*)lf[95]+1);
((C_proc2)C_retrieve_proc(t7))(2,t7,t6);}
else{
/* match.scm: 856  ##match#syntax-err */
t6=*((C_word*)lf[1]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t1,lf[114],lf[115]);}}}}

/* k1430 in error-maker in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_1432(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1432,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1435,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* match.scm: 847  gensym */
t3=*((C_word*)lf[95]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k1433 in k1430 in error-maker in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_1435(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[43],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1435,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(C_word)C_a_i_list(&a,2,lf[42],((C_word*)t0)[4]);
t4=(C_word)C_a_i_list(&a,3,lf[5],t1,t3);
t5=(C_word)C_a_i_list(&a,3,lf[19],t2,t4);
t6=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t5);
t7=(C_word)C_a_i_list(&a,1,t6);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1444,a[2]=((C_word*)t0)[3],a[3]=((C_word)li98),tmp=(C_word)a,a+=4,tmp);
t9=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_a_i_cons(&a,2,t7,t8));}

/* a1443 in k1433 in k1430 in error-maker in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_1444(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1444,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,((C_word*)t0)[2],t2));}

/* a1418 in error-maker in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_1419(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1419,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[5],t2));}

/* a1406 in error-maker in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_1407(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1407,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[112]);}

/* unreachable in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_fcall f_1473(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1473,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1479,a[2]=t3,a[3]=((C_word)li94),tmp=(C_word)a,a+=4,tmp);
/* for-each */
t5=*((C_word*)lf[111]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t4,t2);}

/* a1478 in unreachable in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_1479(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1479,3,t0,t1,t2);}
t3=(C_word)C_i_cddddr(t2);
if(C_truep((C_word)C_i_car(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(C_word)C_i_car(t2);
/* match.scm: 863  ##sys#warn */
t5=*((C_word*)lf[108]+1);
((C_proc6)C_retrieve_proc(t5))(6,t5,t1,lf[109],t4,lf[110],((C_word*)t0)[2]);}}

/* validate-pattern in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_fcall f_1503(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1503,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1506,a[2]=((C_word)li87),tmp=(C_word)a,a+=3,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1536,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t7,a[6]=t3,a[7]=t5,a[8]=((C_word)li89),tmp=(C_word)a,a+=9,tmp));
t11=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2266,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t9,a[5]=t5,a[6]=t3,a[7]=t7,a[8]=((C_word)li91),tmp=(C_word)a,a+=9,tmp));
t12=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2528,a[2]=t2,a[3]=t5,a[4]=t9,a[5]=((C_word)li92),tmp=(C_word)a,a+=6,tmp));
/* match.scm: 1187 ordinary */
t13=((C_word*)t5)[1];
f_1536(3,t13,t1,t2);}

/* ordlist in validate-pattern in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_fcall f_2528(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2528,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2548,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_car(t2);
/* match.scm: 1180 ordinary */
t5=((C_word*)((C_word*)t0)[3])[1];
f_1536(3,t5,t3,t4);}
else{
/* match.scm: 1184 ##match#syntax-err */
t3=*((C_word*)lf[1]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,((C_word*)t0)[2],lf[107]);}}}

/* k2546 in ordlist in validate-pattern in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_2548(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2548,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2552,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* match.scm: 1182 ordlist */
t4=((C_word*)((C_word*)t0)[2])[1];
f_2528(t4,t2,t3);}

/* k2550 in k2546 in ordlist in validate-pattern in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_2552(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2552,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* quasi in validate-pattern in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_2266(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[35],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2266,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2268,a[2]=((C_word*)t0)[7],a[3]=((C_word)li90),tmp=(C_word)a,a+=4,tmp);
t4=f_1506(t2);
if(C_truep(t4)){
t5=t2;
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
if(C_truep((C_word)C_i_symbolp(t2))){
t5=t2;
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_list(&a,2,lf[42],t5));}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t5=(C_word)C_i_car(t2);
t6=(C_word)C_eqp(t5,lf[102]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2313,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t8=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_pairp(t8))){
t9=(C_word)C_i_cddr(t2);
t10=t7;
f_2313(t10,(C_word)C_i_nullp(t9));}
else{
t9=t7;
f_2313(t9,C_SCHEME_FALSE);}}
else{
t7=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2350,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[7],a[6]=t1,a[7]=((C_word*)t0)[5],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
t8=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_pairp(t8))){
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2467,a[2]=t2,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
/* match.scm: 1116 caar */
t10=*((C_word*)lf[63]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,t2);}
else{
t9=t7;
f_2350(t9,C_SCHEME_FALSE);}}}
else{
if(C_truep((C_word)C_i_vectorp(t2))){
t5=t2;
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2484,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[7],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* match.scm: 1158 vector->list */
t7=*((C_word*)lf[99]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t5);}
else{
/* match.scm: 1174 ##match#syntax-err */
t5=*((C_word*)lf[1]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,((C_word*)t0)[2],lf[106]);}}}}}

/* k2482 in quasi in validate-pattern in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_2484(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2484,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2487,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* match.scm: 1160 reverse */
t3=*((C_word*)lf[77]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}

/* k2485 in k2482 in quasi in validate-pattern in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_2487(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2487,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2494,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2497,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_i_car(t1);
/* match.scm: 1164 dot-dot-k? */
f_1327(t3,t4);}

/* k2495 in k2485 in k2482 in quasi in validate-pattern in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_2497(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2497,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2512,a[2]=((C_word*)t0)[5],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[6]);
/* map */
t5=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,((C_word*)((C_word*)t0)[4])[1],t4);}
else{
/* map */
t2=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[5],((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}}

/* k2510 in k2495 in k2485 in k2482 in quasi in validate-pattern in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_2512(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2512,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
/* match.scm: 1166 reverse */
t3=*((C_word*)lf[77]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t2);}

/* k2492 in k2485 in k2482 in quasi in validate-pattern in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_2494(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],*((C_word*)lf[104]+1),t1);}

/* k2465 in quasi in validate-pattern in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_2467(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2467,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[103]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2463,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* match.scm: 1119 cdar */
t4=*((C_word*)lf[60]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[3];
f_2350(t3,C_SCHEME_FALSE);}}

/* k2461 in k2465 in quasi in validate-pattern in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_2463(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2463,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2459,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* match.scm: 1121 cddar */
t3=*((C_word*)lf[58]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_2350(t2,C_SCHEME_FALSE);}}

/* k2457 in k2461 in k2465 in quasi in validate-pattern in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_2459(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_2350(t2,(C_word)C_i_nullp(t1));}

/* k2348 in quasi in validate-pattern in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_fcall f_2350(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2350,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[8]);
if(C_truep((C_word)C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2359,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* match.scm: 1128 cadar */
t4=*((C_word*)lf[56]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[8]);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2365,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
/* match.scm: 1137 cadar */
t4=*((C_word*)lf[56]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[8]);}}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2389,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[8]);
if(C_truep((C_word)C_i_pairp(t3))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2422,a[2]=t2,a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_cadr(((C_word*)t0)[8]);
/* match.scm: 1142 dot-dot-k? */
f_1327(t4,t5);}
else{
t4=t2;
f_2389(t4,C_SCHEME_FALSE);}}}

/* k2420 in k2348 in quasi in validate-pattern in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_2422(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cddr(((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
f_2389(t3,(C_word)C_i_nullp(t2));}
else{
t2=((C_word*)t0)[2];
f_2389(t2,C_SCHEME_FALSE);}}

/* k2387 in k2348 in quasi in validate-pattern in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_fcall f_2389(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2389,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_i_cadr(((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2402,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* match.scm: 1148 quasi */
t5=((C_word*)((C_word*)t0)[3])[1];
f_2266(3,t5,t4,t2);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* match.scm: 1153 g109 */
t4=((C_word*)t0)[2];
f_2268(t4,((C_word*)t0)[4],t2,t3);}}

/* k2400 in k2387 in k2348 in quasi in validate-pattern in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_2402(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2402,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[2]));}

/* k2363 in k2348 in quasi in validate-pattern in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_2365(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2365,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2375,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* match.scm: 1133 ordlist */
t4=((C_word*)((C_word*)t0)[2])[1];
f_2528(t4,t3,t1);}

/* k2373 in k2363 in k2348 in quasi in validate-pattern in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_2375(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2375,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2379,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* match.scm: 1135 quasi */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2266(3,t3,t2,((C_word*)t0)[2]);}

/* k2377 in k2373 in k2363 in k2348 in quasi in validate-pattern in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_2379(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* match.scm: 1132 append */
t2=*((C_word*)lf[66]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2357 in k2348 in quasi in validate-pattern in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_2359(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* match.scm: 1126 ordinary */
t2=((C_word*)((C_word*)t0)[3])[1];
f_1536(3,t2,((C_word*)t0)[2],t1);}

/* k2311 in quasi in validate-pattern in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_fcall f_2313(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* match.scm: 1108 ordinary */
t3=((C_word*)((C_word*)t0)[4])[1];
f_1536(3,t3,((C_word*)t0)[3],t2);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* match.scm: 1111 g109 */
t4=((C_word*)t0)[2];
f_2268(t4,((C_word*)t0)[3],t2,t3);}}

/* g109 in quasi in validate-pattern in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_fcall f_2268(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2268,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2276,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* match.scm: 1089 quasi */
t5=((C_word*)((C_word*)t0)[2])[1];
f_2266(3,t5,t4,t2);}

/* k2274 in g109 in quasi in validate-pattern in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_2276(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2276,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2280,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* match.scm: 1091 quasi */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2266(3,t3,t2,((C_word*)t0)[2]);}

/* k2278 in k2274 in g109 in quasi in validate-pattern in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_2280(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2280,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* ordinary in validate-pattern in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_1536(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1536,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1538,a[2]=((C_word*)t0)[7],a[3]=((C_word)li88),tmp=(C_word)a,a+=4,tmp);
t4=f_1506(t2);
if(C_truep(t4)){
t5=t2;
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t5=(C_word)C_eqp(t2,lf[72]);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,lf[72]);}
else{
t6=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1568,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[7],a[6]=t3,a[7]=((C_word*)t0)[5],a[8]=t1,a[9]=t2,tmp=(C_word)a,a+=10,tmp);
/* match.scm: 885  pattern-var? */
t7=((C_word*)t0)[4];
f_1301(3,t7,t6,t2);}}}

/* k1566 in ordinary in validate-pattern in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_1568(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word ab[80],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1568,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[9];
t3=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[9]))){
t2=(C_word)C_i_car(((C_word*)t0)[9]);
t3=(C_word)C_eqp(t2,lf[101]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1586,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_cdr(((C_word*)t0)[9]);
if(C_truep((C_word)C_i_pairp(t5))){
t6=(C_word)C_i_cddr(((C_word*)t0)[9]);
t7=t4;
f_1586(t7,(C_word)C_i_nullp(t6));}
else{
t6=t4;
f_1586(t6,C_SCHEME_FALSE);}}
else{
t4=(C_word)C_i_car(((C_word*)t0)[9]);
t5=(C_word)C_eqp(t4,lf[42]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1629,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_i_cdr(((C_word*)t0)[9]);
if(C_truep((C_word)C_i_pairp(t7))){
t8=(C_word)C_i_cddr(((C_word*)t0)[9]);
t9=t6;
f_1629(t9,(C_word)C_i_nullp(t8));}
else{
t8=t6;
f_1629(t8,C_SCHEME_FALSE);}}
else{
t6=(C_word)C_i_car(((C_word*)t0)[9]);
t7=(C_word)C_eqp(t6,lf[74]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1666,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
t9=(C_word)C_i_cdr(((C_word*)t0)[9]);
if(C_truep((C_word)C_i_pairp(t9))){
t10=(C_word)C_i_cddr(((C_word*)t0)[9]);
t11=t8;
f_1666(t11,(C_word)C_i_listp(t10));}
else{
t10=t8;
f_1666(t10,C_SCHEME_FALSE);}}
else{
t8=(C_word)C_i_car(((C_word*)t0)[9]);
t9=(C_word)C_eqp(t8,lf[92]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1720,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
t11=(C_word)C_i_cdr(((C_word*)t0)[9]);
if(C_truep((C_word)C_i_pairp(t11))){
t12=(C_word)C_i_cddr(((C_word*)t0)[9]);
if(C_truep((C_word)C_i_pairp(t12))){
t13=(C_word)C_i_cdddr(((C_word*)t0)[9]);
t14=t10;
f_1720(t14,(C_word)C_i_nullp(t13));}
else{
t13=t10;
f_1720(t13,C_SCHEME_FALSE);}}
else{
t12=t10;
f_1720(t12,C_SCHEME_FALSE);}}
else{
t10=(C_word)C_i_car(((C_word*)t0)[9]);
t11=(C_word)C_eqp(t10,lf[50]);
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1780,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
t13=(C_word)C_i_cdr(((C_word*)t0)[9]);
if(C_truep((C_word)C_i_listp(t13))){
t14=(C_word)C_i_cdr(((C_word*)t0)[9]);
t15=t12;
f_1780(t15,(C_word)C_i_pairp(t14));}
else{
t14=t12;
f_1780(t14,C_SCHEME_FALSE);}}
else{
t12=(C_word)C_i_car(((C_word*)t0)[9]);
t13=(C_word)C_eqp(t12,lf[91]);
if(C_truep(t13)){
t14=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1827,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
t15=(C_word)C_i_cdr(((C_word*)t0)[9]);
if(C_truep((C_word)C_i_listp(t15))){
t16=(C_word)C_i_cdr(((C_word*)t0)[9]);
t17=t14;
f_1827(t17,(C_word)C_i_pairp(t16));}
else{
t16=t14;
f_1827(t16,C_SCHEME_FALSE);}}
else{
t14=(C_word)C_i_car(((C_word*)t0)[9]);
t15=(C_word)C_eqp(t14,lf[43]);
if(C_truep(t15)){
t16=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1874,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
t17=(C_word)C_i_cdr(((C_word*)t0)[9]);
if(C_truep((C_word)C_i_listp(t17))){
t18=(C_word)C_i_cdr(((C_word*)t0)[9]);
t19=t16;
f_1874(t19,(C_word)C_i_pairp(t18));}
else{
t18=t16;
f_1874(t18,C_SCHEME_FALSE);}}
else{
t16=(C_word)C_i_car(((C_word*)t0)[9]);
t17=(C_word)C_eqp(t16,lf[90]);
if(C_truep(t17)){
t18=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1921,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
t19=(C_word)C_i_cdr(((C_word*)t0)[9]);
if(C_truep((C_word)C_i_pairp(t19))){
t20=(C_word)C_i_cadr(((C_word*)t0)[9]);
if(C_truep((C_word)C_i_symbolp(t20))){
t21=(C_word)C_i_cddr(((C_word*)t0)[9]);
t22=t18;
f_1921(t22,(C_word)C_i_listp(t21));}
else{
t21=t18;
f_1921(t21,C_SCHEME_FALSE);}}
else{
t20=t18;
f_1921(t20,C_SCHEME_FALSE);}}
else{
t18=(C_word)C_i_car(((C_word*)t0)[9]);
t19=(C_word)C_eqp(t18,lf[89]);
if(C_truep(t19)){
t20=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1985,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
t21=(C_word)C_i_cdr(((C_word*)t0)[9]);
if(C_truep((C_word)C_i_pairp(t21))){
t22=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2005,a[2]=t20,a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
t23=(C_word)C_i_cadr(((C_word*)t0)[9]);
/* match.scm: 1015 pattern-var? */
t24=((C_word*)t0)[4];
f_1301(3,t24,t22,t23);}
else{
t22=t20;
f_1985(t22,C_SCHEME_FALSE);}}
else{
t20=(C_word)C_i_car(((C_word*)t0)[9]);
t21=(C_word)C_eqp(t20,lf[88]);
if(C_truep(t21)){
t22=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2032,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
t23=(C_word)C_i_cdr(((C_word*)t0)[9]);
if(C_truep((C_word)C_i_pairp(t23))){
t24=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2052,a[2]=t22,a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
t25=(C_word)C_i_cadr(((C_word*)t0)[9]);
/* match.scm: 1029 pattern-var? */
t26=((C_word*)t0)[4];
f_1301(3,t26,t24,t25);}
else{
t24=t22;
f_2032(t24,C_SCHEME_FALSE);}}
else{
t22=(C_word)C_i_car(((C_word*)t0)[9]);
t23=(C_word)C_eqp(t22,lf[102]);
if(C_truep(t23)){
t24=(C_word)C_i_car(((C_word*)t0)[9]);
t25=(C_word)C_i_cdr(((C_word*)t0)[9]);
/* match.scm: 1041 g88 */
t26=((C_word*)t0)[6];
f_1538(t26,((C_word*)t0)[8],t24,t25);}
else{
t24=(C_word)C_i_car(((C_word*)t0)[9]);
t25=(C_word)C_eqp(t24,lf[103]);
if(C_truep(t25)){
t26=(C_word)C_i_car(((C_word*)t0)[9]);
t27=(C_word)C_i_cdr(((C_word*)t0)[9]);
/* match.scm: 1046 g88 */
t28=((C_word*)t0)[6];
f_1538(t28,((C_word*)t0)[8],t26,t27);}
else{
t26=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2107,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
t27=(C_word)C_i_cdr(((C_word*)t0)[9]);
if(C_truep((C_word)C_i_pairp(t27))){
t28=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2140,a[2]=t26,a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
t29=(C_word)C_i_cadr(((C_word*)t0)[9]);
/* match.scm: 1050 dot-dot-k? */
f_1327(t28,t29);}
else{
t28=t26;
f_2107(t28,C_SCHEME_FALSE);}}}}}}}}}}}}}}
else{
if(C_truep((C_word)C_i_vectorp(((C_word*)t0)[9]))){
t2=((C_word*)t0)[9];
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2212,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
/* match.scm: 1066 vector->list */
t4=*((C_word*)lf[99]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}
else{
/* match.scm: 1084 ##match#syntax-err */
t2=*((C_word*)lf[1]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[8],((C_word*)t0)[2],lf[105]);}}}}

/* k2210 in k1566 in ordinary in validate-pattern in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_2212(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2212,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2215,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* match.scm: 1068 reverse */
t3=*((C_word*)lf[77]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}

/* k2213 in k2210 in k1566 in ordinary in validate-pattern in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_2215(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2215,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2222,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2225,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_nullp(t1))){
t4=t3;
f_2225(2,t4,C_SCHEME_FALSE);}
else{
t4=(C_word)C_i_car(t1);
/* match.scm: 1074 dot-dot-k? */
f_1327(t3,t4);}}

/* k2223 in k2213 in k2210 in k1566 in ordinary in validate-pattern in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_2225(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2225,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2240,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* map */
t5=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,((C_word*)((C_word*)t0)[3])[1],t4);}
else{
/* map */
t2=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}}

/* k2238 in k2223 in k2213 in k2210 in k1566 in ordinary in validate-pattern in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_2240(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2240,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
/* match.scm: 1076 reverse */
t3=*((C_word*)lf[77]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t2);}

/* k2220 in k2213 in k2210 in k1566 in ordinary in validate-pattern in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_2222(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],*((C_word*)lf[104]+1),t1);}

/* k2138 in k1566 in ordinary in validate-pattern in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_2140(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cddr(((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
f_2107(t3,(C_word)C_i_nullp(t2));}
else{
t2=((C_word*)t0)[2];
f_2107(t2,C_SCHEME_FALSE);}}

/* k2105 in k1566 in ordinary in validate-pattern in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_fcall f_2107(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2107,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_i_cadr(((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2120,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* match.scm: 1056 ordinary */
t5=((C_word*)((C_word*)t0)[3])[1];
f_1536(3,t5,t4,t2);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* match.scm: 1061 g88 */
t4=((C_word*)t0)[2];
f_1538(t4,((C_word*)t0)[4],t2,t3);}}

/* k2118 in k2105 in k1566 in ordinary in validate-pattern in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_2120(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2120,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[2]));}

/* k2050 in k1566 in ordinary in validate-pattern in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_2052(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cddr(((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
f_2032(t3,(C_word)C_i_nullp(t2));}
else{
t2=((C_word*)t0)[2];
f_2032(t2,C_SCHEME_FALSE);}}

/* k2030 in k1566 in ordinary in validate-pattern in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_fcall f_2032(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* match.scm: 1036 g88 */
t4=((C_word*)t0)[2];
f_1538(t4,((C_word*)t0)[3],t2,t3);}}

/* k2003 in k1566 in ordinary in validate-pattern in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_2005(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cddr(((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
f_1985(t3,(C_word)C_i_nullp(t2));}
else{
t2=((C_word*)t0)[2];
f_1985(t2,C_SCHEME_FALSE);}}

/* k1983 in k1566 in ordinary in validate-pattern in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_fcall f_1985(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* match.scm: 1022 g88 */
t4=((C_word*)t0)[2];
f_1538(t4,((C_word*)t0)[3],t2,t3);}}

/* k1919 in k1566 in ordinary in validate-pattern in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_fcall f_1921(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1921,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(C_word)C_i_cddr(((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1938,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* map */
t5=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)((C_word*)t0)[3])[1],t3);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* match.scm: 1008 g88 */
t4=((C_word*)t0)[2];
f_1538(t4,((C_word*)t0)[4],t2,t3);}}

/* k1936 in k1919 in k1566 in ordinary in validate-pattern in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_1938(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1938,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[90],t2));}

/* k1872 in k1566 in ordinary in validate-pattern in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_fcall f_1874(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1874,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1884,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* map */
t4=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)((C_word*)t0)[3])[1],t2);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* match.scm: 990  g88 */
t4=((C_word*)t0)[2];
f_1538(t4,((C_word*)t0)[4],t2,t3);}}

/* k1882 in k1872 in k1566 in ordinary in validate-pattern in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_1884(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1884,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[43],t1));}

/* k1825 in k1566 in ordinary in validate-pattern in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_fcall f_1827(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1827,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1837,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* map */
t4=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)((C_word*)t0)[3])[1],t2);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* match.scm: 977  g88 */
t4=((C_word*)t0)[2];
f_1538(t4,((C_word*)t0)[4],t2,t3);}}

/* k1835 in k1825 in k1566 in ordinary in validate-pattern in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_1837(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1837,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[91],t1));}

/* k1778 in k1566 in ordinary in validate-pattern in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_fcall f_1780(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1780,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1790,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* map */
t4=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)((C_word*)t0)[3])[1],t2);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* match.scm: 964  g88 */
t4=((C_word*)t0)[2];
f_1538(t4,((C_word*)t0)[4],t2,t3);}}

/* k1788 in k1778 in k1566 in ordinary in validate-pattern in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_1790(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1790,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[50],t1));}

/* k1718 in k1566 in ordinary in validate-pattern in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_fcall f_1720(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1720,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(C_word)C_i_caddr(((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1733,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* match.scm: 946  ordinary */
t5=((C_word*)((C_word*)t0)[3])[1];
f_1536(3,t5,t4,t3);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* match.scm: 951  g88 */
t4=((C_word*)t0)[2];
f_1538(t4,((C_word*)t0)[4],t2,t3);}}

/* k1731 in k1718 in k1566 in ordinary in validate-pattern in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_1733(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1733,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[92],((C_word*)t0)[2],t1));}

/* k1664 in k1566 in ordinary in validate-pattern in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_fcall f_1666(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1666,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(C_word)C_i_cddr(((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1683,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* map */
t5=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)((C_word*)t0)[3])[1],t3);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* match.scm: 931  g88 */
t4=((C_word*)t0)[2];
f_1538(t4,((C_word*)t0)[4],t2,t3);}}

/* k1681 in k1664 in k1566 in ordinary in validate-pattern in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_1683(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1683,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[74],t2));}

/* k1627 in k1566 in ordinary in validate-pattern in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_fcall f_1629(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* match.scm: 915  g88 */
t4=((C_word*)t0)[2];
f_1538(t4,((C_word*)t0)[3],t2,t3);}}

/* k1584 in k1566 in ordinary in validate-pattern in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_fcall f_1586(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* match.scm: 900  quasi */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2266(3,t3,((C_word*)t0)[3],t2);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* match.scm: 903  g88 */
t4=((C_word*)t0)[2];
f_1538(t4,((C_word*)t0)[3],t2,t3);}}

/* g88 in ordinary in validate-pattern in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_fcall f_1538(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1538,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1546,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* match.scm: 875  ordinary */
t5=((C_word*)((C_word*)t0)[2])[1];
f_1536(3,t5,t4,t2);}

/* k1544 in g88 in ordinary in validate-pattern in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_1546(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1546,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1550,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* match.scm: 877  ordinary */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1536(3,t3,t2,((C_word*)t0)[2]);}

/* k1548 in k1544 in g88 in ordinary in validate-pattern in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_1550(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1550,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* simple? in validate-pattern in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static C_word C_fcall f_1506(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_stack_check;
t2=(C_word)C_i_stringp(t1);
if(C_truep(t2)){
return(t2);}
else{
t3=(C_word)C_booleanp(t1);
if(C_truep(t3)){
return(t3);}
else{
t4=(C_word)C_charp(t1);
if(C_truep(t4)){
return(t4);}
else{
t5=(C_word)C_i_numberp(t1);
return((C_truep(t5)?t5:(C_word)C_i_nullp(t1)));}}}}

/* pattern-var? in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_1301(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1301,3,t0,t1,t2);}
if(C_truep((C_word)C_i_symbolp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1325,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* match.scm: 806  dot-dot-k? */
f_1327(t3,t2);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k1323 in pattern-var? in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_1325(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(C_word)C_i_memq(((C_word*)t0)[2],lf[100]);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_not(t2));}}

/* bound in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_fcall f_2568(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[43],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2568,NULL,3,t0,t1,t2);}
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3425,a[2]=((C_word)li60),tmp=(C_word)a,a+=3,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3401,a[2]=t7,a[3]=((C_word)li61),tmp=(C_word)a,a+=4,tmp));
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2572,a[2]=((C_word*)t0)[2],a[3]=t12,a[4]=t7,a[5]=t5,a[6]=t14,a[7]=t10,a[8]=t4,a[9]=t2,a[10]=((C_word)li76),tmp=(C_word)a,a+=11,tmp));
t16=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3269,a[2]=((C_word*)t0)[2],a[3]=t12,a[4]=t10,a[5]=((C_word)li80),tmp=(C_word)a,a+=6,tmp));
t17=C_set_block_item(t14,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3362,a[2]=t10,a[3]=t14,a[4]=((C_word)li83),tmp=(C_word)a,a+=5,tmp));
t18=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3454,a[2]=t4,a[3]=((C_word)li84),tmp=(C_word)a,a+=4,tmp);
/* match.scm: 1412 bound */
t19=((C_word*)t10)[1];
f_2572(t19,t1,t2,C_SCHEME_END_OF_LIST,t18);}

/* a3453 in bound in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_3454(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3454,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3462,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* match.scm: 1415 reverse */
t5=*((C_word*)lf[77]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t3);}

/* k3460 in a3453 in bound in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_3462(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3462,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,((C_word*)t0)[3],t1,((C_word*)((C_word*)t0)[2])[1]));}

/* bound* in bound in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_fcall f_3362(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3362,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
/* match.scm: 1387 k */
t5=t4;
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t2,t3);}
else{
t5=(C_word)C_i_car(t2);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3381,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t2,a[5]=((C_word)li82),tmp=(C_word)a,a+=6,tmp);
/* match.scm: 1388 bound */
t7=((C_word*)((C_word*)t0)[2])[1];
f_2572(t7,t1,t5,t3,t6);}}

/* a3380 in bound* in bound in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_3381(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3381,4,t0,t1,t2,t3);}
t4=(C_word)C_i_cdr(((C_word*)t0)[4]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3391,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word)li81),tmp=(C_word)a,a+=5,tmp);
/* match.scm: 1392 bound* */
t6=((C_word*)((C_word*)t0)[2])[1];
f_3362(t6,t1,t4,t3,t5);}

/* a3390 in a3380 in bound* in bound in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_3391(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3391,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
/* match.scm: 1396 k */
t5=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t4,t3);}

/* boundv in bound in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_fcall f_3269(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3269,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3271,a[2]=t3,a[3]=t2,a[4]=t4,a[5]=((C_word)li77),tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3287,a[2]=((C_word*)t0)[3],a[3]=t5,a[4]=t4,a[5]=t3,a[6]=t2,a[7]=t1,a[8]=((C_word*)t0)[4],tmp=(C_word)a,a+=9,tmp);
t7=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_pairp(t7))){
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3333,a[2]=t6,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t9=(C_word)C_i_cadr(t2);
/* match.scm: 1360 dot-dot-k? */
f_1327(t8,t9);}
else{
t8=t6;
f_3287(t8,C_SCHEME_FALSE);}}
else{
if(C_truep((C_word)C_i_nullp(t2))){
/* match.scm: 1383 g115 */
t6=t5;
f_3271(t6,t1);}
else{
/* match.scm: 1384 ##sys#match-error */
t6=*((C_word*)lf[5]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t1,t2);}}}

/* k3331 in boundv in bound in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_3333(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cddr(((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
f_3287(t3,(C_word)C_i_nullp(t2));}
else{
t2=((C_word*)t0)[2];
f_3287(t2,C_SCHEME_FALSE);}}

/* k3285 in boundv in bound in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_fcall f_3287(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3287,NULL,2,t0,t1);}
if(C_truep(t1)){
/* match.scm: 1364 bound */
t2=((C_word*)((C_word*)t0)[8])[1];
f_2572(t2,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[6]))){
/* match.scm: 1366 g115 */
t2=((C_word*)t0)[3];
f_3271(t2,((C_word*)t0)[7]);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(C_word)C_i_cdr(((C_word*)t0)[6]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3310,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word)li79),tmp=(C_word)a,a+=6,tmp);
/* match.scm: 1368 bound */
t5=((C_word*)((C_word*)t0)[8])[1];
f_2572(t5,((C_word*)t0)[7],t2,((C_word*)t0)[5],t4);}}}

/* a3309 in k3285 in boundv in bound in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_3310(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3310,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3316,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word)li78),tmp=(C_word)a,a+=5,tmp);
/* match.scm: 1372 boundv */
t5=((C_word*)((C_word*)t0)[3])[1];
f_3269(t5,t1,((C_word*)t0)[2],t3,t4);}

/* a3315 in a3309 in k3285 in boundv in bound in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_3316(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3316,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
/* match.scm: 1377 k */
t5=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t4,t3);}

/* g115 in boundv in bound in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_fcall f_3271(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3271,NULL,2,t0,t1);}
/* match.scm: 1357 k */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* bound in bound in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_fcall f_2572(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2572,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(lf[72],t2);
if(C_truep(t5)){
/* match.scm: 1192 k */
t6=t4;
((C_proc4)C_retrieve_proc(t6))(4,t6,t1,t2,t3);}
else{
if(C_truep((C_word)C_i_symbolp(t2))){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2591,a[2]=t1,a[3]=t4,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_memq(t2,t3))){
/* match.scm: 1194 ##match#syntax-err */
t7=*((C_word*)lf[1]+1);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,((C_word*)t0)[9],lf[94]);}
else{
t7=t6;
f_2591(2,t7,C_SCHEME_UNDEFINED);}}
else{
t6=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_2610,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=t3,a[11]=t2,a[12]=t1,a[13]=t4,tmp=(C_word)a,a+=14,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t7=(C_word)C_i_car(t2);
t8=t6;
f_2610(t8,(C_word)C_eqp(lf[42],t7));}
else{
t7=t6;
f_2610(t7,C_SCHEME_FALSE);}}}}

/* k2608 in bound in bound in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_fcall f_2610(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2610,NULL,2,t0,t1);}
if(C_truep(t1)){
/* match.scm: 1199 k */
t2=((C_word*)t0)[13];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[12],((C_word*)t0)[11],((C_word*)t0)[10]);}
else{
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_2619,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[9],a[13]=((C_word*)t0)[11],tmp=(C_word)a,a+=14,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[11]))){
t3=(C_word)C_i_car(((C_word*)t0)[11]);
t4=t2;
f_2619(t4,(C_word)C_eqp(lf[74],t3));}
else{
t3=t2;
f_2619(t3,C_SCHEME_FALSE);}}}

/* k2617 in k2608 in bound in bound in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_fcall f_2619(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2619,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cddr(((C_word*)t0)[13]);
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_i_cadr(((C_word*)t0)[13]);
t4=(C_word)C_i_symbolp(t3);
t5=(C_word)C_i_not(t4);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2657,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[13],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t5)){
t7=t6;
f_2657(t7,t5);}
else{
t7=(C_word)C_i_cadr(((C_word*)t0)[13]);
t8=t6;
f_2657(t8,(C_word)C_i_memq(t7,((C_word*)t0)[9]));}}
else{
t3=(C_word)C_i_cadr(((C_word*)t0)[13]);
t4=(C_word)C_a_i_list(&a,2,lf[74],t3);
t5=(C_word)C_i_cddr(((C_word*)t0)[13]);
t6=(C_word)C_a_i_cons(&a,2,t4,t5);
t7=(C_word)C_a_i_cons(&a,2,lf[50],t6);
/* match.scm: 1202 bound */
t8=((C_word*)((C_word*)t0)[8])[1];
f_2572(t8,((C_word*)t0)[10],t7,((C_word*)t0)[9],((C_word*)t0)[11]);}}
else{
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_2711,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[8],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[13]))){
t3=(C_word)C_i_car(((C_word*)t0)[13]);
t4=t2;
f_2711(t4,(C_word)C_eqp(lf[92],t3));}
else{
t3=t2;
f_2711(t3,C_SCHEME_FALSE);}}}

/* k2709 in k2617 in k2608 in bound in bound in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_fcall f_2711(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2711,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[13]);
t3=(C_word)C_i_symbolp(t2);
t4=(C_word)C_i_not(t3);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2720,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[12],a[7]=((C_word*)t0)[13],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t4)){
t6=t5;
f_2720(t6,t4);}
else{
t6=(C_word)C_i_cadr(((C_word*)t0)[13]);
t7=t5;
f_2720(t7,(C_word)C_i_memq(t6,((C_word*)t0)[9]));}}
else{
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2788,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[7],a[11]=((C_word*)t0)[8],a[12]=((C_word*)t0)[13],tmp=(C_word)a,a+=13,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[13]))){
t3=(C_word)C_i_car(((C_word*)t0)[13]);
t4=t2;
f_2788(t4,(C_word)C_eqp(lf[50],t3));}
else{
t3=t2;
f_2788(t3,C_SCHEME_FALSE);}}}

/* k2786 in k2709 in k2617 in k2608 in bound in bound in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_fcall f_2788(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2788,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[12]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2797,a[2]=((C_word*)t0)[11],a[3]=((C_word)li63),tmp=(C_word)a,a+=4,tmp);
/* match.scm: 1241 bound* */
t4=((C_word*)((C_word*)t0)[10])[1];
f_3362(t4,((C_word*)t0)[9],t2,((C_word*)t0)[8],t3);}
else{
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2811,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[7],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[12]))){
t3=(C_word)C_i_car(((C_word*)t0)[12]);
t4=t2;
f_2811(t4,(C_word)C_eqp(lf[91],t3));}
else{
t3=t2;
f_2811(t3,C_SCHEME_FALSE);}}}

/* k2809 in k2786 in k2709 in k2617 in k2608 in bound in bound in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_fcall f_2811(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2811,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[12]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2820,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[12],a[8]=((C_word)li68),tmp=(C_word)a,a+=9,tmp);
/* match.scm: 1248 bound */
t4=((C_word*)((C_word*)t0)[8])[1];
f_2572(t4,((C_word*)t0)[6],t2,((C_word*)t0)[7],t3);}
else{
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2900,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],tmp=(C_word)a,a+=12,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[12]))){
t3=(C_word)C_i_car(((C_word*)t0)[12]);
t4=t2;
f_2900(t4,(C_word)C_eqp(lf[43],t3));}
else{
t3=t2;
f_2900(t3,C_SCHEME_FALSE);}}}

/* k2898 in k2809 in k2786 in k2709 in k2617 in k2608 in bound in bound in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_fcall f_2900(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2900,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cddr(((C_word*)t0)[11]);
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_i_cadr(((C_word*)t0)[11]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2930,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=((C_word)li69),tmp=(C_word)a,a+=7,tmp);
/* match.scm: 1282 bound */
t5=((C_word*)((C_word*)t0)[7])[1];
f_2572(t5,((C_word*)t0)[6],t3,((C_word*)t0)[9],t4);}
else{
t3=(C_word)C_i_cdr(((C_word*)t0)[11]);
t4=(C_word)C_a_i_cons(&a,2,lf[91],t3);
t5=(C_word)C_a_i_list(&a,2,lf[43],t4);
/* match.scm: 1278 bound */
t6=((C_word*)((C_word*)t0)[7])[1];
f_2572(t6,((C_word*)t0)[6],t5,((C_word*)t0)[9],((C_word*)t0)[10]);}}
else{
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2965,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[11]))){
t3=(C_word)C_i_cdr(((C_word*)t0)[11]);
if(C_truep((C_word)C_i_pairp(t3))){
t4=(C_word)C_i_cadr(((C_word*)t0)[11]);
/* match.scm: 1297 dot-dot-k? */
f_1327(t2,t4);}
else{
t4=t2;
f_2965(2,t4,C_SCHEME_FALSE);}}
else{
t3=t2;
f_2965(2,t3,C_SCHEME_FALSE);}}}

/* k2963 in k2898 in k2809 in k2786 in k2709 in k2617 in k2608 in bound in bound in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_2965(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2965,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[9]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2974,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word)li71),tmp=(C_word)a,a+=7,tmp);
/* match.scm: 1297 bound */
t4=((C_word*)((C_word*)t0)[5])[1];
f_2572(t4,((C_word*)t0)[4],t2,((C_word*)t0)[6],t3);}
else{
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3013,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[9]))){
t3=(C_word)C_i_car(((C_word*)t0)[9]);
t4=t2;
f_3013(t4,(C_word)C_eqp(lf[90],t3));}
else{
t3=t2;
f_3013(t3,C_SCHEME_FALSE);}}}

/* k3011 in k2963 in k2898 in k2809 in k2786 in k2709 in k2617 in k2608 in bound in bound in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_fcall f_3013(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3013,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cddr(((C_word*)t0)[8]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3022,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word)li72),tmp=(C_word)a,a+=5,tmp);
/* match.scm: 1313 bound* */
t4=((C_word*)((C_word*)t0)[6])[1];
f_3362(t4,((C_word*)t0)[5],t2,((C_word*)t0)[4],t3);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3044,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[8]))){
t3=(C_word)C_i_car(((C_word*)t0)[8]);
t4=t2;
f_3044(t4,(C_word)C_eqp(lf[89],t3));}
else{
t3=t2;
f_3044(t3,C_SCHEME_FALSE);}}}

/* k3042 in k3011 in k2963 in k2898 in k2809 in k2786 in k2709 in k2617 in k2608 in bound in bound in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_fcall f_3044(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3044,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[7]);
if(C_truep((C_word)C_i_memq(t2,((C_word*)t0)[6]))){
/* match.scm: 1324 k */
t3=((C_word*)t0)[5];
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[4],((C_word*)t0)[7],((C_word*)t0)[6]);}
else{
t3=(C_word)C_i_cadr(((C_word*)t0)[7]);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[6]);
/* match.scm: 1326 k */
t5=((C_word*)t0)[5];
((C_proc4)C_retrieve_proc(t5))(4,t5,((C_word*)t0)[4],((C_word*)t0)[7],t4);}}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3074,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[7]))){
t3=(C_word)C_i_car(((C_word*)t0)[7]);
t4=t2;
f_3074(t4,(C_word)C_eqp(lf[88],t3));}
else{
t3=t2;
f_3074(t3,C_SCHEME_FALSE);}}}

/* k3072 in k3042 in k3011 in k2963 in k2898 in k2809 in k2786 in k2709 in k2617 in k2608 in bound in bound in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_fcall f_3074(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3074,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[7]);
if(C_truep((C_word)C_i_memq(t2,((C_word*)t0)[6]))){
/* match.scm: 1332 k */
t3=((C_word*)t0)[5];
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[4],((C_word*)t0)[7],((C_word*)t0)[6]);}
else{
t3=(C_word)C_i_cadr(((C_word*)t0)[7]);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[6]);
/* match.scm: 1334 k */
t5=((C_word*)t0)[5];
((C_proc4)C_retrieve_proc(t5))(4,t5,((C_word*)t0)[4],((C_word*)t0)[7],t4);}}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[7]))){
t2=(C_word)C_i_car(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3113,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[7],a[5]=((C_word)li74),tmp=(C_word)a,a+=6,tmp);
/* match.scm: 1337 bound */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2572(t4,((C_word*)t0)[4],t2,((C_word*)t0)[6],t3);}
else{
if(C_truep((C_word)C_i_vectorp(((C_word*)t0)[7]))){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3144,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* match.scm: 1349 vector->list */
t3=*((C_word*)lf[99]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[7]);}
else{
/* match.scm: 1355 k */
t2=((C_word*)t0)[5];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[4],((C_word*)t0)[7],((C_word*)t0)[6]);}}}}

/* k3142 in k3072 in k3042 in k3011 in k2963 in k2898 in k2809 in k2786 in k2709 in k2617 in k2608 in bound in bound in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_3144(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3144,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3146,a[2]=((C_word*)t0)[5],a[3]=((C_word)li75),tmp=(C_word)a,a+=4,tmp);
/* match.scm: 1348 boundv */
t3=((C_word*)((C_word*)t0)[4])[1];
f_3269(t3,((C_word*)t0)[3],t1,((C_word*)t0)[2],t2);}

/* a3145 in k3142 in k3072 in k3042 in k3011 in k2963 in k2898 in k2809 in k2786 in k2709 in k2617 in k2608 in bound in bound in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_3146(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3146,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3154,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* match.scm: 1352 list->vector */
t5=*((C_word*)lf[98]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k3152 in a3145 in k3142 in k3072 in k3042 in k3011 in k2963 in k2898 in k2809 in k2786 in k2709 in k2617 in k2608 in bound in bound in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_3154(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* match.scm: 1352 k */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* a3112 in k3072 in k3042 in k3011 in k2963 in k2898 in k2809 in k2786 in k2709 in k2617 in k2608 in bound in bound in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_3113(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3113,4,t0,t1,t2,t3);}
t4=(C_word)C_i_cdr(((C_word*)t0)[4]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3123,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word)li73),tmp=(C_word)a,a+=5,tmp);
/* match.scm: 1341 bound */
t6=((C_word*)((C_word*)t0)[2])[1];
f_2572(t6,t1,t4,t3,t5);}

/* a3122 in a3112 in k3072 in k3042 in k3011 in k2963 in k2898 in k2809 in k2786 in k2709 in k2617 in k2608 in bound in bound in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_3123(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3123,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
/* match.scm: 1345 k */
t5=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t4,t3);}

/* a3021 in k3011 in k2963 in k2898 in k2809 in k2786 in k2709 in k2617 in k2608 in bound in bound in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_3022(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3022,4,t0,t1,t2,t3);}
t4=(C_word)C_i_cadr(((C_word*)t0)[3]);
t5=(C_word)C_a_i_cons(&a,2,t4,t2);
t6=(C_word)C_a_i_cons(&a,2,lf[90],t5);
/* match.scm: 1318 k */
t7=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t7))(4,t7,t1,t6,t3);}

/* a2973 in k2963 in k2898 in k2809 in k2786 in k2709 in k2617 in k2608 in bound in bound in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_2974(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2974,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2978,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* match.scm: 1302 find-prefix */
t5=((C_word*)((C_word*)t0)[3])[1];
f_3401(t5,t4,t3,((C_word*)t0)[2]);}

/* k2976 in a2973 in k2963 in k2898 in k2809 in k2786 in k2709 in k2617 in k2608 in bound in bound in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_2978(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2978,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2993,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=t2,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
/* match.scm: 1307 gensym */
t4=*((C_word*)lf[95]+1);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k2991 in k2976 in a2973 in k2963 in k2898 in k2809 in k2786 in k2709 in k2617 in k2608 in bound in bound in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_2993(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2993,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2997,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* match.scm: 1308 gensym */
t3=*((C_word*)lf[95]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k2995 in k2991 in k2976 in a2973 in k2963 in k2898 in k2809 in k2786 in k2709 in k2617 in k2608 in bound in bound in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_2997(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2997,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3001,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3003,a[2]=((C_word)li70),tmp=(C_word)a,a+=3,tmp);
/* map */
t4=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[6]);}

/* a3002 in k2995 in k2991 in k2976 in a2973 in k2963 in k2898 in k2809 in k2786 in k2709 in k2617 in k2608 in bound in bound in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_3003(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3003,3,t0,t1,t2);}
/* match.scm: 1310 gensym */
t3=*((C_word*)lf[95]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,t1);}

/* k2999 in k2995 in k2991 in k2976 in a2973 in k2963 in k2898 in k2809 in k2786 in k2709 in k2617 in k2608 in bound in bound in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_3001(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3001,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,6,((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],t1);
/* match.scm: 1305 k */
t3=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a2929 in k2898 in k2809 in k2786 in k2709 in k2617 in k2608 in bound in bound in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_2930(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2930,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2934,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2951,a[2]=((C_word*)t0)[3],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* match.scm: 1287 permutation */
f_3425(t5,((C_word*)t0)[4],t3);}

/* k2949 in a2929 in k2898 in k2809 in k2786 in k2709 in k2617 in k2608 in bound in bound in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_2951(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_2934(2,t2,C_SCHEME_UNDEFINED);}
else{
/* match.scm: 1290 ##match#syntax-err */
t2=*((C_word*)lf[1]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[97]);}}

/* k2932 in a2929 in k2898 in k2809 in k2786 in k2709 in k2617 in k2608 in bound in bound in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_2934(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2934,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[43],((C_word*)t0)[5]);
/* match.scm: 1293 k */
t3=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a2819 in k2809 in k2786 in k2709 in k2617 in k2608 in bound in bound in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_2820(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[17],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2820,4,t0,t1,t2,t3);}
t4=(C_word)C_i_cddr(((C_word*)t0)[7]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2830,a[2]=t3,a[3]=((C_word*)t0)[6],a[4]=t2,a[5]=((C_word)li64),tmp=(C_word)a,a+=6,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2844,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t7,a[8]=((C_word)li67),tmp=(C_word)a,a+=9,tmp));
t9=((C_word*)t7)[1];
f_2844(t9,t1,t4,t5);}

/* or* in a2819 in k2809 in k2786 in k2709 in k2617 in k2608 in bound in bound in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_fcall f_2844(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2844,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
/* match.scm: 1260 k */
t4=t3;
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t2);}
else{
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2863,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=t3,a[7]=t2,a[8]=((C_word)li66),tmp=(C_word)a,a+=9,tmp);
/* match.scm: 1261 bound */
t6=((C_word*)((C_word*)t0)[3])[1];
f_2572(t6,t1,t4,((C_word*)t0)[2],t5);}}

/* a2862 in or* in a2819 in k2809 in k2786 in k2709 in k2617 in k2608 in bound in bound in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_2863(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2863,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2867,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t2,a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2894,a[2]=((C_word*)t0)[4],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* match.scm: 1266 permutation */
f_3425(t5,t3,((C_word*)t0)[2]);}

/* k2892 in a2862 in or* in a2819 in k2809 in k2786 in k2709 in k2617 in k2608 in bound in bound in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_2894(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_2867(2,t2,C_SCHEME_UNDEFINED);}
else{
/* match.scm: 1269 ##match#syntax-err */
t2=*((C_word*)lf[1]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[96]);}}

/* k2865 in a2862 in or* in a2819 in k2809 in k2786 in k2709 in k2617 in k2608 in bound in bound in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_2867(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2867,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2876,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word)li65),tmp=(C_word)a,a+=5,tmp);
/* match.scm: 1272 or* */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2844(t4,((C_word*)t0)[2],t2,t3);}

/* a2875 in k2865 in a2862 in or* in a2819 in k2809 in k2786 in k2709 in k2617 in k2608 in bound in bound in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_2876(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2876,3,t0,t1,t2);}
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
/* match.scm: 1274 k */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a2829 in a2819 in k2809 in k2786 in k2709 in k2617 in k2608 in bound in bound in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_2830(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2830,3,t0,t1,t2);}
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=(C_word)C_a_i_cons(&a,2,lf[91],t3);
/* match.scm: 1255 k */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t4,((C_word*)t0)[2]);}

/* a2796 in k2786 in k2709 in k2617 in k2608 in bound in bound in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_2797(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2797,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_cons(&a,2,lf[50],t2);
/* match.scm: 1246 k */
t5=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t4,t3);}

/* k2718 in k2709 in k2617 in k2608 in bound in bound in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_fcall f_2720(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2720,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2723,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* match.scm: 1222 gensym */
t3=*((C_word*)lf[95]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}
else{
t2=(C_word)C_i_caddr(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2755,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[7],a[4]=((C_word)li62),tmp=(C_word)a,a+=5,tmp);
/* match.scm: 1232 bound */
t4=((C_word*)((C_word*)t0)[5])[1];
f_2572(t4,((C_word*)t0)[4],t2,((C_word*)t0)[3],t3);}}

/* a2754 in k2718 in k2709 in k2617 in k2608 in bound in bound in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_2755(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2755,4,t0,t1,t2,t3);}
t4=(C_word)C_i_cadr(((C_word*)t0)[3]);
t5=(C_word)C_a_i_list(&a,3,lf[92],t4,t2);
/* match.scm: 1238 k */
t6=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t6))(4,t6,t1,t5,t3);}

/* k2721 in k2718 in k2709 in k2617 in k2608 in bound in bound in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_2723(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2723,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[7]);
t3=(C_word)C_a_i_list(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)((C_word*)t0)[6])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[6])+1,t4);
t6=(C_word)C_i_caddr(((C_word*)t0)[7]);
t7=(C_word)C_a_i_list(&a,3,lf[92],t1,t6);
/* match.scm: 1226 bound */
t8=((C_word*)((C_word*)t0)[5])[1];
f_2572(t8,((C_word*)t0)[4],t7,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2655 in k2617 in k2608 in bound in bound in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_fcall f_2657(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2657,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2660,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* match.scm: 1210 gensym */
t3=*((C_word*)lf[95]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}
else{
/* match.scm: 1216 k */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[6],((C_word*)t0)[2]);}}

/* k2658 in k2655 in k2617 in k2608 in bound in bound in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_2660(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2660,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[6]);
t3=(C_word)C_a_i_list(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)((C_word*)t0)[5])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[5])+1,t4);
t6=(C_word)C_a_i_list(&a,2,lf[74],t1);
/* match.scm: 1214 k */
t7=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t7))(4,t7,((C_word*)t0)[3],t6,((C_word*)t0)[2]);}

/* k2589 in bound in bound in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_2591(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2591,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[4]);
/* match.scm: 1197 k */
t3=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[2],((C_word*)t0)[5],t2);}

/* find-prefix in bound in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_fcall f_3401(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3401,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t2,t3);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_END_OF_LIST);}
else{
t5=(C_word)C_i_car(t2);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3419,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_i_cdr(t2);
/* match.scm: 1402 find-prefix */
t9=t6;
t10=t7;
t11=t3;
t1=t9;
t2=t10;
t3=t11;
goto loop;}}

/* k3417 in find-prefix in bound in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_3419(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3419,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* permutation in bound in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_fcall f_3425(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3425,NULL,3,t1,t2,t3);}
t4=(C_word)C_i_length(t2);
t5=(C_word)C_i_length(t3);
if(C_truep((C_word)C_i_nequalp(t4,t5))){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3437,a[2]=t3,a[3]=((C_word)li59),tmp=(C_word)a,a+=4,tmp);
/* match.scm: 1408 ##match#every */
t7=*((C_word*)lf[0]+1);
((C_proc4)C_retrieve_proc(t7))(4,t7,t1,t6,t2);}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}

/* a3436 in permutation in bound in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_3437(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3437,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_memq(t2,((C_word*)t0)[2]));}

/* inline-let in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_fcall f_3464(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3464,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3547,a[2]=((C_word)li52),tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3629,a[2]=t3,a[3]=((C_word)li53),tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3651,a[2]=t3,a[3]=((C_word)li54),tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cadr(t2);
t7=(C_word)C_i_caddr(t2);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3724,a[2]=t5,a[3]=t9,a[4]=t4,a[5]=((C_word)li57),tmp=(C_word)a,a+=6,tmp));
t11=((C_word*)t9)[1];
f_3724(t11,t1,t6,C_SCHEME_END_OF_LIST,t7);}

/* loop in inline-let in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_fcall f_3724(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a;
loop:
a=C_alloc(15);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3724,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
if(C_truep((C_word)C_i_nullp(t3))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3744,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* match.scm: 1467 reverse */
t6=*((C_word*)lf[77]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t3);}}
else{
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_cadr(t5);
t7=f_3629(((C_word*)t0)[4],t6);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3753,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[3],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* match.scm: 1468 caar */
t9=*((C_word*)lf[63]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t2);}
else{
t8=(C_word)C_i_cdr(t2);
t9=(C_word)C_i_car(t2);
t10=(C_word)C_a_i_cons(&a,2,t9,t3);
/* match.scm: 1486 loop */
t14=t1;
t15=t8;
t16=t10;
t17=t4;
t1=t14;
t2=t15;
t3=t16;
t4=t17;
goto loop;}}}

/* k3751 in loop in inline-let in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_3753(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3753,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3756,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=t1;
t4=((C_word*)t0)[3];
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3473,a[2]=t3,a[3]=t6,a[4]=((C_word)li56),tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_3473(t8,t2,t4);}

/* loop in k3751 in loop in inline-let in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_fcall f_3473(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
loop:
a=C_alloc(5);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3473,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3487,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_car(t2);
/* match.scm: 1420 loop */
t7=t3;
t8=t4;
t1=t7;
t2=t8;
goto loop;}
else{
t3=(C_word)C_eqp(((C_word*)t0)[2],t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?C_fix(1):C_fix(0)));}}

/* k3485 in loop in k3751 in loop in inline-let in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_3487(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3487,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3491,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* match.scm: 1421 loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_3473(t4,t2,t3);}

/* k3489 in k3485 in loop in k3751 in loop in inline-let in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_3491(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3491,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_plus(&a,2,((C_word*)t0)[2],t1));}

/* k3754 in k3751 in loop in inline-let in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_3756(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3756,2,t0,t1);}
if(C_truep((C_word)C_i_nequalp(C_fix(0),t1))){
t2=(C_word)C_i_cdr(((C_word*)t0)[8]);
/* match.scm: 1471 loop */
t3=((C_word*)((C_word*)t0)[7])[1];
f_3724(t3,((C_word*)t0)[6],t2,((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t2=(C_word)C_i_nequalp(C_fix(1),t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3778,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_3778(t4,t2);}
else{
t4=(C_word)C_i_car(((C_word*)t0)[8]);
t5=(C_word)C_i_cadr(t4);
/* match.scm: 1475 small? */
t6=t3;
f_3778(t6,f_3651(((C_word*)t0)[2],t5));}}}

/* k3776 in k3754 in k3751 in loop in inline-let in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_fcall f_3778(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3778,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3789,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[7]);
t5=(C_word)C_i_cadr(t4);
t6=((C_word*)t0)[3];
t7=((C_word*)t0)[2];
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3513,a[2]=t5,a[3]=t7,a[4]=t9,a[5]=((C_word)li55),tmp=(C_word)a,a+=6,tmp));
t11=((C_word*)t9)[1];
f_3513(t11,t3,t6);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
t3=(C_word)C_i_car(((C_word*)t0)[7]);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[4]);
/* match.scm: 1482 loop */
t5=((C_word*)((C_word*)t0)[6])[1];
f_3724(t5,((C_word*)t0)[5],t2,t4,((C_word*)t0)[3]);}}

/* loop in k3776 in k3754 in k3751 in loop in inline-let in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_fcall f_3513(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
loop:
a=C_alloc(5);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3513,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3527,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_car(t2);
/* match.scm: 1427 loop */
t7=t3;
t8=t4;
t1=t7;
t2=t8;
goto loop;}
else{
t3=(C_word)C_eqp(((C_word*)t0)[3],t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?((C_word*)t0)[2]:t2));}}

/* k3525 in loop in k3776 in k3754 in k3751 in loop in inline-let in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_3527(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3527,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3531,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* match.scm: 1428 loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_3513(t4,t2,t3);}

/* k3529 in k3525 in loop in k3776 in k3754 in k3751 in loop in inline-let in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_3531(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3531,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k3787 in k3776 in k3754 in k3751 in loop in inline-let in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_3789(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* match.scm: 1476 loop */
t2=((C_word*)((C_word*)t0)[5])[1];
f_3724(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3742 in loop in inline-let in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_3744(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3744,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[20],t1,((C_word*)t0)[2]));}

/* small? in inline-let in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static C_word C_fcall f_3651(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_stack_check;
t2=f_3547(t1);
if(C_truep(t2)){
return(t2);}
else{
if(C_truep((C_word)C_i_pairp(t1))){
t3=(C_word)C_i_car(t1);
t4=(C_word)C_eqp(t3,lf[19]);
if(C_truep(t4)){
t5=(C_word)C_i_cdr(t1);
if(C_truep((C_word)C_i_pairp(t5))){
t6=(C_word)C_i_cddr(t1);
if(C_truep((C_word)C_i_pairp(t6))){
t7=(C_word)C_i_caddr(t1);
t8=f_3547(t7);
if(C_truep(t8)){
t9=(C_word)C_i_cdddr(t1);
return((C_word)C_i_nullp(t9));}
else{
return(C_SCHEME_FALSE);}}
else{
return(C_SCHEME_FALSE);}}
else{
return(C_SCHEME_FALSE);}}
else{
return(C_SCHEME_FALSE);}}
else{
return(C_SCHEME_FALSE);}}}

/* isval? in inline-let in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static C_word C_fcall f_3629(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_stack_check;
t2=f_3547(t1);
if(C_truep(t2)){
return(t2);}
else{
if(C_truep((C_word)C_i_pairp(t1))){
t3=(C_word)C_i_car(t1);
return((C_word)C_i_memq(t3,lf[93]));}
else{
return(C_SCHEME_FALSE);}}}

/* const? in inline-let in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static C_word C_fcall f_3547(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_stack_check;
t2=(C_word)C_i_symbolp(t1);
if(C_truep(t2)){
return(t2);}
else{
t3=(C_word)C_booleanp(t1);
if(C_truep(t3)){
return(t3);}
else{
t4=(C_word)C_i_stringp(t1);
if(C_truep(t4)){
return(t4);}
else{
t5=(C_word)C_charp(t1);
if(C_truep(t5)){
return(t5);}
else{
t6=(C_word)C_i_numberp(t1);
if(C_truep(t6)){
return(t6);}
else{
t7=(C_word)C_i_nullp(t1);
if(C_truep(t7)){
return(t7);}
else{
if(C_truep((C_word)C_i_pairp(t1))){
t8=(C_word)C_i_car(t1);
t9=(C_word)C_eqp(t8,lf[42]);
if(C_truep(t9)){
t10=(C_word)C_i_cdr(t1);
if(C_truep((C_word)C_i_pairp(t10))){
t11=(C_word)C_i_cadr(t1);
if(C_truep((C_word)C_i_symbolp(t11))){
t12=(C_word)C_i_cddr(t1);
return((C_word)C_i_nullp(t12));}
else{
return(C_SCHEME_FALSE);}}
else{
return(C_SCHEME_FALSE);}}
else{
return(C_SCHEME_FALSE);}}
else{
return(C_SCHEME_FALSE);}}}}}}}}

/* gen in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_fcall f_3848(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[40],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3848,NULL,8,t0,t1,t2,t3,t4,t5,t6,t7);}
if(C_truep((C_word)C_i_nullp(t4))){
/* match.scm: 1489 erract */
t8=t5;
((C_proc3)C_retrieve_proc(t8))(3,t8,t1,t2);}
else{
t8=C_SCHEME_END_OF_LIST;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3859,a[2]=t9,a[3]=((C_word)li22),tmp=(C_word)a,a+=4,tmp);
t11=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3868,a[2]=t7,a[3]=t6,a[4]=t5,a[5]=t2,a[6]=((C_word*)t0)[10],a[7]=t4,a[8]=((C_word)li23),tmp=(C_word)a,a+=9,tmp);
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3877,a[2]=t10,a[3]=t11,a[4]=t4,a[5]=((C_word)li24),tmp=(C_word)a,a+=6,tmp);
t13=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_3973,a[2]=t12,a[3]=t11,a[4]=t3,a[5]=t2,a[6]=t1,a[7]=((C_word*)t0)[2],a[8]=((C_word*)t0)[3],a[9]=((C_word*)t0)[4],a[10]=t6,a[11]=t10,a[12]=t7,a[13]=((C_word*)t0)[5],a[14]=((C_word*)t0)[6],a[15]=((C_word*)t0)[7],a[16]=((C_word*)t0)[8],a[17]=((C_word*)t0)[9],a[18]=t9,tmp=(C_word)a,a+=19,tmp);
/* match.scm: 1516 caar */
t14=*((C_word*)lf[63]+1);
((C_proc3)(void*)(*((C_word*)t14+1)))(3,t14,t13,t4);}}

/* k3971 in gen in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_3973(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3973,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_3975,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[12],a[8]=((C_word*)t0)[13],a[9]=((C_word*)t0)[14],a[10]=((C_word*)t0)[15],a[11]=((C_word*)t0)[16],a[12]=t3,a[13]=((C_word*)t0)[17],a[14]=((C_word*)t0)[18],a[15]=((C_word)li50),tmp=(C_word)a,a+=16,tmp));
t5=((C_word*)t3)[1];
f_3975(t5,((C_word*)t0)[6],t1,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* next in k3971 in gen in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_fcall f_3975(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[75],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3975,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(C_word)C_eqp(lf[72],t2);
if(C_truep(t7)){
/* match.scm: 1522 ks */
t8=t6;
((C_proc3)C_retrieve_proc(t8))(3,t8,t1,t4);}
else{
if(C_truep((C_word)C_i_symbolp(t2))){
t8=(C_word)C_a_i_cons(&a,2,t2,t3);
t9=(C_word)C_a_i_cons(&a,2,t8,((C_word*)((C_word*)t0)[14])[1]);
t10=C_mutate(((C_word *)((C_word*)t0)[14])+1,t9);
/* match.scm: 1524 ks */
t11=t6;
((C_proc3)C_retrieve_proc(t11))(3,t11,t1,t4);}
else{
if(C_truep((C_word)C_i_nullp(t2))){
t8=(C_word)C_a_i_list(&a,2,lf[46],t3);
/* match.scm: 1525 emit */
t9=((C_word*)t0)[13];
f_5121(t9,t1,t8,t4,t5,t6);}
else{
if(C_truep((C_word)C_i_equalp(t2,lf[73]))){
t8=(C_word)C_a_i_list(&a,2,lf[46],t3);
/* match.scm: 1526 emit */
t9=((C_word*)t0)[13];
f_5121(t9,t1,t8,t4,t5,t6);}
else{
if(C_truep((C_word)C_i_stringp(t2))){
t8=(C_word)C_a_i_list(&a,3,lf[36],t3,t2);
/* match.scm: 1527 emit */
t9=((C_word*)t0)[13];
f_5121(t9,t1,t8,t4,t5,t6);}
else{
if(C_truep((C_word)C_booleanp(t2))){
t8=(C_word)C_a_i_list(&a,3,lf[36],t3,t2);
/* match.scm: 1528 emit */
t9=((C_word*)t0)[13];
f_5121(t9,t1,t8,t4,t5,t6);}
else{
if(C_truep((C_word)C_charp(t2))){
t8=(C_word)C_a_i_list(&a,3,lf[36],t3,t2);
/* match.scm: 1529 emit */
t9=((C_word*)t0)[13];
f_5121(t9,t1,t8,t4,t5,t6);}
else{
if(C_truep((C_word)C_i_numberp(t2))){
t8=(C_word)C_a_i_list(&a,3,lf[36],t3,t2);
/* match.scm: 1530 emit */
t9=((C_word*)t0)[13];
f_5121(t9,t1,t8,t4,t5,t6);}
else{
t8=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_4086,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[14],a[13]=((C_word*)t0)[12],a[14]=t6,a[15]=t5,a[16]=t4,a[17]=t1,a[18]=((C_word*)t0)[13],a[19]=t2,a[20]=t3,tmp=(C_word)a,a+=21,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t9=(C_word)C_i_car(t2);
t10=t8;
f_4086(t10,(C_word)C_eqp(lf[42],t9));}
else{
t9=t8;
f_4086(t9,C_SCHEME_FALSE);}}}}}}}}}}

/* k4084 in next in k3971 in gen in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_fcall f_4086(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4086,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_list(&a,3,lf[36],((C_word*)t0)[20],((C_word*)t0)[19]);
/* match.scm: 1531 emit */
t3=((C_word*)t0)[18];
f_5121(t3,((C_word*)t0)[17],t2,((C_word*)t0)[16],((C_word*)t0)[15],((C_word*)t0)[14]);}
else{
t2=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_4099,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[19],tmp=(C_word)a,a+=21,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[19]))){
t3=(C_word)C_i_car(((C_word*)t0)[19]);
t4=t2;
f_4099(t4,(C_word)C_eqp(lf[74],t3));}
else{
t3=t2;
f_4099(t3,C_SCHEME_FALSE);}}}

/* k4097 in k4084 in next in k3971 in gen in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_fcall f_4099(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4099,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[20]);
t3=(C_word)C_a_i_list(&a,2,t2,((C_word*)t0)[19]);
/* match.scm: 1539 emit */
t4=((C_word*)t0)[18];
f_5121(t4,((C_word*)t0)[17],t3,((C_word*)t0)[16],((C_word*)t0)[15],((C_word*)t0)[14]);}
else{
t2=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_4115,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[18],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[13],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],tmp=(C_word)a,a+=21,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[20]))){
t3=(C_word)C_i_car(((C_word*)t0)[20]);
t4=t2;
f_4115(t4,(C_word)C_eqp(lf[92],t3));}
else{
t3=t2;
f_4115(t3,C_SCHEME_FALSE);}}}

/* k4113 in k4097 in k4084 in next in k3971 in gen in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_fcall f_4115(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4115,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_caddr(((C_word*)t0)[20]);
t3=(C_word)C_i_cadr(((C_word*)t0)[20]);
t4=(C_word)C_a_i_list(&a,2,t3,((C_word*)t0)[19]);
/* match.scm: 1543 next */
t5=((C_word*)((C_word*)t0)[18])[1];
f_3975(t5,((C_word*)t0)[17],t2,t4,((C_word*)t0)[16],((C_word*)t0)[15],((C_word*)t0)[14]);}
else{
t2=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_4136,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[16],a[15]=((C_word*)t0)[17],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[19],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[14],a[20]=((C_word*)t0)[20],tmp=(C_word)a,a+=21,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[20]))){
t3=(C_word)C_i_car(((C_word*)t0)[20]);
t4=t2;
f_4136(t4,(C_word)C_eqp(lf[50],t3));}
else{
t3=t2;
f_4136(t3,C_SCHEME_FALSE);}}}

/* k4134 in k4113 in k4097 in k4084 in next in k3971 in gen in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_fcall f_4136(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4136,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[20]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4145,a[2]=((C_word*)t0)[16],a[3]=((C_word*)t0)[17],a[4]=((C_word*)t0)[18],a[5]=t4,a[6]=((C_word*)t0)[19],a[7]=((C_word)li26),tmp=(C_word)a,a+=8,tmp));
t6=((C_word*)t4)[1];
f_4145(t6,((C_word*)t0)[15],t2,((C_word*)t0)[14]);}
else{
t2=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_4178,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[19],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[16],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[13],tmp=(C_word)a,a+=21,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[20]))){
t3=(C_word)C_i_car(((C_word*)t0)[20]);
t4=t2;
f_4178(t4,(C_word)C_eqp(lf[91],t3));}
else{
t3=t2;
f_4178(t3,C_SCHEME_FALSE);}}}

/* k4176 in k4134 in k4113 in k4097 in k4084 in next in k3971 in gen in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_fcall f_4178(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4178,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)((C_word*)t0)[20])[1];
t3=(C_word)C_i_cdr(((C_word*)t0)[19]);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4187,a[2]=((C_word*)t0)[15],a[3]=((C_word*)t0)[16],a[4]=((C_word*)t0)[17],a[5]=t5,a[6]=t2,a[7]=((C_word*)t0)[20],a[8]=((C_word*)t0)[18],a[9]=((C_word)li28),tmp=(C_word)a,a+=10,tmp));
t7=((C_word*)t5)[1];
f_4187(t7,((C_word*)t0)[14],t3,((C_word*)t0)[13]);}
else{
t2=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_4221,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[20],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[18],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[13],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[14],a[19]=((C_word*)t0)[17],a[20]=((C_word*)t0)[19],tmp=(C_word)a,a+=21,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[19]))){
t3=(C_word)C_i_car(((C_word*)t0)[19]);
t4=t2;
f_4221(t4,(C_word)C_eqp(lf[43],t3));}
else{
t3=t2;
f_4221(t3,C_SCHEME_FALSE);}}}

/* k4219 in k4176 in k4134 in k4113 in k4097 in k4084 in next in k3971 in gen in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_fcall f_4221(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4221,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[20]);
/* match.scm: 1577 next */
t3=((C_word*)((C_word*)t0)[19])[1];
f_3975(t3,((C_word*)t0)[18],t2,((C_word*)t0)[17],((C_word*)t0)[16],((C_word*)t0)[15],((C_word*)t0)[14]);}
else{
t2=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_4234,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[19],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[13],a[19]=((C_word*)t0)[17],a[20]=((C_word*)t0)[20],tmp=(C_word)a,a+=21,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[20]))){
t3=(C_word)C_i_car(((C_word*)t0)[20]);
t4=t2;
f_4234(t4,(C_word)C_eqp(lf[90],t3));}
else{
t3=t2;
f_4234(t3,C_SCHEME_FALSE);}}}

/* k4232 in k4219 in k4176 in k4134 in k4113 in k4097 in k4084 in next in k3971 in gen in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_fcall f_4234(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[37],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4234,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[20]);
t3=(C_word)C_i_cdr(((C_word*)t0)[20]);
t4=(C_word)C_i_length(t3);
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4290,a[2]=((C_word*)t0)[13],a[3]=t3,a[4]=((C_word*)t0)[14],a[5]=t4,a[6]=((C_word*)t0)[15],a[7]=((C_word*)t0)[16],a[8]=((C_word*)t0)[17],a[9]=((C_word*)t0)[18],a[10]=((C_word*)t0)[19],tmp=(C_word)a,a+=11,tmp);
/* match.scm: 1586 symbol-append */
f_7371(t5,(C_word)C_a_i_list(&a,2,t2,lf[74]));}
else{
t2=(*a=C_CLOSURE_TYPE|19,a[1]=(C_word)f_4296,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[18],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[13],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[15],a[11]=((C_word*)t0)[8],a[12]=((C_word*)t0)[9],a[13]=((C_word*)t0)[19],a[14]=((C_word*)t0)[10],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[14],a[18]=((C_word*)t0)[11],a[19]=((C_word*)t0)[20],tmp=(C_word)a,a+=20,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[20]))){
t3=(C_word)C_i_car(((C_word*)t0)[20]);
t4=t2;
f_4296(t4,(C_word)C_eqp(lf[89],t3));}
else{
t3=t2;
f_4296(t3,C_SCHEME_FALSE);}}}

/* k4294 in k4232 in k4219 in k4176 in k4134 in k4113 in k4097 in k4084 in next in k3971 in gen in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_fcall f_4296(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4296,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[19]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4315,a[2]=((C_word*)t0)[15],a[3]=((C_word*)t0)[16],a[4]=((C_word*)t0)[17],a[5]=((C_word*)t0)[18],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* match.scm: 1609 setter */
t4=((C_word*)t0)[14];
f_6801(t4,t3,((C_word*)t0)[13],((C_word*)t0)[19]);}
else{
t2=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_4321,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],tmp=(C_word)a,a+=19,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[19]))){
t3=(C_word)C_i_car(((C_word*)t0)[19]);
t4=t2;
f_4321(t4,(C_word)C_eqp(lf[88],t3));}
else{
t3=t2;
f_4321(t3,C_SCHEME_FALSE);}}}

/* k4319 in k4294 in k4232 in k4219 in k4176 in k4134 in k4113 in k4097 in k4084 in next in k3971 in gen in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_fcall f_4321(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4321,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[18]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4340,a[2]=((C_word*)t0)[14],a[3]=((C_word*)t0)[15],a[4]=((C_word*)t0)[16],a[5]=((C_word*)t0)[17],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* match.scm: 1616 getter */
t4=((C_word*)t0)[13];
f_7106(t4,t3,((C_word*)t0)[12],((C_word*)t0)[18]);}
else{
t2=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_4346,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[14],a[5]=((C_word*)t0)[15],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[17],a[11]=((C_word*)t0)[8],a[12]=((C_word*)t0)[9],a[13]=((C_word*)t0)[10],a[14]=((C_word*)t0)[11],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[18],a[17]=((C_word*)t0)[12],tmp=(C_word)a,a+=18,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[18]))){
t3=(C_word)C_i_cdr(((C_word*)t0)[18]);
if(C_truep((C_word)C_i_pairp(t3))){
t4=(C_word)C_i_cadr(((C_word*)t0)[18]);
/* match.scm: 1623 dot-dot-k? */
f_1327(t2,t4);}
else{
t4=t2;
f_4346(2,t4,C_SCHEME_FALSE);}}
else{
t3=t2;
f_4346(2,t3,C_SCHEME_FALSE);}}}

/* k4344 in k4319 in k4294 in k4232 in k4219 in k4176 in k4134 in k4113 in k4097 in k4084 in next in k3971 in gen in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_4346(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[55],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4346,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_list(&a,2,lf[44],((C_word*)t0)[17]);
t3=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_4355,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[12],a[9]=((C_word*)t0)[13],a[10]=((C_word*)t0)[14],a[11]=((C_word*)t0)[17],a[12]=((C_word*)t0)[15],a[13]=((C_word*)t0)[16],a[14]=((C_word)li38),tmp=(C_word)a,a+=15,tmp);
/* match.scm: 1623 emit */
t4=((C_word*)t0)[8];
f_5121(t4,((C_word*)t0)[5],t2,((C_word*)t0)[4],((C_word*)t0)[13],t3);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[16]))){
t2=(C_word)C_a_i_list(&a,2,lf[47],((C_word*)t0)[17]);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4653,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[17],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[15],a[6]=((C_word*)t0)[13],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[16],a[9]=((C_word)li40),tmp=(C_word)a,a+=10,tmp);
/* match.scm: 1724 emit */
t4=((C_word*)t0)[8];
f_5121(t4,((C_word*)t0)[5],t2,((C_word*)t0)[4],((C_word*)t0)[13],t3);}
else{
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_4685,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[13],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[15],a[11]=((C_word*)t0)[14],a[12]=((C_word*)t0)[17],a[13]=((C_word*)t0)[16],tmp=(C_word)a,a+=14,tmp);
if(C_truep((C_word)C_i_vectorp(((C_word*)t0)[16]))){
t3=(C_word)C_i_vector_length(((C_word*)t0)[16]);
if(C_truep((C_word)C_i_greater_or_equalp(t3,C_fix(6)))){
t4=(C_word)C_i_vector_length(((C_word*)t0)[16]);
t5=(C_word)C_a_i_minus(&a,2,t4,C_fix(5));
t6=(C_word)C_i_vector_ref(((C_word*)t0)[16],t5);
/* match.scm: 1740 dot-dot-k? */
f_1327(t2,t6);}
else{
t4=t2;
f_4685(2,t4,C_SCHEME_FALSE);}}
else{
t3=t2;
f_4685(2,t3,C_SCHEME_FALSE);}}}}

/* k4683 in k4344 in k4319 in k4294 in k4232 in k4219 in k4176 in k4134 in k4113 in k4097 in k4084 in next in k3971 in gen in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_4685(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[41],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4685,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_vector_length(((C_word*)t0)[13]);
t3=(C_word)C_a_i_minus(&a,2,t2,C_fix(6));
t4=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_4691,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=t3,tmp=(C_word)a,a+=14,tmp);
t5=(C_word)C_a_i_plus(&a,2,t3,C_fix(1));
t6=(C_word)C_i_vector_ref(((C_word*)t0)[13],t5);
/* match.scm: 1746 dot-dot-k? */
f_1327(t4,t6);}
else{
if(C_truep((C_word)C_i_vectorp(((C_word*)t0)[13]))){
t2=(C_word)C_i_vector_length(((C_word*)t0)[13]);
t3=(C_word)C_a_i_list(&a,2,lf[78],((C_word*)t0)[12]);
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4923,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[5],a[7]=t2,a[8]=((C_word*)t0)[12],a[9]=((C_word)li49),tmp=(C_word)a,a+=10,tmp);
/* match.scm: 1834 emit */
t5=((C_word*)t0)[5];
f_5121(t5,((C_word*)t0)[4],t3,((C_word*)t0)[3],((C_word*)t0)[6],t4);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4975,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* match.scm: 1859 display */
t3=*((C_word*)lf[86]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[87]);}}}

/* k4973 in k4683 in k4344 in k4319 in k4294 in k4232 in k4219 in k4176 in k4134 in k4113 in k4097 in k4084 in next in k3971 in gen in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_4975(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4975,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4978,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* match.scm: 1861 newline */
t3=*((C_word*)lf[85]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k4976 in k4973 in k4683 in k4344 in k4319 in k4294 in k4232 in k4219 in k4176 in k4134 in k4113 in k4097 in k4084 in next in k3971 in gen in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_4978(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* match.scm: 1862 ##sys#error */
t2=*((C_word*)lf[83]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_SCHEME_FALSE,lf[84]);}

/* a4922 in k4683 in k4344 in k4319 in k4294 in k4232 in k4219 in k4176 in k4134 in k4113 in k4097 in k4084 in next in k3971 in gen in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_4923(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[34],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4923,3,t0,t1,t2);}
t3=(C_word)C_a_i_list(&a,2,lf[79],((C_word*)t0)[8]);
t4=(C_word)C_a_i_list(&a,3,lf[36],t3,((C_word*)t0)[7]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4935,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=t4,a[5]=t1,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4937,a[2]=t7,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[7],a[9]=((C_word)li48),tmp=(C_word)a,a+=10,tmp));
t9=((C_word*)t7)[1];
f_4937(t9,t5,C_fix(0));}

/* vloop in a4922 in k4683 in k4344 in k4319 in k4294 in k4232 in k4219 in k4176 in k4134 in k4113 in k4097 in k4084 in next in k3971 in gen in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_fcall f_4937(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4937,NULL,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4939,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t2,a[10]=((C_word)li47),tmp=(C_word)a,a+=11,tmp));}

/* f_4939 in vloop in a4922 in k4683 in k4344 in k4319 in k4294 in k4232 in k4219 in k4176 in k4134 in k4113 in k4097 in k4084 in next in k3971 in gen in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_4939(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[21],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4939,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nequalp(((C_word*)t0)[9],((C_word*)t0)[8]))){
/* match.scm: 1847 ks */
t3=((C_word*)t0)[7];
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,t2);}
else{
t3=(C_word)C_i_vector_ref(((C_word*)t0)[6],((C_word*)t0)[9]);
t4=(C_word)C_a_i_list(&a,3,lf[17],((C_word*)t0)[5],((C_word*)t0)[9]);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4964,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t4,a[5]=t3,a[6]=t1,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
t6=(C_word)C_a_i_plus(&a,2,C_fix(1),((C_word*)t0)[9]);
/* match.scm: 1856 vloop */
t7=((C_word*)((C_word*)t0)[2])[1];
f_4937(t7,t5,t6);}}

/* k4962 */
static void C_ccall f_4964(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* match.scm: 1848 next */
t2=((C_word*)((C_word*)t0)[7])[1];
f_3975(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4933 in a4922 in k4683 in k4344 in k4319 in k4294 in k4232 in k4219 in k4176 in k4134 in k4113 in k4097 in k4084 in next in k3971 in gen in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_4935(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* match.scm: 1838 emit */
t2=((C_word*)t0)[6];
f_5121(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4689 in k4683 in k4344 in k4319 in k4294 in k4232 in k4219 in k4176 in k4134 in k4113 in k4097 in k4084 in next in k3971 in gen in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_4691(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4691,2,t0,t1);}
t2=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[13],t1);
t3=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[13],C_fix(2));
t4=(C_word)C_i_vector_ref(((C_word*)t0)[12],t3);
t5=(C_word)C_a_i_list(&a,2,lf[78],((C_word*)t0)[11]);
t6=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_4706,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=t4,a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[12],a[9]=((C_word*)t0)[13],a[10]=((C_word*)t0)[10],a[11]=t2,a[12]=((C_word*)t0)[11],a[13]=((C_word)li46),tmp=(C_word)a,a+=14,tmp);
/* match.scm: 1757 emit */
t7=((C_word*)t0)[4];
f_5121(t7,((C_word*)t0)[3],t5,((C_word*)t0)[2],((C_word*)t0)[5],t6);}

/* a4705 in k4689 in k4683 in k4344 in k4319 in k4294 in k4232 in k4219 in k4176 in k4134 in k4113 in k4097 in k4084 in next in k3971 in gen in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_4706(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[31],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4706,3,t0,t1,t2);}
t3=(C_word)C_a_i_list(&a,2,lf[79],((C_word*)t0)[12]);
t4=(C_word)C_a_i_list(&a,3,lf[80],t3,((C_word*)t0)[11]);
t5=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_4718,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[12],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],a[12]=t2,a[13]=t4,a[14]=t1,a[15]=((C_word*)t0)[10],tmp=(C_word)a,a+=16,tmp);
/* match.scm: 1765 kf */
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}

/* k4716 in a4705 in k4689 in k4683 in k4344 in k4319 in k4294 in k4232 in k4219 in k4176 in k4134 in k4113 in k4097 in k4084 in next in k3971 in gen in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_4718(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4718,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4722,a[2]=t1,a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[14],a[5]=((C_word*)t0)[15],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4725,a[2]=((C_word*)t0)[12],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_4727,a[2]=t5,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word)li45),tmp=(C_word)a,a+=14,tmp));
t7=((C_word*)t5)[1];
f_4727(t7,t3,C_fix(0));}

/* vloop in k4716 in a4705 in k4689 in k4683 in k4344 in k4319 in k4294 in k4232 in k4219 in k4176 in k4134 in k4113 in k4097 in k4084 in next in k3971 in gen in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_fcall f_4727(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4727,NULL,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_4729,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=t2,a[14]=((C_word)li44),tmp=(C_word)a,a+=15,tmp));}

/* f_4729 in vloop in k4716 in a4705 in k4689 in k4683 in k4344 in k4319 in k4294 in k4232 in k4219 in k4176 in k4134 in k4113 in k4097 in k4084 in next in k3971 in gen in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_4729(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[62],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4729,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nequalp(((C_word*)t0)[13],((C_word*)t0)[12]))){
t3=(C_word)C_i_vector_ref(((C_word*)t0)[11],((C_word*)t0)[12]);
t4=(C_word)C_eqp(t3,lf[72]);
if(C_truep(t4)){
/* match.scm: 1784 ks */
t5=((C_word*)t0)[10];
((C_proc3)C_retrieve_proc(t5))(3,t5,t1,t2);}
else{
t5=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[12],C_fix(3));
t6=(C_word)C_i_vector_ref(((C_word*)t0)[11],t5);
t7=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[12],C_fix(4));
t8=(C_word)C_i_vector_ref(((C_word*)t0)[11],t7);
t9=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[12],C_fix(5));
t10=(C_word)C_i_vector_ref(((C_word*)t0)[11],t9);
t11=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4776,a[2]=((C_word*)t0)[6],a[3]=t10,a[4]=t2,a[5]=((C_word*)t0)[10],a[6]=t6,a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=t8,a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],tmp=(C_word)a,a+=12,tmp);
t12=(C_word)C_i_vector_ref(((C_word*)t0)[11],((C_word*)t0)[12]);
t13=(C_word)C_a_i_list(&a,3,lf[17],((C_word*)t0)[8],t8);
t14=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4839,a[2]=t10,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[5],a[5]=t6,a[6]=t8,a[7]=((C_word)li43),tmp=(C_word)a,a+=8,tmp);
/* match.scm: 1797 next */
t15=((C_word*)((C_word*)t0)[4])[1];
f_3975(t15,t11,t12,t13,t2,((C_word*)t0)[3],t14);}}
else{
t3=(C_word)C_i_vector_ref(((C_word*)t0)[11],((C_word*)t0)[13]);
t4=(C_word)C_a_i_list(&a,3,lf[17],((C_word*)t0)[8],((C_word*)t0)[13]);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4751,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t4,a[5]=t3,a[6]=t1,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
t6=(C_word)C_a_i_plus(&a,2,C_fix(1),((C_word*)t0)[13]);
/* match.scm: 1778 vloop */
t7=((C_word*)((C_word*)t0)[2])[1];
f_4727(t7,t5,t6);}}

/* k4749 */
static void C_ccall f_4751(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* match.scm: 1770 next */
t2=((C_word*)((C_word*)t0)[7])[1];
f_3975(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a4838 */
static void C_ccall f_4839(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[18],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4839,3,t0,t1,t2);}
t3=(C_word)C_a_i_list(&a,3,lf[81],((C_word*)t0)[6],C_fix(1));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4855,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4857,a[2]=((C_word*)t0)[4],a[3]=((C_word)li42),tmp=(C_word)a,a+=4,tmp);
/* match.scm: 1809 map */
t6=*((C_word*)lf[75]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t4,t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a4856 in a4838 */
static void C_ccall f_4857(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4857,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4865,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* match.scm: 1811 val */
t5=((C_word*)t0)[2];
f_3859(3,t5,t4,t2);}

/* k4863 in a4856 in a4838 */
static void C_ccall f_4865(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4865,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[76],t1,((C_word*)t0)[2]));}

/* k4853 in a4838 */
static void C_ccall f_4855(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4855,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* k4774 */
static void C_ccall f_4776(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4776,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4780,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4829,a[2]=((C_word*)t0)[11],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* match.scm: 1817 map */
t4=*((C_word*)lf[75]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,*((C_word*)lf[76]+1),((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k4827 in k4774 */
static void C_ccall f_4829(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* match.scm: 1816 append */
t2=*((C_word*)lf[66]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)((C_word*)t0)[2])[1]);}

/* k4778 in k4774 */
static void C_ccall f_4780(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[34],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4780,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[11])+1,t1);
t3=(C_word)C_a_i_list(&a,2,lf[79],((C_word*)t0)[10]);
t4=(C_word)C_a_i_list(&a,3,lf[81],t3,C_fix(1));
t5=(C_word)C_a_i_list(&a,2,((C_word*)t0)[9],t4);
t6=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4807,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[8],a[9]=t5,tmp=(C_word)a,a+=10,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4809,a[2]=((C_word)li41),tmp=(C_word)a,a+=3,tmp);
/* map */
t8=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,t7,((C_word*)t0)[2]);}

/* a4808 in k4778 in k4774 */
static void C_ccall f_4809(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4809,3,t0,t1,t2);}
t3=(C_word)C_a_i_list(&a,2,lf[42],C_SCHEME_END_OF_LIST);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,2,t2,t3));}

/* k4805 in k4778 in k4774 */
static void C_ccall f_4807(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4807,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t1);
t3=(C_word)C_a_i_list(&a,3,lf[82],((C_word*)t0)[8],((C_word*)t0)[7]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4799,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* match.scm: 1830 ks */
t5=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[2]);}

/* k4797 in k4805 in k4778 in k4774 */
static void C_ccall f_4799(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4799,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,4,lf[49],((C_word*)t0)[6],t1,((C_word*)t0)[5]);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,4,lf[20],((C_word*)t0)[3],((C_word*)t0)[2],t2));}

/* k4723 in k4716 in a4705 in k4689 in k4683 in k4344 in k4319 in k4294 in k4232 in k4219 in k4176 in k4134 in k4113 in k4097 in k4084 in next in k3971 in gen in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_4725(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4720 in k4716 in a4705 in k4689 in k4683 in k4344 in k4319 in k4294 in k4232 in k4219 in k4176 in k4134 in k4113 in k4097 in k4084 in next in k3971 in gen in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_4722(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* match.scm: 1762 assm */
t2=((C_word*)((C_word*)t0)[5])[1];
f_5303(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a4652 in k4344 in k4319 in k4294 in k4232 in k4219 in k4176 in k4134 in k4113 in k4097 in k4084 in next in k3971 in gen in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_4653(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4653,3,t0,t1,t2);}
t3=(C_word)C_i_car(((C_word*)t0)[8]);
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4665,a[2]=t2,a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp);
/* match.scm: 1729 add-a */
t5=((C_word*)t0)[2];
f_6734(t5,t4,((C_word*)t0)[3]);}

/* k4663 in a4652 in k4344 in k4319 in k4294 in k4232 in k4219 in k4176 in k4134 in k4113 in k4097 in k4084 in next in k3971 in gen in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_4665(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4665,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4667,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word)li39),tmp=(C_word)a,a+=9,tmp);
/* match.scm: 1728 next */
t3=((C_word*)((C_word*)t0)[9])[1];
f_3975(t3,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2],((C_word*)t0)[8],t2);}

/* a4666 in k4663 in a4652 in k4344 in k4319 in k4294 in k4232 in k4219 in k4176 in k4134 in k4113 in k4097 in k4084 in next in k3971 in gen in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_4667(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4667,3,t0,t1,t2);}
t3=(C_word)C_i_cdr(((C_word*)t0)[7]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4679,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t2,a[5]=t3,a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* match.scm: 1734 add-d */
t5=((C_word*)t0)[3];
f_6767(t5,t4,((C_word*)t0)[2]);}

/* k4677 in a4666 in k4663 in a4652 in k4344 in k4319 in k4294 in k4232 in k4219 in k4176 in k4134 in k4113 in k4097 in k4084 in next in k3971 in gen in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_4679(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* match.scm: 1733 next */
t2=((C_word*)((C_word*)t0)[7])[1];
f_3975(t2,((C_word*)t0)[6],((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a4354 in k4344 in k4319 in k4294 in k4232 in k4219 in k4176 in k4134 in k4113 in k4097 in k4084 in next in k3971 in gen in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_4355(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4355,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_4359,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],tmp=(C_word)a,a+=15,tmp);
t4=(C_word)C_i_cadr(((C_word*)t0)[13]);
/* match.scm: 1627 dot-dot-k? */
f_1327(t3,t4);}

/* k4357 in a4354 in k4344 in k4319 in k4294 in k4232 in k4219 in k4176 in k4134 in k4113 in k4097 in k4084 in next in k3971 in gen in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_4359(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4359,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4360,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[12],a[9]=((C_word*)t0)[13],a[10]=((C_word*)t0)[14],a[11]=((C_word)li37),tmp=(C_word)a,a+=12,tmp);
switch(t1){
case C_fix(0):
/* match.scm: 1712 ks */
t3=t2;
f_4360(3,t3,((C_word*)t0)[5],((C_word*)t0)[4]);
case C_fix(1):
t3=(C_word)C_a_i_list(&a,2,lf[47],((C_word*)t0)[12]);
/* match.scm: 1713 emit */
t4=((C_word*)t0)[3];
f_5121(t4,((C_word*)t0)[5],t3,((C_word*)t0)[4],((C_word*)t0)[10],t2);
default:
t3=(C_word)C_a_i_list(&a,2,((C_word*)t0)[2],t1);
t4=(C_word)C_a_i_list(&a,2,t3,((C_word*)t0)[12]);
/* match.scm: 1718 emit */
t5=((C_word*)t0)[3];
f_5121(t5,((C_word*)t0)[5],t4,((C_word*)t0)[4],((C_word*)t0)[10],t2);}}

/* ks in k4357 in a4354 in k4344 in k4319 in k4294 in k4232 in k4219 in k4176 in k4134 in k4113 in k4097 in k4084 in next in k3971 in gen in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_4360(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[30],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4360,3,t0,t1,t2);}
t3=(C_word)C_i_list_ref(((C_word*)t0)[10],C_fix(2));
t4=(C_word)C_i_car(((C_word*)t0)[10]);
t5=(C_word)C_eqp(t4,lf[72]);
if(C_truep(t5)){
/* match.scm: 1635 ks */
t6=((C_word*)t0)[9];
((C_proc3)C_retrieve_proc(t6))(3,t6,t1,t2);}
else{
if(C_truep((C_word)C_i_nullp(t3))){
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4382,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t2,a[5]=((C_word*)t0)[9],a[6]=t1,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t7=(C_word)C_i_car(((C_word*)t0)[10]);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4459,a[2]=((C_word)li31),tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4462,a[2]=((C_word)li32),tmp=(C_word)a,a+=3,tmp);
/* match.scm: 1637 next */
t10=((C_word*)((C_word*)t0)[4])[1];
f_3975(t10,t6,t7,((C_word*)t0)[5],t2,t8,t9);}
else{
t6=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4469,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[6],a[7]=t2,a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[4],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
t7=(C_word)C_i_car(((C_word*)t0)[10]);
if(C_truep((C_word)C_i_symbolp(t7))){
t8=(C_word)C_i_car(((C_word*)t0)[10]);
t9=(C_word)C_a_i_list(&a,1,t8);
t10=t6;
f_4469(t10,(C_word)C_i_equalp(t9,t3));}
else{
t8=t6;
f_4469(t8,C_SCHEME_FALSE);}}}}

/* k4467 in ks in k4357 in a4354 in k4344 in k4319 in k4294 in k4232 in k4219 in k4176 in k4134 in k4113 in k4097 in k4084 in next in k3971 in gen in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_fcall f_4469(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4469,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[11]);
/* match.scm: 1666 next */
t3=((C_word*)((C_word*)t0)[10])[1];
f_3975(t3,((C_word*)t0)[9],t2,((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5]);}
else{
t2=(C_word)C_i_list_ref(((C_word*)t0)[11],C_fix(3));
t3=(C_word)C_i_list_ref(((C_word*)t0)[11],C_fix(4));
t4=(C_word)C_i_list_ref(((C_word*)t0)[11],C_fix(5));
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4488,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[8],a[9]=t3,a[10]=((C_word*)t0)[4],tmp=(C_word)a,a+=11,tmp);
t6=(C_word)C_i_car(((C_word*)t0)[11]);
t7=(C_word)C_a_i_list(&a,2,lf[22],t3);
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4553,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[2],a[5]=t2,a[6]=t3,a[7]=((C_word)li36),tmp=(C_word)a,a+=8,tmp);
/* match.scm: 1680 next */
t9=((C_word*)((C_word*)t0)[10])[1];
f_3975(t9,t5,t6,t7,((C_word*)t0)[7],((C_word*)t0)[6],t8);}}

/* a4552 in k4467 in ks in k4357 in a4354 in k4344 in k4319 in k4294 in k4232 in k4219 in k4176 in k4134 in k4113 in k4097 in k4084 in next in k3971 in gen in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_4553(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4553,3,t0,t1,t2);}
t3=(C_word)C_a_i_list(&a,2,lf[23],((C_word*)t0)[6]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4569,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4571,a[2]=((C_word*)t0)[4],a[3]=((C_word)li35),tmp=(C_word)a,a+=4,tmp);
/* match.scm: 1687 map */
t6=*((C_word*)lf[75]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t4,t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a4570 in a4552 in k4467 in ks in k4357 in a4354 in k4344 in k4319 in k4294 in k4232 in k4219 in k4176 in k4134 in k4113 in k4097 in k4084 in next in k3971 in gen in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_4571(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4571,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4579,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* match.scm: 1689 val */
t5=((C_word*)t0)[2];
f_3859(3,t5,t4,t2);}

/* k4577 in a4570 in a4552 in k4467 in ks in k4357 in a4354 in k4344 in k4319 in k4294 in k4232 in k4219 in k4176 in k4134 in k4113 in k4097 in k4084 in next in k3971 in gen in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_4579(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4579,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[76],t1,((C_word*)t0)[2]));}

/* k4567 in a4552 in k4467 in ks in k4357 in a4354 in k4344 in k4319 in k4294 in k4232 in k4219 in k4176 in k4134 in k4113 in k4097 in k4084 in next in k3971 in gen in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_4569(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4569,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* k4486 in k4467 in ks in k4357 in a4354 in k4344 in k4319 in k4294 in k4232 in k4219 in k4176 in k4134 in k4113 in k4097 in k4084 in next in k3971 in gen in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_4488(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4488,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4492,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4533,a[2]=((C_word*)t0)[10],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4537,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4539,a[2]=((C_word)li34),tmp=(C_word)a,a+=3,tmp);
/* map */
t6=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,((C_word*)t0)[3]);}

/* a4538 in k4486 in k4467 in ks in k4357 in a4354 in k4344 in k4319 in k4294 in k4232 in k4219 in k4176 in k4134 in k4113 in k4097 in k4084 in next in k3971 in gen in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_4539(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4539,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[77],t2));}

/* k4535 in k4486 in k4467 in ks in k4357 in a4354 in k4344 in k4319 in k4294 in k4232 in k4219 in k4176 in k4134 in k4113 in k4097 in k4084 in next in k3971 in gen in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_4537(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* match.scm: 1695 map */
t2=*((C_word*)lf[75]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],*((C_word*)lf[76]+1),((C_word*)t0)[2],t1);}

/* k4531 in k4486 in k4467 in ks in k4357 in a4354 in k4344 in k4319 in k4294 in k4232 in k4219 in k4176 in k4134 in k4113 in k4097 in k4084 in next in k3971 in gen in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_4533(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* match.scm: 1694 append */
t2=*((C_word*)lf[66]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)((C_word*)t0)[2])[1]);}

/* k4490 in k4486 in k4467 in ks in k4357 in a4354 in k4344 in k4319 in k4294 in k4232 in k4219 in k4176 in k4134 in k4113 in k4097 in k4084 in next in k3971 in gen in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_4492(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4492,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[10])+1,t1);
t3=(C_word)C_a_i_list(&a,2,((C_word*)t0)[9],((C_word*)t0)[8]);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4519,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[9],a[8]=t3,tmp=(C_word)a,a+=9,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4521,a[2]=((C_word)li33),tmp=(C_word)a,a+=3,tmp);
/* map */
t6=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,((C_word*)t0)[2]);}

/* a4520 in k4490 in k4486 in k4467 in ks in k4357 in a4354 in k4344 in k4319 in k4294 in k4232 in k4219 in k4176 in k4134 in k4113 in k4097 in k4084 in next in k3971 in gen in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_4521(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4521,3,t0,t1,t2);}
t3=(C_word)C_a_i_list(&a,2,lf[42],C_SCHEME_END_OF_LIST);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,2,t2,t3));}

/* k4517 in k4490 in k4486 in k4467 in ks in k4357 in a4354 in k4344 in k4319 in k4294 in k4232 in k4219 in k4176 in k4134 in k4113 in k4097 in k4084 in next in k3971 in gen in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_4519(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4519,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
t3=(C_word)C_a_i_list(&a,2,lf[46],((C_word*)t0)[7]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4511,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* match.scm: 1709 ks */
t5=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[2]);}

/* k4509 in k4517 in k4490 in k4486 in k4467 in ks in k4357 in a4354 in k4344 in k4319 in k4294 in k4232 in k4219 in k4176 in k4134 in k4113 in k4097 in k4084 in next in k3971 in gen in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_4511(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4511,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,4,lf[49],((C_word*)t0)[6],t1,((C_word*)t0)[5]);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,4,lf[20],((C_word*)t0)[3],((C_word*)t0)[2],t2));}

/* a4461 in ks in k4357 in a4354 in k4344 in k4319 in k4294 in k4232 in k4219 in k4176 in k4134 in k4113 in k4097 in k4084 in next in k3971 in gen in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_4462(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4462,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_TRUE);}

/* a4458 in ks in k4357 in a4354 in k4344 in k4319 in k4294 in k4232 in k4219 in k4176 in k4134 in k4113 in k4097 in k4084 in next in k3971 in gen in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_4459(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4459,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}

/* k4380 in ks in k4357 in a4354 in k4344 in k4319 in k4294 in k4232 in k4219 in k4176 in k4134 in k4113 in k4097 in k4084 in next in k3971 in gen in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_4382(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4382,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4385,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4403,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(t1))){
t4=(C_word)C_i_car(t1);
if(C_truep((C_word)C_i_symbolp(t4))){
t5=(C_word)C_i_cdr(t1);
if(C_truep((C_word)C_i_pairp(t5))){
t6=(C_word)C_i_cadr(t1);
t7=(C_word)C_eqp(((C_word*)t0)[2],t6);
if(C_truep(t7)){
t8=(C_word)C_i_cddr(t1);
t9=t3;
f_4403(t9,(C_word)C_i_nullp(t8));}
else{
t8=t3;
f_4403(t8,C_SCHEME_FALSE);}}
else{
t6=t3;
f_4403(t6,C_SCHEME_FALSE);}}
else{
t5=t3;
f_4403(t5,C_SCHEME_FALSE);}}
else{
t4=t3;
f_4403(t4,C_SCHEME_FALSE);}}

/* k4401 in k4380 in ks in k4357 in a4354 in k4344 in k4319 in k4294 in k4232 in k4219 in k4176 in k4134 in k4113 in k4097 in k4084 in next in k3971 in gen in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_fcall f_4403(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4403,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_4385(t2,(C_word)C_i_car(((C_word*)t0)[3]));}
else{
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
t3=((C_word*)t0)[4];
f_4385(t3,(C_word)C_a_i_list(&a,3,lf[19],t2,((C_word*)t0)[3]));}}

/* k4383 in k4380 in ks in k4357 in a4354 in k4344 in k4319 in k4294 in k4232 in k4219 in k4176 in k4134 in k4113 in k4097 in k4084 in next in k3971 in gen in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_fcall f_4385(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4385,NULL,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,lf[0],t1,((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4396,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* match.scm: 1660 kf */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[3]);}

/* k4394 in k4383 in k4380 in ks in k4357 in a4354 in k4344 in k4319 in k4294 in k4232 in k4219 in k4176 in k4134 in k4113 in k4097 in k4084 in next in k3971 in gen in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_4396(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4396,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4400,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* match.scm: 1661 ks */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k4398 in k4394 in k4383 in k4380 in ks in k4357 in a4354 in k4344 in k4319 in k4294 in k4232 in k4219 in k4176 in k4134 in k4113 in k4097 in k4084 in next in k3971 in gen in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_4400(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* match.scm: 1657 assm */
t2=((C_word*)((C_word*)t0)[5])[1];
f_5303(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4338 in k4319 in k4294 in k4232 in k4219 in k4176 in k4134 in k4113 in k4097 in k4084 in next in k3971 in gen in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_4340(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4340,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[5])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[5])+1,t3);
/* match.scm: 1620 ks */
t5=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t5))(3,t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4313 in k4294 in k4232 in k4219 in k4176 in k4134 in k4113 in k4097 in k4084 in next in k3971 in gen in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_4315(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4315,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[5])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[5])+1,t3);
/* match.scm: 1613 ks */
t5=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t5))(3,t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4288 in k4232 in k4219 in k4176 in k4134 in k4113 in k4097 in k4084 in next in k3971 in gen in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_4290(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4290,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[10]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4253,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t2,a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4255,a[2]=t5,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=((C_word)li30),tmp=(C_word)a,a+=10,tmp));
t7=((C_word*)t5)[1];
f_4255(t7,t3,C_fix(1));}

/* rloop in k4288 in k4232 in k4219 in k4176 in k4134 in k4113 in k4097 in k4084 in next in k3971 in gen in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_fcall f_4255(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4255,NULL,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4257,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t2,a[10]=((C_word)li29),tmp=(C_word)a,a+=11,tmp));}

/* f_4257 in rloop in k4288 in k4232 in k4219 in k4176 in k4134 in k4113 in k4097 in k4084 in next in k3971 in gen in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_4257(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[21],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4257,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nequalp(((C_word*)t0)[9],((C_word*)t0)[8]))){
/* match.scm: 1597 ks */
t3=((C_word*)t0)[7];
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,t2);}
else{
t3=(C_word)C_i_list_ref(((C_word*)t0)[6],((C_word*)t0)[9]);
t4=(C_word)C_a_i_list(&a,3,lf[24],((C_word*)t0)[5],((C_word*)t0)[9]);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4282,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t4,a[5]=t3,a[6]=t1,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
t6=(C_word)C_a_i_plus(&a,2,C_fix(1),((C_word*)t0)[9]);
/* match.scm: 1604 rloop */
t7=((C_word*)((C_word*)t0)[2])[1];
f_4255(t7,t5,t6);}}

/* k4280 */
static void C_ccall f_4282(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* match.scm: 1598 next */
t2=((C_word*)((C_word*)t0)[7])[1];
f_3975(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4251 in k4288 in k4232 in k4219 in k4176 in k4134 in k4113 in k4097 in k4084 in next in k3971 in gen in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_4253(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* match.scm: 1590 emit */
t2=((C_word*)t0)[6];
f_5121(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* loop in k4176 in k4134 in k4113 in k4097 in k4084 in next in k3971 in gen in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_fcall f_4187(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4187,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
/* match.scm: 1567 kf */
t4=((C_word*)t0)[8];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}
else{
t4=C_mutate(((C_word *)((C_word*)t0)[7])+1,((C_word*)t0)[6]);
t5=(C_word)C_i_car(t2);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4207,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word)li27),tmp=(C_word)a,a+=5,tmp);
/* match.scm: 1570 next */
t7=((C_word*)((C_word*)t0)[4])[1];
f_3975(t7,t1,t5,((C_word*)t0)[3],t3,t6,((C_word*)t0)[2]);}}

/* a4206 in loop in k4176 in k4134 in k4113 in k4097 in k4084 in next in k3971 in gen in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_4207(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4207,3,t0,t1,t2);}
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* match.scm: 1574 loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_4187(t4,t1,t3,t2);}

/* loop in k4134 in k4113 in k4097 in k4084 in next in k3971 in gen in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_fcall f_4145(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4145,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
/* match.scm: 1554 ks */
t4=((C_word*)t0)[6];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}
else{
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4164,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word)li25),tmp=(C_word)a,a+=5,tmp);
/* match.scm: 1555 next */
t6=((C_word*)((C_word*)t0)[4])[1];
f_3975(t6,t1,t4,((C_word*)t0)[3],t3,((C_word*)t0)[2],t5);}}

/* a4163 in loop in k4134 in k4113 in k4097 in k4084 in next in k3971 in gen in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_4164(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4164,3,t0,t1,t2);}
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* match.scm: 1560 loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_4145(t4,t1,t3,t2);}

/* success in gen in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_3877(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[11],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3877,3,t0,t1,t2);}
t3=(C_word)C_i_car(((C_word*)t0)[4]);
t4=(C_word)C_i_cddddr(t3);
t5=(C_word)C_i_set_car(t4,C_SCHEME_TRUE);
t6=(C_word)C_i_car(((C_word*)t0)[4]);
t7=(C_word)C_i_cadr(t6);
t8=(C_word)C_i_car(((C_word*)t0)[4]);
t9=(C_word)C_i_caddr(t8);
t10=(C_word)C_i_car(((C_word*)t0)[4]);
t11=(C_word)C_i_cadddr(t10);
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3939,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t7,a[6]=t11,tmp=(C_word)a,a+=7,tmp);
/* map */
t13=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t13+1)))(4,t13,t12,((C_word*)t0)[2],t9);}
else{
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3946,a[2]=t7,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* map */
t13=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t13+1)))(4,t13,t12,((C_word*)t0)[2],t9);}}

/* k3944 in success in gen in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_3946(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3946,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k3937 in success in gen in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_3939(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3939,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t2);
t4=(C_word)C_a_i_list(&a,1,((C_word*)t0)[6]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3931,a[2]=((C_word*)t0)[4],a[3]=t4,a[4]=t3,a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* match.scm: 1513 fail */
t6=((C_word*)t0)[3];
f_3868(3,t6,t5,((C_word*)t0)[2]);}

/* k3929 in k3937 in success in gen in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_3931(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[48],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3931,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_list(&a,3,lf[19],C_SCHEME_END_OF_LIST,t2);
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[5],t3);
t5=(C_word)C_a_i_list(&a,1,t4);
t6=(C_word)C_a_i_list(&a,3,lf[20],t5,((C_word*)t0)[4]);
t7=(C_word)C_a_i_list(&a,3,lf[19],((C_word*)t0)[3],t6);
t8=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_list(&a,2,lf[51],t7));}

/* fail in gen in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_3868(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3868,3,t0,t1,t2);}
t3=(C_word)C_i_cdr(((C_word*)t0)[7]);
/* match.scm: 1493 gen */
t4=((C_word*)((C_word*)t0)[6])[1];
f_3848(t4,t1,((C_word*)t0)[5],t2,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* val in gen in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_3859(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3859,3,t0,t1,t2);}
t3=(C_word)C_i_assq(t2,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_cdr(t3));}

/* dot-dot-k? in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_fcall f_1327(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1327,NULL,2,t1,t2);}
if(C_truep((C_word)C_i_symbolp(t2))){
t3=t2;
if(C_truep((C_truep((C_word)C_eqp(t3,lf[67]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,lf[68]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_fix(0));}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1343,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* match.scm: 827  symbol->string */
t5=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k1341 in dot-dot-k? in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_1343(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1343,2,t0,t1);}
t2=(C_word)C_i_string_length(t1);
if(C_truep((C_word)C_i_less_or_equalp(C_fix(3),t2))){
t3=(C_word)C_i_string_ref(t1,C_fix(0));
if(C_truep((C_truep((C_word)C_eqp(t3,C_make_character(46)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(95)))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
t4=(C_word)C_i_string_ref(t1,C_fix(1));
if(C_truep((C_truep((C_word)C_eqp(t4,C_make_character(46)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t4,C_make_character(95)))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1370,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1381,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1385,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* match.scm: 835  substring */
t8=*((C_word*)lf[69]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t7,t1,C_fix(2),t2);}
else{
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}
else{
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k1383 in k1341 in dot-dot-k? in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_1385(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* string->list */
t2=*((C_word*)lf[71]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1379 in k1341 in dot-dot-k? in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_1381(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* match.scm: 832  ##match#every */
t2=*((C_word*)lf[0]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],*((C_word*)lf[70]+1),t1);}

/* k1368 in k1341 in dot-dot-k? in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_1370(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1370,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1377,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* match.scm: 837  substring */
t3=*((C_word*)lf[69]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[3],C_fix(2),((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k1375 in k1368 in k1341 in dot-dot-k? in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_1377(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* match.scm: 836  string->number */
C_string_to_number(3,0,((C_word*)t0)[2],t1);}

/* emit in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_fcall f_5121(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5121,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5128,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t4,a[6]=t3,a[7]=t1,a[8]=t5,tmp=(C_word)a,a+=9,tmp);
/* match.scm: 1865 in */
t7=((C_word*)t0)[2];
f_6328(t7,t6,t2,t3);}

/* k5126 in emit in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_5128(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5128,2,t0,t1);}
if(C_truep(t1)){
/* match.scm: 1865 ks */
t2=((C_word*)t0)[8];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[7],((C_word*)t0)[6]);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5137,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_a_i_list(&a,2,lf[43],((C_word*)t0)[4]);
/* match.scm: 1866 in */
t4=((C_word*)t0)[2];
f_6328(t4,t2,t3,((C_word*)t0)[6]);}}

/* k5135 in k5126 in emit in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_5137(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[58],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5137,2,t0,t1);}
if(C_truep(t1)){
/* match.scm: 1866 kf */
t2=((C_word*)t0)[7];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[6],((C_word*)t0)[5]);}
else{
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5146,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[4],tmp=(C_word)a,a+=9,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[4]);
t5=(C_word)C_eqp(t4,lf[36]);
if(C_truep(t5)){
t6=(C_word)C_i_caddr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_stringp(t6))){
t7=(C_word)C_a_i_list(&a,2,lf[37],t2);
t8=t3;
f_5146(t8,(C_word)C_a_i_list(&a,1,t7));}
else{
if(C_truep((C_word)C_booleanp(t6))){
t7=(C_word)C_a_i_list(&a,2,lf[38],t2);
t8=t3;
f_5146(t8,(C_word)C_a_i_list(&a,1,t7));}
else{
if(C_truep((C_word)C_charp(t6))){
t7=(C_word)C_a_i_list(&a,2,lf[39],t2);
t8=t3;
f_5146(t8,(C_word)C_a_i_list(&a,1,t7));}
else{
if(C_truep((C_word)C_i_numberp(t6))){
t7=(C_word)C_a_i_list(&a,2,lf[40],t2);
t8=t3;
f_5146(t8,(C_word)C_a_i_list(&a,1,t7));}
else{
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5259,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(t6))){
t8=(C_word)C_i_car(t6);
t9=t7;
f_5259(t9,(C_word)C_eqp(lf[42],t8));}
else{
t8=t7;
f_5259(t8,C_SCHEME_FALSE);}}}}}}
else{
t6=(C_word)C_i_car(((C_word*)t0)[4]);
t7=(C_word)C_eqp(t6,lf[46]);
if(C_truep(t7)){
t8=(C_word)C_a_i_list(&a,2,lf[44],t2);
t9=t3;
f_5146(t9,(C_word)C_a_i_list(&a,1,t8));}
else{
t8=t3;
f_5146(t8,C_SCHEME_END_OF_LIST);}}}}

/* k5257 in k5135 in k5126 in emit in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_fcall f_5259(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5259,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_list(&a,2,lf[41],((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
f_5146(t3,(C_word)C_a_i_list(&a,1,t2));}
else{
t2=((C_word*)t0)[2];
f_5146(t2,C_SCHEME_END_OF_LIST);}}

/* k5144 in k5135 in k5126 in emit in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_fcall f_5146(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5146,NULL,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[8]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5152,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t4=(C_word)C_eqp(t2,lf[44]);
if(C_truep(t4)){
t5=(C_word)C_a_i_list(&a,2,lf[46],((C_word*)t0)[2]);
t6=(C_word)C_a_i_list(&a,2,lf[43],t5);
t7=t3;
f_5152(t7,(C_word)C_a_i_list(&a,1,t6));}
else{
t5=t3;
f_5152(t5,C_SCHEME_END_OF_LIST);}}

/* k5150 in k5144 in k5135 in k5126 in emit in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_fcall f_5152(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5152,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5155,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5181,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* match.scm: 1896 append */
t4=*((C_word*)lf[66]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[2],((C_word*)t0)[4]);}

/* k5179 in k5150 in k5144 in k5135 in k5126 in emit in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_5181(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5181,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
/* match.scm: 1896 ks */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],t2);}

/* k5153 in k5150 in k5144 in k5135 in k5126 in emit in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_5155(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5155,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5158,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_a_i_list(&a,2,lf[43],((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5173,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* match.scm: 1898 append */
t5=*((C_word*)lf[66]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5171 in k5153 in k5150 in k5144 in k5135 in k5126 in emit in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_5173(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5173,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
/* match.scm: 1897 kf */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],t2);}

/* k5156 in k5153 in k5150 in k5144 in k5135 in k5126 in emit in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_5158(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* match.scm: 1899 assm */
t2=((C_word*)((C_word*)t0)[5])[1];
f_5303(t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* assm in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_fcall f_5303(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5303,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_equalp(t4,t3))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(C_word)C_eqp(t4,C_SCHEME_TRUE);
t6=(C_truep(t5)?(C_word)C_eqp(t3,C_SCHEME_FALSE):C_SCHEME_FALSE);
if(C_truep(t6)){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t2);}
else{
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5322,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t2,a[5]=t4,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t8=(C_word)C_i_car(t2);
t9=(C_word)C_eqp(t8,lf[47]);
if(C_truep(t9)){
t10=*((C_word*)lf[6]+1);
if(C_truep((C_truep((C_word)C_eqp(t10,lf[64]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t10,lf[65]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
t11=(C_word)C_i_car(t3);
if(C_truep((C_truep((C_word)C_eqp(t11,lf[48]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t11,lf[5]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
t12=(C_word)C_i_cadr(t2);
/* match.scm: 1907 guarantees */
t13=((C_word*)t0)[2];
f_6197(t13,t7,t4,t12);}
else{
t12=t7;
f_5322(2,t12,C_SCHEME_FALSE);}}
else{
t11=t7;
f_5322(2,t11,C_SCHEME_FALSE);}}
else{
t10=t7;
f_5322(2,t10,C_SCHEME_FALSE);}}}}

/* k5320 in assm in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_5322(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5322,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[5]);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5328,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[5]))){
t3=(C_word)C_i_car(((C_word*)t0)[5]);
t4=(C_word)C_eqp(t3,lf[49]);
if(C_truep(t4)){
t5=(C_word)C_i_cadddr(((C_word*)t0)[5]);
t6=t2;
f_5328(t6,(C_word)C_i_equalp(t5,((C_word*)t0)[3]));}
else{
t5=t2;
f_5328(t5,C_SCHEME_FALSE);}}
else{
t3=t2;
f_5328(t3,C_SCHEME_FALSE);}}}

/* k5326 in k5320 in assm in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_fcall f_5328(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[51],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5328,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[6]);
t3=(C_word)C_i_car(t2);
t4=(C_word)C_eqp(t3,lf[50]);
if(C_truep(t4)){
t5=(C_word)C_i_cadr(((C_word*)t0)[6]);
t6=(C_word)C_i_cdr(t5);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t6);
t8=(C_word)C_a_i_cons(&a,2,lf[50],t7);
t9=(C_word)C_i_caddr(((C_word*)t0)[6]);
t10=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_list(&a,4,lf[49],t8,t9,((C_word*)t0)[3]));}
else{
t5=(C_word)C_i_cadr(((C_word*)t0)[6]);
t6=(C_word)C_a_i_list(&a,3,lf[50],((C_word*)t0)[5],t5);
t7=(C_word)C_i_caddr(((C_word*)t0)[6]);
t8=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_list(&a,4,lf[49],t6,t7,((C_word*)t0)[3]));}}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5386,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[6]))){
t3=(C_word)C_i_car(((C_word*)t0)[6]);
t4=(C_word)C_eqp(t3,lf[51]);
if(C_truep(t4)){
t5=(C_word)C_i_cdr(((C_word*)t0)[6]);
if(C_truep((C_word)C_i_pairp(t5))){
t6=(C_word)C_i_cadr(((C_word*)t0)[6]);
if(C_truep((C_word)C_i_pairp(t6))){
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6127,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* match.scm: 1924 caadr */
t8=*((C_word*)lf[62]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,((C_word*)t0)[6]);}
else{
t7=t2;
f_5386(t7,C_SCHEME_FALSE);}}
else{
t6=t2;
f_5386(t6,C_SCHEME_FALSE);}}
else{
t5=t2;
f_5386(t5,C_SCHEME_FALSE);}}
else{
t3=t2;
f_5386(t3,C_SCHEME_FALSE);}}}

/* k6125 in k5326 in k5320 in assm in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_6127(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6127,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[19]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6123,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* match.scm: 1925 cdadr */
t4=*((C_word*)lf[61]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[4]);}
else{
t3=((C_word*)t0)[3];
f_5386(t3,C_SCHEME_FALSE);}}

/* k6121 in k6125 in k5326 in k5320 in assm in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_6123(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6123,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6119,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* match.scm: 1926 cadadr */
t3=*((C_word*)lf[55]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[4]);}
else{
t2=((C_word*)t0)[3];
f_5386(t2,C_SCHEME_FALSE);}}

/* k6117 in k6121 in k6125 in k5326 in k5320 in assm in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_6119(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6119,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6115,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* match.scm: 1927 cadadr */
t3=*((C_word*)lf[55]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[4]);}
else{
t2=((C_word*)t0)[3];
f_5386(t2,C_SCHEME_FALSE);}}

/* k6113 in k6117 in k6121 in k6125 in k5326 in k5320 in assm in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_6115(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6115,2,t0,t1);}
t2=(C_word)C_i_cdr(t1);
if(C_truep((C_word)C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6107,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* match.scm: 1928 cddadr */
t4=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[4]);}
else{
t3=((C_word*)t0)[3];
f_5386(t3,C_SCHEME_FALSE);}}

/* k6105 in k6113 in k6117 in k6121 in k6125 in k5326 in k5320 in assm in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_6107(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6107,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6103,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* match.scm: 1929 cddadr */
t3=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[4]);}
else{
t2=((C_word*)t0)[3];
f_5386(t2,C_SCHEME_FALSE);}}

/* k6101 in k6105 in k6113 in k6117 in k6121 in k6125 in k5326 in k5320 in assm in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_6103(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6103,2,t0,t1);}
t2=(C_word)C_i_car(t1);
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6091,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6095,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* match.scm: 1930 cddadr */
t5=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[4]);}
else{
t3=((C_word*)t0)[3];
f_5386(t3,C_SCHEME_FALSE);}}

/* k6093 in k6101 in k6105 in k6113 in k6117 in k6121 in k6125 in k5326 in k5320 in assm in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_6095(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* match.scm: 1930 caar */
t2=*((C_word*)lf[63]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k6089 in k6101 in k6105 in k6113 in k6117 in k6121 in k6125 in k5326 in k5320 in assm in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_6091(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6091,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[20]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6083,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6087,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* match.scm: 1931 cddadr */
t5=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[4]);}
else{
t3=((C_word*)t0)[3];
f_5386(t3,C_SCHEME_FALSE);}}

/* k6085 in k6089 in k6101 in k6105 in k6113 in k6117 in k6121 in k6125 in k5326 in k5320 in assm in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_6087(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* match.scm: 1931 cdar */
t2=*((C_word*)lf[60]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k6081 in k6089 in k6101 in k6105 in k6113 in k6117 in k6121 in k6125 in k5326 in k5320 in assm in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_6083(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6083,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6075,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6079,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* match.scm: 1932 cddadr */
t4=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[4]);}
else{
t2=((C_word*)t0)[3];
f_5386(t2,C_SCHEME_FALSE);}}

/* k6077 in k6081 in k6089 in k6101 in k6105 in k6113 in k6117 in k6121 in k6125 in k5326 in k5320 in assm in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_6079(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* match.scm: 1932 cadar */
t2=*((C_word*)lf[56]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k6073 in k6081 in k6089 in k6101 in k6105 in k6113 in k6117 in k6121 in k6125 in k5326 in k5320 in assm in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_6075(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6075,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6067,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6071,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* match.scm: 1933 cddadr */
t4=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[4]);}
else{
t2=((C_word*)t0)[3];
f_5386(t2,C_SCHEME_FALSE);}}

/* k6069 in k6073 in k6081 in k6089 in k6101 in k6105 in k6113 in k6117 in k6121 in k6125 in k5326 in k5320 in assm in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_6071(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* match.scm: 1933 caadar */
t2=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k6065 in k6073 in k6081 in k6089 in k6101 in k6105 in k6113 in k6117 in k6121 in k6125 in k5326 in k5320 in assm in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_6067(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6067,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6059,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6063,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* match.scm: 1934 cddadr */
t4=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[4]);}
else{
t2=((C_word*)t0)[3];
f_5386(t2,C_SCHEME_FALSE);}}

/* k6061 in k6065 in k6073 in k6081 in k6089 in k6101 in k6105 in k6113 in k6117 in k6121 in k6125 in k5326 in k5320 in assm in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_6063(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* match.scm: 1934 caadar */
t2=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k6057 in k6065 in k6073 in k6081 in k6089 in k6101 in k6105 in k6113 in k6117 in k6121 in k6125 in k5326 in k5320 in assm in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_6059(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6059,2,t0,t1);}
t2=(C_word)C_i_cdr(t1);
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6047,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6051,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* match.scm: 1935 cddadr */
t5=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[4]);}
else{
t3=((C_word*)t0)[3];
f_5386(t3,C_SCHEME_FALSE);}}

/* k6049 in k6057 in k6065 in k6073 in k6081 in k6089 in k6101 in k6105 in k6113 in k6117 in k6121 in k6125 in k5326 in k5320 in assm in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_6051(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* match.scm: 1935 caadar */
t2=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k6045 in k6057 in k6065 in k6073 in k6081 in k6089 in k6101 in k6105 in k6113 in k6117 in k6121 in k6125 in k5326 in k5320 in assm in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_6047(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6047,2,t0,t1);}
t2=(C_word)C_i_cadr(t1);
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6031,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6035,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6039,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* match.scm: 1936 cddadr */
t6=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[4]);}
else{
t3=((C_word*)t0)[3];
f_5386(t3,C_SCHEME_FALSE);}}

/* k6037 in k6045 in k6057 in k6065 in k6073 in k6081 in k6089 in k6101 in k6105 in k6113 in k6117 in k6121 in k6125 in k5326 in k5320 in assm in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_6039(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* match.scm: 1936 caadar */
t2=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k6033 in k6045 in k6057 in k6065 in k6073 in k6081 in k6089 in k6101 in k6105 in k6113 in k6117 in k6121 in k6125 in k5326 in k5320 in assm in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_6035(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* match.scm: 1936 caadr */
t2=*((C_word*)lf[62]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k6029 in k6045 in k6057 in k6065 in k6073 in k6081 in k6089 in k6101 in k6105 in k6113 in k6117 in k6121 in k6125 in k5326 in k5320 in assm in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_6031(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6031,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[19]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6019,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6023,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6027,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* match.scm: 1937 cddadr */
t6=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[4]);}
else{
t3=((C_word*)t0)[3];
f_5386(t3,C_SCHEME_FALSE);}}

/* k6025 in k6029 in k6045 in k6057 in k6065 in k6073 in k6081 in k6089 in k6101 in k6105 in k6113 in k6117 in k6121 in k6125 in k5326 in k5320 in assm in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_6027(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* match.scm: 1937 caadar */
t2=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k6021 in k6029 in k6045 in k6057 in k6065 in k6073 in k6081 in k6089 in k6101 in k6105 in k6113 in k6117 in k6121 in k6125 in k5326 in k5320 in assm in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_6023(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* match.scm: 1937 cdadr */
t2=*((C_word*)lf[61]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k6017 in k6029 in k6045 in k6057 in k6065 in k6073 in k6081 in k6089 in k6101 in k6105 in k6113 in k6117 in k6121 in k6125 in k5326 in k5320 in assm in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_6019(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6019,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6007,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6011,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6015,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* match.scm: 1938 cddadr */
t5=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[4]);}
else{
t2=((C_word*)t0)[3];
f_5386(t2,C_SCHEME_FALSE);}}

/* k6013 in k6017 in k6029 in k6045 in k6057 in k6065 in k6073 in k6081 in k6089 in k6101 in k6105 in k6113 in k6117 in k6121 in k6125 in k5326 in k5320 in assm in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_6015(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* match.scm: 1938 caadar */
t2=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k6009 in k6017 in k6029 in k6045 in k6057 in k6065 in k6073 in k6081 in k6089 in k6101 in k6105 in k6113 in k6117 in k6121 in k6125 in k5326 in k5320 in assm in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_6011(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* match.scm: 1938 cadadr */
t2=*((C_word*)lf[55]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k6005 in k6017 in k6029 in k6045 in k6057 in k6065 in k6073 in k6081 in k6089 in k6101 in k6105 in k6113 in k6117 in k6121 in k6125 in k5326 in k5320 in assm in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_6007(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6007,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5995,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5999,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6003,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* match.scm: 1939 cddadr */
t5=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[4]);}
else{
t2=((C_word*)t0)[3];
f_5386(t2,C_SCHEME_FALSE);}}

/* k6001 in k6005 in k6017 in k6029 in k6045 in k6057 in k6065 in k6073 in k6081 in k6089 in k6101 in k6105 in k6113 in k6117 in k6121 in k6125 in k5326 in k5320 in assm in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_6003(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* match.scm: 1939 caadar */
t2=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5997 in k6005 in k6017 in k6029 in k6045 in k6057 in k6065 in k6073 in k6081 in k6089 in k6101 in k6105 in k6113 in k6117 in k6121 in k6125 in k5326 in k5320 in assm in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_5999(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* match.scm: 1939 cddadr */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5993 in k6005 in k6017 in k6029 in k6045 in k6057 in k6065 in k6073 in k6081 in k6089 in k6101 in k6105 in k6113 in k6117 in k6121 in k6125 in k5326 in k5320 in assm in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_5995(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5995,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5983,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5987,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5991,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* match.scm: 1940 cddadr */
t5=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[4]);}
else{
t2=((C_word*)t0)[3];
f_5386(t2,C_SCHEME_FALSE);}}

/* k5989 in k5993 in k6005 in k6017 in k6029 in k6045 in k6057 in k6065 in k6073 in k6081 in k6089 in k6101 in k6105 in k6113 in k6117 in k6121 in k6125 in k5326 in k5320 in assm in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_5991(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* match.scm: 1940 caadar */
t2=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5985 in k5993 in k6005 in k6017 in k6029 in k6045 in k6057 in k6065 in k6073 in k6081 in k6089 in k6101 in k6105 in k6113 in k6117 in k6121 in k6125 in k5326 in k5320 in assm in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_5987(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* match.scm: 1940 cddadr */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5981 in k5993 in k6005 in k6017 in k6029 in k6045 in k6057 in k6065 in k6073 in k6081 in k6089 in k6101 in k6105 in k6113 in k6117 in k6121 in k6125 in k5326 in k5320 in assm in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_5983(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5983,2,t0,t1);}
t2=(C_word)C_i_car(t1);
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5963,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5967,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5971,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5975,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* match.scm: 1941 cddadr */
t7=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,((C_word*)t0)[4]);}
else{
t3=((C_word*)t0)[3];
f_5386(t3,C_SCHEME_FALSE);}}

/* k5973 in k5981 in k5993 in k6005 in k6017 in k6029 in k6045 in k6057 in k6065 in k6073 in k6081 in k6089 in k6101 in k6105 in k6113 in k6117 in k6121 in k6125 in k5326 in k5320 in assm in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_5975(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* match.scm: 1941 caadar */
t2=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5969 in k5981 in k5993 in k6005 in k6017 in k6029 in k6045 in k6057 in k6065 in k6073 in k6081 in k6089 in k6101 in k6105 in k6113 in k6117 in k6121 in k6125 in k5326 in k5320 in assm in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_5971(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* match.scm: 1941 cddadr */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5965 in k5981 in k5993 in k6005 in k6017 in k6029 in k6045 in k6057 in k6065 in k6073 in k6081 in k6089 in k6101 in k6105 in k6113 in k6117 in k6121 in k6125 in k5326 in k5320 in assm in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_5967(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* match.scm: 1941 cdar */
t2=*((C_word*)lf[60]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5961 in k5981 in k5993 in k6005 in k6017 in k6029 in k6045 in k6057 in k6065 in k6073 in k6081 in k6089 in k6101 in k6105 in k6113 in k6117 in k6121 in k6125 in k5326 in k5320 in assm in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_5963(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5963,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5947,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5951,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5955,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5959,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* match.scm: 1942 cddadr */
t6=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[4]);}
else{
t2=((C_word*)t0)[3];
f_5386(t2,C_SCHEME_FALSE);}}

/* k5957 in k5961 in k5981 in k5993 in k6005 in k6017 in k6029 in k6045 in k6057 in k6065 in k6073 in k6081 in k6089 in k6101 in k6105 in k6113 in k6117 in k6121 in k6125 in k5326 in k5320 in assm in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_5959(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* match.scm: 1942 caadar */
t2=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5953 in k5961 in k5981 in k5993 in k6005 in k6017 in k6029 in k6045 in k6057 in k6065 in k6073 in k6081 in k6089 in k6101 in k6105 in k6113 in k6117 in k6121 in k6125 in k5326 in k5320 in assm in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_5955(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* match.scm: 1942 cddadr */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5949 in k5961 in k5981 in k5993 in k6005 in k6017 in k6029 in k6045 in k6057 in k6065 in k6073 in k6081 in k6089 in k6101 in k6105 in k6113 in k6117 in k6121 in k6125 in k5326 in k5320 in assm in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_5951(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* match.scm: 1942 cddar */
t2=*((C_word*)lf[58]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5945 in k5961 in k5981 in k5993 in k6005 in k6017 in k6029 in k6045 in k6057 in k6065 in k6073 in k6081 in k6089 in k6101 in k6105 in k6113 in k6117 in k6121 in k6125 in k5326 in k5320 in assm in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_5947(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5947,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5935,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5939,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5943,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* match.scm: 1943 cddadr */
t5=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[4]);}
else{
t2=((C_word*)t0)[3];
f_5386(t2,C_SCHEME_FALSE);}}

/* k5941 in k5945 in k5961 in k5981 in k5993 in k6005 in k6017 in k6029 in k6045 in k6057 in k6065 in k6073 in k6081 in k6089 in k6101 in k6105 in k6113 in k6117 in k6121 in k6125 in k5326 in k5320 in assm in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_5943(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* match.scm: 1943 caadar */
t2=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5937 in k5945 in k5961 in k5981 in k5993 in k6005 in k6017 in k6029 in k6045 in k6057 in k6065 in k6073 in k6081 in k6089 in k6101 in k6105 in k6113 in k6117 in k6121 in k6125 in k5326 in k5320 in assm in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_5939(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* match.scm: 1943 cddadr */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5933 in k5945 in k5961 in k5981 in k5993 in k6005 in k6017 in k6029 in k6045 in k6057 in k6065 in k6073 in k6081 in k6089 in k6101 in k6105 in k6113 in k6117 in k6121 in k6125 in k5326 in k5320 in assm in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_5935(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5935,2,t0,t1);}
t2=(C_word)C_i_cdr(t1);
if(C_truep((C_word)C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5923,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5927,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* match.scm: 1944 cddadr */
t5=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[4]);}
else{
t3=((C_word*)t0)[3];
f_5386(t3,C_SCHEME_FALSE);}}

/* k5925 in k5933 in k5945 in k5961 in k5981 in k5993 in k6005 in k6017 in k6029 in k6045 in k6057 in k6065 in k6073 in k6081 in k6089 in k6101 in k6105 in k6113 in k6117 in k6121 in k6125 in k5326 in k5320 in assm in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_5927(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* match.scm: 1944 caadar */
t2=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5921 in k5933 in k5945 in k5961 in k5981 in k5993 in k6005 in k6017 in k6029 in k6045 in k6057 in k6065 in k6073 in k6081 in k6089 in k6101 in k6105 in k6113 in k6117 in k6121 in k6125 in k5326 in k5320 in assm in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_5923(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5923,2,t0,t1);}
t2=(C_word)C_i_cddr(t1);
if(C_truep((C_word)C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5911,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5915,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* match.scm: 1945 cddadr */
t5=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[4]);}
else{
t3=((C_word*)t0)[3];
f_5386(t3,C_SCHEME_FALSE);}}

/* k5913 in k5921 in k5933 in k5945 in k5961 in k5981 in k5993 in k6005 in k6017 in k6029 in k6045 in k6057 in k6065 in k6073 in k6081 in k6089 in k6101 in k6105 in k6113 in k6117 in k6121 in k6125 in k5326 in k5320 in assm in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_5915(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* match.scm: 1945 cdadar */
t2=*((C_word*)lf[59]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5909 in k5921 in k5933 in k5945 in k5961 in k5981 in k5993 in k6005 in k6017 in k6029 in k6045 in k6057 in k6065 in k6073 in k6081 in k6089 in k6101 in k6105 in k6113 in k6117 in k6121 in k6125 in k5326 in k5320 in assm in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_5911(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5911,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5903,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5907,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* match.scm: 1946 cddadr */
t4=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[4]);}
else{
t2=((C_word*)t0)[3];
f_5386(t2,C_SCHEME_FALSE);}}

/* k5905 in k5909 in k5921 in k5933 in k5945 in k5961 in k5981 in k5993 in k6005 in k6017 in k6029 in k6045 in k6057 in k6065 in k6073 in k6081 in k6089 in k6101 in k6105 in k6113 in k6117 in k6121 in k6125 in k5326 in k5320 in assm in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_5907(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* match.scm: 1946 cddar */
t2=*((C_word*)lf[58]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5901 in k5909 in k5921 in k5933 in k5945 in k5961 in k5981 in k5993 in k6005 in k6017 in k6029 in k6045 in k6057 in k6065 in k6073 in k6081 in k6089 in k6101 in k6105 in k6113 in k6117 in k6121 in k6125 in k5326 in k5320 in assm in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_5903(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5903,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5895,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5899,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* match.scm: 1947 cddadr */
t4=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[4]);}
else{
t2=((C_word*)t0)[3];
f_5386(t2,C_SCHEME_FALSE);}}

/* k5897 in k5901 in k5909 in k5921 in k5933 in k5945 in k5961 in k5981 in k5993 in k6005 in k6017 in k6029 in k6045 in k6057 in k6065 in k6073 in k6081 in k6089 in k6101 in k6105 in k6113 in k6117 in k6121 in k6125 in k5326 in k5320 in assm in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_5899(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* match.scm: 1947 cdddar */
t2=*((C_word*)lf[57]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5893 in k5901 in k5909 in k5921 in k5933 in k5945 in k5961 in k5981 in k5993 in k6005 in k6017 in k6029 in k6045 in k6057 in k6065 in k6073 in k6081 in k6089 in k6101 in k6105 in k6113 in k6117 in k6121 in k6125 in k5326 in k5320 in assm in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_5895(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5895,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5891,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* match.scm: 1948 cddadr */
t3=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[4]);}
else{
t2=((C_word*)t0)[3];
f_5386(t2,C_SCHEME_FALSE);}}

/* k5889 in k5893 in k5901 in k5909 in k5921 in k5933 in k5945 in k5961 in k5981 in k5993 in k6005 in k6017 in k6029 in k6045 in k6057 in k6065 in k6073 in k6081 in k6089 in k6101 in k6105 in k6113 in k6117 in k6121 in k6125 in k5326 in k5320 in assm in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_5891(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5891,2,t0,t1);}
t2=(C_word)C_i_cdr(t1);
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_i_cddr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_nullp(t3))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5867,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5871,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5875,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5879,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* match.scm: 1950 cddadr */
t8=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,((C_word*)t0)[4]);}
else{
t4=((C_word*)t0)[3];
f_5386(t4,C_SCHEME_FALSE);}}
else{
t3=((C_word*)t0)[3];
f_5386(t3,C_SCHEME_FALSE);}}

/* k5877 in k5889 in k5893 in k5901 in k5909 in k5921 in k5933 in k5945 in k5961 in k5981 in k5993 in k6005 in k6017 in k6029 in k6045 in k6057 in k6065 in k6073 in k6081 in k6089 in k6101 in k6105 in k6113 in k6117 in k6121 in k6125 in k5326 in k5320 in assm in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_5879(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* match.scm: 1950 caadar */
t2=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5873 in k5889 in k5893 in k5901 in k5909 in k5921 in k5933 in k5945 in k5961 in k5981 in k5993 in k6005 in k6017 in k6029 in k6045 in k6057 in k6065 in k6073 in k6081 in k6089 in k6101 in k6105 in k6113 in k6117 in k6121 in k6125 in k5326 in k5320 in assm in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_5875(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* match.scm: 1950 cddadr */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5869 in k5889 in k5893 in k5901 in k5909 in k5921 in k5933 in k5945 in k5961 in k5981 in k5993 in k6005 in k6017 in k6029 in k6045 in k6057 in k6065 in k6073 in k6081 in k6089 in k6101 in k6105 in k6113 in k6117 in k6121 in k6125 in k5326 in k5320 in assm in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_5871(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* match.scm: 1950 cadar */
t2=*((C_word*)lf[56]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5865 in k5889 in k5893 in k5901 in k5909 in k5921 in k5933 in k5945 in k5961 in k5981 in k5993 in k6005 in k6017 in k6029 in k6045 in k6057 in k6065 in k6073 in k6081 in k6089 in k6101 in k6105 in k6113 in k6117 in k6121 in k6125 in k5326 in k5320 in assm in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_5867(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_5386(t2,(C_word)C_i_equalp(((C_word*)t0)[2],t1));}

/* k5384 in k5326 in k5320 in assm in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_fcall f_5386(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5386,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5450,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* match.scm: 1950 cadadr */
t3=*((C_word*)lf[55]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,4,lf[49],((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[6]));}}

/* k5448 in k5384 in k5326 in k5320 in assm in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_5450(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5450,2,t0,t1);}
t2=(C_word)C_i_car(t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5442,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5446,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* match.scm: 1953 cddadr */
t5=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[2]);}

/* k5444 in k5448 in k5384 in k5326 in k5320 in assm in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_5446(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* match.scm: 1952 caadar */
t2=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5440 in k5448 in k5384 in k5326 in k5320 in assm in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_5442(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5442,2,t0,t1);}
t2=(C_word)C_i_car(t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5395,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5438,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* match.scm: 1956 cddadr */
t5=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[2]);}

/* k5436 in k5440 in k5448 in k5384 in k5326 in k5320 in assm in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_5438(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* match.scm: 1955 caddar */
t2=*((C_word*)lf[52]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5393 in k5440 in k5448 in k5384 in k5326 in k5320 in assm in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_5395(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5395,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[7]);
t3=(C_word)C_a_i_list(&a,2,((C_word*)t0)[7],((C_word*)t0)[6]);
t4=(C_word)C_a_i_list(&a,3,lf[19],C_SCHEME_END_OF_LIST,t3);
t5=(C_word)C_a_i_list(&a,2,((C_word*)t0)[5],t4);
t6=(C_word)C_a_i_list(&a,1,t5);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5418,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
t8=(C_word)C_a_i_list(&a,1,((C_word*)t0)[5]);
/* match.scm: 1962 assm */
t9=((C_word*)((C_word*)t0)[3])[1];
f_5303(t9,t7,((C_word*)t0)[2],t8,t1);}

/* k5416 in k5393 in k5440 in k5448 in k5384 in k5326 in k5320 in assm in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_5418(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5418,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,lf[20],((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_list(&a,3,lf[19],((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,2,lf[51],t3));}

/* guarantees in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_fcall f_6197(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6197,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6201,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* match.scm: 1993 add-a */
t5=((C_word*)t0)[2];
f_6734(t5,t4,t3);}

/* k6199 in guarantees in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_6201(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6201,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6204,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* match.scm: 1993 add-d */
t3=((C_word*)t0)[3];
f_6767(t3,t2,((C_word*)t0)[2]);}

/* k6202 in k6199 in guarantees in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_6204(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6204,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6209,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word)li17),tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_6209(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop in k6202 in k6199 in guarantees in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_fcall f_6209(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word *a;
loop:
a=C_alloc(10);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_6209,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_i_car(t2);
if(C_truep((C_truep((C_word)C_eqp(t3,lf[48]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,lf[5]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_TRUE);}
else{
t4=(C_word)C_i_equalp(t2,((C_word*)t0)[4]);
t5=(C_truep(t4)?t4:(C_word)C_i_equalp(t2,((C_word*)t0)[3]));
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_TRUE);}
else{
t6=(C_word)C_i_car(t2);
t7=(C_word)C_eqp(t6,lf[49]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6240,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t9=(C_word)C_i_cadr(t2);
/* match.scm: 1999 loop */
t17=t8;
t18=t9;
t1=t17;
t2=t18;
goto loop;}
else{
t8=(C_word)C_i_car(t2);
t9=(C_word)C_eqp(t8,lf[19]);
if(C_truep(t9)){
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}
else{
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6276,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t11=(C_word)C_i_car(t2);
t12=(C_word)C_eqp(t11,lf[20]);
if(C_truep(t12)){
t13=(C_word)C_i_cadr(t2);
t14=t10;
f_6276(t14,(C_word)C_i_symbolp(t13));}
else{
t13=t10;
f_6276(t13,C_SCHEME_FALSE);}}}}}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k6274 in loop in k6202 in k6199 in guarantees in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_fcall f_6276(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6276,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6279,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
/* match.scm: 2007 loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_6209(t4,t2,t3);}}

/* k6277 in k6274 in loop in k6202 in k6199 in guarantees in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_6279(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* match.scm: 2008 loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_6209(t3,((C_word*)t0)[4],t2);}}

/* k6238 in loop in k6202 in k6199 in guarantees in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_6240(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6240,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6249,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_caddr(((C_word*)t0)[3]);
/* match.scm: 2000 loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_6209(t4,t2,t3);}}

/* k6247 in k6238 in loop in k6202 in k6199 in guarantees in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_6249(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadddr(((C_word*)t0)[4]);
/* match.scm: 2002 loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_6209(t3,((C_word*)t0)[2],t2);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* in in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_fcall f_6328(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6328,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_member(t2,t3);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6338,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t6=(C_word)C_i_car(t2);
t7=(C_word)C_eqp(t6,lf[44]);
if(C_truep(t7)){
t8=(C_word)C_i_cadr(t2);
t9=(C_word)C_a_i_list(&a,2,lf[46],t8);
t10=(C_word)C_i_member(t9,t3);
if(C_truep(t10)){
t11=t5;
f_6338(t11,t10);}
else{
t11=(C_word)C_i_cadr(t2);
t12=(C_word)C_a_i_list(&a,2,lf[47],t11);
t13=t5;
f_6338(t13,(C_word)C_i_member(t12,t3));}}
else{
t8=t5;
f_6338(t8,C_SCHEME_FALSE);}}}

/* k6336 in in in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_fcall f_6338(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6338,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_eqp(t2,lf[43]);
if(C_truep(t3)){
t4=(C_word)C_i_cadr(((C_word*)t0)[5]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6353,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t4,tmp=(C_word)a,a+=7,tmp);
/* match.scm: 2016 equal-test? */
f_6638(t5,t4);}
else{
t4=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}}

/* k6351 in k6336 in in in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_6353(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6353,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6361,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word)li13),tmp=(C_word)a,a+=8,tmp));
t5=((C_word*)t3)[1];
f_6361(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=f_6724(((C_word*)t0)[6]);
if(C_truep(t2)){
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6479,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[6],a[4]=t4,a[5]=((C_word)li14),tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_6479(t6,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t3=(C_word)C_i_car(((C_word*)t0)[6]);
t4=(C_word)C_eqp(t3,lf[44]);
if(C_truep(t4)){
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6545,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[6],a[4]=t6,a[5]=((C_word)li15),tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_6545(t8,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}}}

/* mem in k6351 in k6336 in in in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_fcall f_6545(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6545,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6558,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_cadr(t3);
t6=(C_word)C_i_cadr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_equalp(t5,t6))){
t7=f_6724(t3);
if(C_truep(t7)){
t8=(C_word)C_i_car(t3);
t9=(C_word)C_i_memq(t8,lf[45]);
t10=t4;
f_6558(t10,(C_word)C_i_not(t9));}
else{
t8=t4;
f_6558(t8,C_SCHEME_FALSE);}}
else{
t7=t4;
f_6558(t7,C_SCHEME_FALSE);}}}

/* k6556 in mem in k6351 in k6336 in in in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_fcall f_6558(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* match.scm: 2069 mem */
t3=((C_word*)((C_word*)t0)[2])[1];
f_6545(t3,((C_word*)t0)[4],t2);}}

/* mem in k6351 in k6336 in in in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_fcall f_6479(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6479,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6492,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_cadr(t3);
t6=(C_word)C_i_cadr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_equalp(t5,t6))){
t7=f_6724(t3);
if(C_truep(t7)){
t8=(C_word)C_i_car(t3);
t9=(C_word)C_i_car(((C_word*)t0)[3]);
t10=(C_word)C_i_equalp(t8,t9);
t11=t4;
f_6492(t11,(C_word)C_i_not(t10));}
else{
t8=t4;
f_6492(t8,C_SCHEME_FALSE);}}
else{
t7=t4;
f_6492(t7,C_SCHEME_FALSE);}}}

/* k6490 in mem in k6351 in k6336 in in in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_fcall f_6492(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* match.scm: 2055 mem */
t3=((C_word*)((C_word*)t0)[2])[1];
f_6479(t3,((C_word*)t0)[4],t2);}}

/* mem in k6351 in k6336 in in in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_fcall f_6361(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6361,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6374,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=t3,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t5=(C_word)C_i_cadr(t3);
t6=(C_word)C_i_cadr(((C_word*)t0)[6]);
if(C_truep((C_word)C_i_equalp(t5,t6))){
t7=f_6724(t3);
if(C_truep(t7)){
t8=(C_word)C_i_car(t3);
t9=(C_word)C_i_equalp(((C_word*)t0)[5],t8);
t10=t4;
f_6374(t10,(C_word)C_i_not(t9));}
else{
t8=t4;
f_6374(t8,C_SCHEME_FALSE);}}
else{
t7=t4;
f_6374(t7,C_SCHEME_FALSE);}}}

/* k6372 in mem in k6351 in k6336 in in in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_fcall f_6374(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6374,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_i_cadr(((C_word*)t0)[7]);
t3=(C_word)C_a_i_list(&a,2,((C_word*)t0)[6],t2);
t4=(C_word)C_a_i_list(&a,2,lf[43],t3);
t5=(C_word)C_i_equalp(((C_word*)t0)[5],t4);
if(C_truep(t5)){
t6=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6386,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_i_cadr(((C_word*)t0)[5]);
t8=(C_word)C_i_cadr(((C_word*)t0)[7]);
if(C_truep((C_word)C_i_equalp(t7,t8))){
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6405,a[2]=t6,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* match.scm: 2036 equal-test? */
f_6638(t9,((C_word*)t0)[5]);}
else{
t9=t6;
f_6386(t9,C_SCHEME_FALSE);}}}}

/* k6403 in k6372 in mem in k6351 in k6336 in in in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_6405(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_caddr(((C_word*)t0)[4]);
t3=(C_word)C_i_caddr(((C_word*)t0)[3]);
t4=(C_word)C_i_equalp(t2,t3);
t5=((C_word*)t0)[2];
f_6386(t5,(C_word)C_i_not(t4));}
else{
t2=((C_word*)t0)[2];
f_6386(t2,C_SCHEME_FALSE);}}

/* k6384 in k6372 in mem in k6351 in k6336 in in in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_fcall f_6386(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* match.scm: 2042 mem */
t3=((C_word*)((C_word*)t0)[2])[1];
f_6361(t3,((C_word*)t0)[4],t2);}}

/* equal-test? in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_fcall f_6638(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6638,NULL,2,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_eqp(t3,lf[36]);
if(C_truep(t4)){
t5=(C_word)C_i_caddr(t2);
if(C_truep((C_word)C_i_stringp(t5))){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,lf[37]);}
else{
if(C_truep((C_word)C_booleanp(t5))){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,lf[38]);}
else{
if(C_truep((C_word)C_charp(t5))){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,lf[39]);}
else{
if(C_truep((C_word)C_i_numberp(t5))){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,lf[40]);}
else{
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6678,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(t5))){
t7=(C_word)C_i_cdr(t5);
if(C_truep((C_word)C_i_pairp(t7))){
t8=(C_word)C_i_cddr(t5);
if(C_truep((C_word)C_i_nullp(t8))){
t9=(C_word)C_i_car(t5);
t10=(C_word)C_eqp(lf[42],t9);
if(C_truep(t10)){
t11=(C_word)C_i_cadr(t5);
t12=t6;
f_6678(t12,(C_word)C_i_symbolp(t11));}
else{
t11=t6;
f_6678(t11,C_SCHEME_FALSE);}}
else{
t9=t6;
f_6678(t9,C_SCHEME_FALSE);}}
else{
t8=t6;
f_6678(t8,C_SCHEME_FALSE);}}
else{
t7=t6;
f_6678(t7,C_SCHEME_FALSE);}}}}}}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}

/* k6676 in equal-test? in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_fcall f_6678(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?lf[41]:C_SCHEME_FALSE));}

/* disjoint? in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static C_word C_fcall f_6724(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_i_car(t1);
return((C_word)C_i_memq(t2,*((C_word*)lf[11]+1)));}

/* add-a in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_fcall f_6734(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6734,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6738,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_car(t2);
t5=t3;
f_6738(t5,(C_word)C_i_assq(t4,((C_word*)t0)[2]));}
else{
t4=t3;
f_6738(t4,C_SCHEME_FALSE);}}

/* k6736 in add-a in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_fcall f_6738(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6738,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(t1);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,t2,t3));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,lf[22],((C_word*)t0)[3]));}}

/* add-d in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_fcall f_6767(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6767,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6771,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_car(t2);
t5=t3;
f_6771(t5,(C_word)C_i_assq(t4,((C_word*)t0)[2]));}
else{
t4=t3;
f_6771(t4,C_SCHEME_FALSE);}}

/* k6769 in add-d in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_fcall f_6771(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6771,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cddr(t1);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,t2,t3));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,lf[23],((C_word*)t0)[3]));}}

/* setter in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_fcall f_6801(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word ab[233],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6801,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6803,a[2]=((C_word*)t0)[3],a[3]=((C_word)li7),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t5=(C_word)C_i_car(t2);
t6=(C_word)C_eqp(t5,lf[17]);
if(C_truep(t6)){
t7=(C_word)C_i_cadr(t2);
t8=(C_word)C_a_i_list(&a,2,lf[18],t7);
t9=(C_word)C_a_i_list(&a,1,t8);
t10=(C_word)C_a_i_list(&a,1,lf[28]);
t11=(C_word)C_i_caddr(t2);
t12=(C_word)C_a_i_list(&a,4,lf[29],lf[18],t11,lf[28]);
t13=(C_word)C_a_i_list(&a,3,lf[19],t10,t12);
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,(C_word)C_a_i_list(&a,3,lf[20],t9,t13));}
else{
t7=(C_word)C_i_car(t2);
t8=(C_word)C_eqp(t7,lf[21]);
if(C_truep(t8)){
t9=(C_word)C_i_cadr(t2);
t10=(C_word)C_a_i_list(&a,2,lf[18],t9);
t11=(C_word)C_a_i_list(&a,1,t10);
t12=(C_word)C_a_i_list(&a,1,lf[28]);
t13=(C_word)C_a_i_list(&a,3,lf[30],lf[18],lf[28]);
t14=(C_word)C_a_i_list(&a,3,lf[19],t12,t13);
t15=t1;
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,(C_word)C_a_i_list(&a,3,lf[20],t11,t14));}
else{
t9=(C_word)C_i_car(t2);
t10=(C_word)C_eqp(t9,lf[22]);
if(C_truep(t10)){
t11=(C_word)C_i_cadr(t2);
t12=(C_word)C_a_i_list(&a,2,lf[18],t11);
t13=(C_word)C_a_i_list(&a,1,t12);
t14=(C_word)C_a_i_list(&a,1,lf[28]);
t15=(C_word)C_a_i_list(&a,3,lf[31],lf[18],lf[28]);
t16=(C_word)C_a_i_list(&a,3,lf[19],t14,t15);
t17=t1;
((C_proc2)(void*)(*((C_word*)t17+1)))(2,t17,(C_word)C_a_i_list(&a,3,lf[20],t13,t16));}
else{
t11=(C_word)C_i_car(t2);
t12=(C_word)C_eqp(t11,lf[23]);
if(C_truep(t12)){
t13=(C_word)C_i_cadr(t2);
t14=(C_word)C_a_i_list(&a,2,lf[18],t13);
t15=(C_word)C_a_i_list(&a,1,t14);
t16=(C_word)C_a_i_list(&a,1,lf[28]);
t17=(C_word)C_a_i_list(&a,3,lf[32],lf[18],lf[28]);
t18=(C_word)C_a_i_list(&a,3,lf[19],t16,t17);
t19=t1;
((C_proc2)(void*)(*((C_word*)t19+1)))(2,t19,(C_word)C_a_i_list(&a,3,lf[20],t15,t18));}
else{
t13=(C_word)C_i_car(t2);
t14=(C_word)C_eqp(t13,lf[24]);
if(C_truep(t14)){
t15=(C_word)C_i_cadr(t2);
t16=(C_word)C_a_i_list(&a,2,lf[18],t15);
t17=(C_word)C_a_i_list(&a,1,t16);
t18=(C_word)C_a_i_list(&a,1,lf[28]);
t19=(C_word)C_i_caddr(t2);
t20=(C_word)C_a_i_list(&a,4,lf[33],lf[18],t19,lf[28]);
t21=(C_word)C_a_i_list(&a,3,lf[19],t18,t20);
t22=t1;
((C_proc2)(void*)(*((C_word*)t22+1)))(2,t22,(C_word)C_a_i_list(&a,3,lf[20],t17,t21));}
else{
t15=(C_word)C_i_car(t2);
t16=(C_word)C_i_assq(t15,((C_word*)t0)[2]);
t17=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6995,a[2]=t4,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t16)){
t18=(C_word)C_i_cadr(t16);
t19=(C_word)C_i_cadr(t2);
t20=(C_word)C_a_i_list(&a,2,t18,t19);
t21=(C_word)C_a_i_list(&a,2,lf[18],t20);
t22=(C_word)C_a_i_list(&a,1,t21);
t23=(C_word)C_a_i_list(&a,1,lf[28]);
t24=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7056,a[2]=t22,a[3]=t17,a[4]=t23,tmp=(C_word)a,a+=5,tmp);
t25=(C_word)C_i_cddr(t16);
/* match.scm: 2137 mk-setter */
t26=t4;
f_6803(t26,t24,t25);}
else{
t18=t17;
f_6995(t18,C_SCHEME_FALSE);}}}}}}}
else{
/* match.scm: 2111 ##match#syntax-err */
t5=*((C_word*)lf[1]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t3,lf[34]);}}

/* k7054 in setter in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_7056(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7056,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,t1,lf[18],lf[28]);
t3=(C_word)C_a_i_list(&a,3,lf[19],((C_word*)t0)[4],t2);
t4=((C_word*)t0)[3];
f_6995(t4,(C_word)C_a_i_list(&a,3,lf[20],((C_word*)t0)[2],t3));}

/* k6993 in setter in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_fcall f_6995(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6995,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_i_cadr(((C_word*)t0)[3]);
t3=(C_word)C_a_i_list(&a,2,lf[18],t2);
t4=(C_word)C_a_i_list(&a,1,t3);
t5=(C_word)C_a_i_list(&a,1,lf[28]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7021,a[2]=t4,a[3]=((C_word*)t0)[4],a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_i_car(((C_word*)t0)[3]);
/* match.scm: 2139 mk-setter */
t8=((C_word*)t0)[2];
f_6803(t8,t6,t7);}}

/* k7019 in k6993 in setter in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_7021(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7021,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,t1,lf[18],lf[28]);
t3=(C_word)C_a_i_list(&a,3,lf[19],((C_word*)t0)[4],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[20],((C_word*)t0)[2],t3));}

/* mk-setter in setter in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_fcall f_6803(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6803,NULL,3,t0,t1,t2);}
/* match.scm: 2109 symbol-append */
f_7371(t1,(C_word)C_a_i_list(&a,3,lf[26],t2,lf[27]));}

/* getter in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_fcall f_7106(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word ab[214],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7106,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_car(t2);
t5=(C_word)C_eqp(t4,lf[17]);
if(C_truep(t5)){
t6=(C_word)C_i_cadr(t2);
t7=(C_word)C_a_i_list(&a,2,lf[18],t6);
t8=(C_word)C_a_i_list(&a,1,t7);
t9=(C_word)C_i_caddr(t2);
t10=(C_word)C_a_i_list(&a,3,lf[17],lf[18],t9);
t11=(C_word)C_a_i_list(&a,3,lf[19],C_SCHEME_END_OF_LIST,t10);
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,(C_word)C_a_i_list(&a,3,lf[20],t8,t11));}
else{
t6=(C_word)C_i_car(t2);
t7=(C_word)C_eqp(t6,lf[21]);
if(C_truep(t7)){
t8=(C_word)C_i_cadr(t2);
t9=(C_word)C_a_i_list(&a,2,lf[18],t8);
t10=(C_word)C_a_i_list(&a,1,t9);
t11=(C_word)C_a_i_list(&a,2,lf[21],lf[18]);
t12=(C_word)C_a_i_list(&a,3,lf[19],C_SCHEME_END_OF_LIST,t11);
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,(C_word)C_a_i_list(&a,3,lf[20],t10,t12));}
else{
t8=(C_word)C_i_car(t2);
t9=(C_word)C_eqp(t8,lf[22]);
if(C_truep(t9)){
t10=(C_word)C_i_cadr(t2);
t11=(C_word)C_a_i_list(&a,2,lf[18],t10);
t12=(C_word)C_a_i_list(&a,1,t11);
t13=(C_word)C_a_i_list(&a,2,lf[22],lf[18]);
t14=(C_word)C_a_i_list(&a,3,lf[19],C_SCHEME_END_OF_LIST,t13);
t15=t1;
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,(C_word)C_a_i_list(&a,3,lf[20],t12,t14));}
else{
t10=(C_word)C_i_car(t2);
t11=(C_word)C_eqp(t10,lf[23]);
if(C_truep(t11)){
t12=(C_word)C_i_cadr(t2);
t13=(C_word)C_a_i_list(&a,2,lf[18],t12);
t14=(C_word)C_a_i_list(&a,1,t13);
t15=(C_word)C_a_i_list(&a,2,lf[23],lf[18]);
t16=(C_word)C_a_i_list(&a,3,lf[19],C_SCHEME_END_OF_LIST,t15);
t17=t1;
((C_proc2)(void*)(*((C_word*)t17+1)))(2,t17,(C_word)C_a_i_list(&a,3,lf[20],t14,t16));}
else{
t12=(C_word)C_i_car(t2);
t13=(C_word)C_eqp(t12,lf[24]);
if(C_truep(t13)){
t14=(C_word)C_i_cadr(t2);
t15=(C_word)C_a_i_list(&a,2,lf[18],t14);
t16=(C_word)C_a_i_list(&a,1,t15);
t17=(C_word)C_i_caddr(t2);
t18=(C_word)C_a_i_list(&a,3,lf[24],lf[18],t17);
t19=(C_word)C_a_i_list(&a,3,lf[19],C_SCHEME_END_OF_LIST,t18);
t20=t1;
((C_proc2)(void*)(*((C_word*)t20+1)))(2,t20,(C_word)C_a_i_list(&a,3,lf[20],t16,t19));}
else{
t14=(C_word)C_i_car(t2);
t15=(C_word)C_i_assq(t14,((C_word*)t0)[2]);
t16=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7275,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t15)){
t17=(C_word)C_i_cadr(t15);
t18=(C_word)C_i_cadr(t2);
t19=(C_word)C_a_i_list(&a,2,t17,t18);
t20=(C_word)C_a_i_list(&a,2,lf[18],t19);
t21=(C_word)C_a_i_list(&a,1,t20);
t22=(C_word)C_i_cddr(t15);
t23=(C_word)C_a_i_list(&a,2,t22,lf[18]);
t24=(C_word)C_a_i_list(&a,3,lf[19],C_SCHEME_END_OF_LIST,t23);
t25=t16;
f_7275(t25,(C_word)C_a_i_list(&a,3,lf[20],t21,t24));}
else{
t17=t16;
f_7275(t17,C_SCHEME_FALSE);}}}}}}}
else{
/* match.scm: 2142 ##match#syntax-err */
t4=*((C_word*)lf[1]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,t3,lf[25]);}}

/* k7273 in getter in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_fcall f_7275(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7275,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_i_cadr(((C_word*)t0)[2]);
t3=(C_word)C_a_i_list(&a,2,lf[18],t2);
t4=(C_word)C_a_i_list(&a,1,t3);
t5=(C_word)C_i_car(((C_word*)t0)[2]);
t6=(C_word)C_a_i_list(&a,2,t5,lf[18]);
t7=(C_word)C_a_i_list(&a,3,lf[19],C_SCHEME_END_OF_LIST,t6);
t8=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_list(&a,3,lf[20],t4,t7));}}

/* symbol-append in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_fcall f_7371(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7371,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7379,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7383,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7385,a[2]=((C_word)li4),tmp=(C_word)a,a+=3,tmp);
/* map */
t6=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,t2);}

/* a7384 in symbol-append in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_7385(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7385,3,t0,t1,t2);}
if(C_truep((C_word)C_i_symbolp(t2))){
/* match.scm: 2199 symbol->string */
t3=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}
else{
if(C_truep((C_word)C_i_numberp(t2))){
/* match.scm: 2200 number->string */
C_number_to_string(3,0,t1,t2);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}}

/* k7381 in symbol-append in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_7383(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],*((C_word*)lf[13]+1),t1);}

/* k7377 in symbol-append in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_7379(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* match.scm: 2194 string->symbol */
t2=*((C_word*)lf[12]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* ##match#set-error-control in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_748(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_748,3,t0,t1,t2);}
t3=C_mutate((C_word*)lf[6]+1,t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* ##match#set-error in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_743(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_743,3,t0,t1,t2);}
t3=C_mutate((C_word*)lf[5]+1,t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* ##match#syntax-err in k733 in k730 in k727 in k724 in k721 in k718 in k715 */
static void C_ccall f_737(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_737,4,t0,t1,t2,t3);}
/* match.scm: 661  ##sys#signal-hook */
t4=*((C_word*)lf[2]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t1,lf[3],t3,t2);}

/* ##match#every */
static void C_ccall f_690(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_690,4,t0,t1,t2,t3);}
t4=(C_word)C_i_nullp(t3);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_703,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_i_car(t3);
/* match.scm: 138  fn */
t7=t2;
((C_proc3)C_retrieve_proc(t7))(3,t7,t5,t6);}}

/* k701 in ##match#every */
static void C_ccall f_703(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* match.scm: 139  ##match#every */
t3=*((C_word*)lf[0]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[697] = {
{"toplevelmatch.scm",(void*)C_match_toplevel},
{"f_10831match.scm",(void*)f_10831},
{"f_10912match.scm",(void*)f_10912},
{"f_10838match.scm",(void*)f_10838},
{"f_10847match.scm",(void*)f_10847},
{"f_10874match.scm",(void*)f_10874},
{"f_717match.scm",(void*)f_717},
{"f_10765match.scm",(void*)f_10765},
{"f_10805match.scm",(void*)f_10805},
{"f_10812match.scm",(void*)f_10812},
{"f_10772match.scm",(void*)f_10772},
{"f_10775match.scm",(void*)f_10775},
{"f_720match.scm",(void*)f_720},
{"f_10703match.scm",(void*)f_10703},
{"f_10739match.scm",(void*)f_10739},
{"f_10746match.scm",(void*)f_10746},
{"f_10710match.scm",(void*)f_10710},
{"f_10713match.scm",(void*)f_10713},
{"f_723match.scm",(void*)f_723},
{"f_9153match.scm",(void*)f_9153},
{"f_10683match.scm",(void*)f_10683},
{"f_10679match.scm",(void*)f_10679},
{"f_10675match.scm",(void*)f_10675},
{"f_10143match.scm",(void*)f_10143},
{"f_10558match.scm",(void*)f_10558},
{"f_10655match.scm",(void*)f_10655},
{"f_10651match.scm",(void*)f_10651},
{"f_10609match.scm",(void*)f_10609},
{"f_10632match.scm",(void*)f_10632},
{"f_10628match.scm",(void*)f_10628},
{"f_10571match.scm",(void*)f_10571},
{"f_10578match.scm",(void*)f_10578},
{"f_10582match.scm",(void*)f_10582},
{"f_10549match.scm",(void*)f_10549},
{"f_10545match.scm",(void*)f_10545},
{"f_10541match.scm",(void*)f_10541},
{"f_10537match.scm",(void*)f_10537},
{"f_10533match.scm",(void*)f_10533},
{"f_10525match.scm",(void*)f_10525},
{"f_10265match.scm",(void*)f_10265},
{"f_10396match.scm",(void*)f_10396},
{"f_10493match.scm",(void*)f_10493},
{"f_10489match.scm",(void*)f_10489},
{"f_10447match.scm",(void*)f_10447},
{"f_10470match.scm",(void*)f_10470},
{"f_10466match.scm",(void*)f_10466},
{"f_10409match.scm",(void*)f_10409},
{"f_10416match.scm",(void*)f_10416},
{"f_10420match.scm",(void*)f_10420},
{"f_10271match.scm",(void*)f_10271},
{"f_10307match.scm",(void*)f_10307},
{"f_10369match.scm",(void*)f_10369},
{"f_10365match.scm",(void*)f_10365},
{"f_10323match.scm",(void*)f_10323},
{"f_10346match.scm",(void*)f_10346},
{"f_10342match.scm",(void*)f_10342},
{"f_10278match.scm",(void*)f_10278},
{"f_10282match.scm",(void*)f_10282},
{"f_10286match.scm",(void*)f_10286},
{"f_10298match.scm",(void*)f_10298},
{"f_10155match.scm",(void*)f_10155},
{"f_10179match.scm",(void*)f_10179},
{"f_10241match.scm",(void*)f_10241},
{"f_10237match.scm",(void*)f_10237},
{"f_10195match.scm",(void*)f_10195},
{"f_10218match.scm",(void*)f_10218},
{"f_10214match.scm",(void*)f_10214},
{"f_10162match.scm",(void*)f_10162},
{"f_10166match.scm",(void*)f_10166},
{"f_10093match.scm",(void*)f_10093},
{"f_10116match.scm",(void*)f_10116},
{"f_10100match.scm",(void*)f_10100},
{"f_9437match.scm",(void*)f_9437},
{"f_10087match.scm",(void*)f_10087},
{"f_10083match.scm",(void*)f_10083},
{"f_10079match.scm",(void*)f_10079},
{"f_9541match.scm",(void*)f_9541},
{"f_9956match.scm",(void*)f_9956},
{"f_10053match.scm",(void*)f_10053},
{"f_10049match.scm",(void*)f_10049},
{"f_10007match.scm",(void*)f_10007},
{"f_10030match.scm",(void*)f_10030},
{"f_10026match.scm",(void*)f_10026},
{"f_9969match.scm",(void*)f_9969},
{"f_9976match.scm",(void*)f_9976},
{"f_9980match.scm",(void*)f_9980},
{"f_9947match.scm",(void*)f_9947},
{"f_9943match.scm",(void*)f_9943},
{"f_9939match.scm",(void*)f_9939},
{"f_9935match.scm",(void*)f_9935},
{"f_9931match.scm",(void*)f_9931},
{"f_9923match.scm",(void*)f_9923},
{"f_9663match.scm",(void*)f_9663},
{"f_9794match.scm",(void*)f_9794},
{"f_9891match.scm",(void*)f_9891},
{"f_9887match.scm",(void*)f_9887},
{"f_9845match.scm",(void*)f_9845},
{"f_9868match.scm",(void*)f_9868},
{"f_9864match.scm",(void*)f_9864},
{"f_9807match.scm",(void*)f_9807},
{"f_9814match.scm",(void*)f_9814},
{"f_9818match.scm",(void*)f_9818},
{"f_9669match.scm",(void*)f_9669},
{"f_9705match.scm",(void*)f_9705},
{"f_9767match.scm",(void*)f_9767},
{"f_9763match.scm",(void*)f_9763},
{"f_9721match.scm",(void*)f_9721},
{"f_9744match.scm",(void*)f_9744},
{"f_9740match.scm",(void*)f_9740},
{"f_9676match.scm",(void*)f_9676},
{"f_9680match.scm",(void*)f_9680},
{"f_9684match.scm",(void*)f_9684},
{"f_9696match.scm",(void*)f_9696},
{"f_9553match.scm",(void*)f_9553},
{"f_9577match.scm",(void*)f_9577},
{"f_9639match.scm",(void*)f_9639},
{"f_9635match.scm",(void*)f_9635},
{"f_9593match.scm",(void*)f_9593},
{"f_9616match.scm",(void*)f_9616},
{"f_9612match.scm",(void*)f_9612},
{"f_9560match.scm",(void*)f_9560},
{"f_9564match.scm",(void*)f_9564},
{"f_9443match.scm",(void*)f_9443},
{"f_9455match.scm",(void*)f_9455},
{"f_9517match.scm",(void*)f_9517},
{"f_9513match.scm",(void*)f_9513},
{"f_9471match.scm",(void*)f_9471},
{"f_9494match.scm",(void*)f_9494},
{"f_9490match.scm",(void*)f_9490},
{"f_9265match.scm",(void*)f_9265},
{"f_9274match.scm",(void*)f_9274},
{"f_9404match.scm",(void*)f_9404},
{"f_9400match.scm",(void*)f_9400},
{"f_9358match.scm",(void*)f_9358},
{"f_9381match.scm",(void*)f_9381},
{"f_9377match.scm",(void*)f_9377},
{"f_9287match.scm",(void*)f_9287},
{"f_9293match.scm",(void*)f_9293},
{"f_9296match.scm",(void*)f_9296},
{"f_9305match.scm",(void*)f_9305},
{"f_9206match.scm",(void*)f_9206},
{"f_9210match.scm",(void*)f_9210},
{"f_9213match.scm",(void*)f_9213},
{"f_9197match.scm",(void*)f_9197},
{"f_9164match.scm",(void*)f_9164},
{"f_9192match.scm",(void*)f_9192},
{"f_9168match.scm",(void*)f_9168},
{"f_9171match.scm",(void*)f_9171},
{"f_9178match.scm",(void*)f_9178},
{"f_9155match.scm",(void*)f_9155},
{"f_726match.scm",(void*)f_726},
{"f_8965match.scm",(void*)f_8965},
{"f_9140match.scm",(void*)f_9140},
{"f_9136match.scm",(void*)f_9136},
{"f_9132match.scm",(void*)f_9132},
{"f_9128match.scm",(void*)f_9128},
{"f_9022match.scm",(void*)f_9022},
{"f_9025match.scm",(void*)f_9025},
{"f_9028match.scm",(void*)f_9028},
{"f_9031match.scm",(void*)f_9031},
{"f_9040match.scm",(void*)f_9040},
{"f_8993match.scm",(void*)f_8993},
{"f_8967match.scm",(void*)f_8967},
{"f_729match.scm",(void*)f_729},
{"f_7598match.scm",(void*)f_7598},
{"f_8949match.scm",(void*)f_8949},
{"f_8945match.scm",(void*)f_8945},
{"f_8941match.scm",(void*)f_8941},
{"f_8409match.scm",(void*)f_8409},
{"f_8824match.scm",(void*)f_8824},
{"f_8921match.scm",(void*)f_8921},
{"f_8917match.scm",(void*)f_8917},
{"f_8875match.scm",(void*)f_8875},
{"f_8898match.scm",(void*)f_8898},
{"f_8894match.scm",(void*)f_8894},
{"f_8837match.scm",(void*)f_8837},
{"f_8844match.scm",(void*)f_8844},
{"f_8848match.scm",(void*)f_8848},
{"f_8815match.scm",(void*)f_8815},
{"f_8811match.scm",(void*)f_8811},
{"f_8807match.scm",(void*)f_8807},
{"f_8803match.scm",(void*)f_8803},
{"f_8799match.scm",(void*)f_8799},
{"f_8791match.scm",(void*)f_8791},
{"f_8531match.scm",(void*)f_8531},
{"f_8662match.scm",(void*)f_8662},
{"f_8759match.scm",(void*)f_8759},
{"f_8755match.scm",(void*)f_8755},
{"f_8713match.scm",(void*)f_8713},
{"f_8736match.scm",(void*)f_8736},
{"f_8732match.scm",(void*)f_8732},
{"f_8675match.scm",(void*)f_8675},
{"f_8682match.scm",(void*)f_8682},
{"f_8686match.scm",(void*)f_8686},
{"f_8537match.scm",(void*)f_8537},
{"f_8573match.scm",(void*)f_8573},
{"f_8635match.scm",(void*)f_8635},
{"f_8631match.scm",(void*)f_8631},
{"f_8589match.scm",(void*)f_8589},
{"f_8612match.scm",(void*)f_8612},
{"f_8608match.scm",(void*)f_8608},
{"f_8544match.scm",(void*)f_8544},
{"f_8548match.scm",(void*)f_8548},
{"f_8552match.scm",(void*)f_8552},
{"f_8564match.scm",(void*)f_8564},
{"f_8421match.scm",(void*)f_8421},
{"f_8445match.scm",(void*)f_8445},
{"f_8507match.scm",(void*)f_8507},
{"f_8503match.scm",(void*)f_8503},
{"f_8461match.scm",(void*)f_8461},
{"f_8484match.scm",(void*)f_8484},
{"f_8480match.scm",(void*)f_8480},
{"f_8428match.scm",(void*)f_8428},
{"f_8432match.scm",(void*)f_8432},
{"f_8359match.scm",(void*)f_8359},
{"f_8382match.scm",(void*)f_8382},
{"f_8366match.scm",(void*)f_8366},
{"f_7703match.scm",(void*)f_7703},
{"f_8353match.scm",(void*)f_8353},
{"f_8349match.scm",(void*)f_8349},
{"f_8345match.scm",(void*)f_8345},
{"f_7807match.scm",(void*)f_7807},
{"f_8222match.scm",(void*)f_8222},
{"f_8319match.scm",(void*)f_8319},
{"f_8315match.scm",(void*)f_8315},
{"f_8273match.scm",(void*)f_8273},
{"f_8296match.scm",(void*)f_8296},
{"f_8292match.scm",(void*)f_8292},
{"f_8235match.scm",(void*)f_8235},
{"f_8242match.scm",(void*)f_8242},
{"f_8246match.scm",(void*)f_8246},
{"f_8213match.scm",(void*)f_8213},
{"f_8209match.scm",(void*)f_8209},
{"f_8205match.scm",(void*)f_8205},
{"f_8201match.scm",(void*)f_8201},
{"f_8197match.scm",(void*)f_8197},
{"f_8189match.scm",(void*)f_8189},
{"f_7929match.scm",(void*)f_7929},
{"f_8060match.scm",(void*)f_8060},
{"f_8157match.scm",(void*)f_8157},
{"f_8153match.scm",(void*)f_8153},
{"f_8111match.scm",(void*)f_8111},
{"f_8134match.scm",(void*)f_8134},
{"f_8130match.scm",(void*)f_8130},
{"f_8073match.scm",(void*)f_8073},
{"f_8080match.scm",(void*)f_8080},
{"f_8084match.scm",(void*)f_8084},
{"f_7935match.scm",(void*)f_7935},
{"f_7971match.scm",(void*)f_7971},
{"f_8033match.scm",(void*)f_8033},
{"f_8029match.scm",(void*)f_8029},
{"f_7987match.scm",(void*)f_7987},
{"f_8010match.scm",(void*)f_8010},
{"f_8006match.scm",(void*)f_8006},
{"f_7942match.scm",(void*)f_7942},
{"f_7946match.scm",(void*)f_7946},
{"f_7950match.scm",(void*)f_7950},
{"f_7962match.scm",(void*)f_7962},
{"f_7819match.scm",(void*)f_7819},
{"f_7843match.scm",(void*)f_7843},
{"f_7905match.scm",(void*)f_7905},
{"f_7901match.scm",(void*)f_7901},
{"f_7859match.scm",(void*)f_7859},
{"f_7882match.scm",(void*)f_7882},
{"f_7878match.scm",(void*)f_7878},
{"f_7826match.scm",(void*)f_7826},
{"f_7830match.scm",(void*)f_7830},
{"f_7709match.scm",(void*)f_7709},
{"f_7721match.scm",(void*)f_7721},
{"f_7783match.scm",(void*)f_7783},
{"f_7779match.scm",(void*)f_7779},
{"f_7737match.scm",(void*)f_7737},
{"f_7760match.scm",(void*)f_7760},
{"f_7756match.scm",(void*)f_7756},
{"f_7662match.scm",(void*)f_7662},
{"f_7637match.scm",(void*)f_7637},
{"f_7657match.scm",(void*)f_7657},
{"f_7628match.scm",(void*)f_7628},
{"f_7603match.scm",(void*)f_7603},
{"f_732match.scm",(void*)f_732},
{"f_7495match.scm",(void*)f_7495},
{"f_7520match.scm",(void*)f_7520},
{"f_7556match.scm",(void*)f_7556},
{"f_7526match.scm",(void*)f_7526},
{"f_7500match.scm",(void*)f_7500},
{"f_735match.scm",(void*)f_735},
{"f_7493match.scm",(void*)f_7493},
{"f_7476match.scm",(void*)f_7476},
{"f_7460match.scm",(void*)f_7460},
{"f_7429match.scm",(void*)f_7429},
{"f_7447match.scm",(void*)f_7447},
{"f_7406match.scm",(void*)f_7406},
{"f_1125match.scm",(void*)f_1125},
{"f_1129match.scm",(void*)f_1129},
{"f_1132match.scm",(void*)f_1132},
{"f_1299match.scm",(void*)f_1299},
{"f_1135match.scm",(void*)f_1135},
{"f_1147match.scm",(void*)f_1147},
{"f_1153match.scm",(void*)f_1153},
{"f_1291match.scm",(void*)f_1291},
{"f_1156match.scm",(void*)f_1156},
{"f_1279match.scm",(void*)f_1279},
{"f_1159match.scm",(void*)f_1159},
{"f_1162match.scm",(void*)f_1162},
{"f_1273match.scm",(void*)f_1273},
{"f_1173match.scm",(void*)f_1173},
{"f_1243match.scm",(void*)f_1243},
{"f_1233match.scm",(void*)f_1233},
{"f_1229match.scm",(void*)f_1229},
{"f_1213match.scm",(void*)f_1213},
{"f_1181match.scm",(void*)f_1181},
{"f_1169match.scm",(void*)f_1169},
{"f_969match.scm",(void*)f_969},
{"f_973match.scm",(void*)f_973},
{"f_976match.scm",(void*)f_976},
{"f_1123match.scm",(void*)f_1123},
{"f_979match.scm",(void*)f_979},
{"f_991match.scm",(void*)f_991},
{"f_997match.scm",(void*)f_997},
{"f_1115match.scm",(void*)f_1115},
{"f_1000match.scm",(void*)f_1000},
{"f_1103match.scm",(void*)f_1103},
{"f_1003match.scm",(void*)f_1003},
{"f_1006match.scm",(void*)f_1006},
{"f_1073match.scm",(void*)f_1073},
{"f_1025match.scm",(void*)f_1025},
{"f_1067match.scm",(void*)f_1067},
{"f_1065match.scm",(void*)f_1065},
{"f_1061match.scm",(void*)f_1061},
{"f_1045match.scm",(void*)f_1045},
{"f_1021match.scm",(void*)f_1021},
{"f_757match.scm",(void*)f_757},
{"f_761match.scm",(void*)f_761},
{"f_764match.scm",(void*)f_764},
{"f_825match.scm",(void*)f_825},
{"f_963match.scm",(void*)f_963},
{"f_829match.scm",(void*)f_829},
{"f_841match.scm",(void*)f_841},
{"f_951match.scm",(void*)f_951},
{"f_947match.scm",(void*)f_947},
{"f_943match.scm",(void*)f_943},
{"f_939match.scm",(void*)f_939},
{"f_844match.scm",(void*)f_844},
{"f_872match.scm",(void*)f_872},
{"f_861match.scm",(void*)f_861},
{"f_770match.scm",(void*)f_770},
{"f_823match.scm",(void*)f_823},
{"f_773match.scm",(void*)f_773},
{"f_776match.scm",(void*)f_776},
{"f_1395match.scm",(void*)f_1395},
{"f_1432match.scm",(void*)f_1432},
{"f_1435match.scm",(void*)f_1435},
{"f_1444match.scm",(void*)f_1444},
{"f_1419match.scm",(void*)f_1419},
{"f_1407match.scm",(void*)f_1407},
{"f_1473match.scm",(void*)f_1473},
{"f_1479match.scm",(void*)f_1479},
{"f_1503match.scm",(void*)f_1503},
{"f_2528match.scm",(void*)f_2528},
{"f_2548match.scm",(void*)f_2548},
{"f_2552match.scm",(void*)f_2552},
{"f_2266match.scm",(void*)f_2266},
{"f_2484match.scm",(void*)f_2484},
{"f_2487match.scm",(void*)f_2487},
{"f_2497match.scm",(void*)f_2497},
{"f_2512match.scm",(void*)f_2512},
{"f_2494match.scm",(void*)f_2494},
{"f_2467match.scm",(void*)f_2467},
{"f_2463match.scm",(void*)f_2463},
{"f_2459match.scm",(void*)f_2459},
{"f_2350match.scm",(void*)f_2350},
{"f_2422match.scm",(void*)f_2422},
{"f_2389match.scm",(void*)f_2389},
{"f_2402match.scm",(void*)f_2402},
{"f_2365match.scm",(void*)f_2365},
{"f_2375match.scm",(void*)f_2375},
{"f_2379match.scm",(void*)f_2379},
{"f_2359match.scm",(void*)f_2359},
{"f_2313match.scm",(void*)f_2313},
{"f_2268match.scm",(void*)f_2268},
{"f_2276match.scm",(void*)f_2276},
{"f_2280match.scm",(void*)f_2280},
{"f_1536match.scm",(void*)f_1536},
{"f_1568match.scm",(void*)f_1568},
{"f_2212match.scm",(void*)f_2212},
{"f_2215match.scm",(void*)f_2215},
{"f_2225match.scm",(void*)f_2225},
{"f_2240match.scm",(void*)f_2240},
{"f_2222match.scm",(void*)f_2222},
{"f_2140match.scm",(void*)f_2140},
{"f_2107match.scm",(void*)f_2107},
{"f_2120match.scm",(void*)f_2120},
{"f_2052match.scm",(void*)f_2052},
{"f_2032match.scm",(void*)f_2032},
{"f_2005match.scm",(void*)f_2005},
{"f_1985match.scm",(void*)f_1985},
{"f_1921match.scm",(void*)f_1921},
{"f_1938match.scm",(void*)f_1938},
{"f_1874match.scm",(void*)f_1874},
{"f_1884match.scm",(void*)f_1884},
{"f_1827match.scm",(void*)f_1827},
{"f_1837match.scm",(void*)f_1837},
{"f_1780match.scm",(void*)f_1780},
{"f_1790match.scm",(void*)f_1790},
{"f_1720match.scm",(void*)f_1720},
{"f_1733match.scm",(void*)f_1733},
{"f_1666match.scm",(void*)f_1666},
{"f_1683match.scm",(void*)f_1683},
{"f_1629match.scm",(void*)f_1629},
{"f_1586match.scm",(void*)f_1586},
{"f_1538match.scm",(void*)f_1538},
{"f_1546match.scm",(void*)f_1546},
{"f_1550match.scm",(void*)f_1550},
{"f_1506match.scm",(void*)f_1506},
{"f_1301match.scm",(void*)f_1301},
{"f_1325match.scm",(void*)f_1325},
{"f_2568match.scm",(void*)f_2568},
{"f_3454match.scm",(void*)f_3454},
{"f_3462match.scm",(void*)f_3462},
{"f_3362match.scm",(void*)f_3362},
{"f_3381match.scm",(void*)f_3381},
{"f_3391match.scm",(void*)f_3391},
{"f_3269match.scm",(void*)f_3269},
{"f_3333match.scm",(void*)f_3333},
{"f_3287match.scm",(void*)f_3287},
{"f_3310match.scm",(void*)f_3310},
{"f_3316match.scm",(void*)f_3316},
{"f_3271match.scm",(void*)f_3271},
{"f_2572match.scm",(void*)f_2572},
{"f_2610match.scm",(void*)f_2610},
{"f_2619match.scm",(void*)f_2619},
{"f_2711match.scm",(void*)f_2711},
{"f_2788match.scm",(void*)f_2788},
{"f_2811match.scm",(void*)f_2811},
{"f_2900match.scm",(void*)f_2900},
{"f_2965match.scm",(void*)f_2965},
{"f_3013match.scm",(void*)f_3013},
{"f_3044match.scm",(void*)f_3044},
{"f_3074match.scm",(void*)f_3074},
{"f_3144match.scm",(void*)f_3144},
{"f_3146match.scm",(void*)f_3146},
{"f_3154match.scm",(void*)f_3154},
{"f_3113match.scm",(void*)f_3113},
{"f_3123match.scm",(void*)f_3123},
{"f_3022match.scm",(void*)f_3022},
{"f_2974match.scm",(void*)f_2974},
{"f_2978match.scm",(void*)f_2978},
{"f_2993match.scm",(void*)f_2993},
{"f_2997match.scm",(void*)f_2997},
{"f_3003match.scm",(void*)f_3003},
{"f_3001match.scm",(void*)f_3001},
{"f_2930match.scm",(void*)f_2930},
{"f_2951match.scm",(void*)f_2951},
{"f_2934match.scm",(void*)f_2934},
{"f_2820match.scm",(void*)f_2820},
{"f_2844match.scm",(void*)f_2844},
{"f_2863match.scm",(void*)f_2863},
{"f_2894match.scm",(void*)f_2894},
{"f_2867match.scm",(void*)f_2867},
{"f_2876match.scm",(void*)f_2876},
{"f_2830match.scm",(void*)f_2830},
{"f_2797match.scm",(void*)f_2797},
{"f_2720match.scm",(void*)f_2720},
{"f_2755match.scm",(void*)f_2755},
{"f_2723match.scm",(void*)f_2723},
{"f_2657match.scm",(void*)f_2657},
{"f_2660match.scm",(void*)f_2660},
{"f_2591match.scm",(void*)f_2591},
{"f_3401match.scm",(void*)f_3401},
{"f_3419match.scm",(void*)f_3419},
{"f_3425match.scm",(void*)f_3425},
{"f_3437match.scm",(void*)f_3437},
{"f_3464match.scm",(void*)f_3464},
{"f_3724match.scm",(void*)f_3724},
{"f_3753match.scm",(void*)f_3753},
{"f_3473match.scm",(void*)f_3473},
{"f_3487match.scm",(void*)f_3487},
{"f_3491match.scm",(void*)f_3491},
{"f_3756match.scm",(void*)f_3756},
{"f_3778match.scm",(void*)f_3778},
{"f_3513match.scm",(void*)f_3513},
{"f_3527match.scm",(void*)f_3527},
{"f_3531match.scm",(void*)f_3531},
{"f_3789match.scm",(void*)f_3789},
{"f_3744match.scm",(void*)f_3744},
{"f_3651match.scm",(void*)f_3651},
{"f_3629match.scm",(void*)f_3629},
{"f_3547match.scm",(void*)f_3547},
{"f_3848match.scm",(void*)f_3848},
{"f_3973match.scm",(void*)f_3973},
{"f_3975match.scm",(void*)f_3975},
{"f_4086match.scm",(void*)f_4086},
{"f_4099match.scm",(void*)f_4099},
{"f_4115match.scm",(void*)f_4115},
{"f_4136match.scm",(void*)f_4136},
{"f_4178match.scm",(void*)f_4178},
{"f_4221match.scm",(void*)f_4221},
{"f_4234match.scm",(void*)f_4234},
{"f_4296match.scm",(void*)f_4296},
{"f_4321match.scm",(void*)f_4321},
{"f_4346match.scm",(void*)f_4346},
{"f_4685match.scm",(void*)f_4685},
{"f_4975match.scm",(void*)f_4975},
{"f_4978match.scm",(void*)f_4978},
{"f_4923match.scm",(void*)f_4923},
{"f_4937match.scm",(void*)f_4937},
{"f_4939match.scm",(void*)f_4939},
{"f_4964match.scm",(void*)f_4964},
{"f_4935match.scm",(void*)f_4935},
{"f_4691match.scm",(void*)f_4691},
{"f_4706match.scm",(void*)f_4706},
{"f_4718match.scm",(void*)f_4718},
{"f_4727match.scm",(void*)f_4727},
{"f_4729match.scm",(void*)f_4729},
{"f_4751match.scm",(void*)f_4751},
{"f_4839match.scm",(void*)f_4839},
{"f_4857match.scm",(void*)f_4857},
{"f_4865match.scm",(void*)f_4865},
{"f_4855match.scm",(void*)f_4855},
{"f_4776match.scm",(void*)f_4776},
{"f_4829match.scm",(void*)f_4829},
{"f_4780match.scm",(void*)f_4780},
{"f_4809match.scm",(void*)f_4809},
{"f_4807match.scm",(void*)f_4807},
{"f_4799match.scm",(void*)f_4799},
{"f_4725match.scm",(void*)f_4725},
{"f_4722match.scm",(void*)f_4722},
{"f_4653match.scm",(void*)f_4653},
{"f_4665match.scm",(void*)f_4665},
{"f_4667match.scm",(void*)f_4667},
{"f_4679match.scm",(void*)f_4679},
{"f_4355match.scm",(void*)f_4355},
{"f_4359match.scm",(void*)f_4359},
{"f_4360match.scm",(void*)f_4360},
{"f_4469match.scm",(void*)f_4469},
{"f_4553match.scm",(void*)f_4553},
{"f_4571match.scm",(void*)f_4571},
{"f_4579match.scm",(void*)f_4579},
{"f_4569match.scm",(void*)f_4569},
{"f_4488match.scm",(void*)f_4488},
{"f_4539match.scm",(void*)f_4539},
{"f_4537match.scm",(void*)f_4537},
{"f_4533match.scm",(void*)f_4533},
{"f_4492match.scm",(void*)f_4492},
{"f_4521match.scm",(void*)f_4521},
{"f_4519match.scm",(void*)f_4519},
{"f_4511match.scm",(void*)f_4511},
{"f_4462match.scm",(void*)f_4462},
{"f_4459match.scm",(void*)f_4459},
{"f_4382match.scm",(void*)f_4382},
{"f_4403match.scm",(void*)f_4403},
{"f_4385match.scm",(void*)f_4385},
{"f_4396match.scm",(void*)f_4396},
{"f_4400match.scm",(void*)f_4400},
{"f_4340match.scm",(void*)f_4340},
{"f_4315match.scm",(void*)f_4315},
{"f_4290match.scm",(void*)f_4290},
{"f_4255match.scm",(void*)f_4255},
{"f_4257match.scm",(void*)f_4257},
{"f_4282match.scm",(void*)f_4282},
{"f_4253match.scm",(void*)f_4253},
{"f_4187match.scm",(void*)f_4187},
{"f_4207match.scm",(void*)f_4207},
{"f_4145match.scm",(void*)f_4145},
{"f_4164match.scm",(void*)f_4164},
{"f_3877match.scm",(void*)f_3877},
{"f_3946match.scm",(void*)f_3946},
{"f_3939match.scm",(void*)f_3939},
{"f_3931match.scm",(void*)f_3931},
{"f_3868match.scm",(void*)f_3868},
{"f_3859match.scm",(void*)f_3859},
{"f_1327match.scm",(void*)f_1327},
{"f_1343match.scm",(void*)f_1343},
{"f_1385match.scm",(void*)f_1385},
{"f_1381match.scm",(void*)f_1381},
{"f_1370match.scm",(void*)f_1370},
{"f_1377match.scm",(void*)f_1377},
{"f_5121match.scm",(void*)f_5121},
{"f_5128match.scm",(void*)f_5128},
{"f_5137match.scm",(void*)f_5137},
{"f_5259match.scm",(void*)f_5259},
{"f_5146match.scm",(void*)f_5146},
{"f_5152match.scm",(void*)f_5152},
{"f_5181match.scm",(void*)f_5181},
{"f_5155match.scm",(void*)f_5155},
{"f_5173match.scm",(void*)f_5173},
{"f_5158match.scm",(void*)f_5158},
{"f_5303match.scm",(void*)f_5303},
{"f_5322match.scm",(void*)f_5322},
{"f_5328match.scm",(void*)f_5328},
{"f_6127match.scm",(void*)f_6127},
{"f_6123match.scm",(void*)f_6123},
{"f_6119match.scm",(void*)f_6119},
{"f_6115match.scm",(void*)f_6115},
{"f_6107match.scm",(void*)f_6107},
{"f_6103match.scm",(void*)f_6103},
{"f_6095match.scm",(void*)f_6095},
{"f_6091match.scm",(void*)f_6091},
{"f_6087match.scm",(void*)f_6087},
{"f_6083match.scm",(void*)f_6083},
{"f_6079match.scm",(void*)f_6079},
{"f_6075match.scm",(void*)f_6075},
{"f_6071match.scm",(void*)f_6071},
{"f_6067match.scm",(void*)f_6067},
{"f_6063match.scm",(void*)f_6063},
{"f_6059match.scm",(void*)f_6059},
{"f_6051match.scm",(void*)f_6051},
{"f_6047match.scm",(void*)f_6047},
{"f_6039match.scm",(void*)f_6039},
{"f_6035match.scm",(void*)f_6035},
{"f_6031match.scm",(void*)f_6031},
{"f_6027match.scm",(void*)f_6027},
{"f_6023match.scm",(void*)f_6023},
{"f_6019match.scm",(void*)f_6019},
{"f_6015match.scm",(void*)f_6015},
{"f_6011match.scm",(void*)f_6011},
{"f_6007match.scm",(void*)f_6007},
{"f_6003match.scm",(void*)f_6003},
{"f_5999match.scm",(void*)f_5999},
{"f_5995match.scm",(void*)f_5995},
{"f_5991match.scm",(void*)f_5991},
{"f_5987match.scm",(void*)f_5987},
{"f_5983match.scm",(void*)f_5983},
{"f_5975match.scm",(void*)f_5975},
{"f_5971match.scm",(void*)f_5971},
{"f_5967match.scm",(void*)f_5967},
{"f_5963match.scm",(void*)f_5963},
{"f_5959match.scm",(void*)f_5959},
{"f_5955match.scm",(void*)f_5955},
{"f_5951match.scm",(void*)f_5951},
{"f_5947match.scm",(void*)f_5947},
{"f_5943match.scm",(void*)f_5943},
{"f_5939match.scm",(void*)f_5939},
{"f_5935match.scm",(void*)f_5935},
{"f_5927match.scm",(void*)f_5927},
{"f_5923match.scm",(void*)f_5923},
{"f_5915match.scm",(void*)f_5915},
{"f_5911match.scm",(void*)f_5911},
{"f_5907match.scm",(void*)f_5907},
{"f_5903match.scm",(void*)f_5903},
{"f_5899match.scm",(void*)f_5899},
{"f_5895match.scm",(void*)f_5895},
{"f_5891match.scm",(void*)f_5891},
{"f_5879match.scm",(void*)f_5879},
{"f_5875match.scm",(void*)f_5875},
{"f_5871match.scm",(void*)f_5871},
{"f_5867match.scm",(void*)f_5867},
{"f_5386match.scm",(void*)f_5386},
{"f_5450match.scm",(void*)f_5450},
{"f_5446match.scm",(void*)f_5446},
{"f_5442match.scm",(void*)f_5442},
{"f_5438match.scm",(void*)f_5438},
{"f_5395match.scm",(void*)f_5395},
{"f_5418match.scm",(void*)f_5418},
{"f_6197match.scm",(void*)f_6197},
{"f_6201match.scm",(void*)f_6201},
{"f_6204match.scm",(void*)f_6204},
{"f_6209match.scm",(void*)f_6209},
{"f_6276match.scm",(void*)f_6276},
{"f_6279match.scm",(void*)f_6279},
{"f_6240match.scm",(void*)f_6240},
{"f_6249match.scm",(void*)f_6249},
{"f_6328match.scm",(void*)f_6328},
{"f_6338match.scm",(void*)f_6338},
{"f_6353match.scm",(void*)f_6353},
{"f_6545match.scm",(void*)f_6545},
{"f_6558match.scm",(void*)f_6558},
{"f_6479match.scm",(void*)f_6479},
{"f_6492match.scm",(void*)f_6492},
{"f_6361match.scm",(void*)f_6361},
{"f_6374match.scm",(void*)f_6374},
{"f_6405match.scm",(void*)f_6405},
{"f_6386match.scm",(void*)f_6386},
{"f_6638match.scm",(void*)f_6638},
{"f_6678match.scm",(void*)f_6678},
{"f_6724match.scm",(void*)f_6724},
{"f_6734match.scm",(void*)f_6734},
{"f_6738match.scm",(void*)f_6738},
{"f_6767match.scm",(void*)f_6767},
{"f_6771match.scm",(void*)f_6771},
{"f_6801match.scm",(void*)f_6801},
{"f_7056match.scm",(void*)f_7056},
{"f_6995match.scm",(void*)f_6995},
{"f_7021match.scm",(void*)f_7021},
{"f_6803match.scm",(void*)f_6803},
{"f_7106match.scm",(void*)f_7106},
{"f_7275match.scm",(void*)f_7275},
{"f_7371match.scm",(void*)f_7371},
{"f_7385match.scm",(void*)f_7385},
{"f_7383match.scm",(void*)f_7383},
{"f_7379match.scm",(void*)f_7379},
{"f_748match.scm",(void*)f_748},
{"f_743match.scm",(void*)f_743},
{"f_737match.scm",(void*)f_737},
{"f_690match.scm",(void*)f_690},
{"f_703match.scm",(void*)f_703},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
