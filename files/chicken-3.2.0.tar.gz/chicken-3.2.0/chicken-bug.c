/* Generated from chicken-bug.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-04-30 12:00
   Version 3.1.10 - linux-unix-gnu-x86	[ manyargs dload ptables applyhook ]
   SVN rev. 10602	compiled 2008-04-30 on galinha (Linux)
   command line: chicken-bug.scm -quiet -no-trace -optimize-level 2 -include-path . -no-lambda-info -output-file chicken-bug.c
   used units: library eval data_structures extras srfi_69 srfi_13 posix tcp data_structures utils extras
*/

#include "chicken.h"


#ifndef C_TARGET_CC
# define C_TARGET_CC  C_INSTALL_CC
#endif

#ifndef C_TARGET_CXX
# define C_TARGET_CXX  C_INSTALL_CXX
#endif


static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_69_toplevel)
C_externimport void C_ccall C_srfi_69_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_13_toplevel)
C_externimport void C_ccall C_srfi_13_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_posix_toplevel)
C_externimport void C_ccall C_posix_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_tcp_toplevel)
C_externimport void C_ccall C_tcp_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_utils_toplevel)
C_externimport void C_ccall C_utils_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[149];
static double C_possibly_force_alignment;


C_noret_decl(C_toplevel)
C_externexport void C_ccall C_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_152)
static void C_ccall f_152(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_155)
static void C_ccall f_155(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_158)
static void C_ccall f_158(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_161)
static void C_ccall f_161(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_164)
static void C_ccall f_164(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_167)
static void C_ccall f_167(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_170)
static void C_ccall f_170(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_173)
static void C_ccall f_173(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_176)
static void C_ccall f_176(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_179)
static void C_ccall f_179(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_182)
static void C_ccall f_182(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1084)
static void C_ccall f_1084(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1074)
static void C_ccall f_1074(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1080)
static void C_ccall f_1080(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1077)
static void C_ccall f_1077(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_991)
static void C_ccall f_991(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_995)
static void C_ccall f_995(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1006)
static void C_ccall f_1006(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1012)
static void C_ccall f_1012(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1071)
static void C_ccall f_1071(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1016)
static void C_ccall f_1016(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1067)
static void C_ccall f_1067(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1019)
static void C_ccall f_1019(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1063)
static void C_ccall f_1063(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1022)
static void C_ccall f_1022(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1059)
static void C_ccall f_1059(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1025)
static void C_ccall f_1025(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1055)
static void C_ccall f_1055(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1028)
static void C_ccall f_1028(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1051)
static void C_ccall f_1051(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1047)
static void C_ccall f_1047(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1031)
static void C_ccall f_1031(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1034)
static void C_ccall f_1034(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1037)
static void C_ccall f_1037(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1040)
static void C_ccall f_1040(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1043)
static void C_ccall f_1043(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1000)
static void C_ccall f_1000(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_970)
static void C_ccall f_970(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_980)
static void C_ccall f_980(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_983)
static void C_ccall f_983(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_901)
static void C_ccall f_901(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_916)
static void C_ccall f_916(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_946)
static void C_ccall f_946(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_958)
static void C_ccall f_958(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_958)
static void C_ccall f_958r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_964)
static void C_ccall f_964(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_952)
static void C_ccall f_952(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_922)
static void C_ccall f_922(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_928)
static void C_ccall f_928(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_935)
static void C_ccall f_935(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_938)
static void C_ccall f_938(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_914)
static void C_ccall f_914(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_905)
static void C_ccall f_905(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_815)
static void C_ccall f_815(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_847)
static void C_ccall f_847(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_877)
static void C_ccall f_877(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_889)
static void C_ccall f_889(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_889)
static void C_ccall f_889r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_895)
static void C_ccall f_895(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_883)
static void C_ccall f_883(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_853)
static void C_ccall f_853(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_859)
static void C_ccall f_859(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_866)
static void C_ccall f_866(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_869)
static void C_ccall f_869(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_845)
static void C_ccall f_845(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_819)
static void C_ccall f_819(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_835)
static void C_ccall f_835(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_797)
static void C_ccall f_797(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_813)
static void C_ccall f_813(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_809)
static void C_ccall f_809(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_805)
static void C_ccall f_805(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_609)
static void C_ccall f_609(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_620)
static void C_fcall f_620(C_word t0,C_word t1) C_noret;
C_noret_decl(f_752)
static void C_ccall f_752(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_624)
static void C_ccall f_624(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_631)
static void C_fcall f_631(C_word t0,C_word t1) C_noret;
C_noret_decl(f_635)
static void C_ccall f_635(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_667)
static void C_ccall f_667(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_639)
static void C_ccall f_639(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_659)
static void C_ccall f_659(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_643)
static void C_ccall f_643(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_651)
static void C_ccall f_651(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_647)
static void C_ccall f_647(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_568)
static void C_ccall f_568(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_593)
static void C_ccall f_593(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_586)
static void C_ccall f_586(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_578)
static void C_ccall f_578(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_581)
static void C_ccall f_581(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_425)
static void C_ccall f_425(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_525)
static void C_ccall f_525(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_566)
static void C_ccall f_566(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_562)
static void C_ccall f_562(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_541)
static void C_ccall f_541(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_537)
static void C_ccall f_537(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_429)
static void C_ccall f_429(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_523)
static void C_ccall f_523(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_519)
static void C_ccall f_519(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_432)
static void C_fcall f_432(C_word t0,C_word t1) C_noret;
C_noret_decl(f_435)
static void C_ccall f_435(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_515)
static void C_ccall f_515(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_438)
static void C_ccall f_438(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_444)
static void C_fcall f_444(C_word t0,C_word t1) C_noret;
C_noret_decl(f_494)
static void C_ccall f_494(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_498)
static void C_ccall f_498(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_469)
static void C_ccall f_469(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_473)
static void C_ccall f_473(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_479)
static void C_ccall f_479(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_483)
static void C_ccall f_483(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_477)
static void C_ccall f_477(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_459)
static void C_ccall f_459(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_406)
static void C_ccall f_406(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_410)
static void C_ccall f_410(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_387)
static void C_ccall f_387(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_404)
static void C_ccall f_404(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_397)
static void C_ccall f_397(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_391)
static void C_ccall f_391(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_378)
static void C_ccall f_378(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_382)
static void C_ccall f_382(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_188)
static void C_ccall f_188(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_192)
static void C_ccall f_192(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_195)
static void C_ccall f_195(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_376)
static void C_ccall f_376(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_372)
static void C_ccall f_372(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_198)
static void C_ccall f_198(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_368)
static void C_ccall f_368(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_364)
static void C_ccall f_364(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_201)
static void C_ccall f_201(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_204)
static void C_ccall f_204(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_360)
static void C_ccall f_360(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_207)
static void C_ccall f_207(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_356)
static void C_ccall f_356(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_210)
static void C_ccall f_210(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_352)
static void C_ccall f_352(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_213)
static void C_ccall f_213(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_348)
static void C_ccall f_348(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_216)
static void C_ccall f_216(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_344)
static void C_ccall f_344(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_219)
static void C_ccall f_219(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_340)
static void C_ccall f_340(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_222)
static void C_ccall f_222(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_225)
static void C_ccall f_225(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_228)
static void C_ccall f_228(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_336)
static void C_ccall f_336(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_332)
static void C_ccall f_332(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_328)
static void C_ccall f_328(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_295)
static void C_ccall f_295(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_299)
static void C_ccall f_299(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_304)
static void C_ccall f_304(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_312)
static void C_ccall f_312(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_231)
static void C_ccall f_231(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_234)
static void C_ccall f_234(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_293)
static void C_ccall f_293(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_279)
static void C_ccall f_279(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_281)
static void C_ccall f_281(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_289)
static void C_ccall f_289(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_237)
static void C_ccall f_237(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_240)
static void C_ccall f_240(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_275)
static void C_ccall f_275(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_249)
static void C_ccall f_249(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_252)
static void C_ccall f_252(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_257)
static void C_ccall f_257(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_265)
static void C_ccall f_265(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_243)
static void C_ccall f_243(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_620)
static void C_fcall trf_620(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_620(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_620(t0,t1);}

C_noret_decl(trf_631)
static void C_fcall trf_631(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_631(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_631(t0,t1);}

C_noret_decl(trf_432)
static void C_fcall trf_432(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_432(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_432(t0,t1);}

C_noret_decl(trf_444)
static void C_fcall trf_444(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_444(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_444(t0,t1);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr7)
static void C_fcall tr7(C_proc7 k) C_regparm C_noret;
C_regparm static void C_fcall tr7(C_proc7 k){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
(k)(7,t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_main_entry_point
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("toplevel"));
C_resize_stack(131072);
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(636)){
C_save(t1);
C_rereclaim2(636*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,149);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033chicken-bug-report.~a-~a-~a");
lf[3]=C_decode_literal(C_heaptop,"\376B\000\000Ochicken-janitors@nongnu.org\012chicken-hackers@nongnu.org\012chicken-users@nongnu"
".org");
lf[5]=C_decode_literal(C_heaptop,"\376B\000\000\033chicken-janitors@nongnu.org");
lf[7]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\014mx10.gnu.org\376\003\000\000\002\376B\000\000\014mx20.gnu.org\376\377\016");
lf[8]=C_h_intern(&lf[8],12,"collect-info");
lf[9]=C_h_intern(&lf[9],7,"newline");
lf[10]=C_h_intern(&lf[10],7,"display");
lf[11]=C_h_intern(&lf[11],8,"read-all");
lf[12]=C_h_intern(&lf[12],20,"with-input-from-pipe");
lf[13]=C_decode_literal(C_heaptop,"\376B\000\000\013gcc -v 2>&1");
lf[14]=C_h_intern(&lf[14],5,"print");
lf[15]=C_decode_literal(C_heaptop,"\376B\000\0000CC seems to be gcc, trying to obtain version...\012");
lf[16]=C_decode_literal(C_heaptop,"\376B\000\000\003gcc");
lf[17]=C_h_intern(&lf[17],8,"feature\077");
lf[18]=C_h_intern(&lf[18],4,"unix");
lf[19]=C_h_intern(&lf[19],17,"\003syspeek-c-string");
lf[20]=C_h_intern(&lf[20],20,"with-input-from-file");
lf[21]=C_h_intern(&lf[21],13,"make-pathname");
lf[22]=C_decode_literal(C_heaptop,"\376B\000\000\020chicken-config.h");
lf[23]=C_decode_literal(C_heaptop,"\376B\000\000\024\012\012chicken-config.h:\012");
lf[24]=C_h_intern(&lf[24],6,"printf");
lf[25]=C_decode_literal(C_heaptop,"\376B\000\000\004~a~a");
lf[26]=C_h_intern(&lf[26],11,"make-string");
lf[27]=C_h_intern(&lf[27],12,"\003sysfor-each");
lf[28]=C_decode_literal(C_heaptop,"\376B\000\000\003\012  ");
lf[29]=C_h_intern(&lf[29],4,"chop");
lf[30]=C_h_intern(&lf[30],4,"sort");
lf[31]=C_h_intern(&lf[31],8,"string<\077");
lf[32]=C_h_intern(&lf[32],7,"\003sysmap");
lf[33]=C_h_intern(&lf[33],15,"keyword->string");
lf[34]=C_h_intern(&lf[34],12,"\003sysfeatures");
lf[35]=C_decode_literal(C_heaptop,"\376B\000\000\011Features:");
lf[36]=C_decode_literal(C_heaptop,"\376B\000\000\024Include path:\011~s~%~%");
lf[37]=C_h_intern(&lf[37],21,"\003sysinclude-pathnames");
lf[38]=C_decode_literal(C_heaptop,"\376B\000\000\020Home directory:\011");
lf[39]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[40]=C_h_intern(&lf[40],12,"chicken-home");
lf[41]=C_decode_literal(C_heaptop,"\376B\000\000\024CHICKEN version is:\012");
lf[42]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[43]=C_h_intern(&lf[43],15,"chicken-version");
lf[44]=C_decode_literal(C_heaptop,"\376B\000\000\021\011build platform:\011");
lf[45]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[46]=C_h_intern(&lf[46],14,"build-platform");
lf[47]=C_decode_literal(C_heaptop,"\376B\000\000\023\011software version:\011");
lf[48]=C_h_intern(&lf[48],16,"software-version");
lf[49]=C_decode_literal(C_heaptop,"\376B\000\000\020\011software type:\011");
lf[50]=C_h_intern(&lf[50],13,"software-type");
lf[51]=C_decode_literal(C_heaptop,"\376B\000\000\017\011machine type:\011");
lf[52]=C_h_intern(&lf[52],12,"machine-type");
lf[53]=C_decode_literal(C_heaptop,"\376B\000\000\022Host information:\012");
lf[54]=C_decode_literal(C_heaptop,"\376B\000\000\030User information:\011~s~%~%");
lf[55]=C_h_intern(&lf[55],16,"user-information");
lf[56]=C_h_intern(&lf[56],15,"current-user-id");
lf[57]=C_decode_literal(C_heaptop,"\376B\000\000\006Date:\011");
lf[58]=C_decode_literal(C_heaptop,"\376B\000\000\002\012\012");
lf[59]=C_h_intern(&lf[59],15,"seconds->string");
lf[60]=C_h_intern(&lf[60],15,"current-seconds");
lf[61]=C_decode_literal(C_heaptop,"\376B\000\0002This is a bug report generated by chicken-bug(1).\012");
lf[62]=C_decode_literal(C_heaptop,"\376B\000\0004\012--------------------------------------------------\012");
lf[63]=C_h_intern(&lf[63],5,"usage");
lf[64]=C_h_intern(&lf[64],4,"exit");
lf[65]=C_decode_literal(C_heaptop,"\376B\000\0017usage: chicken-bug [FILENAME ...]\012\012  -help  -h            show this message"
"\012  -to-stdout           write bug report to standard output\012  -                 "
"   read description from standard input\012\012Generates a bug report file from user i"
"nput or alternatively\012from the contents of files given on the command line.\012");
lf[66]=C_h_intern(&lf[66],10,"user-input");
lf[67]=C_decode_literal(C_heaptop,"\376B\000\001VThis is the CHICKEN bug report generator. Please enter a detailed\012descripti"
"on of the problem you have encountered and enter CTRL-D (EOF)\012once you have fini"
"shed. Press CTRL-C to abort the program. You can\012also pass the description from "
"a file (just abort now and re-invoke\012\042chicken-bug\042 with one or more input files "
"given on the command-line)\012");
lf[68]=C_h_intern(&lf[68],13,"\003systty-port\077");
lf[69]=C_h_intern(&lf[69],18,"current-input-port");
lf[70]=C_h_intern(&lf[70],7,"justify");
lf[71]=C_h_intern(&lf[71],13,"string-append");
lf[72]=C_decode_literal(C_heaptop,"\376B\000\000\0010");
lf[73]=C_h_intern(&lf[73],4,"main");
lf[74]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[75]=C_h_intern(&lf[75],8,"try-mail");
lf[76]=C_h_intern(&lf[76],21,"with-output-to-string");
lf[77]=C_h_intern(&lf[77],12,"mail-headers");
lf[78]=C_h_intern(&lf[78],7,"sprintf");
lf[79]=C_h_intern(&lf[79],15,"\003sysmatch-error");
lf[80]=C_h_intern(&lf[80],19,"seconds->local-time");
lf[81]=C_decode_literal(C_heaptop,"\376B\000\000\002\012\012");
lf[82]=C_decode_literal(C_heaptop,"\376B\000\000\001-");
lf[83]=C_decode_literal(C_heaptop,"\376B\000\000\017\012\012User input:\012\012");
lf[84]=C_decode_literal(C_heaptop,"\376B\000\000\006--help");
lf[85]=C_decode_literal(C_heaptop,"\376B\000\000\002-h");
lf[86]=C_decode_literal(C_heaptop,"\376B\000\000\005-help");
lf[87]=C_decode_literal(C_heaptop,"\376B\000\000\012-to-stdout");
lf[88]=C_decode_literal(C_heaptop,"\376B\000\000\016\012\012File added: ");
lf[89]=C_decode_literal(C_heaptop,"\376B\000\000\002\012\012");
lf[90]=C_decode_literal(C_heaptop,"\376B\000\000!one of the following addresses:\012\012");
lf[91]=C_decode_literal(C_heaptop,"\376B\000\000G\012Could not send mail automatically!\012\012A bug report has been written to `");
lf[92]=C_decode_literal(C_heaptop,"\376B\000\000\025\047.  Please send it to");
lf[93]=C_h_intern(&lf[93],19,"with-output-to-file");
lf[94]=C_h_intern(&lf[94],9,"send-mail");
lf[95]=C_h_intern(&lf[95],13,"mail-date-str");
lf[96]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[97]=C_decode_literal(C_heaptop,"\376B\000\000\001:");
lf[98]=C_decode_literal(C_heaptop,"\376B\000\000\001:");
lf[99]=C_decode_literal(C_heaptop,"\376B\000\000\006 +0000");
lf[100]=C_h_intern(&lf[100],10,"string-pad");
lf[101]=C_decode_literal(C_heaptop,"\376B\000\000\005 Jan ");
lf[102]=C_decode_literal(C_heaptop,"\376B\000\000\005 Feb ");
lf[103]=C_decode_literal(C_heaptop,"\376B\000\000\005 Mar ");
lf[104]=C_decode_literal(C_heaptop,"\376B\000\000\005 Apr ");
lf[105]=C_decode_literal(C_heaptop,"\376B\000\000\005 May ");
lf[106]=C_decode_literal(C_heaptop,"\376B\000\000\005 Jun ");
lf[107]=C_decode_literal(C_heaptop,"\376B\000\000\005 Jul ");
lf[108]=C_decode_literal(C_heaptop,"\376B\000\000\005 Aug ");
lf[109]=C_decode_literal(C_heaptop,"\376B\000\000\005 Sep ");
lf[110]=C_decode_literal(C_heaptop,"\376B\000\000\005 Oct ");
lf[111]=C_decode_literal(C_heaptop,"\376B\000\000\005 Nov ");
lf[112]=C_decode_literal(C_heaptop,"\376B\000\000\005 Dec ");
lf[113]=C_decode_literal(C_heaptop,"\376B\000\000\005Sun, ");
lf[114]=C_decode_literal(C_heaptop,"\376B\000\000\005Mon, ");
lf[115]=C_decode_literal(C_heaptop,"\376B\000\000\005Tue, ");
lf[116]=C_decode_literal(C_heaptop,"\376B\000\000\005Wed, ");
lf[117]=C_decode_literal(C_heaptop,"\376B\000\000\005Thu, ");
lf[118]=C_decode_literal(C_heaptop,"\376B\000\000\005Fri, ");
lf[119]=C_decode_literal(C_heaptop,"\376B\000\000\005Sat, ");
lf[120]=C_decode_literal(C_heaptop,"\376B\000\000\006Date: ");
lf[121]=C_decode_literal(C_heaptop,"\376B\000\000\002\015\012");
lf[122]=C_decode_literal(C_heaptop,"\376B\000\000;From: \042chicken-bug user\042 <chicken-bug-command@callcc.org>\015\012");
lf[123]=C_decode_literal(C_heaptop,"\376B\000\0006To: \042Chicken Janitors\042 <chicken-janitors@nongnu.org>\015\012");
lf[124]=C_decode_literal(C_heaptop,"\376B\000\000)Subject: Automated chicken-bug output -- ");
lf[125]=C_h_intern(&lf[125],17,"seconds->utc-time");
lf[126]=C_h_intern(&lf[126],9,"mail-read");
lf[127]=C_h_intern(&lf[127],9,"substring");
lf[128]=C_h_intern(&lf[128],9,"condition");
lf[129]=C_h_intern(&lf[129],17,"close-output-port");
lf[130]=C_h_intern(&lf[130],16,"close-input-port");
lf[131]=C_h_intern(&lf[131],9,"read-line");
lf[132]=C_h_intern(&lf[132],22,"with-exception-handler");
lf[133]=C_h_intern(&lf[133],30,"call-with-current-continuation");
lf[134]=C_h_intern(&lf[134],10,"mail-write");
lf[135]=C_h_intern(&lf[135],10,"mail-check");
lf[136]=C_h_intern(&lf[136],11,"tcp-connect");
lf[137]=C_decode_literal(C_heaptop,"\376B\000\000QBug report successfully mailed to the Chicken maintainers.\012Thank you very m"
"uch!\012\012");
lf[138]=C_decode_literal(C_heaptop,"\376B\000\000\004QUIT");
lf[139]=C_decode_literal(C_heaptop,"\376B\000\000\004\015\012\015\012");
lf[140]=C_decode_literal(C_heaptop,"\376B\000\000\005\015\012.\015\012");
lf[141]=C_decode_literal(C_heaptop,"\376B\000\000\006DATA\015\012");
lf[142]=C_decode_literal(C_heaptop,"\376B\000\000\047RCPT TO:<chicken-janitors@nongnu.org>\015\012");
lf[143]=C_decode_literal(C_heaptop,"\376B\000\000,MAIL FROM:<chicken-bug-command@callcc.org>\015\012");
lf[144]=C_decode_literal(C_heaptop,"\376B\000\000\021HELO callcc.org\015\012");
lf[145]=C_decode_literal(C_heaptop,"\376B\000\000\016connecting to ");
lf[146]=C_decode_literal(C_heaptop,"\376B\000\000\004 ...");
lf[147]=C_h_intern(&lf[147],25,"\003sysimplicit-exit-handler");
lf[148]=C_h_intern(&lf[148],22,"command-line-arguments");
C_register_lf2(lf,149,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_152,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k150 */
static void C_ccall f_152(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_152,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_155,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k153 in k150 */
static void C_ccall f_155(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_155,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_158,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k156 in k153 in k150 */
static void C_ccall f_158(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_158,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_161,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k159 in k156 in k153 in k150 */
static void C_ccall f_161(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_161,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_164,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_164(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_164,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_167,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_13_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_167(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_167,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_170,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_posix_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_170(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_170,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_173,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_tcp_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_173(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_173,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_176,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_176(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_176,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_179,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_utils_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_179(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_179,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_182,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_182(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word ab[30],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_182,2,t0,t1);}
t2=C_mutate(&lf[0],lf[1]);
t3=C_mutate(&lf[2],lf[3]);
t4=C_mutate(&lf[4],lf[5]);
t5=C_mutate(&lf[6],lf[7]);
t6=C_mutate((C_word*)lf[8]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_188,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate((C_word*)lf[63]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_378,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate((C_word*)lf[66]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_387,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate((C_word*)lf[70]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_406,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate((C_word*)lf[73]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_425,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate((C_word*)lf[75]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_568,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate((C_word*)lf[95]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_609,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate((C_word*)lf[77]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_797,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate((C_word*)lf[126]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_815,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate((C_word*)lf[134]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_901,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate((C_word*)lf[135]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_970,tmp=(C_word)a,a+=2,tmp));
t17=C_mutate((C_word*)lf[94]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_991,tmp=(C_word)a,a+=2,tmp));
t18=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1074,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t19=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1084,a[2]=t18,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 262  command-line-arguments */
t20=C_retrieve(lf[148]);
((C_proc2)C_retrieve_proc(t20))(2,t20,t19);}

/* k1082 in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_1084(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 262  main */
t2=*((C_word*)lf[73]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1072 in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_1074(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1074,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1077,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1080,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#implicit-exit-handler */
t4=C_retrieve(lf[147]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k1078 in k1072 in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_1080(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k1075 in k1072 in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_1077(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* send-mail in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_991(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_991,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_995,a[2]=t1,a[3]=t3,a[4]=t5,a[5]=t4,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* chicken-bug.scm: 245  print */
t7=*((C_word*)lf[14]+1);
((C_proc5)C_retrieve_proc(t7))(5,t7,t6,lf[145],t2,lf[146]);}

/* k993 in send-mail in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_995(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_995,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1000,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1006,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* chicken-bug.scm: 246  ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a1005 in k993 in send-mail in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_1006(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1006,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1012,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* chicken-bug.scm: 248  call-with-current-continuation */
t5=*((C_word*)lf[133]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t1,t4);}

/* a1011 in a1005 in k993 in send-mail in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_1012(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1012,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1016,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1071,a[2]=t2,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[5],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* chicken-bug.scm: 250  mail-read */
t5=*((C_word*)lf[126]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[5],((C_word*)t0)[6]);}

/* k1069 in a1011 in a1005 in k993 in send-mail in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_1071(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 250  mail-check */
t2=*((C_word*)lf[135]+1);
((C_proc7)C_retrieve_proc(t2))(7,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,C_fix(220),((C_word*)t0)[2]);}

/* k1014 in a1011 in a1005 in k993 in send-mail in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_1016(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1016,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1019,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1067,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[6],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken-bug.scm: 251  mail-write */
t4=*((C_word*)lf[134]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[6],((C_word*)t0)[7],lf[144]);}

/* k1065 in k1014 in a1011 in a1005 in k993 in send-mail in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_1067(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 251  mail-check */
t2=*((C_word*)lf[135]+1);
((C_proc7)C_retrieve_proc(t2))(7,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,C_fix(250),((C_word*)t0)[2]);}

/* k1017 in k1014 in a1011 in a1005 in k993 in send-mail in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_1019(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1019,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1022,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1063,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[6],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken-bug.scm: 252  mail-write */
t4=*((C_word*)lf[134]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[6],((C_word*)t0)[7],lf[143]);}

/* k1061 in k1017 in k1014 in a1011 in a1005 in k993 in send-mail in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_1063(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 252  mail-check */
t2=*((C_word*)lf[135]+1);
((C_proc7)C_retrieve_proc(t2))(7,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,C_fix(250),((C_word*)t0)[2]);}

/* k1020 in k1017 in k1014 in a1011 in a1005 in k993 in send-mail in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_1022(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1022,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1025,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1059,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[6],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken-bug.scm: 253  mail-write */
t4=*((C_word*)lf[134]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[6],((C_word*)t0)[7],lf[142]);}

/* k1057 in k1020 in k1017 in k1014 in a1011 in a1005 in k993 in send-mail in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_1059(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 253  mail-check */
t2=*((C_word*)lf[135]+1);
((C_proc7)C_retrieve_proc(t2))(7,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,C_fix(250),((C_word*)t0)[2]);}

/* k1023 in k1020 in k1017 in k1014 in a1011 in a1005 in k993 in send-mail in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_1025(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1025,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1028,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1055,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[6],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken-bug.scm: 254  mail-write */
t4=*((C_word*)lf[134]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[6],((C_word*)t0)[7],lf[141]);}

/* k1053 in k1023 in k1020 in k1017 in k1014 in a1011 in a1005 in k993 in send-mail in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_1055(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 254  mail-check */
t2=*((C_word*)lf[135]+1);
((C_proc7)C_retrieve_proc(t2))(7,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,C_fix(354),((C_word*)t0)[2]);}

/* k1026 in k1023 in k1020 in k1017 in k1014 in a1011 in a1005 in k993 in send-mail in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_1028(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1028,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1031,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1047,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[6],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1051,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[6],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* chicken-bug.scm: 255  string-append */
t5=*((C_word*)lf[71]+1);
((C_proc7)C_retrieve_proc(t5))(7,t5,t4,((C_word*)t0)[4],((C_word*)t0)[3],lf[139],((C_word*)t0)[2],lf[140]);}

/* k1049 in k1026 in k1023 in k1020 in k1017 in k1014 in a1011 in a1005 in k993 in send-mail in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_1051(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 255  mail-write */
t2=*((C_word*)lf[134]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1045 in k1026 in k1023 in k1020 in k1017 in k1014 in a1011 in a1005 in k993 in send-mail in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_1047(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 255  mail-check */
t2=*((C_word*)lf[135]+1);
((C_proc7)C_retrieve_proc(t2))(7,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,C_fix(250),((C_word*)t0)[2]);}

/* k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in a1011 in a1005 in k993 in send-mail in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_1031(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1031,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1034,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken-bug.scm: 256  display */
t3=*((C_word*)lf[10]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[138],((C_word*)t0)[3]);}

/* k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in a1011 in a1005 in k993 in send-mail in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_1034(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1034,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1037,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* chicken-bug.scm: 257  close-input-port */
t3=*((C_word*)lf[130]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in a1011 in a1005 in k993 in send-mail in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_1037(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1037,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1040,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 258  close-output-port */
t3=*((C_word*)lf[129]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in a1011 in a1005 in k993 in send-mail in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_1040(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1040,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1043,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 259  print */
t3=*((C_word*)lf[14]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[137]);}

/* k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in a1011 in a1005 in k993 in send-mail in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_1043(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* a999 in k993 in send-mail in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_1000(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1000,2,t0,t1);}
/* chicken-bug.scm: 247  tcp-connect */
t2=C_retrieve(lf[136]);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,((C_word*)t0)[2],C_fix(25));}

/* mail-check in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_970(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word ab[5],*a=ab;
if(c!=7) C_bad_argc_2(c,7,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr7,(void*)f_970,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(C_truep(t4)?(C_word)C_i_nequalp(t4,t5):C_SCHEME_FALSE);
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_TRUE);}
else{
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_980,a[2]=t3,a[3]=t1,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
/* chicken-bug.scm: 240  close-input-port */
t9=*((C_word*)lf[130]+1);
((C_proc3)C_retrieve_proc(t9))(3,t9,t8,t2);}}

/* k978 in mail-check in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_980(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_980,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_983,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* chicken-bug.scm: 241  close-output-port */
t3=*((C_word*)lf[129]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k981 in k978 in mail-check in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_983(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 242  k */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* mail-write in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_901(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_901,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_905,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_914,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_916,a[2]=t4,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* chicken-bug.scm: 230  call-with-current-continuation */
t8=*((C_word*)lf[133]+1);
((C_proc3)C_retrieve_proc(t8))(3,t8,t6,t7);}

/* a915 in mail-write in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_916(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_916,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_922,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_946,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* chicken-bug.scm: 230  with-exception-handler */
t5=C_retrieve(lf[132]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t3,t4);}

/* a945 in a915 in mail-write in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_946(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_946,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_952,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_958,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 230  ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a957 in a945 in a915 in mail-write in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_958(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_958r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_958r(t0,t1,t2);}}

static void C_ccall f_958r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_964,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 230  g84 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a963 in a957 in a945 in a915 in mail-write in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_964(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_964,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a951 in a945 in a915 in mail-write in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_952(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_952,2,t0,t1);}
/* chicken-bug.scm: 230  display */
t2=*((C_word*)lf[10]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a921 in a915 in mail-write in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_922(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_922,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_928,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-bug.scm: 230  g84 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a927 in a921 in a915 in mail-write in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_928(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_928,2,t0,t1);}
t2=(C_word)C_i_structurep(((C_word*)t0)[4],lf[128]);
t3=(C_truep(t2)?(C_word)C_slot(((C_word*)t0)[4],C_fix(1)):C_SCHEME_FALSE);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_935,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-bug.scm: 231  close-input-port */
t5=*((C_word*)lf[130]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[2]);}

/* k933 in a927 in a921 in a915 in mail-write in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_935(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_935,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_938,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 231  close-output-port */
t3=*((C_word*)lf[129]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k936 in k933 in a927 in a921 in a915 in mail-write in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_938(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* k912 in mail-write in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_914(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k903 in mail-write in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_905(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* chicken-bug.scm: 233  mail-read */
t2=*((C_word*)lf[126]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* mail-read in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_815(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_815,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_819,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_845,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_847,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* chicken-bug.scm: 221  call-with-current-continuation */
t7=*((C_word*)lf[133]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,t5,t6);}

/* a846 in mail-read in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_847(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_847,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_853,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_877,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken-bug.scm: 221  with-exception-handler */
t5=C_retrieve(lf[132]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t3,t4);}

/* a876 in a846 in mail-read in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_877(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_877,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_883,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_889,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 221  ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a888 in a876 in a846 in mail-read in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_889(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_889r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_889r(t0,t1,t2);}}

static void C_ccall f_889r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_895,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 221  g69 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a894 in a888 in a876 in a846 in mail-read in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_895(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_895,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a882 in a876 in a846 in mail-read in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_883(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_883,2,t0,t1);}
/* chicken-bug.scm: 221  read-line */
t2=C_retrieve(lf[131]);
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* a852 in a846 in mail-read in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_853(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_853,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_859,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-bug.scm: 221  g69 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a858 in a852 in a846 in mail-read in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_859(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_859,2,t0,t1);}
t2=(C_word)C_i_structurep(((C_word*)t0)[4],lf[128]);
t3=(C_truep(t2)?(C_word)C_slot(((C_word*)t0)[4],C_fix(1)):C_SCHEME_FALSE);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_866,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-bug.scm: 222  close-input-port */
t5=*((C_word*)lf[130]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[2]);}

/* k864 in a858 in a852 in a846 in mail-read in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_866(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_866,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_869,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 222  close-output-port */
t3=*((C_word*)lf[129]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k867 in k864 in a858 in a852 in a846 in mail-read in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_869(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* k843 in mail-read in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_845(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k817 in mail-read in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_819(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_819,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_string_ref(t1,C_fix(0));
if(C_truep((C_word)C_u_i_char_numericp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_835,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 225  substring */
t4=*((C_word*)lf[127]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,t1,C_fix(0),C_fix(3));}
else{
/* chicken-bug.scm: 226  mail-read */
t3=*((C_word*)lf[126]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k833 in k817 in mail-read in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_835(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 225  string->number */
C_string_to_number(3,0,((C_word*)t0)[2],t1);}

/* mail-headers in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_797(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_797,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_805,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_809,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_813,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 215  current-seconds */
t5=C_retrieve(lf[60]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k811 in mail-headers in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_813(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 215  seconds->utc-time */
t2=C_retrieve(lf[125]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k807 in mail-headers in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_809(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 215  mail-date-str */
t2=*((C_word*)lf[95]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k803 in mail-headers in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_805(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 214  string-append */
t2=*((C_word*)lf[71]+1);
((C_proc8)C_retrieve_proc(t2))(8,t2,((C_word*)t0)[2],lf[120],t1,lf[121],lf[122],lf[123],lf[124]);}

/* mail-date-str in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_609(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_609,3,t0,t1,t2);}
t3=(C_word)C_i_vector_ref(t2,C_fix(6));
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_620,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
switch(t3){
case C_fix(0):
t5=t4;
f_620(t5,lf[113]);
case C_fix(1):
t5=t4;
f_620(t5,lf[114]);
case C_fix(2):
t5=t4;
f_620(t5,lf[115]);
case C_fix(3):
t5=t4;
f_620(t5,lf[116]);
case C_fix(4):
t5=t4;
f_620(t5,lf[117]);
case C_fix(5):
t5=t4;
f_620(t5,lf[118]);
default:
t5=(C_word)C_eqp(t3,C_fix(6));
t6=t4;
f_620(t6,(C_truep(t5)?lf[119]:C_SCHEME_UNDEFINED));}}

/* k618 in mail-date-str in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_fcall f_620(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_620,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_624,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_752,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_vector_ref(((C_word*)t0)[3],C_fix(3));
/* chicken-bug.scm: 190  number->string */
C_number_to_string(3,0,t3,t4);}

/* k750 in k618 in mail-date-str in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_752(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 190  string-pad */
t2=C_retrieve(lf[100]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],t1,C_fix(2),C_make_character(48));}

/* k622 in k618 in mail-date-str in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_624(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_624,2,t0,t1);}
t2=(C_word)C_i_vector_ref(((C_word*)t0)[4],C_fix(4));
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_631,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
switch(t2){
case C_fix(0):
t4=t3;
f_631(t4,lf[101]);
case C_fix(1):
t4=t3;
f_631(t4,lf[102]);
case C_fix(2):
t4=t3;
f_631(t4,lf[103]);
case C_fix(3):
t4=t3;
f_631(t4,lf[104]);
case C_fix(4):
t4=t3;
f_631(t4,lf[105]);
case C_fix(5):
t4=t3;
f_631(t4,lf[106]);
case C_fix(6):
t4=t3;
f_631(t4,lf[107]);
case C_fix(7):
t4=t3;
f_631(t4,lf[108]);
case C_fix(8):
t4=t3;
f_631(t4,lf[109]);
case C_fix(9):
t4=t3;
f_631(t4,lf[110]);
case C_fix(10):
t4=t3;
f_631(t4,lf[111]);
default:
t4=(C_word)C_eqp(t2,C_fix(11));
t5=t3;
f_631(t5,(C_truep(t4)?lf[112]:C_SCHEME_UNDEFINED));}}

/* k629 in k622 in k618 in mail-date-str in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_fcall f_631(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_631,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_635,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_vector_ref(((C_word*)t0)[2],C_fix(5));
t4=(C_word)C_a_i_plus(&a,2,C_fix(1900),t3);
/* chicken-bug.scm: 204  number->string */
C_number_to_string(3,0,t2,t4);}

/* k633 in k629 in k622 in k618 in mail-date-str in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_635(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_635,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_639,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_667,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_vector_ref(((C_word*)t0)[2],C_fix(2));
/* chicken-bug.scm: 206  number->string */
C_number_to_string(3,0,t3,t4);}

/* k665 in k633 in k629 in k622 in k618 in mail-date-str in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_667(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 206  string-pad */
t2=C_retrieve(lf[100]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],t1,C_fix(2),C_make_character(48));}

/* k637 in k633 in k629 in k622 in k618 in mail-date-str in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_639(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_639,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_643,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_659,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_vector_ref(((C_word*)t0)[2],C_fix(1));
/* chicken-bug.scm: 208  number->string */
C_number_to_string(3,0,t3,t4);}

/* k657 in k637 in k633 in k629 in k622 in k618 in mail-date-str in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_659(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 208  string-pad */
t2=C_retrieve(lf[100]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],t1,C_fix(2),C_make_character(48));}

/* k641 in k637 in k633 in k629 in k622 in k618 in mail-date-str in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_643(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_643,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_647,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_651,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_vector_ref(((C_word*)t0)[2],C_fix(0));
/* chicken-bug.scm: 210  number->string */
C_number_to_string(3,0,t3,t4);}

/* k649 in k641 in k637 in k633 in k629 in k622 in k618 in mail-date-str in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_651(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 210  string-pad */
t2=C_retrieve(lf[100]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],t1,C_fix(2),C_make_character(48));}

/* k645 in k641 in k637 in k633 in k629 in k622 in k618 in mail-date-str in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_647(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 181  string-append */
t2=*((C_word*)lf[71]+1);
((C_proc13)C_retrieve_proc(t2))(13,t2,((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],lf[96],((C_word*)t0)[3],lf[97],((C_word*)t0)[2],lf[98],t1,lf[99]);}

/* try-mail in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_568(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[14],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_568,6,t0,t1,t2,t3,t4,t5);}
if(C_truep((C_word)C_i_nullp(t2))){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_578,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_586,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 173  with-output-to-file */
t8=C_retrieve(lf[93]);
((C_proc4)C_retrieve_proc(t8))(4,t8,t6,t3,t7);}
else{
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_593,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t7=(C_word)C_i_car(t2);
/* chicken-bug.scm: 177  send-mail */
t8=*((C_word*)lf[94]+1);
((C_proc6)C_retrieve_proc(t8))(6,t8,t6,t7,t5,t4,t3);}}

/* k591 in try-mail in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_593(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* chicken-bug.scm: 178  try-mail */
t3=*((C_word*)lf[75]+1);
((C_proc6)C_retrieve_proc(t3))(6,t3,((C_word*)t0)[6],t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* a585 in try-mail in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_586(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_586,2,t0,t1);}
/* chicken-bug.scm: 174  print */
t2=*((C_word*)lf[14]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* k576 in try-mail in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_578(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_578,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_581,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 175  print */
t3=*((C_word*)lf[14]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[91],((C_word*)t0)[2],lf[92]);}

/* k579 in k576 in try-mail in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_581(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 176  print */
t2=*((C_word*)lf[14]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[90],lf[3]);}

/* main in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_425(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[17],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_425,3,t0,t1,t2);}
t3=lf[74];
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_FALSE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_429,a[2]=t6,a[3]=t4,a[4]=t1,a[5]=t8,tmp=(C_word)a,a+=6,tmp);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_525,a[2]=t8,a[3]=t4,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
/* for-each */
t11=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t9,t10,t2);}

/* a524 in main in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_525(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[17],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_525,3,t0,t1,t2);}
if(C_truep((C_word)C_i_string_equal_p(lf[82],t2))){
t3=C_set_block_item(((C_word*)t0)[4],0,C_SCHEME_TRUE);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_537,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_541,a[2]=((C_word*)t0)[3],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* chicken-bug.scm: 130  user-input */
t6=*((C_word*)lf[66]+1);
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}
else{
t3=t2;
if(C_truep((C_truep((C_word)C_i_equalp(t3,lf[84]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t3,lf[85]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t3,lf[86]))?C_SCHEME_TRUE:C_SCHEME_FALSE))))){
/* chicken-bug.scm: 132  usage */
t4=*((C_word*)lf[63]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,C_fix(0));}
else{
if(C_truep((C_word)C_i_string_equal_p(lf[87],t2))){
t4=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_TRUE);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=C_set_block_item(((C_word*)t0)[4],0,C_SCHEME_TRUE);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_562,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_566,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* chicken-bug.scm: 141  read-all */
t7=C_retrieve(lf[11]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t2);}}}}

/* k564 in a524 in main in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_566(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 138  string-append */
t2=*((C_word*)lf[71]+1);
((C_proc7)C_retrieve_proc(t2))(7,t2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1],lf[88],((C_word*)t0)[2],lf[89],t1);}

/* k560 in a524 in main in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_562(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k539 in a524 in main in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_541(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 130  string-append */
t2=*((C_word*)lf[71]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],lf[83],t1);}

/* k535 in a524 in main in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_537(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k427 in main in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_429(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_429,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_432,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=t2;
f_432(t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_519,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_523,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* chicken-bug.scm: 144  user-input */
t5=*((C_word*)lf[66]+1);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}}

/* k521 in k427 in main in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_523(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 144  string-append */
t2=*((C_word*)lf[71]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],lf[81],t1);}

/* k517 in k427 in main in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_519(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_432(t3,t2);}

/* k430 in k427 in main in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_fcall f_432(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_432,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_435,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken-bug.scm: 145  newline */
t3=*((C_word*)lf[9]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k433 in k430 in k427 in main in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_435(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_435,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_438,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_515,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 146  current-seconds */
t4=C_retrieve(lf[60]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k513 in k433 in k430 in k427 in main in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_515(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 146  seconds->local-time */
t2=C_retrieve(lf[80]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k436 in k433 in k430 in k427 in main in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_438(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_438,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_444,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_vectorp(t1))){
t3=(C_word)C_i_vector_length(t1);
t4=t2;
f_444(t4,(C_word)C_eqp(t3,C_fix(10)));}
else{
t3=t2;
f_444(t3,C_SCHEME_FALSE);}}

/* k442 in k436 in k433 in k430 in k427 in main in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_fcall f_444(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_444,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_vector_ref(((C_word*)t0)[5],C_fix(3));
t3=(C_word)C_i_vector_ref(((C_word*)t0)[5],C_fix(4));
t4=(C_word)C_i_vector_ref(((C_word*)t0)[5],C_fix(5));
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_459,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 149  print */
t6=*((C_word*)lf[14]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)((C_word*)t0)[2])[1]);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_469,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_a_i_plus(&a,2,C_fix(1900),t4);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_494,a[2]=t2,a[3]=t6,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* chicken-bug.scm: 153  justify */
t8=*((C_word*)lf[70]+1);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t3);}}
else{
/* chicken-bug.scm: 146  ##sys#match-error */
t2=*((C_word*)lf[79]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[5]);}}

/* k492 in k442 in k436 in k433 in k430 in k427 in main in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_494(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_494,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_498,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken-bug.scm: 153  justify */
t3=*((C_word*)lf[70]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k496 in k492 in k442 in k436 in k433 in k430 in k427 in main in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_498(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 153  sprintf */
t2=C_retrieve(lf[78]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[4],lf[1],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k467 in k442 in k436 in k433 in k430 in k427 in main in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_469(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_469,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_473,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* chicken-bug.scm: 154  mail-headers */
t3=*((C_word*)lf[77]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k471 in k467 in k442 in k436 in k433 in k430 in k427 in main in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_473(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_473,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_477,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_479,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 155  with-output-to-string */
t4=C_retrieve(lf[76]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}

/* a478 in k471 in k467 in k442 in k436 in k433 in k430 in k427 in main in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_479(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_479,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_483,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 157  print */
t3=*((C_word*)lf[14]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* k481 in a478 in k471 in k467 in k442 in k436 in k433 in k430 in k427 in main in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_483(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 158  collect-info */
t2=*((C_word*)lf[8]+1);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k475 in k471 in k467 in k442 in k436 in k433 in k430 in k427 in main in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_477(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 151  try-mail */
t2=*((C_word*)lf[75]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[4],lf[7],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k457 in k442 in k436 in k433 in k430 in k427 in main in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_459(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 150  collect-info */
t2=*((C_word*)lf[8]+1);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* justify in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_406(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_406,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_410,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 117  number->string */
C_number_to_string(3,0,t3,t2);}

/* k408 in justify in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_410(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_string_length(t1);
if(C_truep((C_word)C_i_greaterp(t2,C_fix(1)))){
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}
else{
/* chicken-bug.scm: 120  string-append */
t3=*((C_word*)lf[71]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[2],lf[72],t1);}}

/* user-input in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_387(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_387,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_391,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_397,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_404,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 104  current-input-port */
t5=*((C_word*)lf[69]+1);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k402 in user-input in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_404(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 104  ##sys#tty-port? */
t2=C_retrieve(lf[68]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k395 in user-input in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_397(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* chicken-bug.scm: 105  print */
t2=*((C_word*)lf[14]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[67]);}
else{
t2=((C_word*)t0)[2];
f_391(2,t2,C_SCHEME_UNDEFINED);}}

/* k389 in user-input in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_391(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 114  read-all */
t2=C_retrieve(lf[11]);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* usage in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_378(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_378,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_382,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-bug.scm: 89   print */
t4=*((C_word*)lf[14]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[65]);}

/* k380 in usage in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_382(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 101  exit */
t2=C_retrieve(lf[64]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* collect-info in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_188(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_188,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_192,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 55   print */
t3=*((C_word*)lf[14]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[62]);}

/* k190 in collect-info in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_192(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_192,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_195,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 56   print */
t3=*((C_word*)lf[14]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[61]);}

/* k193 in k190 in collect-info in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_195(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_195,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_198,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_372,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_376,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 57   current-seconds */
t5=C_retrieve(lf[60]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k374 in k193 in k190 in collect-info in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_376(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 57   seconds->string */
t2=C_retrieve(lf[59]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k370 in k193 in k190 in collect-info in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_372(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 57   print */
t2=*((C_word*)lf[14]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[57],t1,lf[58]);}

/* k196 in k193 in k190 in collect-info in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_198(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_198,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_201,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_364,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_368,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 58   current-user-id */
t5=C_retrieve(lf[56]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k366 in k196 in k193 in k190 in collect-info in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_368(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 58   user-information */
t2=C_retrieve(lf[55]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k362 in k196 in k193 in k190 in collect-info in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_364(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 58   printf */
t2=C_retrieve(lf[24]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[54],t1);}

/* k199 in k196 in k193 in k190 in collect-info in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_201(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_201,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_204,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 59   print */
t3=*((C_word*)lf[14]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[53]);}

/* k202 in k199 in k196 in k193 in k190 in collect-info in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_204(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_204,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_207,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_360,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 60   machine-type */
t4=C_retrieve(lf[52]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k358 in k202 in k199 in k196 in k193 in k190 in collect-info in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_360(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 60   print */
t2=*((C_word*)lf[14]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[51],t1);}

/* k205 in k202 in k199 in k196 in k193 in k190 in collect-info in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_207(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_207,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_210,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_356,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 61   software-type */
t4=C_retrieve(lf[50]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k354 in k205 in k202 in k199 in k196 in k193 in k190 in collect-info in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_356(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 61   print */
t2=*((C_word*)lf[14]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[49],t1);}

/* k208 in k205 in k202 in k199 in k196 in k193 in k190 in collect-info in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_210(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_210,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_213,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_352,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 62   software-version */
t4=C_retrieve(lf[48]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k350 in k208 in k205 in k202 in k199 in k196 in k193 in k190 in collect-info in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_352(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 62   print */
t2=*((C_word*)lf[14]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[47],t1);}

/* k211 in k208 in k205 in k202 in k199 in k196 in k193 in k190 in collect-info in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_213(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_213,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_216,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_348,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 63   build-platform */
t4=C_retrieve(lf[46]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k346 in k211 in k208 in k205 in k202 in k199 in k196 in k193 in k190 in collect-info in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_348(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 63   print */
t2=*((C_word*)lf[14]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[44],t1,lf[45]);}

/* k214 in k211 in k208 in k205 in k202 in k199 in k196 in k193 in k190 in collect-info in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_216(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_216,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_219,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_344,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 64   chicken-version */
t4=C_retrieve(lf[43]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_TRUE);}

/* k342 in k214 in k211 in k208 in k205 in k202 in k199 in k196 in k193 in k190 in collect-info in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_344(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 64   print */
t2=*((C_word*)lf[14]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[41],t1,lf[42]);}

/* k217 in k214 in k211 in k208 in k205 in k202 in k199 in k196 in k193 in k190 in collect-info in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_219(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_219,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_222,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_340,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 65   chicken-home */
t4=C_retrieve(lf[40]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k338 in k217 in k214 in k211 in k208 in k205 in k202 in k199 in k196 in k193 in k190 in collect-info in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_340(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 65   print */
t2=*((C_word*)lf[14]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[38],t1,lf[39]);}

/* k220 in k217 in k214 in k211 in k208 in k205 in k202 in k199 in k196 in k193 in k190 in collect-info in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_222(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_222,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_225,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 66   printf */
t3=C_retrieve(lf[24]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[36],C_retrieve(lf[37]));}

/* k223 in k220 in k217 in k214 in k211 in k208 in k205 in k202 in k199 in k196 in k193 in k190 in collect-info in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_225(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_225,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_228,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 67   print */
t3=*((C_word*)lf[14]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[35]);}

/* k226 in k223 in k220 in k217 in k214 in k211 in k208 in k205 in k202 in k199 in k196 in k193 in k190 in collect-info in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_228(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_228,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_231,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_295,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_328,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_332,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_336,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* map */
t7=*((C_word*)lf[32]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,C_retrieve(lf[33]),C_retrieve(lf[34]));}

/* k334 in k226 in k223 in k220 in k217 in k214 in k211 in k208 in k205 in k202 in k199 in k196 in k193 in k190 in collect-info in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_336(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 75   sort */
t2=C_retrieve(lf[30]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,*((C_word*)lf[31]+1));}

/* k330 in k226 in k223 in k220 in k217 in k214 in k211 in k208 in k205 in k202 in k199 in k196 in k193 in k190 in collect-info in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_332(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 75   chop */
t2=C_retrieve(lf[29]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_fix(5));}

/* k326 in k226 in k223 in k220 in k217 in k214 in k211 in k208 in k205 in k202 in k199 in k196 in k193 in k190 in collect-info in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_328(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a294 in k226 in k223 in k220 in k217 in k214 in k211 in k208 in k205 in k202 in k199 in k196 in k193 in k190 in collect-info in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_295(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_295,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_299,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-bug.scm: 70   display */
t4=*((C_word*)lf[10]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[28]);}

/* k297 in a294 in k226 in k223 in k220 in k217 in k214 in k211 in k208 in k205 in k202 in k199 in k196 in k193 in k190 in collect-info in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_299(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_299,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_304,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t3=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a303 in k297 in a294 in k226 in k223 in k220 in k217 in k214 in k211 in k208 in k205 in k202 in k199 in k196 in k193 in k190 in collect-info in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_304(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_304,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_312,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_string_length(t2);
t5=(C_word)C_fixnum_difference(C_fix(16),t4);
t6=(C_word)C_i_fixnum_max(C_fix(1),t5);
/* chicken-bug.scm: 73   make-string */
t7=*((C_word*)lf[26]+1);
((C_proc4)C_retrieve_proc(t7))(4,t7,t3,t6,C_make_character(32));}

/* k310 in a303 in k297 in a294 in k226 in k223 in k220 in k217 in k214 in k211 in k208 in k205 in k202 in k199 in k196 in k193 in k190 in collect-info in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_312(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 73   printf */
t2=C_retrieve(lf[24]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[25],((C_word*)t0)[2],t1);}

/* k229 in k226 in k223 in k220 in k217 in k214 in k211 in k208 in k205 in k202 in k199 in k196 in k193 in k190 in collect-info in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_231(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_231,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_234,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 76   print */
t3=*((C_word*)lf[14]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[23]);}

/* k232 in k229 in k226 in k223 in k220 in k217 in k214 in k211 in k208 in k205 in k202 in k199 in k196 in k193 in k190 in collect-info in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_234(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_234,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_237,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_279,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_293,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t5=*((C_word*)lf[19]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_INSTALL_INCLUDE_HOME),C_fix(0));}

/* k291 in k232 in k229 in k226 in k223 in k220 in k217 in k214 in k211 in k208 in k205 in k202 in k199 in k196 in k193 in k190 in collect-info in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_293(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 77   make-pathname */
t2=C_retrieve(lf[21]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,lf[22]);}

/* k277 in k232 in k229 in k226 in k223 in k220 in k217 in k214 in k211 in k208 in k205 in k202 in k199 in k196 in k193 in k190 in collect-info in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_279(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_279,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_281,tmp=(C_word)a,a+=2,tmp);
/* chicken-bug.scm: 77   with-input-from-file */
t3=C_retrieve(lf[20]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[2],t1,t2);}

/* a280 in k277 in k232 in k229 in k226 in k223 in k220 in k217 in k214 in k211 in k208 in k205 in k202 in k199 in k196 in k193 in k190 in collect-info in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_281(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_281,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_289,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 79   read-all */
t3=C_retrieve(lf[11]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k287 in a280 in k277 in k232 in k229 in k226 in k223 in k220 in k217 in k214 in k211 in k208 in k205 in k202 in k199 in k196 in k193 in k190 in collect-info in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_289(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 79   display */
t2=*((C_word*)lf[10]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k235 in k232 in k229 in k226 in k223 in k220 in k217 in k214 in k211 in k208 in k205 in k202 in k199 in k196 in k193 in k190 in collect-info in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_237(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_237,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_240,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 80   newline */
t3=*((C_word*)lf[9]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k238 in k235 in k232 in k229 in k226 in k223 in k220 in k217 in k214 in k211 in k208 in k205 in k202 in k199 in k196 in k193 in k190 in collect-info in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_240(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_240,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_243,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_249,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_275,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t5=*((C_word*)lf[19]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_TARGET_CC),C_fix(0));}

/* k273 in k238 in k235 in k232 in k229 in k226 in k223 in k220 in k217 in k214 in k211 in k208 in k205 in k202 in k199 in k196 in k193 in k190 in collect-info in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_275(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_string_equal_p(t1,lf[16]))){
/* chicken-bug.scm: 81   feature? */
t2=C_retrieve(lf[17]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[18]);}
else{
t2=((C_word*)t0)[2];
f_249(2,t2,C_SCHEME_FALSE);}}

/* k247 in k238 in k235 in k232 in k229 in k226 in k223 in k220 in k217 in k214 in k211 in k208 in k205 in k202 in k199 in k196 in k193 in k190 in collect-info in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_249(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_249,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_252,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 82   print */
t3=*((C_word*)lf[14]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[15]);}
else{
t2=((C_word*)t0)[2];
f_243(2,t2,C_SCHEME_UNDEFINED);}}

/* k250 in k247 in k238 in k235 in k232 in k229 in k226 in k223 in k220 in k217 in k214 in k211 in k208 in k205 in k202 in k199 in k196 in k193 in k190 in collect-info in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_252(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_252,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_257,tmp=(C_word)a,a+=2,tmp);
/* chicken-bug.scm: 83   with-input-from-pipe */
t3=C_retrieve(lf[12]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[2],lf[13],t2);}

/* a256 in k250 in k247 in k238 in k235 in k232 in k229 in k226 in k223 in k220 in k217 in k214 in k211 in k208 in k205 in k202 in k199 in k196 in k193 in k190 in collect-info in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_257(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_257,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_265,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 85   read-all */
t3=C_retrieve(lf[11]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k263 in a256 in k250 in k247 in k238 in k235 in k232 in k229 in k226 in k223 in k220 in k217 in k214 in k211 in k208 in k205 in k202 in k199 in k196 in k193 in k190 in collect-info in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_265(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 85   display */
t2=*((C_word*)lf[10]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k241 in k238 in k235 in k232 in k229 in k226 in k223 in k220 in k217 in k214 in k211 in k208 in k205 in k202 in k199 in k196 in k193 in k190 in collect-info in k180 in k177 in k174 in k171 in k168 in k165 in k162 in k159 in k156 in k153 in k150 */
static void C_ccall f_243(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 86   newline */
t2=*((C_word*)lf[9]+1);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[163] = {
{"toplevelchicken-bug.scm",(void*)C_toplevel},
{"f_152chicken-bug.scm",(void*)f_152},
{"f_155chicken-bug.scm",(void*)f_155},
{"f_158chicken-bug.scm",(void*)f_158},
{"f_161chicken-bug.scm",(void*)f_161},
{"f_164chicken-bug.scm",(void*)f_164},
{"f_167chicken-bug.scm",(void*)f_167},
{"f_170chicken-bug.scm",(void*)f_170},
{"f_173chicken-bug.scm",(void*)f_173},
{"f_176chicken-bug.scm",(void*)f_176},
{"f_179chicken-bug.scm",(void*)f_179},
{"f_182chicken-bug.scm",(void*)f_182},
{"f_1084chicken-bug.scm",(void*)f_1084},
{"f_1074chicken-bug.scm",(void*)f_1074},
{"f_1080chicken-bug.scm",(void*)f_1080},
{"f_1077chicken-bug.scm",(void*)f_1077},
{"f_991chicken-bug.scm",(void*)f_991},
{"f_995chicken-bug.scm",(void*)f_995},
{"f_1006chicken-bug.scm",(void*)f_1006},
{"f_1012chicken-bug.scm",(void*)f_1012},
{"f_1071chicken-bug.scm",(void*)f_1071},
{"f_1016chicken-bug.scm",(void*)f_1016},
{"f_1067chicken-bug.scm",(void*)f_1067},
{"f_1019chicken-bug.scm",(void*)f_1019},
{"f_1063chicken-bug.scm",(void*)f_1063},
{"f_1022chicken-bug.scm",(void*)f_1022},
{"f_1059chicken-bug.scm",(void*)f_1059},
{"f_1025chicken-bug.scm",(void*)f_1025},
{"f_1055chicken-bug.scm",(void*)f_1055},
{"f_1028chicken-bug.scm",(void*)f_1028},
{"f_1051chicken-bug.scm",(void*)f_1051},
{"f_1047chicken-bug.scm",(void*)f_1047},
{"f_1031chicken-bug.scm",(void*)f_1031},
{"f_1034chicken-bug.scm",(void*)f_1034},
{"f_1037chicken-bug.scm",(void*)f_1037},
{"f_1040chicken-bug.scm",(void*)f_1040},
{"f_1043chicken-bug.scm",(void*)f_1043},
{"f_1000chicken-bug.scm",(void*)f_1000},
{"f_970chicken-bug.scm",(void*)f_970},
{"f_980chicken-bug.scm",(void*)f_980},
{"f_983chicken-bug.scm",(void*)f_983},
{"f_901chicken-bug.scm",(void*)f_901},
{"f_916chicken-bug.scm",(void*)f_916},
{"f_946chicken-bug.scm",(void*)f_946},
{"f_958chicken-bug.scm",(void*)f_958},
{"f_964chicken-bug.scm",(void*)f_964},
{"f_952chicken-bug.scm",(void*)f_952},
{"f_922chicken-bug.scm",(void*)f_922},
{"f_928chicken-bug.scm",(void*)f_928},
{"f_935chicken-bug.scm",(void*)f_935},
{"f_938chicken-bug.scm",(void*)f_938},
{"f_914chicken-bug.scm",(void*)f_914},
{"f_905chicken-bug.scm",(void*)f_905},
{"f_815chicken-bug.scm",(void*)f_815},
{"f_847chicken-bug.scm",(void*)f_847},
{"f_877chicken-bug.scm",(void*)f_877},
{"f_889chicken-bug.scm",(void*)f_889},
{"f_895chicken-bug.scm",(void*)f_895},
{"f_883chicken-bug.scm",(void*)f_883},
{"f_853chicken-bug.scm",(void*)f_853},
{"f_859chicken-bug.scm",(void*)f_859},
{"f_866chicken-bug.scm",(void*)f_866},
{"f_869chicken-bug.scm",(void*)f_869},
{"f_845chicken-bug.scm",(void*)f_845},
{"f_819chicken-bug.scm",(void*)f_819},
{"f_835chicken-bug.scm",(void*)f_835},
{"f_797chicken-bug.scm",(void*)f_797},
{"f_813chicken-bug.scm",(void*)f_813},
{"f_809chicken-bug.scm",(void*)f_809},
{"f_805chicken-bug.scm",(void*)f_805},
{"f_609chicken-bug.scm",(void*)f_609},
{"f_620chicken-bug.scm",(void*)f_620},
{"f_752chicken-bug.scm",(void*)f_752},
{"f_624chicken-bug.scm",(void*)f_624},
{"f_631chicken-bug.scm",(void*)f_631},
{"f_635chicken-bug.scm",(void*)f_635},
{"f_667chicken-bug.scm",(void*)f_667},
{"f_639chicken-bug.scm",(void*)f_639},
{"f_659chicken-bug.scm",(void*)f_659},
{"f_643chicken-bug.scm",(void*)f_643},
{"f_651chicken-bug.scm",(void*)f_651},
{"f_647chicken-bug.scm",(void*)f_647},
{"f_568chicken-bug.scm",(void*)f_568},
{"f_593chicken-bug.scm",(void*)f_593},
{"f_586chicken-bug.scm",(void*)f_586},
{"f_578chicken-bug.scm",(void*)f_578},
{"f_581chicken-bug.scm",(void*)f_581},
{"f_425chicken-bug.scm",(void*)f_425},
{"f_525chicken-bug.scm",(void*)f_525},
{"f_566chicken-bug.scm",(void*)f_566},
{"f_562chicken-bug.scm",(void*)f_562},
{"f_541chicken-bug.scm",(void*)f_541},
{"f_537chicken-bug.scm",(void*)f_537},
{"f_429chicken-bug.scm",(void*)f_429},
{"f_523chicken-bug.scm",(void*)f_523},
{"f_519chicken-bug.scm",(void*)f_519},
{"f_432chicken-bug.scm",(void*)f_432},
{"f_435chicken-bug.scm",(void*)f_435},
{"f_515chicken-bug.scm",(void*)f_515},
{"f_438chicken-bug.scm",(void*)f_438},
{"f_444chicken-bug.scm",(void*)f_444},
{"f_494chicken-bug.scm",(void*)f_494},
{"f_498chicken-bug.scm",(void*)f_498},
{"f_469chicken-bug.scm",(void*)f_469},
{"f_473chicken-bug.scm",(void*)f_473},
{"f_479chicken-bug.scm",(void*)f_479},
{"f_483chicken-bug.scm",(void*)f_483},
{"f_477chicken-bug.scm",(void*)f_477},
{"f_459chicken-bug.scm",(void*)f_459},
{"f_406chicken-bug.scm",(void*)f_406},
{"f_410chicken-bug.scm",(void*)f_410},
{"f_387chicken-bug.scm",(void*)f_387},
{"f_404chicken-bug.scm",(void*)f_404},
{"f_397chicken-bug.scm",(void*)f_397},
{"f_391chicken-bug.scm",(void*)f_391},
{"f_378chicken-bug.scm",(void*)f_378},
{"f_382chicken-bug.scm",(void*)f_382},
{"f_188chicken-bug.scm",(void*)f_188},
{"f_192chicken-bug.scm",(void*)f_192},
{"f_195chicken-bug.scm",(void*)f_195},
{"f_376chicken-bug.scm",(void*)f_376},
{"f_372chicken-bug.scm",(void*)f_372},
{"f_198chicken-bug.scm",(void*)f_198},
{"f_368chicken-bug.scm",(void*)f_368},
{"f_364chicken-bug.scm",(void*)f_364},
{"f_201chicken-bug.scm",(void*)f_201},
{"f_204chicken-bug.scm",(void*)f_204},
{"f_360chicken-bug.scm",(void*)f_360},
{"f_207chicken-bug.scm",(void*)f_207},
{"f_356chicken-bug.scm",(void*)f_356},
{"f_210chicken-bug.scm",(void*)f_210},
{"f_352chicken-bug.scm",(void*)f_352},
{"f_213chicken-bug.scm",(void*)f_213},
{"f_348chicken-bug.scm",(void*)f_348},
{"f_216chicken-bug.scm",(void*)f_216},
{"f_344chicken-bug.scm",(void*)f_344},
{"f_219chicken-bug.scm",(void*)f_219},
{"f_340chicken-bug.scm",(void*)f_340},
{"f_222chicken-bug.scm",(void*)f_222},
{"f_225chicken-bug.scm",(void*)f_225},
{"f_228chicken-bug.scm",(void*)f_228},
{"f_336chicken-bug.scm",(void*)f_336},
{"f_332chicken-bug.scm",(void*)f_332},
{"f_328chicken-bug.scm",(void*)f_328},
{"f_295chicken-bug.scm",(void*)f_295},
{"f_299chicken-bug.scm",(void*)f_299},
{"f_304chicken-bug.scm",(void*)f_304},
{"f_312chicken-bug.scm",(void*)f_312},
{"f_231chicken-bug.scm",(void*)f_231},
{"f_234chicken-bug.scm",(void*)f_234},
{"f_293chicken-bug.scm",(void*)f_293},
{"f_279chicken-bug.scm",(void*)f_279},
{"f_281chicken-bug.scm",(void*)f_281},
{"f_289chicken-bug.scm",(void*)f_289},
{"f_237chicken-bug.scm",(void*)f_237},
{"f_240chicken-bug.scm",(void*)f_240},
{"f_275chicken-bug.scm",(void*)f_275},
{"f_249chicken-bug.scm",(void*)f_249},
{"f_252chicken-bug.scm",(void*)f_252},
{"f_257chicken-bug.scm",(void*)f_257},
{"f_265chicken-bug.scm",(void*)f_265},
{"f_243chicken-bug.scm",(void*)f_243},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
