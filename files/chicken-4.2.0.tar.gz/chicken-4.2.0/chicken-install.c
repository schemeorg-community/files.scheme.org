/* Generated from chicken-install.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2009-09-21 21:28
   Version 4.0.1 - SVN rev. 14292
   linux-unix-gnu-x86 [ manyargs dload ptables applyhook ]
   compiled 2009-05-12 on galinha (Linux)
   command line: chicken-install.scm -no-trace -optimize-level 2 -include-path . -include-path ./ -no-lambda-info -inline -local -ignore-repository -output-file chicken-install.c
   used units: library eval data_structures ports extras srfi_69 srfi_1 posix data_structures utils regex ports extras srfi_13 files chicken_syntax
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_69_toplevel)
C_externimport void C_ccall C_srfi_69_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_1_toplevel)
C_externimport void C_ccall C_srfi_1_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_posix_toplevel)
C_externimport void C_ccall C_posix_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_utils_toplevel)
C_externimport void C_ccall C_utils_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_regex_toplevel)
C_externimport void C_ccall C_regex_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_13_toplevel)
C_externimport void C_ccall C_srfi_13_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_files_toplevel)
C_externimport void C_ccall C_files_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_chicken_syntax_toplevel)
C_externimport void C_ccall C_chicken_syntax_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[250];
static double C_possibly_force_alignment;


C_noret_decl(C_toplevel)
C_externexport void C_ccall C_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1021)
static void C_ccall f_1021(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1024)
static void C_ccall f_1024(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1027)
static void C_ccall f_1027(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1030)
static void C_ccall f_1030(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1033)
static void C_ccall f_1033(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1036)
static void C_ccall f_1036(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1039)
static void C_ccall f_1039(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1042)
static void C_ccall f_1042(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1045)
static void C_ccall f_1045(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1048)
static void C_ccall f_1048(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1051)
static void C_ccall f_1051(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1054)
static void C_ccall f_1054(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1057)
static void C_ccall f_1057(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1060)
static void C_ccall f_1060(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1063)
static void C_ccall f_1063(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1066)
static void C_ccall f_1066(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1069)
static void C_ccall f_1069(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1072)
static void C_ccall f_1072(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1077)
static void C_ccall f_1077(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1080)
static void C_ccall f_1080(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1083)
static void C_ccall f_1083(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3196)
static void C_ccall f_3196(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3192)
static void C_ccall f_3192(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1498)
static void C_ccall f_1498(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3117)
static void C_ccall f_3117(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3131)
static void C_ccall f_3131(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3159)
static void C_ccall f_3159(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3178)
static void C_ccall f_3178(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3178)
static void C_ccall f_3178r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3184)
static void C_ccall f_3184(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3165)
static void C_ccall f_3165(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3176)
static void C_ccall f_3176(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1125)
static void C_ccall f_1125(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1104)
static void C_ccall f_1104(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1121)
static void C_ccall f_1121(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1114)
static void C_ccall f_1114(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2468)
static void C_fcall f_2468(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2473)
static void C_fcall f_2473(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2563)
static void C_fcall f_2563(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2916)
static void C_fcall f_2916(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3061)
static void C_ccall f_3061(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3024)
static void C_ccall f_3024(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3038)
static void C_ccall f_3038(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2979)
static void C_ccall f_2979(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3002)
static void C_ccall f_3002(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3011)
static void C_ccall f_3011(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3018)
static void C_ccall f_3018(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3005)
static void C_ccall f_3005(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2983)
static void C_ccall f_2983(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2963)
static void C_ccall f_2963(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2925)
static void C_ccall f_2925(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2959)
static void C_ccall f_2959(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2948)
static void C_ccall f_2948(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2942)
static void C_ccall f_2942(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2938)
static void C_ccall f_2938(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2889)
static void C_ccall f_2889(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2859)
static void C_ccall f_2859(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2802)
static void C_ccall f_2802(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1189)
static void C_ccall f_1189(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1195)
static void C_ccall f_1195(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1200)
static void C_ccall f_1200(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1220)
static void C_ccall f_1220(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1212)
static void C_ccall f_1212(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1216)
static void C_ccall f_1216(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1208)
static void C_ccall f_1208(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2805)
static void C_ccall f_2805(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2773)
static void C_ccall f_2773(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2766)
static void C_ccall f_2766(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2715)
static void C_ccall f_2715(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2678)
static void C_ccall f_2678(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2682)
static void C_ccall f_2682(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2645)
static void C_ccall f_2645(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2609)
static void C_ccall f_2609(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2517)
static void C_ccall f_2517(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2548)
static void C_ccall f_2548(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2533)
static void C_ccall f_2533(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2541)
static void C_ccall f_2541(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2531)
static void C_ccall f_2531(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2527)
static void C_ccall f_2527(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2489)
static void C_ccall f_2489(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2502)
static void C_ccall f_2502(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2492)
static void C_ccall f_2492(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2499)
static void C_ccall f_2499(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2056)
static void C_ccall f_2056(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2170)
static void C_ccall f_2170(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2062)
static void C_ccall f_2062(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2065)
static void C_ccall f_2065(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2068)
static void C_ccall f_2068(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2162)
static void C_ccall f_2162(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2160)
static void C_ccall f_2160(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2073)
static void C_ccall f_2073(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2077)
static void C_ccall f_2077(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2080)
static void C_ccall f_2080(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2097)
static void C_ccall f_2097(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2000)
static void C_ccall f_2000(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2042)
static void C_ccall f_2042(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2020)
static void C_ccall f_2020(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2028)
static void C_ccall f_2028(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2024)
static void C_ccall f_2024(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2101)
static void C_ccall f_2101(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2104)
static void C_ccall f_2104(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2107)
static void C_ccall f_2107(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2135)
static void C_ccall f_2135(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2141)
static void C_ccall f_2141(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2113)
static void C_ccall f_2113(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2116)
static void C_ccall f_2116(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2119)
static void C_ccall f_2119(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2122)
static void C_ccall f_2122(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2084)
static void C_ccall f_2084(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2088)
static void C_ccall f_2088(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2091)
static void C_ccall f_2091(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2430)
static void C_ccall f_2430(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2426)
static void C_ccall f_2426(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2191)
static void C_ccall f_2191(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2194)
static void C_ccall f_2194(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2197)
static void C_ccall f_2197(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2200)
static void C_ccall f_2200(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2203)
static void C_ccall f_2203(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2419)
static void C_ccall f_2419(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2335)
static void C_ccall f_2335(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2341)
static void C_ccall f_2341(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2345)
static void C_ccall f_2345(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2353)
static void C_ccall f_2353(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2379)
static void C_ccall f_2379(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2407)
static void C_ccall f_2407(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2407)
static void C_ccall f_2407r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2413)
static void C_ccall f_2413(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2385)
static void C_ccall f_2385(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2401)
static void C_ccall f_2401(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2359)
static void C_ccall f_2359(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2365)
static void C_ccall f_2365(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2373)
static void C_ccall f_2373(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2377)
static void C_ccall f_2377(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2351)
static void C_ccall f_2351(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2330)
static void C_ccall f_2330(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2206)
static void C_ccall f_2206(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2209)
static void C_ccall f_2209(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2275)
static void C_ccall f_2275(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2282)
static void C_ccall f_2282(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2285)
static void C_ccall f_2285(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2296)
static void C_ccall f_2296(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2320)
static void C_ccall f_2320(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2304)
static void C_ccall f_2304(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2310)
static void C_ccall f_2310(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2308)
static void C_ccall f_2308(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2290)
static void C_ccall f_2290(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2251)
static void C_ccall f_2251(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2253)
static void C_ccall f_2253(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2261)
static void C_ccall f_2261(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2265)
static void C_ccall f_2265(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2212)
static void C_ccall f_2212(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2215)
static void C_ccall f_2215(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2234)
static void C_ccall f_2234(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2240)
static void C_ccall f_2240(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2244)
static void C_ccall f_2244(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2218)
static void C_ccall f_2218(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2232)
static void C_ccall f_2232(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2228)
static void C_ccall f_2228(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2221)
static void C_ccall f_2221(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3169)
static void C_ccall f_3169(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3137)
static void C_ccall f_3137(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3143)
static void C_ccall f_3143(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3157)
static void C_ccall f_3157(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3147)
static void C_ccall f_3147(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3150)
static void C_ccall f_3150(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3129)
static void C_ccall f_3129(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3120)
static void C_ccall f_3120(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3126)
static void C_ccall f_3126(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3123)
static void C_ccall f_3123(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2454)
static void C_fcall f_2454(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2458)
static void C_ccall f_2458(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2432)
static void C_fcall f_2432(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2449)
static void C_ccall f_2449(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2436)
static void C_ccall f_2436(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2172)
static void C_fcall f_2172(C_word t0) C_noret;
C_noret_decl(f_2179)
static void C_ccall f_2179(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1766)
static void C_fcall f_1766(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1770)
static void C_ccall f_1770(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1928)
static void C_ccall f_1928(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1960)
static void C_ccall f_1960(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1964)
static void C_ccall f_1964(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1967)
static void C_ccall f_1967(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1954)
static void C_ccall f_1954(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1641)
static void C_fcall f_1641(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1643)
static void C_fcall f_1643(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1707)
static void C_ccall f_1707(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1697)
static void C_ccall f_1697(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1673)
static void C_ccall f_1673(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1168)
static void C_ccall f_1168(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1667)
static void C_ccall f_1667(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1509)
static void C_ccall f_1509(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1602)
static void C_ccall f_1602(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1621)
static void C_ccall f_1621(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1621)
static void C_ccall f_1621r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1627)
static void C_ccall f_1627(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1608)
static void C_ccall f_1608(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1616)
static void C_ccall f_1616(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1515)
static void C_ccall f_1515(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1521)
static void C_ccall f_1521(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1531)
static void C_fcall f_1531(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1543)
static void C_fcall f_1543(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1555)
static void C_fcall f_1555(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1558)
static void C_ccall f_1558(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1561)
static void C_ccall f_1561(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1546)
static void C_ccall f_1546(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1534)
static void C_ccall f_1534(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1507)
static void C_ccall f_1507(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1943)
static void C_ccall f_1943(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1773)
static void C_ccall f_1773(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1781)
static void C_ccall f_1781(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1795)
static void C_ccall f_1795(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1801)
static void C_ccall f_1801(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1906)
static void C_ccall f_1906(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1804)
static void C_ccall f_1804(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1807)
static void C_ccall f_1807(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1818)
static void C_ccall f_1818(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1895)
static void C_ccall f_1895(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1883)
static void C_ccall f_1883(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1876)
static void C_ccall f_1876(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1826)
static void C_ccall f_1826(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1730)
static void C_ccall f_1730(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1756)
static void C_ccall f_1756(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1728)
static void C_ccall f_1728(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1720)
static void C_ccall f_1720(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1870)
static void C_ccall f_1870(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1832)
static void C_ccall f_1832(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1835)
static void C_ccall f_1835(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1857)
static void C_ccall f_1857(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1838)
static void C_ccall f_1838(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1846)
static void C_ccall f_1846(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1850)
static void C_ccall f_1850(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1841)
static void C_ccall f_1841(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1812)
static void C_ccall f_1812(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1285)
static void C_fcall f_1285(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1294)
static void C_ccall f_1294(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1299)
static void C_fcall f_1299(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1355)
static void C_fcall f_1355(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1455)
static void C_ccall f_1455(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1358)
static void C_ccall f_1358(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1375)
static void C_ccall f_1375(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1444)
static void C_ccall f_1444(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1440)
static void C_ccall f_1440(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1429)
static void C_ccall f_1429(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1421)
static void C_ccall f_1421(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1388)
static void C_ccall f_1388(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1399)
static void C_ccall f_1399(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1403)
static void C_ccall f_1403(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1395)
static void C_ccall f_1395(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1342)
static void C_ccall f_1342(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1349)
static void C_ccall f_1349(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1339)
static void C_fcall f_1339(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1313)
static void C_ccall f_1313(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1317)
static void C_ccall f_1317(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1222)
static void C_fcall f_1222(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1267)
static void C_ccall f_1267(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1232)
static void C_fcall f_1232(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1238)
static void C_ccall f_1238(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_2468)
static void C_fcall trf_2468(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2468(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2468(t0,t1);}

C_noret_decl(trf_2473)
static void C_fcall trf_2473(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2473(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2473(t0,t1,t2,t3);}

C_noret_decl(trf_2563)
static void C_fcall trf_2563(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2563(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2563(t0,t1);}

C_noret_decl(trf_2916)
static void C_fcall trf_2916(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2916(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2916(t0,t1);}

C_noret_decl(trf_2454)
static void C_fcall trf_2454(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2454(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2454(t0,t1);}

C_noret_decl(trf_2432)
static void C_fcall trf_2432(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2432(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2432(t0,t1);}

C_noret_decl(trf_2172)
static void C_fcall trf_2172(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2172(void *dummy){
C_word t0=C_pick(0);
C_adjust_stack(-1);
f_2172(t0);}

C_noret_decl(trf_1766)
static void C_fcall trf_1766(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1766(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1766(t0,t1);}

C_noret_decl(trf_1641)
static void C_fcall trf_1641(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1641(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1641(t0,t1);}

C_noret_decl(trf_1643)
static void C_fcall trf_1643(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1643(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1643(t0,t1,t2);}

C_noret_decl(trf_1531)
static void C_fcall trf_1531(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1531(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1531(t0,t1);}

C_noret_decl(trf_1543)
static void C_fcall trf_1543(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1543(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1543(t0,t1);}

C_noret_decl(trf_1555)
static void C_fcall trf_1555(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1555(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1555(t0,t1);}

C_noret_decl(trf_1285)
static void C_fcall trf_1285(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1285(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1285(t0,t1);}

C_noret_decl(trf_1299)
static void C_fcall trf_1299(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1299(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1299(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1355)
static void C_fcall trf_1355(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1355(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1355(t0,t1);}

C_noret_decl(trf_1339)
static void C_fcall trf_1339(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1339(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1339(t0,t1);}

C_noret_decl(trf_1222)
static void C_fcall trf_1222(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1222(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1222(t0,t1);}

C_noret_decl(trf_1232)
static void C_fcall trf_1232(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1232(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1232(t0,t1);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_main_entry_point
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("toplevel"));
C_resize_stack(131072);
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(1151)){
C_save(t1);
C_rereclaim2(1151*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,250);
lf[13]=C_h_intern(&lf[13],4,"http");
lf[16]=C_decode_literal(C_heaptop,"\376B\000\000\012modules.db");
lf[18]=C_h_intern(&lf[18],7,"chicken");
lf[19]=C_h_intern(&lf[19],15,"chicken-version");
lf[20]=C_h_intern(&lf[20],7,"version");
lf[21]=C_h_intern(&lf[21],8,"->string");
lf[22]=C_decode_literal(C_heaptop,"\376B\000\000\0050.0.0");
lf[23]=C_h_intern(&lf[23],21,"extension-information");
lf[24]=C_decode_literal(C_heaptop,"\376B\000\000\007chicken");
lf[25]=C_h_intern(&lf[25],24,"\003syscore-library-modules");
lf[31]=C_h_intern(&lf[31],7,"reverse");
lf[32]=C_h_intern(&lf[32],10,"alist-cons");
lf[33]=C_decode_literal(C_heaptop,"\376B\000\000\007chicken");
lf[34]=C_h_intern(&lf[34],5,"error");
lf[35]=C_h_intern(&lf[35],13,"string-append");
lf[36]=C_decode_literal(C_heaptop,"\376B\000\000JYour CHICKEN version is not recent enough to use this extension - version ");
lf[37]=C_decode_literal(C_heaptop,"\376B\000\000\025 or newer is required");
lf[38]=C_h_intern(&lf[38],20,"setup-api#version>=\077");
lf[39]=C_h_intern(&lf[39],7,"warning");
lf[40]=C_decode_literal(C_heaptop,"\376B\000\0007invalid dependency syntax in extension meta information");
lf[41]=C_h_intern(&lf[41],7,"depends");
lf[42]=C_h_intern(&lf[42],5,"needs");
lf[43]=C_h_intern(&lf[43],6,"append");
lf[44]=C_h_intern(&lf[44],12,"test-depends");
lf[45]=C_h_intern(&lf[45],26,"setup-api#remove-extension");
lf[46]=C_h_intern(&lf[46],5,"print");
lf[47]=C_decode_literal(C_heaptop,"\376B\000\000)removing previously installed extension `");
lf[48]=C_decode_literal(C_heaptop,"\376B\000\000\005\047 ...");
lf[49]=C_h_intern(&lf[49],12,"\003sysfor-each");
lf[50]=C_decode_literal(C_heaptop,"\376B\000\000\012 upgrade: ");
lf[51]=C_h_intern(&lf[51],18,"string-intersperse");
lf[52]=C_decode_literal(C_heaptop,"\376B\000\000\002, ");
lf[53]=C_h_intern(&lf[53],6,"unzip1");
lf[54]=C_h_intern(&lf[54],20,"setup-api#yes-or-no\077");
lf[55]=C_decode_literal(C_heaptop,"\376B\000\000\002no");
lf[56]=C_h_intern(&lf[56],18,"string-concatenate");
lf[57]=C_decode_literal(C_heaptop,"\376B\000\000:The following installed extensions are outdated, because `");
lf[58]=C_decode_literal(C_heaptop,"\376B\000\000\033\047 requires later versions:\012");
lf[59]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\0000\012Do you want to replace the existing extensions\077\376\377\016");
lf[60]=C_decode_literal(C_heaptop,"\376B\000\000\003\077\077\077");
lf[61]=C_h_intern(&lf[61],4,"conc");
lf[62]=C_decode_literal(C_heaptop,"\376B\000\000\002  ");
lf[63]=C_decode_literal(C_heaptop,"\376B\000\000\002 (");
lf[64]=C_decode_literal(C_heaptop,"\376B\000\000\004 -> ");
lf[65]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[66]=C_h_intern(&lf[66],7,"\003sysmap");
lf[67]=C_decode_literal(C_heaptop,"\376B\000\000\012 missing: ");
lf[68]=C_decode_literal(C_heaptop,"\376B\000\000\002, ");
lf[69]=C_decode_literal(C_heaptop,"\376B\000\000\033checking dependencies for `");
lf[70]=C_decode_literal(C_heaptop,"\376B\000\000\005\047 ...");
lf[71]=C_h_intern(&lf[71],20,"with-input-from-file");
lf[72]=C_h_intern(&lf[72],4,"read");
lf[73]=C_decode_literal(C_heaptop,"\376B\000\000\013extension `");
lf[74]=C_decode_literal(C_heaptop,"\376B\000\000\024\047 has no .meta file ");
lf[75]=C_decode_literal(C_heaptop,"\376B\000\000!- assuming it has no dependencies");
lf[76]=C_h_intern(&lf[76],12,"file-exists\077");
lf[77]=C_h_intern(&lf[77],13,"make-pathname");
lf[78]=C_decode_literal(C_heaptop,"\376B\000\000\004meta");
lf[79]=C_h_intern(&lf[79],6,"delete");
lf[80]=C_h_intern(&lf[80],3,"eq\077");
lf[81]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[82]=C_h_intern(&lf[82],8,"location");
lf[83]=C_h_intern(&lf[83],9,"transport");
lf[84]=C_h_intern(&lf[84],9,"condition");
lf[85]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[86]=C_decode_literal(C_heaptop,"\376B\000\000\023TCP connect timeout");
lf[87]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[88]=C_decode_literal(C_heaptop,"\376B\000\000\023HTTP protocol error");
lf[89]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[90]=C_h_intern(&lf[90],19,"print-error-message");
lf[91]=C_decode_literal(C_heaptop,"\376B\000\000\015Server error:");
lf[92]=C_h_intern(&lf[92],5,"abort");
lf[93]=C_h_intern(&lf[93],3,"exn");
lf[94]=C_h_intern(&lf[94],20,"setup-download-error");
lf[95]=C_h_intern(&lf[95],10,"http-fetch");
lf[96]=C_h_intern(&lf[96],3,"net");
lf[97]=C_h_intern(&lf[97],33,"setup-download#retrieve-extension");
lf[98]=C_h_intern(&lf[98],8,"\000version");
lf[99]=C_h_intern(&lf[99],12,"\000destination");
lf[100]=C_h_intern(&lf[100],6,"\000tests");
lf[101]=C_h_intern(&lf[101],9,"\000username");
lf[102]=C_h_intern(&lf[102],9,"\000password");
lf[103]=C_h_intern(&lf[103],17,"current-directory");
lf[104]=C_h_intern(&lf[104],22,"with-exception-handler");
lf[105]=C_h_intern(&lf[105],30,"call-with-current-continuation");
lf[106]=C_decode_literal(C_heaptop,"\376B\000\000\027missing transport entry");
lf[107]=C_decode_literal(C_heaptop,"\376B\000\000\026missing location entry");
lf[108]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[109]=C_decode_literal(C_heaptop,"\376B\000\000\014 located at ");
lf[110]=C_decode_literal(C_heaptop,"\376B\000\000\036extension or version not found");
lf[111]=C_decode_literal(C_heaptop,"\376B\000\000\016retrieving ...");
lf[113]=C_h_intern(&lf[113],26,"setup-api#remove-directory");
lf[114]=C_h_intern(&lf[114],34,"setup-download#temporary-directory");
lf[116]=C_decode_literal(C_heaptop,"\376B\000\000/shell command terminated with nonzero exit code");
lf[117]=C_h_intern(&lf[117],6,"system");
lf[118]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[119]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[121]=C_h_intern(&lf[121],4,"exit");
lf[122]=C_decode_literal(C_heaptop,"\376B\000\004\250usage: chicken-install [OPTION | EXTENSION[:VERSION]] ...\012\012  -h   -help    "
"                show this message and exit\012  -v   -version                 show "
"version and exit\012       -force                   don\047t ask, install even if vers"
"ions don\047t match\012  -k   -keep                    keep temporary files\012  -l   -lo"
"cation LOCATION       install from given location instead of default\012  -t   -tra"
"nsport TRANSPORT     use given transport instead of default\012  -s   -sudo        "
"            use sudo(1) for filesystem operations\012  -r   -retrieve              "
"  only retrieve egg into current directory, don\047t install\012  -n   -no-install    "
"          do not install, just build (implies `-keep\047)\012  -p   -prefix PREFIX    "
"       change installation prefix to PREFIX\012       -host-extension          when"
" cross-compiling, compile extension for host\012       -test                    run"
" included test-cases, if available\012       -username USER           set username "
"for transports that require this\012       -password PASS           set password fo"
"r transports that require this\012  -i   -init DIRECTORY          initialize empty "
"alternative repository\012  -u   -update-db               update export database");
lf[123]=C_h_intern(&lf[123],25,"\003sysimplicit-exit-handler");
lf[124]=C_h_intern(&lf[124],18,"current-error-port");
lf[125]=C_h_intern(&lf[125],19,"setup-api#copy-file");
lf[126]=C_h_intern(&lf[126],15,"repository-path");
lf[127]=C_h_intern(&lf[127],7,"newline");
lf[128]=C_h_intern(&lf[128],5,"write");
lf[129]=C_h_intern(&lf[129],19,"with-output-to-file");
lf[130]=C_h_intern(&lf[130],8,"string<\077");
lf[131]=C_h_intern(&lf[131],14,"symbol->string");
lf[132]=C_h_intern(&lf[132],4,"sort");
lf[133]=C_h_intern(&lf[133],18,"\003sysmodule-exports");
lf[134]=C_h_intern(&lf[134],5,"value");
lf[135]=C_h_intern(&lf[135],6,"syntax");
lf[136]=C_h_intern(&lf[136],6,"print*");
lf[137]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[138]=C_h_intern(&lf[138],15,"\003sysmodule-name");
lf[139]=C_h_intern(&lf[139],10,"append-map");
lf[140]=C_h_intern(&lf[140],16,"\003sysmodule-table");
lf[141]=C_decode_literal(C_heaptop,"\376B\000\000\023generating database");
lf[142]=C_h_intern(&lf[142],20,"\003syswarnings-enabled");
lf[143]=C_h_intern(&lf[143],7,"sprintf");
lf[144]=C_decode_literal(C_heaptop,"\376B\000\000\032Failed to import from `~a\047");
lf[145]=C_h_intern(&lf[145],6,"import");
lf[146]=C_h_intern(&lf[146],4,"eval");
lf[147]=C_h_intern(&lf[147],14,"string->symbol");
lf[148]=C_h_intern(&lf[148],12,"string-match");
lf[149]=C_h_intern(&lf[149],16,"\003sysdynamic-wind");
lf[150]=C_decode_literal(C_heaptop,"\376B\000\000\034loading import libraries ...");
lf[151]=C_h_intern(&lf[151],6,"regexp");
lf[152]=C_decode_literal(C_heaptop,"\376B\000\000\034.*/([^/]+)\134.import\134.(scm|so)");
lf[153]=C_h_intern(&lf[153],36,"setup-api#create-temporary-directory");
lf[154]=C_h_intern(&lf[154],4,"glob");
lf[155]=C_decode_literal(C_heaptop,"\376B\000\000\012*.import.*");
lf[156]=C_decode_literal(C_heaptop,"\376B\000\000\002  ");
lf[157]=C_decode_literal(C_heaptop,"\376B\000\000\020~a -s run.scm ~a");
lf[158]=C_decode_literal(C_heaptop,"\376B\000\000\005tests");
lf[159]=C_decode_literal(C_heaptop,"\376B\000\000\015tests/run.scm");
lf[160]=C_h_intern(&lf[160],10,"directory\077");
lf[161]=C_decode_literal(C_heaptop,"\376B\000\000\005tests");
lf[162]=C_decode_literal(C_heaptop,"\376B\000\000\005tests");
lf[163]=C_decode_literal(C_heaptop,"\376B\000\000\002  ");
lf[164]=C_decode_literal(C_heaptop,"\376B\000\000\027 -e \042(sudo-install #t)\042");
lf[165]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[166]=C_decode_literal(C_heaptop,"\376B\000\000\035 -e \042(keep-intermediates #t)\042");
lf[167]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[168]=C_decode_literal(C_heaptop,"\376B\000\000\035 -e \042(setup-install-mode #f)\042");
lf[169]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[170]=C_decode_literal(C_heaptop,"\376B\000\000\031 -e \042(host-extension #t)\042");
lf[171]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[172]=C_decode_literal(C_heaptop,"\376B\000\000J -bnq -setup-mode -e \042(require-library setup-api)\042 -e \042(import setup-api)\042");
lf[173]=C_h_intern(&lf[173],19,"setup-api#shellpath");
lf[174]=C_decode_literal(C_heaptop,"\376B\000\000\005setup");
lf[175]=C_decode_literal(C_heaptop,"\376B\000\000\042 -e \042(installation-prefix \134\042~a\134\042)\042");
lf[176]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[177]=C_h_intern(&lf[177],22,"setup-api#sudo-install");
lf[178]=C_decode_literal(C_heaptop,"\376B\000\0003 -e \042(extension-name-and-version \047(\134\042~a\134\042 \134\042~a\134\042))\042");
lf[179]=C_decode_literal(C_heaptop,"\376B\000\000\036changing current directory to ");
lf[180]=C_decode_literal(C_heaptop,"\376B\000\000\013installing ");
lf[181]=C_decode_literal(C_heaptop,"\376B\000\000\004 ...");
lf[182]=C_h_intern(&lf[182],2,"pp");
lf[183]=C_decode_literal(C_heaptop,"\376B\000\000\016install order:");
lf[184]=C_h_intern(&lf[184],16,"topological-sort");
lf[185]=C_h_intern(&lf[185],8,"string=\077");
lf[186]=C_decode_literal(C_heaptop,"\376B\000\000;no default location defined - please use `-location\047 option");
lf[187]=C_decode_literal(C_heaptop,"\376B\000\000=no default transport defined - please use `-transport\047 option");
lf[188]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[189]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[190]=C_h_intern(&lf[190],13,"pathname-file");
lf[191]=C_decode_literal(C_heaptop,"\376B\000\000\033no setup-scripts to process");
lf[192]=C_decode_literal(C_heaptop,"\376B\000\000\007*.setup");
lf[193]=C_decode_literal(C_heaptop,"\376B\000\000\005-help");
lf[194]=C_decode_literal(C_heaptop,"\376B\000\000\006-force");
lf[195]=C_decode_literal(C_heaptop,"\376B\000\000\002-k");
lf[196]=C_decode_literal(C_heaptop,"\376B\000\000\005-keep");
lf[197]=C_decode_literal(C_heaptop,"\376B\000\000\002-s");
lf[198]=C_decode_literal(C_heaptop,"\376B\000\000\005-sudo");
lf[199]=C_decode_literal(C_heaptop,"\376B\000\000\002-r");
lf[200]=C_decode_literal(C_heaptop,"\376B\000\000\011-retrieve");
lf[201]=C_decode_literal(C_heaptop,"\376B\000\000\002-l");
lf[202]=C_decode_literal(C_heaptop,"\376B\000\000\011-location");
lf[203]=C_decode_literal(C_heaptop,"\376B\000\000\002-t");
lf[204]=C_decode_literal(C_heaptop,"\376B\000\000\012-transport");
lf[205]=C_decode_literal(C_heaptop,"\376B\000\000\002-p");
lf[206]=C_decode_literal(C_heaptop,"\376B\000\000\007-prefix");
lf[207]=C_decode_literal(C_heaptop,"\376B\000\000\002-n");
lf[208]=C_decode_literal(C_heaptop,"\376B\000\000\013-no-install");
lf[209]=C_decode_literal(C_heaptop,"\376B\000\000\002-v");
lf[210]=C_decode_literal(C_heaptop,"\376B\000\000\010-version");
lf[211]=C_decode_literal(C_heaptop,"\376B\000\000\002-u");
lf[212]=C_decode_literal(C_heaptop,"\376B\000\000\012-update-db");
lf[213]=C_decode_literal(C_heaptop,"\376B\000\000\002-i");
lf[214]=C_decode_literal(C_heaptop,"\376B\000\000\005-init");
lf[215]=C_decode_literal(C_heaptop,"\376B\000\000\004copy");
lf[216]=C_decode_literal(C_heaptop,"\376B\000\000\005cp -r");
lf[217]=C_decode_literal(C_heaptop,"\376B\000\000\010~a ~a ~a");
lf[218]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\014setup-api.so\376\003\000\000\002\376B\000\000\023setup-api.import.so\376\003\000\000\002\376B\000\000\021setup-download.so\376\003"
"\000\000\002\376B\000\000\030setup-download.import.so\376\003\000\000\002\376B\000\000\021chicken.import.so\376\003\000\000\002\376B\000\000\021lolevel.imp"
"ort.so\376\003\000\000\002\376B\000\000\020srfi-1.import.so\376\003\000\000\002\376B\000\000\020srfi-4.import.so\376\003\000\000\002\376B\000\000\031data-structu"
"res.import.so\376\003\000\000\002\376B\000\000\017ports.import.so\376\003\000\000\002\376B\000\000\017files.import.so\376\003\000\000\002\376B\000\000\017posix.i"
"mport.so\376\003\000\000\002\376B\000\000\021srfi-13.import.so\376\003\000\000\002\376B\000\000\021srfi-69.import.so\376\003\000\000\002\376B\000\000\020extras.i"
"mport.so\376\003\000\000\002\376B\000\000\017regex.import.so\376\003\000\000\002\376B\000\000\021srfi-14.import.so\376\003\000\000\002\376B\000\000\015tcp.import"
".so\376\003\000\000\002\376B\000\000\021foreign.import.so\376\003\000\000\002\376B\000\000\020scheme.import.so\376\003\000\000\002\376B\000\000\021srfi-18.import"
".so\376\003\000\000\002\376B\000\000\017utils.import.so\376\003\000\000\002\376B\000\000\015csi.import.so\376\003\000\000\002\376B\000\000\021irregex.import.so\376\003"
"\000\000\002\376B\000\000\010types.db\376\377\016");
lf[219]=C_decode_literal(C_heaptop,"\376B\000\000\032copying required files to ");
lf[220]=C_decode_literal(C_heaptop,"\376B\000\000\004 ...");
lf[221]=C_decode_literal(C_heaptop,"\376B\000\000\005-test");
lf[222]=C_decode_literal(C_heaptop,"\376B\000\000\017-host-extension");
lf[223]=C_decode_literal(C_heaptop,"\376B\000\000\011-username");
lf[224]=C_decode_literal(C_heaptop,"\376B\000\000\011-password");
lf[225]=C_h_intern(&lf[225],17,"lset-intersection");
lf[226]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000h\376\003\000\000\002\376\377\012\000\000k\376\003\000\000\002\376\377\012\000\000l\376\003\000\000\002\376\377\012\000\000t\376\003\000\000\002\376\377\012\000\000s\376\003\000\000\002\376\377\012\000\000p\376\003\000\000\002\376\377\012\000\000r\376\003\000"
"\000\002\376\377\012\000\000n\376\003\000\000\002\376\377\012\000\000v\376\003\000\000\002\376\377\012\000\000i\376\003\000\000\002\376\377\012\000\000u\376\377\016");
lf[227]=C_h_intern(&lf[227],16,"\003sysstring->list");
lf[228]=C_h_intern(&lf[228],9,"substring");
lf[229]=C_decode_literal(C_heaptop,"\376B\000\000\005setup");
lf[230]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[231]=C_h_intern(&lf[231],18,"absolute-pathname\077");
lf[232]=C_h_intern(&lf[232],18,"pathname-directory");
lf[233]=C_decode_literal(C_heaptop,"\376B\000\000\014([^:]+):(.+)");
lf[234]=C_h_intern(&lf[234],18,"pathname-extension");
lf[235]=C_decode_literal(C_heaptop,"\376B\000\000\002-h");
lf[236]=C_decode_literal(C_heaptop,"\376B\000\000\006--help");
lf[237]=C_h_intern(&lf[237],9,"read-file");
lf[238]=C_decode_literal(C_heaptop,"\376B\000\000\016setup.defaults");
lf[239]=C_h_intern(&lf[239],12,"chicken-home");
lf[240]=C_h_intern(&lf[240],22,"command-line-arguments");
lf[241]=C_h_intern(&lf[241],17,"register-feature!");
lf[242]=C_h_intern(&lf[242],15,"chicken-install");
lf[243]=C_h_intern(&lf[243],17,"\003syspeek-c-string");
lf[244]=C_decode_literal(C_heaptop,"\376B\000\000\003bin");
lf[245]=C_h_intern(&lf[245],24,"get-environment-variable");
lf[246]=C_decode_literal(C_heaptop,"\376B\000\000\016CHICKEN_PREFIX");
lf[247]=C_h_intern(&lf[247],11,"\003sysrequire");
lf[248]=C_h_intern(&lf[248],9,"setup-api");
lf[249]=C_h_intern(&lf[249],14,"setup-download");
C_register_lf2(lf,250,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1021,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1019 */
static void C_ccall f_1021(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1021,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1024,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1022 in k1019 */
static void C_ccall f_1024(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1024,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1027,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1025 in k1022 in k1019 */
static void C_ccall f_1027(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1027,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1030,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_1030(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1030,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1033,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_1033(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1033,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1036,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_1036(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1036,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1039,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_1_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_1039(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1039,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1042,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_posix_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_1042(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1042,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1045,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_1045(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1045,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1048,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_utils_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_1048(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1048,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1051,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_regex_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_1051(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1051,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1054,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_1054(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1054,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1057,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_1057(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1057,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1060,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_13_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_1060(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1060,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1063,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_files_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_1063(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1063,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1066,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_chicken_syntax_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_1066(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1066,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1069,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#require */
((C_proc3)C_retrieve_symbol_proc(lf[247]))(3,*((C_word*)lf[247]+1),t2,lf[249]);}

/* k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_1069(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1069,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1072,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#require */
((C_proc3)C_retrieve_symbol_proc(lf[247]))(3,*((C_word*)lf[247]+1),t2,lf[248]);}

/* k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_1072(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1072,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1077,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 67   get-environment-variable */
((C_proc3)C_retrieve_symbol_proc(lf[245]))(3,*((C_word*)lf[245]+1),t2,lf[246]);}

/* k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_1077(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1077,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1080,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
/* chicken-install.scm: 68   make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[77]))(4,*((C_word*)lf[77]+1),t2,t1,lf[244]);}
else{
t3=t2;
f_1080(2,t3,C_SCHEME_FALSE);}}

/* k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_1080(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1080,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1083,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
t3=t2;
f_1083(2,t3,t1);}
else{
/* ##sys#peek-c-string */
t3=*((C_word*)lf[243]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_INSTALL_BIN_HOME),C_fix(0));}}

/* k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_1083(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1083,2,t0,t1);}
t2=C_mutate(&lf[0] /* (set! main#*program-path* ...) */,t1);
t3=lf[1] /* main#*keep* */ =C_SCHEME_FALSE;;
t4=lf[2] /* main#*force* */ =C_SCHEME_FALSE;;
t5=lf[3] /* main#*prefix* */ =C_SCHEME_FALSE;;
t6=lf[4] /* main#*host-extension* */ =C_SCHEME_FALSE;;
t7=lf[5] /* main#*run-tests* */ =C_SCHEME_FALSE;;
t8=lf[6] /* main#*retrieve-only* */ =C_SCHEME_FALSE;;
t9=lf[7] /* main#*no-install* */ =C_SCHEME_FALSE;;
t10=lf[8] /* main#*username* */ =C_SCHEME_FALSE;;
t11=lf[9] /* main#*password* */ =C_SCHEME_FALSE;;
t12=lf[10] /* main#*default-sources* */ =C_SCHEME_END_OF_LIST;;
t13=lf[11] /* main#*default-location* */ =C_SCHEME_FALSE;;
t14=C_mutate(&lf[12] /* (set! main#*default-transport* ...) */,lf[13]);
t15=C_mutate(&lf[14] /* (set! main#*windows-shell* ...) */,C_mk_bool(C_WINDOWS_SHELL));
t16=C_mutate(&lf[15] /* (set! main#constant220 ...) */,lf[16]);
t17=C_mutate(&lf[17] /* (set! main#ext-version ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1222,tmp=(C_word)a,a+=2,tmp));
t18=lf[26] /* main#*eggs+dirs+vers* */ =C_SCHEME_END_OF_LIST;;
t19=lf[27] /* main#*dependencies* */ =C_SCHEME_END_OF_LIST;;
t20=lf[28] /* main#*checked* */ =C_SCHEME_END_OF_LIST;;
t21=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1498,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t22=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3192,a[2]=t21,tmp=(C_word)a,a+=3,tmp);
t23=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3196,a[2]=t22,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t24=*((C_word*)lf[243]+1);
((C_proc4)(void*)(*((C_word*)t24+1)))(4,t24,t23,C_mpointer(&a,(void*)C_CSI_PROGRAM),C_fix(0));}

/* k3194 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_3196(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 179  make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[77]))(4,*((C_word*)lf[77]+1),((C_word*)t0)[2],C_retrieve2(lf[0],"main#*program-path*"),t1);}

/* k3190 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_3192(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 179  setup-api#shellpath */
((C_proc3)C_retrieve_symbol_proc(lf[173]))(3,*((C_word*)lf[173]+1),((C_word*)t0)[2],t1);}

/* k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_1498(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1498,2,t0,t1);}
t2=C_mutate(&lf[29] /* (set! main#*csi* ...) */,t1);
t3=C_mutate(&lf[30] /* (set! main#retrieve ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1766,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate(&lf[112] /* (set! main#cleanup ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2172,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate(&lf[115] /* (set! main#$system ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2432,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate(&lf[120] /* (set! main#usage ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2454,tmp=(C_word)a,a+=2,tmp));
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3117,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 513  register-feature! */
((C_proc3)C_retrieve_symbol_proc(lf[241]))(3,*((C_word*)lf[241]+1),t7,lf[242]);}

/* k3115 in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_3117(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3117,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3120,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3129,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3131,tmp=(C_word)a,a+=2,tmp);
/* call-with-current-continuation */
((C_proc3)C_retrieve_proc(*((C_word*)lf[105]+1)))(3,*((C_word*)lf[105]+1),t3,t4);}

/* a3130 in k3115 in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_3131(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3131,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3137,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3159,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* with-exception-handler */
((C_proc4)C_retrieve_symbol_proc(lf[104]))(4,*((C_word*)lf[104]+1),t1,t3,t4);}

/* a3158 in a3130 in k3115 in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_3159(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3159,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3165,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3178,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a3177 in a3158 in a3130 in k3115 in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_3178(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_3178r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3178r(t0,t1,t2);}}

static void C_ccall f_3178r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3184,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* k937942 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a3183 in a3177 in a3158 in a3130 in k3115 in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_3184(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3184,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a3164 in a3158 in a3130 in k3115 in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_3165(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3165,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3169,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3176,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 520  command-line-arguments */
((C_proc2)C_retrieve_symbol_proc(lf[240]))(2,*((C_word*)lf[240]+1),t3);}

/* k3174 in a3164 in a3158 in a3130 in k3115 in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_3176(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3176,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2468,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1104,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1125,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 89   chicken-home */
((C_proc2)C_retrieve_symbol_proc(lf[239]))(2,*((C_word*)lf[239]+1),t4);}

/* k1123 in k3174 in a3164 in a3158 in a3130 in k3115 in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_1125(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 89   make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[77]))(4,*((C_word*)lf[77]+1),((C_word*)t0)[2],t1,lf[238]);}

/* k1102 in k3174 in a3164 in a3158 in a3130 in k3115 in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_1104(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1104,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1121,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm: 90   file-exists? */
((C_proc3)C_retrieve_symbol_proc(lf[76]))(3,*((C_word*)lf[76]+1),t2,t1);}

/* k1119 in k1102 in k3174 in a3164 in a3158 in a3130 in k3115 in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_1121(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1121,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1114,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 93   read-file */
((C_proc3)C_retrieve_symbol_proc(lf[237]))(3,*((C_word*)lf[237]+1),t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_2468(t2,C_SCHEME_END_OF_LIST);}}

/* k1112 in k1119 in k1102 in k3174 in a3164 in a3158 in a3130 in k3115 in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_1114(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[10] /* (set! main#*default-sources* ...) */,t1);
t3=((C_word*)t0)[2];
f_2468(t3,(C_word)C_i_pairp(C_retrieve2(lf[10],"main#*default-sources*")));}

/* k2466 in k3174 in a3164 in a3158 in a3130 in k3115 in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_fcall f_2468(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2468,NULL,2,t0,t1);}
t2=C_SCHEME_FALSE;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2473,a[2]=t5,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_2473(t7,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* loop in k2466 in k3174 in a3164 in a3158 in a3130 in k3115 in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_fcall f_2473(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2473,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t4=t1;
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2191,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2426,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2430,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 330  repository-path */
((C_proc2)C_retrieve_symbol_proc(lf[126]))(2,*((C_word*)lf[126]+1),t7);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2489,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2517,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 410  glob */
((C_proc3)C_retrieve_symbol_proc(lf[154]))(3,*((C_word*)lf[154]+1),t5,lf[192]);}
else{
t5=t4;
f_2489(2,t5,C_SCHEME_UNDEFINED);}}}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_string_equal_p(t4,lf[193]);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2563,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t2,a[6]=t4,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
if(C_truep(t5)){
t7=t6;
f_2563(t7,t5);}
else{
t7=(C_word)C_i_string_equal_p(t4,lf[235]);
t8=t6;
f_2563(t8,(C_truep(t7)?t7:(C_word)C_i_string_equal_p(t4,lf[236])));}}}

/* k2561 in loop in k2466 in k3174 in a3164 in a3158 in a3130 in k3115 in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_fcall f_2563(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2563,NULL,2,t0,t1);}
if(C_truep(t1)){
/* chicken-install.scm: 432  usage */
f_2454(((C_word*)t0)[7],C_fix(0));}
else{
if(C_truep((C_word)C_i_string_equal_p(((C_word*)t0)[6],lf[194]))){
t2=lf[2] /* main#*force* */ =C_SCHEME_TRUE;;
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* chicken-install.scm: 435  loop */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2473(t4,((C_word*)t0)[7],t3,((C_word*)t0)[3]);}
else{
t2=(C_word)C_i_string_equal_p(((C_word*)t0)[6],lf[195]);
t3=(C_truep(t2)?t2:(C_word)C_i_string_equal_p(((C_word*)t0)[6],lf[196]));
if(C_truep(t3)){
t4=lf[1] /* main#*keep* */ =C_SCHEME_TRUE;;
t5=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* chicken-install.scm: 438  loop */
t6=((C_word*)((C_word*)t0)[4])[1];
f_2473(t6,((C_word*)t0)[7],t5,((C_word*)t0)[3]);}
else{
t4=(C_word)C_i_string_equal_p(((C_word*)t0)[6],lf[197]);
t5=(C_truep(t4)?t4:(C_word)C_i_string_equal_p(((C_word*)t0)[6],lf[198]));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2609,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* chicken-install.scm: 440  setup-api#sudo-install */
((C_proc3)C_retrieve_symbol_proc(lf[177]))(3,*((C_word*)lf[177]+1),t6,C_SCHEME_TRUE);}
else{
t6=(C_word)C_i_string_equal_p(((C_word*)t0)[6],lf[199]);
t7=(C_truep(t6)?t6:(C_word)C_i_string_equal_p(((C_word*)t0)[6],lf[200]));
if(C_truep(t7)){
t8=lf[6] /* main#*retrieve-only* */ =C_SCHEME_TRUE;;
t9=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* chicken-install.scm: 444  loop */
t10=((C_word*)((C_word*)t0)[4])[1];
f_2473(t10,((C_word*)t0)[7],t9,((C_word*)t0)[3]);}
else{
t8=(C_word)C_i_string_equal_p(((C_word*)t0)[6],lf[201]);
t9=(C_truep(t8)?t8:(C_word)C_i_string_equal_p(((C_word*)t0)[6],lf[202]));
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2645,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t11=(C_word)C_i_cdr(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_pairp(t11))){
t12=t10;
f_2645(2,t12,C_SCHEME_UNDEFINED);}
else{
/* chicken-install.scm: 446  usage */
f_2454(t10,C_fix(1));}}
else{
t10=(C_word)C_i_string_equal_p(((C_word*)t0)[6],lf[203]);
t11=(C_truep(t10)?t10:(C_word)C_i_string_equal_p(((C_word*)t0)[6],lf[204]));
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2678,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t13=(C_word)C_i_cdr(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_pairp(t13))){
t14=t12;
f_2678(2,t14,C_SCHEME_UNDEFINED);}
else{
/* chicken-install.scm: 450  usage */
f_2454(t12,C_fix(1));}}
else{
t12=(C_word)C_i_string_equal_p(((C_word*)t0)[6],lf[205]);
t13=(C_truep(t12)?t12:(C_word)C_i_string_equal_p(((C_word*)t0)[6],lf[206]));
if(C_truep(t13)){
t14=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2715,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t15=(C_word)C_i_cdr(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_pairp(t15))){
t16=t14;
f_2715(2,t16,C_SCHEME_UNDEFINED);}
else{
/* chicken-install.scm: 454  usage */
f_2454(t14,C_fix(1));}}
else{
t14=(C_word)C_i_string_equal_p(((C_word*)t0)[6],lf[207]);
t15=(C_truep(t14)?t14:(C_word)C_i_string_equal_p(((C_word*)t0)[6],lf[208]));
if(C_truep(t15)){
t16=lf[1] /* main#*keep* */ =C_SCHEME_TRUE;;
t17=lf[7] /* main#*no-install* */ =C_SCHEME_TRUE;;
t18=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* chicken-install.scm: 460  loop */
t19=((C_word*)((C_word*)t0)[4])[1];
f_2473(t19,((C_word*)t0)[7],t18,((C_word*)t0)[3]);}
else{
t16=(C_word)C_i_string_equal_p(((C_word*)t0)[6],lf[209]);
t17=(C_truep(t16)?t16:(C_word)C_i_string_equal_p(((C_word*)t0)[6],lf[210]));
if(C_truep(t17)){
t18=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2766,a[2]=((C_word*)t0)[7],tmp=(C_word)a,a+=3,tmp);
t19=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2773,a[2]=t18,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 462  chicken-version */
((C_proc2)C_retrieve_symbol_proc(lf[19]))(2,*((C_word*)lf[19]+1),t19);}
else{
t18=(C_word)C_i_string_equal_p(((C_word*)t0)[6],lf[211]);
t19=(C_truep(t18)?t18:(C_word)C_i_string_equal_p(((C_word*)t0)[6],lf[212]));
if(C_truep(t19)){
t20=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_TRUE);
t21=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* chicken-install.scm: 466  loop */
t22=((C_word*)((C_word*)t0)[4])[1];
f_2473(t22,((C_word*)t0)[7],t21,((C_word*)t0)[3]);}
else{
t20=(C_word)C_i_string_equal_p(((C_word*)t0)[6],lf[213]);
t21=(C_truep(t20)?t20:(C_word)C_i_string_equal_p(((C_word*)t0)[6],lf[214]));
if(C_truep(t21)){
t22=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2802,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
t23=(C_word)C_i_cdr(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_pairp(t23))){
t24=t22;
f_2802(2,t24,C_SCHEME_UNDEFINED);}
else{
/* chicken-install.scm: 468  usage */
f_2454(t22,C_fix(1));}}
else{
if(C_truep((C_word)C_i_string_equal_p(lf[221],((C_word*)t0)[6]))){
t22=lf[5] /* main#*run-tests* */ =C_SCHEME_TRUE;;
t23=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* chicken-install.scm: 473  loop */
t24=((C_word*)((C_word*)t0)[4])[1];
f_2473(t24,((C_word*)t0)[7],t23,((C_word*)t0)[3]);}
else{
if(C_truep((C_word)C_i_string_equal_p(lf[222],((C_word*)t0)[6]))){
t22=lf[4] /* main#*host-extension* */ =C_SCHEME_TRUE;;
t23=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* chicken-install.scm: 476  loop */
t24=((C_word*)((C_word*)t0)[4])[1];
f_2473(t24,((C_word*)t0)[7],t23,((C_word*)t0)[3]);}
else{
if(C_truep((C_word)C_i_string_equal_p(lf[223],((C_word*)t0)[6]))){
t22=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2859,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t23=(C_word)C_i_cdr(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_pairp(t23))){
t24=t22;
f_2859(2,t24,C_SCHEME_UNDEFINED);}
else{
/* chicken-install.scm: 478  usage */
f_2454(t22,C_fix(1));}}
else{
if(C_truep((C_word)C_i_string_equal_p(lf[224],((C_word*)t0)[6]))){
t22=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2889,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t23=(C_word)C_i_cdr(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_pairp(t23))){
t24=t22;
f_2889(2,t24,C_SCHEME_UNDEFINED);}
else{
/* chicken-install.scm: 482  usage */
f_2454(t22,C_fix(1));}}
else{
t22=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2916,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t23=(C_word)C_i_string_length(((C_word*)t0)[6]);
if(C_truep((C_word)C_i_positivep(t23))){
t24=(C_word)C_i_string_ref(((C_word*)t0)[6],C_fix(0));
t25=t22;
f_2916(t25,(C_word)C_eqp(C_make_character(45),t24));}
else{
t24=t22;
f_2916(t24,C_SCHEME_FALSE);}}}}}}}}}}}}}}}}}}

/* k2914 in k2561 in loop in k2466 in k3174 in a3164 in a3158 in a3130 in k3115 in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_fcall f_2916(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2916,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_string_length(((C_word*)t0)[6]);
if(C_truep((C_word)C_i_greaterp(t2,C_fix(2)))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2925,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2963,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 488  substring */
((C_proc4)C_retrieve_proc(*((C_word*)lf[228]+1)))(4,*((C_word*)lf[228]+1),t4,((C_word*)t0)[6],C_fix(1));}
else{
/* chicken-install.scm: 492  usage */
f_2454(((C_word*)t0)[4],C_fix(1));}}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3061,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
/* chicken-install.scm: 493  pathname-extension */
((C_proc3)C_retrieve_symbol_proc(lf[234]))(3,*((C_word*)lf[234]+1),t2,((C_word*)t0)[6]);}}

/* k3059 in k2914 in k2561 in loop in k2466 in k3174 in a3164 in a3158 in a3130 in k3115 in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_3061(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3061,2,t0,t1);}
if(C_truep((C_word)C_i_equalp(lf[229],t1))){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2979,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* chicken-install.scm: 494  pathname-file */
((C_proc3)C_retrieve_symbol_proc(lf[190]))(3,*((C_word*)lf[190]+1),t2,((C_word*)t0)[2]);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3024,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* chicken-install.scm: 508  string-match */
((C_proc4)C_retrieve_symbol_proc(lf[148]))(4,*((C_word*)lf[148]+1),t2,lf[233],((C_word*)t0)[2]);}}

/* k3022 in k3059 in k2914 in k2561 in loop in k2466 in k3174 in a3164 in a3158 in a3130 in k3115 in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_3024(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3024,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3038,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_cadr(t1);
t5=(C_word)C_i_caddr(t1);
/* chicken-install.scm: 510  alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[32]))(5,*((C_word*)lf[32]+1),t3,t4,t5,((C_word*)t0)[3]);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[6]);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)t0)[3]);
/* chicken-install.scm: 511  loop */
t4=((C_word*)((C_word*)t0)[5])[1];
f_2473(t4,((C_word*)t0)[4],t2,t3);}}

/* k3036 in k3022 in k3059 in k2914 in k2561 in loop in k2466 in k3174 in a3164 in a3158 in a3130 in k3115 in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_3038(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 510  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_2473(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2977 in k3059 in k2914 in k2561 in loop in k2466 in k3174 in a3164 in a3158 in a3130 in k3115 in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_2979(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2979,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2983,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3002,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm: 499  pathname-directory */
((C_proc3)C_retrieve_symbol_proc(lf[232]))(3,*((C_word*)lf[232]+1),t3,((C_word*)t0)[2]);}

/* k3000 in k2977 in k3059 in k2914 in k2561 in loop in k2466 in k3174 in a3164 in a3158 in a3130 in k3115 in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_3002(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3002,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3005,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3011,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm: 501  absolute-pathname? */
((C_proc3)C_retrieve_symbol_proc(lf[231]))(3,*((C_word*)lf[231]+1),t3,t1);}
else{
/* chicken-install.scm: 504  current-directory */
((C_proc2)C_retrieve_symbol_proc(lf[103]))(2,*((C_word*)lf[103]+1),t2);}}

/* k3009 in k3000 in k2977 in k3059 in k2914 in k2561 in loop in k2466 in k3174 in a3164 in a3158 in a3130 in k3115 in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_3011(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3011,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_3005(2,t2,((C_word*)t0)[2]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3018,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm: 503  current-directory */
((C_proc2)C_retrieve_symbol_proc(lf[103]))(2,*((C_word*)lf[103]+1),t2);}}

/* k3016 in k3009 in k3000 in k2977 in k3059 in k2914 in k2561 in loop in k2466 in k3174 in a3164 in a3158 in a3130 in k3115 in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_3018(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 503  make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[77]))(4,*((C_word*)lf[77]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3003 in k3000 in k2977 in k3059 in k2914 in k2561 in loop in k2466 in k3174 in a3164 in a3158 in a3130 in k3115 in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_3005(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3005,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,lf[230]);
/* chicken-install.scm: 496  alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[32]))(5,*((C_word*)lf[32]+1),((C_word*)t0)[3],((C_word*)t0)[2],t2,C_retrieve2(lf[26],"main#*eggs+dirs+vers*"));}

/* k2981 in k2977 in k3059 in k2914 in k2561 in loop in k2466 in k3174 in a3164 in a3158 in a3130 in k3115 in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_2983(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2983,2,t0,t1);}
t2=C_mutate(&lf[26] /* (set! main#*eggs+dirs+vers* ...) */,t1);
t3=(C_word)C_i_cdr(((C_word*)t0)[6]);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[4]);
/* chicken-install.scm: 507  loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_2473(t5,((C_word*)t0)[2],t3,t4);}

/* k2961 in k2914 in k2561 in loop in k2466 in k3174 in a3164 in a3158 in a3130 in k3115 in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_2963(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* string->list */
t2=C_retrieve(lf[227]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2923 in k2914 in k2561 in loop in k2466 in k3174 in a3164 in a3158 in a3130 in k3115 in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_2925(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2925,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2959,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* chicken-install.scm: 489  lset-intersection */
((C_proc5)C_retrieve_symbol_proc(lf[225]))(5,*((C_word*)lf[225]+1),t2,*((C_word*)lf[80]+1),lf[226],t1);}

/* k2957 in k2923 in k2914 in k2561 in loop in k2466 in k3174 in a3164 in a3158 in a3130 in k3115 in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_2959(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2959,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2938,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2942,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2948,tmp=(C_word)a,a+=2,tmp);
/* map */
t5=*((C_word*)lf[66]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}
else{
/* chicken-install.scm: 491  usage */
f_2454(((C_word*)t0)[5],C_fix(1));}}

/* a2947 in k2957 in k2923 in k2914 in k2561 in loop in k2466 in k3174 in a3164 in a3158 in a3130 in k3115 in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_2948(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2948,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_string(&a,2,C_make_character(45),t2));}

/* k2940 in k2957 in k2923 in k2914 in k2561 in loop in k2466 in k3174 in a3164 in a3158 in a3130 in k3115 in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_2942(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* chicken-install.scm: 490  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[43]+1)))(4,*((C_word*)lf[43]+1),((C_word*)t0)[2],t1,t2);}

/* k2936 in k2957 in k2923 in k2914 in k2561 in loop in k2466 in k3174 in a3164 in a3158 in a3130 in k3115 in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_2938(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 490  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_2473(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2887 in k2561 in loop in k2466 in k3174 in a3164 in a3158 in a3130 in k3115 in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_2889(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=C_mutate(&lf[9] /* (set! main#*password* ...) */,t2);
t4=(C_word)C_i_cddr(((C_word*)t0)[5]);
/* chicken-install.scm: 484  loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_2473(t5,((C_word*)t0)[3],t4,((C_word*)t0)[2]);}

/* k2857 in k2561 in loop in k2466 in k3174 in a3164 in a3158 in a3130 in k3115 in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_2859(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=C_mutate(&lf[8] /* (set! main#*username* ...) */,t2);
t4=(C_word)C_i_cddr(((C_word*)t0)[5]);
/* chicken-install.scm: 480  loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_2473(t5,((C_word*)t0)[3],t4,((C_word*)t0)[2]);}

/* k2800 in k2561 in loop in k2466 in k3174 in a3164 in a3158 in a3130 in k3115 in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_2802(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2802,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2805,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[2]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1189,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm: 111  repository-path */
((C_proc2)C_retrieve_symbol_proc(lf[126]))(2,*((C_word*)lf[126]+1),t4);}

/* k1187 in k2800 in k2561 in loop in k2466 in k3174 in a3164 in a3158 in a3130 in k3115 in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_1189(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1189,2,t0,t1);}
t2=(C_truep(C_retrieve2(lf[14],"main#*windows-shell*"))?lf[215]:lf[216]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1195,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken-install.scm: 115  print */
((C_proc5)C_retrieve_proc(*((C_word*)lf[46]+1)))(5,*((C_word*)lf[46]+1),t3,lf[219],((C_word*)t0)[3],lf[220]);}

/* k1193 in k1187 in k2800 in k2561 in loop in k2466 in k3174 in a3164 in a3158 in a3130 in k3115 in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_1195(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1195,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1200,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* for-each */
t3=*((C_word*)lf[49]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t2,lf[218]);}

/* a1199 in k1193 in k1187 in k2800 in k2561 in loop in k2466 in k3174 in a3164 in a3158 in a3130 in k3115 in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_1200(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1200,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1208,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1212,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1220,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 118  make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[77]))(4,*((C_word*)lf[77]+1),t5,((C_word*)t0)[2],t2);}

/* k1218 in a1199 in k1193 in k1187 in k2800 in k2561 in loop in k2466 in k3174 in a3164 in a3158 in a3130 in k3115 in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_1220(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 118  setup-api#shellpath */
((C_proc3)C_retrieve_symbol_proc(lf[173]))(3,*((C_word*)lf[173]+1),((C_word*)t0)[2],t1);}

/* k1210 in a1199 in k1193 in k1187 in k2800 in k2561 in loop in k2466 in k3174 in a3164 in a3158 in a3130 in k3115 in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_1212(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1212,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1216,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken-install.scm: 118  setup-api#shellpath */
((C_proc3)C_retrieve_symbol_proc(lf[173]))(3,*((C_word*)lf[173]+1),t2,((C_word*)t0)[2]);}

/* k1214 in k1210 in a1199 in k1193 in k1187 in k2800 in k2561 in loop in k2466 in k3174 in a3164 in a3158 in a3130 in k3115 in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_1216(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 118  sprintf */
((C_proc6)C_retrieve_symbol_proc(lf[143]))(6,*((C_word*)lf[143]+1),((C_word*)t0)[4],lf[217],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1206 in a1199 in k1193 in k1187 in k2800 in k2561 in loop in k2466 in k3174 in a3164 in a3158 in a3130 in k3115 in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_1208(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 118  $system */
f_2432(((C_word*)t0)[2],t1);}

/* k2803 in k2800 in k2561 in loop in k2466 in k3174 in a3164 in a3158 in a3130 in k3115 in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_2805(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 470  exit */
((C_proc3)C_retrieve_symbol_proc(lf[121]))(3,*((C_word*)lf[121]+1),((C_word*)t0)[2],C_fix(0));}

/* k2771 in k2561 in loop in k2466 in k3174 in a3164 in a3158 in a3130 in k3115 in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_2773(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 462  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[46]+1)))(3,*((C_word*)lf[46]+1),((C_word*)t0)[2],t1);}

/* k2764 in k2561 in loop in k2466 in k3174 in a3164 in a3158 in a3130 in k3115 in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_2766(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 463  exit */
((C_proc3)C_retrieve_symbol_proc(lf[121]))(3,*((C_word*)lf[121]+1),((C_word*)t0)[2],C_fix(0));}

/* k2713 in k2561 in loop in k2466 in k3174 in a3164 in a3158 in a3130 in k3115 in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_2715(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=C_mutate(&lf[3] /* (set! main#*prefix* ...) */,t2);
t4=(C_word)C_i_cddr(((C_word*)t0)[5]);
/* chicken-install.scm: 456  loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_2473(t5,((C_word*)t0)[3],t4,((C_word*)t0)[2]);}

/* k2676 in k2561 in loop in k2466 in k3174 in a3164 in a3158 in a3130 in k3115 in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_2678(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2678,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2682,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* chicken-install.scm: 451  string->symbol */
((C_proc3)C_retrieve_proc(*((C_word*)lf[147]+1)))(3,*((C_word*)lf[147]+1),t2,t3);}

/* k2680 in k2676 in k2561 in loop in k2466 in k3174 in a3164 in a3158 in a3130 in k3115 in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_2682(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(&lf[12] /* (set! main#*default-transport* ...) */,t1);
t3=(C_word)C_i_cddr(((C_word*)t0)[5]);
/* chicken-install.scm: 452  loop */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2473(t4,((C_word*)t0)[3],t3,((C_word*)t0)[2]);}

/* k2643 in k2561 in loop in k2466 in k3174 in a3164 in a3158 in a3130 in k3115 in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_2645(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=C_mutate(&lf[11] /* (set! main#*default-location* ...) */,t2);
t4=(C_word)C_i_cddr(((C_word*)t0)[5]);
/* chicken-install.scm: 448  loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_2473(t5,((C_word*)t0)[3],t4,((C_word*)t0)[2]);}

/* k2607 in k2561 in loop in k2466 in k3174 in a3164 in a3158 in a3130 in k3115 in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_2609(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* chicken-install.scm: 441  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2473(t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k2515 in loop in k2466 in k3174 in a3164 in a3158 in a3130 in k3115 in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_2517(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2517,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2527,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2531,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2533,tmp=(C_word)a,a+=2,tmp);
/* map */
t5=*((C_word*)lf[66]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2548,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 419  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[46]+1)))(3,*((C_word*)lf[46]+1),t2,lf[191]);}}

/* k2546 in k2515 in loop in k2466 in k3174 in a3164 in a3158 in a3130 in k3115 in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_2548(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 420  exit */
((C_proc3)C_retrieve_symbol_proc(lf[121]))(3,*((C_word*)lf[121]+1),((C_word*)t0)[2],C_fix(1));}

/* a2532 in k2515 in loop in k2466 in k3174 in a3164 in a3158 in a3130 in k3115 in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_2533(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2533,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2541,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 415  pathname-file */
((C_proc3)C_retrieve_symbol_proc(lf[190]))(3,*((C_word*)lf[190]+1),t3,t2);}

/* k2539 in a2532 in k2515 in loop in k2466 in k3174 in a3164 in a3158 in a3130 in k3115 in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_2541(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2541,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[188],lf[189]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,t1,t2));}

/* k2529 in k2515 in loop in k2466 in k3174 in a3164 in a3158 in a3130 in k3115 in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_2531(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 413  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[43]+1)))(4,*((C_word*)lf[43]+1),((C_word*)t0)[2],t1,C_retrieve2(lf[26],"main#*eggs+dirs+vers*"));}

/* k2525 in k2515 in loop in k2466 in k3174 in a3164 in a3158 in a3130 in k3115 in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_2527(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[26] /* (set! main#*eggs+dirs+vers* ...) */,t1);
t3=((C_word*)t0)[2];
f_2489(2,t3,t2);}

/* k2487 in loop in k2466 in k3174 in a3164 in a3158 in a3130 in k3115 in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_2489(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2489,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2492,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=t2;
f_2492(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2502,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[12],"main#*default-transport*"))){
t4=t3;
f_2502(2,t4,C_SCHEME_UNDEFINED);}
else{
/* chicken-install.scm: 423  error */
((C_proc3)C_retrieve_proc(*((C_word*)lf[34]+1)))(3,*((C_word*)lf[34]+1),t3,lf[187]);}}}

/* k2500 in k2487 in loop in k2466 in k3174 in a3164 in a3158 in a3130 in k3115 in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_2502(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(C_retrieve2(lf[11],"main#*default-location*"))){
t2=((C_word*)t0)[2];
f_2492(2,t2,C_SCHEME_UNDEFINED);}
else{
/* chicken-install.scm: 425  error */
((C_proc3)C_retrieve_proc(*((C_word*)lf[34]+1)))(3,*((C_word*)lf[34]+1),((C_word*)t0)[2],lf[186]);}}

/* k2490 in k2487 in loop in k2466 in k3174 in a3164 in a3158 in a3130 in k3115 in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_2492(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2492,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2499,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 426  reverse */
((C_proc3)C_retrieve_proc(*((C_word*)lf[31]+1)))(3,*((C_word*)lf[31]+1),t2,((C_word*)t0)[2]);}

/* k2497 in k2490 in k2487 in loop in k2466 in k3174 in a3164 in a3158 in a3130 in k3115 in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_2499(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2499,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2056,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 301  retrieve */
f_1766(t3,t1);}

/* k2054 in k2497 in k2490 in k2487 in loop in k2466 in k3174 in a3164 in a3158 in a3130 in k3115 in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_2056(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2056,2,t0,t1);}
if(C_truep(C_retrieve2(lf[6],"main#*retrieve-only*"))){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2062,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2170,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 303  topological-sort */
((C_proc4)C_retrieve_symbol_proc(lf[184]))(4,*((C_word*)lf[184]+1),t3,C_retrieve2(lf[27],"main#*dependencies*"),*((C_word*)lf[185]+1));}}

/* k2168 in k2054 in k2497 in k2490 in k2487 in loop in k2466 in k3174 in a3164 in a3158 in a3130 in k3115 in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_2170(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 303  reverse */
((C_proc3)C_retrieve_proc(*((C_word*)lf[31]+1)))(3,*((C_word*)lf[31]+1),((C_word*)t0)[2],t1);}

/* k2060 in k2054 in k2497 in k2490 in k2487 in loop in k2466 in k3174 in a3164 in a3158 in a3130 in k3115 in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_2062(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2062,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2065,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm: 304  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[46]+1)))(3,*((C_word*)lf[46]+1),t2,lf[183]);}

/* k2063 in k2060 in k2054 in k2497 in k2490 in k2487 in loop in k2466 in k3174 in a3164 in a3158 in a3130 in k3115 in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_2065(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2065,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2068,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm: 305  pp */
((C_proc3)C_retrieve_symbol_proc(lf[182]))(3,*((C_word*)lf[182]+1),t2,((C_word*)t0)[2]);}

/* k2066 in k2063 in k2060 in k2054 in k2497 in k2490 in k2487 in loop in k2466 in k3174 in a3164 in a3158 in a3130 in k3115 in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_2068(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2068,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2073,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2160,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2162,tmp=(C_word)a,a+=2,tmp);
/* map */
t5=*((C_word*)lf[66]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a2161 in k2066 in k2063 in k2060 in k2054 in k2497 in k2490 in k2487 in loop in k2466 in k3174 in a3164 in a3158 in a3130 in k3115 in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_2162(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2162,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_assoc(t2,C_retrieve2(lf[26],"main#*eggs+dirs+vers*")));}

/* k2158 in k2066 in k2063 in k2060 in k2054 in k2497 in k2490 in k2487 in loop in k2466 in k3174 in a3164 in a3158 in a3130 in k3115 in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_2160(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[49]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2072 in k2066 in k2063 in k2060 in k2054 in k2497 in k2490 in k2487 in loop in k2466 in k3174 in a3164 in a3158 in a3130 in k3115 in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_2073(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2073,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2077,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_caddr(t2);
/* chicken-install.scm: 308  print */
((C_proc7)C_retrieve_proc(*((C_word*)lf[46]+1)))(7,*((C_word*)lf[46]+1),t3,lf[180],t4,C_make_character(58),t5,lf[181]);}

/* k2075 in a2072 in k2066 in k2063 in k2060 in k2054 in k2497 in k2490 in k2487 in loop in k2466 in k3174 in a3164 in a3158 in a3130 in k3115 in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_2077(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2077,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2080,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[3]);
/* chicken-install.scm: 309  print */
((C_proc4)C_retrieve_proc(*((C_word*)lf[46]+1)))(4,*((C_word*)lf[46]+1),t2,lf[179],t3);}

/* k2078 in k2075 in a2072 in k2066 in k2063 in k2060 in k2054 in k2497 in k2490 in k2487 in loop in k2466 in k3174 in a3164 in a3158 in a3130 in k3115 in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_2080(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2080,2,t0,t1);}
t2=C_retrieve(lf[103]);
t3=(C_word)C_i_cadr(((C_word*)t0)[3]);
t4=t3;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2084,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2097,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* ##sys#dynamic-wind */
t8=*((C_word*)lf[149]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,((C_word*)t0)[2],t6,t7,t6);}

/* a2096 in k2078 in k2075 in a2072 in k2066 in k2063 in k2060 in k2054 in k2497 in k2490 in k2487 in loop in k2466 in k3174 in a3164 in a3158 in a3130 in k3115 in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_2097(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2097,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2101,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[2];
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2000,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_car(t3);
t6=(C_word)C_i_caddr(t3);
/* chicken-install.scm: 292  sprintf */
((C_proc5)C_retrieve_symbol_proc(lf[143]))(5,*((C_word*)lf[143]+1),t4,lf[178],t5,t6);}

/* k1998 in a2096 in k2078 in k2075 in a2072 in k2066 in k2063 in k2060 in k2054 in k2497 in k2490 in k2487 in loop in k2466 in k3174 in a3164 in a3158 in a3130 in k3115 in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_2000(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2000,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2042,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* chicken-install.scm: 293  setup-api#sudo-install */
((C_proc2)C_retrieve_symbol_proc(lf[177]))(2,*((C_word*)lf[177]+1),t2);}

/* k2040 in k1998 in a2096 in k2078 in k2075 in a2072 in k2066 in k2063 in k2060 in k2054 in k2497 in k2490 in k2487 in loop in k2466 in k3174 in a3164 in a3158 in a3130 in k3115 in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_2042(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2042,2,t0,t1);}
t2=(C_truep(t1)?lf[164]:lf[165]);
t3=(C_truep(C_retrieve2(lf[1],"main#*keep*"))?lf[166]:lf[167]);
t4=(C_truep(C_retrieve2(lf[7],"main#*no-install*"))?lf[168]:lf[169]);
t5=(C_truep(C_retrieve2(lf[4],"main#*host-extension*"))?lf[170]:lf[171]);
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2020,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=t4,a[5]=t3,a[6]=t2,a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[4],tmp=(C_word)a,a+=9,tmp);
if(C_truep(C_retrieve2(lf[3],"main#*prefix*"))){
/* chicken-install.scm: 297  sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[143]))(4,*((C_word*)lf[143]+1),t6,lf[175],C_retrieve2(lf[3],"main#*prefix*"));}
else{
t7=t6;
f_2020(2,t7,lf[176]);}}

/* k2018 in k2040 in k1998 in a2096 in k2078 in k2075 in a2072 in k2066 in k2063 in k2060 in k2054 in k2497 in k2490 in k2487 in loop in k2466 in k3174 in a3164 in a3158 in a3130 in k3115 in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_2020(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2020,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2024,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2028,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_cadr(((C_word*)t0)[2]);
t5=(C_word)C_i_car(((C_word*)t0)[2]);
/* chicken-install.scm: 298  make-pathname */
((C_proc5)C_retrieve_symbol_proc(lf[77]))(5,*((C_word*)lf[77]+1),t3,t4,t5,lf[174]);}

/* k2026 in k2018 in k2040 in k1998 in a2096 in k2078 in k2075 in a2072 in k2066 in k2063 in k2060 in k2054 in k2497 in k2490 in k2487 in loop in k2466 in k3174 in a3164 in a3158 in a3130 in k3115 in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_2028(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 298  setup-api#shellpath */
((C_proc3)C_retrieve_symbol_proc(lf[173]))(3,*((C_word*)lf[173]+1),((C_word*)t0)[2],t1);}

/* k2022 in k2018 in k2040 in k1998 in a2096 in k2078 in k2075 in a2072 in k2066 in k2063 in k2060 in k2054 in k2497 in k2490 in k2487 in loop in k2466 in k3174 in a3164 in a3158 in a3130 in k3115 in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_2024(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 289  conc */
((C_proc12)C_retrieve_symbol_proc(lf[61]))(12,*((C_word*)lf[61]+1),((C_word*)t0)[8],C_retrieve2(lf[29],"main#*csi*"),lf[172],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],C_make_character(32),t1);}

/* k2099 in a2096 in k2078 in k2075 in a2072 in k2066 in k2063 in k2060 in k2054 in k2497 in k2490 in k2487 in loop in k2466 in k3174 in a3164 in a3158 in a3130 in k3115 in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_2101(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2101,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2104,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* chicken-install.scm: 312  print */
((C_proc4)C_retrieve_proc(*((C_word*)lf[46]+1)))(4,*((C_word*)lf[46]+1),t2,lf[163],t1);}

/* k2102 in k2099 in a2096 in k2078 in k2075 in a2072 in k2066 in k2063 in k2060 in k2054 in k2497 in k2490 in k2487 in loop in k2466 in k3174 in a3164 in a3158 in a3130 in k3115 in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_2104(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2104,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2107,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm: 313  $system */
f_2432(t2,((C_word*)t0)[2]);}

/* k2105 in k2102 in k2099 in a2096 in k2078 in k2075 in a2072 in k2066 in k2063 in k2060 in k2054 in k2497 in k2490 in k2487 in loop in k2466 in k3174 in a3164 in a3158 in a3130 in k3115 in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_2107(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2107,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2113,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[5],"main#*run-tests*"))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2135,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 315  file-exists? */
((C_proc3)C_retrieve_symbol_proc(lf[76]))(3,*((C_word*)lf[76]+1),t3,lf[162]);}
else{
t3=t2;
f_2113(2,t3,C_SCHEME_FALSE);}}

/* k2133 in k2105 in k2102 in k2099 in a2096 in k2078 in k2075 in a2072 in k2066 in k2063 in k2060 in k2054 in k2497 in k2490 in k2487 in loop in k2466 in k3174 in a3164 in a3158 in a3130 in k3115 in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_2135(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2135,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2141,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 316  directory? */
((C_proc3)C_retrieve_symbol_proc(lf[160]))(3,*((C_word*)lf[160]+1),t2,lf[161]);}
else{
t2=((C_word*)t0)[2];
f_2113(2,t2,C_SCHEME_FALSE);}}

/* k2139 in k2133 in k2105 in k2102 in k2099 in a2096 in k2078 in k2075 in a2072 in k2066 in k2063 in k2060 in k2054 in k2497 in k2490 in k2487 in loop in k2466 in k3174 in a3164 in a3158 in a3130 in k3115 in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_2141(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* chicken-install.scm: 317  file-exists? */
((C_proc3)C_retrieve_symbol_proc(lf[76]))(3,*((C_word*)lf[76]+1),((C_word*)t0)[2],lf[159]);}
else{
t2=((C_word*)t0)[2];
f_2113(2,t2,C_SCHEME_FALSE);}}

/* k2111 in k2105 in k2102 in k2099 in a2096 in k2078 in k2075 in a2072 in k2066 in k2063 in k2060 in k2054 in k2497 in k2490 in k2487 in loop in k2466 in k3174 in a3164 in a3158 in a3130 in k3115 in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_2113(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2113,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2116,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm: 318  current-directory */
((C_proc3)C_retrieve_symbol_proc(lf[103]))(3,*((C_word*)lf[103]+1),t2,lf[158]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k2114 in k2111 in k2105 in k2102 in k2099 in a2096 in k2078 in k2075 in a2072 in k2066 in k2063 in k2060 in k2054 in k2497 in k2490 in k2487 in loop in k2466 in k3174 in a3164 in a3158 in a3130 in k3115 in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_2116(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2116,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2119,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[2]);
/* chicken-install.scm: 319  sprintf */
((C_proc5)C_retrieve_symbol_proc(lf[143]))(5,*((C_word*)lf[143]+1),t2,lf[157],C_retrieve2(lf[29],"main#*csi*"),t3);}

/* k2117 in k2114 in k2111 in k2105 in k2102 in k2099 in a2096 in k2078 in k2075 in a2072 in k2066 in k2063 in k2060 in k2054 in k2497 in k2490 in k2487 in loop in k2466 in k3174 in a3164 in a3158 in a3130 in k3115 in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_2119(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2119,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2122,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm: 320  print */
((C_proc4)C_retrieve_proc(*((C_word*)lf[46]+1)))(4,*((C_word*)lf[46]+1),t2,lf[156],t1);}

/* k2120 in k2117 in k2114 in k2111 in k2105 in k2102 in k2099 in a2096 in k2078 in k2075 in a2072 in k2066 in k2063 in k2060 in k2054 in k2497 in k2490 in k2487 in loop in k2466 in k3174 in a3164 in a3158 in a3130 in k3115 in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_2122(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 321  $system */
f_2432(((C_word*)t0)[3],((C_word*)t0)[2]);}

/* swap584 in k2078 in k2075 in a2072 in k2066 in k2063 in k2060 in k2054 in k2497 in k2490 in k2487 in loop in k2466 in k3174 in a3164 in a3158 in a3130 in k3115 in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_2084(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2084,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2088,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* g587588591 */
t3=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k2086 in swap584 in k2078 in k2075 in a2072 in k2066 in k2063 in k2060 in k2054 in k2497 in k2490 in k2487 in loop in k2466 in k3174 in a3164 in a3158 in a3130 in k3115 in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_2088(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2088,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2091,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* g587588591 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)((C_word*)t0)[4])[1]);}

/* k2089 in k2086 in swap584 in k2078 in k2075 in a2072 in k2066 in k2063 in k2060 in k2054 in k2497 in k2490 in k2487 in loop in k2466 in k3174 in a3164 in a3158 in a3130 in k3115 in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_2091(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2428 in loop in k2466 in k3174 in a3164 in a3158 in a3130 in k3115 in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_2430(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 330  make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[77]))(4,*((C_word*)lf[77]+1),((C_word*)t0)[2],t1,lf[155]);}

/* k2424 in loop in k2466 in k3174 in a3164 in a3158 in a3130 in k3115 in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_2426(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 330  glob */
((C_proc3)C_retrieve_symbol_proc(lf[154]))(3,*((C_word*)lf[154]+1),((C_word*)t0)[2],t1);}

/* k2189 in loop in k2466 in k3174 in a3164 in a3158 in a3130 in k3115 in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_2191(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2191,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2194,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm: 331  setup-api#create-temporary-directory */
((C_proc2)C_retrieve_symbol_proc(lf[153]))(2,*((C_word*)lf[153]+1),t2);}

/* k2192 in k2189 in loop in k2466 in k3174 in a3164 in a3158 in a3130 in k3115 in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_2194(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2194,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2197,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* chicken-install.scm: 332  make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[77]))(4,*((C_word*)lf[77]+1),t2,t1,C_retrieve2(lf[15],"main#constant220"));}

/* k2195 in k2192 in k2189 in loop in k2466 in k3174 in a3164 in a3158 in a3130 in k3115 in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_2197(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2197,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2200,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* chicken-install.scm: 333  regexp */
((C_proc3)C_retrieve_symbol_proc(lf[151]))(3,*((C_word*)lf[151]+1),t2,lf[152]);}

/* k2198 in k2195 in k2192 in k2189 in loop in k2466 in k3174 in a3164 in a3158 in a3130 in k3115 in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_2200(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2200,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2203,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* chicken-install.scm: 334  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[46]+1)))(3,*((C_word*)lf[46]+1),t2,lf[150]);}

/* k2201 in k2198 in k2195 in k2192 in k2189 in loop in k2466 in k3174 in a3164 in a3158 in a3130 in k3115 in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_2203(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[21],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2203,2,t0,t1);}
t2=C_SCHEME_FALSE;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2206,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2330,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2335,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2419,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* ##sys#dynamic-wind */
t10=*((C_word*)lf[149]+1);
((C_proc5)(void*)(*((C_word*)t10+1)))(5,t10,t6,t7,t8,t9);}

/* a2418 in k2201 in k2198 in k2195 in k2192 in k2189 in loop in k2466 in k3174 in a3164 in a3158 in a3130 in k3115 in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_2419(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2419,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,C_retrieve(lf[142]));
t3=C_mutate((C_word*)lf[142]+1 /* (set! warnings-enabled ...) */,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* a2334 in k2201 in k2198 in k2195 in k2192 in k2189 in loop in k2466 in k3174 in a3164 in a3158 in a3130 in k3115 in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_2335(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2335,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2341,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* for-each */
t3=*((C_word*)lf[49]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,((C_word*)t0)[2]);}

/* a2340 in a2334 in k2201 in k2198 in k2195 in k2192 in k2189 in loop in k2466 in k3174 in a3164 in a3158 in a3130 in k3115 in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_2341(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2341,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2345,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm: 338  string-match */
((C_proc4)C_retrieve_symbol_proc(lf[148]))(4,*((C_word*)lf[148]+1),t3,((C_word*)t0)[2],t2);}

/* k2343 in a2340 in a2334 in k2201 in k2198 in k2195 in k2192 in k2189 in loop in k2466 in k3174 in a3164 in a3158 in a3130 in k3115 in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_2345(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2345,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2351,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2353,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* call-with-current-continuation */
((C_proc3)C_retrieve_proc(*((C_word*)lf[105]+1)))(3,*((C_word*)lf[105]+1),t2,t3);}

/* a2352 in k2343 in a2340 in a2334 in k2201 in k2198 in k2195 in k2192 in k2189 in loop in k2466 in k3174 in a3164 in a3158 in a3130 in k3115 in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_2353(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2353,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2359,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2379,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* with-exception-handler */
((C_proc4)C_retrieve_symbol_proc(lf[104]))(4,*((C_word*)lf[104]+1),t1,t3,t4);}

/* a2378 in a2352 in k2343 in a2340 in a2334 in k2201 in k2198 in k2195 in k2192 in k2189 in loop in k2466 in k3174 in a3164 in a3158 in a3130 in k3115 in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_2379(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2379,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2385,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2407,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a2406 in a2378 in a2352 in k2343 in a2340 in a2334 in k2201 in k2198 in k2195 in k2192 in k2189 in loop in k2466 in k3174 in a3164 in a3158 in a3130 in k3115 in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_2407(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_2407r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2407r(t0,t1,t2);}}

static void C_ccall f_2407r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2413,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* k668674 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a2412 in a2406 in a2378 in a2352 in k2343 in a2340 in a2334 in k2201 in k2198 in k2195 in k2192 in k2189 in loop in k2466 in k3174 in a3164 in a3158 in a3130 in k3115 in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_2413(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2413,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a2384 in a2378 in a2352 in k2343 in a2340 in a2334 in k2201 in k2198 in k2195 in k2192 in k2189 in loop in k2466 in k3174 in a3164 in a3158 in a3130 in k3115 in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_2385(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2385,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2401,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[2]);
/* chicken-install.scm: 343  string->symbol */
((C_proc3)C_retrieve_proc(*((C_word*)lf[147]+1)))(3,*((C_word*)lf[147]+1),t2,t3);}

/* k2399 in a2384 in a2378 in a2352 in k2343 in a2340 in a2334 in k2201 in k2198 in k2195 in k2192 in k2189 in loop in k2466 in k3174 in a3164 in a3158 in a3130 in k3115 in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_2401(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2401,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[145],t2);
/* chicken-install.scm: 343  eval */
((C_proc3)C_retrieve_symbol_proc(lf[146]))(3,*((C_word*)lf[146]+1),((C_word*)t0)[2],t3);}

/* a2358 in a2352 in k2343 in a2340 in a2334 in k2201 in k2198 in k2195 in k2192 in k2189 in loop in k2466 in k3174 in a3164 in a3158 in a3130 in k3115 in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_2359(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2359,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2365,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* k668674 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a2364 in a2358 in a2352 in k2343 in a2340 in a2334 in k2201 in k2198 in k2195 in k2192 in k2189 in loop in k2466 in k3174 in a3164 in a3158 in a3130 in k3115 in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_2365(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2365,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2373,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* chicken-install.scm: 341  current-error-port */
((C_proc2)C_retrieve_symbol_proc(lf[124]))(2,*((C_word*)lf[124]+1),t2);}

/* k2371 in a2364 in a2358 in a2352 in k2343 in a2340 in a2334 in k2201 in k2198 in k2195 in k2192 in k2189 in loop in k2466 in k3174 in a3164 in a3158 in a3130 in k3115 in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_2373(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2373,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2377,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken-install.scm: 342  sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[143]))(4,*((C_word*)lf[143]+1),t2,lf[144],((C_word*)t0)[2]);}

/* k2375 in k2371 in a2364 in a2358 in a2352 in k2343 in a2340 in a2334 in k2201 in k2198 in k2195 in k2192 in k2189 in loop in k2466 in k3174 in a3164 in a3158 in a3130 in k3115 in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_2377(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 340  print-error-message */
((C_proc5)C_retrieve_symbol_proc(lf[90]))(5,*((C_word*)lf[90]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2349 in k2343 in a2340 in a2334 in k2201 in k2198 in k2195 in k2192 in k2189 in loop in k2466 in k3174 in a3164 in a3158 in a3130 in k3115 in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_2351(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* a2329 in k2201 in k2198 in k2195 in k2192 in k2189 in loop in k2466 in k3174 in a3164 in a3158 in a3130 in k3115 in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_2330(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2330,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,C_retrieve(lf[142]));
t3=C_mutate((C_word*)lf[142]+1 /* (set! warnings-enabled ...) */,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* k2204 in k2201 in k2198 in k2195 in k2192 in k2189 in loop in k2466 in k3174 in a3164 in a3158 in a3130 in k3115 in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_2206(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2206,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2209,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken-install.scm: 345  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[46]+1)))(3,*((C_word*)lf[46]+1),t2,lf[141]);}

/* k2207 in k2204 in k2201 in k2198 in k2195 in k2192 in k2189 in loop in k2466 in k3174 in a3164 in a3158 in a3130 in k3115 in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_2209(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2209,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2212,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2251,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2275,tmp=(C_word)a,a+=2,tmp);
/* chicken-install.scm: 348  append-map */
((C_proc4)C_retrieve_symbol_proc(lf[139]))(4,*((C_word*)lf[139]+1),t3,t4,C_retrieve(lf[140]));}

/* a2274 in k2207 in k2204 in k2201 in k2198 in k2195 in k2192 in k2189 in loop in k2466 in k3174 in a3164 in a3158 in a3130 in k3115 in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_2275(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2275,3,t0,t1,t2);}
t3=(C_word)C_i_cdr(t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2282,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm: 351  ##sys#module-name */
((C_proc3)C_retrieve_symbol_proc(lf[138]))(3,*((C_word*)lf[138]+1),t4,t3);}

/* k2280 in a2274 in k2207 in k2204 in k2201 in k2198 in k2195 in k2192 in k2189 in loop in k2466 in k3174 in a3164 in a3158 in a3130 in k3115 in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_2282(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2282,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2285,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* chicken-install.scm: 352  print* */
((C_proc4)C_retrieve_proc(*((C_word*)lf[136]+1)))(4,*((C_word*)lf[136]+1),t2,lf[137],t1);}

/* k2283 in k2280 in a2274 in k2207 in k2204 in k2201 in k2198 in k2195 in k2192 in k2189 in loop in k2466 in k3174 in a3164 in a3158 in a3130 in k3115 in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_2285(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2285,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2290,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2296,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a2295 in k2283 in k2280 in a2274 in k2207 in k2204 in k2201 in k2198 in k2195 in k2192 in k2189 in loop in k2466 in k3174 in a3164 in a3158 in a3130 in k3115 in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_2296(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2296,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2304,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2320,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* map */
t7=*((C_word*)lf[66]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,t4);}

/* a2319 in a2295 in k2283 in k2280 in a2274 in k2207 in k2204 in k2201 in k2198 in k2195 in k2192 in k2189 in loop in k2466 in k3174 in a3164 in a3158 in a3130 in k3115 in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_2320(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2320,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,t3,lf[135],((C_word*)t0)[2]));}

/* k2302 in a2295 in k2283 in k2280 in a2274 in k2207 in k2204 in k2201 in k2198 in k2195 in k2192 in k2189 in loop in k2466 in k3174 in a3164 in a3158 in a3130 in k3115 in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_2304(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2304,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2308,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2310,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* map */
t4=*((C_word*)lf[66]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a2309 in k2302 in a2295 in k2283 in k2280 in a2274 in k2207 in k2204 in k2201 in k2198 in k2195 in k2192 in k2189 in loop in k2466 in k3174 in a3164 in a3158 in a3130 in k3115 in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_2310(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2310,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,t3,lf[134],((C_word*)t0)[2]));}

/* k2306 in k2302 in a2295 in k2283 in k2280 in a2274 in k2207 in k2204 in k2201 in k2198 in k2195 in k2192 in k2189 in loop in k2466 in k3174 in a3164 in a3158 in a3130 in k3115 in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_2308(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 354  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[43]+1)))(4,*((C_word*)lf[43]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2289 in k2283 in k2280 in a2274 in k2207 in k2204 in k2201 in k2198 in k2195 in k2192 in k2189 in loop in k2466 in k3174 in a3164 in a3158 in a3130 in k3115 in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_2290(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2290,2,t0,t1);}
/* chicken-install.scm: 353  ##sys#module-exports */
((C_proc3)C_retrieve_symbol_proc(lf[133]))(3,*((C_word*)lf[133]+1),t1,((C_word*)t0)[2]);}

/* k2249 in k2207 in k2204 in k2201 in k2198 in k2195 in k2192 in k2189 in loop in k2466 in k3174 in a3164 in a3158 in a3130 in k3115 in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_2251(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2251,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2253,tmp=(C_word)a,a+=2,tmp);
/* chicken-install.scm: 347  sort */
((C_proc4)C_retrieve_symbol_proc(lf[132]))(4,*((C_word*)lf[132]+1),((C_word*)t0)[2],t1,t2);}

/* a2252 in k2249 in k2207 in k2204 in k2201 in k2198 in k2195 in k2192 in k2189 in loop in k2466 in k3174 in a3164 in a3158 in a3130 in k3115 in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_2253(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2253,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2261,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_car(t2);
/* chicken-install.scm: 359  symbol->string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[131]+1)))(3,*((C_word*)lf[131]+1),t4,t5);}

/* k2259 in a2252 in k2249 in k2207 in k2204 in k2201 in k2198 in k2195 in k2192 in k2189 in loop in k2466 in k3174 in a3164 in a3158 in a3130 in k3115 in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_2261(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2261,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2265,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[2]);
/* chicken-install.scm: 359  symbol->string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[131]+1)))(3,*((C_word*)lf[131]+1),t2,t3);}

/* k2263 in k2259 in a2252 in k2249 in k2207 in k2204 in k2201 in k2198 in k2195 in k2192 in k2189 in loop in k2466 in k3174 in a3164 in a3158 in a3130 in k3115 in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_2265(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 359  string<? */
((C_proc4)C_retrieve_proc(*((C_word*)lf[130]+1)))(4,*((C_word*)lf[130]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2210 in k2207 in k2204 in k2201 in k2198 in k2195 in k2192 in k2189 in loop in k2466 in k3174 in a3164 in a3158 in a3130 in k3115 in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_2212(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2212,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2215,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* chicken-install.scm: 360  newline */
((C_proc2)C_retrieve_proc(*((C_word*)lf[127]+1)))(2,*((C_word*)lf[127]+1),t2);}

/* k2213 in k2210 in k2207 in k2204 in k2201 in k2198 in k2195 in k2192 in k2189 in loop in k2466 in k3174 in a3164 in a3158 in a3130 in k3115 in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_2215(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2215,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2218,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2234,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 361  with-output-to-file */
((C_proc4)C_retrieve_symbol_proc(lf[129]))(4,*((C_word*)lf[129]+1),t2,((C_word*)t0)[3],t3);}

/* a2233 in k2213 in k2210 in k2207 in k2204 in k2201 in k2198 in k2195 in k2192 in k2189 in loop in k2466 in k3174 in a3164 in a3158 in a3130 in k3115 in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_2234(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2234,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2240,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t3=*((C_word*)lf[49]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,((C_word*)t0)[2]);}

/* a2239 in a2233 in k2213 in k2210 in k2207 in k2204 in k2201 in k2198 in k2195 in k2192 in k2189 in loop in k2466 in k3174 in a3164 in a3158 in a3130 in k3115 in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_2240(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2240,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2244,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 363  write */
((C_proc3)C_retrieve_proc(*((C_word*)lf[128]+1)))(3,*((C_word*)lf[128]+1),t3,t2);}

/* k2242 in a2239 in a2233 in k2213 in k2210 in k2207 in k2204 in k2201 in k2198 in k2195 in k2192 in k2189 in loop in k2466 in k3174 in a3164 in a3158 in a3130 in k3115 in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_2244(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 363  newline */
((C_proc2)C_retrieve_proc(*((C_word*)lf[127]+1)))(2,*((C_word*)lf[127]+1),((C_word*)t0)[2]);}

/* k2216 in k2213 in k2210 in k2207 in k2204 in k2201 in k2198 in k2195 in k2192 in k2189 in loop in k2466 in k3174 in a3164 in a3158 in a3130 in k3115 in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_2218(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2218,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2221,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2228,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2232,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 364  repository-path */
((C_proc2)C_retrieve_symbol_proc(lf[126]))(2,*((C_word*)lf[126]+1),t4);}

/* k2230 in k2216 in k2213 in k2210 in k2207 in k2204 in k2201 in k2198 in k2195 in k2192 in k2189 in loop in k2466 in k3174 in a3164 in a3158 in a3130 in k3115 in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_2232(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 364  make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[77]))(4,*((C_word*)lf[77]+1),((C_word*)t0)[2],t1,C_retrieve2(lf[15],"main#constant220"));}

/* k2226 in k2216 in k2213 in k2210 in k2207 in k2204 in k2201 in k2198 in k2195 in k2192 in k2189 in loop in k2466 in k3174 in a3164 in a3158 in a3130 in k3115 in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_2228(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 364  setup-api#copy-file */
((C_proc4)C_retrieve_symbol_proc(lf[125]))(4,*((C_word*)lf[125]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2219 in k2216 in k2213 in k2210 in k2207 in k2204 in k2201 in k2198 in k2195 in k2192 in k2189 in loop in k2466 in k3174 in a3164 in a3158 in a3130 in k3115 in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_2221(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 365  setup-api#remove-directory */
((C_proc3)C_retrieve_symbol_proc(lf[113]))(3,*((C_word*)lf[113]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3167 in a3164 in a3158 in a3130 in k3115 in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_3169(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 521  cleanup */
f_2172(((C_word*)t0)[2]);}

/* a3136 in a3130 in k3115 in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_3137(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3137,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3143,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* k937942 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a3142 in a3136 in a3130 in k3115 in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_3143(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3143,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3147,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3157,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm: 517  current-error-port */
((C_proc2)C_retrieve_symbol_proc(lf[124]))(2,*((C_word*)lf[124]+1),t3);}

/* k3155 in a3142 in a3136 in a3130 in k3115 in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_3157(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 517  print-error-message */
((C_proc4)C_retrieve_symbol_proc(lf[90]))(4,*((C_word*)lf[90]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3145 in a3142 in a3136 in a3130 in k3115 in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_3147(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3147,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3150,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 518  cleanup */
f_2172(t2);}

/* k3148 in k3145 in a3142 in a3136 in a3130 in k3115 in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_3150(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 519  exit */
((C_proc3)C_retrieve_symbol_proc(lf[121]))(3,*((C_word*)lf[121]+1),((C_word*)t0)[2],C_fix(1));}

/* k3127 in k3115 in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_3129(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k3118 in k3115 in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_3120(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3120,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3123,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3126,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#implicit-exit-handler */
((C_proc2)C_retrieve_symbol_proc(lf[123]))(2,*((C_word*)lf[123]+1),t3);}

/* k3124 in k3118 in k3115 in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_3126(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k3121 in k3118 in k3115 in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_3123(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* main#usage in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_fcall f_2454(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2454,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2458,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm: 376  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[46]+1)))(3,*((C_word*)lf[46]+1),t3,lf[122]);}

/* k2456 in main#usage in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_2458(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 397  exit */
((C_proc3)C_retrieve_symbol_proc(lf[121]))(3,*((C_word*)lf[121]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* main#$system in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_fcall f_2432(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2432,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2436,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2449,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[14],"main#*windows-shell*"))){
/* chicken-install.scm: 370  string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[35]+1)))(5,*((C_word*)lf[35]+1),t4,lf[118],t2,lf[119]);}
else{
t5=t4;
f_2449(2,t5,t2);}}

/* k2447 in main#$system in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_2449(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 368  system */
((C_proc3)C_retrieve_symbol_proc(lf[117]))(3,*((C_word*)lf[117]+1),((C_word*)t0)[2],t1);}

/* k2434 in main#$system in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_2436(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_zerop(t1))){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
/* chicken-install.scm: 373  error */
((C_proc5)C_retrieve_proc(*((C_word*)lf[34]+1)))(5,*((C_word*)lf[34]+1),((C_word*)t0)[3],lf[116],t1,((C_word*)t0)[2]);}}

/* main#cleanup in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_fcall f_2172(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2172,NULL,1,t1);}
if(C_truep(C_retrieve2(lf[1],"main#*keep*"))){
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2179,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 326  setup-download#temporary-directory */
((C_proc2)C_retrieve_symbol_proc(lf[114]))(2,*((C_word*)lf[114]+1),t2);}}

/* k2177 in main#cleanup in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_2179(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* chicken-install.scm: 327  setup-api#remove-directory */
((C_proc3)C_retrieve_symbol_proc(lf[113]))(3,*((C_word*)lf[113]+1),((C_word*)t0)[2],t1);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* main#retrieve in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_fcall f_1766(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1766,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1770,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm: 236  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[46]+1)))(3,*((C_word*)lf[46]+1),t3,lf[111]);}

/* k1768 in main#retrieve in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_1770(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1770,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1773,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1928,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[49]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a1927 in k1768 in main#retrieve in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_1928(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1928,3,t0,t1,t2);}
t3=(C_word)C_i_assoc(t2,C_retrieve2(lf[26],"main#*eggs+dirs+vers*"));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1943,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm: 242  delete */
((C_proc5)C_retrieve_symbol_proc(lf[79]))(5,*((C_word*)lf[79]+1),t4,t3,C_retrieve2(lf[26],"main#*eggs+dirs+vers*"),*((C_word*)lf[80]+1));}
else{
t4=(C_word)C_i_pairp(t2);
t5=(C_truep(t4)?(C_word)C_i_car(t2):t2);
t6=(C_word)C_i_pairp(t2);
t7=(C_truep(t6)?(C_word)C_i_cdr(t2):C_SCHEME_FALSE);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1954,a[2]=t7,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1960,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t8,t9);}}

/* a1959 in a1927 in k1768 in main#retrieve in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_1960(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1960,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1964,a[2]=t1,a[3]=t3,a[4]=t2,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t5=t4;
f_1964(2,t5,C_SCHEME_UNDEFINED);}
else{
/* chicken-install.scm: 247  error */
((C_proc3)C_retrieve_proc(*((C_word*)lf[34]+1)))(3,*((C_word*)lf[34]+1),t4,lf[110]);}}

/* k1962 in a1959 in a1927 in k1768 in main#retrieve in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_1964(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1964,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1967,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* chicken-install.scm: 248  print */
((C_proc6)C_retrieve_proc(*((C_word*)lf[46]+1)))(6,*((C_word*)lf[46]+1),t2,lf[108],((C_word*)t0)[5],lf[109],((C_word*)t0)[4]);}

/* k1965 in k1962 in a1959 in a1927 in k1768 in main#retrieve in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_1967(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1967,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_retrieve2(lf[26],"main#*eggs+dirs+vers*"));
t4=C_mutate(&lf[26] /* (set! main#*eggs+dirs+vers* ...) */,t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* a1953 in a1927 in k1768 in main#retrieve in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_1954(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[26],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1954,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1641,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=(C_truep(C_retrieve2(lf[11],"main#*default-location*"))?C_retrieve2(lf[12],"main#*default-transport*"):C_SCHEME_FALSE);
if(C_truep(t3)){
t4=(C_word)C_a_i_cons(&a,2,C_retrieve2(lf[11],"main#*default-location*"),C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[82],t4);
t6=(C_word)C_a_i_cons(&a,2,C_retrieve2(lf[12],"main#*default-transport*"),C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,lf[83],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,t5,t8);
t10=t2;
f_1641(t10,(C_word)C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST));}
else{
t4=t2;
f_1641(t4,C_retrieve2(lf[10],"main#*default-sources*"));}}

/* k1639 in a1953 in a1927 in k1768 in main#retrieve in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_fcall f_1641(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1641,NULL,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1643,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_1643(t5,((C_word*)t0)[2],t1);}

/* trying-sources in k1639 in a1953 in a1927 in k1768 in main#retrieve in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_fcall f_1643(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1643,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
/* chicken-install.scm: 206  values */
C_values(4,0,t1,C_SCHEME_FALSE,lf[81]);}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_assq(lf[82],t3);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1707,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t3,tmp=(C_word)a,a+=8,tmp);
if(C_truep(t4)){
t6=t5;
f_1707(2,t6,t4);}
else{
/* chicken-install.scm: 209  error */
((C_proc4)C_retrieve_proc(*((C_word*)lf[34]+1)))(4,*((C_word*)lf[34]+1),t5,lf[107],t3);}}}

/* k1705 in trying-sources in k1639 in a1953 in a1927 in k1768 in main#retrieve in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_1707(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1707,2,t0,t1);}
t2=(C_word)C_i_cadr(t1);
t3=(C_word)C_i_assq(lf[83],((C_word*)t0)[7]);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1697,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t2,a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t3)){
t5=t4;
f_1697(2,t5,t3);}
else{
/* chicken-install.scm: 211  error */
((C_proc4)C_retrieve_proc(*((C_word*)lf[34]+1)))(4,*((C_word*)lf[34]+1),t4,lf[106],((C_word*)t0)[7]);}}

/* k1695 in k1705 in trying-sources in k1639 in a1953 in a1927 in k1768 in main#retrieve in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_1697(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1697,2,t0,t1);}
t2=(C_word)C_i_cadr(t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1667,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t2,a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1673,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t3,t4);}

/* a1672 in k1695 in k1705 in trying-sources in k1639 in a1953 in a1927 in k1768 in main#retrieve in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_1673(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1673,4,t0,t1,t2,t3);}
if(C_truep(t2)){
/* chicken-install.scm: 214  values */
C_values(4,0,t1,t2,t3);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1168,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken-install.scm: 103  delete */
((C_proc5)C_retrieve_symbol_proc(lf[79]))(5,*((C_word*)lf[79]+1),t4,((C_word*)t0)[2],C_retrieve2(lf[10],"main#*default-sources*"),*((C_word*)lf[80]+1));}}

/* k1166 in a1672 in k1695 in k1705 in trying-sources in k1639 in a1953 in a1927 in k1768 in main#retrieve in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_1168(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(&lf[10] /* (set! main#*default-sources* ...) */,t1);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* chicken-install.scm: 217  trying-sources */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1643(t4,((C_word*)t0)[2],t3);}

/* a1666 in k1695 in k1705 in trying-sources in k1639 in a1953 in a1927 in k1768 in main#retrieve in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_1667(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1667,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1507,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1509,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* call-with-current-continuation */
((C_proc3)C_retrieve_proc(*((C_word*)lf[105]+1)))(3,*((C_word*)lf[105]+1),t2,t3);}

/* a1508 in a1666 in k1695 in k1705 in trying-sources in k1639 in a1953 in a1927 in k1768 in main#retrieve in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_1509(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1509,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1515,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1602,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* with-exception-handler */
((C_proc4)C_retrieve_symbol_proc(lf[104]))(4,*((C_word*)lf[104]+1),t1,t3,t4);}

/* a1601 in a1508 in a1666 in k1695 in k1705 in trying-sources in k1639 in a1953 in a1927 in k1768 in main#retrieve in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_1602(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1602,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1608,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1621,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a1620 in a1601 in a1508 in a1666 in k1695 in k1705 in trying-sources in k1639 in a1953 in a1927 in k1768 in main#retrieve in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_1621(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_1621r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1621r(t0,t1,t2);}}

static void C_ccall f_1621r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1627,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* k373379 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a1626 in a1620 in a1601 in a1508 in a1666 in k1695 in k1705 in trying-sources in k1639 in a1953 in a1927 in k1768 in main#retrieve in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_1627(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1627,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a1607 in a1601 in a1508 in a1666 in k1695 in k1705 in trying-sources in k1639 in a1953 in a1927 in k1768 in main#retrieve in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_1608(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1608,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1616,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(C_retrieve2(lf[6],"main#*retrieve-only*"))){
/* chicken-install.scm: 186  current-directory */
((C_proc2)C_retrieve_symbol_proc(lf[103]))(2,*((C_word*)lf[103]+1),t2);}
else{
t3=t2;
f_1616(2,t3,C_SCHEME_FALSE);}}

/* k1614 in a1607 in a1601 in a1508 in a1666 in k1695 in k1705 in trying-sources in k1639 in a1953 in a1927 in k1768 in main#retrieve in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_1616(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 183  setup-download#retrieve-extension */
((C_proc15)C_retrieve_symbol_proc(lf[97]))(15,*((C_word*)lf[97]+1),((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],lf[98],((C_word*)t0)[2],lf[99],t1,lf[100],C_retrieve2(lf[5],"main#*run-tests*"),lf[101],C_retrieve2(lf[8],"main#*username*"),lf[102],C_retrieve2(lf[9],"main#*password*"));}

/* a1514 in a1508 in a1666 in k1695 in k1705 in trying-sources in k1639 in a1953 in a1927 in k1768 in main#retrieve in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_1515(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1515,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1521,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* k373379 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a1520 in a1514 in a1508 in a1666 in k1695 in k1705 in trying-sources in k1639 in a1953 in a1927 in k1768 in main#retrieve in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_1521(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1521,2,t0,t1);}
t2=(C_word)C_i_structurep(((C_word*)t0)[2],lf[84]);
t3=(C_truep(t2)?(C_word)C_slot(((C_word*)t0)[2],C_fix(1)):C_SCHEME_FALSE);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1531,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t3)){
t5=(C_word)C_i_memv(lf[93],t3);
t6=t4;
f_1531(t6,(C_truep(t5)?(C_word)C_i_memv(lf[96],t3):C_SCHEME_FALSE));}
else{
t5=t4;
f_1531(t5,C_SCHEME_FALSE);}}

/* k1529 in a1520 in a1514 in a1508 in a1666 in k1695 in k1705 in trying-sources in k1639 in a1953 in a1927 in k1768 in main#retrieve in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_fcall f_1531(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1531,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1534,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 191  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[46]+1)))(3,*((C_word*)lf[46]+1),t2,lf[86]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1543,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(C_word)C_i_memv(lf[93],((C_word*)t0)[2]);
t4=t2;
f_1543(t4,(C_truep(t3)?(C_word)C_i_memv(lf[95],((C_word*)t0)[2]):C_SCHEME_FALSE));}
else{
t3=t2;
f_1543(t3,C_SCHEME_FALSE);}}}

/* k1541 in k1529 in a1520 in a1514 in a1508 in a1666 in k1695 in k1705 in trying-sources in k1639 in a1953 in a1927 in k1768 in main#retrieve in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_fcall f_1543(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1543,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1546,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 194  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[46]+1)))(3,*((C_word*)lf[46]+1),t2,lf[88]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1555,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(C_word)C_i_memv(lf[93],((C_word*)t0)[2]);
t4=t2;
f_1555(t4,(C_truep(t3)?(C_word)C_i_memv(lf[94],((C_word*)t0)[2]):C_SCHEME_FALSE));}
else{
t3=t2;
f_1555(t3,C_SCHEME_FALSE);}}}

/* k1553 in k1541 in k1529 in a1520 in a1514 in a1508 in a1666 in k1695 in k1705 in trying-sources in k1639 in a1953 in a1927 in k1768 in main#retrieve in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_fcall f_1555(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1555,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1558,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm: 197  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[46]+1)))(3,*((C_word*)lf[46]+1),t3,lf[91]);}
else{
t2=((C_word*)t0)[3];
/* chicken-install.scm: 201  abort */
((C_proc3)C_retrieve_symbol_proc(lf[92]))(3,*((C_word*)lf[92]+1),((C_word*)t0)[2],t2);}}

/* k1556 in k1553 in k1541 in k1529 in a1520 in a1514 in a1508 in a1666 in k1695 in k1705 in trying-sources in k1639 in a1953 in a1927 in k1768 in main#retrieve in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_1558(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1558,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1561,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 198  print-error-message */
((C_proc3)C_retrieve_symbol_proc(lf[90]))(3,*((C_word*)lf[90]+1),t2,((C_word*)t0)[2]);}

/* k1559 in k1556 in k1553 in k1541 in k1529 in a1520 in a1514 in a1508 in a1666 in k1695 in k1705 in trying-sources in k1639 in a1953 in a1927 in k1768 in main#retrieve in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_1561(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 199  values */
C_values(4,0,((C_word*)t0)[2],C_SCHEME_FALSE,lf[89]);}

/* k1544 in k1541 in k1529 in a1520 in a1514 in a1508 in a1666 in k1695 in k1705 in trying-sources in k1639 in a1953 in a1927 in k1768 in main#retrieve in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_1546(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 195  values */
C_values(4,0,((C_word*)t0)[2],C_SCHEME_FALSE,lf[87]);}

/* k1532 in k1529 in a1520 in a1514 in a1508 in a1666 in k1695 in k1705 in trying-sources in k1639 in a1953 in a1927 in k1768 in main#retrieve in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_1534(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 192  values */
C_values(4,0,((C_word*)t0)[2],C_SCHEME_FALSE,lf[85]);}

/* k1505 in a1666 in k1695 in k1705 in trying-sources in k1639 in a1953 in a1927 in k1768 in main#retrieve in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_1507(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k1941 in a1927 in k1768 in main#retrieve in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_1943(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1943,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=C_mutate(&lf[26] /* (set! main#*eggs+dirs+vers* ...) */,t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k1771 in k1768 in main#retrieve in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_1773(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1773,2,t0,t1);}
if(C_truep(C_retrieve2(lf[6],"main#*retrieve-only*"))){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1781,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t3=*((C_word*)lf[49]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t2,C_retrieve2(lf[26],"main#*eggs+dirs+vers*"));}}

/* a1780 in k1771 in k1768 in main#retrieve in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_1781(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1781,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_member(t3,C_retrieve2(lf[28],"main#*checked*")))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_a_i_cons(&a,2,t4,C_retrieve2(lf[28],"main#*checked*"));
t6=C_mutate(&lf[28] /* (set! main#*checked* ...) */,t5);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1795,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t8=(C_word)C_i_cadr(t2);
t9=(C_word)C_i_car(t2);
/* chicken-install.scm: 256  make-pathname */
((C_proc5)C_retrieve_symbol_proc(lf[77]))(5,*((C_word*)lf[77]+1),t7,t8,t9,lf[78]);}}

/* k1793 in a1780 in k1771 in k1768 in main#retrieve in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_1795(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1795,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1801,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* chicken-install.scm: 257  file-exists? */
((C_proc3)C_retrieve_symbol_proc(lf[76]))(3,*((C_word*)lf[76]+1),t2,t1);}

/* k1799 in k1793 in a1780 in k1771 in k1768 in main#retrieve in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_1801(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1801,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1804,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm: 258  with-input-from-file */
((C_proc4)C_retrieve_symbol_proc(lf[71]))(4,*((C_word*)lf[71]+1),t2,((C_word*)t0)[2],*((C_word*)lf[72]+1));}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1906,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* chicken-install.scm: 283  string-append */
((C_proc6)C_retrieve_proc(*((C_word*)lf[35]+1)))(6,*((C_word*)lf[35]+1),t2,lf[73],t3,lf[74],lf[75]);}}

/* k1904 in k1799 in k1793 in a1780 in k1771 in k1768 in main#retrieve in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_1906(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 282  warning */
((C_proc3)C_retrieve_symbol_proc(lf[39]))(3,*((C_word*)lf[39]+1),((C_word*)t0)[2],t1);}

/* k1802 in k1799 in k1793 in a1780 in k1771 in k1768 in main#retrieve in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_1804(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1804,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1807,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
/* chicken-install.scm: 259  print */
((C_proc5)C_retrieve_proc(*((C_word*)lf[46]+1)))(5,*((C_word*)lf[46]+1),t2,lf[69],t3,lf[70]);}

/* k1805 in k1802 in k1799 in k1793 in a1780 in k1771 in k1768 in main#retrieve in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_1807(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1807,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1812,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1818,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a1817 in k1805 in k1802 in k1799 in k1793 in a1780 in k1771 in k1768 in main#retrieve in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_1818(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1818,4,t0,t1,t2,t3);}
t4=(C_word)C_i_car(((C_word*)t0)[2]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1895,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t1,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
/* chicken-install.scm: 263  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[43]+1)))(4,*((C_word*)lf[43]+1),t5,t2,t3);}

/* k1893 in a1817 in k1805 in k1802 in k1799 in k1793 in a1780 in k1771 in k1768 in main#retrieve in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_1895(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1895,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_retrieve2(lf[27],"main#*dependencies*"));
t4=C_mutate(&lf[27] /* (set! main#*dependencies* ...) */,t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1826,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1876,a[2]=((C_word*)t0)[2],a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1883,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 266  string-intersperse */
((C_proc4)C_retrieve_symbol_proc(lf[51]))(4,*((C_word*)lf[51]+1),t7,((C_word*)t0)[2],lf[68]);}
else{
t6=t5;
f_1826(2,t6,C_SCHEME_UNDEFINED);}}

/* k1881 in k1893 in a1817 in k1805 in k1802 in k1799 in k1793 in a1780 in k1771 in k1768 in main#retrieve in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_1883(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 266  print */
((C_proc4)C_retrieve_proc(*((C_word*)lf[46]+1)))(4,*((C_word*)lf[46]+1),((C_word*)t0)[2],lf[67],t1);}

/* k1874 in k1893 in a1817 in k1805 in k1802 in k1799 in k1793 in a1780 in k1771 in k1768 in main#retrieve in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_1876(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 267  retrieve */
f_1766(((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1824 in k1893 in a1817 in k1805 in k1802 in k1799 in k1793 in a1780 in k1771 in k1768 in main#retrieve in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_1826(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[25],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1826,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1832,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
t3=C_retrieve2(lf[2],"main#*force*");
if(C_truep(t3)){
t4=t2;
f_1832(2,t4,t3);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1870,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=((C_word*)t0)[2];
t6=((C_word*)t0)[3];
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1720,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_i_car(t5);
t9=(C_word)C_a_i_list(&a,3,lf[57],t8,lf[58]);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1728,a[2]=t9,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
t11=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1730,tmp=(C_word)a,a+=2,tmp);
/* map */
t12=*((C_word*)lf[66]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t10,t11,t6);}}
else{
t3=t2;
f_1832(2,t3,C_SCHEME_FALSE);}}

/* a1729 in k1824 in k1893 in a1817 in k1805 in k1802 in k1799 in k1793 in a1780 in k1771 in k1768 in main#retrieve in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_1730(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1730,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1756,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_car(t2);
/* chicken-install.scm: 229  extension-information */
((C_proc3)C_retrieve_symbol_proc(lf[23]))(3,*((C_word*)lf[23]+1),t4,t5);}

/* k1754 in a1729 in k1824 in k1893 in a1817 in k1805 in k1802 in k1799 in k1793 in a1780 in k1771 in k1768 in main#retrieve in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_1756(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_i_assq(lf[20],t1);
t3=(C_truep(t2)?(C_word)C_i_cadr(t2):lf[60]);
t4=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* chicken-install.scm: 227  conc */
((C_proc10)C_retrieve_symbol_proc(lf[61]))(10,*((C_word*)lf[61]+1),((C_word*)t0)[3],lf[62],((C_word*)t0)[2],lf[63],t3,lf[64],t4,lf[65],C_make_character(10));}

/* k1726 in k1824 in k1893 in a1817 in k1805 in k1802 in k1799 in k1793 in a1780 in k1771 in k1768 in main#retrieve in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_1728(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 221  append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[43]+1)))(5,*((C_word*)lf[43]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1,lf[59]);}

/* k1718 in k1824 in k1893 in a1817 in k1805 in k1802 in k1799 in k1793 in a1780 in k1771 in k1768 in main#retrieve in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_1720(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 220  string-concatenate */
((C_proc3)C_retrieve_symbol_proc(lf[56]))(3,*((C_word*)lf[56]+1),((C_word*)t0)[2],t1);}

/* k1868 in k1824 in k1893 in a1817 in k1805 in k1802 in k1799 in k1793 in a1780 in k1771 in k1768 in main#retrieve in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_1870(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 270  setup-api#yes-or-no? */
((C_proc4)C_retrieve_symbol_proc(lf[54]))(4,*((C_word*)lf[54]+1),((C_word*)t0)[2],t1,lf[55]);}

/* k1830 in k1824 in k1893 in a1817 in k1805 in k1802 in k1799 in k1793 in a1780 in k1771 in k1768 in main#retrieve in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_1832(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1832,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1835,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 273  unzip1 */
((C_proc3)C_retrieve_symbol_proc(lf[53]))(3,*((C_word*)lf[53]+1),t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k1833 in k1830 in k1824 in k1893 in a1817 in k1805 in k1802 in k1799 in k1793 in a1780 in k1771 in k1768 in main#retrieve in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_1835(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1835,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1838,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1857,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 274  string-intersperse */
((C_proc4)C_retrieve_symbol_proc(lf[51]))(4,*((C_word*)lf[51]+1),t3,t1,lf[52]);}

/* k1855 in k1833 in k1830 in k1824 in k1893 in a1817 in k1805 in k1802 in k1799 in k1793 in a1780 in k1771 in k1768 in main#retrieve in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_1857(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 274  print */
((C_proc4)C_retrieve_proc(*((C_word*)lf[46]+1)))(4,*((C_word*)lf[46]+1),((C_word*)t0)[2],lf[50],t1);}

/* k1836 in k1833 in k1830 in k1824 in k1893 in a1817 in k1805 in k1802 in k1799 in k1793 in a1780 in k1771 in k1768 in main#retrieve in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_1838(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1838,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1841,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1846,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[49]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a1845 in k1836 in k1833 in k1830 in k1824 in k1893 in a1817 in k1805 in k1802 in k1799 in k1793 in a1780 in k1771 in k1768 in main#retrieve in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_1846(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1846,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1850,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm: 277  print */
((C_proc5)C_retrieve_proc(*((C_word*)lf[46]+1)))(5,*((C_word*)lf[46]+1),t3,lf[47],t2,lf[48]);}

/* k1848 in a1845 in k1836 in k1833 in k1830 in k1824 in k1893 in a1817 in k1805 in k1802 in k1799 in k1793 in a1780 in k1771 in k1768 in main#retrieve in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_1850(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 278  setup-api#remove-extension */
((C_proc3)C_retrieve_symbol_proc(lf[45]))(3,*((C_word*)lf[45]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1839 in k1836 in k1833 in k1830 in k1824 in k1893 in a1817 in k1805 in k1802 in k1799 in k1793 in a1780 in k1771 in k1768 in main#retrieve in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_1841(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 280  retrieve */
f_1766(((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a1811 in k1805 in k1802 in k1799 in k1793 in a1780 in k1771 in k1768 in main#retrieve in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_1812(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[8],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1812,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1294,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_assq(lf[41],t2);
t5=(C_truep(t4)?(C_word)C_i_cdr(t4):C_SCHEME_FALSE);
t6=(C_truep(t5)?t5:C_SCHEME_END_OF_LIST);
t7=(C_word)C_i_assq(lf[42],t2);
t8=(C_truep(t7)?(C_word)C_i_cdr(t7):C_SCHEME_FALSE);
t9=(C_truep(t8)?t8:C_SCHEME_END_OF_LIST);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1285,a[2]=t9,a[3]=t6,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve2(lf[5],"main#*run-tests*"))){
t11=(C_word)C_i_assq(lf[44],t2);
t12=(C_truep(t11)?(C_word)C_i_cdr(t11):C_SCHEME_FALSE);
t13=t10;
f_1285(t13,(C_truep(t12)?t12:C_SCHEME_END_OF_LIST));}
else{
t11=t10;
f_1285(t11,C_SCHEME_END_OF_LIST);}}

/* k1283 in a1811 in k1805 in k1802 in k1799 in k1793 in a1780 in k1771 in k1768 in main#retrieve in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_fcall f_1285(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 135  append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[43]+1)))(5,*((C_word*)lf[43]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1292 in a1811 in k1805 in k1802 in k1799 in k1793 in a1780 in k1771 in k1768 in main#retrieve in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_1294(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1294,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1299,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_1299(t5,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}

/* loop in k1292 in a1811 in k1805 in k1802 in k1799 in k1793 in a1780 in k1771 in k1768 in main#retrieve in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_fcall f_1299(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1299,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1313,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm: 144  reverse */
((C_proc3)C_retrieve_proc(*((C_word*)lf[31]+1)))(3,*((C_word*)lf[31]+1),t5,t3);}
else{
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_cdr(t2);
t7=(C_word)C_i_symbolp(t5);
t8=(C_truep(t7)?t7:(C_word)C_i_stringp(t5));
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1339,a[2]=t4,a[3]=t6,a[4]=t1,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1342,a[2]=t5,a[3]=t3,a[4]=t9,tmp=(C_word)a,a+=5,tmp);
/* chicken-install.scm: 149  ext-version */
f_1222(t10,t5);}
else{
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1355,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t6,a[6]=t1,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_i_listp(t5))){
t10=(C_word)C_i_length(t5);
if(C_truep((C_word)C_i_nequalp(C_fix(2),t10))){
t11=(C_word)C_i_car(t5);
t12=(C_word)C_i_stringp(t11);
if(C_truep(t12)){
t13=t9;
f_1355(t13,t12);}
else{
t13=(C_word)C_i_car(t5);
t14=t9;
f_1355(t14,(C_word)C_i_symbolp(t13));}}
else{
t11=t9;
f_1355(t11,C_SCHEME_FALSE);}}
else{
t10=t9;
f_1355(t10,C_SCHEME_FALSE);}}}}

/* k1353 in loop in k1292 in a1811 in k1805 in k1802 in k1799 in k1793 in a1780 in k1771 in k1768 in main#retrieve in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_fcall f_1355(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1355,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1358,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[2]);
/* chicken-install.scm: 155  ext-version */
f_1222(t2,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1455,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* chicken-install.scm: 171  warning */
((C_proc4)C_retrieve_symbol_proc(lf[39]))(4,*((C_word*)lf[39]+1),t2,lf[40],((C_word*)t0)[2]);}}

/* k1453 in k1353 in loop in k1292 in a1811 in k1805 in k1802 in k1799 in k1793 in a1780 in k1771 in k1768 in main#retrieve in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_1455(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 174  loop */
t2=((C_word*)((C_word*)t0)[6])[1];
f_1299(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1356 in k1353 in loop in k1292 in a1811 in k1805 in k1802 in k1799 in k1793 in a1780 in k1771 in k1768 in main#retrieve in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_1358(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1358,2,t0,t1);}
t2=t1;
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1440,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1444,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_cadr(((C_word*)t0)[2]);
/* chicken-install.scm: 158  ->string */
((C_proc3)C_retrieve_symbol_proc(lf[21]))(3,*((C_word*)lf[21]+1),t4,t5);}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1375,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[2]);
/* chicken-install.scm: 157  ->string */
((C_proc3)C_retrieve_symbol_proc(lf[21]))(3,*((C_word*)lf[21]+1),t3,t4);}}

/* k1373 in k1356 in k1353 in loop in k1292 in a1811 in k1805 in k1802 in k1799 in k1793 in a1780 in k1771 in k1768 in main#retrieve in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_1375(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1375,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[6]);
/* chicken-install.scm: 157  loop */
t3=((C_word*)((C_word*)t0)[5])[1];
f_1299(t3,((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k1442 in k1356 in k1353 in loop in k1292 in a1811 in k1805 in k1802 in k1799 in k1793 in a1780 in k1771 in k1768 in main#retrieve in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_1444(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 158  setup-api#version>=? */
((C_proc4)C_retrieve_symbol_proc(lf[38]))(4,*((C_word*)lf[38]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1438 in k1356 in k1353 in loop in k1292 in a1811 in k1805 in k1802 in k1799 in k1793 in a1780 in k1771 in k1768 in main#retrieve in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_1440(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1440,2,t0,t1);}
if(C_truep(t1)){
/* chicken-install.scm: 169  loop */
t2=((C_word*)((C_word*)t0)[7])[1];
f_1299(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1388,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1429,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[2]);
/* chicken-install.scm: 159  ->string */
((C_proc3)C_retrieve_symbol_proc(lf[21]))(3,*((C_word*)lf[21]+1),t3,t4);}}

/* k1427 in k1438 in k1356 in k1353 in loop in k1292 in a1811 in k1805 in k1802 in k1799 in k1793 in a1780 in k1771 in k1768 in main#retrieve in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_1429(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1429,2,t0,t1);}
if(C_truep((C_word)C_i_string_equal_p(lf[33],t1))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1421,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[2]);
/* chicken-install.scm: 161  string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[35]+1)))(5,*((C_word*)lf[35]+1),t2,lf[36],t3,lf[37]);}
else{
t2=((C_word*)t0)[3];
f_1388(2,t2,C_SCHEME_UNDEFINED);}}

/* k1419 in k1427 in k1438 in k1356 in k1353 in loop in k1292 in a1811 in k1805 in k1802 in k1799 in k1793 in a1780 in k1771 in k1768 in main#retrieve in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_1421(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 160  error */
((C_proc3)C_retrieve_proc(*((C_word*)lf[34]+1)))(3,*((C_word*)lf[34]+1),((C_word*)t0)[2],t1);}

/* k1386 in k1438 in k1356 in k1353 in loop in k1292 in a1811 in k1805 in k1802 in k1799 in k1793 in a1780 in k1771 in k1768 in main#retrieve in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_1388(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1388,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1395,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1399,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[2]);
/* chicken-install.scm: 167  ->string */
((C_proc3)C_retrieve_symbol_proc(lf[21]))(3,*((C_word*)lf[21]+1),t3,t4);}

/* k1397 in k1386 in k1438 in k1356 in k1353 in loop in k1292 in a1811 in k1805 in k1802 in k1799 in k1793 in a1780 in k1771 in k1768 in main#retrieve in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_1399(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1399,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1403,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[2]);
/* chicken-install.scm: 167  ->string */
((C_proc3)C_retrieve_symbol_proc(lf[21]))(3,*((C_word*)lf[21]+1),t2,t3);}

/* k1401 in k1397 in k1386 in k1438 in k1356 in k1353 in loop in k1292 in a1811 in k1805 in k1802 in k1799 in k1793 in a1780 in k1771 in k1768 in main#retrieve in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_1403(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 166  alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[32]))(5,*((C_word*)lf[32]+1),((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k1393 in k1386 in k1438 in k1356 in k1353 in loop in k1292 in a1811 in k1805 in k1802 in k1799 in k1793 in a1780 in k1771 in k1768 in main#retrieve in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_1395(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 165  loop */
t2=((C_word*)((C_word*)t0)[5])[1];
f_1299(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1340 in loop in k1292 in a1811 in k1805 in k1802 in k1799 in k1793 in a1780 in k1771 in k1768 in main#retrieve in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_1342(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1342,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_1339(t2,((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1349,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm: 151  ->string */
((C_proc3)C_retrieve_symbol_proc(lf[21]))(3,*((C_word*)lf[21]+1),t2,((C_word*)t0)[2]);}}

/* k1347 in k1340 in loop in k1292 in a1811 in k1805 in k1802 in k1799 in k1793 in a1780 in k1771 in k1768 in main#retrieve in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_1349(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1349,2,t0,t1);}
t2=((C_word*)t0)[3];
f_1339(t2,(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[2]));}

/* k1337 in loop in k1292 in a1811 in k1805 in k1802 in k1799 in k1793 in a1780 in k1771 in k1768 in main#retrieve in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_fcall f_1339(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 148  loop */
t2=((C_word*)((C_word*)t0)[5])[1];
f_1299(t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k1311 in loop in k1292 in a1811 in k1805 in k1802 in k1799 in k1793 in a1780 in k1771 in k1768 in main#retrieve in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_1313(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1313,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1317,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm: 144  reverse */
((C_proc3)C_retrieve_proc(*((C_word*)lf[31]+1)))(3,*((C_word*)lf[31]+1),t2,((C_word*)t0)[2]);}

/* k1315 in k1311 in loop in k1292 in a1811 in k1805 in k1802 in k1799 in k1793 in a1780 in k1771 in k1768 in main#retrieve in k1496 in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_1317(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 144  values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* main#ext-version in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_fcall f_1222(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1222,NULL,2,t1,t2);}
t3=(C_word)C_eqp(t2,lf[18]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1232,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t3)){
t5=t4;
f_1232(t5,t3);}
else{
t5=(C_word)C_i_equalp(t2,lf[24]);
if(C_truep(t5)){
t6=t4;
f_1232(t6,t5);}
else{
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1267,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 124  ->string */
((C_proc3)C_retrieve_symbol_proc(lf[21]))(3,*((C_word*)lf[21]+1),t6,t2);}}}

/* k1265 in main#ext-version in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_1267(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_1232(t2,(C_word)C_i_member(t1,C_retrieve(lf[25])));}

/* k1230 in main#ext-version in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_fcall f_1232(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1232,NULL,2,t0,t1);}
if(C_truep(t1)){
/* chicken-install.scm: 125  chicken-version */
((C_proc2)C_retrieve_symbol_proc(lf[19]))(2,*((C_word*)lf[19]+1),((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1238,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 126  extension-information */
((C_proc3)C_retrieve_symbol_proc(lf[23]))(3,*((C_word*)lf[23]+1),t2,((C_word*)t0)[2]);}}

/* k1236 in k1230 in main#ext-version in k1081 in k1078 in k1075 in k1070 in k1067 in k1064 in k1061 in k1058 in k1055 in k1052 in k1049 in k1046 in k1043 in k1040 in k1037 in k1034 in k1031 in k1028 in k1025 in k1022 in k1019 */
static void C_ccall f_1238(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_assq(lf[20],t1);
if(C_truep(t2)){
t3=(C_word)C_i_cadr(t2);
/* chicken-install.scm: 130  ->string */
((C_proc3)C_retrieve_symbol_proc(lf[21]))(3,*((C_word*)lf[21]+1),((C_word*)t0)[2],t3);}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[22]);}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[256] = {
{"toplevel:chicken_install_scm",(void*)C_toplevel},
{"f_1021:chicken_install_scm",(void*)f_1021},
{"f_1024:chicken_install_scm",(void*)f_1024},
{"f_1027:chicken_install_scm",(void*)f_1027},
{"f_1030:chicken_install_scm",(void*)f_1030},
{"f_1033:chicken_install_scm",(void*)f_1033},
{"f_1036:chicken_install_scm",(void*)f_1036},
{"f_1039:chicken_install_scm",(void*)f_1039},
{"f_1042:chicken_install_scm",(void*)f_1042},
{"f_1045:chicken_install_scm",(void*)f_1045},
{"f_1048:chicken_install_scm",(void*)f_1048},
{"f_1051:chicken_install_scm",(void*)f_1051},
{"f_1054:chicken_install_scm",(void*)f_1054},
{"f_1057:chicken_install_scm",(void*)f_1057},
{"f_1060:chicken_install_scm",(void*)f_1060},
{"f_1063:chicken_install_scm",(void*)f_1063},
{"f_1066:chicken_install_scm",(void*)f_1066},
{"f_1069:chicken_install_scm",(void*)f_1069},
{"f_1072:chicken_install_scm",(void*)f_1072},
{"f_1077:chicken_install_scm",(void*)f_1077},
{"f_1080:chicken_install_scm",(void*)f_1080},
{"f_1083:chicken_install_scm",(void*)f_1083},
{"f_3196:chicken_install_scm",(void*)f_3196},
{"f_3192:chicken_install_scm",(void*)f_3192},
{"f_1498:chicken_install_scm",(void*)f_1498},
{"f_3117:chicken_install_scm",(void*)f_3117},
{"f_3131:chicken_install_scm",(void*)f_3131},
{"f_3159:chicken_install_scm",(void*)f_3159},
{"f_3178:chicken_install_scm",(void*)f_3178},
{"f_3184:chicken_install_scm",(void*)f_3184},
{"f_3165:chicken_install_scm",(void*)f_3165},
{"f_3176:chicken_install_scm",(void*)f_3176},
{"f_1125:chicken_install_scm",(void*)f_1125},
{"f_1104:chicken_install_scm",(void*)f_1104},
{"f_1121:chicken_install_scm",(void*)f_1121},
{"f_1114:chicken_install_scm",(void*)f_1114},
{"f_2468:chicken_install_scm",(void*)f_2468},
{"f_2473:chicken_install_scm",(void*)f_2473},
{"f_2563:chicken_install_scm",(void*)f_2563},
{"f_2916:chicken_install_scm",(void*)f_2916},
{"f_3061:chicken_install_scm",(void*)f_3061},
{"f_3024:chicken_install_scm",(void*)f_3024},
{"f_3038:chicken_install_scm",(void*)f_3038},
{"f_2979:chicken_install_scm",(void*)f_2979},
{"f_3002:chicken_install_scm",(void*)f_3002},
{"f_3011:chicken_install_scm",(void*)f_3011},
{"f_3018:chicken_install_scm",(void*)f_3018},
{"f_3005:chicken_install_scm",(void*)f_3005},
{"f_2983:chicken_install_scm",(void*)f_2983},
{"f_2963:chicken_install_scm",(void*)f_2963},
{"f_2925:chicken_install_scm",(void*)f_2925},
{"f_2959:chicken_install_scm",(void*)f_2959},
{"f_2948:chicken_install_scm",(void*)f_2948},
{"f_2942:chicken_install_scm",(void*)f_2942},
{"f_2938:chicken_install_scm",(void*)f_2938},
{"f_2889:chicken_install_scm",(void*)f_2889},
{"f_2859:chicken_install_scm",(void*)f_2859},
{"f_2802:chicken_install_scm",(void*)f_2802},
{"f_1189:chicken_install_scm",(void*)f_1189},
{"f_1195:chicken_install_scm",(void*)f_1195},
{"f_1200:chicken_install_scm",(void*)f_1200},
{"f_1220:chicken_install_scm",(void*)f_1220},
{"f_1212:chicken_install_scm",(void*)f_1212},
{"f_1216:chicken_install_scm",(void*)f_1216},
{"f_1208:chicken_install_scm",(void*)f_1208},
{"f_2805:chicken_install_scm",(void*)f_2805},
{"f_2773:chicken_install_scm",(void*)f_2773},
{"f_2766:chicken_install_scm",(void*)f_2766},
{"f_2715:chicken_install_scm",(void*)f_2715},
{"f_2678:chicken_install_scm",(void*)f_2678},
{"f_2682:chicken_install_scm",(void*)f_2682},
{"f_2645:chicken_install_scm",(void*)f_2645},
{"f_2609:chicken_install_scm",(void*)f_2609},
{"f_2517:chicken_install_scm",(void*)f_2517},
{"f_2548:chicken_install_scm",(void*)f_2548},
{"f_2533:chicken_install_scm",(void*)f_2533},
{"f_2541:chicken_install_scm",(void*)f_2541},
{"f_2531:chicken_install_scm",(void*)f_2531},
{"f_2527:chicken_install_scm",(void*)f_2527},
{"f_2489:chicken_install_scm",(void*)f_2489},
{"f_2502:chicken_install_scm",(void*)f_2502},
{"f_2492:chicken_install_scm",(void*)f_2492},
{"f_2499:chicken_install_scm",(void*)f_2499},
{"f_2056:chicken_install_scm",(void*)f_2056},
{"f_2170:chicken_install_scm",(void*)f_2170},
{"f_2062:chicken_install_scm",(void*)f_2062},
{"f_2065:chicken_install_scm",(void*)f_2065},
{"f_2068:chicken_install_scm",(void*)f_2068},
{"f_2162:chicken_install_scm",(void*)f_2162},
{"f_2160:chicken_install_scm",(void*)f_2160},
{"f_2073:chicken_install_scm",(void*)f_2073},
{"f_2077:chicken_install_scm",(void*)f_2077},
{"f_2080:chicken_install_scm",(void*)f_2080},
{"f_2097:chicken_install_scm",(void*)f_2097},
{"f_2000:chicken_install_scm",(void*)f_2000},
{"f_2042:chicken_install_scm",(void*)f_2042},
{"f_2020:chicken_install_scm",(void*)f_2020},
{"f_2028:chicken_install_scm",(void*)f_2028},
{"f_2024:chicken_install_scm",(void*)f_2024},
{"f_2101:chicken_install_scm",(void*)f_2101},
{"f_2104:chicken_install_scm",(void*)f_2104},
{"f_2107:chicken_install_scm",(void*)f_2107},
{"f_2135:chicken_install_scm",(void*)f_2135},
{"f_2141:chicken_install_scm",(void*)f_2141},
{"f_2113:chicken_install_scm",(void*)f_2113},
{"f_2116:chicken_install_scm",(void*)f_2116},
{"f_2119:chicken_install_scm",(void*)f_2119},
{"f_2122:chicken_install_scm",(void*)f_2122},
{"f_2084:chicken_install_scm",(void*)f_2084},
{"f_2088:chicken_install_scm",(void*)f_2088},
{"f_2091:chicken_install_scm",(void*)f_2091},
{"f_2430:chicken_install_scm",(void*)f_2430},
{"f_2426:chicken_install_scm",(void*)f_2426},
{"f_2191:chicken_install_scm",(void*)f_2191},
{"f_2194:chicken_install_scm",(void*)f_2194},
{"f_2197:chicken_install_scm",(void*)f_2197},
{"f_2200:chicken_install_scm",(void*)f_2200},
{"f_2203:chicken_install_scm",(void*)f_2203},
{"f_2419:chicken_install_scm",(void*)f_2419},
{"f_2335:chicken_install_scm",(void*)f_2335},
{"f_2341:chicken_install_scm",(void*)f_2341},
{"f_2345:chicken_install_scm",(void*)f_2345},
{"f_2353:chicken_install_scm",(void*)f_2353},
{"f_2379:chicken_install_scm",(void*)f_2379},
{"f_2407:chicken_install_scm",(void*)f_2407},
{"f_2413:chicken_install_scm",(void*)f_2413},
{"f_2385:chicken_install_scm",(void*)f_2385},
{"f_2401:chicken_install_scm",(void*)f_2401},
{"f_2359:chicken_install_scm",(void*)f_2359},
{"f_2365:chicken_install_scm",(void*)f_2365},
{"f_2373:chicken_install_scm",(void*)f_2373},
{"f_2377:chicken_install_scm",(void*)f_2377},
{"f_2351:chicken_install_scm",(void*)f_2351},
{"f_2330:chicken_install_scm",(void*)f_2330},
{"f_2206:chicken_install_scm",(void*)f_2206},
{"f_2209:chicken_install_scm",(void*)f_2209},
{"f_2275:chicken_install_scm",(void*)f_2275},
{"f_2282:chicken_install_scm",(void*)f_2282},
{"f_2285:chicken_install_scm",(void*)f_2285},
{"f_2296:chicken_install_scm",(void*)f_2296},
{"f_2320:chicken_install_scm",(void*)f_2320},
{"f_2304:chicken_install_scm",(void*)f_2304},
{"f_2310:chicken_install_scm",(void*)f_2310},
{"f_2308:chicken_install_scm",(void*)f_2308},
{"f_2290:chicken_install_scm",(void*)f_2290},
{"f_2251:chicken_install_scm",(void*)f_2251},
{"f_2253:chicken_install_scm",(void*)f_2253},
{"f_2261:chicken_install_scm",(void*)f_2261},
{"f_2265:chicken_install_scm",(void*)f_2265},
{"f_2212:chicken_install_scm",(void*)f_2212},
{"f_2215:chicken_install_scm",(void*)f_2215},
{"f_2234:chicken_install_scm",(void*)f_2234},
{"f_2240:chicken_install_scm",(void*)f_2240},
{"f_2244:chicken_install_scm",(void*)f_2244},
{"f_2218:chicken_install_scm",(void*)f_2218},
{"f_2232:chicken_install_scm",(void*)f_2232},
{"f_2228:chicken_install_scm",(void*)f_2228},
{"f_2221:chicken_install_scm",(void*)f_2221},
{"f_3169:chicken_install_scm",(void*)f_3169},
{"f_3137:chicken_install_scm",(void*)f_3137},
{"f_3143:chicken_install_scm",(void*)f_3143},
{"f_3157:chicken_install_scm",(void*)f_3157},
{"f_3147:chicken_install_scm",(void*)f_3147},
{"f_3150:chicken_install_scm",(void*)f_3150},
{"f_3129:chicken_install_scm",(void*)f_3129},
{"f_3120:chicken_install_scm",(void*)f_3120},
{"f_3126:chicken_install_scm",(void*)f_3126},
{"f_3123:chicken_install_scm",(void*)f_3123},
{"f_2454:chicken_install_scm",(void*)f_2454},
{"f_2458:chicken_install_scm",(void*)f_2458},
{"f_2432:chicken_install_scm",(void*)f_2432},
{"f_2449:chicken_install_scm",(void*)f_2449},
{"f_2436:chicken_install_scm",(void*)f_2436},
{"f_2172:chicken_install_scm",(void*)f_2172},
{"f_2179:chicken_install_scm",(void*)f_2179},
{"f_1766:chicken_install_scm",(void*)f_1766},
{"f_1770:chicken_install_scm",(void*)f_1770},
{"f_1928:chicken_install_scm",(void*)f_1928},
{"f_1960:chicken_install_scm",(void*)f_1960},
{"f_1964:chicken_install_scm",(void*)f_1964},
{"f_1967:chicken_install_scm",(void*)f_1967},
{"f_1954:chicken_install_scm",(void*)f_1954},
{"f_1641:chicken_install_scm",(void*)f_1641},
{"f_1643:chicken_install_scm",(void*)f_1643},
{"f_1707:chicken_install_scm",(void*)f_1707},
{"f_1697:chicken_install_scm",(void*)f_1697},
{"f_1673:chicken_install_scm",(void*)f_1673},
{"f_1168:chicken_install_scm",(void*)f_1168},
{"f_1667:chicken_install_scm",(void*)f_1667},
{"f_1509:chicken_install_scm",(void*)f_1509},
{"f_1602:chicken_install_scm",(void*)f_1602},
{"f_1621:chicken_install_scm",(void*)f_1621},
{"f_1627:chicken_install_scm",(void*)f_1627},
{"f_1608:chicken_install_scm",(void*)f_1608},
{"f_1616:chicken_install_scm",(void*)f_1616},
{"f_1515:chicken_install_scm",(void*)f_1515},
{"f_1521:chicken_install_scm",(void*)f_1521},
{"f_1531:chicken_install_scm",(void*)f_1531},
{"f_1543:chicken_install_scm",(void*)f_1543},
{"f_1555:chicken_install_scm",(void*)f_1555},
{"f_1558:chicken_install_scm",(void*)f_1558},
{"f_1561:chicken_install_scm",(void*)f_1561},
{"f_1546:chicken_install_scm",(void*)f_1546},
{"f_1534:chicken_install_scm",(void*)f_1534},
{"f_1507:chicken_install_scm",(void*)f_1507},
{"f_1943:chicken_install_scm",(void*)f_1943},
{"f_1773:chicken_install_scm",(void*)f_1773},
{"f_1781:chicken_install_scm",(void*)f_1781},
{"f_1795:chicken_install_scm",(void*)f_1795},
{"f_1801:chicken_install_scm",(void*)f_1801},
{"f_1906:chicken_install_scm",(void*)f_1906},
{"f_1804:chicken_install_scm",(void*)f_1804},
{"f_1807:chicken_install_scm",(void*)f_1807},
{"f_1818:chicken_install_scm",(void*)f_1818},
{"f_1895:chicken_install_scm",(void*)f_1895},
{"f_1883:chicken_install_scm",(void*)f_1883},
{"f_1876:chicken_install_scm",(void*)f_1876},
{"f_1826:chicken_install_scm",(void*)f_1826},
{"f_1730:chicken_install_scm",(void*)f_1730},
{"f_1756:chicken_install_scm",(void*)f_1756},
{"f_1728:chicken_install_scm",(void*)f_1728},
{"f_1720:chicken_install_scm",(void*)f_1720},
{"f_1870:chicken_install_scm",(void*)f_1870},
{"f_1832:chicken_install_scm",(void*)f_1832},
{"f_1835:chicken_install_scm",(void*)f_1835},
{"f_1857:chicken_install_scm",(void*)f_1857},
{"f_1838:chicken_install_scm",(void*)f_1838},
{"f_1846:chicken_install_scm",(void*)f_1846},
{"f_1850:chicken_install_scm",(void*)f_1850},
{"f_1841:chicken_install_scm",(void*)f_1841},
{"f_1812:chicken_install_scm",(void*)f_1812},
{"f_1285:chicken_install_scm",(void*)f_1285},
{"f_1294:chicken_install_scm",(void*)f_1294},
{"f_1299:chicken_install_scm",(void*)f_1299},
{"f_1355:chicken_install_scm",(void*)f_1355},
{"f_1455:chicken_install_scm",(void*)f_1455},
{"f_1358:chicken_install_scm",(void*)f_1358},
{"f_1375:chicken_install_scm",(void*)f_1375},
{"f_1444:chicken_install_scm",(void*)f_1444},
{"f_1440:chicken_install_scm",(void*)f_1440},
{"f_1429:chicken_install_scm",(void*)f_1429},
{"f_1421:chicken_install_scm",(void*)f_1421},
{"f_1388:chicken_install_scm",(void*)f_1388},
{"f_1399:chicken_install_scm",(void*)f_1399},
{"f_1403:chicken_install_scm",(void*)f_1403},
{"f_1395:chicken_install_scm",(void*)f_1395},
{"f_1342:chicken_install_scm",(void*)f_1342},
{"f_1349:chicken_install_scm",(void*)f_1349},
{"f_1339:chicken_install_scm",(void*)f_1339},
{"f_1313:chicken_install_scm",(void*)f_1313},
{"f_1317:chicken_install_scm",(void*)f_1317},
{"f_1222:chicken_install_scm",(void*)f_1222},
{"f_1267:chicken_install_scm",(void*)f_1267},
{"f_1232:chicken_install_scm",(void*)f_1232},
{"f_1238:chicken_install_scm",(void*)f_1238},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
