/* Generated from c-backend.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2009-09-21 21:29
   Version 4.0.1 - SVN rev. 14292
   linux-unix-gnu-x86 [ manyargs dload ptables applyhook ]
   compiled 2009-05-12 on galinha (Linux)
   command line: c-backend.scm -no-trace -optimize-level 2 -include-path . -include-path ./ -no-lambda-info -inline -local -extend private-namespace.scm -output-file c-backend.c
   unit: backend
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_69_toplevel)
C_externimport void C_ccall C_srfi_69_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[840];
static double C_possibly_force_alignment;


/* from getsize */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub2379(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub2379(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word lit=(C_word )(C_a0);
return(C_header_size(lit));
C_ret:
#undef return

return C_r;}

/* from getbits */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub2374(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub2374(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word lit=(C_word )(C_a0);

#ifdef C_SIXTY_FOUR
return((C_header_bits(lit) >> (24 + 32)) & 0xff);
#else
return((C_header_bits(lit) >> 24) & 0xff);
#endif

C_ret:
#undef return

return C_r;}

C_noret_decl(C_backend_toplevel)
C_externexport void C_ccall C_backend_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2435)
static void C_ccall f_2435(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2438)
static void C_ccall f_2438(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2441)
static void C_ccall f_2441(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2444)
static void C_ccall f_2444(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2447)
static void C_ccall f_2447(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2450)
static void C_ccall f_2450(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9167)
static void C_ccall f_9167(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9171)
static void C_ccall f_9171(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9163)
static void C_ccall f_9163(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2492)
static void C_ccall f_2492(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8863)
static void C_ccall f_8863(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9139)
static void C_ccall f_9139(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9137)
static void C_ccall f_9137(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9125)
static void C_ccall f_9125(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9095)
static void C_ccall f_9095(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9056)
static void C_ccall f_9056(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9043)
static void C_ccall f_9043(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9039)
static void C_ccall f_9039(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8925)
static void C_ccall f_8925(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8872)
static C_word C_fcall f_8872(C_word *a,C_word t0);
C_noret_decl(f_8465)
static void C_ccall f_8465(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8552)
static void C_fcall f_8552(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8633)
static void C_ccall f_8633(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8655)
static void C_fcall f_8655(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8467)
static void C_fcall f_8467(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7980)
static void C_ccall f_7980(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8010)
static void C_fcall f_8010(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8037)
static void C_fcall f_8037(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8232)
static void C_fcall f_8232(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8241)
static void C_fcall f_8241(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8250)
static void C_ccall f_8250(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8272)
static void C_fcall f_8272(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8349)
static void C_ccall f_8349(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7982)
static void C_fcall f_7982(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7135)
static void C_ccall f_7135(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7212)
static void C_fcall f_7212(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7314)
static void C_fcall f_7314(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7347)
static void C_fcall f_7347(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7443)
static void C_fcall f_7443(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7455)
static void C_fcall f_7455(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7470)
static void C_ccall f_7470(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7510)
static void C_fcall f_7510(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7527)
static void C_fcall f_7527(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7544)
static void C_fcall f_7544(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7583)
static void C_fcall f_7583(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7600)
static void C_fcall f_7600(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7617)
static void C_fcall f_7617(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7634)
static void C_fcall f_7634(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7651)
static void C_fcall f_7651(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7668)
static void C_fcall f_7668(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7685)
static void C_fcall f_7685(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7697)
static void C_ccall f_7697(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7704)
static void C_ccall f_7704(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7714)
static void C_ccall f_7714(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7712)
static void C_ccall f_7712(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7708)
static void C_ccall f_7708(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7675)
static void C_ccall f_7675(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7658)
static void C_ccall f_7658(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7641)
static void C_ccall f_7641(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7624)
static void C_ccall f_7624(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7607)
static void C_ccall f_7607(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7590)
static void C_ccall f_7590(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7555)
static void C_ccall f_7555(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7565)
static void C_ccall f_7565(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7563)
static void C_ccall f_7563(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7559)
static void C_ccall f_7559(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7551)
static void C_ccall f_7551(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7538)
static void C_ccall f_7538(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7521)
static void C_ccall f_7521(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7142)
static void C_fcall f_7142(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7137)
static void C_fcall f_7137(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7070)
static void C_ccall f_7070(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7074)
static void C_ccall f_7074(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7077)
static void C_ccall f_7077(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7080)
static void C_ccall f_7080(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7083)
static void C_ccall f_7083(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7089)
static void C_ccall f_7089(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7133)
static void C_ccall f_7133(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7092)
static void C_ccall f_7092(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7100)
static void C_ccall f_7100(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7121)
static void C_ccall f_7121(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7104)
static void C_ccall f_7104(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7095)
static void C_ccall f_7095(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6639)
static void C_ccall f_6639(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6645)
static void C_ccall f_6645(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6649)
static void C_ccall f_6649(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6652)
static void C_ccall f_6652(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6655)
static void C_ccall f_6655(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6658)
static void C_ccall f_6658(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6664)
static void C_ccall f_6664(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7005)
static void C_ccall f_7005(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7008)
static void C_ccall f_7008(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7068)
static void C_ccall f_7068(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7011)
static void C_ccall f_7011(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7014)
static void C_ccall f_7014(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7017)
static void C_ccall f_7017(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7020)
static void C_ccall f_7020(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7053)
static void C_ccall f_7053(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7061)
static void C_ccall f_7061(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7023)
static void C_ccall f_7023(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7051)
static void C_ccall f_7051(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7026)
static void C_ccall f_7026(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7029)
static void C_ccall f_7029(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7032)
static void C_ccall f_7032(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6666)
static void C_ccall f_6666(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6676)
static void C_fcall f_6676(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6685)
static void C_fcall f_6685(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6697)
static void C_fcall f_6697(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6709)
static void C_fcall f_6709(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6715)
static void C_ccall f_6715(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6749)
static void C_fcall f_6749(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6406)
static void C_ccall f_6406(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6412)
static void C_ccall f_6412(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6416)
static void C_ccall f_6416(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6419)
static void C_ccall f_6419(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6422)
static void C_ccall f_6422(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6637)
static void C_ccall f_6637(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6428)
static void C_ccall f_6428(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6431)
static void C_ccall f_6431(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6434)
static void C_ccall f_6434(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6437)
static void C_ccall f_6437(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6440)
static void C_ccall f_6440(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6443)
static void C_ccall f_6443(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6446)
static void C_ccall f_6446(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6449)
static void C_ccall f_6449(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6452)
static void C_ccall f_6452(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6455)
static void C_ccall f_6455(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6626)
static void C_ccall f_6626(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6458)
static void C_ccall f_6458(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6461)
static void C_ccall f_6461(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6464)
static void C_ccall f_6464(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6467)
static void C_ccall f_6467(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6470)
static void C_ccall f_6470(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6473)
static void C_ccall f_6473(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6476)
static void C_ccall f_6476(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6479)
static void C_ccall f_6479(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6604)
static void C_ccall f_6604(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6574)
static void C_ccall f_6574(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6594)
static void C_ccall f_6594(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6582)
static void C_ccall f_6582(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6586)
static void C_ccall f_6586(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6590)
static void C_ccall f_6590(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6482)
static void C_ccall f_6482(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6485)
static void C_ccall f_6485(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6515)
static void C_ccall f_6515(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6518)
static void C_ccall f_6518(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6556)
static void C_ccall f_6556(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6552)
static void C_ccall f_6552(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6521)
static void C_ccall f_6521(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6524)
static void C_ccall f_6524(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6527)
static void C_ccall f_6527(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6494)
static void C_ccall f_6494(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6497)
static void C_ccall f_6497(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6488)
static void C_ccall f_6488(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6388)
static void C_ccall f_6388(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6394)
static void C_ccall f_6394(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6398)
static void C_ccall f_6398(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6401)
static void C_ccall f_6401(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6356)
static void C_ccall f_6356(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6360)
static void C_ccall f_6360(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6365)
static void C_ccall f_6365(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6386)
static void C_ccall f_6386(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6340)
static void C_ccall f_6340(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6346)
static void C_ccall f_6346(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6354)
static void C_ccall f_6354(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6324)
static void C_ccall f_6324(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6330)
static void C_ccall f_6330(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6338)
static void C_ccall f_6338(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6235)
static void C_ccall f_6235(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6244)
static void C_fcall f_6244(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6273)
static void C_fcall f_6273(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6283)
static void C_ccall f_6283(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6276)
static void C_fcall f_6276(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6260)
static void C_fcall f_6260(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6158)
static void C_ccall f_6158(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6162)
static void C_ccall f_6162(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6176)
static void C_fcall f_6176(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6189)
static void C_ccall f_6189(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6221)
static void C_ccall f_6221(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6192)
static void C_ccall f_6192(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6195)
static void C_ccall f_6195(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6165)
static void C_ccall f_6165(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6168)
static void C_ccall f_6168(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6171)
static void C_ccall f_6171(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2494)
static void C_ccall f_2494(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8) C_noret;
C_noret_decl(f_6125)
static void C_ccall f_6125(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6129)
static void C_ccall f_6129(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6132)
static void C_ccall f_6132(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6135)
static void C_ccall f_6135(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6138)
static void C_ccall f_6138(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6141)
static void C_ccall f_6141(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6144)
static void C_ccall f_6144(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6147)
static void C_ccall f_6147(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6150)
static void C_ccall f_6150(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6153)
static void C_ccall f_6153(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5378)
static void C_fcall f_5378(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5384)
static void C_ccall f_5384(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5388)
static void C_ccall f_5388(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5391)
static void C_ccall f_5391(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5394)
static void C_ccall f_5394(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5397)
static void C_ccall f_5397(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5400)
static void C_ccall f_5400(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5403)
static void C_ccall f_5403(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6122)
static void C_ccall f_6122(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5406)
static void C_fcall f_5406(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5412)
static void C_ccall f_5412(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5415)
static void C_ccall f_5415(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5418)
static void C_ccall f_5418(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5421)
static void C_ccall f_5421(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5424)
static void C_ccall f_5424(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5427)
static void C_ccall f_5427(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5430)
static void C_ccall f_5430(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5433)
static void C_ccall f_5433(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5436)
static void C_ccall f_5436(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5439)
static void C_ccall f_5439(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5442)
static void C_ccall f_5442(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5445)
static void C_ccall f_5445(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6091)
static void C_ccall f_6091(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5448)
static void C_ccall f_5448(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6052)
static void C_ccall f_6052(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6055)
static void C_ccall f_6055(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6058)
static void C_ccall f_6058(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6074)
static void C_ccall f_6074(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6077)
static void C_ccall f_6077(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5451)
static void C_ccall f_5451(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5454)
static void C_ccall f_5454(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5457)
static void C_ccall f_5457(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6024)
static void C_fcall f_6024(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6027)
static void C_ccall f_6027(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5460)
static void C_ccall f_5460(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5463)
static void C_ccall f_5463(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5466)
static void C_ccall f_5466(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5469)
static void C_ccall f_5469(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5472)
static void C_fcall f_5472(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5475)
static void C_ccall f_5475(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5986)
static void C_fcall f_5986(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5996)
static void C_ccall f_5996(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5478)
static void C_ccall f_5478(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5929)
static void C_fcall f_5929(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5941)
static void C_ccall f_5941(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5944)
static void C_ccall f_5944(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5950)
static void C_fcall f_5950(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5851)
static void C_ccall f_5851(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5893)
static void C_fcall f_5893(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5854)
static void C_ccall f_5854(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5860)
static void C_fcall f_5860(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5863)
static void C_ccall f_5863(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5869)
static void C_fcall f_5869(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5787)
static void C_ccall f_5787(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5790)
static void C_ccall f_5790(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5793)
static void C_ccall f_5793(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5796)
static void C_ccall f_5796(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5799)
static void C_ccall f_5799(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5814)
static void C_fcall f_5814(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5802)
static void C_ccall f_5802(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5805)
static void C_ccall f_5805(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5773)
static void C_ccall f_5773(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5781)
static void C_ccall f_5781(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5698)
static void C_ccall f_5698(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5704)
static void C_ccall f_5704(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5707)
static void C_ccall f_5707(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5741)
static void C_ccall f_5741(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5744)
static void C_ccall f_5744(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5747)
static void C_ccall f_5747(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5710)
static void C_ccall f_5710(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5713)
static void C_ccall f_5713(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5716)
static void C_ccall f_5716(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5719)
static void C_ccall f_5719(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5728)
static void C_ccall f_5728(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5731)
static void C_ccall f_5731(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5481)
static void C_ccall f_5481(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5504)
static void C_fcall f_5504(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5639)
static void C_ccall f_5639(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5642)
static void C_ccall f_5642(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5654)
static void C_ccall f_5654(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5645)
static void C_ccall f_5645(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5510)
static void C_ccall f_5510(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5513)
static void C_ccall f_5513(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5516)
static void C_ccall f_5516(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5620)
static void C_ccall f_5620(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5519)
static void C_ccall f_5519(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5522)
static void C_ccall f_5522(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5525)
static void C_ccall f_5525(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5528)
static void C_ccall f_5528(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5593)
static void C_ccall f_5593(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5589)
static void C_ccall f_5589(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5531)
static void C_ccall f_5531(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5534)
static void C_ccall f_5534(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5537)
static void C_ccall f_5537(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5540)
static void C_ccall f_5540(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5543)
static void C_ccall f_5543(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5546)
static void C_ccall f_5546(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5564)
static void C_fcall f_5564(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5574)
static void C_ccall f_5574(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5549)
static void C_ccall f_5549(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5484)
static void C_ccall f_5484(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5494)
static void C_ccall f_5494(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5487)
static void C_ccall f_5487(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4988)
static void C_ccall f_4988(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4995)
static void C_ccall f_4995(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5069)
static void C_ccall f_5069(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5087)
static void C_ccall f_5087(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5116)
static void C_fcall f_5116(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5138)
static void C_ccall f_5138(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5094)
static void C_ccall f_5094(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5063)
static void C_ccall f_5063(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5059)
static void C_ccall f_5059(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5055)
static void C_ccall f_5055(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5026)
static void C_ccall f_5026(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5030)
static void C_ccall f_5030(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4945)
static void C_fcall f_4945(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4951)
static void C_fcall f_4951(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4980)
static void C_ccall f_4980(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4961)
static void C_ccall f_4961(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5147)
static void C_fcall f_5147(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5287)
static void C_ccall f_5287(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5154)
static void C_fcall f_5154(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5160)
static void C_ccall f_5160(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5243)
static void C_fcall f_5243(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5246)
static void C_ccall f_5246(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5256)
static void C_ccall f_5256(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5249)
static void C_ccall f_5249(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5210)
static void C_ccall f_5210(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5216)
static void C_ccall f_5216(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4982)
static void C_fcall f_4982(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5289)
static void C_fcall f_5289(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5296)
static void C_ccall f_5296(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5299)
static void C_ccall f_5299(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5304)
static void C_fcall f_5304(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5360)
static void C_ccall f_5360(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5356)
static void C_ccall f_5356(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5341)
static void C_ccall f_5341(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5320)
static void C_fcall f_5320(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5331)
static void C_ccall f_5331(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5327)
static void C_ccall f_5327(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5366)
static void C_fcall f_5366(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5373)
static void C_ccall f_5373(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5376)
static void C_ccall f_5376(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4659)
static void C_fcall f_4659(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4826)
static void C_ccall f_4826(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4830)
static void C_ccall f_4830(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4833)
static void C_ccall f_4833(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4836)
static void C_ccall f_4836(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4839)
static void C_ccall f_4839(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4842)
static void C_ccall f_4842(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4943)
static void C_ccall f_4943(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4845)
static void C_fcall f_4845(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4848)
static void C_fcall f_4848(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4854)
static void C_ccall f_4854(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4932)
static void C_ccall f_4932(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4888)
static void C_ccall f_4888(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4894)
static void C_fcall f_4894(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4912)
static void C_ccall f_4912(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4908)
static void C_ccall f_4908(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4904)
static void C_ccall f_4904(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4860)
static void C_ccall f_4860(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4863)
static void C_ccall f_4863(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4866)
static void C_ccall f_4866(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4869)
static void C_ccall f_4869(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4872)
static void C_ccall f_4872(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4882)
static void C_ccall f_4882(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4875)
static void C_ccall f_4875(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4778)
static void C_ccall f_4778(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4797)
static void C_ccall f_4797(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4801)
static void C_ccall f_4801(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4804)
static void C_ccall f_4804(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4807)
static void C_ccall f_4807(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4810)
static void C_ccall f_4810(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4824)
static void C_ccall f_4824(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4820)
static void C_ccall f_4820(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4813)
static void C_ccall f_4813(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4781)
static void C_ccall f_4781(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4795)
static void C_ccall f_4795(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4784)
static void C_ccall f_4784(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4791)
static void C_ccall f_4791(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4698)
static void C_fcall f_4698(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4700)
static void C_ccall f_4700(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4704)
static void C_ccall f_4704(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4707)
static void C_ccall f_4707(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4710)
static void C_ccall f_4710(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4713)
static void C_ccall f_4713(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4716)
static void C_ccall f_4716(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4719)
static void C_ccall f_4719(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4722)
static void C_ccall f_4722(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4725)
static void C_ccall f_4725(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4728)
static void C_ccall f_4728(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4731)
static void C_ccall f_4731(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4734)
static void C_ccall f_4734(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4737)
static void C_ccall f_4737(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4751)
static void C_ccall f_4751(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4747)
static void C_ccall f_4747(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4740)
static void C_ccall f_4740(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4662)
static void C_fcall f_4662(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4675)
static void C_fcall f_4675(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4685)
static void C_ccall f_4685(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4666)
static void C_ccall f_4666(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4408)
static void C_fcall f_4408(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4412)
static void C_ccall f_4412(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4436)
static void C_ccall f_4436(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4440)
static void C_ccall f_4440(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4443)
static void C_ccall f_4443(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4657)
static void C_ccall f_4657(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4446)
static void C_fcall f_4446(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4643)
static void C_ccall f_4643(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4449)
static void C_ccall f_4449(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4452)
static void C_ccall f_4452(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4455)
static void C_ccall f_4455(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4458)
static void C_ccall f_4458(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4461)
static void C_ccall f_4461(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4464)
static void C_ccall f_4464(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4635)
static void C_ccall f_4635(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4467)
static void C_fcall f_4467(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4470)
static void C_ccall f_4470(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4628)
static void C_ccall f_4628(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4609)
static void C_ccall f_4609(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4620)
static void C_ccall f_4620(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4473)
static void C_ccall f_4473(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4560)
static void C_ccall f_4560(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4563)
static void C_ccall f_4563(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4566)
static void C_ccall f_4566(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4569)
static void C_ccall f_4569(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4585)
static void C_ccall f_4585(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4588)
static void C_ccall f_4588(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4591)
static void C_ccall f_4591(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4594)
static void C_ccall f_4594(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4476)
static void C_ccall f_4476(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4479)
static void C_ccall f_4479(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4482)
static void C_ccall f_4482(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4532)
static void C_fcall f_4532(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4535)
static void C_ccall f_4535(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4485)
static void C_ccall f_4485(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4488)
static void C_ccall f_4488(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4520)
static void C_ccall f_4520(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4523)
static void C_ccall f_4523(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4494)
static void C_ccall f_4494(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4503)
static void C_ccall f_4503(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4506)
static void C_ccall f_4506(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4415)
static void C_ccall f_4415(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4420)
static void C_ccall f_4420(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4424)
static void C_ccall f_4424(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4434)
static void C_ccall f_4434(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4427)
static void C_ccall f_4427(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4259)
static void C_fcall f_4259(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4266)
static void C_ccall f_4266(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4402)
static void C_ccall f_4402(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4269)
static void C_ccall f_4269(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4272)
static void C_ccall f_4272(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4275)
static void C_ccall f_4275(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4280)
static void C_fcall f_4280(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4290)
static void C_ccall f_4290(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4296)
static void C_ccall f_4296(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4349)
static void C_fcall f_4349(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4359)
static void C_ccall f_4359(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4299)
static void C_ccall f_4299(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4322)
static void C_fcall f_4322(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4332)
static void C_ccall f_4332(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4302)
static void C_ccall f_4302(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4305)
static void C_ccall f_4305(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4112)
static void C_fcall f_4112(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4251)
static void C_ccall f_4251(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4132)
static void C_ccall f_4132(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4209)
static void C_ccall f_4209(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4213)
static void C_ccall f_4213(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4217)
static void C_ccall f_4217(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4221)
static void C_ccall f_4221(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4243)
static void C_ccall f_4243(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4239)
static void C_ccall f_4239(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4231)
static void C_ccall f_4231(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4229)
static void C_ccall f_4229(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4225)
static void C_ccall f_4225(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4150)
static void C_ccall f_4150(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4153)
static void C_ccall f_4153(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4156)
static void C_ccall f_4156(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4198)
static void C_ccall f_4198(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4159)
static void C_ccall f_4159(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4162)
static void C_ccall f_4162(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4165)
static void C_ccall f_4165(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4180)
static void C_ccall f_4180(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4185)
static void C_ccall f_4185(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4168)
static void C_ccall f_4168(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4115)
static void C_fcall f_4115(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4129)
static void C_ccall f_4129(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2539)
static void C_fcall f_2539(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4080)
static void C_fcall f_4080(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4086)
static void C_ccall f_4086(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4090)
static void C_ccall f_4090(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2542)
static void C_fcall f_2542(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4045)
static void C_ccall f_4045(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4048)
static void C_ccall f_4048(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4051)
static void C_ccall f_4051(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4054)
static void C_ccall f_4054(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4057)
static void C_ccall f_4057(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4060)
static void C_ccall f_4060(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3962)
static void C_ccall f_3962(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3965)
static void C_ccall f_3965(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3968)
static void C_ccall f_3968(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3981)
static void C_fcall f_3981(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4004)
static void C_ccall f_4004(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4007)
static void C_ccall f_4007(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4010)
static void C_ccall f_4010(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4013)
static void C_ccall f_4013(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3991)
static void C_ccall f_3991(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3994)
static void C_ccall f_3994(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3953)
static void C_ccall f_3953(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3925)
static void C_ccall f_3925(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3928)
static void C_ccall f_3928(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3945)
static void C_ccall f_3945(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3931)
static void C_ccall f_3931(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3934)
static void C_ccall f_3934(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3909)
static void C_ccall f_3909(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3913)
static void C_ccall f_3913(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3895)
static void C_ccall f_3895(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3898)
static void C_ccall f_3898(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3879)
static void C_ccall f_3879(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3883)
static void C_ccall f_3883(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3861)
static void C_ccall f_3861(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3864)
static void C_ccall f_3864(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3841)
static void C_ccall f_3841(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3805)
static void C_ccall f_3805(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3817)
static void C_ccall f_3817(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3808)
static void C_ccall f_3808(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3786)
static void C_ccall f_3786(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3789)
static void C_ccall f_3789(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3767)
static void C_ccall f_3767(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3770)
static void C_ccall f_3770(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3748)
static void C_ccall f_3748(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3751)
static void C_ccall f_3751(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3729)
static void C_ccall f_3729(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3725)
static void C_ccall f_3725(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3673)
static void C_ccall f_3673(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3706)
static void C_ccall f_3706(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3676)
static void C_ccall f_3676(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3694)
static void C_ccall f_3694(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3679)
static void C_ccall f_3679(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3682)
static void C_ccall f_3682(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3640)
static void C_ccall f_3640(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3624)
static void C_ccall f_3624(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3627)
static void C_ccall f_3627(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3630)
static void C_ccall f_3630(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3583)
static void C_ccall f_3583(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3586)
static void C_ccall f_3586(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3607)
static void C_ccall f_3607(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3611)
static void C_ccall f_3611(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3614)
static void C_ccall f_3614(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3589)
static void C_ccall f_3589(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3605)
static void C_ccall f_3605(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3597)
static void C_ccall f_3597(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3592)
static void C_ccall f_3592(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3216)
static void C_ccall f_3216(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3219)
static void C_fcall f_3219(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3533)
static void C_ccall f_3533(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3529)
static void C_ccall f_3529(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3225)
static void C_fcall f_3225(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3522)
static void C_ccall f_3522(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2527)
static void C_ccall f_2527(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3515)
static void C_ccall f_3515(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3231)
static void C_ccall f_3231(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3358)
static void C_fcall f_3358(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3442)
static void C_ccall f_3442(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3445)
static void C_ccall f_3445(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3448)
static void C_ccall f_3448(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3463)
static void C_fcall f_3463(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3451)
static void C_ccall f_3451(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3454)
static void C_ccall f_3454(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3457)
static void C_ccall f_3457(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3373)
static void C_ccall f_3373(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3439)
static void C_ccall f_3439(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3432)
static void C_ccall f_3432(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3428)
static void C_ccall f_3428(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3421)
static void C_ccall f_3421(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3414)
static void C_ccall f_3414(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3389)
static void C_ccall f_3389(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3406)
static void C_ccall f_3406(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3402)
static void C_ccall f_3402(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3376)
static void C_ccall f_3376(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3379)
static void C_ccall f_3379(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3382)
static void C_ccall f_3382(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3352)
static void C_ccall f_3352(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3262)
static void C_ccall f_3262(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3336)
static void C_ccall f_3336(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3339)
static void C_ccall f_3339(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3312)
static void C_ccall f_3312(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3315)
static void C_ccall f_3315(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3318)
static void C_ccall f_3318(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3321)
static void C_ccall f_3321(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3324)
static void C_ccall f_3324(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3265)
static void C_ccall f_3265(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3268)
static void C_ccall f_3268(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3295)
static void C_ccall f_3295(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3299)
static void C_ccall f_3299(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3302)
static void C_ccall f_3302(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3271)
static void C_ccall f_3271(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3293)
static void C_ccall f_3293(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3285)
static void C_ccall f_3285(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3274)
static void C_ccall f_3274(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3277)
static void C_ccall f_3277(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3243)
static void C_ccall f_3243(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3246)
static void C_ccall f_3246(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3183)
static void C_ccall f_3183(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3179)
static void C_ccall f_3179(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3165)
static void C_ccall f_3165(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3168)
static void C_ccall f_3168(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3162)
static void C_ccall f_3162(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3158)
static void C_ccall f_3158(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3144)
static void C_ccall f_3144(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3147)
static void C_ccall f_3147(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3096)
static void C_ccall f_3096(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3117)
static void C_ccall f_3117(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3113)
static void C_ccall f_3113(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3099)
static void C_ccall f_3099(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3102)
static void C_ccall f_3102(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3065)
static void C_ccall f_3065(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3061)
static void C_ccall f_3061(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3019)
static void C_ccall f_3019(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2987)
static void C_ccall f_2987(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2990)
static void C_ccall f_2990(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2952)
static void C_ccall f_2952(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2978)
static void C_ccall f_2978(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2964)
static void C_ccall f_2964(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2968)
static void C_ccall f_2968(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2971)
static void C_ccall f_2971(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2955)
static void C_ccall f_2955(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2920)
static void C_ccall f_2920(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2923)
static void C_ccall f_2923(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2926)
static void C_ccall f_2926(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2929)
static void C_ccall f_2929(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2891)
static void C_ccall f_2891(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2894)
static void C_ccall f_2894(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2897)
static void C_ccall f_2897(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2900)
static void C_ccall f_2900(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2854)
static void C_ccall f_2854(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2857)
static void C_ccall f_2857(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2860)
static void C_ccall f_2860(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2863)
static void C_ccall f_2863(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2821)
static void C_ccall f_2821(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2824)
static void C_ccall f_2824(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2827)
static void C_ccall f_2827(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2830)
static void C_ccall f_2830(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2802)
static void C_ccall f_2802(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2805)
static void C_ccall f_2805(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2775)
static void C_ccall f_2775(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2778)
static void C_ccall f_2778(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2724)
static void C_fcall f_2724(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2734)
static void C_ccall f_2734(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2737)
static void C_ccall f_2737(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2740)
static void C_ccall f_2740(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2666)
static void C_ccall f_2666(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2669)
static void C_ccall f_2669(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2672)
static void C_ccall f_2672(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2675)
static void C_ccall f_2675(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2678)
static void C_ccall f_2678(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2681)
static void C_ccall f_2681(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2529)
static void C_fcall f_2529(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2537)
static void C_ccall f_2537(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2497)
static void C_fcall f_2497(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2509)
static void C_ccall f_2509(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2517)
static void C_ccall f_2517(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2501)
static void C_ccall f_2501(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2474)
static void C_ccall f_2474(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2488)
static void C_ccall f_2488(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2480)
static void C_ccall f_2480(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2453)
static void C_ccall f_2453(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2453)
static void C_ccall f_2453r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2459)
static void C_ccall f_2459(C_word c,C_word t0,C_word t1,C_word t2) C_noret;

C_noret_decl(trf_8552)
static void C_fcall trf_8552(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8552(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8552(t0,t1);}

C_noret_decl(trf_8655)
static void C_fcall trf_8655(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8655(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8655(t0,t1);}

C_noret_decl(trf_8467)
static void C_fcall trf_8467(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8467(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8467(t0,t1);}

C_noret_decl(trf_8010)
static void C_fcall trf_8010(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8010(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8010(t0,t1);}

C_noret_decl(trf_8037)
static void C_fcall trf_8037(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8037(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8037(t0,t1);}

C_noret_decl(trf_8232)
static void C_fcall trf_8232(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8232(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8232(t0,t1);}

C_noret_decl(trf_8241)
static void C_fcall trf_8241(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8241(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8241(t0,t1);}

C_noret_decl(trf_8272)
static void C_fcall trf_8272(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8272(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8272(t0,t1);}

C_noret_decl(trf_7982)
static void C_fcall trf_7982(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7982(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7982(t0,t1);}

C_noret_decl(trf_7212)
static void C_fcall trf_7212(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7212(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7212(t0,t1);}

C_noret_decl(trf_7314)
static void C_fcall trf_7314(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7314(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7314(t0,t1);}

C_noret_decl(trf_7347)
static void C_fcall trf_7347(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7347(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7347(t0,t1);}

C_noret_decl(trf_7443)
static void C_fcall trf_7443(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7443(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7443(t0,t1);}

C_noret_decl(trf_7455)
static void C_fcall trf_7455(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7455(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7455(t0,t1);}

C_noret_decl(trf_7510)
static void C_fcall trf_7510(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7510(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7510(t0,t1);}

C_noret_decl(trf_7527)
static void C_fcall trf_7527(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7527(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7527(t0,t1);}

C_noret_decl(trf_7544)
static void C_fcall trf_7544(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7544(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7544(t0,t1);}

C_noret_decl(trf_7583)
static void C_fcall trf_7583(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7583(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7583(t0,t1);}

C_noret_decl(trf_7600)
static void C_fcall trf_7600(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7600(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7600(t0,t1);}

C_noret_decl(trf_7617)
static void C_fcall trf_7617(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7617(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7617(t0,t1);}

C_noret_decl(trf_7634)
static void C_fcall trf_7634(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7634(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7634(t0,t1);}

C_noret_decl(trf_7651)
static void C_fcall trf_7651(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7651(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7651(t0,t1);}

C_noret_decl(trf_7668)
static void C_fcall trf_7668(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7668(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7668(t0,t1);}

C_noret_decl(trf_7685)
static void C_fcall trf_7685(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7685(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7685(t0,t1);}

C_noret_decl(trf_7142)
static void C_fcall trf_7142(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7142(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7142(t0,t1,t2);}

C_noret_decl(trf_7137)
static void C_fcall trf_7137(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7137(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7137(t0,t1);}

C_noret_decl(trf_6676)
static void C_fcall trf_6676(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6676(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6676(t0,t1);}

C_noret_decl(trf_6685)
static void C_fcall trf_6685(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6685(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6685(t0,t1);}

C_noret_decl(trf_6697)
static void C_fcall trf_6697(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6697(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6697(t0,t1);}

C_noret_decl(trf_6709)
static void C_fcall trf_6709(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6709(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6709(t0,t1);}

C_noret_decl(trf_6749)
static void C_fcall trf_6749(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6749(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6749(t0,t1);}

C_noret_decl(trf_6244)
static void C_fcall trf_6244(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6244(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6244(t0,t1,t2);}

C_noret_decl(trf_6273)
static void C_fcall trf_6273(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6273(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6273(t0,t1);}

C_noret_decl(trf_6276)
static void C_fcall trf_6276(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6276(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6276(t0,t1);}

C_noret_decl(trf_6260)
static void C_fcall trf_6260(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6260(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6260(t0,t1);}

C_noret_decl(trf_6176)
static void C_fcall trf_6176(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6176(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6176(t0,t1,t2);}

C_noret_decl(trf_5378)
static void C_fcall trf_5378(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5378(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5378(t0,t1);}

C_noret_decl(trf_5406)
static void C_fcall trf_5406(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5406(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5406(t0,t1);}

C_noret_decl(trf_6024)
static void C_fcall trf_6024(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6024(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6024(t0,t1);}

C_noret_decl(trf_5472)
static void C_fcall trf_5472(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5472(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5472(t0,t1);}

C_noret_decl(trf_5986)
static void C_fcall trf_5986(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5986(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5986(t0,t1,t2,t3);}

C_noret_decl(trf_5929)
static void C_fcall trf_5929(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5929(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5929(t0,t1);}

C_noret_decl(trf_5950)
static void C_fcall trf_5950(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5950(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5950(t0,t1);}

C_noret_decl(trf_5893)
static void C_fcall trf_5893(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5893(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5893(t0,t1);}

C_noret_decl(trf_5860)
static void C_fcall trf_5860(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5860(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5860(t0,t1);}

C_noret_decl(trf_5869)
static void C_fcall trf_5869(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5869(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5869(t0,t1);}

C_noret_decl(trf_5814)
static void C_fcall trf_5814(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5814(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5814(t0,t1);}

C_noret_decl(trf_5504)
static void C_fcall trf_5504(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5504(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5504(t0,t1);}

C_noret_decl(trf_5564)
static void C_fcall trf_5564(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5564(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5564(t0,t1,t2,t3);}

C_noret_decl(trf_5116)
static void C_fcall trf_5116(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5116(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5116(t0,t1,t2,t3);}

C_noret_decl(trf_4945)
static void C_fcall trf_4945(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4945(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4945(t0,t1);}

C_noret_decl(trf_4951)
static void C_fcall trf_4951(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4951(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4951(t0,t1,t2,t3);}

C_noret_decl(trf_5147)
static void C_fcall trf_5147(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5147(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5147(t0,t1,t2,t3);}

C_noret_decl(trf_5154)
static void C_fcall trf_5154(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5154(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5154(t0,t1);}

C_noret_decl(trf_5243)
static void C_fcall trf_5243(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5243(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5243(t0,t1);}

C_noret_decl(trf_4982)
static void C_fcall trf_4982(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4982(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4982(t0,t1);}

C_noret_decl(trf_5289)
static void C_fcall trf_5289(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5289(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5289(t0,t1,t2);}

C_noret_decl(trf_5304)
static void C_fcall trf_5304(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5304(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5304(t0,t1,t2,t3);}

C_noret_decl(trf_5320)
static void C_fcall trf_5320(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5320(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5320(t0,t1);}

C_noret_decl(trf_5366)
static void C_fcall trf_5366(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5366(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5366(t0,t1,t2,t3);}

C_noret_decl(trf_4659)
static void C_fcall trf_4659(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4659(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4659(t0,t1);}

C_noret_decl(trf_4845)
static void C_fcall trf_4845(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4845(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4845(t0,t1);}

C_noret_decl(trf_4848)
static void C_fcall trf_4848(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4848(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4848(t0,t1);}

C_noret_decl(trf_4894)
static void C_fcall trf_4894(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4894(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4894(t0,t1);}

C_noret_decl(trf_4698)
static void C_fcall trf_4698(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4698(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4698(t0,t1,t2);}

C_noret_decl(trf_4662)
static void C_fcall trf_4662(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4662(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4662(t0,t1);}

C_noret_decl(trf_4675)
static void C_fcall trf_4675(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4675(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4675(t0,t1,t2,t3);}

C_noret_decl(trf_4408)
static void C_fcall trf_4408(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4408(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4408(t0,t1);}

C_noret_decl(trf_4446)
static void C_fcall trf_4446(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4446(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4446(t0,t1);}

C_noret_decl(trf_4467)
static void C_fcall trf_4467(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4467(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4467(t0,t1);}

C_noret_decl(trf_4532)
static void C_fcall trf_4532(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4532(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4532(t0,t1);}

C_noret_decl(trf_4259)
static void C_fcall trf_4259(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4259(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4259(t0,t1);}

C_noret_decl(trf_4280)
static void C_fcall trf_4280(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4280(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4280(t0,t1,t2,t3);}

C_noret_decl(trf_4349)
static void C_fcall trf_4349(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4349(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4349(t0,t1,t2);}

C_noret_decl(trf_4322)
static void C_fcall trf_4322(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4322(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4322(t0,t1,t2);}

C_noret_decl(trf_4112)
static void C_fcall trf_4112(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4112(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4112(t0,t1);}

C_noret_decl(trf_4115)
static void C_fcall trf_4115(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4115(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4115(t0,t1);}

C_noret_decl(trf_2539)
static void C_fcall trf_2539(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2539(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_2539(t0,t1,t2,t3,t4);}

C_noret_decl(trf_4080)
static void C_fcall trf_4080(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4080(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4080(t0,t1,t2,t3);}

C_noret_decl(trf_2542)
static void C_fcall trf_2542(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2542(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2542(t0,t1,t2,t3);}

C_noret_decl(trf_3981)
static void C_fcall trf_3981(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3981(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3981(t0,t1,t2,t3);}

C_noret_decl(trf_3219)
static void C_fcall trf_3219(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3219(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3219(t0,t1);}

C_noret_decl(trf_3225)
static void C_fcall trf_3225(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3225(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3225(t0,t1);}

C_noret_decl(trf_3358)
static void C_fcall trf_3358(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3358(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3358(t0,t1);}

C_noret_decl(trf_3463)
static void C_fcall trf_3463(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3463(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3463(t0,t1);}

C_noret_decl(trf_2724)
static void C_fcall trf_2724(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2724(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_2724(t0,t1,t2,t3,t4);}

C_noret_decl(trf_2529)
static void C_fcall trf_2529(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2529(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2529(t0,t1);}

C_noret_decl(trf_2497)
static void C_fcall trf_2497(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2497(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2497(t0,t1,t2);}

C_noret_decl(tr9)
static void C_fcall tr9(C_proc9 k) C_regparm C_noret;
C_regparm static void C_fcall tr9(C_proc9 k){
C_word t8=C_pick(0);
C_word t7=C_pick(1);
C_word t6=C_pick(2);
C_word t5=C_pick(3);
C_word t4=C_pick(4);
C_word t3=C_pick(5);
C_word t2=C_pick(6);
C_word t1=C_pick(7);
C_word t0=C_pick(8);
C_adjust_stack(-9);
(k)(9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_backend_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_backend_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("backend_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(2414)){
C_save(t1);
C_rereclaim2(2414*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,840);
lf[0]=C_h_intern(&lf[0],15,"\010compileroutput");
lf[1]=C_h_intern(&lf[1],12,"\010compilergen");
lf[2]=C_h_intern(&lf[2],7,"newline");
lf[3]=C_h_intern(&lf[3],7,"display");
lf[4]=C_h_intern(&lf[4],12,"\003sysfor-each");
lf[5]=C_h_intern(&lf[5],17,"\010compilergen-list");
lf[6]=C_h_intern(&lf[6],11,"intersperse");
lf[7]=C_h_intern(&lf[7],18,"\010compilerunique-id");
lf[8]=C_h_intern(&lf[8],22,"\010compilergenerate-code");
lf[9]=C_h_intern(&lf[9],13,"\010compilerbomb");
lf[10]=C_decode_literal(C_heaptop,"\376B\000\000\021can\047t find lambda");
lf[11]=C_h_intern(&lf[11],17,"lambda-literal-id");
lf[12]=C_h_intern(&lf[12],4,"find");
lf[13]=C_h_intern(&lf[13],17,"string-translate*");
lf[14]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376B\000\000\002*/\376B\000\000\003* /\376\377\016");
lf[15]=C_h_intern(&lf[15],8,"->string");
lf[16]=C_h_intern(&lf[16],14,"\004coreimmediate");
lf[17]=C_h_intern(&lf[17],4,"bool");
lf[18]=C_decode_literal(C_heaptop,"\376B\000\000\015C_SCHEME_TRUE");
lf[19]=C_decode_literal(C_heaptop,"\376B\000\000\016C_SCHEME_FALSE");
lf[20]=C_h_intern(&lf[20],4,"char");
lf[21]=C_decode_literal(C_heaptop,"\376B\000\000\021C_make_character(");
lf[22]=C_h_intern(&lf[22],3,"nil");
lf[23]=C_decode_literal(C_heaptop,"\376B\000\000\024C_SCHEME_END_OF_LIST");
lf[24]=C_h_intern(&lf[24],3,"fix");
lf[25]=C_decode_literal(C_heaptop,"\376B\000\000\006C_fix(");
lf[26]=C_h_intern(&lf[26],3,"eof");
lf[27]=C_decode_literal(C_heaptop,"\376B\000\000\024C_SCHEME_END_OF_FILE");
lf[28]=C_decode_literal(C_heaptop,"\376B\000\000\015bad immediate");
lf[29]=C_h_intern(&lf[29],12,"\004coreliteral");
lf[30]=C_decode_literal(C_heaptop,"\376B\000\000\013((C_word)li");
lf[31]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[32]=C_decode_literal(C_heaptop,"\376B\000\000\003lf[");
lf[33]=C_h_intern(&lf[33],2,"if");
lf[34]=C_decode_literal(C_heaptop,"\376B\000\000\005else{");
lf[35]=C_decode_literal(C_heaptop,"\376B\000\000\003)){");
lf[36]=C_decode_literal(C_heaptop,"\376B\000\000\013if(C_truep(");
lf[37]=C_h_intern(&lf[37],9,"\004coreproc");
lf[38]=C_decode_literal(C_heaptop,"\376B\000\000\010(C_word)");
lf[39]=C_h_intern(&lf[39],9,"\004corebind");
lf[40]=C_h_intern(&lf[40],8,"\004coreref");
lf[41]=C_decode_literal(C_heaptop,"\376B\000\000\002)[");
lf[42]=C_decode_literal(C_heaptop,"\376B\000\000\012((C_word*)");
lf[43]=C_h_intern(&lf[43],10,"\004coreunbox");
lf[44]=C_decode_literal(C_heaptop,"\376B\000\000\004)[1]");
lf[45]=C_decode_literal(C_heaptop,"\376B\000\000\012((C_word*)");
lf[46]=C_h_intern(&lf[46],13,"\004coreupdate_i");
lf[47]=C_decode_literal(C_heaptop,"\376B\000\000\021C_set_block_item(");
lf[48]=C_h_intern(&lf[48],11,"\004coreupdate");
lf[49]=C_decode_literal(C_heaptop,"\376B\000\000\002)+");
lf[50]=C_decode_literal(C_heaptop,"\376B\000\000\001,");
lf[51]=C_decode_literal(C_heaptop,"\376B\000\000\024C_mutate(((C_word *)");
lf[52]=C_h_intern(&lf[52],16,"\004coreupdatebox_i");
lf[53]=C_decode_literal(C_heaptop,"\376B\000\000\003,0,");
lf[54]=C_decode_literal(C_heaptop,"\376B\000\000\021C_set_block_item(");
lf[55]=C_h_intern(&lf[55],14,"\004coreupdatebox");
lf[56]=C_decode_literal(C_heaptop,"\376B\000\000\004)+1,");
lf[57]=C_decode_literal(C_heaptop,"\376B\000\000\024C_mutate(((C_word *)");
lf[58]=C_h_intern(&lf[58],12,"\004coreclosure");
lf[59]=C_decode_literal(C_heaptop,"\376B\000\000\021tmp=(C_word)a,a+=");
lf[60]=C_decode_literal(C_heaptop,"\376B\000\000\005,tmp)");
lf[61]=C_decode_literal(C_heaptop,"\376B\000\000\002a[");
lf[62]=C_decode_literal(C_heaptop,"\376B\000\000\002]=");
lf[63]=C_h_intern(&lf[63],8,"for-each");
lf[64]=C_h_intern(&lf[64],4,"iota");
lf[65]=C_decode_literal(C_heaptop,"\376B\000\000\023(*a=C_CLOSURE_TYPE|");
lf[66]=C_h_intern(&lf[66],8,"\004corebox");
lf[67]=C_decode_literal(C_heaptop,"\376B\000\000\030,tmp=(C_word)a,a+=2,tmp)");
lf[68]=C_decode_literal(C_heaptop,"\376B\000\000\031(*a=C_VECTOR_TYPE|1,a[1]=");
lf[69]=C_h_intern(&lf[69],10,"\004corelocal");
lf[70]=C_h_intern(&lf[70],13,"\004coresetlocal");
lf[71]=C_h_intern(&lf[71],11,"\004coreglobal");
lf[72]=C_decode_literal(C_heaptop,"\376B\000\000\003lf[");
lf[73]=C_decode_literal(C_heaptop,"\376B\000\000\001]");
lf[74]=C_decode_literal(C_heaptop,"\376B\000\000\017C_retrieve2(lf[");
lf[75]=C_decode_literal(C_heaptop,"\376B\000\000\002],");
lf[76]=C_h_intern(&lf[76],21,"\010compilerc-ify-string");
lf[77]=C_h_intern(&lf[77],14,"symbol->string");
lf[78]=C_decode_literal(C_heaptop,"\376B\000\000\016*((C_word*)lf[");
lf[79]=C_decode_literal(C_heaptop,"\376B\000\000\004]+1)");
lf[80]=C_decode_literal(C_heaptop,"\376B\000\000\016C_retrieve(lf[");
lf[81]=C_decode_literal(C_heaptop,"\376B\000\000\002])");
lf[82]=C_h_intern(&lf[82],14,"\004coresetglobal");
lf[83]=C_decode_literal(C_heaptop,"\376B\000\000\012 /* (set! ");
lf[84]=C_decode_literal(C_heaptop,"\376B\000\000\011 ...) */,");
lf[85]=C_decode_literal(C_heaptop,"\376B\000\000\015C_mutate(&lf[");
lf[86]=C_decode_literal(C_heaptop,"\376B\000\000\001]");
lf[87]=C_decode_literal(C_heaptop,"\376B\000\000\025C_mutate((C_word*)lf[");
lf[88]=C_decode_literal(C_heaptop,"\376B\000\000\003]+1");
lf[89]=C_h_intern(&lf[89],16,"\004coresetglobal_i");
lf[90]=C_decode_literal(C_heaptop,"\376B\000\000\003lf[");
lf[91]=C_decode_literal(C_heaptop,"\376B\000\000\005] /* ");
lf[92]=C_decode_literal(C_heaptop,"\376B\000\000\005 */ =");
lf[93]=C_decode_literal(C_heaptop,"\376B\000\000\024C_set_block_item(lf[");
lf[94]=C_decode_literal(C_heaptop,"\376B\000\000\005] /* ");
lf[95]=C_decode_literal(C_heaptop,"\376B\000\000\006 */,0,");
lf[96]=C_h_intern(&lf[96],14,"\004coreundefined");
lf[97]=C_decode_literal(C_heaptop,"\376B\000\000\022C_SCHEME_UNDEFINED");
lf[98]=C_h_intern(&lf[98],9,"\004corecall");
lf[99]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[100]=C_decode_literal(C_heaptop,"\376B\000\000\003,0,");
lf[101]=C_decode_literal(C_heaptop,"\376B\000\000\012goto loop;");
lf[102]=C_decode_literal(C_heaptop,"\376B\000\000\002c=");
lf[103]=C_decode_literal(C_heaptop,"\376B\000\000\002=t");
lf[104]=C_h_intern(&lf[104],26,"lambda-literal-temporaries");
lf[105]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[106]=C_h_intern(&lf[106],22,"lambda-literal-looping");
lf[107]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[108]=C_decode_literal(C_heaptop,"\376B\000\000\002)(");
lf[109]=C_decode_literal(C_heaptop,"\376B\000\000\020C_retrieve_proc(");
lf[110]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[111]=C_decode_literal(C_heaptop,"\376B\000\000\030C_retrieve2_symbol_proc(");
lf[112]=C_decode_literal(C_heaptop,"\376B\000\000\001,");
lf[113]=C_h_intern(&lf[113],13,"string-append");
lf[114]=C_decode_literal(C_heaptop,"\376B\000\000\003lf[");
lf[115]=C_decode_literal(C_heaptop,"\376B\000\000\001]");
lf[116]=C_decode_literal(C_heaptop,"\376B\000\000\020C_retrieve_proc(");
lf[117]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[118]=C_decode_literal(C_heaptop,"\376B\000\000\016*((C_word*)lf[");
lf[119]=C_decode_literal(C_heaptop,"\376B\000\000\004]+1)");
lf[120]=C_decode_literal(C_heaptop,"\376B\000\000\032C_retrieve_symbol_proc(lf[");
lf[121]=C_decode_literal(C_heaptop,"\376B\000\000\002])");
lf[122]=C_decode_literal(C_heaptop,"\376B\000\000\016*((C_word*)lf[");
lf[123]=C_decode_literal(C_heaptop,"\376B\000\000\004]+1)");
lf[124]=C_decode_literal(C_heaptop,"\376B\000\000\010((C_proc");
lf[125]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[126]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[127]=C_decode_literal(C_heaptop,"\376B\000\000\002)(");
lf[128]=C_decode_literal(C_heaptop,"\376B\000\000\002,t");
lf[129]=C_h_intern(&lf[129],6,"unsafe");
lf[130]=C_decode_literal(C_heaptop,"\376B\000\000\024(void*)(*((C_word*)t");
lf[131]=C_decode_literal(C_heaptop,"\376B\000\000\004+1))");
lf[132]=C_decode_literal(C_heaptop,"\376B\000\000\021C_retrieve_proc(t");
lf[133]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[134]=C_h_intern(&lf[134],28,"\010compilerno-procedure-checks");
lf[135]=C_decode_literal(C_heaptop,"\376B\000\000\010((C_proc");
lf[136]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[137]=C_h_intern(&lf[137],24,"\010compileremit-trace-info");
lf[138]=C_decode_literal(C_heaptop,"\376B\000\000\011C_trace(\042");
lf[139]=C_decode_literal(C_heaptop,"\376B\000\000\003\042);");
lf[140]=C_h_intern(&lf[140],16,"string-translate");
lf[141]=C_decode_literal(C_heaptop,"\376B\000\000\001\134");
lf[142]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[143]=C_decode_literal(C_heaptop,"\376B\000\000\003/* ");
lf[144]=C_decode_literal(C_heaptop,"\376B\000\000\003 */");
lf[145]=C_h_intern(&lf[145],27,"lambda-literal-closure-size");
lf[146]=C_h_intern(&lf[146],28,"\010compilersource-info->string");
lf[147]=C_h_intern(&lf[147],12,"\004corerecurse");
lf[148]=C_decode_literal(C_heaptop,"\376B\000\000\012goto loop;");
lf[149]=C_decode_literal(C_heaptop,"\376B\000\000\002=t");
lf[150]=C_decode_literal(C_heaptop,"\376B\000\000\003t0,");
lf[151]=C_h_intern(&lf[151],16,"\004coredirect_call");
lf[152]=C_decode_literal(C_heaptop,"\376B\000\000\011C_a_i(&a,");
lf[153]=C_h_intern(&lf[153],13,"\004corecallunit");
lf[154]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[155]=C_decode_literal(C_heaptop,"\376B\000\000\002C_");
lf[156]=C_decode_literal(C_heaptop,"\376B\000\000\012_toplevel(");
lf[157]=C_decode_literal(C_heaptop,"\376B\000\000\024,C_SCHEME_UNDEFINED,");
lf[158]=C_h_intern(&lf[158],11,"\004corereturn");
lf[159]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[160]=C_decode_literal(C_heaptop,"\376B\000\000\007return(");
lf[161]=C_h_intern(&lf[161],11,"\004coreinline");
lf[162]=C_decode_literal(C_heaptop,"\376B\000\000\010(C_word)");
lf[163]=C_h_intern(&lf[163],20,"\004coreinline_allocate");
lf[164]=C_decode_literal(C_heaptop,"\376B\000\000\010(C_word)");
lf[165]=C_decode_literal(C_heaptop,"\376B\000\000\004(&a,");
lf[166]=C_h_intern(&lf[166],15,"\004coreinline_ref");
lf[167]=C_h_intern(&lf[167],34,"\010compilerforeign-result-conversion");
lf[168]=C_decode_literal(C_heaptop,"\376B\000\000\001a");
lf[169]=C_h_intern(&lf[169],18,"\004coreinline_update");
lf[170]=C_decode_literal(C_heaptop,"\376B\000\000\025),C_SCHEME_UNDEFINED)");
lf[171]=C_decode_literal(C_heaptop,"\376B\000\000\002=(");
lf[172]=C_h_intern(&lf[172],36,"\010compilerforeign-argument-conversion");
lf[173]=C_h_intern(&lf[173],33,"\010compilerforeign-type-declaration");
lf[174]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[175]=C_h_intern(&lf[175],19,"\004coreinline_loc_ref");
lf[176]=C_decode_literal(C_heaptop,"\376B\000\000\003)))");
lf[177]=C_decode_literal(C_heaptop,"\376B\000\000\003*((");
lf[178]=C_decode_literal(C_heaptop,"\376B\000\000\021*)C_data_pointer(");
lf[179]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[180]=C_decode_literal(C_heaptop,"\376B\000\000\001a");
lf[181]=C_h_intern(&lf[181],22,"\004coreinline_loc_update");
lf[182]=C_decode_literal(C_heaptop,"\376B\000\000\025),C_SCHEME_UNDEFINED)");
lf[183]=C_decode_literal(C_heaptop,"\376B\000\000\003))=");
lf[184]=C_decode_literal(C_heaptop,"\376B\000\000\004((*(");
lf[185]=C_decode_literal(C_heaptop,"\376B\000\000\021*)C_data_pointer(");
lf[186]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[187]=C_h_intern(&lf[187],11,"\004coreswitch");
lf[188]=C_decode_literal(C_heaptop,"\376B\000\000\010default:");
lf[189]=C_decode_literal(C_heaptop,"\376B\000\000\005case ");
lf[190]=C_decode_literal(C_heaptop,"\376B\000\000\002){");
lf[191]=C_decode_literal(C_heaptop,"\376B\000\000\007switch(");
lf[192]=C_h_intern(&lf[192],9,"\004corecond");
lf[193]=C_decode_literal(C_heaptop,"\376B\000\000\002)\077");
lf[194]=C_decode_literal(C_heaptop,"\376B\000\000\011(C_truep(");
lf[195]=C_decode_literal(C_heaptop,"\376B\000\000\010bad form");
lf[196]=C_h_intern(&lf[196],13,"pair-for-each");
lf[197]=C_decode_literal(C_heaptop,"\376B\000\000\0010");
lf[198]=C_h_intern(&lf[198],30,"\010compilerexternal-protos-first");
lf[199]=C_h_intern(&lf[199],50,"\010compilergenerate-foreign-callback-stub-prototypes");
lf[200]=C_h_intern(&lf[200],22,"foreign-callback-stubs");
lf[201]=C_h_intern(&lf[201],29,"\010compilerforeign-declarations");
lf[202]=C_decode_literal(C_heaptop,"\376B\000\000\002*/");
lf[203]=C_decode_literal(C_heaptop,"\376B\000\000\012#include \042");
lf[204]=C_h_intern(&lf[204],28,"\010compilertarget-include-file");
lf[205]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[206]=C_h_intern(&lf[206],18,"\010compilerunit-name");
lf[207]=C_decode_literal(C_heaptop,"\376B\000\000\011   unit: ");
lf[208]=C_h_intern(&lf[208],19,"\010compilerused-units");
lf[209]=C_decode_literal(C_heaptop,"\376B\000\000\017   used units: ");
lf[210]=C_h_intern(&lf[210],27,"\010compilercompiler-arguments");
lf[211]=C_decode_literal(C_heaptop,"\376B\000\000\022/* Generated from ");
lf[212]=C_decode_literal(C_heaptop,"\376B\000\000\030 by the CHICKEN compiler");
lf[213]=C_decode_literal(C_heaptop,"\376B\000\0000   http://www.call-with-current-continuation.org");
lf[214]=C_decode_literal(C_heaptop,"\376B\000\000\003   ");
lf[215]=C_decode_literal(C_heaptop,"\376B\000\000\021   command line: ");
lf[216]=C_h_intern(&lf[216],18,"string-intersperse");
lf[217]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[218]=C_decode_literal(C_heaptop,"\376B\000\000\003   ");
lf[219]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[220]=C_h_intern(&lf[220],7,"\003sysmap");
lf[221]=C_h_intern(&lf[221],12,"string-split");
lf[222]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[223]=C_h_intern(&lf[223],15,"chicken-version");
lf[224]=C_h_intern(&lf[224],18,"\003sysdecode-seconds");
lf[225]=C_h_intern(&lf[225],15,"current-seconds");
lf[226]=C_decode_literal(C_heaptop,"\376B\000\000\002};");
lf[227]=C_decode_literal(C_heaptop,"\376B\000\000\002,0");
lf[228]=C_decode_literal(C_heaptop,"\376B\000\000\026static C_char C_TLS li");
lf[229]=C_decode_literal(C_heaptop,"\376B\000\000\026[] C_aligned={C_lihdr(");
lf[230]=C_h_intern(&lf[230],23,"\003syslambda-info->string");
lf[231]=C_decode_literal(C_heaptop,"\376B\000\000)static double C_possibly_force_alignment;");
lf[232]=C_decode_literal(C_heaptop,"\376B\000\000\027static C_TLS C_word lf[");
lf[233]=C_decode_literal(C_heaptop,"\376B\000\000\002];");
lf[234]=C_decode_literal(C_heaptop,"\376B\000\000\017C_noret_decl(C_");
lf[235]=C_decode_literal(C_heaptop,"\376B\000\000\012_toplevel)");
lf[236]=C_decode_literal(C_heaptop,"\376B\000\000\036C_externimport void C_ccall C_");
lf[237]=C_decode_literal(C_heaptop,"\376B\000\000._toplevel(C_word c,C_word d,C_word k) C_noret;");
lf[238]=C_decode_literal(C_heaptop,"\376B\000\000+static C_PTABLE_ENTRY *create_ptable(void);");
lf[239]=C_decode_literal(C_heaptop,"\376B\000\000\012) C_noret;");
lf[240]=C_h_intern(&lf[240],9,"make-list");
lf[241]=C_decode_literal(C_heaptop,"\376B\000\000\007,C_word");
lf[242]=C_decode_literal(C_heaptop,"\376B\000\000\025typedef void (*C_proc");
lf[243]=C_decode_literal(C_heaptop,"\376B\000\000\010)(C_word");
lf[244]=C_h_intern(&lf[244],4,"none");
lf[245]=C_decode_literal(C_heaptop,"\376B\000\000\011,C_word t");
lf[246]=C_decode_literal(C_heaptop,"\376B\000\000\012) C_noret;");
lf[247]=C_decode_literal(C_heaptop,"\376B\000\000\015C_noret_decl(");
lf[248]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[249]=C_decode_literal(C_heaptop,"\376B\000\000\024static void C_ccall ");
lf[250]=C_decode_literal(C_heaptop,"\376B\000\000\002r(");
lf[251]=C_decode_literal(C_heaptop,"\376B\000\000\016,...) C_noret;");
lf[252]=C_decode_literal(C_heaptop,"\376B\000\000\010 C_noret");
lf[253]=C_decode_literal(C_heaptop,"\376B\000\000\011C_word *a");
lf[254]=C_decode_literal(C_heaptop,"\376B\000\000\011C_word c,");
lf[255]=C_h_intern(&lf[255],8,"toplevel");
lf[256]=C_decode_literal(C_heaptop,"\376B\000\000\002C_");
lf[257]=C_decode_literal(C_heaptop,"\376B\000\000\034C_externexport void C_ccall ");
lf[258]=C_h_intern(&lf[258],27,"\010compileremit-unsafe-marker");
lf[259]=C_decode_literal(C_heaptop,"\376B\000\0001C_externexport void C_dynamic_and_unsafe(void) {}");
lf[260]=C_decode_literal(C_heaptop,"\376B\000\000\017C_noret_decl(C_");
lf[261]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[262]=C_decode_literal(C_heaptop,"\376B\000\000\011_toplevel");
lf[263]=C_decode_literal(C_heaptop,"\376B\000\000\010toplevel");
lf[264]=C_decode_literal(C_heaptop,"\376B\000\000\010C_fcall ");
lf[265]=C_decode_literal(C_heaptop,"\376B\000\000\010C_ccall ");
lf[266]=C_decode_literal(C_heaptop,"\376B\000\000\007C_word ");
lf[267]=C_decode_literal(C_heaptop,"\376B\000\000\005void ");
lf[268]=C_decode_literal(C_heaptop,"\376B\000\000\007static ");
lf[269]=C_decode_literal(C_heaptop,"\376B\000\000\015C_noret_decl(");
lf[270]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[271]=C_h_intern(&lf[271],21,"small-parameter-limit");
lf[272]=C_h_intern(&lf[272],11,"lset-adjoin");
lf[273]=C_h_intern(&lf[273],1,"=");
lf[274]=C_h_intern(&lf[274],32,"lambda-literal-callee-signatures");
lf[275]=C_h_intern(&lf[275],24,"lambda-literal-allocated");
lf[276]=C_h_intern(&lf[276],21,"lambda-literal-direct");
lf[277]=C_h_intern(&lf[277],33,"lambda-literal-rest-argument-mode");
lf[278]=C_h_intern(&lf[278],28,"lambda-literal-rest-argument");
lf[279]=C_h_intern(&lf[279],27,"\010compilermake-variable-list");
lf[280]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[281]=C_h_intern(&lf[281],27,"lambda-literal-customizable");
lf[282]=C_h_intern(&lf[282],29,"lambda-literal-argument-count");
lf[283]=C_decode_literal(C_heaptop,"\376B\000\000\020C_adjust_stack(-");
lf[284]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[285]=C_decode_literal(C_heaptop,"\376B\000\000\010C_word t");
lf[286]=C_decode_literal(C_heaptop,"\376B\000\000\010=C_pick(");
lf[287]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[288]=C_decode_literal(C_heaptop,"\376B\000\000\003);}");
lf[289]=C_h_intern(&lf[289],27,"\010compilermake-argument-list");
lf[290]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[291]=C_decode_literal(C_heaptop,"\376B\000\000\004(k)(");
lf[292]=C_decode_literal(C_heaptop,"\376B\000\000\006(a,n);");
lf[293]=C_decode_literal(C_heaptop,"\376B\000\000\007_vector");
lf[294]=C_decode_literal(C_heaptop,"\376B\000\000\017=C_restore_rest");
lf[295]=C_decode_literal(C_heaptop,"\376B\000\000\017a=C_alloc(n+1);");
lf[296]=C_decode_literal(C_heaptop,"\376B\000\000\017a=C_alloc(n*3);");
lf[297]=C_decode_literal(C_heaptop,"\376B\000\000\022n=C_rest_count(0);");
lf[298]=C_decode_literal(C_heaptop,"\376B\000\000\007(C_proc");
lf[299]=C_decode_literal(C_heaptop,"\376B\000\000\004 k){");
lf[300]=C_decode_literal(C_heaptop,"\376B\000\000\006int n;");
lf[301]=C_decode_literal(C_heaptop,"\376B\000\000\013C_word *a,t");
lf[302]=C_decode_literal(C_heaptop,"\376B\000\000 C_regparm static void C_fcall tr");
lf[303]=C_decode_literal(C_heaptop,"\376B\000\000\007(C_proc");
lf[304]=C_decode_literal(C_heaptop,"\376B\000\000\026 k) C_regparm C_noret;");
lf[305]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[306]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[307]=C_decode_literal(C_heaptop,"\376B\000\000\017C_noret_decl(tr");
lf[308]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[309]=C_decode_literal(C_heaptop,"\376B\000\000\026static void C_fcall tr");
lf[310]=C_decode_literal(C_heaptop,"\376B\000\000\003);}");
lf[311]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[312]=C_decode_literal(C_heaptop,"\376B\000\000\004(k)(");
lf[313]=C_decode_literal(C_heaptop,"\376B\000\000 C_regparm static void C_fcall tr");
lf[314]=C_decode_literal(C_heaptop,"\376B\000\000\007(C_proc");
lf[315]=C_decode_literal(C_heaptop,"\376B\000\000\004 k){");
lf[316]=C_decode_literal(C_heaptop,"\376B\000\000\017C_noret_decl(tr");
lf[317]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[318]=C_decode_literal(C_heaptop,"\376B\000\000\026static void C_fcall tr");
lf[319]=C_decode_literal(C_heaptop,"\376B\000\000\007(C_proc");
lf[320]=C_decode_literal(C_heaptop,"\376B\000\000\026 k) C_regparm C_noret;");
lf[321]=C_decode_literal(C_heaptop,"\376B\000\000\003);}");
lf[322]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[323]=C_decode_literal(C_heaptop,"\376B\000\000 C_regparm static void C_fcall tr");
lf[324]=C_decode_literal(C_heaptop,"\376B\000\000\016(void *dummy){");
lf[325]=C_decode_literal(C_heaptop,"\376B\000\000\017C_noret_decl(tr");
lf[326]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[327]=C_decode_literal(C_heaptop,"\376B\000\000\026static void C_fcall tr");
lf[328]=C_decode_literal(C_heaptop,"\376B\000\000 (void *dummy) C_regparm C_noret;");
lf[329]=C_h_intern(&lf[329],6,"vector");
lf[330]=C_h_intern(&lf[330],23,"lambda-literal-external");
lf[331]=C_h_intern(&lf[331],14,"\003syscopy-bytes");
lf[332]=C_h_intern(&lf[332],11,"make-string");
lf[333]=C_h_intern(&lf[333],6,"modulo");
lf[334]=C_h_intern(&lf[334],3,"fx/");
lf[335]=C_decode_literal(C_heaptop,"\376B\000\000\035type of literal not supported");
lf[336]=C_decode_literal(C_heaptop,"\376B\000\000\007=C_fix(");
lf[337]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[338]=C_h_intern(&lf[338],19,"\003sysundefined-value");
lf[339]=C_decode_literal(C_heaptop,"\376B\000\000\024=C_SCHEME_UNDEFINED;");
lf[340]=C_decode_literal(C_heaptop,"\376B\000\000\015C_SCHEME_TRUE");
lf[341]=C_decode_literal(C_heaptop,"\376B\000\000\016C_SCHEME_FALSE");
lf[342]=C_decode_literal(C_heaptop,"\376B\000\000\022=C_make_character(");
lf[343]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[344]=C_decode_literal(C_heaptop,"\376B\000\000\014C_h_intern(&");
lf[345]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[346]=C_decode_literal(C_heaptop,"\376B\000\000\001=");
lf[347]=C_decode_literal(C_heaptop,"\376B\000\000\026=C_SCHEME_END_OF_LIST;");
lf[348]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[349]=C_h_intern(&lf[349],23,"\010compilerencode-literal");
lf[350]=C_decode_literal(C_heaptop,"\376B\000\000\034=C_decode_literal(C_heaptop,");
lf[351]=C_h_intern(&lf[351],32,"\010compilerblock-variable-literal\077");
lf[352]=C_h_intern(&lf[352],20,"\010compilerbig-fixnum\077");
lf[353]=C_h_intern(&lf[353],7,"sprintf");
lf[354]=C_decode_literal(C_heaptop,"\376B\000\000\006lf[~s]");
lf[355]=C_h_intern(&lf[355],25,"\010compilerwords-per-flonum");
lf[356]=C_h_intern(&lf[356],6,"reduce");
lf[357]=C_h_intern(&lf[357],1,"+");
lf[358]=C_h_intern(&lf[358],12,"vector->list");
lf[359]=C_h_intern(&lf[359],14,"\010compilerwords");
lf[360]=C_h_intern(&lf[360],15,"\003sysbytevector\077");
lf[361]=C_h_intern(&lf[361],19,"\010compilerimmediate\077");
lf[362]=C_h_intern(&lf[362],19,"lambda-literal-body");
lf[363]=C_decode_literal(C_heaptop,"\376B\000\000\022C_word *a=C_alloc(");
lf[364]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[365]=C_decode_literal(C_heaptop,"\376B\000\000\010C_word t");
lf[366]=C_decode_literal(C_heaptop,"\376B\000\000\013C_word tmp;");
lf[367]=C_decode_literal(C_heaptop,"\376B\000\000\011,C_word t");
lf[368]=C_decode_literal(C_heaptop,"\376B\000\000\002){");
lf[369]=C_decode_literal(C_heaptop,"\376B\000\000\024static void C_ccall ");
lf[370]=C_decode_literal(C_heaptop,"\376B\000\000\002r(");
lf[371]=C_decode_literal(C_heaptop,"\376B\000\000\002,t");
lf[372]=C_decode_literal(C_heaptop,"\376B\000\000\004);}}");
lf[373]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[374]=C_decode_literal(C_heaptop,"\376B\000\000\002r(");
lf[375]=C_h_intern(&lf[375],4,"list");
lf[376]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[377]=C_decode_literal(C_heaptop,"\376B\000\000#=C_restore_rest(a,C_rest_count(0));");
lf[378]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[379]=C_decode_literal(C_heaptop,"\376B\000\000*=C_restore_rest_vector(a,C_rest_count(0));");
lf[380]=C_decode_literal(C_heaptop,"\376B\000\000\003);}");
lf[381]=C_decode_literal(C_heaptop,"\376B\000\000\005else{");
lf[382]=C_decode_literal(C_heaptop,"\376B\000\000\015a=C_alloc((c-");
lf[383]=C_decode_literal(C_heaptop,"\376B\000\000\005)*3);");
lf[384]=C_decode_literal(C_heaptop,"\376B\000\000\010,(void*)");
lf[385]=C_decode_literal(C_heaptop,"\376B\000\000\001r");
lf[386]=C_decode_literal(C_heaptop,"\376B\000\000\022C_save_and_reclaim");
lf[387]=C_decode_literal(C_heaptop,"\376B\000\000\011C_reclaim");
lf[388]=C_decode_literal(C_heaptop,"\376B\000\000\012((void*)tr");
lf[389]=C_decode_literal(C_heaptop,"\376B\000\000\003);}");
lf[390]=C_decode_literal(C_heaptop,"\376B\000\000\005,NULL");
lf[391]=C_decode_literal(C_heaptop,"\376B\000\000\010,(void*)");
lf[392]=C_decode_literal(C_heaptop,"\376B\000\000\022C_save_and_reclaim");
lf[393]=C_decode_literal(C_heaptop,"\376B\000\000\011C_reclaim");
lf[394]=C_decode_literal(C_heaptop,"\376B\000\000\012((void*)tr");
lf[395]=C_decode_literal(C_heaptop,"\376B\000\000\022C_register_lf2(lf,");
lf[396]=C_decode_literal(C_heaptop,"\376B\000\000\022,create_ptable());");
lf[397]=C_decode_literal(C_heaptop,"\376B\000\000\023C_initialize_lf(lf,");
lf[398]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[399]=C_decode_literal(C_heaptop,"\376B\000\000\012a=C_alloc(");
lf[400]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[401]=C_decode_literal(C_heaptop,"\376B\000\000\017if(!C_demand_2(");
lf[402]=C_decode_literal(C_heaptop,"\376B\000\000\003)){");
lf[403]=C_decode_literal(C_heaptop,"\376B\000\000\013C_save(t1);");
lf[404]=C_decode_literal(C_heaptop,"\376B\000\000\015C_rereclaim2(");
lf[405]=C_decode_literal(C_heaptop,"\376B\000\000\024*sizeof(C_word), 1);");
lf[406]=C_decode_literal(C_heaptop,"\376B\000\000\016t1=C_restore;}");
lf[407]=C_decode_literal(C_heaptop,"\376B\000\000\030C_check_nursery_minimum(");
lf[408]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[409]=C_decode_literal(C_heaptop,"\376B\000\000\015if(!C_demand(");
lf[410]=C_decode_literal(C_heaptop,"\376B\000\000\003)){");
lf[411]=C_decode_literal(C_heaptop,"\376B\000\000\013C_save(t1);");
lf[412]=C_decode_literal(C_heaptop,"\376B\000\000,C_reclaim((void*)toplevel_trampoline,NULL);}");
lf[413]=C_decode_literal(C_heaptop,"\376B\000\000\027toplevel_initialized=1;");
lf[414]=C_h_intern(&lf[414],26,"\010compilertarget-stack-size");
lf[415]=C_decode_literal(C_heaptop,"\376B\000\000\017C_resize_stack(");
lf[416]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[417]=C_h_intern(&lf[417],30,"\010compilertarget-heap-shrinkage");
lf[418]=C_decode_literal(C_heaptop,"\376B\000\000\021C_heap_shrinkage=");
lf[419]=C_h_intern(&lf[419],27,"\010compilertarget-heap-growth");
lf[420]=C_decode_literal(C_heaptop,"\376B\000\000\016C_heap_growth=");
lf[421]=C_h_intern(&lf[421],33,"\010compilertarget-initial-heap-size");
lf[422]=C_decode_literal(C_heaptop,"\376B\000\000\032C_set_or_change_heap_size(");
lf[423]=C_decode_literal(C_heaptop,"\376B\000\000\004,1);");
lf[424]=C_h_intern(&lf[424],25,"\010compilertarget-heap-size");
lf[425]=C_decode_literal(C_heaptop,"\376B\000\000\032C_set_or_change_heap_size(");
lf[426]=C_decode_literal(C_heaptop,"\376B\000\000\004,1);");
lf[427]=C_decode_literal(C_heaptop,"\376B\000\000\027C_heap_size_is_fixed=1;");
lf[428]=C_h_intern(&lf[428],40,"\010compilerdisable-stack-overflow-checking");
lf[429]=C_decode_literal(C_heaptop,"\376B\000\000\033C_disable_overflow_check=1;");
lf[430]=C_decode_literal(C_heaptop,"\376B\000\000\012C_word *a;");
lf[431]=C_decode_literal(C_heaptop,"\376B\000\000;if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);");
lf[432]=C_decode_literal(C_heaptop,"\376B\000\000\036else C_toplevel_entry(C_text(\042");
lf[433]=C_decode_literal(C_heaptop,"\376B\000\000\004\042));");
lf[434]=C_h_intern(&lf[434],4,"fold");
lf[435]=C_decode_literal(C_heaptop,"\376B\000\000\035if(!C_demand(c*C_SIZEOF_PAIR+");
lf[436]=C_decode_literal(C_heaptop,"\376B\000\000\003)){");
lf[437]=C_h_intern(&lf[437],28,"\010compilerinsert-timer-checks");
lf[438]=C_decode_literal(C_heaptop,"\376B\000\000\026C_check_for_interrupt;");
lf[439]=C_decode_literal(C_heaptop,"\376B\000\000\005if(c<");
lf[440]=C_decode_literal(C_heaptop,"\376B\000\000\025) C_bad_min_argc_2(c,");
lf[441]=C_decode_literal(C_heaptop,"\376B\000\000\005,t0);");
lf[442]=C_h_intern(&lf[442],23,"\010compilerno-argc-checks");
lf[443]=C_decode_literal(C_heaptop,"\376B\000\000\004,c2,");
lf[444]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[445]=C_decode_literal(C_heaptop,"\376B\000\000\001c");
lf[446]=C_decode_literal(C_heaptop,"\376B\000\000\014C_save_rest(");
lf[447]=C_decode_literal(C_heaptop,"\376B\000\000\017C_word *a,c2=c;");
lf[448]=C_decode_literal(C_heaptop,"\376B\000\000\012va_list v;");
lf[449]=C_decode_literal(C_heaptop,"\376B\000\000\026if(!C_stack_probe(a)){");
lf[450]=C_decode_literal(C_heaptop,"\376B\000\000\027if(!C_stack_probe(&a)){");
lf[451]=C_decode_literal(C_heaptop,"\376B\000\000\026C_check_for_interrupt;");
lf[452]=C_decode_literal(C_heaptop,"\376B\000\000\005if(c<");
lf[453]=C_decode_literal(C_heaptop,"\376B\000\000\025) C_bad_min_argc_2(c,");
lf[454]=C_decode_literal(C_heaptop,"\376B\000\000\005,t0);");
lf[455]=C_decode_literal(C_heaptop,"\376B\000\000\006if(c!=");
lf[456]=C_decode_literal(C_heaptop,"\376B\000\000\021) C_bad_argc_2(c,");
lf[457]=C_decode_literal(C_heaptop,"\376B\000\000\005,t0);");
lf[458]=C_decode_literal(C_heaptop,"\376B\000\000\012C_word *a;");
lf[459]=C_decode_literal(C_heaptop,"\376B\000\000\005loop:");
lf[460]=C_decode_literal(C_heaptop,"\376B\000\000\012a=C_alloc(");
lf[461]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[462]=C_decode_literal(C_heaptop,"\376B\000\000\012C_word ab[");
lf[463]=C_decode_literal(C_heaptop,"\376B\000\000\010],*a=ab;");
lf[464]=C_decode_literal(C_heaptop,"\376B\000\000\016C_stack_check;");
lf[465]=C_decode_literal(C_heaptop,"\376B\000\000\005loop:");
lf[466]=C_decode_literal(C_heaptop,"\376B\000\000\012C_word *a;");
lf[467]=C_decode_literal(C_heaptop,"\376B\000\000\010C_word t");
lf[468]=C_decode_literal(C_heaptop,"\376B\000\000\010C_word t");
lf[469]=C_decode_literal(C_heaptop,"\376B\000\000\013C_word tmp;");
lf[470]=C_decode_literal(C_heaptop,"\376B\000\000\002){");
lf[471]=C_decode_literal(C_heaptop,"\376B\000\000\004,...");
lf[472]=C_decode_literal(C_heaptop,"\376B\000\000\011C_word *a");
lf[473]=C_decode_literal(C_heaptop,"\376B\000\000\011C_word c,");
lf[474]=C_decode_literal(C_heaptop,"\376B\000\000!C_noret_decl(toplevel_trampoline)");
lf[475]=C_decode_literal(C_heaptop,"\376B\000\000Gstatic void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;");
lf[476]=C_decode_literal(C_heaptop,"\376B\000\000\077C_regparm static void C_fcall toplevel_trampoline(void *dummy){");
lf[477]=C_decode_literal(C_heaptop,"\376B\000\000\002C_");
lf[478]=C_decode_literal(C_heaptop,"\376B\000\000\042(2,C_SCHEME_UNDEFINED,C_restore);}");
lf[479]=C_decode_literal(C_heaptop,"\376B\000\000\017void C_ccall C_");
lf[480]=C_decode_literal(C_heaptop,"\376B\000\000\022C_main_entry_point");
lf[481]=C_decode_literal(C_heaptop,"\376B\000\000(static C_TLS int toplevel_initialized=0;");
lf[482]=C_decode_literal(C_heaptop,"\376B\000\000\010C_fcall ");
lf[483]=C_decode_literal(C_heaptop,"\376B\000\000\010C_ccall ");
lf[484]=C_decode_literal(C_heaptop,"\376B\000\000\007C_word ");
lf[485]=C_decode_literal(C_heaptop,"\376B\000\000\005void ");
lf[486]=C_decode_literal(C_heaptop,"\376B\000\000\007static ");
lf[487]=C_decode_literal(C_heaptop,"\376B\000\000\003/* ");
lf[488]=C_decode_literal(C_heaptop,"\376B\000\000\003 */");
lf[489]=C_h_intern(&lf[489],16,"\010compilercleanup");
lf[490]=C_h_intern(&lf[490],18,"\010compilerdebugging");
lf[491]=C_h_intern(&lf[491],1,"o");
lf[492]=C_decode_literal(C_heaptop,"\376B\000\000 dropping unused closure argument");
lf[493]=C_decode_literal(C_heaptop,"\376B\000\000\011_toplevel");
lf[494]=C_decode_literal(C_heaptop,"\376B\000\000\010toplevel");
lf[495]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[496]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[497]=C_h_intern(&lf[497],18,"\010compilerreal-name");
lf[498]=C_decode_literal(C_heaptop,"\376B\000\000\021/* end of file */");
lf[499]=C_h_intern(&lf[499],25,"emit-procedure-table-info");
lf[500]=C_h_intern(&lf[500],31,"generate-foreign-callback-stubs");
lf[501]=C_h_intern(&lf[501],31,"\010compilergenerate-foreign-stubs");
lf[502]=C_h_intern(&lf[502],29,"\010compilerforeign-lambda-stubs");
lf[503]=C_h_intern(&lf[503],36,"\010compilergenerate-external-variables");
lf[504]=C_h_intern(&lf[504],27,"\010compilerexternal-variables");
lf[505]=C_h_intern(&lf[505],1,"p");
lf[506]=C_decode_literal(C_heaptop,"\376B\000\000\030code generation phase...");
lf[507]=C_decode_literal(C_heaptop,"\376B\000\000\001{");
lf[508]=C_decode_literal(C_heaptop,"\376B\000\000\027#ifdef C_ENABLE_PTABLES");
lf[509]=C_decode_literal(C_heaptop,"\376B\000\000\016return ptable;");
lf[510]=C_decode_literal(C_heaptop,"\376B\000\000\005#else");
lf[511]=C_decode_literal(C_heaptop,"\376B\000\000\014return NULL;");
lf[512]=C_decode_literal(C_heaptop,"\376B\000\000\006#endif");
lf[513]=C_decode_literal(C_heaptop,"\376B\000\000\001}");
lf[514]=C_decode_literal(C_heaptop,"\376B\000\000*static C_PTABLE_ENTRY *create_ptable(void)");
lf[515]=C_decode_literal(C_heaptop,"\376B\000\000\006#endif");
lf[516]=C_decode_literal(C_heaptop,"\376B\000\000\015{NULL,NULL}};");
lf[517]=C_decode_literal(C_heaptop,"\376B\000\000\002C_");
lf[518]=C_decode_literal(C_heaptop,"\376B\000\000\013_toplevel},");
lf[519]=C_decode_literal(C_heaptop,"\376B\000\000\014C_toplevel},");
lf[520]=C_decode_literal(C_heaptop,"\376B\000\000\002},");
lf[521]=C_decode_literal(C_heaptop,"\376B\000\000\002{\042");
lf[522]=C_decode_literal(C_heaptop,"\376B\000\000\011\042,(void*)");
lf[523]=C_h_intern(&lf[523],29,"\010compilerstring->c-identifier");
lf[524]=C_decode_literal(C_heaptop,"\376B\000\000\027#ifdef C_ENABLE_PTABLES");
lf[525]=C_decode_literal(C_heaptop,"\376B\000\000\035static C_PTABLE_ENTRY ptable[");
lf[526]=C_decode_literal(C_heaptop,"\376B\000\000\005] = {");
lf[527]=C_h_intern(&lf[527],11,"string-copy");
lf[528]=C_decode_literal(C_heaptop,"\376B\000\000\007C_word ");
lf[529]=C_h_intern(&lf[529],13,"list-tabulate");
lf[530]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[531]=C_decode_literal(C_heaptop,"\376B\000\000\007static ");
lf[532]=C_h_intern(&lf[532],41,"\010compilergenerate-foreign-callback-header");
lf[533]=C_decode_literal(C_heaptop,"\376B\000\000\017C_externexport ");
lf[534]=C_decode_literal(C_heaptop,"\376B\000\000.C_k=C_restore_callback_continuation2(C_level);");
lf[535]=C_decode_literal(C_heaptop,"\376B\000\000\024C_kontinue(C_k,C_r);");
lf[536]=C_decode_literal(C_heaptop,"\376B\000\000\024C_kontinue(C_k,C_r);");
lf[537]=C_decode_literal(C_heaptop,"\376B\000\000\013return C_r;");
lf[538]=C_decode_literal(C_heaptop,"\376B\000\000\015#undef return");
lf[539]=C_decode_literal(C_heaptop,"\376B\000\000\006C_ret:");
lf[540]=C_decode_literal(C_heaptop,"\376B\000\000.C_k=C_restore_callback_continuation2(C_level);");
lf[541]=C_decode_literal(C_heaptop,"\376B\000\000\024C_kontinue(C_k,C_r);");
lf[542]=C_decode_literal(C_heaptop,"\376B\000\000\024C_kontinue(C_k,C_r);");
lf[543]=C_decode_literal(C_heaptop,"\376B\000\000\013return C_r;");
lf[544]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[545]=C_h_intern(&lf[545],4,"void");
lf[546]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[547]=C_decode_literal(C_heaptop,"\376B\000\000\004C_r=");
lf[548]=C_decode_literal(C_heaptop,"\376B\000\0003int C_level=C_save_callback_continuation(&C_a,C_k);");
lf[549]=C_decode_literal(C_heaptop,"\376B\000\000\002=(");
lf[550]=C_decode_literal(C_heaptop,"\376B\000\000\003C_a");
lf[551]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[552]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[553]=C_decode_literal(C_heaptop,"\376B\000\000\003t~a");
lf[554]=C_decode_literal(C_heaptop,"\376B\000\0002C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;");
lf[555]=C_decode_literal(C_heaptop,"\376B\000\000\002){");
lf[556]=C_decode_literal(C_heaptop,"\376B\000\000\012) C_noret;");
lf[557]=C_decode_literal(C_heaptop,"\376B\000\000\024static void C_ccall ");
lf[558]=C_decode_literal(C_heaptop,"\376B\000\000%(C_word C_c,C_word C_self,C_word C_k,");
lf[559]=C_decode_literal(C_heaptop,"\376B\000\000\014) C_regparm;");
lf[560]=C_decode_literal(C_heaptop,"\376B\000\000 C_regparm static C_word C_fcall ");
lf[561]=C_decode_literal(C_heaptop,"\376B\000\000\015C_noret_decl(");
lf[562]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[563]=C_decode_literal(C_heaptop,"\376B\000\000\024static void C_ccall ");
lf[564]=C_decode_literal(C_heaptop,"\376B\000\000%(C_word C_c,C_word C_self,C_word C_k,");
lf[565]=C_decode_literal(C_heaptop,"\376B\000\000\026static C_word C_fcall ");
lf[566]=C_decode_literal(C_heaptop,"\376B\000\000\042#define return(x) C_cblock C_r = (");
lf[567]=C_decode_literal(C_heaptop,"\376B\000\000\036(x))); goto C_ret; C_cblockend");
lf[568]=C_decode_literal(C_heaptop,"\376B\000\000\010/* from ");
lf[569]=C_decode_literal(C_heaptop,"\376B\000\000\003 */");
lf[570]=C_h_intern(&lf[570],21,"foreign-stub-callback");
lf[571]=C_h_intern(&lf[571],16,"foreign-stub-cps");
lf[572]=C_decode_literal(C_heaptop,"\376B\000\000\003C_a");
lf[573]=C_h_intern(&lf[573],27,"foreign-stub-argument-names");
lf[574]=C_h_intern(&lf[574],17,"foreign-stub-body");
lf[575]=C_h_intern(&lf[575],17,"foreign-stub-name");
lf[576]=C_h_intern(&lf[576],24,"foreign-stub-return-type");
lf[577]=C_decode_literal(C_heaptop,"\376B\000\000\014C_word C_buf");
lf[578]=C_decode_literal(C_heaptop,"\376B\000\000\003C_a");
lf[579]=C_h_intern(&lf[579],27,"foreign-stub-argument-types");
lf[580]=C_h_intern(&lf[580],19,"\010compilerreal-name2");
lf[581]=C_h_intern(&lf[581],15,"foreign-stub-id");
lf[582]=C_h_intern(&lf[582],5,"float");
lf[583]=C_decode_literal(C_heaptop,"\376B\000\000\002+3");
lf[584]=C_h_intern(&lf[584],8,"c-string");
lf[585]=C_decode_literal(C_heaptop,"\376B\000\000\004+2+(");
lf[586]=C_decode_literal(C_heaptop,"\376B\000\000!==NULL\0771:C_bytestowords(C_strlen(");
lf[587]=C_decode_literal(C_heaptop,"\376B\000\000\003)))");
lf[588]=C_h_intern(&lf[588],16,"nonnull-c-string");
lf[589]=C_decode_literal(C_heaptop,"\376B\000\000\033+2+C_bytestowords(C_strlen(");
lf[590]=C_decode_literal(C_heaptop,"\376B\000\000\002))");
lf[591]=C_h_intern(&lf[591],3,"ref");
lf[592]=C_decode_literal(C_heaptop,"\376B\000\000\002+3");
lf[593]=C_h_intern(&lf[593],5,"const");
lf[594]=C_h_intern(&lf[594],7,"pointer");
lf[595]=C_h_intern(&lf[595],9,"c-pointer");
lf[596]=C_h_intern(&lf[596],15,"nonnull-pointer");
lf[597]=C_h_intern(&lf[597],17,"nonnull-c-pointer");
lf[598]=C_h_intern(&lf[598],8,"function");
lf[599]=C_h_intern(&lf[599],8,"instance");
lf[600]=C_h_intern(&lf[600],16,"nonnull-instance");
lf[601]=C_h_intern(&lf[601],12,"instance-ref");
lf[602]=C_h_intern(&lf[602],18,"\003syshash-table-ref");
lf[603]=C_h_intern(&lf[603],27,"\010compilerforeign-type-table");
lf[604]=C_h_intern(&lf[604],17,"nonnull-c-string*");
lf[605]=C_h_intern(&lf[605],25,"nonnull-unsigned-c-string");
lf[606]=C_h_intern(&lf[606],26,"nonnull-unsigned-c-string*");
lf[607]=C_h_intern(&lf[607],6,"symbol");
lf[608]=C_h_intern(&lf[608],9,"c-string*");
lf[609]=C_h_intern(&lf[609],17,"unsigned-c-string");
lf[610]=C_h_intern(&lf[610],18,"unsigned-c-string*");
lf[611]=C_h_intern(&lf[611],6,"double");
lf[612]=C_h_intern(&lf[612],16,"unsigned-integer");
lf[613]=C_h_intern(&lf[613],18,"unsigned-integer32");
lf[614]=C_h_intern(&lf[614],4,"long");
lf[615]=C_h_intern(&lf[615],7,"integer");
lf[616]=C_h_intern(&lf[616],9,"integer32");
lf[617]=C_h_intern(&lf[617],13,"unsigned-long");
lf[618]=C_h_intern(&lf[618],6,"number");
lf[619]=C_h_intern(&lf[619],9,"integer64");
lf[620]=C_h_intern(&lf[620],13,"c-string-list");
lf[621]=C_h_intern(&lf[621],14,"c-string-list*");
lf[622]=C_h_intern(&lf[622],3,"int");
lf[623]=C_h_intern(&lf[623],5,"int32");
lf[624]=C_h_intern(&lf[624],5,"short");
lf[625]=C_h_intern(&lf[625],14,"unsigned-short");
lf[626]=C_h_intern(&lf[626],13,"scheme-object");
lf[627]=C_h_intern(&lf[627],13,"unsigned-char");
lf[628]=C_h_intern(&lf[628],12,"unsigned-int");
lf[629]=C_h_intern(&lf[629],14,"unsigned-int32");
lf[630]=C_h_intern(&lf[630],4,"byte");
lf[631]=C_h_intern(&lf[631],13,"unsigned-byte");
lf[632]=C_decode_literal(C_heaptop,"\376B\000\000\002;}");
lf[633]=C_decode_literal(C_heaptop,"\376B\000\000\033C_callback_wrapper((void *)");
lf[634]=C_decode_literal(C_heaptop,"\376B\000\000\007return ");
lf[635]=C_decode_literal(C_heaptop,"\376B\000\000\002x=");
lf[636]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[637]=C_decode_literal(C_heaptop,"\376B\000\000\012C_save(x);");
lf[638]=C_decode_literal(C_heaptop,"\376B\000\000\001a");
lf[639]=C_decode_literal(C_heaptop,"\376B\000\000\035C_callback_adjust_stack(a,s);");
lf[640]=C_decode_literal(C_heaptop,"\376B\000\000\013C_word x,s=");
lf[641]=C_decode_literal(C_heaptop,"\376B\000\000\017,*a=C_alloc(s);");
lf[642]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[643]=C_decode_literal(C_heaptop,"\376B\000\000\010/* from ");
lf[644]=C_decode_literal(C_heaptop,"\376B\000\000\003 */");
lf[645]=C_decode_literal(C_heaptop,"\376B\000\000\0010");
lf[646]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[647]=C_h_intern(&lf[647],36,"foreign-callback-stub-argument-types");
lf[648]=C_h_intern(&lf[648],33,"foreign-callback-stub-return-type");
lf[649]=C_h_intern(&lf[649],24,"foreign-callback-stub-id");
lf[650]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[651]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[652]=C_h_intern(&lf[652],32,"foreign-callback-stub-qualifiers");
lf[653]=C_h_intern(&lf[653],26,"foreign-callback-stub-name");
lf[654]=C_h_intern(&lf[654],4,"quit");
lf[655]=C_decode_literal(C_heaptop,"\376B\000\000\031illegal foreign type `~A\047");
lf[656]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[657]=C_decode_literal(C_heaptop,"\376B\000\000\006C_word");
lf[658]=C_decode_literal(C_heaptop,"\376B\000\000\006C_char");
lf[659]=C_decode_literal(C_heaptop,"\376B\000\000\017unsigned C_char");
lf[660]=C_decode_literal(C_heaptop,"\376B\000\000\014unsigned int");
lf[661]=C_decode_literal(C_heaptop,"\376B\000\000\005C_u32");
lf[662]=C_decode_literal(C_heaptop,"\376B\000\000\003int");
lf[663]=C_decode_literal(C_heaptop,"\376B\000\000\005C_s32");
lf[664]=C_decode_literal(C_heaptop,"\376B\000\000\005C_s64");
lf[665]=C_decode_literal(C_heaptop,"\376B\000\000\005short");
lf[666]=C_decode_literal(C_heaptop,"\376B\000\000\004long");
lf[667]=C_decode_literal(C_heaptop,"\376B\000\000\016unsigned short");
lf[668]=C_decode_literal(C_heaptop,"\376B\000\000\015unsigned long");
lf[669]=C_decode_literal(C_heaptop,"\376B\000\000\005float");
lf[670]=C_decode_literal(C_heaptop,"\376B\000\000\006double");
lf[671]=C_decode_literal(C_heaptop,"\376B\000\000\006void *");
lf[672]=C_decode_literal(C_heaptop,"\376B\000\000\006void *");
lf[673]=C_decode_literal(C_heaptop,"\376B\000\000\011C_char **");
lf[674]=C_h_intern(&lf[674],11,"byte-vector");
lf[675]=C_h_intern(&lf[675],19,"nonnull-byte-vector");
lf[676]=C_decode_literal(C_heaptop,"\376B\000\000\017unsigned char *");
lf[677]=C_h_intern(&lf[677],4,"blob");
lf[678]=C_decode_literal(C_heaptop,"\376B\000\000\017unsigned char *");
lf[679]=C_h_intern(&lf[679],9,"u16vector");
lf[680]=C_h_intern(&lf[680],17,"nonnull-u16vector");
lf[681]=C_decode_literal(C_heaptop,"\376B\000\000\020unsigned short *");
lf[682]=C_h_intern(&lf[682],8,"s8vector");
lf[683]=C_h_intern(&lf[683],16,"nonnull-s8vector");
lf[684]=C_decode_literal(C_heaptop,"\376B\000\000\006char *");
lf[685]=C_h_intern(&lf[685],9,"u32vector");
lf[686]=C_h_intern(&lf[686],17,"nonnull-u32vector");
lf[687]=C_decode_literal(C_heaptop,"\376B\000\000\016unsigned int *");
lf[688]=C_h_intern(&lf[688],9,"s16vector");
lf[689]=C_h_intern(&lf[689],17,"nonnull-s16vector");
lf[690]=C_decode_literal(C_heaptop,"\376B\000\000\007short *");
lf[691]=C_h_intern(&lf[691],9,"s32vector");
lf[692]=C_h_intern(&lf[692],17,"nonnull-s32vector");
lf[693]=C_decode_literal(C_heaptop,"\376B\000\000\005int *");
lf[694]=C_h_intern(&lf[694],9,"f32vector");
lf[695]=C_h_intern(&lf[695],17,"nonnull-f32vector");
lf[696]=C_decode_literal(C_heaptop,"\376B\000\000\007float *");
lf[697]=C_h_intern(&lf[697],9,"f64vector");
lf[698]=C_h_intern(&lf[698],17,"nonnull-f64vector");
lf[699]=C_decode_literal(C_heaptop,"\376B\000\000\010double *");
lf[700]=C_decode_literal(C_heaptop,"\376B\000\000\006char *");
lf[701]=C_decode_literal(C_heaptop,"\376B\000\000\017unsigned char *");
lf[702]=C_decode_literal(C_heaptop,"\376B\000\000\004void");
lf[703]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[704]=C_decode_literal(C_heaptop,"\376B\000\000\001&");
lf[705]=C_decode_literal(C_heaptop,"\376B\000\000\001<");
lf[706]=C_decode_literal(C_heaptop,"\376B\000\000\002> ");
lf[707]=C_decode_literal(C_heaptop,"\376B\000\000\001,");
lf[708]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[709]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[710]=C_decode_literal(C_heaptop,"\376B\000\000\006const ");
lf[711]=C_decode_literal(C_heaptop,"\376B\000\000\007struct ");
lf[712]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[713]=C_decode_literal(C_heaptop,"\376B\000\000\006union ");
lf[714]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[715]=C_decode_literal(C_heaptop,"\376B\000\000\005enum ");
lf[716]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[717]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[718]=C_decode_literal(C_heaptop,"\376B\000\000\001&");
lf[719]=C_decode_literal(C_heaptop,"\376B\000\000\003 (*");
lf[720]=C_decode_literal(C_heaptop,"\376B\000\000\002)(");
lf[721]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[722]=C_decode_literal(C_heaptop,"\376B\000\000\001,");
lf[723]=C_h_intern(&lf[723],3,"...");
lf[724]=C_decode_literal(C_heaptop,"\376B\000\000\003...");
lf[725]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[726]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[727]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[728]=C_h_intern(&lf[728],9,"\003syserror");
lf[729]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[730]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010instance\376\003\000\000\002\376\001\000\000\020nonnull-instance\376\377\016");
lf[731]=C_h_intern(&lf[731],4,"enum");
lf[732]=C_h_intern(&lf[732],5,"union");
lf[733]=C_h_intern(&lf[733],6,"struct");
lf[734]=C_h_intern(&lf[734],8,"template");
lf[735]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\007pointer\376\003\000\000\002\376\001\000\000\017nonnull-pointer\376\003\000\000\002\376\001\000\000\011c-pointer\376\003\000\000\002\376\001\000\000\021nonnull-c"
"-pointer\376\377\016");
lf[736]=C_h_intern(&lf[736],12,"nonnull-blob");
lf[737]=C_h_intern(&lf[737],8,"u8vector");
lf[738]=C_h_intern(&lf[738],16,"nonnull-u8vector");
lf[739]=C_h_intern(&lf[739],14,"scheme-pointer");
lf[740]=C_h_intern(&lf[740],22,"nonnull-scheme-pointer");
lf[741]=C_decode_literal(C_heaptop,"\376B\000\000\042illegal foreign argument type `~A\047");
lf[742]=C_decode_literal(C_heaptop,"\376B\000\000\001(");
lf[743]=C_decode_literal(C_heaptop,"\376B\000\000\031C_character_code((C_word)");
lf[744]=C_decode_literal(C_heaptop,"\376B\000\000\010C_unfix(");
lf[745]=C_decode_literal(C_heaptop,"\376B\000\000\010C_unfix(");
lf[746]=C_decode_literal(C_heaptop,"\376B\000\000\030(unsigned short)C_unfix(");
lf[747]=C_decode_literal(C_heaptop,"\376B\000\000\027C_num_to_unsigned_long(");
lf[748]=C_decode_literal(C_heaptop,"\376B\000\000\013C_c_double(");
lf[749]=C_decode_literal(C_heaptop,"\376B\000\000\015C_num_to_int(");
lf[750]=C_decode_literal(C_heaptop,"\376B\000\000\017C_num_to_int64(");
lf[751]=C_decode_literal(C_heaptop,"\376B\000\000\016C_num_to_long(");
lf[752]=C_decode_literal(C_heaptop,"\376B\000\000\026C_num_to_unsigned_int(");
lf[753]=C_decode_literal(C_heaptop,"\376B\000\000\027C_data_pointer_or_null(");
lf[754]=C_decode_literal(C_heaptop,"\376B\000\000\017C_data_pointer(");
lf[755]=C_decode_literal(C_heaptop,"\376B\000\000\027C_data_pointer_or_null(");
lf[756]=C_decode_literal(C_heaptop,"\376B\000\000\017C_data_pointer(");
lf[757]=C_decode_literal(C_heaptop,"\376B\000\000\024C_c_pointer_or_null(");
lf[758]=C_decode_literal(C_heaptop,"\376B\000\000\017C_c_pointer_nn(");
lf[759]=C_decode_literal(C_heaptop,"\376B\000\000\027C_c_bytevector_or_null(");
lf[760]=C_decode_literal(C_heaptop,"\376B\000\000\017C_c_bytevector(");
lf[761]=C_decode_literal(C_heaptop,"\376B\000\000\027C_c_bytevector_or_null(");
lf[762]=C_decode_literal(C_heaptop,"\376B\000\000\017C_c_bytevector(");
lf[763]=C_decode_literal(C_heaptop,"\376B\000\000\025C_c_u8vector_or_null(");
lf[764]=C_decode_literal(C_heaptop,"\376B\000\000\015C_c_u8vector(");
lf[765]=C_decode_literal(C_heaptop,"\376B\000\000\026C_c_u16vector_or_null(");
lf[766]=C_decode_literal(C_heaptop,"\376B\000\000\016C_c_u16vector(");
lf[767]=C_decode_literal(C_heaptop,"\376B\000\000\026C_c_u32vector_or_null(");
lf[768]=C_decode_literal(C_heaptop,"\376B\000\000\016C_c_u32vector(");
lf[769]=C_decode_literal(C_heaptop,"\376B\000\000\025C_c_s8vector_or_null(");
lf[770]=C_decode_literal(C_heaptop,"\376B\000\000\015C_c_s8vector(");
lf[771]=C_decode_literal(C_heaptop,"\376B\000\000\026C_c_s16vector_or_null(");
lf[772]=C_decode_literal(C_heaptop,"\376B\000\000\016C_c_s16vector(");
lf[773]=C_decode_literal(C_heaptop,"\376B\000\000\026C_c_s32vector_or_null(");
lf[774]=C_decode_literal(C_heaptop,"\376B\000\000\016C_c_s32vector(");
lf[775]=C_decode_literal(C_heaptop,"\376B\000\000\026C_c_f32vector_or_null(");
lf[776]=C_decode_literal(C_heaptop,"\376B\000\000\016C_c_f32vector(");
lf[777]=C_decode_literal(C_heaptop,"\376B\000\000\026C_c_f64vector_or_null(");
lf[778]=C_decode_literal(C_heaptop,"\376B\000\000\016C_c_f64vector(");
lf[779]=C_decode_literal(C_heaptop,"\376B\000\000\021C_string_or_null(");
lf[780]=C_decode_literal(C_heaptop,"\376B\000\000\013C_c_string(");
lf[781]=C_decode_literal(C_heaptop,"\376B\000\000\010C_truep(");
lf[782]=C_decode_literal(C_heaptop,"\376B\000\000\024C_c_pointer_or_null(");
lf[783]=C_decode_literal(C_heaptop,"\376B\000\000\017C_c_pointer_nn(");
lf[784]=C_decode_literal(C_heaptop,"\376B\000\000\024C_c_pointer_or_null(");
lf[785]=C_decode_literal(C_heaptop,"\376B\000\000\017C_c_pointer_nn(");
lf[786]=C_decode_literal(C_heaptop,"\376B\000\000\024C_c_pointer_or_null(");
lf[787]=C_decode_literal(C_heaptop,"\376B\000\000\017C_c_pointer_nn(");
lf[788]=C_decode_literal(C_heaptop,"\376B\000\000\024C_c_pointer_or_null(");
lf[789]=C_decode_literal(C_heaptop,"\376B\000\000\015C_num_to_int(");
lf[790]=C_decode_literal(C_heaptop,"\376B\000\000\002*(");
lf[791]=C_decode_literal(C_heaptop,"\376B\000\000\020)C_c_pointer_nn(");
lf[792]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[793]=C_decode_literal(C_heaptop,"\376B\000\000\002*(");
lf[794]=C_decode_literal(C_heaptop,"\376B\000\000\021*)C_c_pointer_nn(");
lf[795]=C_decode_literal(C_heaptop,"\376B\000\000 illegal foreign return type `~A\047");
lf[796]=C_decode_literal(C_heaptop,"\376B\000\000\031C_make_character((C_word)");
lf[797]=C_decode_literal(C_heaptop,"\376B\000\000\016C_fix((C_word)");
lf[798]=C_decode_literal(C_heaptop,"\376B\000\000%C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)");
lf[799]=C_decode_literal(C_heaptop,"\376B\000\000\015C_fix((short)");
lf[800]=C_decode_literal(C_heaptop,"\376B\000\000\025C_fix(0xffff&(C_word)");
lf[801]=C_decode_literal(C_heaptop,"\376B\000\000\014C_fix((char)");
lf[802]=C_decode_literal(C_heaptop,"\376B\000\000\023C_fix(0xff&(C_word)");
lf[803]=C_decode_literal(C_heaptop,"\376B\000\000\015C_flonum(&~a,");
lf[804]=C_decode_literal(C_heaptop,"\376B\000\000\015C_number(&~a,");
lf[805]=C_decode_literal(C_heaptop,"\376B\000\000\026C_mpointer(&~a,(void*)");
lf[806]=C_decode_literal(C_heaptop,"\376B\000\000\037C_mpointer_or_false(&~a,(void*)");
lf[807]=C_decode_literal(C_heaptop,"\376B\000\000\021C_int_to_num(&~a,");
lf[808]=C_decode_literal(C_heaptop,"\376B\000\000\026C_a_double_to_num(&~a,");
lf[809]=C_decode_literal(C_heaptop,"\376B\000\000\032C_unsigned_int_to_num(&~a,");
lf[810]=C_decode_literal(C_heaptop,"\376B\000\000\022C_long_to_num(&~a,");
lf[811]=C_decode_literal(C_heaptop,"\376B\000\000\033C_unsigned_long_to_num(&~a,");
lf[812]=C_decode_literal(C_heaptop,"\376B\000\000\012C_mk_bool(");
lf[813]=C_decode_literal(C_heaptop,"\376B\000\000\011((C_word)");
lf[814]=C_decode_literal(C_heaptop,"\376B\000\000\026C_mpointer(&~A,(void*)");
lf[815]=C_decode_literal(C_heaptop,"\376B\000\000\027C_mpointer(&~A,(void*)&");
lf[816]=C_decode_literal(C_heaptop,"\376B\000\000\037C_mpointer_or_false(&~A,(void*)");
lf[817]=C_decode_literal(C_heaptop,"\376B\000\000\026C_mpointer(&~A,(void*)");
lf[818]=C_decode_literal(C_heaptop,"\376B\000\000\027C_mpointer(&~A,(void*)&");
lf[819]=C_decode_literal(C_heaptop,"\376B\000\000\037C_mpointer_or_false(&~a,(void*)");
lf[820]=C_decode_literal(C_heaptop,"\376B\000\000\026C_mpointer(&~a,(void*)");
lf[821]=C_decode_literal(C_heaptop,"\376B\000\000\021C_int_to_num(&~a,");
lf[822]=C_decode_literal(C_heaptop,"\376B\000\000\003\377\006\001");
lf[823]=C_decode_literal(C_heaptop,"\376B\000\000\003\377\006\000");
lf[824]=C_decode_literal(C_heaptop,"\376B\000\000\002\377\012");
lf[825]=C_decode_literal(C_heaptop,"\376B\000\000\002\377\016");
lf[826]=C_decode_literal(C_heaptop,"\376B\000\000\002\377>");
lf[827]=C_decode_literal(C_heaptop,"\376B\000\000\002\377\036");
lf[828]=C_decode_literal(C_heaptop,"\376B\000\000\002\377U");
lf[829]=C_decode_literal(C_heaptop,"\376B\000\000\001\000");
lf[830]=C_decode_literal(C_heaptop,"\376B\000\000\002\377\001");
lf[831]=C_decode_literal(C_heaptop,"\376B\000\000\001U");
lf[832]=C_decode_literal(C_heaptop,"\376B\000\000\001\000");
lf[833]=C_decode_literal(C_heaptop,"\376B\000\000\001\001");
lf[834]=C_decode_literal(C_heaptop,"\376B\000\000\037invalid literal - cannot encode");
lf[835]=C_h_intern(&lf[835],17,"\003sysstring-append");
lf[836]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[837]=C_h_intern(&lf[837],5,"cons*");
lf[838]=C_decode_literal(C_heaptop,"\376B\000\000\010C_~X_~A_");
lf[839]=C_h_intern(&lf[839],6,"random");
C_register_lf2(lf,840,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2435,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k2433 */
static void C_ccall f_2435(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2435,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2438,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k2436 in k2433 */
static void C_ccall f_2438(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2438,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2441,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k2439 in k2436 in k2433 */
static void C_ccall f_2441(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2441,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2444,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_2444(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2444,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2447,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_2447(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2447,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2450,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_2450(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2450,2,t0,t1);}
t2=C_set_block_item(lf[0] /* output */,0,C_SCHEME_FALSE);
t3=C_mutate((C_word*)lf[1]+1 /* (set! gen ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2453,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate((C_word*)lf[5]+1 /* (set! gen-list ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2474,tmp=(C_word)a,a+=2,tmp));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2492,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9163,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9167,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 57   random */
((C_proc3)C_retrieve_symbol_proc(lf[839]))(3,*((C_word*)lf[839]+1),t7,C_fix(16777216));}

/* k9165 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_9167(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9167,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9171,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 57   current-seconds */
((C_proc2)C_retrieve_symbol_proc(lf[225]))(2,*((C_word*)lf[225]+1),t2);}

/* k9169 in k9165 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_9171(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 57   sprintf */
((C_proc5)C_retrieve_symbol_proc(lf[353]))(5,*((C_word*)lf[353]+1),((C_word*)t0)[3],lf[838],((C_word*)t0)[2],t1);}

/* k9161 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_9163(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 56   string->c-identifier */
((C_proc3)C_retrieve_symbol_proc(lf[523]))(3,*((C_word*)lf[523]+1),((C_word*)t0)[2],t1);}

/* k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_2492(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2492,2,t0,t1);}
t2=C_mutate((C_word*)lf[7]+1 /* (set! unique-id ...) */,t1);
t3=C_mutate((C_word*)lf[8]+1 /* (set! generate-code ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2494,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate((C_word*)lf[499]+1 /* (set! emit-procedure-table-info ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6158,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[489]+1 /* (set! cleanup ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6235,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[279]+1 /* (set! make-variable-list ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6324,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate((C_word*)lf[289]+1 /* (set! make-argument-list ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6340,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate((C_word*)lf[503]+1 /* (set! generate-external-variables ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6356,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate((C_word*)lf[199]+1 /* (set! generate-foreign-callback-stub-prototypes ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6388,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate((C_word*)lf[501]+1 /* (set! generate-foreign-stubs ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6406,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate((C_word*)lf[500]+1 /* (set! generate-foreign-callback-stubs ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6639,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate((C_word*)lf[532]+1 /* (set! generate-foreign-callback-header ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7070,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate((C_word*)lf[173]+1 /* (set! foreign-type-declaration ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7135,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate((C_word*)lf[172]+1 /* (set! foreign-argument-conversion ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7980,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate((C_word*)lf[167]+1 /* (set! foreign-result-conversion ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8465,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate((C_word*)lf[349]+1 /* (set! encode-literal ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8863,tmp=(C_word)a,a+=2,tmp));
t17=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t17+1)))(2,t17,C_SCHEME_UNDEFINED);}

/* ##compiler#encode-literal in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_8863(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word ab[22],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8863,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8872,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8925,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_eqp(C_SCHEME_TRUE,t2);
if(C_truep(t5)){
t6=t4;
f_8925(2,t6,lf[822]);}
else{
t6=(C_word)C_eqp(C_SCHEME_FALSE,t2);
if(C_truep(t6)){
t7=t4;
f_8925(2,t7,lf[823]);}
else{
if(C_truep((C_word)C_charp(t2))){
t7=(C_word)C_fix((C_word)C_character_code(t2));
t8=f_8872(C_a_i(&a,4),t7);
/* c-backend.scm: 1366 string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[113]+1)))(4,*((C_word*)lf[113]+1),t4,lf[824],t8);}
else{
if(C_truep((C_word)C_i_nullp(t2))){
t7=t4;
f_8925(2,t7,lf[825]);}
else{
if(C_truep((C_word)C_eofp(t2))){
t7=t4;
f_8925(2,t7,lf[826]);}
else{
t7=C_retrieve(lf[338]);
t8=(C_word)C_eqp(t7,t2);
if(C_truep(t8)){
t9=t4;
f_8925(2,t9,lf[827]);}
else{
if(C_truep((C_word)C_fixnump(t2))){
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9043,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 1371 big-fixnum? */
((C_proc3)C_retrieve_symbol_proc(lf[352]))(3,*((C_word*)lf[352]+1),t9,t2);}
else{
if(C_truep((C_word)C_i_numberp(t2))){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9056,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 1380 number->string */
C_number_to_string(3,0,t9,t2);}
else{
if(C_truep((C_word)C_i_symbolp(t2))){
t9=(C_word)C_slot(t2,C_fix(1));
t10=(C_word)C_i_string_length(t9);
t11=f_8872(C_a_i(&a,4),t10);
/* c-backend.scm: 1383 string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[113]+1)))(5,*((C_word*)lf[113]+1),t4,lf[833],t11,t9);}
else{
if(C_truep((C_word)C_immp(t2))){
/* c-backend.scm: 1388 bomb */
((C_proc4)C_retrieve_symbol_proc(lf[9]))(4,*((C_word*)lf[9]+1),t4,lf[834],t2);}
else{
if(C_truep((C_word)C_byteblockp(t2))){
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9095,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t10=t2;
t11=(C_word)stub2374(C_SCHEME_UNDEFINED,t10);
t12=(C_word)C_make_character((C_word)C_unfix(t11));
t13=(C_word)C_a_i_string(&a,1,t12);
t14=t2;
t15=(C_word)stub2379(C_SCHEME_UNDEFINED,t14);
t16=f_8872(C_a_i(&a,4),t15);
/* c-backend.scm: 1391 string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[113]+1)))(4,*((C_word*)lf[113]+1),t9,t13,t16);}
else{
t9=t2;
t10=(C_word)stub2379(C_SCHEME_UNDEFINED,t9);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9125,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t12=t2;
t13=(C_word)stub2374(C_SCHEME_UNDEFINED,t12);
t14=(C_word)C_make_character((C_word)C_unfix(t13));
t15=(C_word)C_a_i_string(&a,1,t14);
t16=f_8872(C_a_i(&a,4),t10);
t17=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9137,a[2]=t16,a[3]=t15,a[4]=t11,tmp=(C_word)a,a+=5,tmp);
t18=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9139,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 1401 list-tabulate */
((C_proc4)C_retrieve_symbol_proc(lf[529]))(4,*((C_word*)lf[529]+1),t17,t10,t18);}}}}}}}}}}}}

/* a9138 in ##compiler#encode-literal in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_9139(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9139,3,t0,t1,t2);}
t3=(C_word)C_slot(((C_word*)t0)[2],t2);
/* c-backend.scm: 1401 encode-literal */
((C_proc3)C_retrieve_symbol_proc(lf[349]))(3,*((C_word*)lf[349]+1),t1,t3);}

/* k9135 in ##compiler#encode-literal in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_9137(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1398 cons* */
((C_proc5)C_retrieve_symbol_proc(lf[837]))(5,*((C_word*)lf[837]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k9123 in ##compiler#encode-literal in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_9125(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1397 string-intersperse */
((C_proc4)C_retrieve_symbol_proc(lf[216]))(4,*((C_word*)lf[216]+1),((C_word*)t0)[2],t1,lf[836]);}

/* k9093 in ##compiler#encode-literal in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_9095(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1390 ##sys#string-append */
((C_proc4)C_retrieve_symbol_proc(lf[835]))(4,*((C_word*)lf[835]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k9054 in ##compiler#encode-literal in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_9056(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1380 string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[113]+1)))(5,*((C_word*)lf[113]+1),((C_word*)t0)[2],lf[831],t1,lf[832]);}

/* k9041 in ##compiler#encode-literal in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_9043(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9043,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9039,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 1378 number->string */
C_number_to_string(3,0,t2,((C_word*)t0)[2]);}
else{
t2=(C_word)C_fixnum_shift_right(((C_word*)t0)[2],C_fix(24));
t3=(C_word)C_fixnum_and(C_fix(255),t2);
t4=(C_word)C_make_character((C_word)C_unfix(t3));
t5=(C_word)C_fixnum_shift_right(((C_word*)t0)[2],C_fix(16));
t6=(C_word)C_fixnum_and(C_fix(255),t5);
t7=(C_word)C_make_character((C_word)C_unfix(t6));
t8=(C_word)C_fixnum_shift_right(((C_word*)t0)[2],C_fix(8));
t9=(C_word)C_fixnum_and(C_fix(255),t8);
t10=(C_word)C_make_character((C_word)C_unfix(t9));
t11=(C_word)C_fixnum_and(C_fix(255),((C_word*)t0)[2]);
t12=(C_word)C_make_character((C_word)C_unfix(t11));
t13=(C_word)C_a_i_string(&a,4,t4,t7,t10,t12);
/* c-backend.scm: 1372 string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[113]+1)))(4,*((C_word*)lf[113]+1),((C_word*)t0)[3],lf[830],t13);}}

/* k9037 in k9041 in ##compiler#encode-literal in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_9039(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1378 string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[113]+1)))(5,*((C_word*)lf[113]+1),((C_word*)t0)[2],lf[828],t1,lf[829]);}

/* k8923 in ##compiler#encode-literal in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_8925(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8925,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=(C_word)C_a_i_string(&a,1,C_make_character(254));
/* c-backend.scm: 1362 string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[113]+1)))(4,*((C_word*)lf[113]+1),t2,t3,t1);}

/* encode-size in ##compiler#encode-literal in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static C_word C_fcall f_8872(C_word *a,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_stack_check;
t2=(C_word)C_fixnum_shift_right(t1,C_fix(16));
t3=(C_word)C_fixnum_and(C_fix(255),t2);
t4=(C_word)C_make_character((C_word)C_unfix(t3));
t5=(C_word)C_fixnum_shift_right(t1,C_fix(8));
t6=(C_word)C_fixnum_and(C_fix(255),t5);
t7=(C_word)C_make_character((C_word)C_unfix(t6));
t8=(C_word)C_fixnum_and(C_fix(255),t1);
t9=(C_word)C_make_character((C_word)C_unfix(t8));
return((C_word)C_a_i_string(&a,3,t4,t7,t9));}

/* ##compiler#foreign-result-conversion in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_8465(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word ab[10],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8465,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8467,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=t2;
t6=(C_word)C_eqp(t5,lf[20]);
t7=(C_truep(t6)?t6:(C_word)C_eqp(t5,lf[627]));
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,lf[796]);}
else{
t8=(C_word)C_eqp(t5,lf[622]);
t9=(C_truep(t8)?t8:(C_word)C_eqp(t5,lf[623]));
if(C_truep(t9)){
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,lf[797]);}
else{
t10=(C_word)C_eqp(t5,lf[628]);
t11=(C_truep(t10)?t10:(C_word)C_eqp(t5,lf[629]));
if(C_truep(t11)){
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,lf[798]);}
else{
t12=(C_word)C_eqp(t5,lf[624]);
if(C_truep(t12)){
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,lf[799]);}
else{
t13=(C_word)C_eqp(t5,lf[625]);
if(C_truep(t13)){
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,lf[800]);}
else{
t14=(C_word)C_eqp(t5,lf[630]);
if(C_truep(t14)){
t15=t1;
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,lf[801]);}
else{
t15=(C_word)C_eqp(t5,lf[631]);
if(C_truep(t15)){
t16=t1;
((C_proc2)(void*)(*((C_word*)t16+1)))(2,t16,lf[802]);}
else{
t16=(C_word)C_eqp(t5,lf[582]);
t17=(C_truep(t16)?t16:(C_word)C_eqp(t5,lf[611]));
if(C_truep(t17)){
/* c-backend.scm: 1300 sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[353]))(4,*((C_word*)lf[353]+1),t1,lf[803],t3);}
else{
t18=(C_word)C_eqp(t5,lf[618]);
if(C_truep(t18)){
/* c-backend.scm: 1301 sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[353]))(4,*((C_word*)lf[353]+1),t1,lf[804],t3);}
else{
t19=(C_word)C_eqp(t5,lf[588]);
t20=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8552,a[2]=t4,a[3]=t2,a[4]=t5,a[5]=t3,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t19)){
t21=t20;
f_8552(t21,t19);}
else{
t21=(C_word)C_eqp(t5,lf[584]);
if(C_truep(t21)){
t22=t20;
f_8552(t22,t21);}
else{
t22=(C_word)C_eqp(t5,lf[597]);
if(C_truep(t22)){
t23=t20;
f_8552(t23,t22);}
else{
t23=(C_word)C_eqp(t5,lf[608]);
if(C_truep(t23)){
t24=t20;
f_8552(t24,t23);}
else{
t24=(C_word)C_eqp(t5,lf[604]);
if(C_truep(t24)){
t25=t20;
f_8552(t25,t24);}
else{
t25=(C_word)C_eqp(t5,lf[609]);
if(C_truep(t25)){
t26=t20;
f_8552(t26,t25);}
else{
t26=(C_word)C_eqp(t5,lf[610]);
if(C_truep(t26)){
t27=t20;
f_8552(t27,t26);}
else{
t27=(C_word)C_eqp(t5,lf[605]);
if(C_truep(t27)){
t28=t20;
f_8552(t28,t27);}
else{
t28=(C_word)C_eqp(t5,lf[606]);
if(C_truep(t28)){
t29=t20;
f_8552(t29,t28);}
else{
t29=(C_word)C_eqp(t5,lf[607]);
if(C_truep(t29)){
t30=t20;
f_8552(t30,t29);}
else{
t30=(C_word)C_eqp(t5,lf[620]);
t31=t20;
f_8552(t31,(C_truep(t30)?t30:(C_word)C_eqp(t5,lf[621])));}}}}}}}}}}}}}}}}}}}}

/* k8550 in ##compiler#foreign-result-conversion in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_fcall f_8552(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8552,NULL,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm: 1305 sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[353]))(4,*((C_word*)lf[353]+1),((C_word*)t0)[6],lf[805],((C_word*)t0)[5]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[595]);
if(C_truep(t2)){
/* c-backend.scm: 1306 sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[353]))(4,*((C_word*)lf[353]+1),((C_word*)t0)[6],lf[806],((C_word*)t0)[5]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[4],lf[615]);
t4=(C_truep(t3)?t3:(C_word)C_eqp(((C_word*)t0)[4],lf[616]));
if(C_truep(t4)){
/* c-backend.scm: 1307 sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[353]))(4,*((C_word*)lf[353]+1),((C_word*)t0)[6],lf[807],((C_word*)t0)[5]);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[619]);
if(C_truep(t5)){
/* c-backend.scm: 1308 sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[353]))(4,*((C_word*)lf[353]+1),((C_word*)t0)[6],lf[808],((C_word*)t0)[5]);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[4],lf[612]);
t7=(C_truep(t6)?t6:(C_word)C_eqp(((C_word*)t0)[4],lf[613]));
if(C_truep(t7)){
/* c-backend.scm: 1309 sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[353]))(4,*((C_word*)lf[353]+1),((C_word*)t0)[6],lf[809],((C_word*)t0)[5]);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[4],lf[614]);
if(C_truep(t8)){
/* c-backend.scm: 1310 sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[353]))(4,*((C_word*)lf[353]+1),((C_word*)t0)[6],lf[810],((C_word*)t0)[5]);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[4],lf[617]);
if(C_truep(t9)){
/* c-backend.scm: 1311 sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[353]))(4,*((C_word*)lf[353]+1),((C_word*)t0)[6],lf[811],((C_word*)t0)[5]);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[4],lf[17]);
if(C_truep(t10)){
t11=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,lf[812]);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[4],lf[545]);
t12=(C_truep(t11)?t11:(C_word)C_eqp(((C_word*)t0)[4],lf[626]));
if(C_truep(t12)){
t13=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,lf[813]);}
else{
t13=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8633,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[3]))){
/* c-backend.scm: 1315 ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[602]))(4,*((C_word*)lf[602]+1),t13,C_retrieve(lf[603]),((C_word*)t0)[3]);}
else{
t14=t13;
f_8633(2,t14,C_SCHEME_FALSE);}}}}}}}}}}}

/* k8631 in k8550 in ##compiler#foreign-result-conversion in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_8633(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8633,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_vectorp(t1);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(t1,C_fix(0)):t1);
/* c-backend.scm: 1317 foreign-result-conversion */
((C_proc4)C_retrieve_symbol_proc(lf[167]))(4,*((C_word*)lf[167]+1),((C_word*)t0)[5],t3,((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8655,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_listp(((C_word*)t0)[3]))){
t3=(C_word)C_i_length(((C_word*)t0)[3]);
t4=t2;
f_8655(t4,(C_word)C_fixnum_greater_or_equal_p(t3,C_fix(2)));}
else{
t3=t2;
f_8655(t3,C_SCHEME_FALSE);}}}

/* k8653 in k8631 in k8550 in ##compiler#foreign-result-conversion in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_fcall f_8655(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_eqp(t2,lf[596]);
t4=(C_truep(t3)?t3:(C_word)C_eqp(t2,lf[597]));
if(C_truep(t4)){
/* c-backend.scm: 1321 sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[353]))(4,*((C_word*)lf[353]+1),((C_word*)t0)[4],lf[814],((C_word*)t0)[3]);}
else{
t5=(C_word)C_eqp(t2,lf[591]);
if(C_truep(t5)){
/* c-backend.scm: 1323 sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[353]))(4,*((C_word*)lf[353]+1),((C_word*)t0)[4],lf[815],((C_word*)t0)[3]);}
else{
t6=(C_word)C_eqp(t2,lf[599]);
if(C_truep(t6)){
/* c-backend.scm: 1325 sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[353]))(4,*((C_word*)lf[353]+1),((C_word*)t0)[4],lf[816],((C_word*)t0)[3]);}
else{
t7=(C_word)C_eqp(t2,lf[600]);
if(C_truep(t7)){
/* c-backend.scm: 1327 sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[353]))(4,*((C_word*)lf[353]+1),((C_word*)t0)[4],lf[817],((C_word*)t0)[3]);}
else{
t8=(C_word)C_eqp(t2,lf[601]);
if(C_truep(t8)){
/* c-backend.scm: 1329 sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[353]))(4,*((C_word*)lf[353]+1),((C_word*)t0)[4],lf[818],((C_word*)t0)[3]);}
else{
t9=(C_word)C_eqp(t2,lf[593]);
if(C_truep(t9)){
t10=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* c-backend.scm: 1330 foreign-result-conversion */
((C_proc4)C_retrieve_symbol_proc(lf[167]))(4,*((C_word*)lf[167]+1),((C_word*)t0)[4],t10,((C_word*)t0)[3]);}
else{
t10=(C_word)C_eqp(t2,lf[594]);
t11=(C_truep(t10)?t10:(C_word)C_eqp(t2,lf[595]));
if(C_truep(t11)){
/* c-backend.scm: 1332 sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[353]))(4,*((C_word*)lf[353]+1),((C_word*)t0)[4],lf[819],((C_word*)t0)[3]);}
else{
t12=(C_word)C_eqp(t2,lf[598]);
if(C_truep(t12)){
/* c-backend.scm: 1333 sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[353]))(4,*((C_word*)lf[353]+1),((C_word*)t0)[4],lf[820],((C_word*)t0)[3]);}
else{
t13=(C_word)C_eqp(t2,lf[731]);
if(C_truep(t13)){
/* c-backend.scm: 1334 sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[353]))(4,*((C_word*)lf[353]+1),((C_word*)t0)[4],lf[821],((C_word*)t0)[3]);}
else{
/* c-backend.scm: 1335 err */
t14=((C_word*)t0)[2];
f_8467(t14,((C_word*)t0)[4]);}}}}}}}}}}
else{
/* c-backend.scm: 1336 err */
t2=((C_word*)t0)[2];
f_8467(t2,((C_word*)t0)[4]);}}

/* err in ##compiler#foreign-result-conversion in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_fcall f_8467(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8467,NULL,2,t0,t1);}
/* c-backend.scm: 1291 quit */
((C_proc4)C_retrieve_symbol_proc(lf[654]))(4,*((C_word*)lf[654]+1),t1,lf[795],((C_word*)t0)[2]);}

/* ##compiler#foreign-argument-conversion in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_7980(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7980,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7982,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=t2;
t5=(C_word)C_eqp(t4,lf[626]);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,lf[742]);}
else{
t6=(C_word)C_eqp(t4,lf[20]);
t7=(C_truep(t6)?t6:(C_word)C_eqp(t4,lf[627]));
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,lf[743]);}
else{
t8=(C_word)C_eqp(t4,lf[630]);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8010,a[2]=t3,a[3]=t2,a[4]=t4,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t8)){
t10=t9;
f_8010(t10,t8);}
else{
t10=(C_word)C_eqp(t4,lf[622]);
if(C_truep(t10)){
t11=t9;
f_8010(t11,t10);}
else{
t11=(C_word)C_eqp(t4,lf[628]);
if(C_truep(t11)){
t12=t9;
f_8010(t12,t11);}
else{
t12=(C_word)C_eqp(t4,lf[629]);
t13=t9;
f_8010(t13,(C_truep(t12)?t12:(C_word)C_eqp(t4,lf[631])));}}}}}}

/* k8008 in ##compiler#foreign-argument-conversion in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_fcall f_8010(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8010,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[744]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[624]);
if(C_truep(t2)){
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[745]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[4],lf[625]);
if(C_truep(t3)){
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[746]);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[617]);
if(C_truep(t4)){
t5=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,lf[747]);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[611]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8037,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t5)){
t7=t6;
f_8037(t7,t5);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[4],lf[618]);
t8=t6;
f_8037(t8,(C_truep(t7)?t7:(C_word)C_eqp(((C_word*)t0)[4],lf[582])));}}}}}}

/* k8035 in k8008 in ##compiler#foreign-argument-conversion in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_fcall f_8037(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8037,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[748]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[615]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(((C_word*)t0)[4],lf[616]));
if(C_truep(t3)){
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[749]);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[619]);
if(C_truep(t4)){
t5=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,lf[750]);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[614]);
if(C_truep(t5)){
t6=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,lf[751]);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[4],lf[612]);
t7=(C_truep(t6)?t6:(C_word)C_eqp(((C_word*)t0)[4],lf[613]));
if(C_truep(t7)){
t8=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,lf[752]);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[4],lf[594]);
if(C_truep(t8)){
t9=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,lf[753]);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[4],lf[596]);
if(C_truep(t9)){
t10=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,lf[754]);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[4],lf[739]);
if(C_truep(t10)){
t11=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,lf[755]);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[4],lf[740]);
if(C_truep(t11)){
t12=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,lf[756]);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[4],lf[595]);
if(C_truep(t12)){
t13=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,lf[757]);}
else{
t13=(C_word)C_eqp(((C_word*)t0)[4],lf[597]);
if(C_truep(t13)){
t14=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,lf[758]);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[4],lf[677]);
if(C_truep(t14)){
t15=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,lf[759]);}
else{
t15=(C_word)C_eqp(((C_word*)t0)[4],lf[736]);
if(C_truep(t15)){
t16=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t16+1)))(2,t16,lf[760]);}
else{
t16=(C_word)C_eqp(((C_word*)t0)[4],lf[674]);
if(C_truep(t16)){
t17=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t17+1)))(2,t17,lf[761]);}
else{
t17=(C_word)C_eqp(((C_word*)t0)[4],lf[675]);
if(C_truep(t17)){
t18=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t18+1)))(2,t18,lf[762]);}
else{
t18=(C_word)C_eqp(((C_word*)t0)[4],lf[737]);
if(C_truep(t18)){
t19=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t19+1)))(2,t19,lf[763]);}
else{
t19=(C_word)C_eqp(((C_word*)t0)[4],lf[738]);
if(C_truep(t19)){
t20=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t20+1)))(2,t20,lf[764]);}
else{
t20=(C_word)C_eqp(((C_word*)t0)[4],lf[679]);
if(C_truep(t20)){
t21=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t21+1)))(2,t21,lf[765]);}
else{
t21=(C_word)C_eqp(((C_word*)t0)[4],lf[680]);
if(C_truep(t21)){
t22=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t22+1)))(2,t22,lf[766]);}
else{
t22=(C_word)C_eqp(((C_word*)t0)[4],lf[685]);
if(C_truep(t22)){
t23=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t23+1)))(2,t23,lf[767]);}
else{
t23=(C_word)C_eqp(((C_word*)t0)[4],lf[686]);
if(C_truep(t23)){
t24=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t24+1)))(2,t24,lf[768]);}
else{
t24=(C_word)C_eqp(((C_word*)t0)[4],lf[682]);
if(C_truep(t24)){
t25=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t25+1)))(2,t25,lf[769]);}
else{
t25=(C_word)C_eqp(((C_word*)t0)[4],lf[683]);
if(C_truep(t25)){
t26=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t26+1)))(2,t26,lf[770]);}
else{
t26=(C_word)C_eqp(((C_word*)t0)[4],lf[688]);
if(C_truep(t26)){
t27=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t27+1)))(2,t27,lf[771]);}
else{
t27=(C_word)C_eqp(((C_word*)t0)[4],lf[689]);
if(C_truep(t27)){
t28=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t28+1)))(2,t28,lf[772]);}
else{
t28=(C_word)C_eqp(((C_word*)t0)[4],lf[691]);
if(C_truep(t28)){
t29=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t29+1)))(2,t29,lf[773]);}
else{
t29=(C_word)C_eqp(((C_word*)t0)[4],lf[692]);
if(C_truep(t29)){
t30=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t30+1)))(2,t30,lf[774]);}
else{
t30=(C_word)C_eqp(((C_word*)t0)[4],lf[694]);
if(C_truep(t30)){
t31=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t31+1)))(2,t31,lf[775]);}
else{
t31=(C_word)C_eqp(((C_word*)t0)[4],lf[695]);
if(C_truep(t31)){
t32=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t32+1)))(2,t32,lf[776]);}
else{
t32=(C_word)C_eqp(((C_word*)t0)[4],lf[697]);
if(C_truep(t32)){
t33=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t33+1)))(2,t33,lf[777]);}
else{
t33=(C_word)C_eqp(((C_word*)t0)[4],lf[698]);
if(C_truep(t33)){
t34=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t34+1)))(2,t34,lf[778]);}
else{
t34=(C_word)C_eqp(((C_word*)t0)[4],lf[584]);
t35=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8232,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t34)){
t36=t35;
f_8232(t36,t34);}
else{
t36=(C_word)C_eqp(((C_word*)t0)[4],lf[608]);
if(C_truep(t36)){
t37=t35;
f_8232(t37,t36);}
else{
t37=(C_word)C_eqp(((C_word*)t0)[4],lf[609]);
t38=t35;
f_8232(t38,(C_truep(t37)?t37:(C_word)C_eqp(((C_word*)t0)[4],lf[610])));}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}

/* k8230 in k8035 in k8008 in ##compiler#foreign-argument-conversion in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_fcall f_8232(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8232,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[779]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[588]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8241,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t4=t3;
f_8241(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[604]);
if(C_truep(t4)){
t5=t3;
f_8241(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[605]);
if(C_truep(t5)){
t6=t3;
f_8241(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[4],lf[606]);
t7=t3;
f_8241(t7,(C_truep(t6)?t6:(C_word)C_eqp(((C_word*)t0)[4],lf[607])));}}}}}

/* k8239 in k8230 in k8035 in k8008 in ##compiler#foreign-argument-conversion in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_fcall f_8241(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8241,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[780]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[17]);
if(C_truep(t2)){
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[781]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8250,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[3]))){
/* c-backend.scm: 1264 ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[602]))(4,*((C_word*)lf[602]+1),t3,C_retrieve(lf[603]),((C_word*)t0)[3]);}
else{
t4=t3;
f_8250(2,t4,C_SCHEME_FALSE);}}}}

/* k8248 in k8239 in k8230 in k8035 in k8008 in ##compiler#foreign-argument-conversion in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_8250(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8250,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_vectorp(t1);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(t1,C_fix(0)):t1);
/* c-backend.scm: 1266 foreign-argument-conversion */
((C_proc3)C_retrieve_symbol_proc(lf[172]))(3,*((C_word*)lf[172]+1),((C_word*)t0)[4],t3);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8272,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_listp(((C_word*)t0)[3]))){
t3=(C_word)C_i_length(((C_word*)t0)[3]);
t4=t2;
f_8272(t4,(C_word)C_fixnum_greater_or_equal_p(t3,C_fix(2)));}
else{
t3=t2;
f_8272(t3,C_SCHEME_FALSE);}}}

/* k8270 in k8248 in k8239 in k8230 in k8035 in k8008 in ##compiler#foreign-argument-conversion in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_fcall f_8272(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8272,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(C_word)C_eqp(t2,lf[594]);
if(C_truep(t3)){
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[782]);}
else{
t4=(C_word)C_eqp(t2,lf[596]);
if(C_truep(t4)){
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,lf[783]);}
else{
t5=(C_word)C_eqp(t2,lf[595]);
if(C_truep(t5)){
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,lf[784]);}
else{
t6=(C_word)C_eqp(t2,lf[597]);
if(C_truep(t6)){
t7=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,lf[785]);}
else{
t7=(C_word)C_eqp(t2,lf[599]);
if(C_truep(t7)){
t8=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,lf[786]);}
else{
t8=(C_word)C_eqp(t2,lf[600]);
if(C_truep(t8)){
t9=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,lf[787]);}
else{
t9=(C_word)C_eqp(t2,lf[598]);
if(C_truep(t9)){
t10=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,lf[788]);}
else{
t10=(C_word)C_eqp(t2,lf[593]);
if(C_truep(t10)){
t11=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 1277 foreign-argument-conversion */
((C_proc3)C_retrieve_symbol_proc(lf[172]))(3,*((C_word*)lf[172]+1),((C_word*)t0)[3],t11);}
else{
t11=(C_word)C_eqp(t2,lf[731]);
if(C_truep(t11)){
t12=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,lf[789]);}
else{
t12=(C_word)C_eqp(t2,lf[591]);
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8349,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t14=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 1280 foreign-type-declaration */
((C_proc4)C_retrieve_symbol_proc(lf[173]))(4,*((C_word*)lf[173]+1),t13,t14,lf[792]);}
else{
t13=(C_word)C_eqp(t2,lf[601]);
if(C_truep(t13)){
t14=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 1283 string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[113]+1)))(5,*((C_word*)lf[113]+1),((C_word*)t0)[3],lf[793],t14,lf[794]);}
else{
/* c-backend.scm: 1284 err */
t14=((C_word*)t0)[2];
f_7982(t14,((C_word*)t0)[3]);}}}}}}}}}}}}
else{
/* c-backend.scm: 1285 err */
t2=((C_word*)t0)[2];
f_7982(t2,((C_word*)t0)[3]);}}

/* k8347 in k8270 in k8248 in k8239 in k8230 in k8035 in k8008 in ##compiler#foreign-argument-conversion in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_8349(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1280 string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[113]+1)))(5,*((C_word*)lf[113]+1),((C_word*)t0)[2],lf[790],t1,lf[791]);}

/* err in ##compiler#foreign-argument-conversion in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_fcall f_7982(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7982,NULL,2,t0,t1);}
/* c-backend.scm: 1218 quit */
((C_proc4)C_retrieve_symbol_proc(lf[654]))(4,*((C_word*)lf[654]+1),t1,lf[741],((C_word*)t0)[2]);}

/* ##compiler#foreign-type-declaration in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_7135(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[14],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7135,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7137,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7142,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t6=t2;
t7=(C_word)C_eqp(t6,lf[626]);
if(C_truep(t7)){
/* c-backend.scm: 1125 str */
t8=t5;
f_7142(t8,t1,lf[657]);}
else{
t8=(C_word)C_eqp(t6,lf[20]);
t9=(C_truep(t8)?t8:(C_word)C_eqp(t6,lf[630]));
if(C_truep(t9)){
/* c-backend.scm: 1126 str */
t10=t5;
f_7142(t10,t1,lf[658]);}
else{
t10=(C_word)C_eqp(t6,lf[627]);
t11=(C_truep(t10)?t10:(C_word)C_eqp(t6,lf[631]));
if(C_truep(t11)){
/* c-backend.scm: 1127 str */
t12=t5;
f_7142(t12,t1,lf[659]);}
else{
t12=(C_word)C_eqp(t6,lf[628]);
t13=(C_truep(t12)?t12:(C_word)C_eqp(t6,lf[612]));
if(C_truep(t13)){
/* c-backend.scm: 1128 str */
t14=t5;
f_7142(t14,t1,lf[660]);}
else{
t14=(C_word)C_eqp(t6,lf[629]);
t15=(C_truep(t14)?t14:(C_word)C_eqp(t6,lf[613]));
if(C_truep(t15)){
/* c-backend.scm: 1129 str */
t16=t5;
f_7142(t16,t1,lf[661]);}
else{
t16=(C_word)C_eqp(t6,lf[622]);
t17=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7212,a[2]=t4,a[3]=t2,a[4]=t3,a[5]=t6,a[6]=t1,a[7]=t5,tmp=(C_word)a,a+=8,tmp);
if(C_truep(t16)){
t18=t17;
f_7212(t18,t16);}
else{
t18=(C_word)C_eqp(t6,lf[615]);
t19=t17;
f_7212(t19,(C_truep(t18)?t18:(C_word)C_eqp(t6,lf[17])));}}}}}}}

/* k7210 in ##compiler#foreign-type-declaration in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_fcall f_7212(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7212,NULL,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm: 1130 str */
t2=((C_word*)t0)[7];
f_7142(t2,((C_word*)t0)[6],lf[662]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[623]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(((C_word*)t0)[5],lf[616]));
if(C_truep(t3)){
/* c-backend.scm: 1131 str */
t4=((C_word*)t0)[7];
f_7142(t4,((C_word*)t0)[6],lf[663]);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[619]);
if(C_truep(t4)){
/* c-backend.scm: 1132 str */
t5=((C_word*)t0)[7];
f_7142(t5,((C_word*)t0)[6],lf[664]);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],lf[624]);
if(C_truep(t5)){
/* c-backend.scm: 1133 str */
t6=((C_word*)t0)[7];
f_7142(t6,((C_word*)t0)[6],lf[665]);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[5],lf[614]);
if(C_truep(t6)){
/* c-backend.scm: 1134 str */
t7=((C_word*)t0)[7];
f_7142(t7,((C_word*)t0)[6],lf[666]);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[5],lf[625]);
if(C_truep(t7)){
/* c-backend.scm: 1135 str */
t8=((C_word*)t0)[7];
f_7142(t8,((C_word*)t0)[6],lf[667]);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[5],lf[617]);
if(C_truep(t8)){
/* c-backend.scm: 1136 str */
t9=((C_word*)t0)[7];
f_7142(t9,((C_word*)t0)[6],lf[668]);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[5],lf[582]);
if(C_truep(t9)){
/* c-backend.scm: 1137 str */
t10=((C_word*)t0)[7];
f_7142(t10,((C_word*)t0)[6],lf[669]);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[5],lf[611]);
t11=(C_truep(t10)?t10:(C_word)C_eqp(((C_word*)t0)[5],lf[618]));
if(C_truep(t11)){
/* c-backend.scm: 1138 str */
t12=((C_word*)t0)[7];
f_7142(t12,((C_word*)t0)[6],lf[670]);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[5],lf[594]);
t13=(C_truep(t12)?t12:(C_word)C_eqp(((C_word*)t0)[5],lf[596]));
if(C_truep(t13)){
/* c-backend.scm: 1140 str */
t14=((C_word*)t0)[7];
f_7142(t14,((C_word*)t0)[6],lf[671]);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[5],lf[595]);
t15=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7314,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t14)){
t16=t15;
f_7314(t16,t14);}
else{
t16=(C_word)C_eqp(((C_word*)t0)[5],lf[597]);
if(C_truep(t16)){
t17=t15;
f_7314(t17,t16);}
else{
t17=(C_word)C_eqp(((C_word*)t0)[5],lf[739]);
t18=t15;
f_7314(t18,(C_truep(t17)?t17:(C_word)C_eqp(((C_word*)t0)[5],lf[740])));}}}}}}}}}}}}}

/* k7312 in k7210 in ##compiler#foreign-type-declaration in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_fcall f_7314(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7314,NULL,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm: 1141 str */
t2=((C_word*)t0)[7];
f_7142(t2,((C_word*)t0)[6],lf[672]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[620]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(((C_word*)t0)[5],lf[621]));
if(C_truep(t3)){
t4=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[673]);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[674]);
t5=(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[5],lf[675]));
if(C_truep(t5)){
/* c-backend.scm: 1144 str */
t6=((C_word*)t0)[7];
f_7142(t6,((C_word*)t0)[6],lf[676]);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[5],lf[677]);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7347,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t6)){
t8=t7;
f_7347(t8,t6);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[5],lf[736]);
if(C_truep(t8)){
t9=t7;
f_7347(t9,t8);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[5],lf[737]);
t10=t7;
f_7347(t10,(C_truep(t9)?t9:(C_word)C_eqp(((C_word*)t0)[5],lf[738])));}}}}}}

/* k7345 in k7312 in k7210 in ##compiler#foreign-type-declaration in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_fcall f_7347(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7347,NULL,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm: 1145 str */
t2=((C_word*)t0)[7];
f_7142(t2,((C_word*)t0)[6],lf[678]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[679]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(((C_word*)t0)[5],lf[680]));
if(C_truep(t3)){
/* c-backend.scm: 1146 str */
t4=((C_word*)t0)[7];
f_7142(t4,((C_word*)t0)[6],lf[681]);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[682]);
t5=(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[5],lf[683]));
if(C_truep(t5)){
/* c-backend.scm: 1147 str */
t6=((C_word*)t0)[7];
f_7142(t6,((C_word*)t0)[6],lf[684]);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[5],lf[685]);
t7=(C_truep(t6)?t6:(C_word)C_eqp(((C_word*)t0)[5],lf[686]));
if(C_truep(t7)){
/* c-backend.scm: 1148 str */
t8=((C_word*)t0)[7];
f_7142(t8,((C_word*)t0)[6],lf[687]);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[5],lf[688]);
t9=(C_truep(t8)?t8:(C_word)C_eqp(((C_word*)t0)[5],lf[689]));
if(C_truep(t9)){
/* c-backend.scm: 1149 str */
t10=((C_word*)t0)[7];
f_7142(t10,((C_word*)t0)[6],lf[690]);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[5],lf[691]);
t11=(C_truep(t10)?t10:(C_word)C_eqp(((C_word*)t0)[5],lf[692]));
if(C_truep(t11)){
/* c-backend.scm: 1150 str */
t12=((C_word*)t0)[7];
f_7142(t12,((C_word*)t0)[6],lf[693]);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[5],lf[694]);
t13=(C_truep(t12)?t12:(C_word)C_eqp(((C_word*)t0)[5],lf[695]));
if(C_truep(t13)){
/* c-backend.scm: 1151 str */
t14=((C_word*)t0)[7];
f_7142(t14,((C_word*)t0)[6],lf[696]);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[5],lf[697]);
t15=(C_truep(t14)?t14:(C_word)C_eqp(((C_word*)t0)[5],lf[698]));
if(C_truep(t15)){
/* c-backend.scm: 1152 str */
t16=((C_word*)t0)[7];
f_7142(t16,((C_word*)t0)[6],lf[699]);}
else{
t16=(C_word)C_eqp(((C_word*)t0)[5],lf[588]);
t17=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7443,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t16)){
t18=t17;
f_7443(t18,t16);}
else{
t18=(C_word)C_eqp(((C_word*)t0)[5],lf[584]);
if(C_truep(t18)){
t19=t17;
f_7443(t19,t18);}
else{
t19=(C_word)C_eqp(((C_word*)t0)[5],lf[604]);
if(C_truep(t19)){
t20=t17;
f_7443(t20,t19);}
else{
t20=(C_word)C_eqp(((C_word*)t0)[5],lf[608]);
t21=t17;
f_7443(t21,(C_truep(t20)?t20:(C_word)C_eqp(((C_word*)t0)[5],lf[607])));}}}}}}}}}}}}

/* k7441 in k7345 in k7312 in k7210 in ##compiler#foreign-type-declaration in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_fcall f_7443(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7443,NULL,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm: 1154 str */
t2=((C_word*)t0)[7];
f_7142(t2,((C_word*)t0)[6],lf[700]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[605]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7455,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_7455(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[606]);
if(C_truep(t4)){
t5=t3;
f_7455(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],lf[609]);
t6=t3;
f_7455(t6,(C_truep(t5)?t5:(C_word)C_eqp(((C_word*)t0)[5],lf[610])));}}}}

/* k7453 in k7441 in k7345 in k7312 in k7210 in ##compiler#foreign-type-declaration in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_fcall f_7455(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7455,NULL,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm: 1156 str */
t2=((C_word*)t0)[7];
f_7142(t2,((C_word*)t0)[6],lf[701]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[545]);
if(C_truep(t2)){
/* c-backend.scm: 1157 str */
t3=((C_word*)t0)[7];
f_7142(t3,((C_word*)t0)[6],lf[702]);}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7470,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[3]))){
/* c-backend.scm: 1159 ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[602]))(4,*((C_word*)lf[602]+1),t3,C_retrieve(lf[603]),((C_word*)t0)[3]);}
else{
t4=t3;
f_7470(2,t4,C_SCHEME_FALSE);}}}}

/* k7468 in k7453 in k7441 in k7345 in k7312 in k7210 in ##compiler#foreign-type-declaration in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_7470(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7470,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_vectorp(t1);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(t1,C_fix(0)):t1);
/* c-backend.scm: 1161 foreign-type-declaration */
((C_proc4)C_retrieve_symbol_proc(lf[173]))(4,*((C_word*)lf[173]+1),((C_word*)t0)[6],t3,((C_word*)t0)[5]);}
else{
if(C_truep((C_word)C_i_stringp(((C_word*)t0)[4]))){
/* c-backend.scm: 1162 str */
t2=((C_word*)t0)[3];
f_7142(t2,((C_word*)t0)[6],((C_word*)t0)[4]);}
else{
if(C_truep((C_word)C_i_listp(((C_word*)t0)[4]))){
t2=(C_word)C_i_length(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7510,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
t4=(C_word)C_eqp(C_fix(2),t2);
if(C_truep(t4)){
t5=(C_word)C_i_car(((C_word*)t0)[4]);
t6=t3;
f_7510(t6,(C_word)C_i_memq(t5,lf[735]));}
else{
t5=t3;
f_7510(t5,C_SCHEME_FALSE);}}
else{
/* c-backend.scm: 1212 err */
t2=((C_word*)t0)[2];
f_7137(t2,((C_word*)t0)[6]);}}}}

/* k7508 in k7468 in k7453 in k7441 in k7345 in k7312 in k7210 in ##compiler#foreign-type-declaration in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_fcall f_7510(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7510,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7521,a[2]=t2,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 1169 string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[113]+1)))(4,*((C_word*)lf[113]+1),t3,lf[703],((C_word*)t0)[5]);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7527,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_eqp(C_fix(2),((C_word*)t0)[2]);
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[7]);
t5=t2;
f_7527(t5,(C_word)C_eqp(lf[591],t4));}
else{
t4=t2;
f_7527(t4,C_SCHEME_FALSE);}}}

/* k7525 in k7508 in k7468 in k7453 in k7441 in k7345 in k7312 in k7210 in ##compiler#foreign-type-declaration in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_fcall f_7527(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7527,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7538,a[2]=t2,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 1172 string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[113]+1)))(4,*((C_word*)lf[113]+1),t3,lf[704],((C_word*)t0)[5]);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7544,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_fixnum_greaterp(((C_word*)t0)[2],C_fix(2)))){
t3=(C_word)C_i_car(((C_word*)t0)[7]);
t4=t2;
f_7544(t4,(C_word)C_eqp(lf[734],t3));}
else{
t3=t2;
f_7544(t3,C_SCHEME_FALSE);}}}

/* k7542 in k7525 in k7508 in k7468 in k7453 in k7441 in k7345 in k7312 in k7210 in ##compiler#foreign-type-declaration in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_fcall f_7544(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7544,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7551,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7555,a[2]=((C_word*)t0)[5],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* c-backend.scm: 1177 foreign-type-declaration */
((C_proc4)C_retrieve_symbol_proc(lf[173]))(4,*((C_word*)lf[173]+1),t3,t4,lf[709]);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7583,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[2],C_fix(2));
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[5]);
t5=t2;
f_7583(t5,(C_word)C_eqp(lf[593],t4));}
else{
t4=t2;
f_7583(t4,C_SCHEME_FALSE);}}}

/* k7581 in k7542 in k7525 in k7508 in k7468 in k7453 in k7441 in k7345 in k7312 in k7210 in ##compiler#foreign-type-declaration in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_fcall f_7583(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7583,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7590,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* c-backend.scm: 1184 foreign-type-declaration */
((C_proc4)C_retrieve_symbol_proc(lf[173]))(4,*((C_word*)lf[173]+1),t2,t3,((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7600,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[2],C_fix(2));
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[5]);
t5=t2;
f_7600(t5,(C_word)C_eqp(lf[733],t4));}
else{
t4=t2;
f_7600(t4,C_SCHEME_FALSE);}}}

/* k7598 in k7581 in k7542 in k7525 in k7508 in k7468 in k7453 in k7441 in k7345 in k7312 in k7210 in ##compiler#foreign-type-declaration in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_fcall f_7600(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7600,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7607,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 1186 ->string */
((C_proc3)C_retrieve_symbol_proc(lf[15]))(3,*((C_word*)lf[15]+1),t2,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7617,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[2],C_fix(2));
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[4]);
t5=t2;
f_7617(t5,(C_word)C_eqp(lf[732],t4));}
else{
t4=t2;
f_7617(t4,C_SCHEME_FALSE);}}}

/* k7615 in k7598 in k7581 in k7542 in k7525 in k7508 in k7468 in k7453 in k7441 in k7345 in k7312 in k7210 in ##compiler#foreign-type-declaration in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_fcall f_7617(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7617,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7624,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 1188 ->string */
((C_proc3)C_retrieve_symbol_proc(lf[15]))(3,*((C_word*)lf[15]+1),t2,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7634,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[2],C_fix(2));
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[4]);
t5=t2;
f_7634(t5,(C_word)C_eqp(lf[731],t4));}
else{
t4=t2;
f_7634(t4,C_SCHEME_FALSE);}}}

/* k7632 in k7615 in k7598 in k7581 in k7542 in k7525 in k7508 in k7468 in k7453 in k7441 in k7345 in k7312 in k7210 in ##compiler#foreign-type-declaration in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_fcall f_7634(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7634,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7641,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 1190 ->string */
((C_proc3)C_retrieve_symbol_proc(lf[15]))(3,*((C_word*)lf[15]+1),t2,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7651,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[2],C_fix(3));
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[4]);
t5=t2;
f_7651(t5,(C_word)C_i_memq(t4,lf[730]));}
else{
t4=t2;
f_7651(t4,C_SCHEME_FALSE);}}}

/* k7649 in k7632 in k7615 in k7598 in k7581 in k7542 in k7525 in k7508 in k7468 in k7453 in k7441 in k7345 in k7312 in k7210 in ##compiler#foreign-type-declaration in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_fcall f_7651(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7651,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7658,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 1192 ->string */
((C_proc3)C_retrieve_symbol_proc(lf[15]))(3,*((C_word*)lf[15]+1),t2,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7668,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[2],C_fix(3));
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[4]);
t5=t2;
f_7668(t5,(C_word)C_eqp(lf[601],t4));}
else{
t4=t2;
f_7668(t4,C_SCHEME_FALSE);}}}

/* k7666 in k7649 in k7632 in k7615 in k7598 in k7581 in k7542 in k7525 in k7508 in k7468 in k7453 in k7441 in k7345 in k7312 in k7210 in ##compiler#foreign-type-declaration in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_fcall f_7668(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7668,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7675,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 1194 ->string */
((C_proc3)C_retrieve_symbol_proc(lf[15]))(3,*((C_word*)lf[15]+1),t2,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7685,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(((C_word*)t0)[2],C_fix(3)))){
t3=(C_word)C_i_car(((C_word*)t0)[4]);
t4=t2;
f_7685(t4,(C_word)C_eqp(lf[598],t3));}
else{
t3=t2;
f_7685(t3,C_SCHEME_FALSE);}}}

/* k7683 in k7666 in k7649 in k7632 in k7615 in k7598 in k7581 in k7542 in k7525 in k7508 in k7468 in k7453 in k7441 in k7345 in k7312 in k7210 in ##compiler#foreign-type-declaration in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_fcall f_7685(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7685,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(C_word)C_i_caddr(((C_word*)t0)[5]);
t4=(C_word)C_i_cdddr(((C_word*)t0)[5]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7697,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_7697(2,t6,lf[727]);}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_7697(2,t7,(C_word)C_i_car(t4));}
else{
/* ##sys#error */
t7=*((C_word*)lf[728]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[729],t4);}}}
else{
/* c-backend.scm: 1211 err */
t2=((C_word*)t0)[2];
f_7137(t2,((C_word*)t0)[4]);}}

/* k7695 in k7683 in k7666 in k7649 in k7632 in k7615 in k7598 in k7581 in k7542 in k7525 in k7508 in k7468 in k7453 in k7441 in k7345 in k7312 in k7210 in ##compiler#foreign-type-declaration in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_7697(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7697,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7704,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 1200 foreign-type-declaration */
((C_proc4)C_retrieve_symbol_proc(lf[173]))(4,*((C_word*)lf[173]+1),t2,((C_word*)t0)[2],lf[726]);}

/* k7702 in k7695 in k7683 in k7666 in k7649 in k7632 in k7615 in k7598 in k7581 in k7542 in k7525 in k7508 in k7468 in k7453 in k7441 in k7345 in k7312 in k7210 in ##compiler#foreign-type-declaration in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_7704(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7704,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7708,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7712,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7714,tmp=(C_word)a,a+=2,tmp);
/* map */
t5=*((C_word*)lf[220]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a7713 in k7702 in k7695 in k7683 in k7666 in k7649 in k7632 in k7615 in k7598 in k7581 in k7542 in k7525 in k7508 in k7468 in k7453 in k7441 in k7345 in k7312 in k7210 in ##compiler#foreign-type-declaration in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_7714(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7714,3,t0,t1,t2);}
t3=(C_word)C_eqp(lf[723],t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[724]);}
else{
/* c-backend.scm: 1207 foreign-type-declaration */
((C_proc4)C_retrieve_symbol_proc(lf[173]))(4,*((C_word*)lf[173]+1),t1,t2,lf[725]);}}

/* k7710 in k7702 in k7695 in k7683 in k7666 in k7649 in k7632 in k7615 in k7598 in k7581 in k7542 in k7525 in k7508 in k7468 in k7453 in k7441 in k7345 in k7312 in k7210 in ##compiler#foreign-type-declaration in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_7712(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1203 string-intersperse */
((C_proc4)C_retrieve_symbol_proc(lf[216]))(4,*((C_word*)lf[216]+1),((C_word*)t0)[2],t1,lf[722]);}

/* k7706 in k7702 in k7695 in k7683 in k7666 in k7649 in k7632 in k7615 in k7598 in k7581 in k7542 in k7525 in k7508 in k7468 in k7453 in k7441 in k7345 in k7312 in k7210 in ##compiler#foreign-type-declaration in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_7708(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1199 string-append */
((C_proc9)C_retrieve_proc(*((C_word*)lf[113]+1)))(9,*((C_word*)lf[113]+1),((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],lf[719],((C_word*)t0)[2],lf[720],t1,lf[721]);}

/* k7673 in k7666 in k7649 in k7632 in k7615 in k7598 in k7581 in k7542 in k7525 in k7508 in k7468 in k7453 in k7441 in k7345 in k7312 in k7210 in ##compiler#foreign-type-declaration in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_7675(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1194 string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[113]+1)))(5,*((C_word*)lf[113]+1),((C_word*)t0)[3],t1,lf[718],((C_word*)t0)[2]);}

/* k7656 in k7649 in k7632 in k7615 in k7598 in k7581 in k7542 in k7525 in k7508 in k7468 in k7453 in k7441 in k7345 in k7312 in k7210 in ##compiler#foreign-type-declaration in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_7658(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1192 string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[113]+1)))(5,*((C_word*)lf[113]+1),((C_word*)t0)[3],t1,lf[717],((C_word*)t0)[2]);}

/* k7639 in k7632 in k7615 in k7598 in k7581 in k7542 in k7525 in k7508 in k7468 in k7453 in k7441 in k7345 in k7312 in k7210 in ##compiler#foreign-type-declaration in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_7641(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1190 string-append */
((C_proc6)C_retrieve_proc(*((C_word*)lf[113]+1)))(6,*((C_word*)lf[113]+1),((C_word*)t0)[3],lf[715],t1,lf[716],((C_word*)t0)[2]);}

/* k7622 in k7615 in k7598 in k7581 in k7542 in k7525 in k7508 in k7468 in k7453 in k7441 in k7345 in k7312 in k7210 in ##compiler#foreign-type-declaration in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_7624(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1188 string-append */
((C_proc6)C_retrieve_proc(*((C_word*)lf[113]+1)))(6,*((C_word*)lf[113]+1),((C_word*)t0)[3],lf[713],t1,lf[714],((C_word*)t0)[2]);}

/* k7605 in k7598 in k7581 in k7542 in k7525 in k7508 in k7468 in k7453 in k7441 in k7345 in k7312 in k7210 in ##compiler#foreign-type-declaration in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_7607(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1186 string-append */
((C_proc6)C_retrieve_proc(*((C_word*)lf[113]+1)))(6,*((C_word*)lf[113]+1),((C_word*)t0)[3],lf[711],t1,lf[712],((C_word*)t0)[2]);}

/* k7588 in k7581 in k7542 in k7525 in k7508 in k7468 in k7453 in k7441 in k7345 in k7312 in k7210 in ##compiler#foreign-type-declaration in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_7590(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1184 string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[113]+1)))(4,*((C_word*)lf[113]+1),((C_word*)t0)[2],lf[710],t1);}

/* k7553 in k7542 in k7525 in k7508 in k7468 in k7453 in k7441 in k7345 in k7312 in k7210 in ##compiler#foreign-type-declaration in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_7555(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7555,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7559,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7563,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7565,tmp=(C_word)a,a+=2,tmp);
t5=(C_word)C_i_cddr(((C_word*)t0)[2]);
/* map */
t6=*((C_word*)lf[220]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}

/* a7564 in k7553 in k7542 in k7525 in k7508 in k7468 in k7453 in k7441 in k7345 in k7312 in k7210 in ##compiler#foreign-type-declaration in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_7565(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7565,3,t0,t1,t2);}
/* ##compiler#foreign-type-declaration */
((C_proc4)C_retrieve_symbol_proc(lf[173]))(4,*((C_word*)lf[173]+1),t1,t2,lf[708]);}

/* k7561 in k7553 in k7542 in k7525 in k7508 in k7468 in k7453 in k7441 in k7345 in k7312 in k7210 in ##compiler#foreign-type-declaration in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_7563(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1179 string-intersperse */
((C_proc4)C_retrieve_symbol_proc(lf[216]))(4,*((C_word*)lf[216]+1),((C_word*)t0)[2],t1,lf[707]);}

/* k7557 in k7553 in k7542 in k7525 in k7508 in k7468 in k7453 in k7441 in k7345 in k7312 in k7210 in ##compiler#foreign-type-declaration in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_7559(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1176 string-append */
((C_proc6)C_retrieve_proc(*((C_word*)lf[113]+1)))(6,*((C_word*)lf[113]+1),((C_word*)t0)[3],((C_word*)t0)[2],lf[705],t1,lf[706]);}

/* k7549 in k7542 in k7525 in k7508 in k7468 in k7453 in k7441 in k7345 in k7312 in k7210 in ##compiler#foreign-type-declaration in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_7551(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1175 str */
t2=((C_word*)t0)[3];
f_7142(t2,((C_word*)t0)[2],t1);}

/* k7536 in k7525 in k7508 in k7468 in k7453 in k7441 in k7345 in k7312 in k7210 in ##compiler#foreign-type-declaration in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_7538(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1172 foreign-type-declaration */
((C_proc4)C_retrieve_symbol_proc(lf[173]))(4,*((C_word*)lf[173]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7519 in k7508 in k7468 in k7453 in k7441 in k7345 in k7312 in k7210 in ##compiler#foreign-type-declaration in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_7521(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1169 foreign-type-declaration */
((C_proc4)C_retrieve_symbol_proc(lf[173]))(4,*((C_word*)lf[173]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* str in ##compiler#foreign-type-declaration in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_fcall f_7142(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7142,NULL,3,t0,t1,t2);}
/* c-backend.scm: 1123 string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[113]+1)))(5,*((C_word*)lf[113]+1),t1,t2,lf[656],((C_word*)t0)[2]);}

/* err in ##compiler#foreign-type-declaration in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_fcall f_7137(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7137,NULL,2,t0,t1);}
/* c-backend.scm: 1122 quit */
((C_proc4)C_retrieve_symbol_proc(lf[654]))(4,*((C_word*)lf[654]+1),t1,lf[655],((C_word*)t0)[2]);}

/* ##compiler#generate-foreign-callback-header in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_7070(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7070,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7074,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 1104 foreign-callback-stub-name */
((C_proc3)C_retrieve_symbol_proc(lf[653]))(3,*((C_word*)lf[653]+1),t4,t3);}

/* k7072 in ##compiler#generate-foreign-callback-header in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_7074(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7074,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7077,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 1105 foreign-callback-stub-qualifiers */
((C_proc3)C_retrieve_symbol_proc(lf[652]))(3,*((C_word*)lf[652]+1),t2,((C_word*)t0)[2]);}

/* k7075 in k7072 in ##compiler#generate-foreign-callback-header in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_7077(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7077,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7080,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 1106 foreign-callback-stub-return-type */
((C_proc3)C_retrieve_symbol_proc(lf[648]))(3,*((C_word*)lf[648]+1),t2,((C_word*)t0)[2]);}

/* k7078 in k7075 in k7072 in ##compiler#generate-foreign-callback-header in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_7080(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7080,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7083,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 1107 foreign-callback-stub-argument-types */
((C_proc3)C_retrieve_symbol_proc(lf[647]))(3,*((C_word*)lf[647]+1),t2,((C_word*)t0)[2]);}

/* k7081 in k7078 in k7075 in k7072 in ##compiler#generate-foreign-callback-header in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_7083(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7083,2,t0,t1);}
t2=(C_word)C_i_length(t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7089,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 1109 make-argument-list */
((C_proc4)C_retrieve_symbol_proc(lf[289]))(4,*((C_word*)lf[289]+1),t3,t2,lf[651]);}

/* k7087 in k7081 in k7078 in k7075 in k7072 in ##compiler#generate-foreign-callback-header in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_7089(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7089,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7092,a[2]=((C_word*)t0)[6],a[3]=t1,a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7133,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 1110 foreign-type-declaration */
((C_proc4)C_retrieve_symbol_proc(lf[173]))(4,*((C_word*)lf[173]+1),t3,((C_word*)t0)[2],lf[650]);}

/* k7131 in k7087 in k7081 in k7078 in k7075 in k7072 in ##compiler#generate-foreign-callback-header in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_7133(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1110 gen */
((C_proc10)C_retrieve_symbol_proc(lf[1]))(10,*((C_word*)lf[1]+1),((C_word*)t0)[5],C_SCHEME_TRUE,((C_word*)t0)[4],C_make_character(32),t1,((C_word*)t0)[3],C_make_character(32),((C_word*)t0)[2],C_make_character(40));}

/* k7090 in k7087 in k7081 in k7078 in k7075 in k7072 in ##compiler#generate-foreign-callback-header in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_7092(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7092,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7095,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7100,tmp=(C_word)a,a+=2,tmp);
/* c-backend.scm: 1111 pair-for-each */
((C_proc5)C_retrieve_symbol_proc(lf[196]))(5,*((C_word*)lf[196]+1),t2,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a7099 in k7090 in k7087 in k7081 in k7078 in k7075 in k7072 in ##compiler#generate-foreign-callback-header in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_7100(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7100,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7104,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7121,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(C_word)C_i_car(t3);
t7=(C_word)C_i_car(t2);
/* c-backend.scm: 1113 foreign-type-declaration */
((C_proc4)C_retrieve_symbol_proc(lf[173]))(4,*((C_word*)lf[173]+1),t5,t6,t7);}

/* k7119 in a7099 in k7090 in k7087 in k7081 in k7078 in k7075 in k7072 in ##compiler#generate-foreign-callback-header in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_7121(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1113 gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],t1);}

/* k7102 in a7099 in k7090 in k7087 in k7081 in k7078 in k7075 in k7072 in ##compiler#generate-foreign-callback-header in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_7104(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t2))){
/* c-backend.scm: 1114 gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(44));}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k7093 in k7090 in k7087 in k7081 in k7078 in k7075 in k7072 in ##compiler#generate-foreign-callback-header in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_7095(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1116 gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(41));}

/* generate-foreign-callback-stubs in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_6639(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6639,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6645,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* for-each */
t5=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t4,t2);}

/* a6644 in generate-foreign-callback-stubs in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_6645(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6645,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6649,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 1051 foreign-callback-stub-id */
((C_proc3)C_retrieve_symbol_proc(lf[649]))(3,*((C_word*)lf[649]+1),t3,t2);}

/* k6647 in a6644 in generate-foreign-callback-stubs in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_6649(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6649,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6652,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 1052 real-name2 */
((C_proc4)C_retrieve_symbol_proc(lf[580]))(4,*((C_word*)lf[580]+1),t2,t1,((C_word*)t0)[2]);}

/* k6650 in k6647 in a6644 in generate-foreign-callback-stubs in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_6652(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6652,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6655,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 1053 foreign-callback-stub-return-type */
((C_proc3)C_retrieve_symbol_proc(lf[648]))(3,*((C_word*)lf[648]+1),t2,((C_word*)t0)[2]);}

/* k6653 in k6650 in k6647 in a6644 in generate-foreign-callback-stubs in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_6655(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6655,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6658,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 1054 foreign-callback-stub-argument-types */
((C_proc3)C_retrieve_symbol_proc(lf[647]))(3,*((C_word*)lf[647]+1),t2,((C_word*)t0)[3]);}

/* k6656 in k6653 in k6650 in k6647 in a6644 in generate-foreign-callback-stubs in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_6658(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6658,2,t0,t1);}
t2=(C_word)C_i_length(t1);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6664,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t2,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 1056 make-argument-list */
((C_proc4)C_retrieve_symbol_proc(lf[289]))(4,*((C_word*)lf[289]+1),t3,t2,lf[646]);}

/* k6662 in k6656 in k6653 in k6650 in k6647 in a6644 in generate-foreign-callback-stubs in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_6664(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6664,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6666,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7005,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* c-backend.scm: 1083 fold */
((C_proc6)C_retrieve_symbol_proc(lf[434]))(6,*((C_word*)lf[434]+1),t5,((C_word*)t3)[1],lf[645],((C_word*)t0)[4],t1);}

/* k7003 in k6662 in k6656 in k6653 in k6650 in k6647 in a6644 in generate-foreign-callback-stubs in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_7005(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7005,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7008,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm: 1084 gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE);}

/* k7006 in k7003 in k6662 in k6656 in k6653 in k6650 in k6647 in a6644 in generate-foreign-callback-stubs in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_7008(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7008,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7011,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7068,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 1086 cleanup */
((C_proc3)C_retrieve_symbol_proc(lf[489]))(3,*((C_word*)lf[489]+1),t3,((C_word*)t0)[2]);}
else{
t3=t2;
f_7011(2,t3,C_SCHEME_UNDEFINED);}}

/* k7066 in k7006 in k7003 in k6662 in k6656 in k6653 in k6650 in k6647 in a6644 in generate-foreign-callback-stubs in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_7068(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1086 gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_SCHEME_TRUE,lf[643],t1,lf[644]);}

/* k7009 in k7006 in k7003 in k6662 in k6656 in k6653 in k6650 in k6647 in a6644 in generate-foreign-callback-stubs in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_7011(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7011,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7014,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 1087 generate-foreign-callback-header */
((C_proc4)C_retrieve_symbol_proc(lf[532]))(4,*((C_word*)lf[532]+1),t2,lf[642],((C_word*)t0)[2]);}

/* k7012 in k7009 in k7006 in k7003 in k6662 in k6656 in k6653 in k6650 in k6647 in a6644 in generate-foreign-callback-stubs in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_7014(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7014,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7017,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 1088 gen */
((C_proc7)C_retrieve_symbol_proc(lf[1]))(7,*((C_word*)lf[1]+1),t2,C_make_character(123),C_SCHEME_TRUE,lf[640],((C_word*)t0)[2],lf[641]);}

/* k7015 in k7012 in k7009 in k7006 in k7003 in k6662 in k6656 in k6653 in k6650 in k6647 in a6644 in generate-foreign-callback-stubs in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_7017(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7017,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7020,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 1089 gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[639]);}

/* k7018 in k7015 in k7012 in k7009 in k7006 in k7003 in k6662 in k6656 in k6653 in k6650 in k6647 in a6644 in generate-foreign-callback-stubs in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_7020(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7020,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7023,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7053,tmp=(C_word)a,a+=2,tmp);
/* c-backend.scm: 1090 for-each */
((C_proc5)C_retrieve_proc(*((C_word*)lf[63]+1)))(5,*((C_word*)lf[63]+1),t2,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a7052 in k7018 in k7015 in k7012 in k7009 in k7006 in k7003 in k6662 in k6656 in k6653 in k6650 in k6647 in a6644 in generate-foreign-callback-stubs in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_7053(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7053,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7061,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 1092 foreign-result-conversion */
((C_proc4)C_retrieve_symbol_proc(lf[167]))(4,*((C_word*)lf[167]+1),t4,t3,lf[638]);}

/* k7059 in a7052 in k7018 in k7015 in k7012 in k7009 in k7006 in k7003 in k6662 in k6656 in k6653 in k6650 in k6647 in a6644 in generate-foreign-callback-stubs in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_7061(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1092 gen */
((C_proc9)C_retrieve_symbol_proc(lf[1]))(9,*((C_word*)lf[1]+1),((C_word*)t0)[3],C_SCHEME_TRUE,lf[635],t1,((C_word*)t0)[2],lf[636],C_SCHEME_TRUE,lf[637]);}

/* k7021 in k7018 in k7015 in k7012 in k7009 in k7006 in k7003 in k6662 in k6656 in k6653 in k6650 in k6647 in a6644 in generate-foreign-callback-stubs in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_7023(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7023,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7026,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_eqp(lf[545],((C_word*)t0)[4]);
if(C_truep(t3)){
t4=t2;
f_7026(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7051,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 1097 foreign-argument-conversion */
((C_proc3)C_retrieve_symbol_proc(lf[172]))(3,*((C_word*)lf[172]+1),t4,((C_word*)t0)[4]);}}

/* k7049 in k7021 in k7018 in k7015 in k7012 in k7009 in k7006 in k7003 in k6662 in k6656 in k6653 in k6650 in k6647 in a6644 in generate-foreign-callback-stubs in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_7051(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1097 gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_SCHEME_TRUE,lf[634],t1);}

/* k7024 in k7021 in k7018 in k7015 in k7012 in k7009 in k7006 in k7003 in k6662 in k6656 in k6653 in k6650 in k6647 in a6644 in generate-foreign-callback-stubs in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_7026(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7026,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7029,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 1098 gen */
((C_proc7)C_retrieve_symbol_proc(lf[1]))(7,*((C_word*)lf[1]+1),t2,lf[633],((C_word*)t0)[3],C_make_character(44),((C_word*)t0)[2],C_make_character(41));}

/* k7027 in k7024 in k7021 in k7018 in k7015 in k7012 in k7009 in k7006 in k7003 in k6662 in k6656 in k6653 in k6650 in k6647 in a6644 in generate-foreign-callback-stubs in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_7029(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7029,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7032,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_eqp(lf[545],((C_word*)t0)[2]);
if(C_truep(t3)){
t4=t2;
f_7032(2,t4,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 1099 gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,C_make_character(41));}}

/* k7030 in k7027 in k7024 in k7021 in k7018 in k7015 in k7012 in k7009 in k7006 in k7003 in k6662 in k6656 in k6653 in k6650 in k6647 in a6644 in generate-foreign-callback-stubs in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_7032(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1100 gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[632]);}

/* compute-size in k6662 in k6656 in k6653 in k6650 in k6647 in a6644 in generate-foreign-callback-stubs in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_6666(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[8],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6666,5,t0,t1,t2,t3,t4);}
t5=t2;
t6=(C_word)C_eqp(t5,lf[20]);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6676,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t5,a[6]=t4,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
if(C_truep(t6)){
t8=t7;
f_6676(t8,t6);}
else{
t8=(C_word)C_eqp(t5,lf[622]);
if(C_truep(t8)){
t9=t7;
f_6676(t9,t8);}
else{
t9=(C_word)C_eqp(t5,lf[623]);
if(C_truep(t9)){
t10=t7;
f_6676(t10,t9);}
else{
t10=(C_word)C_eqp(t5,lf[624]);
if(C_truep(t10)){
t11=t7;
f_6676(t11,t10);}
else{
t11=(C_word)C_eqp(t5,lf[17]);
if(C_truep(t11)){
t12=t7;
f_6676(t12,t11);}
else{
t12=(C_word)C_eqp(t5,lf[545]);
if(C_truep(t12)){
t13=t7;
f_6676(t13,t12);}
else{
t13=(C_word)C_eqp(t5,lf[625]);
if(C_truep(t13)){
t14=t7;
f_6676(t14,t13);}
else{
t14=(C_word)C_eqp(t5,lf[626]);
if(C_truep(t14)){
t15=t7;
f_6676(t15,t14);}
else{
t15=(C_word)C_eqp(t5,lf[627]);
if(C_truep(t15)){
t16=t7;
f_6676(t16,t15);}
else{
t16=(C_word)C_eqp(t5,lf[628]);
if(C_truep(t16)){
t17=t7;
f_6676(t17,t16);}
else{
t17=(C_word)C_eqp(t5,lf[629]);
if(C_truep(t17)){
t18=t7;
f_6676(t18,t17);}
else{
t18=(C_word)C_eqp(t5,lf[630]);
t19=t7;
f_6676(t19,(C_truep(t18)?t18:(C_word)C_eqp(t5,lf[631])));}}}}}}}}}}}}

/* k6674 in compute-size in k6662 in k6656 in k6653 in k6650 in k6647 in a6644 in generate-foreign-callback-stubs in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_fcall f_6676(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6676,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[6]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[582]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6685,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_6685(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[611]);
if(C_truep(t4)){
t5=t3;
f_6685(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],lf[595]);
if(C_truep(t5)){
t6=t3;
f_6685(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[5],lf[612]);
if(C_truep(t6)){
t7=t3;
f_6685(t7,t6);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[5],lf[613]);
if(C_truep(t7)){
t8=t3;
f_6685(t8,t7);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[5],lf[614]);
if(C_truep(t8)){
t9=t3;
f_6685(t9,t8);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[5],lf[615]);
if(C_truep(t9)){
t10=t3;
f_6685(t10,t9);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[5],lf[616]);
if(C_truep(t10)){
t11=t3;
f_6685(t11,t10);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[5],lf[617]);
if(C_truep(t11)){
t12=t3;
f_6685(t12,t11);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[5],lf[597]);
if(C_truep(t12)){
t13=t3;
f_6685(t13,t12);}
else{
t13=(C_word)C_eqp(((C_word*)t0)[5],lf[618]);
if(C_truep(t13)){
t14=t3;
f_6685(t14,t13);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[5],lf[619]);
if(C_truep(t14)){
t15=t3;
f_6685(t15,t14);}
else{
t15=(C_word)C_eqp(((C_word*)t0)[5],lf[620]);
t16=t3;
f_6685(t16,(C_truep(t15)?t15:(C_word)C_eqp(((C_word*)t0)[5],lf[621])));}}}}}}}}}}}}}}

/* k6683 in k6674 in compute-size in k6662 in k6656 in k6653 in k6650 in k6647 in a6644 in generate-foreign-callback-stubs in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_fcall f_6685(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6685,NULL,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm: 1065 string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[113]+1)))(4,*((C_word*)lf[113]+1),((C_word*)t0)[7],((C_word*)t0)[6],lf[583]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[584]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6697,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_6697(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[608]);
if(C_truep(t4)){
t5=t3;
f_6697(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],lf[609]);
if(C_truep(t5)){
t6=t3;
f_6697(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[5],lf[609]);
t7=t3;
f_6697(t7,(C_truep(t6)?t6:(C_word)C_eqp(((C_word*)t0)[5],lf[610])));}}}}}

/* k6695 in k6683 in k6674 in compute-size in k6662 in k6656 in k6653 in k6650 in k6647 in a6644 in generate-foreign-callback-stubs in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_fcall f_6697(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6697,NULL,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm: 1067 string-append */
((C_proc8)C_retrieve_proc(*((C_word*)lf[113]+1)))(8,*((C_word*)lf[113]+1),((C_word*)t0)[7],((C_word*)t0)[6],lf[585],((C_word*)t0)[5],lf[586],((C_word*)t0)[5],lf[587]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[588]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6709,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t2)){
t4=t3;
f_6709(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[604]);
if(C_truep(t4)){
t5=t3;
f_6709(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[605]);
if(C_truep(t5)){
t6=t3;
f_6709(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[4],lf[606]);
t7=t3;
f_6709(t7,(C_truep(t6)?t6:(C_word)C_eqp(((C_word*)t0)[4],lf[607])));}}}}}

/* k6707 in k6695 in k6683 in k6674 in compute-size in k6662 in k6656 in k6653 in k6650 in k6647 in a6644 in generate-foreign-callback-stubs in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_fcall f_6709(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6709,NULL,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm: 1069 string-append */
((C_proc6)C_retrieve_proc(*((C_word*)lf[113]+1)))(6,*((C_word*)lf[113]+1),((C_word*)t0)[6],((C_word*)t0)[5],lf[589],((C_word*)t0)[4],lf[590]);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6715,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[2]))){
/* c-backend.scm: 1071 ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[602]))(4,*((C_word*)lf[602]+1),t2,C_retrieve(lf[603]),((C_word*)t0)[2]);}
else{
t3=t2;
f_6715(2,t3,C_SCHEME_FALSE);}}}

/* k6713 in k6707 in k6695 in k6683 in k6674 in compute-size in k6662 in k6656 in k6653 in k6650 in k6647 in a6644 in generate-foreign-callback-stubs in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_6715(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6715,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_vectorp(t1);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(t1,C_fix(0)):t1);
/* c-backend.scm: 1073 compute-size */
t4=((C_word*)((C_word*)t0)[6])[1];
f_6666(5,t4,((C_word*)t0)[5],t3,((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t2=(C_word)C_i_car(((C_word*)t0)[2]);
t3=(C_word)C_eqp(t2,lf[591]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6749,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[2],a[5]=t2,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t3)){
t5=t4;
f_6749(t5,t3);}
else{
t5=(C_word)C_eqp(t2,lf[594]);
if(C_truep(t5)){
t6=t4;
f_6749(t6,t5);}
else{
t6=(C_word)C_eqp(t2,lf[595]);
if(C_truep(t6)){
t7=t4;
f_6749(t7,t6);}
else{
t7=(C_word)C_eqp(t2,lf[596]);
if(C_truep(t7)){
t8=t4;
f_6749(t8,t7);}
else{
t8=(C_word)C_eqp(t2,lf[597]);
if(C_truep(t8)){
t9=t4;
f_6749(t9,t8);}
else{
t9=(C_word)C_eqp(t2,lf[598]);
if(C_truep(t9)){
t10=t4;
f_6749(t10,t9);}
else{
t10=(C_word)C_eqp(t2,lf[599]);
if(C_truep(t10)){
t11=t4;
f_6749(t11,t10);}
else{
t11=(C_word)C_eqp(t2,lf[600]);
t12=t4;
f_6749(t12,(C_truep(t11)?t11:(C_word)C_eqp(t2,lf[601])));}}}}}}}}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}}}

/* k6747 in k6713 in k6707 in k6695 in k6683 in k6674 in compute-size in k6662 in k6656 in k6653 in k6650 in k6647 in a6644 in generate-foreign-callback-stubs in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_fcall f_6749(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
/* c-backend.scm: 1078 string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[113]+1)))(4,*((C_word*)lf[113]+1),((C_word*)t0)[7],((C_word*)t0)[6],lf[592]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[593]);
if(C_truep(t2)){
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 1079 compute-size */
t4=((C_word*)((C_word*)t0)[3])[1];
f_6666(5,t4,((C_word*)t0)[7],t3,((C_word*)t0)[2],((C_word*)t0)[6]);}
else{
t3=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[6]);}}}

/* ##compiler#generate-foreign-stubs in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_6406(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6406,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6412,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* for-each */
t5=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t4,t2);}

/* a6411 in ##compiler#generate-foreign-stubs in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_6412(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6412,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6416,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 984  foreign-stub-id */
((C_proc3)C_retrieve_symbol_proc(lf[581]))(3,*((C_word*)lf[581]+1),t3,t2);}

/* k6414 in a6411 in ##compiler#generate-foreign-stubs in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_6416(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6416,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6419,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 985  real-name2 */
((C_proc4)C_retrieve_symbol_proc(lf[580]))(4,*((C_word*)lf[580]+1),t2,t1,((C_word*)t0)[2]);}

/* k6417 in k6414 in a6411 in ##compiler#generate-foreign-stubs in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_6419(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6419,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6422,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 986  foreign-stub-argument-types */
((C_proc3)C_retrieve_symbol_proc(lf[579]))(3,*((C_word*)lf[579]+1),t2,((C_word*)t0)[2]);}

/* k6420 in k6417 in k6414 in a6411 in ##compiler#generate-foreign-stubs in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_6422(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6422,2,t0,t1);}
t2=(C_word)C_i_length(t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6428,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=t2,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6637,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 988  make-variable-list */
((C_proc4)C_retrieve_symbol_proc(lf[279]))(4,*((C_word*)lf[279]+1),t4,t2,lf[578]);}

/* k6635 in k6420 in k6417 in k6414 in a6411 in ##compiler#generate-foreign-stubs in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_6637(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6637,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[577],t1);
/* c-backend.scm: 988  intersperse */
((C_proc4)C_retrieve_symbol_proc(lf[6]))(4,*((C_word*)lf[6]+1),((C_word*)t0)[2],t2,C_make_character(44));}

/* k6426 in k6420 in k6417 in k6414 in a6411 in ##compiler#generate-foreign-stubs in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_6428(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6428,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6431,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 989  foreign-stub-return-type */
((C_proc3)C_retrieve_symbol_proc(lf[576]))(3,*((C_word*)lf[576]+1),t2,((C_word*)t0)[2]);}

/* k6429 in k6426 in k6420 in k6417 in k6414 in a6411 in ##compiler#generate-foreign-stubs in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_6431(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6431,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6434,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* c-backend.scm: 990  foreign-stub-name */
((C_proc3)C_retrieve_symbol_proc(lf[575]))(3,*((C_word*)lf[575]+1),t2,((C_word*)t0)[2]);}

/* k6432 in k6429 in k6426 in k6420 in k6417 in k6414 in a6411 in ##compiler#generate-foreign-stubs in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_6434(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6434,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6437,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm: 991  foreign-stub-body */
((C_proc3)C_retrieve_symbol_proc(lf[574]))(3,*((C_word*)lf[574]+1),t2,((C_word*)t0)[2]);}

/* k6435 in k6432 in k6429 in k6426 in k6420 in k6417 in k6414 in a6411 in ##compiler#generate-foreign-stubs in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_6437(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6437,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6440,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t1,a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* c-backend.scm: 992  foreign-stub-argument-names */
((C_proc3)C_retrieve_symbol_proc(lf[573]))(3,*((C_word*)lf[573]+1),t2,((C_word*)t0)[2]);}

/* k6438 in k6435 in k6432 in k6429 in k6426 in k6420 in k6417 in k6414 in a6411 in ##compiler#generate-foreign-stubs in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_6440(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6440,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6443,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
if(C_truep(t1)){
t3=t2;
f_6443(2,t3,t1);}
else{
/* c-backend.scm: 992  make-list */
((C_proc4)C_retrieve_symbol_proc(lf[240]))(4,*((C_word*)lf[240]+1),t2,((C_word*)t0)[8],C_SCHEME_FALSE);}}

/* k6441 in k6438 in k6435 in k6432 in k6429 in k6426 in k6420 in k6417 in k6414 in a6411 in ##compiler#generate-foreign-stubs in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_6443(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6443,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_6446,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
/* c-backend.scm: 993  foreign-result-conversion */
((C_proc4)C_retrieve_symbol_proc(lf[167]))(4,*((C_word*)lf[167]+1),t2,((C_word*)t0)[9],lf[572]);}

/* k6444 in k6441 in k6438 in k6435 in k6432 in k6429 in k6426 in k6420 in k6417 in k6414 in a6411 in ##compiler#generate-foreign-stubs in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_6446(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6446,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_6449,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
/* c-backend.scm: 994  foreign-stub-cps */
((C_proc3)C_retrieve_symbol_proc(lf[571]))(3,*((C_word*)lf[571]+1),t2,((C_word*)t0)[2]);}

/* k6447 in k6444 in k6441 in k6438 in k6435 in k6432 in k6429 in k6426 in k6420 in k6417 in k6414 in a6411 in ##compiler#generate-foreign-stubs in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_6449(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6449,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_6452,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=t1,a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
/* c-backend.scm: 995  foreign-stub-callback */
((C_proc3)C_retrieve_symbol_proc(lf[570]))(3,*((C_word*)lf[570]+1),t2,((C_word*)t0)[2]);}

/* k6450 in k6447 in k6444 in k6441 in k6438 in k6435 in k6432 in k6429 in k6426 in k6420 in k6417 in k6414 in a6411 in ##compiler#generate-foreign-stubs in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_6452(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6452,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_6455,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=t1,a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],tmp=(C_word)a,a+=15,tmp);
/* c-backend.scm: 996  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE);}

/* k6453 in k6450 in k6447 in k6444 in k6441 in k6438 in k6435 in k6432 in k6429 in k6426 in k6420 in k6417 in k6414 in a6411 in ##compiler#generate-foreign-stubs in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_6455(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6455,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_6458,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],tmp=(C_word)a,a+=14,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6626,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 998  cleanup */
((C_proc3)C_retrieve_symbol_proc(lf[489]))(3,*((C_word*)lf[489]+1),t3,((C_word*)t0)[2]);}
else{
t3=t2;
f_6458(2,t3,C_SCHEME_UNDEFINED);}}

/* k6624 in k6453 in k6450 in k6447 in k6444 in k6441 in k6438 in k6435 in k6432 in k6429 in k6426 in k6420 in k6417 in k6414 in a6411 in ##compiler#generate-foreign-stubs in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_6626(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 998  gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_SCHEME_TRUE,lf[568],t1,lf[569]);}

/* k6456 in k6453 in k6450 in k6447 in k6444 in k6441 in k6438 in k6435 in k6432 in k6429 in k6426 in k6420 in k6417 in k6414 in a6411 in ##compiler#generate-foreign-stubs in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_6458(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6458,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_6461,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
if(C_truep(((C_word*)t0)[12])){
/* c-backend.scm: 1000 gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[566],((C_word*)t0)[6],lf[567]);}
else{
t3=t2;
f_6461(2,t3,C_SCHEME_UNDEFINED);}}

/* k6459 in k6456 in k6453 in k6450 in k6447 in k6444 in k6441 in k6438 in k6435 in k6432 in k6429 in k6426 in k6420 in k6417 in k6414 in a6411 in ##compiler#generate-foreign-stubs in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_6461(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6461,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_6464,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
if(C_truep(((C_word*)t0)[10])){
/* c-backend.scm: 1003 gen */
((C_proc10)C_retrieve_symbol_proc(lf[1]))(10,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[561],((C_word*)t0)[2],lf[562],C_SCHEME_TRUE,lf[563],((C_word*)t0)[2],lf[564]);}
else{
/* c-backend.scm: 1005 gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[565],((C_word*)t0)[2],C_make_character(40));}}

/* k6462 in k6459 in k6456 in k6453 in k6450 in k6447 in k6444 in k6441 in k6438 in k6435 in k6432 in k6429 in k6426 in k6420 in k6417 in k6414 in a6411 in ##compiler#generate-foreign-stubs in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_6464(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6464,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_6467,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
C_apply(4,0,t2,C_retrieve(lf[1]),((C_word*)t0)[3]);}

/* k6465 in k6462 in k6459 in k6456 in k6453 in k6450 in k6447 in k6444 in k6441 in k6438 in k6435 in k6432 in k6429 in k6426 in k6420 in k6417 in k6414 in a6411 in ##compiler#generate-foreign-stubs in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_6467(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6467,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_6470,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],tmp=(C_word)a,a+=13,tmp);
if(C_truep(((C_word*)t0)[10])){
/* c-backend.scm: 1008 gen */
((C_proc7)C_retrieve_symbol_proc(lf[1]))(7,*((C_word*)lf[1]+1),t2,lf[556],C_SCHEME_TRUE,lf[557],((C_word*)t0)[2],lf[558]);}
else{
/* c-backend.scm: 1009 gen */
((C_proc7)C_retrieve_symbol_proc(lf[1]))(7,*((C_word*)lf[1]+1),t2,lf[559],C_SCHEME_TRUE,lf[560],((C_word*)t0)[2],C_make_character(40));}}

/* k6468 in k6465 in k6462 in k6459 in k6456 in k6453 in k6450 in k6447 in k6444 in k6441 in k6438 in k6435 in k6432 in k6429 in k6426 in k6420 in k6417 in k6414 in a6411 in ##compiler#generate-foreign-stubs in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_6470(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6470,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6473,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],tmp=(C_word)a,a+=12,tmp);
C_apply(4,0,t2,C_retrieve(lf[1]),((C_word*)t0)[2]);}

/* k6471 in k6468 in k6465 in k6462 in k6459 in k6456 in k6453 in k6450 in k6447 in k6444 in k6441 in k6438 in k6435 in k6432 in k6429 in k6426 in k6420 in k6417 in k6414 in a6411 in ##compiler#generate-foreign-stubs in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_6473(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6473,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6476,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
/* c-backend.scm: 1011 gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,lf[555]);}

/* k6474 in k6471 in k6468 in k6465 in k6462 in k6459 in k6456 in k6453 in k6450 in k6447 in k6444 in k6441 in k6438 in k6435 in k6432 in k6429 in k6426 in k6420 in k6417 in k6414 in a6411 in ##compiler#generate-foreign-stubs in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_6476(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6476,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6479,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
/* c-backend.scm: 1012 gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[554]);}

/* k6477 in k6474 in k6471 in k6468 in k6465 in k6462 in k6459 in k6456 in k6453 in k6450 in k6447 in k6444 in k6441 in k6438 in k6435 in k6432 in k6429 in k6426 in k6420 in k6417 in k6414 in a6411 in ##compiler#generate-foreign-stubs in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_6479(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6479,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6482,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6574,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6604,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 1021 iota */
((C_proc3)C_retrieve_symbol_proc(lf[64]))(3,*((C_word*)lf[64]+1),t4,((C_word*)t0)[6]);}

/* k6602 in k6477 in k6474 in k6471 in k6468 in k6465 in k6462 in k6459 in k6456 in k6453 in k6450 in k6447 in k6444 in k6441 in k6438 in k6435 in k6432 in k6429 in k6426 in k6420 in k6417 in k6414 in a6411 in ##compiler#generate-foreign-stubs in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_6604(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1013 for-each */
((C_proc6)C_retrieve_proc(*((C_word*)lf[63]+1)))(6,*((C_word*)lf[63]+1),((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* a6573 in k6477 in k6474 in k6471 in k6468 in k6465 in k6462 in k6459 in k6456 in k6453 in k6450 in k6447 in k6444 in k6441 in k6438 in k6435 in k6432 in k6429 in k6426 in k6420 in k6417 in k6414 in a6411 in ##compiler#generate-foreign-stubs in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_6574(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6574,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6582,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6594,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t4)){
/* c-backend.scm: 1018 symbol->string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[77]+1)))(3,*((C_word*)lf[77]+1),t6,t4);}
else{
/* c-backend.scm: 1018 sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[353]))(4,*((C_word*)lf[353]+1),t6,lf[553],t3);}}

/* k6592 in a6573 in k6477 in k6474 in k6471 in k6468 in k6465 in k6462 in k6459 in k6456 in k6453 in k6450 in k6447 in k6444 in k6441 in k6438 in k6435 in k6432 in k6429 in k6426 in k6420 in k6417 in k6414 in a6411 in ##compiler#generate-foreign-stubs in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_6594(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1016 foreign-type-declaration */
((C_proc4)C_retrieve_symbol_proc(lf[173]))(4,*((C_word*)lf[173]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k6580 in a6573 in k6477 in k6474 in k6471 in k6468 in k6465 in k6462 in k6459 in k6456 in k6453 in k6450 in k6447 in k6444 in k6441 in k6438 in k6435 in k6432 in k6429 in k6426 in k6420 in k6417 in k6414 in a6411 in ##compiler#generate-foreign-stubs in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_6582(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6582,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6586,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 1019 foreign-type-declaration */
((C_proc4)C_retrieve_symbol_proc(lf[173]))(4,*((C_word*)lf[173]+1),t2,((C_word*)t0)[2],lf[552]);}

/* k6584 in k6580 in a6573 in k6477 in k6474 in k6471 in k6468 in k6465 in k6462 in k6459 in k6456 in k6453 in k6450 in k6447 in k6444 in k6441 in k6438 in k6435 in k6432 in k6429 in k6426 in k6420 in k6417 in k6414 in a6411 in ##compiler#generate-foreign-stubs in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_6586(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6586,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6590,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 1020 foreign-argument-conversion */
((C_proc3)C_retrieve_symbol_proc(lf[172]))(3,*((C_word*)lf[172]+1),t2,((C_word*)t0)[2]);}

/* k6588 in k6584 in k6580 in a6573 in k6477 in k6474 in k6471 in k6468 in k6465 in k6462 in k6459 in k6456 in k6453 in k6450 in k6447 in k6444 in k6441 in k6438 in k6435 in k6432 in k6429 in k6426 in k6420 in k6417 in k6414 in a6411 in ##compiler#generate-foreign-stubs in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_6590(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1015 gen */
((C_proc11)C_retrieve_symbol_proc(lf[1]))(11,*((C_word*)lf[1]+1),((C_word*)t0)[5],C_SCHEME_TRUE,((C_word*)t0)[4],lf[549],((C_word*)t0)[3],C_make_character(41),t1,lf[550],((C_word*)t0)[2],lf[551]);}

/* k6480 in k6477 in k6474 in k6471 in k6468 in k6465 in k6462 in k6459 in k6456 in k6453 in k6450 in k6447 in k6444 in k6441 in k6438 in k6435 in k6432 in k6429 in k6426 in k6420 in k6417 in k6414 in a6411 in ##compiler#generate-foreign-stubs in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_6482(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6482,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6485,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
if(C_truep(((C_word*)t0)[7])){
/* c-backend.scm: 1022 gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[548]);}
else{
t3=t2;
f_6485(2,t3,C_SCHEME_UNDEFINED);}}

/* k6483 in k6480 in k6477 in k6474 in k6471 in k6468 in k6465 in k6462 in k6459 in k6456 in k6453 in k6450 in k6447 in k6444 in k6441 in k6438 in k6435 in k6432 in k6429 in k6426 in k6420 in k6417 in k6414 in a6411 in ##compiler#generate-foreign-stubs in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_6485(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6485,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6488,a[2]=((C_word*)t0)[9],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[8])){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6494,a[2]=((C_word*)t0)[6],a[3]=t2,a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 1024 gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),t3,C_SCHEME_TRUE,((C_word*)t0)[8],C_SCHEME_TRUE,lf[539]);}
else{
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6515,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[545]);
if(C_truep(t4)){
/* c-backend.scm: 1035 gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t3,C_SCHEME_TRUE);}
else{
/* c-backend.scm: 1034 gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t3,C_SCHEME_TRUE,lf[547],((C_word*)t0)[2]);}}}

/* k6513 in k6483 in k6480 in k6477 in k6474 in k6471 in k6468 in k6465 in k6462 in k6459 in k6456 in k6453 in k6450 in k6447 in k6444 in k6441 in k6438 in k6435 in k6432 in k6429 in k6426 in k6420 in k6417 in k6414 in a6411 in ##compiler#generate-foreign-stubs in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_6515(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6515,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6518,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 1036 gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t2,((C_word*)t0)[2],C_make_character(40));}

/* k6516 in k6513 in k6483 in k6480 in k6477 in k6474 in k6471 in k6468 in k6465 in k6462 in k6459 in k6456 in k6453 in k6450 in k6447 in k6444 in k6441 in k6438 in k6435 in k6432 in k6429 in k6426 in k6420 in k6417 in k6414 in a6411 in ##compiler#generate-foreign-stubs in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_6518(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6518,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6521,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6552,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6556,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 1037 make-argument-list */
((C_proc4)C_retrieve_symbol_proc(lf[289]))(4,*((C_word*)lf[289]+1),t4,((C_word*)t0)[2],lf[546]);}

/* k6554 in k6516 in k6513 in k6483 in k6480 in k6477 in k6474 in k6471 in k6468 in k6465 in k6462 in k6459 in k6456 in k6453 in k6450 in k6447 in k6444 in k6441 in k6438 in k6435 in k6432 in k6429 in k6426 in k6420 in k6417 in k6414 in a6411 in ##compiler#generate-foreign-stubs in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_6556(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1037 intersperse */
((C_proc4)C_retrieve_symbol_proc(lf[6]))(4,*((C_word*)lf[6]+1),((C_word*)t0)[2],t1,C_make_character(44));}

/* k6550 in k6516 in k6513 in k6483 in k6480 in k6477 in k6474 in k6471 in k6468 in k6465 in k6462 in k6459 in k6456 in k6453 in k6450 in k6447 in k6444 in k6441 in k6438 in k6435 in k6432 in k6429 in k6426 in k6420 in k6417 in k6414 in a6411 in ##compiler#generate-foreign-stubs in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_6552(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],C_retrieve(lf[1]),t1);}

/* k6519 in k6516 in k6513 in k6483 in k6480 in k6477 in k6474 in k6471 in k6468 in k6465 in k6462 in k6459 in k6456 in k6453 in k6450 in k6447 in k6444 in k6441 in k6438 in k6435 in k6432 in k6429 in k6426 in k6420 in k6417 in k6414 in a6411 in ##compiler#generate-foreign-stubs in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_6521(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6521,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6524,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[2],lf[545]);
if(C_truep(t3)){
t4=t2;
f_6524(2,t4,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 1038 gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,C_make_character(41));}}

/* k6522 in k6519 in k6516 in k6513 in k6483 in k6480 in k6477 in k6474 in k6471 in k6468 in k6465 in k6462 in k6459 in k6456 in k6453 in k6450 in k6447 in k6444 in k6441 in k6438 in k6435 in k6432 in k6429 in k6426 in k6420 in k6417 in k6414 in a6411 in ##compiler#generate-foreign-stubs in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_6524(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6524,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6527,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 1039 gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,lf[544]);}

/* k6525 in k6522 in k6519 in k6516 in k6513 in k6483 in k6480 in k6477 in k6474 in k6471 in k6468 in k6465 in k6462 in k6459 in k6456 in k6453 in k6450 in k6447 in k6444 in k6441 in k6438 in k6435 in k6432 in k6429 in k6426 in k6420 in k6417 in k6414 in a6411 in ##compiler#generate-foreign-stubs in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_6527(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(((C_word*)t0)[4])){
/* c-backend.scm: 1041 gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),((C_word*)t0)[3],C_SCHEME_TRUE,lf[540],C_SCHEME_TRUE,lf[541]);}
else{
if(C_truep(((C_word*)t0)[2])){
/* c-backend.scm: 1043 gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[3],lf[542]);}
else{
/* c-backend.scm: 1044 gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),((C_word*)t0)[3],C_SCHEME_TRUE,lf[543]);}}}

/* k6492 in k6483 in k6480 in k6477 in k6474 in k6471 in k6468 in k6465 in k6462 in k6459 in k6456 in k6453 in k6450 in k6447 in k6444 in k6441 in k6438 in k6435 in k6432 in k6429 in k6426 in k6420 in k6417 in k6414 in a6411 in ##compiler#generate-foreign-stubs in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_6494(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6494,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6497,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 1026 gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[538],C_SCHEME_TRUE);}

/* k6495 in k6492 in k6483 in k6480 in k6477 in k6474 in k6471 in k6468 in k6465 in k6462 in k6459 in k6456 in k6453 in k6450 in k6447 in k6444 in k6441 in k6438 in k6435 in k6432 in k6429 in k6426 in k6420 in k6417 in k6414 in a6411 in ##compiler#generate-foreign-stubs in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_6497(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(((C_word*)t0)[4])){
/* c-backend.scm: 1028 gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),((C_word*)t0)[3],C_SCHEME_TRUE,lf[534],C_SCHEME_TRUE,lf[535]);}
else{
if(C_truep(((C_word*)t0)[2])){
/* c-backend.scm: 1030 gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),((C_word*)t0)[3],C_SCHEME_TRUE,lf[536]);}
else{
/* c-backend.scm: 1031 gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),((C_word*)t0)[3],C_SCHEME_TRUE,lf[537]);}}}

/* k6486 in k6483 in k6480 in k6477 in k6474 in k6471 in k6468 in k6465 in k6462 in k6459 in k6456 in k6453 in k6450 in k6447 in k6444 in k6441 in k6438 in k6435 in k6432 in k6429 in k6426 in k6420 in k6417 in k6414 in a6411 in ##compiler#generate-foreign-stubs in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_6488(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1045 gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(125));}

/* ##compiler#generate-foreign-callback-stub-prototypes in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_6388(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6388,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6394,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t3,t2);}

/* a6393 in ##compiler#generate-foreign-callback-stub-prototypes in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_6394(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6394,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6398,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 976  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t3,C_SCHEME_TRUE);}

/* k6396 in a6393 in ##compiler#generate-foreign-callback-stub-prototypes in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_6398(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6398,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6401,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 977  generate-foreign-callback-header */
((C_proc4)C_retrieve_symbol_proc(lf[532]))(4,*((C_word*)lf[532]+1),t2,lf[533],((C_word*)t0)[2]);}

/* k6399 in k6396 in a6393 in ##compiler#generate-foreign-callback-stub-prototypes in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_6401(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 978  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(59));}

/* ##compiler#generate-external-variables in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_6356(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6356,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6360,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 961  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t3,C_SCHEME_TRUE);}

/* k6358 in ##compiler#generate-external-variables in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_6360(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6360,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6365,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t3=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a6364 in k6358 in ##compiler#generate-external-variables in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_6365(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6365,3,t0,t1,t2);}
t3=(C_word)C_i_vector_ref(t2,C_fix(0));
t4=(C_word)C_i_vector_ref(t2,C_fix(1));
t5=(C_word)C_i_vector_ref(t2,C_fix(2));
t6=(C_truep(t5)?lf[530]:lf[531]);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6386,a[2]=t6,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 967  foreign-type-declaration */
((C_proc4)C_retrieve_symbol_proc(lf[173]))(4,*((C_word*)lf[173]+1),t7,t4,t3);}

/* k6384 in a6364 in k6358 in ##compiler#generate-external-variables in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_6386(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 967  gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),((C_word*)t0)[3],C_SCHEME_TRUE,((C_word*)t0)[2],t1,C_make_character(59));}

/* ##compiler#make-argument-list in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_6340(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6340,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6346,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 953  list-tabulate */
((C_proc4)C_retrieve_symbol_proc(lf[529]))(4,*((C_word*)lf[529]+1),t1,t2,t4);}

/* a6345 in ##compiler#make-argument-list in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_6346(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6346,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6354,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 955  number->string */
C_number_to_string(3,0,t3,t2);}

/* k6352 in a6345 in ##compiler#make-argument-list in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_6354(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 955  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[113]+1)))(4,*((C_word*)lf[113]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* ##compiler#make-variable-list in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_6324(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6324,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6330,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 948  list-tabulate */
((C_proc4)C_retrieve_symbol_proc(lf[529]))(4,*((C_word*)lf[529]+1),t1,t2,t4);}

/* a6329 in ##compiler#make-variable-list in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_6330(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6330,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6338,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 950  number->string */
C_number_to_string(3,0,t3,t2);}

/* k6336 in a6329 in ##compiler#make-variable-list in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_6338(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 950  string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[113]+1)))(5,*((C_word*)lf[113]+1),((C_word*)t0)[3],lf[528],((C_word*)t0)[2],t1);}

/* ##compiler#cleanup in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_6235(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6235,3,t0,t1,t2);}
t3=C_SCHEME_FALSE;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(C_word)C_i_string_length(t2);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6244,a[2]=t7,a[3]=t2,a[4]=t4,a[5]=t5,tmp=(C_word)a,a+=6,tmp));
t9=((C_word*)t7)[1];
f_6244(t9,t1,C_fix(0));}

/* loop in ##compiler#cleanup in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_fcall f_6244(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6244,NULL,3,t0,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[5]))){
t4=((C_word*)((C_word*)t0)[4])[1];
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_truep(t4)?t4:((C_word*)t0)[3]));}
else{
t4=(C_word)C_i_string_ref(((C_word*)t0)[3],t2);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6260,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_fixnum_lessp(t4,C_make_character(32));
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6273,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=t5,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t6)){
t8=t7;
f_6273(t8,t6);}
else{
t8=(C_word)C_fixnum_greaterp(t4,C_make_character(126));
if(C_truep(t8)){
t9=t7;
f_6273(t9,t8);}
else{
t9=(C_word)C_eqp(t4,C_make_character(42));
if(C_truep(t9)){
t10=(C_word)C_fixnum_decrease(((C_word*)t0)[5]);
t11=t2;
if(C_truep((C_word)C_fixnum_lessp(t11,t10))){
t12=(C_word)C_fixnum_increase(t2);
t13=(C_word)C_i_string_ref(((C_word*)t0)[3],t12);
t14=t7;
f_6273(t14,(C_word)C_eqp(C_make_character(47),t13));}
else{
t12=t7;
f_6273(t12,C_SCHEME_FALSE);}}
else{
t10=t7;
f_6273(t10,C_SCHEME_FALSE);}}}}}

/* k6271 in loop in ##compiler#cleanup in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_fcall f_6273(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6273,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6276,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)((C_word*)t0)[5])[1])){
t3=t2;
f_6276(t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6283,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 939  string-copy */
((C_proc3)C_retrieve_symbol_proc(lf[527]))(3,*((C_word*)lf[527]+1),t3,((C_word*)t0)[3]);}}
else{
t2=((C_word*)t0)[6];
f_6260(t2,(C_truep(((C_word*)((C_word*)t0)[5])[1])?(C_word)C_i_string_set(((C_word*)((C_word*)t0)[5])[1],((C_word*)t0)[4],((C_word*)t0)[2]):C_SCHEME_UNDEFINED));}}

/* k6281 in k6271 in loop in ##compiler#cleanup in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_6283(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_6276(t3,t2);}

/* k6274 in k6271 in loop in ##compiler#cleanup in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_fcall f_6276(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[4];
f_6260(t2,(C_word)C_i_string_set(((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2],C_make_character(126)));}

/* k6258 in loop in ##compiler#cleanup in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_fcall f_6260(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_increase(((C_word*)t0)[4]);
/* c-backend.scm: 942  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_6244(t3,((C_word*)t0)[2],t2);}

/* emit-procedure-table-info in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_6158(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6158,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6162,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_length(t2);
t6=(C_word)C_fixnum_increase(t5);
/* c-backend.scm: 904  gen */
((C_proc9)C_retrieve_symbol_proc(lf[1]))(9,*((C_word*)lf[1]+1),t4,C_SCHEME_TRUE,C_SCHEME_TRUE,lf[524],C_SCHEME_TRUE,lf[525],t6,lf[526]);}

/* k6160 in emit-procedure-table-info in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_6162(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6162,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6165,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6176,a[2]=((C_word*)t0)[3],a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_6176(t6,t2,((C_word*)t0)[2]);}

/* doloop1265 in k6160 in emit-procedure-table-info in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_fcall f_6176(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6176,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
/* c-backend.scm: 908  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t1,C_SCHEME_TRUE,lf[516]);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6189,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_i_car(t2);
/* c-backend.scm: 909  lambda-literal-id */
((C_proc3)C_retrieve_symbol_proc(lf[11]))(3,*((C_word*)lf[11]+1),t3,t4);}}

/* k6187 in doloop1265 in k6160 in emit-procedure-table-info in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_6189(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6189,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6192,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6221,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 910  string->c-identifier */
((C_proc3)C_retrieve_symbol_proc(lf[523]))(3,*((C_word*)lf[523]+1),t3,((C_word*)t0)[2]);}

/* k6219 in k6187 in doloop1265 in k6160 in emit-procedure-table-info in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_6221(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 910  gen */
((C_proc8)C_retrieve_symbol_proc(lf[1]))(8,*((C_word*)lf[1]+1),((C_word*)t0)[3],C_SCHEME_TRUE,lf[521],((C_word*)t0)[2],C_make_character(58),t1,lf[522]);}

/* k6190 in k6187 in doloop1265 in k6160 in emit-procedure-table-info in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_6192(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6192,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6195,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_eqp(lf[255],((C_word*)t0)[2]);
if(C_truep(t3)){
if(C_truep(C_retrieve(lf[206]))){
/* c-backend.scm: 913  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t2,lf[517],C_retrieve(lf[206]),lf[518]);}
else{
/* c-backend.scm: 914  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,lf[519]);}}
else{
/* c-backend.scm: 915  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t2,((C_word*)t0)[2],lf[520]);}}

/* k6193 in k6190 in k6187 in doloop1265 in k6160 in emit-procedure-table-info in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_6195(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
t3=((C_word*)((C_word*)t0)[3])[1];
f_6176(t3,((C_word*)t0)[2],t2);}

/* k6163 in k6160 in emit-procedure-table-info in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_6165(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6165,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6168,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 916  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[515]);}

/* k6166 in k6163 in k6160 in emit-procedure-table-info in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_6168(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6168,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6171,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 917  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,C_SCHEME_TRUE,lf[514]);}

/* k6169 in k6166 in k6163 in k6160 in emit-procedure-table-info in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_6171(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 918  gen */
((C_proc15)C_retrieve_symbol_proc(lf[1]))(15,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[507],C_SCHEME_TRUE,lf[508],C_SCHEME_TRUE,lf[509],C_SCHEME_TRUE,lf[510],C_SCHEME_TRUE,lf[511],C_SCHEME_TRUE,lf[512],C_SCHEME_TRUE,lf[513]);}

/* ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_2494(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word ab[63],*a=ab;
if(c!=9) C_bad_argc_2(c,9,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr9,(void*)f_2494,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2497,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t10=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2529,tmp=(C_word)a,a+=2,tmp);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2539,a[2]=t9,a[3]=t10,tmp=(C_word)a,a+=4,tmp);
t12=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4112,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t13=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4259,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4408,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t15=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4659,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t16=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5366,tmp=(C_word)a,a+=2,tmp);
t17=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5289,a[2]=t16,tmp=(C_word)a,a+=3,tmp);
t18=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4982,tmp=(C_word)a,a+=2,tmp);
t19=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5147,a[2]=t18,a[3]=t17,tmp=(C_word)a,a+=4,tmp);
t20=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4945,a[2]=t2,a[3]=t19,tmp=(C_word)a,a+=4,tmp);
t21=C_SCHEME_UNDEFINED;
t22=(*a=C_VECTOR_TYPE|1,a[1]=t21,tmp=(C_word)a,a+=2,tmp);
t23=C_set_block_item(t22,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4988,a[2]=t18,a[3]=t22,tmp=(C_word)a,a+=4,tmp));
t24=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5378,a[2]=t4,a[3]=t8,a[4]=t22,a[5]=t20,a[6]=t2,a[7]=t11,tmp=(C_word)a,a+=8,tmp);
t25=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6125,a[2]=t12,a[3]=t13,a[4]=t14,a[5]=t8,a[6]=t15,a[7]=t24,a[8]=t6,a[9]=t4,a[10]=t1,a[11]=t5,tmp=(C_word)a,a+=12,tmp);
/* c-backend.scm: 887  debugging */
((C_proc4)C_retrieve_symbol_proc(lf[490]))(4,*((C_word*)lf[490]+1),t25,lf[505],lf[506]);}

/* k6123 in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_6125(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6125,2,t0,t1);}
t2=C_mutate((C_word*)lf[0]+1 /* (set! output ...) */,((C_word*)t0)[11]);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6129,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
/* c-backend.scm: 889  header */
t4=((C_word*)t0)[2];
f_4112(t4,t3);}

/* k6127 in k6123 in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_6129(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6129,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6132,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 890  declarations */
t3=((C_word*)t0)[2];
f_4259(t3,t2);}

/* k6130 in k6127 in k6123 in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_6132(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6132,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6135,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 891  generate-external-variables */
((C_proc3)C_retrieve_symbol_proc(lf[503]))(3,*((C_word*)lf[503]+1),t2,C_retrieve(lf[504]));}

/* k6133 in k6130 in k6127 in k6123 in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_6135(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6135,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6138,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 892  generate-foreign-stubs */
((C_proc4)C_retrieve_symbol_proc(lf[501]))(4,*((C_word*)lf[501]+1),t2,C_retrieve(lf[502]),((C_word*)t0)[3]);}

/* k6136 in k6133 in k6130 in k6127 in k6123 in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_6138(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6138,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6141,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 893  prototypes */
t3=((C_word*)t0)[2];
f_4408(t3,t2);}

/* k6139 in k6136 in k6133 in k6130 in k6127 in k6123 in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_6141(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6141,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6144,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 894  generate-foreign-callback-stubs */
((C_proc4)C_retrieve_symbol_proc(lf[500]))(4,*((C_word*)lf[500]+1),t2,C_retrieve(lf[200]),((C_word*)t0)[2]);}

/* k6142 in k6139 in k6136 in k6133 in k6130 in k6127 in k6123 in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_6144(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6144,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6147,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 895  trampolines */
t3=((C_word*)t0)[2];
f_4659(t3,t2);}

/* k6145 in k6142 in k6139 in k6136 in k6133 in k6130 in k6127 in k6123 in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_6147(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6147,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6150,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 896  procedures */
t3=((C_word*)t0)[2];
f_5378(t3,t2);}

/* k6148 in k6145 in k6142 in k6139 in k6136 in k6133 in k6130 in k6127 in k6123 in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_6150(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6150,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6153,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 897  emit-procedure-table-info */
((C_proc4)C_retrieve_symbol_proc(lf[499]))(4,*((C_word*)lf[499]+1),t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k6151 in k6148 in k6145 in k6142 in k6139 in k6136 in k6133 in k6130 in k6127 in k6123 in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_6153(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=((C_word*)t0)[2];
/* c-backend.scm: 468  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[498],C_SCHEME_TRUE);}

/* procedures in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_fcall f_5378(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5378,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5384,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* for-each */
t3=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,((C_word*)t0)[2]);}

/* a5383 in procedures in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_5384(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5384,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5388,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 711  lambda-literal-argument-count */
((C_proc3)C_retrieve_symbol_proc(lf[282]))(3,*((C_word*)lf[282]+1),t3,t2);}

/* k5386 in a5383 in procedures in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_5388(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5388,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5391,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
/* c-backend.scm: 712  lambda-literal-id */
((C_proc3)C_retrieve_symbol_proc(lf[11]))(3,*((C_word*)lf[11]+1),t2,((C_word*)t0)[6]);}

/* k5389 in k5386 in a5383 in procedures in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_5391(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5391,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5394,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* c-backend.scm: 713  real-name */
((C_proc4)C_retrieve_symbol_proc(lf[497]))(4,*((C_word*)lf[497]+1),t2,t1,((C_word*)t0)[2]);}

/* k5392 in k5389 in k5386 in a5383 in procedures in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_5394(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5394,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5397,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm: 714  lambda-literal-allocated */
((C_proc3)C_retrieve_symbol_proc(lf[275]))(3,*((C_word*)lf[275]+1),t2,((C_word*)t0)[6]);}

/* k5395 in k5392 in k5389 in k5386 in a5383 in procedures in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_5397(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5397,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5400,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* c-backend.scm: 715  lambda-literal-rest-argument */
((C_proc3)C_retrieve_symbol_proc(lf[278]))(3,*((C_word*)lf[278]+1),t2,((C_word*)t0)[7]);}

/* k5398 in k5395 in k5392 in k5389 in k5386 in a5383 in procedures in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_5400(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5400,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_5403,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t3,a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
/* c-backend.scm: 716  lambda-literal-customizable */
((C_proc3)C_retrieve_symbol_proc(lf[281]))(3,*((C_word*)lf[281]+1),t4,((C_word*)t0)[8]);}

/* k5401 in k5398 in k5395 in k5392 in k5389 in k5386 in a5383 in procedures in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_5403(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5403,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_5406,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6122,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 717  lambda-literal-closure-size */
((C_proc3)C_retrieve_symbol_proc(lf[145]))(3,*((C_word*)lf[145]+1),t3,((C_word*)t0)[8]);}
else{
t3=t2;
f_5406(t3,C_SCHEME_FALSE);}}

/* k6120 in k5401 in k5398 in k5395 in k5392 in k5389 in k5386 in a5383 in procedures in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_6122(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_5406(t2,(C_word)C_eqp(t1,C_fix(0)));}

/* k5404 in k5401 in k5398 in k5395 in k5392 in k5389 in k5386 in a5383 in procedures in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_fcall f_5406(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5406,NULL,2,t0,t1);}
t2=(C_truep(t1)?C_fix(1):C_fix(0));
t3=(C_word)C_fixnum_difference(((C_word*)t0)[13],t2);
t4=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_5412,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t3,a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],a[12]=((C_word*)t0)[10],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[11],a[15]=((C_word*)t0)[12],tmp=(C_word)a,a+=16,tmp);
/* c-backend.scm: 719  make-variable-list */
((C_proc4)C_retrieve_symbol_proc(lf[279]))(4,*((C_word*)lf[279]+1),t4,((C_word*)t0)[13],lf[496]);}

/* k5410 in k5404 in k5401 in k5398 in k5395 in k5392 in k5389 in k5386 in a5383 in procedures in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_5412(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5412,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_5415,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],tmp=(C_word)a,a+=17,tmp);
/* c-backend.scm: 720  make-argument-list */
((C_proc4)C_retrieve_symbol_proc(lf[289]))(4,*((C_word*)lf[289]+1),t2,((C_word*)t0)[13],lf[495]);}

/* k5413 in k5410 in k5404 in k5401 in k5398 in k5395 in k5392 in k5389 in k5386 in a5383 in procedures in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_5415(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5415,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_5418,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
t3=(C_truep(((C_word*)t0)[4])?(C_word)C_i_cdr(((C_word*)t0)[2]):((C_word*)t0)[2]);
/* c-backend.scm: 721  intersperse */
((C_proc4)C_retrieve_symbol_proc(lf[6]))(4,*((C_word*)lf[6]+1),t2,t3,C_make_character(44));}

/* k5416 in k5413 in k5410 in k5404 in k5401 in k5398 in k5395 in k5392 in k5389 in k5386 in a5383 in procedures in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_5418(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5418,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_5421,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=t1,a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
t3=(C_truep(((C_word*)t0)[4])?(C_word)C_i_cdr(((C_word*)t0)[2]):((C_word*)t0)[2]);
/* c-backend.scm: 722  intersperse */
((C_proc4)C_retrieve_symbol_proc(lf[6]))(4,*((C_word*)lf[6]+1),t2,t3,C_make_character(44));}

/* k5419 in k5416 in k5413 in k5410 in k5404 in k5401 in k5398 in k5395 in k5392 in k5389 in k5386 in a5383 in procedures in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_5421(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5421,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_5424,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],tmp=(C_word)a,a+=18,tmp);
/* c-backend.scm: 723  lambda-literal-external */
((C_proc3)C_retrieve_symbol_proc(lf[330]))(3,*((C_word*)lf[330]+1),t2,((C_word*)t0)[12]);}

/* k5422 in k5419 in k5416 in k5413 in k5410 in k5404 in k5401 in k5398 in k5395 in k5392 in k5389 in k5386 in a5383 in procedures in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_5424(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5424,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_5427,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],tmp=(C_word)a,a+=19,tmp);
/* c-backend.scm: 724  lambda-literal-looping */
((C_proc3)C_retrieve_symbol_proc(lf[106]))(3,*((C_word*)lf[106]+1),t2,((C_word*)t0)[13]);}

/* k5425 in k5422 in k5419 in k5416 in k5413 in k5410 in k5404 in k5401 in k5398 in k5395 in k5392 in k5389 in k5386 in a5383 in procedures in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_5427(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5427,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|19,a[1]=(C_word)f_5430,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],tmp=(C_word)a,a+=20,tmp);
/* c-backend.scm: 725  lambda-literal-direct */
((C_proc3)C_retrieve_symbol_proc(lf[276]))(3,*((C_word*)lf[276]+1),t2,((C_word*)t0)[14]);}

/* k5428 in k5425 in k5422 in k5419 in k5416 in k5413 in k5410 in k5404 in k5401 in k5398 in k5395 in k5392 in k5389 in k5386 in a5383 in procedures in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_5430(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5430,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_5433,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],tmp=(C_word)a,a+=21,tmp);
/* c-backend.scm: 726  lambda-literal-rest-argument-mode */
((C_proc3)C_retrieve_symbol_proc(lf[277]))(3,*((C_word*)lf[277]+1),t2,((C_word*)t0)[15]);}

/* k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in k5413 in k5410 in k5404 in k5401 in k5398 in k5395 in k5392 in k5389 in k5386 in a5383 in procedures in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_5433(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5433,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|21,a[1]=(C_word)f_5436,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=t1,a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],tmp=(C_word)a,a+=22,tmp);
/* c-backend.scm: 727  lambda-literal-temporaries */
((C_proc3)C_retrieve_symbol_proc(lf[104]))(3,*((C_word*)lf[104]+1),t2,((C_word*)t0)[16]);}

/* k5434 in k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in k5413 in k5410 in k5404 in k5401 in k5398 in k5395 in k5392 in k5389 in k5386 in a5383 in procedures in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_5436(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5436,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_5439,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=t1,a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],tmp=(C_word)a,a+=23,tmp);
if(C_truep(C_retrieve(lf[206]))){
/* c-backend.scm: 729  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[113]+1)))(4,*((C_word*)lf[113]+1),t2,C_retrieve(lf[206]),lf[493]);}
else{
t3=t2;
f_5439(2,t3,lf[494]);}}

/* k5437 in k5434 in k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in k5413 in k5410 in k5404 in k5401 in k5398 in k5395 in k5392 in k5389 in k5386 in a5383 in procedures in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_5439(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5439,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_5442,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],tmp=(C_word)a,a+=24,tmp);
if(C_truep(((C_word*)t0)[4])){
/* c-backend.scm: 731  debugging */
((C_proc5)C_retrieve_symbol_proc(lf[490]))(5,*((C_word*)lf[490]+1),t2,lf[491],lf[492],((C_word*)t0)[14]);}
else{
t3=t2;
f_5442(2,t3,C_SCHEME_UNDEFINED);}}

/* k5440 in k5437 in k5434 in k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in k5413 in k5410 in k5404 in k5401 in k5398 in k5395 in k5392 in k5389 in k5386 in a5383 in procedures in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_5442(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5442,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_5445,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],tmp=(C_word)a,a+=24,tmp);
/* c-backend.scm: 732  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,C_SCHEME_TRUE);}

/* k5443 in k5440 in k5437 in k5434 in k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in k5413 in k5410 in k5404 in k5401 in k5398 in k5395 in k5392 in k5389 in k5386 in a5383 in procedures in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_5445(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5445,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_5448,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],tmp=(C_word)a,a+=23,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6091,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 733  cleanup */
((C_proc3)C_retrieve_symbol_proc(lf[489]))(3,*((C_word*)lf[489]+1),t3,((C_word*)t0)[2]);}

/* k6089 in k5443 in k5440 in k5437 in k5434 in k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in k5413 in k5410 in k5404 in k5401 in k5398 in k5395 in k5392 in k5389 in k5386 in a5383 in procedures in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_6091(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 733  gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[487],t1,lf[488],C_SCHEME_TRUE);}

/* k5446 in k5443 in k5440 in k5437 in k5434 in k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in k5413 in k5410 in k5404 in k5401 in k5398 in k5395 in k5392 in k5389 in k5386 in a5383 in procedures in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_5448(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[29],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5448,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_5451,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
t3=(C_word)C_eqp(lf[255],((C_word*)t0)[14]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6074,a[2]=((C_word*)t0)[5],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 742  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t4,lf[481]);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6052,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[14],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 735  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t4,lf[486]);}}

/* k6050 in k5446 in k5443 in k5440 in k5437 in k5434 in k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in k5413 in k5410 in k5404 in k5401 in k5398 in k5395 in k5392 in k5389 in k5386 in a5383 in procedures in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_6052(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6052,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6055,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_truep(((C_word*)t0)[2])?lf[484]:lf[485]);
/* c-backend.scm: 736  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,t3);}

/* k6053 in k6050 in k5446 in k5443 in k5440 in k5437 in k5434 in k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in k5413 in k5410 in k5404 in k5401 in k5398 in k5395 in k5392 in k5389 in k5386 in a5383 in procedures in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_6055(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6055,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6058,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[2])){
/* c-backend.scm: 738  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,lf[482]);}
else{
/* c-backend.scm: 739  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,lf[483]);}}

/* k6056 in k6053 in k6050 in k5446 in k5443 in k5440 in k5437 in k5434 in k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in k5413 in k5410 in k5404 in k5401 in k5398 in k5395 in k5392 in k5389 in k5386 in a5383 in procedures in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_6058(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 740  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k6072 in k5446 in k5443 in k5440 in k5437 in k5434 in k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in k5413 in k5410 in k5404 in k5401 in k5398 in k5395 in k5392 in k5389 in k5386 in a5383 in procedures in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_6074(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6074,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6077,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve(lf[206]))){
t3=t2;
f_6077(2,t3,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 744  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[480]);}}

/* k6075 in k6072 in k5446 in k5443 in k5440 in k5437 in k5434 in k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in k5413 in k5410 in k5404 in k5401 in k5398 in k5395 in k5392 in k5389 in k5386 in a5383 in procedures in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_6077(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 745  gen */
((C_proc16)C_retrieve_symbol_proc(lf[1]))(16,*((C_word*)lf[1]+1),((C_word*)t0)[3],C_SCHEME_TRUE,lf[474],C_SCHEME_TRUE,lf[475],C_SCHEME_TRUE,lf[476],C_SCHEME_TRUE,lf[477],((C_word*)t0)[2],lf[478],C_SCHEME_TRUE,C_SCHEME_TRUE,lf[479],((C_word*)t0)[2]);}

/* k5449 in k5446 in k5443 in k5440 in k5437 in k5434 in k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in k5413 in k5410 in k5404 in k5401 in k5398 in k5395 in k5392 in k5389 in k5386 in a5383 in procedures in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_5451(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5451,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_5454,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
/* c-backend.scm: 750  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,C_make_character(40));}

/* k5452 in k5449 in k5446 in k5443 in k5440 in k5437 in k5434 in k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in k5413 in k5410 in k5404 in k5401 in k5398 in k5395 in k5392 in k5389 in k5386 in a5383 in procedures in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_5454(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5454,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_5457,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
if(C_truep(((C_word*)t0)[10])){
t3=t2;
f_5457(2,t3,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 751  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,lf[473]);}}

/* k5455 in k5452 in k5449 in k5446 in k5443 in k5440 in k5437 in k5434 in k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in k5413 in k5410 in k5404 in k5401 in k5398 in k5395 in k5392 in k5389 in k5386 in a5383 in procedures in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_5457(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5457,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_5460,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6024,a[2]=t2,a[3]=((C_word*)t0)[15],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[9])){
t4=(C_word)C_eqp(((C_word*)t0)[17],C_fix(0));
t5=t3;
f_6024(t5,(C_word)C_i_not(t4));}
else{
t4=t3;
f_6024(t4,C_SCHEME_FALSE);}}

/* k6022 in k5455 in k5452 in k5449 in k5446 in k5443 in k5440 in k5437 in k5434 in k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in k5413 in k5410 in k5404 in k5401 in k5398 in k5395 in k5392 in k5389 in k5386 in a5383 in procedures in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_fcall f_6024(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6024,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6027,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 753  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,lf[472]);}
else{
t2=((C_word*)t0)[2];
f_5460(2,t2,C_SCHEME_UNDEFINED);}}

/* k6025 in k6022 in k5455 in k5452 in k5449 in k5446 in k5443 in k5440 in k5437 in k5434 in k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in k5413 in k5410 in k5404 in k5401 in k5398 in k5395 in k5392 in k5389 in k5386 in a5383 in procedures in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_6027(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
/* c-backend.scm: 754  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(44));}
else{
t2=((C_word*)t0)[2];
f_5460(2,t2,C_SCHEME_UNDEFINED);}}

/* k5458 in k5455 in k5452 in k5449 in k5446 in k5443 in k5440 in k5437 in k5434 in k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in k5413 in k5410 in k5404 in k5401 in k5398 in k5395 in k5392 in k5389 in k5386 in a5383 in procedures in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_5460(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5460,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_5463,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
C_apply(4,0,t2,C_retrieve(lf[1]),((C_word*)t0)[15]);}

/* k5461 in k5458 in k5455 in k5452 in k5449 in k5446 in k5443 in k5440 in k5437 in k5434 in k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in k5413 in k5410 in k5404 in k5401 in k5398 in k5395 in k5392 in k5389 in k5386 in a5383 in procedures in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_5463(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5463,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_5466,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
if(C_truep(((C_word*)((C_word*)t0)[21])[1])){
/* c-backend.scm: 756  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,lf[471]);}
else{
t3=t2;
f_5466(2,t3,C_SCHEME_UNDEFINED);}}

/* k5464 in k5461 in k5458 in k5455 in k5452 in k5449 in k5446 in k5443 in k5440 in k5437 in k5434 in k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in k5413 in k5410 in k5404 in k5401 in k5398 in k5395 in k5392 in k5389 in k5386 in a5383 in procedures in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_5466(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5466,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_5469,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
/* c-backend.scm: 757  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,lf[470]);}

/* k5467 in k5464 in k5461 in k5458 in k5455 in k5452 in k5449 in k5446 in k5443 in k5440 in k5437 in k5434 in k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in k5413 in k5410 in k5404 in k5401 in k5398 in k5395 in k5392 in k5389 in k5386 in a5383 in procedures in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_5469(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5469,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_5472,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[13],lf[244]);
if(C_truep(t3)){
t4=C_set_block_item(((C_word*)t0)[21],0,C_SCHEME_FALSE);
t5=t2;
f_5472(t5,t4);}
else{
t4=t2;
f_5472(t4,C_SCHEME_UNDEFINED);}}

/* k5470 in k5467 in k5464 in k5461 in k5458 in k5455 in k5452 in k5449 in k5446 in k5443 in k5440 in k5437 in k5434 in k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in k5413 in k5410 in k5404 in k5401 in k5398 in k5395 in k5392 in k5389 in k5386 in a5383 in procedures in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_fcall f_5472(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5472,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_5475,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
/* c-backend.scm: 759  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[469]);}

/* k5473 in k5470 in k5467 in k5464 in k5461 in k5458 in k5455 in k5452 in k5449 in k5446 in k5443 in k5440 in k5437 in k5434 in k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in k5413 in k5410 in k5404 in k5401 in k5398 in k5395 in k5392 in k5389 in k5386 in a5383 in procedures in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_5475(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5475,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_5478,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
if(C_truep(((C_word*)((C_word*)t0)[21])[1])){
/* c-backend.scm: 761  gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[467],((C_word*)t0)[20],C_make_character(59));}
else{
t3=(C_truep(((C_word*)t0)[2])?(C_word)C_fixnum_decrease(((C_word*)t0)[20]):C_fix(0));
t4=(C_word)C_fixnum_plus(((C_word*)t0)[16],t3);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5986,a[2]=t6,tmp=(C_word)a,a+=3,tmp));
t8=((C_word*)t6)[1];
f_5986(t8,t2,((C_word*)t0)[20],t4);}}

/* doloop1018 in k5473 in k5470 in k5467 in k5464 in k5461 in k5458 in k5455 in k5452 in k5449 in k5446 in k5443 in k5440 in k5437 in k5434 in k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in k5413 in k5410 in k5404 in k5401 in k5398 in k5395 in k5392 in k5389 in k5386 in a5383 in procedures in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_fcall f_5986(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5986,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t3,C_fix(0));
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5996,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 765  gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),t5,C_SCHEME_TRUE,lf[468],t2,C_make_character(59));}}

/* k5994 in doloop1018 in k5473 in k5470 in k5467 in k5464 in k5461 in k5458 in k5455 in k5452 in k5449 in k5446 in k5443 in k5440 in k5437 in k5434 in k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in k5413 in k5410 in k5404 in k5401 in k5398 in k5395 in k5392 in k5389 in k5386 in a5383 in procedures in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_5996(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_fixnum_increase(((C_word*)t0)[5]);
t3=(C_word)C_fixnum_decrease(((C_word*)t0)[4]);
t4=((C_word*)((C_word*)t0)[3])[1];
f_5986(t4,((C_word*)t0)[2],t2,t3);}

/* k5476 in k5473 in k5470 in k5467 in k5464 in k5461 in k5458 in k5455 in k5452 in k5449 in k5446 in k5443 in k5440 in k5437 in k5434 in k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in k5413 in k5410 in k5404 in k5401 in k5398 in k5395 in k5392 in k5389 in k5386 in a5383 in procedures in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_5478(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5478,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_5481,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[12],a[7]=((C_word*)t0)[13],a[8]=((C_word*)t0)[14],a[9]=((C_word*)t0)[15],a[10]=((C_word*)t0)[16],a[11]=((C_word*)t0)[17],a[12]=((C_word*)t0)[18],a[13]=((C_word*)t0)[19],a[14]=((C_word*)t0)[20],a[15]=((C_word*)t0)[21],a[16]=((C_word*)t0)[22],tmp=(C_word)a,a+=17,tmp);
t3=(C_word)C_eqp(lf[255],((C_word*)t0)[14]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5698,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[17],a[4]=((C_word*)t0)[6],a[5]=t2,a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5773,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 767  fold */
((C_proc5)C_retrieve_symbol_proc(lf[434]))(5,*((C_word*)lf[434]+1),t4,t5,C_fix(0),((C_word*)t0)[7]);}
else{
if(C_truep(((C_word*)((C_word*)t0)[21])[1])){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5787,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[20],a[4]=((C_word*)t0)[17],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 801  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t4,C_SCHEME_TRUE,lf[448]);}
else{
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5851,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[20],a[4]=((C_word*)t0)[13],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[17],a[8]=((C_word*)t0)[2],a[9]=t2,tmp=(C_word)a,a+=10,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5929,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[17],a[4]=t4,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
t6=((C_word*)t0)[9];
if(C_truep(t6)){
t7=t5;
f_5929(t7,C_SCHEME_FALSE);}
else{
t7=((C_word*)t0)[17];
t8=t5;
f_5929(t8,(C_word)C_fixnum_greaterp(t7,C_fix(0)));}}}}

/* k5927 in k5476 in k5473 in k5470 in k5467 in k5464 in k5461 in k5458 in k5455 in k5452 in k5449 in k5446 in k5443 in k5440 in k5437 in k5434 in k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in k5413 in k5410 in k5404 in k5401 in k5398 in k5395 in k5392 in k5389 in k5386 in a5383 in procedures in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_fcall f_5929(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5929,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(((C_word*)t0)[5])){
/* c-backend.scm: 815  gen */
((C_proc10)C_retrieve_symbol_proc(lf[1]))(10,*((C_word*)lf[1]+1),((C_word*)t0)[4],C_SCHEME_TRUE,lf[458],C_SCHEME_TRUE,lf[459],C_SCHEME_TRUE,lf[460],((C_word*)t0)[3],lf[461]);}
else{
/* c-backend.scm: 818  gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),((C_word*)t0)[4],C_SCHEME_TRUE,lf[462],((C_word*)t0)[3],lf[463]);}}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5941,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=t2;
f_5941(2,t3,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 820  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[466]);}}}

/* k5939 in k5927 in k5476 in k5473 in k5470 in k5467 in k5464 in k5461 in k5458 in k5455 in k5452 in k5449 in k5446 in k5443 in k5440 in k5437 in k5434 in k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in k5413 in k5410 in k5404 in k5401 in k5398 in k5395 in k5392 in k5389 in k5386 in a5383 in procedures in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_5941(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5941,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5944,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[2])){
/* c-backend.scm: 821  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[465]);}
else{
t3=t2;
f_5944(2,t3,C_SCHEME_UNDEFINED);}}

/* k5942 in k5939 in k5927 in k5476 in k5473 in k5470 in k5467 in k5464 in k5461 in k5458 in k5455 in k5452 in k5449 in k5446 in k5443 in k5440 in k5437 in k5434 in k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in k5413 in k5410 in k5404 in k5401 in k5398 in k5395 in k5392 in k5389 in k5386 in a5383 in procedures in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_5944(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5944,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5950,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=C_retrieve(lf[129]);
t4=t2;
f_5950(t4,(C_truep(t3)?C_SCHEME_FALSE:(C_word)C_i_not(C_retrieve(lf[428]))));}
else{
t3=t2;
f_5950(t3,C_SCHEME_FALSE);}}

/* k5948 in k5942 in k5939 in k5927 in k5476 in k5473 in k5470 in k5467 in k5464 in k5461 in k5458 in k5455 in k5452 in k5449 in k5446 in k5443 in k5440 in k5437 in k5434 in k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in k5413 in k5410 in k5404 in k5401 in k5398 in k5395 in k5392 in k5389 in k5386 in a5383 in procedures in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_fcall f_5950(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* c-backend.scm: 823  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_SCHEME_TRUE,lf[464]);}
else{
t2=((C_word*)t0)[2];
f_5851(2,t2,C_SCHEME_UNDEFINED);}}

/* k5849 in k5476 in k5473 in k5470 in k5467 in k5464 in k5461 in k5458 in k5455 in k5452 in k5449 in k5446 in k5443 in k5440 in k5437 in k5434 in k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in k5413 in k5410 in k5404 in k5401 in k5398 in k5395 in k5392 in k5389 in k5386 in a5383 in procedures in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_5851(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5851,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5854,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5893,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[5])){
t4=C_retrieve(lf[129]);
if(C_truep(t4)){
t5=t3;
f_5893(t5,C_SCHEME_FALSE);}
else{
t5=C_retrieve(lf[442]);
t6=t3;
f_5893(t6,(C_truep(t5)?C_SCHEME_FALSE:(C_word)C_i_not(((C_word*)t0)[2])));}}
else{
t4=t3;
f_5893(t4,C_SCHEME_FALSE);}}

/* k5891 in k5849 in k5476 in k5473 in k5470 in k5467 in k5464 in k5461 in k5458 in k5455 in k5452 in k5449 in k5446 in k5443 in k5440 in k5437 in k5434 in k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in k5413 in k5410 in k5404 in k5401 in k5398 in k5395 in k5392 in k5389 in k5386 in a5383 in procedures in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_fcall f_5893(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[244]);
if(C_truep(t2)){
t3=((C_word*)t0)[3];
if(C_truep((C_word)C_fixnum_greaterp(t3,C_fix(2)))){
/* c-backend.scm: 827  gen */
((C_proc8)C_retrieve_symbol_proc(lf[1]))(8,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_SCHEME_TRUE,lf[452],((C_word*)t0)[3],lf[453],((C_word*)t0)[3],lf[454]);}
else{
t4=((C_word*)t0)[2];
f_5854(2,t4,C_SCHEME_UNDEFINED);}}
else{
/* c-backend.scm: 828  gen */
((C_proc8)C_retrieve_symbol_proc(lf[1]))(8,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_SCHEME_TRUE,lf[455],((C_word*)t0)[3],lf[456],((C_word*)t0)[3],lf[457]);}}
else{
t2=((C_word*)t0)[2];
f_5854(2,t2,C_SCHEME_UNDEFINED);}}

/* k5852 in k5849 in k5476 in k5473 in k5470 in k5467 in k5464 in k5461 in k5458 in k5455 in k5452 in k5449 in k5446 in k5443 in k5440 in k5437 in k5434 in k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in k5413 in k5410 in k5404 in k5401 in k5398 in k5395 in k5392 in k5389 in k5386 in a5383 in procedures in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_5854(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5854,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5860,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[3];
if(C_truep(t3)){
t4=t2;
f_5860(t4,C_SCHEME_FALSE);}
else{
if(C_truep(((C_word*)t0)[2])){
t4=t2;
f_5860(t4,((C_word*)t0)[2]);}
else{
t4=((C_word*)t0)[4];
t5=t2;
f_5860(t5,(C_word)C_fixnum_greaterp(t4,C_fix(0)));}}}

/* k5858 in k5852 in k5849 in k5476 in k5473 in k5470 in k5467 in k5464 in k5461 in k5458 in k5455 in k5452 in k5449 in k5446 in k5443 in k5440 in k5437 in k5434 in k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in k5413 in k5410 in k5404 in k5401 in k5398 in k5395 in k5392 in k5389 in k5386 in a5383 in procedures in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_fcall f_5860(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5860,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5863,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve(lf[437]))){
/* c-backend.scm: 830  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[451]);}
else{
t3=t2;
f_5863(2,t3,C_SCHEME_UNDEFINED);}}
else{
t2=((C_word*)t0)[4];
f_5481(2,t2,C_SCHEME_UNDEFINED);}}

/* k5861 in k5858 in k5852 in k5849 in k5476 in k5473 in k5470 in k5467 in k5464 in k5461 in k5458 in k5455 in k5452 in k5449 in k5446 in k5443 in k5440 in k5437 in k5434 in k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in k5413 in k5410 in k5404 in k5401 in k5398 in k5395 in k5392 in k5389 in k5386 in a5383 in procedures in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_5863(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5863,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5869,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=((C_word*)t0)[2];
t4=t2;
f_5869(t4,(C_word)C_fixnum_greaterp(t3,C_fix(0)));}
else{
t3=t2;
f_5869(t3,C_SCHEME_FALSE);}}

/* k5867 in k5861 in k5858 in k5852 in k5849 in k5476 in k5473 in k5470 in k5467 in k5464 in k5461 in k5458 in k5455 in k5452 in k5449 in k5446 in k5443 in k5440 in k5437 in k5434 in k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in k5413 in k5410 in k5404 in k5401 in k5398 in k5395 in k5392 in k5389 in k5386 in a5383 in procedures in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_fcall f_5869(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* c-backend.scm: 832  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_SCHEME_TRUE,lf[449]);}
else{
/* c-backend.scm: 833  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_SCHEME_TRUE,lf[450]);}}

/* k5785 in k5476 in k5473 in k5470 in k5467 in k5464 in k5461 in k5458 in k5455 in k5452 in k5449 in k5446 in k5443 in k5440 in k5437 in k5434 in k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in k5413 in k5410 in k5404 in k5401 in k5398 in k5395 in k5392 in k5389 in k5386 in a5383 in procedures in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_5787(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5787,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5790,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 802  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[447]);}

/* k5788 in k5785 in k5476 in k5473 in k5470 in k5467 in k5464 in k5461 in k5458 in k5455 in k5452 in k5449 in k5446 in k5443 in k5440 in k5437 in k5434 in k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in k5413 in k5410 in k5404 in k5401 in k5398 in k5395 in k5392 in k5389 in k5386 in a5383 in procedures in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_5790(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5790,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5793,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 803  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[446]);}

/* k5791 in k5788 in k5785 in k5476 in k5473 in k5470 in k5467 in k5464 in k5461 in k5458 in k5455 in k5452 in k5449 in k5446 in k5443 in k5440 in k5437 in k5434 in k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in k5413 in k5410 in k5404 in k5401 in k5398 in k5395 in k5392 in k5389 in k5386 in a5383 in procedures in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_5793(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5793,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5796,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=((C_word*)t0)[3];
if(C_truep((C_word)C_fixnum_greaterp(t3,C_fix(0)))){
t4=(C_word)C_fixnum_difference(((C_word*)t0)[3],C_fix(1));
/* c-backend.scm: 805  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t2,C_make_character(116),t4);}
else{
/* c-backend.scm: 806  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,lf[445]);}}

/* k5794 in k5791 in k5788 in k5785 in k5476 in k5473 in k5470 in k5467 in k5464 in k5461 in k5458 in k5455 in k5452 in k5449 in k5446 in k5443 in k5440 in k5437 in k5434 in k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in k5413 in k5410 in k5404 in k5401 in k5398 in k5395 in k5392 in k5389 in k5386 in a5383 in procedures in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_5796(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5796,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5799,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 807  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t2,lf[443],((C_word*)t0)[3],lf[444]);}

/* k5797 in k5794 in k5791 in k5788 in k5785 in k5476 in k5473 in k5470 in k5467 in k5464 in k5461 in k5458 in k5455 in k5452 in k5449 in k5446 in k5443 in k5440 in k5437 in k5434 in k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in k5413 in k5410 in k5404 in k5401 in k5398 in k5395 in k5392 in k5389 in k5386 in a5383 in procedures in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_5799(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5799,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5802,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5814,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=C_retrieve(lf[129]);
if(C_truep(t4)){
t5=t3;
f_5814(t5,C_SCHEME_FALSE);}
else{
t5=C_retrieve(lf[442]);
if(C_truep(t5)){
t6=t3;
f_5814(t6,C_SCHEME_FALSE);}
else{
t6=((C_word*)t0)[3];
t7=(C_word)C_fixnum_greaterp(t6,C_fix(2));
t8=t3;
f_5814(t8,(C_truep(t7)?(C_word)C_i_not(((C_word*)t0)[2]):C_SCHEME_FALSE));}}}

/* k5812 in k5797 in k5794 in k5791 in k5788 in k5785 in k5476 in k5473 in k5470 in k5467 in k5464 in k5461 in k5458 in k5455 in k5452 in k5449 in k5446 in k5443 in k5440 in k5437 in k5434 in k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in k5413 in k5410 in k5404 in k5401 in k5398 in k5395 in k5392 in k5389 in k5386 in a5383 in procedures in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_fcall f_5814(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* c-backend.scm: 809  gen */
((C_proc8)C_retrieve_symbol_proc(lf[1]))(8,*((C_word*)lf[1]+1),((C_word*)t0)[3],C_SCHEME_TRUE,lf[439],((C_word*)t0)[2],lf[440],((C_word*)t0)[2],lf[441]);}
else{
t2=((C_word*)t0)[3];
f_5802(2,t2,C_SCHEME_UNDEFINED);}}

/* k5800 in k5797 in k5794 in k5791 in k5788 in k5785 in k5476 in k5473 in k5470 in k5467 in k5464 in k5461 in k5458 in k5455 in k5452 in k5449 in k5446 in k5443 in k5440 in k5437 in k5434 in k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in k5413 in k5410 in k5404 in k5401 in k5398 in k5395 in k5392 in k5389 in k5386 in a5383 in procedures in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_5802(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5802,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5805,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve(lf[437]))){
/* c-backend.scm: 810  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[438]);}
else{
t3=t2;
f_5805(2,t3,C_SCHEME_UNDEFINED);}}

/* k5803 in k5800 in k5797 in k5794 in k5791 in k5788 in k5785 in k5476 in k5473 in k5470 in k5467 in k5464 in k5461 in k5458 in k5455 in k5452 in k5449 in k5446 in k5443 in k5440 in k5437 in k5434 in k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in k5413 in k5410 in k5404 in k5401 in k5398 in k5395 in k5392 in k5389 in k5386 in a5383 in procedures in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_5805(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 811  gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),((C_word*)t0)[3],C_SCHEME_TRUE,lf[435],((C_word*)t0)[2],lf[436]);}

/* a5772 in k5476 in k5473 in k5470 in k5467 in k5464 in k5461 in k5458 in k5455 in k5452 in k5449 in k5446 in k5443 in k5440 in k5437 in k5434 in k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in k5413 in k5410 in k5404 in k5401 in k5398 in k5395 in k5392 in k5389 in k5386 in a5383 in procedures in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_5773(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5773,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5781,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 767  literal-size */
t5=((C_word*)((C_word*)t0)[2])[1];
f_4988(3,t5,t4,t2);}

/* k5779 in a5772 in k5476 in k5473 in k5470 in k5467 in k5464 in k5461 in k5458 in k5455 in k5452 in k5449 in k5446 in k5443 in k5440 in k5437 in k5434 in k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in k5413 in k5410 in k5404 in k5401 in k5398 in k5395 in k5392 in k5389 in k5386 in a5383 in procedures in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_5781(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_fixnum_plus(((C_word*)t0)[2],t1));}

/* k5696 in k5476 in k5473 in k5470 in k5467 in k5464 in k5461 in k5458 in k5455 in k5452 in k5449 in k5446 in k5443 in k5440 in k5437 in k5434 in k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in k5413 in k5410 in k5404 in k5401 in k5398 in k5395 in k5392 in k5389 in k5386 in a5383 in procedures in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_5698(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5698,2,t0,t1);}
t2=(C_word)C_i_length(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5704,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 769  gen */
((C_proc10)C_retrieve_symbol_proc(lf[1]))(10,*((C_word*)lf[1]+1),t3,C_SCHEME_TRUE,lf[430],C_SCHEME_TRUE,lf[431],C_SCHEME_TRUE,lf[432],((C_word*)t0)[2],lf[433]);}

/* k5702 in k5696 in k5476 in k5473 in k5470 in k5467 in k5464 in k5461 in k5458 in k5455 in k5452 in k5449 in k5446 in k5443 in k5440 in k5437 in k5434 in k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in k5413 in k5410 in k5404 in k5401 in k5398 in k5395 in k5392 in k5389 in k5386 in a5383 in procedures in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_5704(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5704,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5707,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(C_retrieve(lf[428]))){
/* c-backend.scm: 773  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[429]);}
else{
t3=t2;
f_5707(2,t3,C_SCHEME_UNDEFINED);}}

/* k5705 in k5702 in k5696 in k5476 in k5473 in k5470 in k5467 in k5464 in k5461 in k5458 in k5455 in k5452 in k5449 in k5446 in k5443 in k5440 in k5437 in k5434 in k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in k5413 in k5410 in k5404 in k5401 in k5398 in k5395 in k5392 in k5389 in k5386 in a5383 in procedures in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_5707(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5707,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5710,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(C_retrieve(lf[206]))){
t3=t2;
f_5710(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5741,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[421]))){
/* c-backend.scm: 776  gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),t3,C_SCHEME_TRUE,lf[422],C_retrieve(lf[421]),lf[423]);}
else{
if(C_truep(C_retrieve(lf[424]))){
/* c-backend.scm: 778  gen */
((C_proc8)C_retrieve_symbol_proc(lf[1]))(8,*((C_word*)lf[1]+1),t3,C_SCHEME_TRUE,lf[425],C_retrieve(lf[424]),lf[426],C_SCHEME_TRUE,lf[427]);}
else{
t4=t3;
f_5741(2,t4,C_SCHEME_UNDEFINED);}}}}

/* k5739 in k5705 in k5702 in k5696 in k5476 in k5473 in k5470 in k5467 in k5464 in k5461 in k5458 in k5455 in k5452 in k5449 in k5446 in k5443 in k5440 in k5437 in k5434 in k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in k5413 in k5410 in k5404 in k5401 in k5398 in k5395 in k5392 in k5389 in k5386 in a5383 in procedures in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_5741(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5741,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5744,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[419]))){
/* c-backend.scm: 781  gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[420],C_retrieve(lf[419]),C_make_character(59));}
else{
t3=t2;
f_5744(2,t3,C_SCHEME_UNDEFINED);}}

/* k5742 in k5739 in k5705 in k5702 in k5696 in k5476 in k5473 in k5470 in k5467 in k5464 in k5461 in k5458 in k5455 in k5452 in k5449 in k5446 in k5443 in k5440 in k5437 in k5434 in k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in k5413 in k5410 in k5404 in k5401 in k5398 in k5395 in k5392 in k5389 in k5386 in a5383 in procedures in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_5744(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5744,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5747,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[417]))){
/* c-backend.scm: 783  gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[418],C_retrieve(lf[417]),C_make_character(59));}
else{
t3=t2;
f_5747(2,t3,C_SCHEME_UNDEFINED);}}

/* k5745 in k5742 in k5739 in k5705 in k5702 in k5696 in k5476 in k5473 in k5470 in k5467 in k5464 in k5461 in k5458 in k5455 in k5452 in k5449 in k5446 in k5443 in k5440 in k5437 in k5434 in k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in k5413 in k5410 in k5404 in k5401 in k5398 in k5395 in k5392 in k5389 in k5386 in a5383 in procedures in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_5747(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(C_retrieve(lf[414]))){
/* c-backend.scm: 785  gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_SCHEME_TRUE,lf[415],C_retrieve(lf[414]),lf[416]);}
else{
t2=((C_word*)t0)[2];
f_5710(2,t2,C_SCHEME_UNDEFINED);}}

/* k5708 in k5705 in k5702 in k5696 in k5476 in k5473 in k5470 in k5467 in k5464 in k5461 in k5458 in k5455 in k5452 in k5449 in k5446 in k5443 in k5440 in k5437 in k5434 in k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in k5413 in k5410 in k5404 in k5401 in k5398 in k5395 in k5392 in k5389 in k5386 in a5383 in procedures in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_5710(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5710,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5713,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 786  gen */
((C_proc16)C_retrieve_symbol_proc(lf[1]))(16,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[407],((C_word*)t0)[3],lf[408],C_SCHEME_TRUE,lf[409],((C_word*)t0)[3],lf[410],C_SCHEME_TRUE,lf[411],C_SCHEME_TRUE,lf[412],C_SCHEME_TRUE,lf[413]);}

/* k5711 in k5708 in k5705 in k5702 in k5696 in k5476 in k5473 in k5470 in k5467 in k5464 in k5461 in k5458 in k5455 in k5452 in k5449 in k5446 in k5443 in k5440 in k5437 in k5434 in k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in k5413 in k5410 in k5404 in k5401 in k5398 in k5395 in k5392 in k5389 in k5386 in a5383 in procedures in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_5713(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5713,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5716,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 791  gen */
((C_proc14)C_retrieve_symbol_proc(lf[1]))(14,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[401],((C_word*)t0)[2],lf[402],C_SCHEME_TRUE,lf[403],C_SCHEME_TRUE,lf[404],((C_word*)t0)[2],lf[405],C_SCHEME_TRUE,lf[406]);}

/* k5714 in k5711 in k5708 in k5705 in k5702 in k5696 in k5476 in k5473 in k5470 in k5467 in k5464 in k5461 in k5458 in k5455 in k5452 in k5449 in k5446 in k5443 in k5440 in k5437 in k5434 in k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in k5413 in k5410 in k5404 in k5401 in k5398 in k5395 in k5392 in k5389 in k5386 in a5383 in procedures in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_5716(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5716,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5719,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 795  gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[399],((C_word*)t0)[2],lf[400]);}

/* k5717 in k5714 in k5711 in k5708 in k5705 in k5702 in k5696 in k5476 in k5473 in k5470 in k5467 in k5464 in k5461 in k5458 in k5455 in k5452 in k5449 in k5446 in k5443 in k5440 in k5437 in k5434 in k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in k5413 in k5410 in k5404 in k5401 in k5398 in k5395 in k5392 in k5389 in k5386 in a5383 in procedures in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_5719(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5719,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[4],C_fix(0));
if(C_truep(t2)){
t3=((C_word*)t0)[3];
f_5481(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5728,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 797  gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),t3,C_SCHEME_TRUE,lf[397],((C_word*)t0)[4],lf[398]);}}

/* k5726 in k5717 in k5714 in k5711 in k5708 in k5705 in k5702 in k5696 in k5476 in k5473 in k5470 in k5467 in k5464 in k5461 in k5458 in k5455 in k5452 in k5449 in k5446 in k5443 in k5440 in k5437 in k5434 in k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in k5413 in k5410 in k5404 in k5401 in k5398 in k5395 in k5392 in k5389 in k5386 in a5383 in procedures in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_5728(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5728,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5731,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 798  literal-frame */
t3=((C_word*)t0)[2];
f_4945(t3,t2);}

/* k5729 in k5726 in k5717 in k5714 in k5711 in k5708 in k5705 in k5702 in k5696 in k5476 in k5473 in k5470 in k5467 in k5464 in k5461 in k5458 in k5455 in k5452 in k5449 in k5446 in k5443 in k5440 in k5437 in k5434 in k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in k5413 in k5410 in k5404 in k5401 in k5398 in k5395 in k5392 in k5389 in k5386 in a5383 in procedures in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_5731(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 799  gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),((C_word*)t0)[3],C_SCHEME_TRUE,lf[395],((C_word*)t0)[2],lf[396]);}

/* k5479 in k5476 in k5473 in k5470 in k5467 in k5464 in k5461 in k5458 in k5455 in k5452 in k5449 in k5446 in k5443 in k5440 in k5437 in k5434 in k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in k5413 in k5410 in k5404 in k5401 in k5398 in k5395 in k5392 in k5389 in k5386 in a5383 in procedures in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_5481(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5481,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5484,a[2]=((C_word*)t0)[12],a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[14],a[5]=((C_word*)t0)[15],a[6]=((C_word*)t0)[16],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_5504,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[14],a[10]=t2,a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[15],tmp=(C_word)a,a+=13,tmp);
t4=(C_word)C_eqp(lf[255],((C_word*)t0)[8]);
if(C_truep(t4)){
t5=t3;
f_5504(t5,C_SCHEME_FALSE);}
else{
t5=((C_word*)t0)[3];
if(C_truep(t5)){
t6=t3;
f_5504(t6,C_SCHEME_FALSE);}
else{
t6=((C_word*)((C_word*)t0)[15])[1];
if(C_truep(t6)){
t7=t3;
f_5504(t7,t6);}
else{
if(C_truep(((C_word*)t0)[2])){
t7=t3;
f_5504(t7,((C_word*)t0)[2]);}
else{
t7=((C_word*)t0)[11];
t8=t3;
f_5504(t8,(C_word)C_fixnum_greaterp(t7,C_fix(0)));}}}}}

/* k5502 in k5479 in k5476 in k5473 in k5470 in k5467 in k5464 in k5461 in k5458 in k5455 in k5452 in k5449 in k5446 in k5443 in k5440 in k5437 in k5434 in k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in k5413 in k5410 in k5404 in k5401 in k5398 in k5395 in k5392 in k5389 in k5386 in a5383 in procedures in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_fcall f_5504(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5504,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(((C_word*)((C_word*)t0)[12])[1])){
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5510,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
t3=(C_word)C_fixnum_greaterp(((C_word*)t0)[4],C_fix(0));
t4=(C_truep(t3)?lf[386]:lf[387]);
/* c-backend.scm: 844  gen */
((C_proc7)C_retrieve_symbol_proc(lf[1]))(7,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,t4,lf[388],((C_word*)t0)[9],C_make_character(114));}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5639,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_fixnum_greaterp(((C_word*)t0)[4],C_fix(0));
t4=(C_truep(t3)?lf[392]:lf[393]);
/* c-backend.scm: 870  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,t4,lf[394]);}}
else{
t2=((C_word*)t0)[10];
f_5484(2,t2,C_SCHEME_UNDEFINED);}}

/* k5637 in k5502 in k5479 in k5476 in k5473 in k5470 in k5467 in k5464 in k5461 in k5458 in k5455 in k5452 in k5449 in k5446 in k5443 in k5440 in k5437 in k5434 in k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in k5413 in k5410 in k5404 in k5401 in k5398 in k5395 in k5392 in k5389 in k5386 in a5383 in procedures in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_5639(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5639,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5642,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[4])){
/* c-backend.scm: 872  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t2,((C_word*)t0)[3],lf[390]);}
else{
/* c-backend.scm: 873  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t2,((C_word*)t0)[2],lf[391],((C_word*)t0)[3]);}}

/* k5640 in k5637 in k5502 in k5479 in k5476 in k5473 in k5470 in k5467 in k5464 in k5461 in k5458 in k5455 in k5452 in k5449 in k5446 in k5443 in k5440 in k5437 in k5434 in k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in k5413 in k5410 in k5404 in k5401 in k5398 in k5395 in k5392 in k5389 in k5386 in a5383 in procedures in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_5642(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5642,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5645,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_fixnum_greaterp(((C_word*)t0)[3],C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5654,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 875  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t3,C_make_character(44),((C_word*)t0)[3],C_make_character(44));}
else{
t3=t2;
f_5645(2,t3,C_SCHEME_UNDEFINED);}}

/* k5652 in k5640 in k5637 in k5502 in k5479 in k5476 in k5473 in k5470 in k5467 in k5464 in k5461 in k5458 in k5455 in k5452 in k5449 in k5446 in k5443 in k5440 in k5437 in k5434 in k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in k5413 in k5410 in k5404 in k5401 in k5398 in k5395 in k5392 in k5389 in k5386 in a5383 in procedures in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_5654(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],C_retrieve(lf[1]),((C_word*)t0)[2]);}

/* k5643 in k5640 in k5637 in k5502 in k5479 in k5476 in k5473 in k5470 in k5467 in k5464 in k5461 in k5458 in k5455 in k5452 in k5449 in k5446 in k5443 in k5440 in k5437 in k5434 in k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in k5413 in k5410 in k5404 in k5401 in k5398 in k5395 in k5392 in k5389 in k5386 in a5383 in procedures in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_5645(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 877  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[389]);}

/* k5508 in k5502 in k5479 in k5476 in k5473 in k5470 in k5467 in k5464 in k5461 in k5458 in k5455 in k5452 in k5449 in k5446 in k5443 in k5440 in k5437 in k5434 in k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in k5413 in k5410 in k5404 in k5401 in k5398 in k5395 in k5392 in k5389 in k5386 in a5383 in procedures in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_5510(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5510,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5513,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[4],lf[329]);
if(C_truep(t3)){
/* c-backend.scm: 845  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,C_make_character(118));}
else{
t4=t2;
f_5513(2,t4,C_SCHEME_UNDEFINED);}}

/* k5511 in k5508 in k5502 in k5479 in k5476 in k5473 in k5470 in k5467 in k5464 in k5461 in k5458 in k5455 in k5452 in k5449 in k5446 in k5443 in k5440 in k5437 in k5434 in k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in k5413 in k5410 in k5404 in k5401 in k5398 in k5395 in k5392 in k5389 in k5386 in a5383 in procedures in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_5513(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5513,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5516,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm: 846  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t2,lf[384],((C_word*)t0)[5],lf[385]);}

/* k5514 in k5511 in k5508 in k5502 in k5479 in k5476 in k5473 in k5470 in k5467 in k5464 in k5461 in k5458 in k5455 in k5452 in k5449 in k5446 in k5443 in k5440 in k5437 in k5434 in k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in k5413 in k5410 in k5404 in k5401 in k5398 in k5395 in k5392 in k5389 in k5386 in a5383 in procedures in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_5516(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5516,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5519,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_fixnum_greaterp(((C_word*)t0)[3],C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5620,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 848  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t3,C_make_character(44),((C_word*)t0)[3],C_make_character(44));}
else{
t3=t2;
f_5519(2,t3,C_SCHEME_UNDEFINED);}}

/* k5618 in k5514 in k5511 in k5508 in k5502 in k5479 in k5476 in k5473 in k5470 in k5467 in k5464 in k5461 in k5458 in k5455 in k5452 in k5449 in k5446 in k5443 in k5440 in k5437 in k5434 in k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in k5413 in k5410 in k5404 in k5401 in k5398 in k5395 in k5392 in k5389 in k5386 in a5383 in procedures in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_5620(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],C_retrieve(lf[1]),((C_word*)t0)[2]);}

/* k5517 in k5514 in k5511 in k5508 in k5502 in k5479 in k5476 in k5473 in k5470 in k5467 in k5464 in k5461 in k5458 in k5455 in k5452 in k5449 in k5446 in k5443 in k5440 in k5437 in k5434 in k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in k5413 in k5410 in k5404 in k5401 in k5398 in k5395 in k5392 in k5389 in k5386 in a5383 in procedures in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_5519(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5519,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5522,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 850  gen */
((C_proc9)C_retrieve_symbol_proc(lf[1]))(9,*((C_word*)lf[1]+1),t2,lf[380],C_SCHEME_TRUE,lf[381],C_SCHEME_TRUE,lf[382],((C_word*)t0)[6],lf[383]);}

/* k5520 in k5517 in k5514 in k5511 in k5508 in k5502 in k5479 in k5476 in k5473 in k5470 in k5467 in k5464 in k5461 in k5458 in k5455 in k5452 in k5449 in k5446 in k5443 in k5440 in k5437 in k5434 in k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in k5413 in k5410 in k5404 in k5401 in k5398 in k5395 in k5392 in k5389 in k5386 in a5383 in procedures in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_5522(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5522,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5525,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[2],lf[375]);
t4=(C_truep(t3)?t3:(C_word)C_eqp(((C_word*)t0)[2],C_SCHEME_FALSE));
if(C_truep(t4)){
/* c-backend.scm: 854  gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[376],((C_word*)t0)[6],lf[377]);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[2],lf[329]);
if(C_truep(t5)){
/* c-backend.scm: 855  gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[378],((C_word*)t0)[6],lf[379]);}
else{
t6=t2;
f_5525(2,t6,C_SCHEME_UNDEFINED);}}}

/* k5523 in k5520 in k5517 in k5514 in k5511 in k5508 in k5502 in k5479 in k5476 in k5473 in k5470 in k5467 in k5464 in k5461 in k5458 in k5455 in k5452 in k5449 in k5446 in k5443 in k5440 in k5437 in k5434 in k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in k5413 in k5410 in k5404 in k5401 in k5398 in k5395 in k5392 in k5389 in k5386 in a5383 in procedures in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_5525(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5525,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5528,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 856  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,((C_word*)t0)[2],lf[374]);}

/* k5526 in k5523 in k5520 in k5517 in k5514 in k5511 in k5508 in k5502 in k5479 in k5476 in k5473 in k5470 in k5467 in k5464 in k5461 in k5458 in k5455 in k5452 in k5449 in k5446 in k5443 in k5440 in k5437 in k5434 in k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in k5413 in k5410 in k5404 in k5401 in k5398 in k5395 in k5392 in k5389 in k5386 in a5383 in procedures in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_5528(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5528,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5531,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5589,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5593,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 857  make-argument-list */
((C_proc4)C_retrieve_symbol_proc(lf[289]))(4,*((C_word*)lf[289]+1),t4,((C_word*)t0)[5],lf[373]);}

/* k5591 in k5526 in k5523 in k5520 in k5517 in k5514 in k5511 in k5508 in k5502 in k5479 in k5476 in k5473 in k5470 in k5467 in k5464 in k5461 in k5458 in k5455 in k5452 in k5449 in k5446 in k5443 in k5440 in k5437 in k5434 in k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in k5413 in k5410 in k5404 in k5401 in k5398 in k5395 in k5392 in k5389 in k5386 in a5383 in procedures in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_5593(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 857  intersperse */
((C_proc4)C_retrieve_symbol_proc(lf[6]))(4,*((C_word*)lf[6]+1),((C_word*)t0)[2],t1,C_make_character(44));}

/* k5587 in k5526 in k5523 in k5520 in k5517 in k5514 in k5511 in k5508 in k5502 in k5479 in k5476 in k5473 in k5470 in k5467 in k5464 in k5461 in k5458 in k5455 in k5452 in k5449 in k5446 in k5443 in k5440 in k5437 in k5434 in k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in k5413 in k5410 in k5404 in k5401 in k5398 in k5395 in k5392 in k5389 in k5386 in a5383 in procedures in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_5589(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],C_retrieve(lf[1]),t1);}

/* k5529 in k5526 in k5523 in k5520 in k5517 in k5514 in k5511 in k5508 in k5502 in k5479 in k5476 in k5473 in k5470 in k5467 in k5464 in k5461 in k5458 in k5455 in k5452 in k5449 in k5446 in k5443 in k5440 in k5437 in k5434 in k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in k5413 in k5410 in k5404 in k5401 in k5398 in k5395 in k5392 in k5389 in k5386 in a5383 in procedures in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_5531(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5531,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5534,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 858  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t2,lf[371],((C_word*)t0)[5],lf[372]);}

/* k5532 in k5529 in k5526 in k5523 in k5520 in k5517 in k5514 in k5511 in k5508 in k5502 in k5479 in k5476 in k5473 in k5470 in k5467 in k5464 in k5461 in k5458 in k5455 in k5452 in k5449 in k5446 in k5443 in k5440 in k5437 in k5434 in k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in k5413 in k5410 in k5404 in k5401 in k5398 in k5395 in k5392 in k5389 in k5386 in a5383 in procedures in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_5534(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5534,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5537,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 860  gen */
((C_proc7)C_retrieve_symbol_proc(lf[1]))(7,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,C_SCHEME_TRUE,lf[369],((C_word*)t0)[2],lf[370]);}

/* k5535 in k5532 in k5529 in k5526 in k5523 in k5520 in k5517 in k5514 in k5511 in k5508 in k5502 in k5479 in k5476 in k5473 in k5470 in k5467 in k5464 in k5461 in k5458 in k5455 in k5452 in k5449 in k5446 in k5443 in k5440 in k5437 in k5434 in k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in k5413 in k5410 in k5404 in k5401 in k5398 in k5395 in k5392 in k5389 in k5386 in a5383 in procedures in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_5537(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5537,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5540,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
C_apply(4,0,t2,C_retrieve(lf[1]),((C_word*)t0)[2]);}

/* k5538 in k5535 in k5532 in k5529 in k5526 in k5523 in k5520 in k5517 in k5514 in k5511 in k5508 in k5502 in k5479 in k5476 in k5473 in k5470 in k5467 in k5464 in k5461 in k5458 in k5455 in k5452 in k5449 in k5446 in k5443 in k5440 in k5437 in k5434 in k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in k5413 in k5410 in k5404 in k5401 in k5398 in k5395 in k5392 in k5389 in k5386 in a5383 in procedures in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_5540(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5540,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5543,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 862  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t2,lf[367],((C_word*)t0)[3],lf[368]);}

/* k5541 in k5538 in k5535 in k5532 in k5529 in k5526 in k5523 in k5520 in k5517 in k5514 in k5511 in k5508 in k5502 in k5479 in k5476 in k5473 in k5470 in k5467 in k5464 in k5461 in k5458 in k5455 in k5452 in k5449 in k5446 in k5443 in k5440 in k5437 in k5434 in k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in k5413 in k5410 in k5404 in k5401 in k5398 in k5395 in k5392 in k5389 in k5386 in a5383 in procedures in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_5543(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5543,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5546,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 863  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[366]);}

/* k5544 in k5541 in k5538 in k5535 in k5532 in k5529 in k5526 in k5523 in k5520 in k5517 in k5514 in k5511 in k5508 in k5502 in k5479 in k5476 in k5473 in k5470 in k5467 in k5464 in k5461 in k5458 in k5455 in k5452 in k5449 in k5446 in k5443 in k5440 in k5437 in k5434 in k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in k5413 in k5410 in k5404 in k5401 in k5398 in k5395 in k5392 in k5389 in k5386 in a5383 in procedures in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_5546(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5546,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5549,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5564,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_5564(t7,t2,t3,((C_word*)t0)[2]);}

/* doloop1182 in k5544 in k5541 in k5538 in k5535 in k5532 in k5529 in k5526 in k5523 in k5520 in k5517 in k5514 in k5511 in k5508 in k5502 in k5479 in k5476 in k5473 in k5470 in k5467 in k5464 in k5461 in k5458 in k5455 in k5452 in k5449 in k5446 in k5443 in k5440 in k5437 in k5434 in k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in k5413 in k5410 in k5404 in k5401 in k5398 in k5395 in k5392 in k5389 in k5386 in a5383 in procedures in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_fcall f_5564(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5564,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t3,C_fix(0));
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5574,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 867  gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),t5,C_SCHEME_TRUE,lf[365],t2,C_make_character(59));}}

/* k5572 in doloop1182 in k5544 in k5541 in k5538 in k5535 in k5532 in k5529 in k5526 in k5523 in k5520 in k5517 in k5514 in k5511 in k5508 in k5502 in k5479 in k5476 in k5473 in k5470 in k5467 in k5464 in k5461 in k5458 in k5455 in k5452 in k5449 in k5446 in k5443 in k5440 in k5437 in k5434 in k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in k5413 in k5410 in k5404 in k5401 in k5398 in k5395 in k5392 in k5389 in k5386 in a5383 in procedures in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_5574(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_fixnum_difference(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_5564(t4,((C_word*)t0)[2],t2,t3);}

/* k5547 in k5544 in k5541 in k5538 in k5535 in k5532 in k5529 in k5526 in k5523 in k5520 in k5517 in k5514 in k5511 in k5508 in k5502 in k5479 in k5476 in k5473 in k5470 in k5467 in k5464 in k5461 in k5458 in k5455 in k5452 in k5449 in k5446 in k5443 in k5440 in k5437 in k5434 in k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in k5413 in k5410 in k5404 in k5401 in k5398 in k5395 in k5392 in k5389 in k5386 in a5383 in procedures in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_5549(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=((C_word*)t0)[3];
if(C_truep((C_word)C_fixnum_greaterp(t2,C_fix(0)))){
/* c-backend.scm: 868  gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_SCHEME_TRUE,lf[363],((C_word*)t0)[3],lf[364]);}
else{
t3=((C_word*)t0)[2];
f_5484(2,t3,C_SCHEME_UNDEFINED);}}

/* k5482 in k5479 in k5476 in k5473 in k5470 in k5467 in k5464 in k5461 in k5458 in k5455 in k5452 in k5449 in k5446 in k5443 in k5440 in k5437 in k5434 in k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in k5413 in k5410 in k5404 in k5401 in k5398 in k5395 in k5392 in k5389 in k5386 in a5383 in procedures in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_5484(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5484,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5487,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5494,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 879  lambda-literal-body */
((C_proc3)C_retrieve_symbol_proc(lf[362]))(3,*((C_word*)lf[362]+1),t3,((C_word*)t0)[2]);}

/* k5492 in k5482 in k5479 in k5476 in k5473 in k5470 in k5467 in k5464 in k5461 in k5458 in k5455 in k5452 in k5449 in k5446 in k5443 in k5440 in k5437 in k5434 in k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in k5413 in k5410 in k5404 in k5401 in k5398 in k5395 in k5392 in k5389 in k5386 in a5383 in procedures in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_5494(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(((C_word*)((C_word*)t0)[6])[1])?(C_word)C_fixnum_increase(((C_word*)t0)[5]):((C_word*)t0)[5]);
/* c-backend.scm: 878  expression */
t3=((C_word*)t0)[4];
f_2539(t3,((C_word*)t0)[3],t1,t2,((C_word*)t0)[2]);}

/* k5485 in k5482 in k5479 in k5476 in k5473 in k5470 in k5467 in k5464 in k5461 in k5458 in k5455 in k5452 in k5449 in k5446 in k5443 in k5440 in k5437 in k5434 in k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in k5413 in k5410 in k5404 in k5401 in k5398 in k5395 in k5392 in k5389 in k5386 in a5383 in procedures in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_5487(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 884  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(125));}

/* literal-size in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_4988(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4988,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4995,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 646  immediate? */
((C_proc3)C_retrieve_symbol_proc(lf[361]))(3,*((C_word*)lf[361]+1),t3,t2);}

/* k4993 in literal-size in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_4995(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4995,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}
else{
if(C_truep((C_word)C_i_stringp(((C_word*)t0)[4]))){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}
else{
if(C_truep((C_word)C_i_numberp(((C_word*)t0)[4]))){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_retrieve(lf[355]));}
else{
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[4]))){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(10));}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5026,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 650  literal-size */
t4=((C_word*)((C_word*)t0)[3])[1];
f_4988(3,t4,t2,t3);}
else{
if(C_truep((C_word)C_i_vectorp(((C_word*)t0)[4]))){
t2=(C_word)C_i_vector_length(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5055,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5059,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5063,a[2]=((C_word*)t0)[3],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 651  vector->list */
((C_proc3)C_retrieve_proc(*((C_word*)lf[358]+1)))(3,*((C_word*)lf[358]+1),t5,((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5069,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 652  block-variable-literal? */
((C_proc3)C_retrieve_symbol_proc(lf[351]))(3,*((C_word*)lf[351]+1),t2,((C_word*)t0)[4]);}}}}}}}

/* k5067 in k4993 in literal-size in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_5069(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5069,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}
else{
if(C_truep((C_word)C_immp(((C_word*)t0)[4]))){
/* c-backend.scm: 653  bad-literal */
f_4982(((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
if(C_truep((C_word)C_lambdainfop(((C_word*)t0)[4]))){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5087,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 655  ##sys#bytevector? */
((C_proc3)C_retrieve_proc(*((C_word*)lf[360]+1)))(3,*((C_word*)lf[360]+1),t2,((C_word*)t0)[4]);}}}}

/* k5085 in k5067 in k4993 in literal-size in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_5087(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5087,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5094,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[4]);
/* c-backend.scm: 655  words */
((C_proc3)C_retrieve_symbol_proc(lf[359]))(3,*((C_word*)lf[359]+1),t2,t3);}
else{
if(C_truep((C_word)C_structurep(((C_word*)t0)[4]))){
t2=(C_word)C_block_size(((C_word*)t0)[4]);
t3=(C_word)C_fixnum_plus(C_fix(2),t2);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5116,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t5,a[5]=t2,tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_5116(t7,((C_word*)t0)[5],C_fix(0),t3);}
else{
/* c-backend.scm: 662  bad-literal */
f_4982(((C_word*)t0)[5],((C_word*)t0)[4]);}}}

/* loop in k5085 in k5067 in k4993 in literal-size in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_fcall f_5116(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5116,NULL,4,t0,t1,t2,t3);}
t4=t2;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t4,((C_word*)t0)[5]))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}
else{
t5=(C_word)C_fixnum_increase(t2);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5138,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_slot(((C_word*)t0)[3],t2);
/* c-backend.scm: 661  literal-size */
t8=((C_word*)((C_word*)t0)[2])[1];
f_4988(3,t8,t6,t7);}}

/* k5136 in loop in k5085 in k5067 in k4993 in literal-size in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_5138(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[5],t1);
/* c-backend.scm: 661  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_5116(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k5092 in k5085 in k5067 in k4993 in literal-size in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_5094(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_fixnum_plus(C_fix(2),t1));}

/* k5061 in k4993 in literal-size in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_5063(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[220]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t1);}

/* k5057 in k4993 in literal-size in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_5059(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 651  reduce */
((C_proc5)C_retrieve_symbol_proc(lf[356]))(5,*((C_word*)lf[356]+1),((C_word*)t0)[2],*((C_word*)lf[357]+1),C_fix(0),t1);}

/* k5053 in k4993 in literal-size in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_5055(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_fixnum_plus((C_word)C_fixnum_plus(C_fix(1),((C_word*)t0)[2]),t1));}

/* k5024 in k4993 in literal-size in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_5026(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5026,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5030,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* c-backend.scm: 650  literal-size */
t4=((C_word*)((C_word*)t0)[2])[1];
f_4988(3,t4,t2,t3);}

/* k5028 in k5024 in k4993 in literal-size in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_5030(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_fixnum_plus((C_word)C_fixnum_plus(C_fix(3),((C_word*)t0)[2]),t1));}

/* literal-frame in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_fcall f_4945(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4945,NULL,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4951,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_4951(t5,t1,C_fix(0),((C_word*)t0)[2]);}

/* doloop827 in literal-frame in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_fcall f_4951(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4951,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4961,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(t3);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4980,a[2]=t5,a[3]=t4,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 640  sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[353]))(4,*((C_word*)lf[353]+1),t6,lf[354],t2);}}

/* k4978 in doloop827 in literal-frame in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_4980(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 640  gen-lit */
t2=((C_word*)t0)[4];
f_5147(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4959 in doloop827 in literal-frame in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_4961(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_fixnum_increase(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
t4=((C_word*)((C_word*)t0)[3])[1];
f_4951(t4,((C_word*)t0)[2],t2,t3);}

/* gen-lit in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_fcall f_5147(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5147,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5154,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t3,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_fixnump(t2))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5287,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 666  big-fixnum? */
((C_proc3)C_retrieve_symbol_proc(lf[352]))(3,*((C_word*)lf[352]+1),t5,t2);}
else{
t5=t4;
f_5154(t5,C_SCHEME_FALSE);}}

/* k5285 in gen-lit in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_5287(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_5154(t2,(C_word)C_i_not(t1));}

/* k5152 in gen-lit in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_fcall f_5154(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5154,NULL,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm: 667  gen */
((C_proc7)C_retrieve_symbol_proc(lf[1]))(7,*((C_word*)lf[1]+1),((C_word*)t0)[6],C_SCHEME_TRUE,((C_word*)t0)[5],lf[336],((C_word*)t0)[4],lf[337]);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5160,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 668  block-variable-literal? */
((C_proc3)C_retrieve_symbol_proc(lf[351]))(3,*((C_word*)lf[351]+1),t2,((C_word*)t0)[4]);}}

/* k5158 in k5152 in gen-lit in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_5160(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5160,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=C_retrieve(lf[338]);
t3=(C_word)C_eqp(((C_word*)t0)[5],t2);
if(C_truep(t3)){
/* c-backend.scm: 670  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),((C_word*)t0)[6],C_SCHEME_TRUE,((C_word*)t0)[4],lf[339]);}
else{
if(C_truep((C_word)C_booleanp(((C_word*)t0)[5]))){
t4=(C_truep(((C_word*)t0)[5])?lf[340]:lf[341]);
/* c-backend.scm: 672  gen */
((C_proc7)C_retrieve_symbol_proc(lf[1]))(7,*((C_word*)lf[1]+1),((C_word*)t0)[6],C_SCHEME_TRUE,((C_word*)t0)[4],C_make_character(61),t4,C_make_character(59));}
else{
if(C_truep((C_word)C_charp(((C_word*)t0)[5]))){
t4=(C_word)C_fix((C_word)C_character_code(((C_word*)t0)[5]));
/* c-backend.scm: 674  gen */
((C_proc7)C_retrieve_symbol_proc(lf[1]))(7,*((C_word*)lf[1]+1),((C_word*)t0)[6],C_SCHEME_TRUE,((C_word*)t0)[4],lf[342],t4,lf[343]);}
else{
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[5]))){
t4=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5210,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[6],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 677  c-ify-string */
((C_proc3)C_retrieve_symbol_proc(lf[76]))(3,*((C_word*)lf[76]+1),t5,t4);}
else{
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[5]))){
/* c-backend.scm: 682  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),((C_word*)t0)[6],C_SCHEME_TRUE,((C_word*)t0)[4],lf[347]);}
else{
t4=(C_word)C_immp(((C_word*)t0)[5]);
t5=(C_truep(t4)?C_SCHEME_FALSE:(C_word)C_lambdainfop(((C_word*)t0)[5]));
if(C_truep(t5)){
t6=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t6=(C_word)C_fixnump(((C_word*)t0)[5]);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5243,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t6)){
t8=t7;
f_5243(t8,t6);}
else{
t8=(C_word)C_immp(((C_word*)t0)[5]);
t9=t7;
f_5243(t9,(C_word)C_i_not(t8));}}}}}}}}}

/* k5241 in k5158 in k5152 in gen-lit in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_fcall f_5243(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5243,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5246,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 686  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,((C_word*)t0)[3],lf[350]);}
else{
/* c-backend.scm: 689  bad-literal */
f_4982(((C_word*)t0)[6],((C_word*)t0)[4]);}}

/* k5244 in k5241 in k5158 in k5152 in gen-lit in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_5246(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5246,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5249,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5256,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 687  encode-literal */
((C_proc3)C_retrieve_symbol_proc(lf[349]))(3,*((C_word*)lf[349]+1),t3,((C_word*)t0)[2]);}

/* k5254 in k5244 in k5241 in k5158 in k5152 in gen-lit in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_5256(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 687  gen-string-constant */
t2=((C_word*)t0)[3];
f_5289(t2,((C_word*)t0)[2],t1);}

/* k5247 in k5244 in k5241 in k5158 in k5152 in gen-lit in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_5249(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 688  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[348]);}

/* k5208 in k5158 in k5152 in gen-lit in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_5210(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5210,2,t0,t1);}
t2=(C_word)C_block_size(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5216,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 679  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t3,C_SCHEME_TRUE,((C_word*)t0)[2],lf[346]);}

/* k5214 in k5208 in k5158 in k5152 in gen-lit in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_5216(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 680  gen */
((C_proc9)C_retrieve_symbol_proc(lf[1]))(9,*((C_word*)lf[1]+1),((C_word*)t0)[5],lf[344],((C_word*)t0)[4],C_make_character(44),((C_word*)t0)[3],C_make_character(44),((C_word*)t0)[2],lf[345]);}

/* bad-literal in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_fcall f_4982(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4982,NULL,2,t1,t2);}
/* c-backend.scm: 643  bomb */
((C_proc4)C_retrieve_symbol_proc(lf[9]))(4,*((C_word*)lf[9]+1),t1,lf[335],t2);}

/* gen-string-constant in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_fcall f_5289(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5289,NULL,3,t0,t1,t2);}
t3=(C_word)C_block_size(t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5296,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 693  fx/ */
((C_proc4)C_retrieve_proc(*((C_word*)lf[334]+1)))(4,*((C_word*)lf[334]+1),t4,t3,C_fix(80));}

/* k5294 in gen-string-constant in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_5296(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5296,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5299,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 694  modulo */
((C_proc4)C_retrieve_proc(*((C_word*)lf[333]+1)))(4,*((C_word*)lf[333]+1),t2,((C_word*)t0)[5],C_fix(80));}

/* k5297 in k5294 in gen-string-constant in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_5299(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5299,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5304,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_5304(t5,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0));}

/* doloop913 in k5297 in k5294 in gen-string-constant in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_fcall f_5304(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5304,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t4)){
t5=(C_word)C_eqp(((C_word*)t0)[6],C_fix(0));
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5320,a[2]=((C_word*)t0)[6],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t5)){
t7=t6;
f_5320(t7,t5);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[3],C_fix(0));
t8=t6;
f_5320(t8,(C_word)C_i_not(t7));}}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5341,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5356,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5360,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_fixnum_plus(t3,C_fix(80));
/* c-backend.scm: 700  string-like-substring */
f_5366(t7,((C_word*)t0)[4],t3,t8);}}

/* k5358 in doloop913 in k5297 in k5294 in gen-string-constant in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_5360(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 700  c-ify-string */
((C_proc3)C_retrieve_symbol_proc(lf[76]))(3,*((C_word*)lf[76]+1),((C_word*)t0)[2],t1);}

/* k5354 in doloop913 in k5297 in k5294 in gen-string-constant in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_5356(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 700  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),((C_word*)t0)[2],t1,C_SCHEME_TRUE);}

/* k5339 in doloop913 in k5297 in k5294 in gen-string-constant in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_5341(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_fixnum_decrease(((C_word*)t0)[5]);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(80));
t4=((C_word*)((C_word*)t0)[3])[1];
f_5304(t4,((C_word*)t0)[2],t2,t3);}

/* k5318 in doloop913 in k5297 in k5294 in gen-string-constant in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_fcall f_5320(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5320,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5327,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5331,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 699  string-like-substring */
f_5366(t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k5329 in k5318 in doloop913 in k5297 in k5294 in gen-string-constant in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_5331(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 699  c-ify-string */
((C_proc3)C_retrieve_symbol_proc(lf[76]))(3,*((C_word*)lf[76]+1),((C_word*)t0)[2],t1);}

/* k5325 in k5318 in doloop913 in k5297 in k5294 in gen-string-constant in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_5327(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 699  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],t1);}

/* string-like-substring in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_fcall f_5366(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5366,NULL,4,t1,t2,t3,t4);}
t5=(C_word)C_fixnum_difference(t4,t3);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5373,a[2]=t5,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 704  make-string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[332]+1)))(3,*((C_word*)lf[332]+1),t6,t5);}

/* k5371 in string-like-substring in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_5373(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5373,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5376,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 705  ##sys#copy-bytes */
((C_proc7)C_retrieve_symbol_proc(lf[331]))(7,*((C_word*)lf[331]+1),t2,((C_word*)t0)[4],t1,((C_word*)t0)[3],C_fix(0),((C_word*)t0)[2]);}

/* k5374 in k5371 in string-like-substring in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_5376(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* trampolines in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_fcall f_4659(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4659,NULL,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_END_OF_LIST;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4662,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4698,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
t10=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4778,a[2]=t3,a[3]=t8,a[4]=t5,a[5]=t9,a[6]=t7,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4826,a[2]=t3,a[3]=t5,a[4]=t7,a[5]=t8,tmp=(C_word)a,a+=6,tmp);
/* for-each */
t12=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t10,t11,((C_word*)t0)[2]);}

/* a4825 in trampolines in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_4826(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4826,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4830,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 599  lambda-literal-argument-count */
((C_proc3)C_retrieve_symbol_proc(lf[282]))(3,*((C_word*)lf[282]+1),t3,t2);}

/* k4828 in a4825 in trampolines in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_4830(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4830,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4833,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t3,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 600  lambda-literal-rest-argument */
((C_proc3)C_retrieve_symbol_proc(lf[278]))(3,*((C_word*)lf[278]+1),t4,((C_word*)t0)[2]);}

/* k4831 in k4828 in a4825 in trampolines in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_4833(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4833,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4836,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* c-backend.scm: 601  lambda-literal-rest-argument-mode */
((C_proc3)C_retrieve_symbol_proc(lf[277]))(3,*((C_word*)lf[277]+1),t2,((C_word*)t0)[2]);}

/* k4834 in k4831 in k4828 in a4825 in trampolines in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_4836(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4836,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4839,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm: 602  lambda-literal-id */
((C_proc3)C_retrieve_symbol_proc(lf[11]))(3,*((C_word*)lf[11]+1),t2,((C_word*)t0)[2]);}

/* k4837 in k4834 in k4831 in k4828 in a4825 in trampolines in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_4839(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4839,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4842,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* c-backend.scm: 603  lambda-literal-customizable */
((C_proc3)C_retrieve_symbol_proc(lf[281]))(3,*((C_word*)lf[281]+1),t2,((C_word*)t0)[2]);}

/* k4840 in k4837 in k4834 in k4831 in k4828 in a4825 in trampolines in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_4842(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4842,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4845,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=t1,a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4943,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 604  lambda-literal-closure-size */
((C_proc3)C_retrieve_symbol_proc(lf[145]))(3,*((C_word*)lf[145]+1),t3,((C_word*)t0)[2]);}
else{
t3=t2;
f_4845(t3,C_SCHEME_FALSE);}}

/* k4941 in k4840 in k4837 in k4834 in k4831 in k4828 in a4825 in trampolines in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_4943(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_4845(t2,(C_word)C_eqp(t1,C_fix(0)));}

/* k4843 in k4840 in k4837 in k4834 in k4831 in k4828 in a4825 in trampolines in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_fcall f_4845(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4845,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4848,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
if(C_truep(t1)){
t3=(C_word)C_fixnum_decrease(((C_word*)((C_word*)t0)[10])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[10])+1,t3);
t5=t2;
f_4848(t5,t4);}
else{
t3=t2;
f_4848(t3,C_SCHEME_UNDEFINED);}}

/* k4846 in k4843 in k4840 in k4837 in k4834 in k4831 in k4828 in a4825 in trampolines in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_fcall f_4848(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4848,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4854,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
/* c-backend.scm: 606  lambda-literal-direct */
((C_proc3)C_retrieve_symbol_proc(lf[276]))(3,*((C_word*)lf[276]+1),t2,((C_word*)t0)[2]);}

/* k4852 in k4846 in k4843 in k4840 in k4837 in k4834 in k4831 in k4828 in a4825 in trampolines in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_4854(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4854,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[12];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
if(C_truep(((C_word*)t0)[11])){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4860,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[12],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 608  gen */
((C_proc11)C_retrieve_symbol_proc(lf[1]))(11,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,C_SCHEME_TRUE,lf[325],((C_word*)t0)[9],lf[326],C_SCHEME_TRUE,lf[327],((C_word*)t0)[9],lf[328]);}
else{
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4888,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[12],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=t2;
f_4888(2,t3,((C_word*)t0)[3]);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4932,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 616  lambda-literal-allocated */
((C_proc3)C_retrieve_symbol_proc(lf[275]))(3,*((C_word*)lf[275]+1),t3,((C_word*)t0)[2]);}}}}

/* k4930 in k4852 in k4846 in k4843 in k4840 in k4837 in k4834 in k4831 in k4828 in a4825 in trampolines in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_4932(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_greaterp(t1,C_fix(0));
if(C_truep(t2)){
t3=((C_word*)t0)[3];
f_4888(2,t3,t2);}
else{
/* c-backend.scm: 616  lambda-literal-external */
((C_proc3)C_retrieve_symbol_proc(lf[330]))(3,*((C_word*)lf[330]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k4886 in k4852 in k4846 in k4843 in k4840 in k4837 in k4834 in k4831 in k4828 in a4825 in trampolines in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_4888(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4888,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4894,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(C_word)C_eqp(((C_word*)t0)[8],lf[244]);
t4=t2;
f_4894(t4,(C_word)C_i_not(t3));}
else{
t3=t2;
f_4894(t3,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k4892 in k4886 in k4852 in k4846 in k4843 in k4840 in k4837 in k4834 in k4831 in k4828 in a4825 in trampolines in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_fcall f_4894(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4894,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_eqp(((C_word*)t0)[7],lf[329]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4904,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 619  lset-adjoin */
((C_proc5)C_retrieve_symbol_proc(lf[272]))(5,*((C_word*)lf[272]+1),t3,*((C_word*)lf[273]+1),((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[4])[1]);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4908,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 620  lset-adjoin */
((C_proc5)C_retrieve_symbol_proc(lf[272]))(5,*((C_word*)lf[272]+1),t3,*((C_word*)lf[273]+1),((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[4])[1]);}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4912,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 621  lset-adjoin */
((C_proc5)C_retrieve_symbol_proc(lf[272]))(5,*((C_word*)lf[272]+1),t2,*((C_word*)lf[273]+1),((C_word*)((C_word*)t0)[2])[1],((C_word*)((C_word*)t0)[4])[1]);}}

/* k4910 in k4892 in k4886 in k4852 in k4846 in k4843 in k4840 in k4837 in k4834 in k4831 in k4828 in a4825 in trampolines in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_4912(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k4906 in k4892 in k4886 in k4852 in k4846 in k4843 in k4840 in k4837 in k4834 in k4831 in k4828 in a4825 in trampolines in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_4908(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k4902 in k4892 in k4886 in k4852 in k4846 in k4843 in k4840 in k4837 in k4834 in k4831 in k4828 in a4825 in trampolines in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_4904(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k4858 in k4852 in k4846 in k4843 in k4840 in k4837 in k4834 in k4831 in k4828 in a4825 in trampolines in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_4860(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4860,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4863,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 610  gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[323],((C_word*)t0)[3],lf[324]);}

/* k4861 in k4858 in k4852 in k4846 in k4843 in k4840 in k4837 in k4834 in k4831 in k4828 in a4825 in trampolines in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_4863(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4863,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4866,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 611  restore */
f_4662(t2,((C_word*)((C_word*)t0)[4])[1]);}

/* k4864 in k4861 in k4858 in k4852 in k4846 in k4843 in k4840 in k4837 in k4834 in k4831 in k4828 in a4825 in trampolines in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_4866(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4866,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4869,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 612  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,((C_word*)t0)[2],C_make_character(40));}

/* k4867 in k4864 in k4861 in k4858 in k4852 in k4846 in k4843 in k4840 in k4837 in k4834 in k4831 in k4828 in a4825 in trampolines in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_4869(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4869,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4872,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 613  make-argument-list */
((C_proc4)C_retrieve_symbol_proc(lf[289]))(4,*((C_word*)lf[289]+1),t2,((C_word*)((C_word*)t0)[2])[1],lf[322]);}

/* k4870 in k4867 in k4864 in k4861 in k4858 in k4852 in k4846 in k4843 in k4840 in k4837 in k4834 in k4831 in k4828 in a4825 in trampolines in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_4872(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4872,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4875,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4882,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 614  intersperse */
((C_proc4)C_retrieve_symbol_proc(lf[6]))(4,*((C_word*)lf[6]+1),t3,t1,C_make_character(44));}

/* k4880 in k4870 in k4867 in k4864 in k4861 in k4858 in k4852 in k4846 in k4843 in k4840 in k4837 in k4834 in k4831 in k4828 in a4825 in trampolines in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_4882(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],C_retrieve(lf[1]),t1);}

/* k4873 in k4870 in k4867 in k4864 in k4861 in k4858 in k4852 in k4846 in k4843 in k4840 in k4837 in k4834 in k4831 in k4828 in a4825 in trampolines in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_4875(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 615  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[321]);}

/* k4776 in trampolines in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_4778(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4778,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4781,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4797,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* for-each */
t4=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)((C_word*)t0)[2])[1]);}

/* a4796 in k4776 in trampolines in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_4797(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4797,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4801,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 625  gen */
((C_proc13)C_retrieve_symbol_proc(lf[1]))(13,*((C_word*)lf[1]+1),t3,C_SCHEME_TRUE,C_SCHEME_TRUE,lf[316],t2,lf[317],C_SCHEME_TRUE,lf[318],t2,lf[319],t2,lf[320]);}

/* k4799 in a4796 in k4776 in trampolines in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_4801(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4801,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4804,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 627  gen */
((C_proc8)C_retrieve_symbol_proc(lf[1]))(8,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[313],((C_word*)t0)[3],lf[314],((C_word*)t0)[3],lf[315]);}

/* k4802 in k4799 in a4796 in k4776 in trampolines in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_4804(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4804,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4807,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 628  restore */
f_4662(t2,((C_word*)t0)[3]);}

/* k4805 in k4802 in k4799 in a4796 in k4776 in trampolines in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_4807(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4807,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4810,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 629  gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[312],((C_word*)t0)[2],C_make_character(44));}

/* k4808 in k4805 in k4802 in k4799 in a4796 in k4776 in trampolines in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_4810(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4810,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4813,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4820,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4824,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 630  make-argument-list */
((C_proc4)C_retrieve_symbol_proc(lf[289]))(4,*((C_word*)lf[289]+1),t4,((C_word*)t0)[2],lf[311]);}

/* k4822 in k4808 in k4805 in k4802 in k4799 in a4796 in k4776 in trampolines in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_4824(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 630  intersperse */
((C_proc4)C_retrieve_symbol_proc(lf[6]))(4,*((C_word*)lf[6]+1),((C_word*)t0)[2],t1,C_make_character(44));}

/* k4818 in k4808 in k4805 in k4802 in k4799 in a4796 in k4776 in trampolines in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_4820(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],C_retrieve(lf[1]),t1);}

/* k4811 in k4808 in k4805 in k4802 in k4799 in a4796 in k4776 in trampolines in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_4813(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 631  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[310]);}

/* k4779 in k4776 in trampolines in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_4781(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4781,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4784,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4795,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 633  emitter */
t4=((C_word*)t0)[3];
f_4698(t4,t3,C_SCHEME_FALSE);}

/* k4793 in k4779 in k4776 in trampolines in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_4795(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)((C_word*)t0)[2])[1]);}

/* k4782 in k4779 in k4776 in trampolines in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_4784(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4784,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4791,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 634  emitter */
t3=((C_word*)t0)[2];
f_4698(t3,t2,C_SCHEME_TRUE);}

/* k4789 in k4782 in k4779 in k4776 in trampolines in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_4791(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)((C_word*)t0)[2])[1]);}

/* emitter in trampolines in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_fcall f_4698(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4698,NULL,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4700,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp));}

/* f_4700 in emitter in trampolines in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_4700(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4700,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4704,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=(C_truep(((C_word*)t0)[3])?C_make_character(118):lf[305]);
t5=(C_truep(((C_word*)t0)[3])?C_make_character(118):lf[306]);
/* c-backend.scm: 577  gen */
((C_proc14)C_retrieve_symbol_proc(lf[1]))(14,*((C_word*)lf[1]+1),t3,C_SCHEME_TRUE,C_SCHEME_TRUE,lf[307],t2,C_make_character(114),t4,lf[308],C_SCHEME_TRUE,lf[309],t2,C_make_character(114),t5);}

/* k4702 */
static void C_ccall f_4704(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4704,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4707,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 579  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t2,lf[303],((C_word*)t0)[4],lf[304]);}

/* k4705 in k4702 */
static void C_ccall f_4707(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4707,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4710,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 580  gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[302],((C_word*)t0)[4],C_make_character(114));}

/* k4708 in k4705 in k4702 */
static void C_ccall f_4710(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4710,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4713,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[3])){
/* c-backend.scm: 581  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,C_make_character(118));}
else{
t3=t2;
f_4713(2,t3,C_SCHEME_UNDEFINED);}}

/* k4711 in k4708 in k4705 in k4702 */
static void C_ccall f_4713(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4713,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4716,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 582  gen */
((C_proc11)C_retrieve_symbol_proc(lf[1]))(11,*((C_word*)lf[1]+1),t2,lf[298],((C_word*)t0)[4],lf[299],C_SCHEME_TRUE,lf[300],C_SCHEME_TRUE,lf[301],((C_word*)t0)[4],C_make_character(59));}

/* k4714 in k4711 in k4708 in k4705 in k4702 */
static void C_ccall f_4716(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4716,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4719,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 585  restore */
f_4662(t2,((C_word*)t0)[4]);}

/* k4717 in k4714 in k4711 in k4708 in k4705 in k4702 */
static void C_ccall f_4719(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4719,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4722,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 586  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[297]);}

/* k4720 in k4717 in k4714 in k4711 in k4708 in k4705 in k4702 */
static void C_ccall f_4722(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4722,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4725,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
/* c-backend.scm: 588  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[295]);}
else{
/* c-backend.scm: 589  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[296]);}}

/* k4723 in k4720 in k4717 in k4714 in k4711 in k4708 in k4705 in k4702 */
static void C_ccall f_4725(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4725,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4728,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 590  gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,C_make_character(116),((C_word*)t0)[3],lf[294]);}

/* k4726 in k4723 in k4720 in k4717 in k4714 in k4711 in k4708 in k4705 in k4702 */
static void C_ccall f_4728(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4728,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4731,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[2])){
/* c-backend.scm: 591  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,lf[293]);}
else{
t3=t2;
f_4731(2,t3,C_SCHEME_UNDEFINED);}}

/* k4729 in k4726 in k4723 in k4720 in k4717 in k4714 in k4711 in k4708 in k4705 in k4702 */
static void C_ccall f_4731(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4731,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4734,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 592  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,lf[292]);}

/* k4732 in k4729 in k4726 in k4723 in k4720 in k4717 in k4714 in k4711 in k4708 in k4705 in k4702 */
static void C_ccall f_4734(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4734,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4737,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 593  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[291]);}

/* k4735 in k4732 in k4729 in k4726 in k4723 in k4720 in k4717 in k4714 in k4711 in k4708 in k4705 in k4702 */
static void C_ccall f_4737(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4737,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4740,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4747,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4751,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_fixnum_plus(((C_word*)t0)[2],C_fix(1));
/* c-backend.scm: 594  make-argument-list */
((C_proc4)C_retrieve_symbol_proc(lf[289]))(4,*((C_word*)lf[289]+1),t4,t5,lf[290]);}

/* k4749 in k4735 in k4732 in k4729 in k4726 in k4723 in k4720 in k4717 in k4714 in k4711 in k4708 in k4705 in k4702 */
static void C_ccall f_4751(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 594  intersperse */
((C_proc4)C_retrieve_symbol_proc(lf[6]))(4,*((C_word*)lf[6]+1),((C_word*)t0)[2],t1,C_make_character(44));}

/* k4745 in k4735 in k4732 in k4729 in k4726 in k4723 in k4720 in k4717 in k4714 in k4711 in k4708 in k4705 in k4702 */
static void C_ccall f_4747(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],C_retrieve(lf[1]),t1);}

/* k4738 in k4735 in k4732 in k4729 in k4726 in k4723 in k4720 in k4717 in k4714 in k4711 in k4708 in k4705 in k4702 */
static void C_ccall f_4740(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 595  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[288]);}

/* restore in trampolines in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_fcall f_4662(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4662,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4666,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_fixnum_difference(t2,C_fix(1));
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4675,a[2]=t6,tmp=(C_word)a,a+=3,tmp));
t8=((C_word*)t6)[1];
f_4675(t8,t3,t4,C_fix(0));}

/* doloop728 in restore in trampolines in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_fcall f_4675(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4675,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4685,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 572  gen */
((C_proc8)C_retrieve_symbol_proc(lf[1]))(8,*((C_word*)lf[1]+1),t4,C_SCHEME_TRUE,lf[285],t2,lf[286],t3,lf[287]);}}

/* k4683 in doloop728 in restore in trampolines in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_4685(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_fixnum_difference(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_4675(t4,((C_word*)t0)[2],t2,t3);}

/* k4664 in restore in trampolines in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_4666(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 573  gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),((C_word*)t0)[3],C_SCHEME_TRUE,lf[283],((C_word*)t0)[2],lf[284]);}

/* prototypes in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_fcall f_4408(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4408,NULL,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4412,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 501  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t4,C_SCHEME_TRUE);}

/* k4410 in prototypes in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_4412(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4412,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4415,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4436,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* for-each */
t4=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a4435 in k4410 in prototypes in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_4436(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4436,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4440,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 504  lambda-literal-argument-count */
((C_proc3)C_retrieve_symbol_proc(lf[282]))(3,*((C_word*)lf[282]+1),t3,t2);}

/* k4438 in a4435 in k4410 in prototypes in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_4440(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4440,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4443,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 505  lambda-literal-customizable */
((C_proc3)C_retrieve_symbol_proc(lf[281]))(3,*((C_word*)lf[281]+1),t2,((C_word*)t0)[2]);}

/* k4441 in k4438 in a4435 in k4410 in prototypes in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_4443(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4443,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4446,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4657,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 506  lambda-literal-closure-size */
((C_proc3)C_retrieve_symbol_proc(lf[145]))(3,*((C_word*)lf[145]+1),t3,((C_word*)t0)[2]);}
else{
t3=t2;
f_4446(t3,C_SCHEME_FALSE);}}

/* k4655 in k4441 in k4438 in a4435 in k4410 in prototypes in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_4657(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_4446(t2,(C_word)C_eqp(t1,C_fix(0)));}

/* k4444 in k4441 in k4438 in a4435 in k4410 in prototypes in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_fcall f_4446(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4446,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4449,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4643,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_truep(t1)?(C_word)C_fixnum_decrease(((C_word*)t0)[5]):((C_word*)t0)[5]);
/* c-backend.scm: 507  make-variable-list */
((C_proc4)C_retrieve_symbol_proc(lf[279]))(4,*((C_word*)lf[279]+1),t3,t4,lf[280]);}

/* k4641 in k4444 in k4441 in k4438 in a4435 in k4410 in prototypes in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_4643(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 507  intersperse */
((C_proc4)C_retrieve_symbol_proc(lf[6]))(4,*((C_word*)lf[6]+1),((C_word*)t0)[2],t1,C_make_character(44));}

/* k4447 in k4444 in k4441 in k4438 in a4435 in k4410 in prototypes in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_4449(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4449,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4452,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 508  lambda-literal-id */
((C_proc3)C_retrieve_symbol_proc(lf[11]))(3,*((C_word*)lf[11]+1),t2,((C_word*)t0)[2]);}

/* k4450 in k4447 in k4444 in k4441 in k4438 in a4435 in k4410 in prototypes in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_4452(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4452,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4455,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 509  lambda-literal-rest-argument */
((C_proc3)C_retrieve_symbol_proc(lf[278]))(3,*((C_word*)lf[278]+1),t2,((C_word*)t0)[2]);}

/* k4453 in k4450 in k4447 in k4444 in k4441 in k4438 in a4435 in k4410 in prototypes in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_4455(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4455,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4458,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
/* c-backend.scm: 510  lambda-literal-rest-argument-mode */
((C_proc3)C_retrieve_symbol_proc(lf[277]))(3,*((C_word*)lf[277]+1),t2,((C_word*)t0)[2]);}

/* k4456 in k4453 in k4450 in k4447 in k4444 in k4441 in k4438 in a4435 in k4410 in prototypes in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_4458(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4458,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4461,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm: 511  lambda-literal-direct */
((C_proc3)C_retrieve_symbol_proc(lf[276]))(3,*((C_word*)lf[276]+1),t2,((C_word*)t0)[2]);}

/* k4459 in k4456 in k4453 in k4450 in k4447 in k4444 in k4441 in k4438 in a4435 in k4410 in prototypes in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_4461(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4461,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4464,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* c-backend.scm: 512  lambda-literal-allocated */
((C_proc3)C_retrieve_symbol_proc(lf[275]))(3,*((C_word*)lf[275]+1),t2,((C_word*)t0)[2]);}

/* k4462 in k4459 in k4456 in k4453 in k4450 in k4447 in k4444 in k4441 in k4438 in a4435 in k4410 in prototypes in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_4464(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4464,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4467,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
t3=((C_word*)t0)[8];
t4=C_retrieve(lf[271]);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,t4))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4635,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_fixnum_increase(((C_word*)t0)[8]);
/* c-backend.scm: 514  lset-adjoin */
((C_proc5)C_retrieve_symbol_proc(lf[272]))(5,*((C_word*)lf[272]+1),t5,*((C_word*)lf[273]+1),((C_word*)((C_word*)t0)[3])[1],t6);}
else{
t5=t2;
f_4467(t5,C_SCHEME_UNDEFINED);}}

/* k4633 in k4462 in k4459 in k4456 in k4453 in k4450 in k4447 in k4444 in k4441 in k4438 in a4435 in k4410 in prototypes in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_4635(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_4467(t3,t2);}

/* k4465 in k4462 in k4459 in k4456 in k4453 in k4450 in k4447 in k4444 in k4441 in k4438 in a4435 in k4410 in prototypes in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_fcall f_4467(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4467,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4470,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
/* c-backend.scm: 515  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE);}

/* k4468 in k4465 in k4462 in k4459 in k4456 in k4453 in k4450 in k4447 in k4444 in k4441 in k4438 in a4435 in k4410 in prototypes in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_4470(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4470,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4473,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4609,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4628,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 520  lambda-literal-callee-signatures */
((C_proc3)C_retrieve_symbol_proc(lf[274]))(3,*((C_word*)lf[274]+1),t4,((C_word*)t0)[2]);}

/* k4626 in k4468 in k4465 in k4462 in k4459 in k4456 in k4453 in k4450 in k4447 in k4444 in k4441 in k4438 in a4435 in k4410 in prototypes in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_4628(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a4608 in k4468 in k4465 in k4462 in k4459 in k4456 in k4453 in k4450 in k4447 in k4444 in k4441 in k4438 in a4435 in k4410 in prototypes in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_4609(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4609,3,t0,t1,t2);}
t3=t2;
t4=C_retrieve(lf[271]);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,t4))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4620,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_fixnum_increase(t2);
/* c-backend.scm: 519  lset-adjoin */
((C_proc5)C_retrieve_symbol_proc(lf[272]))(5,*((C_word*)lf[272]+1),t5,*((C_word*)lf[273]+1),((C_word*)((C_word*)t0)[2])[1],t6);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}}

/* k4618 in a4608 in k4468 in k4465 in k4462 in k4459 in k4456 in k4453 in k4450 in k4447 in k4444 in k4441 in k4438 in a4435 in k4410 in prototypes in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_4620(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k4471 in k4468 in k4465 in k4462 in k4459 in k4456 in k4453 in k4450 in k4447 in k4444 in k4441 in k4438 in a4435 in k4410 in prototypes in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_4473(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4473,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4476,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(C_word)C_eqp(lf[255],((C_word*)t0)[5]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4585,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[206]))){
/* c-backend.scm: 530  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[113]+1)))(4,*((C_word*)lf[113]+1),t4,C_retrieve(lf[206]),lf[262]);}
else{
t5=t4;
f_4585(2,t5,lf[263]);}}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4560,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[5],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 522  gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),t4,lf[269],((C_word*)t0)[5],lf[270],C_SCHEME_TRUE);}}

/* k4558 in k4471 in k4468 in k4465 in k4462 in k4459 in k4456 in k4453 in k4450 in k4447 in k4444 in k4441 in k4438 in a4435 in k4410 in prototypes in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_4560(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4560,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4563,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 523  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,lf[268]);}

/* k4561 in k4558 in k4471 in k4468 in k4465 in k4462 in k4459 in k4456 in k4453 in k4450 in k4447 in k4444 in k4441 in k4438 in a4435 in k4410 in prototypes in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_4563(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4563,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4566,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_truep(((C_word*)t0)[2])?lf[266]:lf[267]);
/* c-backend.scm: 524  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,t3);}

/* k4564 in k4561 in k4558 in k4471 in k4468 in k4465 in k4462 in k4459 in k4456 in k4453 in k4450 in k4447 in k4444 in k4441 in k4438 in a4435 in k4410 in prototypes in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_4566(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4566,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4569,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[2])){
/* c-backend.scm: 526  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,lf[264]);}
else{
/* c-backend.scm: 527  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,lf[265]);}}

/* k4567 in k4564 in k4561 in k4558 in k4471 in k4468 in k4465 in k4462 in k4459 in k4456 in k4453 in k4450 in k4447 in k4444 in k4441 in k4438 in a4435 in k4410 in prototypes in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_4569(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 528  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4583 in k4471 in k4468 in k4465 in k4462 in k4459 in k4456 in k4453 in k4450 in k4447 in k4444 in k4441 in k4438 in a4435 in k4410 in prototypes in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_4585(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4585,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4588,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 531  gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),t2,lf[260],t1,lf[261],C_SCHEME_TRUE);}

/* k4586 in k4583 in k4471 in k4468 in k4465 in k4462 in k4459 in k4456 in k4453 in k4450 in k4447 in k4444 in k4441 in k4438 in a4435 in k4410 in prototypes in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_4588(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4588,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4591,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve(lf[258]))){
/* c-backend.scm: 533  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t2,lf[259],C_SCHEME_TRUE);}
else{
t3=t2;
f_4591(2,t3,C_SCHEME_UNDEFINED);}}

/* k4589 in k4586 in k4583 in k4471 in k4468 in k4465 in k4462 in k4459 in k4456 in k4453 in k4450 in k4447 in k4444 in k4441 in k4438 in a4435 in k4410 in prototypes in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_4591(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4591,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4594,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 534  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,lf[257]);}

/* k4592 in k4589 in k4586 in k4583 in k4471 in k4468 in k4465 in k4462 in k4459 in k4456 in k4453 in k4450 in k4447 in k4444 in k4441 in k4438 in a4435 in k4410 in prototypes in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_4594(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 535  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),((C_word*)t0)[3],lf[256],((C_word*)t0)[2]);}

/* k4474 in k4471 in k4468 in k4465 in k4462 in k4459 in k4456 in k4453 in k4450 in k4447 in k4444 in k4441 in k4438 in a4435 in k4410 in prototypes in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_4476(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4476,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4479,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm: 536  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,C_make_character(40));}

/* k4477 in k4474 in k4471 in k4468 in k4465 in k4462 in k4459 in k4456 in k4453 in k4450 in k4447 in k4444 in k4441 in k4438 in a4435 in k4410 in prototypes in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_4479(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4479,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4482,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=t2;
f_4482(2,t3,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 537  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,lf[254]);}}

/* k4480 in k4477 in k4474 in k4471 in k4468 in k4465 in k4462 in k4459 in k4456 in k4453 in k4450 in k4447 in k4444 in k4441 in k4438 in a4435 in k4410 in prototypes in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_4482(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4482,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4485,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4532,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[3])){
t4=(C_word)C_eqp(((C_word*)t0)[2],C_fix(0));
t5=t3;
f_4532(t5,(C_word)C_i_not(t4));}
else{
t4=t3;
f_4532(t4,C_SCHEME_FALSE);}}

/* k4530 in k4480 in k4477 in k4474 in k4471 in k4468 in k4465 in k4462 in k4459 in k4456 in k4453 in k4450 in k4447 in k4444 in k4441 in k4438 in a4435 in k4410 in prototypes in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_fcall f_4532(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4532,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4535,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 539  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,lf[253]);}
else{
t2=((C_word*)t0)[2];
f_4485(2,t2,C_SCHEME_UNDEFINED);}}

/* k4533 in k4530 in k4480 in k4477 in k4474 in k4471 in k4468 in k4465 in k4462 in k4459 in k4456 in k4453 in k4450 in k4447 in k4444 in k4441 in k4438 in a4435 in k4410 in prototypes in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_4535(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
/* c-backend.scm: 540  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(44));}
else{
t2=((C_word*)t0)[2];
f_4485(2,t2,C_SCHEME_UNDEFINED);}}

/* k4483 in k4480 in k4477 in k4474 in k4471 in k4468 in k4465 in k4462 in k4459 in k4456 in k4453 in k4450 in k4447 in k4444 in k4441 in k4438 in a4435 in k4410 in prototypes in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_4485(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4485,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4488,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
C_apply(4,0,t2,C_retrieve(lf[1]),((C_word*)t0)[4]);}

/* k4486 in k4483 in k4480 in k4477 in k4474 in k4471 in k4468 in k4465 in k4462 in k4459 in k4456 in k4453 in k4450 in k4447 in k4444 in k4441 in k4438 in a4435 in k4410 in prototypes in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_4488(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4488,2,t0,t1);}
if(C_truep(((C_word*)t0)[8])){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4494,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 543  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,lf[251]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4520,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 551  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,C_make_character(41));}}

/* k4518 in k4486 in k4483 in k4480 in k4477 in k4474 in k4471 in k4468 in k4465 in k4462 in k4459 in k4456 in k4453 in k4450 in k4447 in k4444 in k4441 in k4438 in a4435 in k4410 in prototypes in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_4520(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4520,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4523,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=t2;
f_4523(2,t3,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 553  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,lf[252]);}}

/* k4521 in k4518 in k4486 in k4483 in k4480 in k4477 in k4474 in k4471 in k4468 in k4465 in k4462 in k4459 in k4456 in k4453 in k4450 in k4447 in k4444 in k4441 in k4438 in a4435 in k4410 in prototypes in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_4523(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 554  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(59));}

/* k4492 in k4486 in k4483 in k4480 in k4477 in k4474 in k4471 in k4468 in k4465 in k4462 in k4459 in k4456 in k4453 in k4450 in k4447 in k4444 in k4441 in k4438 in a4435 in k4410 in prototypes in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_4494(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4494,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[6],lf[244]);
if(C_truep(t2)){
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4503,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 546  gen */
((C_proc10)C_retrieve_symbol_proc(lf[1]))(10,*((C_word*)lf[1]+1),t3,C_SCHEME_TRUE,lf[247],((C_word*)t0)[2],lf[248],C_SCHEME_TRUE,lf[249],((C_word*)t0)[2],lf[250]);}}

/* k4501 in k4492 in k4486 in k4483 in k4480 in k4477 in k4474 in k4471 in k4468 in k4465 in k4462 in k4459 in k4456 in k4453 in k4450 in k4447 in k4444 in k4441 in k4438 in a4435 in k4410 in prototypes in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_4503(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4503,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4506,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_apply(4,0,t2,C_retrieve(lf[1]),((C_word*)t0)[2]);}

/* k4504 in k4501 in k4492 in k4486 in k4483 in k4480 in k4477 in k4474 in k4471 in k4468 in k4465 in k4462 in k4459 in k4456 in k4453 in k4450 in k4447 in k4444 in k4441 in k4438 in a4435 in k4410 in prototypes in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_4506(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* c-backend.scm: 549  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[245],t2,lf[246]);}

/* k4413 in k4410 in prototypes in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_4415(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4415,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4420,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t3=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)((C_word*)t0)[2])[1]);}

/* a4419 in k4413 in k4410 in prototypes in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_4420(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4420,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4424,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 558  gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),t3,C_SCHEME_TRUE,lf[242],t2,lf[243]);}

/* k4422 in a4419 in k4413 in k4410 in prototypes in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_4424(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4424,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4427,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4434,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 559  make-list */
((C_proc4)C_retrieve_symbol_proc(lf[240]))(4,*((C_word*)lf[240]+1),t3,((C_word*)t0)[2],lf[241]);}

/* k4432 in k4422 in a4419 in k4413 in k4410 in prototypes in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_4434(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve(lf[1]),t1);}

/* k4425 in k4422 in a4419 in k4413 in k4410 in prototypes in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_4427(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 560  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[239]);}

/* declarations in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_fcall f_4259(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4259,NULL,2,t0,t1);}
t2=(C_word)C_i_length(((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4266,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 472  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t3,C_SCHEME_TRUE,C_SCHEME_TRUE,lf[238]);}

/* k4264 in declarations in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_4266(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4266,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4269,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4402,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_retrieve(lf[208]));}

/* a4401 in k4264 in declarations in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_4402(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4402,3,t0,t1,t2);}
/* c-backend.scm: 475  gen */
((C_proc10)C_retrieve_symbol_proc(lf[1]))(10,*((C_word*)lf[1]+1),t1,C_SCHEME_TRUE,lf[234],t2,lf[235],C_SCHEME_TRUE,lf[236],t2,lf[237]);}

/* k4267 in k4264 in declarations in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_4269(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4269,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4272,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[2],C_fix(0));
if(C_truep(t3)){
t4=t2;
f_4272(2,t4,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 479  gen */
((C_proc7)C_retrieve_symbol_proc(lf[1]))(7,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,C_SCHEME_TRUE,lf[232],((C_word*)t0)[2],lf[233]);}}

/* k4270 in k4267 in k4264 in declarations in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_4272(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4272,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4275,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 480  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[231]);}

/* k4273 in k4270 in k4267 in k4264 in declarations in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_4275(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4275,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4280,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_4280(t5,((C_word*)t0)[3],C_fix(0),((C_word*)t0)[2]);}

/* doloop582 in k4273 in k4270 in k4267 in k4264 in declarations in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_fcall f_4280(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4280,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4290,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(t3);
/* c-backend.scm: 484  ##sys#lambda-info->string */
((C_proc3)C_retrieve_symbol_proc(lf[230]))(3,*((C_word*)lf[230]+1),t4,t5);}}

/* k4288 in doloop582 in k4273 in k4270 in k4267 in k4264 in declarations in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_4290(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4290,2,t0,t1);}
t2=(C_word)C_i_string_length(t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4296,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t4=(C_word)C_fixnum_shift_right(t2,C_fix(16));
t5=(C_word)C_fixnum_shift_right(t2,C_fix(8));
t6=(C_word)C_fixnum_and(C_fix(255),t5);
t7=(C_word)C_fixnum_and(C_fix(255),t2);
/* c-backend.scm: 486  gen */
((C_proc12)C_retrieve_symbol_proc(lf[1]))(12,*((C_word*)lf[1]+1),t3,C_SCHEME_TRUE,lf[228],((C_word*)t0)[5],lf[229],t4,C_make_character(44),t6,C_make_character(44),t7,C_make_character(41));}

/* k4294 in k4288 in doloop582 in k4273 in k4270 in k4267 in k4264 in declarations in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_4296(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4296,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4299,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4349,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_4349(t6,t2,C_fix(0));}

/* doloop598 in k4294 in k4288 in doloop582 in k4273 in k4270 in k4267 in k4264 in declarations in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_fcall f_4349(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4349,NULL,3,t0,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[4]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4359,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_string_ref(((C_word*)t0)[2],t2);
t6=(C_word)C_fix((C_word)C_character_code(t5));
/* c-backend.scm: 493  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t4,C_make_character(44),t6);}}

/* k4357 in doloop598 in k4294 in k4288 in doloop582 in k4273 in k4270 in k4267 in k4264 in declarations in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_4359(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_increase(((C_word*)t0)[4]);
t3=((C_word*)((C_word*)t0)[3])[1];
f_4349(t3,((C_word*)t0)[2],t2);}

/* k4297 in k4294 in k4288 in doloop582 in k4273 in k4270 in k4267 in k4264 in declarations in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_4299(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4299,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4302,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[2],C_fix(7));
t4=(C_word)C_fixnum_and(C_fix(16777208),t3);
t5=(C_word)C_fixnum_difference(t4,((C_word*)t0)[2]);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4322,a[2]=t7,tmp=(C_word)a,a+=3,tmp));
t9=((C_word*)t7)[1];
f_4322(t9,t2,t5);}

/* doloop610 in k4297 in k4294 in k4288 in doloop582 in k4273 in k4270 in k4267 in k4264 in declarations in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_fcall f_4322(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4322,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4332,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 496  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t4,lf[227]);}}

/* k4330 in doloop610 in k4297 in k4294 in k4288 in doloop582 in k4273 in k4270 in k4267 in k4264 in declarations in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_4332(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_decrease(((C_word*)t0)[4]);
t3=((C_word*)((C_word*)t0)[3])[1];
f_4322(t3,((C_word*)t0)[2],t2);}

/* k4300 in k4297 in k4294 in k4288 in doloop582 in k4273 in k4270 in k4267 in k4264 in declarations in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_4302(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4302,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4305,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 497  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,lf[226]);}

/* k4303 in k4300 in k4297 in k4294 in k4288 in doloop582 in k4273 in k4270 in k4267 in k4264 in declarations in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_4305(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_fixnum_increase(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
t4=((C_word*)((C_word*)t0)[3])[1];
f_4280(t4,((C_word*)t0)[2],t2,t3);}

/* header in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_fcall f_4112(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4112,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4115,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4132,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4251,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 438  current-seconds */
((C_proc2)C_retrieve_symbol_proc(lf[225]))(2,*((C_word*)lf[225]+1),t4);}

/* k4249 in header in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_4251(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 438  ##sys#decode-seconds */
((C_proc4)C_retrieve_symbol_proc(lf[224]))(4,*((C_word*)lf[224]+1),((C_word*)t0)[2],t1,C_SCHEME_FALSE);}

/* k4130 in header in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_4132(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4132,2,t0,t1);}
t2=(C_word)C_i_vector_ref(t1,C_fix(1));
t3=(C_word)C_i_vector_ref(t1,C_fix(2));
t4=(C_word)C_i_vector_ref(t1,C_fix(3));
t5=(C_word)C_i_vector_ref(t1,C_fix(4));
t6=(C_word)C_i_vector_ref(t1,C_fix(5));
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4150,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_fixnum_plus(C_fix(1900),t6);
t9=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4209,a[2]=t4,a[3]=t3,a[4]=t2,a[5]=((C_word*)t0)[2],a[6]=t8,a[7]=((C_word*)t0)[3],a[8]=t7,tmp=(C_word)a,a+=9,tmp);
t10=(C_word)C_fixnum_increase(t5);
/* c-backend.scm: 446  pad0 */
f_4115(t9,t10);}

/* k4207 in k4130 in header in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_4209(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4209,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4213,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 446  pad0 */
f_4115(t2,((C_word*)t0)[2]);}

/* k4211 in k4207 in k4130 in header in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_4213(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4213,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4217,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 446  pad0 */
f_4115(t2,((C_word*)t0)[2]);}

/* k4215 in k4211 in k4207 in k4130 in header in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_4217(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4217,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4221,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 446  pad0 */
f_4115(t2,((C_word*)t0)[2]);}

/* k4219 in k4215 in k4211 in k4207 in k4130 in header in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_4221(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4221,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4225,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4229,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4231,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4239,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4243,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 449  chicken-version */
((C_proc3)C_retrieve_symbol_proc(lf[223]))(3,*((C_word*)lf[223]+1),t6,C_SCHEME_TRUE);}

/* k4241 in k4219 in k4215 in k4211 in k4207 in k4130 in header in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_4243(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 449  string-split */
((C_proc4)C_retrieve_symbol_proc(lf[221]))(4,*((C_word*)lf[221]+1),((C_word*)t0)[2],t1,lf[222]);}

/* k4237 in k4219 in k4215 in k4211 in k4207 in k4130 in header in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_4239(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[220]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a4230 in k4219 in k4215 in k4211 in k4207 in k4130 in header in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_4231(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4231,3,t0,t1,t2);}
/* string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[113]+1)))(5,*((C_word*)lf[113]+1),t1,lf[218],t2,lf[219]);}

/* k4227 in k4219 in k4215 in k4211 in k4207 in k4130 in header in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_4229(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 447  string-intersperse */
((C_proc4)C_retrieve_symbol_proc(lf[216]))(4,*((C_word*)lf[216]+1),((C_word*)t0)[2],t1,lf[217]);}

/* k4223 in k4219 in k4215 in k4211 in k4207 in k4130 in header in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_4225(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 444  gen */
((C_proc21)C_retrieve_symbol_proc(lf[1]))(21,*((C_word*)lf[1]+1),((C_word*)t0)[8],lf[211],((C_word*)t0)[7],lf[212],C_SCHEME_TRUE,lf[213],C_SCHEME_TRUE,lf[214],((C_word*)t0)[6],C_make_character(45),((C_word*)t0)[5],C_make_character(45),((C_word*)t0)[4],C_make_character(32),((C_word*)t0)[3],C_make_character(58),((C_word*)t0)[2],C_SCHEME_TRUE,t1,lf[215]);}

/* k4148 in k4130 in header in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_4150(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4150,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4153,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 452  gen-list */
((C_proc3)C_retrieve_symbol_proc(lf[5]))(3,*((C_word*)lf[5]+1),t2,C_retrieve(lf[210]));}

/* k4151 in k4148 in k4130 in header in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_4153(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4153,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4156,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 453  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE);}

/* k4154 in k4151 in k4148 in k4130 in header in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_4156(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4156,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4159,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[206]))){
/* c-backend.scm: 454  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t2,lf[207],C_retrieve(lf[206]));}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4198,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 456  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t3,lf[209]);}}

/* k4196 in k4154 in k4151 in k4148 in k4130 in header in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_4198(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 457  gen-list */
((C_proc3)C_retrieve_symbol_proc(lf[5]))(3,*((C_word*)lf[5]+1),((C_word*)t0)[2],C_retrieve(lf[208]));}

/* k4157 in k4154 in k4151 in k4148 in k4130 in header in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_4159(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4159,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4162,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 458  gen */
((C_proc9)C_retrieve_symbol_proc(lf[1]))(9,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[202],C_SCHEME_TRUE,C_SCHEME_TRUE,lf[203],C_retrieve(lf[204]),lf[205]);}

/* k4160 in k4157 in k4154 in k4151 in k4148 in k4130 in header in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_4162(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4162,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4165,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[198]))){
/* c-backend.scm: 460  generate-foreign-callback-stub-prototypes */
((C_proc3)C_retrieve_symbol_proc(lf[199]))(3,*((C_word*)lf[199]+1),t2,C_retrieve(lf[200]));}
else{
t3=t2;
f_4165(2,t3,C_SCHEME_UNDEFINED);}}

/* k4163 in k4160 in k4157 in k4154 in k4151 in k4148 in k4130 in header in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_4165(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4165,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4168,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(C_retrieve(lf[201])))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4180,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 462  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t3,C_SCHEME_TRUE);}
else{
t3=t2;
f_4168(2,t3,C_SCHEME_UNDEFINED);}}

/* k4178 in k4163 in k4160 in k4157 in k4154 in k4151 in k4148 in k4130 in header in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_4180(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4180,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4185,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t3=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t2,C_retrieve(lf[201]));}

/* a4184 in k4178 in k4163 in k4160 in k4157 in k4154 in k4151 in k4148 in k4130 in header in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_4185(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4185,3,t0,t1,t2);}
/* c-backend.scm: 463  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t1,C_SCHEME_TRUE,t2);}

/* k4166 in k4163 in k4160 in k4157 in k4154 in k4151 in k4148 in k4130 in header in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_4168(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(C_retrieve(lf[198]))){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 465  generate-foreign-callback-stub-prototypes */
((C_proc3)C_retrieve_symbol_proc(lf[199]))(3,*((C_word*)lf[199]+1),((C_word*)t0)[2],C_retrieve(lf[200]));}}

/* pad0 in header in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_fcall f_4115(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4115,NULL,2,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_lessp(t3,C_fix(10)))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4129,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 436  number->string */
C_number_to_string(3,0,t4,t2);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}}

/* k4127 in pad0 in header in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_4129(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 436  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[113]+1)))(4,*((C_word*)lf[113]+1),((C_word*)t0)[2],lf[197],t1);}

/* expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_fcall f_2539(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2539,NULL,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2542,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t8,a[5]=((C_word*)t0)[3],a[6]=t6,tmp=(C_word)a,a+=7,tmp));
t10=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4080,a[2]=t6,tmp=(C_word)a,a+=3,tmp));
/* c-backend.scm: 431  expr */
t11=((C_word*)t6)[1];
f_2542(t11,t1,t2,t3);}

/* expr-args in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_fcall f_4080(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4080,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4086,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 425  pair-for-each */
((C_proc4)C_retrieve_symbol_proc(lf[196]))(4,*((C_word*)lf[196]+1),t1,t4,t2);}

/* a4085 in expr-args in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_4086(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4086,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4090,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_eqp(t2,((C_word*)t0)[2]);
if(C_truep(t4)){
t5=t3;
f_4090(2,t5,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 427  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t3,C_make_character(44));}}

/* k4088 in a4085 in expr-args in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_4090(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(((C_word*)t0)[5]);
/* c-backend.scm: 428  expr */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2542(t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_fcall f_2542(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word t98;
C_word t99;
C_word t100;
C_word t101;
C_word t102;
C_word t103;
C_word t104;
C_word t105;
C_word t106;
C_word t107;
C_word t108;
C_word t109;
C_word t110;
C_word t111;
C_word t112;
C_word t113;
C_word t114;
C_word t115;
C_word t116;
C_word t117;
C_word t118;
C_word t119;
C_word t120;
C_word t121;
C_word t122;
C_word t123;
C_word t124;
C_word t125;
C_word t126;
C_word t127;
C_word t128;
C_word t129;
C_word t130;
C_word t131;
C_word t132;
C_word t133;
C_word t134;
C_word t135;
C_word t136;
C_word t137;
C_word t138;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2542,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_slot(t4,C_fix(3));
t6=t2;
t7=(C_word)C_slot(t6,C_fix(2));
t8=t2;
t9=(C_word)C_slot(t8,C_fix(1));
t10=(C_word)C_eqp(t9,lf[16]);
if(C_truep(t10)){
t11=(C_word)C_i_car(t7);
t12=(C_word)C_eqp(t11,lf[17]);
if(C_truep(t12)){
t13=(C_word)C_i_cadr(t7);
t14=(C_truep(t13)?lf[18]:lf[19]);
/* c-backend.scm: 84   gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t1,t14);}
else{
t13=(C_word)C_eqp(t11,lf[20]);
if(C_truep(t13)){
t14=(C_word)C_i_cadr(t7);
t15=(C_word)C_fix((C_word)C_character_code(t14));
/* c-backend.scm: 85   gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t1,lf[21],t15,C_make_character(41));}
else{
t14=(C_word)C_eqp(t11,lf[22]);
if(C_truep(t14)){
/* c-backend.scm: 86   gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t1,lf[23]);}
else{
t15=(C_word)C_eqp(t11,lf[24]);
if(C_truep(t15)){
t16=(C_word)C_i_cadr(t7);
/* c-backend.scm: 87   gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t1,lf[25],t16,C_make_character(41));}
else{
t16=(C_word)C_eqp(t11,lf[26]);
if(C_truep(t16)){
/* c-backend.scm: 88   gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t1,lf[27]);}
else{
/* c-backend.scm: 89   bomb */
((C_proc3)C_retrieve_symbol_proc(lf[9]))(3,*((C_word*)lf[9]+1),t1,lf[28]);}}}}}}
else{
t11=(C_word)C_eqp(t9,lf[29]);
if(C_truep(t11)){
t12=(C_word)C_i_car(t7);
if(C_truep((C_word)C_i_vectorp(t12))){
t13=(C_word)C_i_vector_ref(t12,C_fix(0));
/* c-backend.scm: 94   gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t1,lf[30],t13,lf[31]);}
else{
t13=(C_word)C_i_car(t7);
/* c-backend.scm: 95   gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t1,lf[32],t13,C_make_character(93));}}
else{
t12=(C_word)C_eqp(t9,lf[33]);
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2666,a[2]=t3,a[3]=((C_word*)t0)[6],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 98   gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t13,C_SCHEME_TRUE,lf[36]);}
else{
t13=(C_word)C_eqp(t9,lf[37]);
if(C_truep(t13)){
t14=(C_word)C_i_car(t7);
/* c-backend.scm: 107  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t1,lf[38],t14);}
else{
t14=(C_word)C_eqp(t9,lf[39]);
if(C_truep(t14)){
t15=(C_word)C_i_car(t7);
t16=C_SCHEME_UNDEFINED;
t17=(*a=C_VECTOR_TYPE|1,a[1]=t16,tmp=(C_word)a,a+=2,tmp);
t18=C_set_block_item(t17,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2724,a[2]=((C_word*)t0)[6],a[3]=t17,tmp=(C_word)a,a+=4,tmp));
t19=((C_word*)t17)[1];
f_2724(t19,t1,t5,t3,t15);}
else{
t15=(C_word)C_eqp(t9,lf[40]);
if(C_truep(t15)){
t16=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2775,a[2]=t3,a[3]=((C_word*)t0)[6],a[4]=t5,a[5]=t1,a[6]=t7,tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 119  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t16,lf[42]);}
else{
t16=(C_word)C_eqp(t9,lf[43]);
if(C_truep(t16)){
t17=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2802,a[2]=t3,a[3]=((C_word*)t0)[6],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 124  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t17,lf[45]);}
else{
t17=(C_word)C_eqp(t9,lf[46]);
if(C_truep(t17)){
t18=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2821,a[2]=t7,a[3]=t3,a[4]=((C_word*)t0)[6],a[5]=t5,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 129  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t18,lf[47]);}
else{
t18=(C_word)C_eqp(t9,lf[48]);
if(C_truep(t18)){
t19=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2854,a[2]=t7,a[3]=t3,a[4]=((C_word*)t0)[6],a[5]=t5,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 136  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t19,lf[51]);}
else{
t19=(C_word)C_eqp(t9,lf[52]);
if(C_truep(t19)){
t20=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2891,a[2]=t3,a[3]=((C_word*)t0)[6],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 143  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t20,lf[54]);}
else{
t20=(C_word)C_eqp(t9,lf[55]);
if(C_truep(t20)){
t21=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2920,a[2]=t3,a[3]=((C_word*)t0)[6],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 150  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t21,lf[57]);}
else{
t21=(C_word)C_eqp(t9,lf[58]);
if(C_truep(t21)){
t22=(C_word)C_i_car(t7);
t23=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2952,a[2]=t5,a[3]=t3,a[4]=((C_word*)t0)[6],a[5]=t1,a[6]=t22,tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 158  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t23,lf[65],t22,C_make_character(44));}
else{
t22=(C_word)C_eqp(t9,lf[66]);
if(C_truep(t22)){
t23=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2987,a[2]=t3,a[3]=((C_word*)t0)[6],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 168  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t23,lf[68]);}
else{
t23=(C_word)C_eqp(t9,lf[69]);
if(C_truep(t23)){
t24=(C_word)C_i_car(t7);
/* c-backend.scm: 172  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t1,C_make_character(116),t24);}
else{
t24=(C_word)C_eqp(t9,lf[70]);
if(C_truep(t24)){
t25=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3019,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[6],a[5]=t5,tmp=(C_word)a,a+=6,tmp);
t26=(C_word)C_i_car(t7);
/* c-backend.scm: 175  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t25,C_make_character(116),t26,C_make_character(61));}
else{
t25=(C_word)C_eqp(t9,lf[71]);
if(C_truep(t25)){
t26=(C_word)C_i_car(t7);
t27=(C_word)C_i_cadr(t7);
if(C_truep((C_word)C_i_caddr(t7))){
if(C_truep(t27)){
/* c-backend.scm: 184  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t1,lf[72],t26,lf[73]);}
else{
t28=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3061,a[2]=t26,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t29=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3065,a[2]=t28,tmp=(C_word)a,a+=3,tmp);
t30=(C_word)C_i_cadddr(t7);
/* c-backend.scm: 185  symbol->string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[77]+1)))(3,*((C_word*)lf[77]+1),t29,t30);}}
else{
if(C_truep(t27)){
/* c-backend.scm: 186  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t1,lf[78],t26,lf[79]);}
else{
/* c-backend.scm: 187  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t1,lf[80],t26,lf[81]);}}}
else{
t26=(C_word)C_eqp(t9,lf[82]);
if(C_truep(t26)){
t27=(C_word)C_i_car(t7);
t28=(C_word)C_i_cadr(t7);
t29=(C_word)C_i_caddr(t7);
t30=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3096,a[2]=t29,a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=((C_word*)t0)[6],a[6]=t5,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
if(C_truep(t28)){
/* c-backend.scm: 194  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t30,lf[85],t27,lf[86]);}
else{
/* c-backend.scm: 195  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t30,lf[87],t27,lf[88]);}}
else{
t27=(C_word)C_eqp(t9,lf[89]);
if(C_truep(t27)){
t28=(C_word)C_i_car(t7);
t29=(C_word)C_i_cadr(t7);
t30=(C_word)C_i_caddr(t7);
if(C_truep(t29)){
t31=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3144,a[2]=t3,a[3]=((C_word*)t0)[6],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t32=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3158,a[2]=t28,a[3]=t31,tmp=(C_word)a,a+=4,tmp);
t33=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3162,a[2]=t32,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 206  symbol->string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[77]+1)))(3,*((C_word*)lf[77]+1),t33,t30);}
else{
t31=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3165,a[2]=t3,a[3]=((C_word*)t0)[6],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t32=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3179,a[2]=t28,a[3]=t31,tmp=(C_word)a,a+=4,tmp);
t33=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3183,a[2]=t32,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 211  symbol->string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[77]+1)))(3,*((C_word*)lf[77]+1),t33,t30);}}
else{
t28=(C_word)C_eqp(t9,lf[96]);
if(C_truep(t28)){
/* c-backend.scm: 215  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t1,lf[97]);}
else{
t29=(C_word)C_eqp(t9,lf[98]);
if(C_truep(t29)){
t30=(C_word)C_i_cdr(t5);
t31=(C_word)C_i_length(t30);
t32=t3;
t33=(C_word)C_fixnum_increase(t31);
t34=(C_word)C_i_cdr(t7);
t35=(C_word)C_i_pairp(t34);
t36=(C_truep(t35)?(C_word)C_i_cadr(t7):C_SCHEME_FALSE);
t37=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_3216,a[2]=t35,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[5],a[5]=t36,a[6]=t32,a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[6],a[9]=t31,a[10]=t33,a[11]=t3,a[12]=t30,a[13]=((C_word*)t0)[4],a[14]=t1,a[15]=t5,a[16]=t7,tmp=(C_word)a,a+=17,tmp);
/* c-backend.scm: 224  source-info->string */
((C_proc3)C_retrieve_symbol_proc(lf[146]))(3,*((C_word*)lf[146]+1),t37,t36);}
else{
t30=(C_word)C_eqp(t9,lf[147]);
if(C_truep(t30)){
t31=(C_word)C_i_length(t5);
t32=(C_word)C_fixnum_increase(t31);
t33=(C_word)C_i_car(t7);
t34=(C_word)C_i_cadr(t7);
t35=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3640,a[2]=t34,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],a[5]=t32,a[6]=t5,a[7]=t3,a[8]=((C_word*)t0)[6],a[9]=t31,a[10]=t1,a[11]=t33,tmp=(C_word)a,a+=12,tmp);
/* c-backend.scm: 308  lambda-literal-closure-size */
((C_proc3)C_retrieve_symbol_proc(lf[145]))(3,*((C_word*)lf[145]+1),t35,((C_word*)t0)[3]);}
else{
t31=(C_word)C_eqp(t9,lf[151]);
if(C_truep(t31)){
t32=(C_word)C_i_cdr(t5);
t33=(C_word)C_i_length(t32);
t34=(C_word)C_fixnum_increase(t33);
t35=(C_word)C_i_caddr(t7);
t36=(C_word)C_i_cadddr(t7);
t37=(C_word)C_eqp(t36,C_fix(0));
t38=(C_word)C_i_not(t37);
t39=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3725,a[2]=t35,a[3]=t36,a[4]=t38,a[5]=((C_word*)t0)[6],a[6]=t3,a[7]=((C_word*)t0)[4],a[8]=t32,a[9]=t1,a[10]=t5,tmp=(C_word)a,a+=11,tmp);
t40=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3729,a[2]=t39,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 336  find-lambda */
t41=((C_word*)t0)[2];
f_2497(t41,t40,t35);}
else{
t32=(C_word)C_eqp(t9,lf[153]);
if(C_truep(t32)){
t33=(C_word)C_i_length(t5);
t34=(C_word)C_fixnum_plus(t33,C_fix(1));
t35=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3748,a[2]=t3,a[3]=t5,a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t36=(C_word)C_i_car(t7);
/* c-backend.scm: 353  gen */
((C_proc8)C_retrieve_symbol_proc(lf[1]))(8,*((C_word*)lf[1]+1),t35,C_SCHEME_TRUE,lf[155],t36,lf[156],t34,lf[157]);}
else{
t33=(C_word)C_eqp(t9,lf[158]);
if(C_truep(t33)){
t34=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3767,a[2]=t3,a[3]=((C_word*)t0)[6],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 358  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t34,C_SCHEME_TRUE,lf[160]);}
else{
t34=(C_word)C_eqp(t9,lf[161]);
if(C_truep(t34)){
t35=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3786,a[2]=t3,a[3]=t5,a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t36=(C_word)C_i_car(t7);
/* c-backend.scm: 363  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t35,lf[162],t36,C_make_character(40));}
else{
t35=(C_word)C_eqp(t9,lf[163]);
if(C_truep(t35)){
t36=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3805,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t37=(C_word)C_i_car(t7);
t38=(C_word)C_i_length(t5);
/* c-backend.scm: 368  gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),t36,lf[164],t37,lf[165],t38);}
else{
t36=(C_word)C_eqp(t9,lf[166]);
if(C_truep(t36)){
t37=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3841,a[2]=t1,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
t38=(C_word)C_i_cadr(t7);
/* c-backend.scm: 376  foreign-result-conversion */
((C_proc4)C_retrieve_symbol_proc(lf[167]))(4,*((C_word*)lf[167]+1),t37,t38,lf[168]);}
else{
t37=(C_word)C_eqp(t9,lf[169]);
if(C_truep(t37)){
t38=(C_word)C_i_cadr(t7);
t39=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3861,a[2]=t3,a[3]=((C_word*)t0)[6],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t40=(C_word)C_i_car(t7);
t41=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3879,a[2]=t38,a[3]=t40,a[4]=t39,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 380  foreign-type-declaration */
((C_proc4)C_retrieve_symbol_proc(lf[173]))(4,*((C_word*)lf[173]+1),t41,t38,lf[174]);}
else{
t38=(C_word)C_eqp(t9,lf[175]);
if(C_truep(t38)){
t39=(C_word)C_i_car(t7);
t40=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3895,a[2]=t3,a[3]=((C_word*)t0)[6],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t41=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3909,a[2]=t39,a[3]=t40,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 386  foreign-result-conversion */
((C_proc4)C_retrieve_symbol_proc(lf[167]))(4,*((C_word*)lf[167]+1),t41,t39,lf[180]);}
else{
t39=(C_word)C_eqp(t9,lf[181]);
if(C_truep(t39)){
t40=(C_word)C_i_car(t7);
t41=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3925,a[2]=t40,a[3]=t3,a[4]=((C_word*)t0)[6],a[5]=t5,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t42=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3953,a[2]=t41,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 392  foreign-type-declaration */
((C_proc4)C_retrieve_symbol_proc(lf[173]))(4,*((C_word*)lf[173]+1),t42,t40,lf[186]);}
else{
t40=(C_word)C_eqp(t9,lf[187]);
if(C_truep(t40)){
t41=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3962,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[6],a[5]=t5,a[6]=t7,tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 399  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t41,C_SCHEME_TRUE,lf[191]);}
else{
t41=(C_word)C_eqp(t9,lf[192]);
if(C_truep(t41)){
t42=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4045,a[2]=t3,a[3]=((C_word*)t0)[6],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 414  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t42,lf[194]);}
else{
/* c-backend.scm: 422  bomb */
((C_proc3)C_retrieve_symbol_proc(lf[9]))(3,*((C_word*)lf[9]+1),t1,lf[195]);}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}

/* k4043 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_4045(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4045,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4048,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 415  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2542(t4,t2,t3,((C_word*)t0)[2]);}

/* k4046 in k4043 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_4048(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4048,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4051,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 416  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,lf[193]);}

/* k4049 in k4046 in k4043 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_4051(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4051,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4054,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 417  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2542(t4,t2,t3,((C_word*)t0)[2]);}

/* k4052 in k4049 in k4046 in k4043 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_4054(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4054,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4057,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 418  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,C_make_character(58));}

/* k4055 in k4052 in k4049 in k4046 in k4043 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_4057(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4057,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4060,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_caddr(((C_word*)t0)[4]);
/* c-backend.scm: 419  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2542(t4,t2,t3,((C_word*)t0)[2]);}

/* k4058 in k4055 in k4052 in k4049 in k4046 in k4043 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_4060(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 420  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(41));}

/* k3960 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_3962(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3962,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3965,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[5]);
/* c-backend.scm: 400  expr */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2542(t4,t2,t3,((C_word*)t0)[3]);}

/* k3963 in k3960 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_3965(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3965,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3968,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 401  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,lf[190]);}

/* k3966 in k3963 in k3960 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_3968(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3968,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3981,a[2]=t5,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_3981(t7,((C_word*)t0)[2],t2,t3);}

/* doloop487 in k3966 in k3963 in k3960 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_fcall f_3981(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3981,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3991,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 405  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t5,C_SCHEME_TRUE,lf[188]);}
else{
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4004,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 408  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t5,C_SCHEME_TRUE,lf[189]);}}

/* k4002 in doloop487 in k3966 in k3963 in k3960 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_4004(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4004,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4007,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[6]);
/* c-backend.scm: 409  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2542(t4,t2,t3,((C_word*)t0)[2]);}

/* k4005 in k4002 in doloop487 in k3966 in k3963 in k3960 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_4007(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4007,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4010,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 410  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,C_make_character(58));}

/* k4008 in k4005 in k4002 in doloop487 in k3966 in k3963 in k3960 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_4010(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4010,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4013,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[6]);
/* c-backend.scm: 411  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2542(t4,t2,t3,((C_word*)t0)[2]);}

/* k4011 in k4008 in k4005 in k4002 in doloop487 in k3966 in k3963 in k3960 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_4013(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_fixnum_decrease(((C_word*)t0)[5]);
t3=(C_word)C_i_cddr(((C_word*)t0)[4]);
t4=((C_word*)((C_word*)t0)[3])[1];
f_3981(t4,((C_word*)t0)[2],t2,t3);}

/* k3989 in doloop487 in k3966 in k3963 in k3960 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_3991(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3991,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3994,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 406  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2542(t4,t2,t3,((C_word*)t0)[2]);}

/* k3992 in k3989 in doloop487 in k3966 in k3963 in k3960 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_3994(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 407  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(125));}

/* k3951 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_3953(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 392  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[184],t1,lf[185]);}

/* k3923 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_3925(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3925,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3928,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[5]);
/* c-backend.scm: 393  expr */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2542(t4,t2,t3,((C_word*)t0)[3]);}

/* k3926 in k3923 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_3928(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3928,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3931,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3945,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 394  foreign-argument-conversion */
((C_proc3)C_retrieve_symbol_proc(lf[172]))(3,*((C_word*)lf[172]+1),t3,((C_word*)t0)[2]);}

/* k3943 in k3926 in k3923 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_3945(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 394  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[183],t1);}

/* k3929 in k3926 in k3923 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_3931(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3931,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3934,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 395  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2542(t4,t2,t3,((C_word*)t0)[2]);}

/* k3932 in k3929 in k3926 in k3923 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_3934(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 396  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[182]);}

/* k3907 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_3909(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3909,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3913,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 386  foreign-type-declaration */
((C_proc4)C_retrieve_symbol_proc(lf[173]))(4,*((C_word*)lf[173]+1),t2,((C_word*)t0)[2],lf[179]);}

/* k3911 in k3907 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_3913(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 386  gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),((C_word*)t0)[3],((C_word*)t0)[2],lf[177],t1,lf[178]);}

/* k3893 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_3895(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3895,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3898,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 387  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2542(t4,t2,t3,((C_word*)t0)[2]);}

/* k3896 in k3893 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_3898(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 388  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[176]);}

/* k3877 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_3879(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3879,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3883,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 380  foreign-argument-conversion */
((C_proc3)C_retrieve_symbol_proc(lf[172]))(3,*((C_word*)lf[172]+1),t2,((C_word*)t0)[2]);}

/* k3881 in k3877 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_3883(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 380  gen */
((C_proc8)C_retrieve_symbol_proc(lf[1]))(8,*((C_word*)lf[1]+1),((C_word*)t0)[4],C_make_character(40),((C_word*)t0)[3],lf[171],((C_word*)t0)[2],C_make_character(41),t1);}

/* k3859 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_3861(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3861,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3864,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 381  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2542(t4,t2,t3,((C_word*)t0)[2]);}

/* k3862 in k3859 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_3864(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 382  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[170]);}

/* k3839 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_3841(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(((C_word*)t0)[3]);
/* c-backend.scm: 376  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),((C_word*)t0)[2],t1,t2,C_make_character(41));}

/* k3803 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_3805(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3805,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3808,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3817,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 371  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t3,C_make_character(44));}
else{
t3=t2;
f_3808(2,t3,C_SCHEME_UNDEFINED);}}

/* k3815 in k3803 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_3817(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 372  expr-args */
t2=((C_word*)((C_word*)t0)[5])[1];
f_4080(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3806 in k3803 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_3808(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 373  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(41));}

/* k3784 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_3786(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3786,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3789,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 364  expr-args */
t3=((C_word*)((C_word*)t0)[4])[1];
f_4080(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3787 in k3784 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_3789(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 365  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(41));}

/* k3765 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_3767(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3767,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3770,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 359  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2542(t4,t2,t3,((C_word*)t0)[2]);}

/* k3768 in k3765 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_3770(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 360  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[159]);}

/* k3746 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_3748(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3748,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3751,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 354  expr-args */
t3=((C_word*)((C_word*)t0)[4])[1];
f_4080(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3749 in k3746 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_3751(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 355  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[154]);}

/* k3727 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_3729(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 336  lambda-literal-closure-size */
((C_proc3)C_retrieve_symbol_proc(lf[145]))(3,*((C_word*)lf[145]+1),((C_word*)t0)[2],t1);}

/* k3723 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_3725(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3725,2,t0,t1);}
t2=(C_word)C_eqp(t1,C_fix(0));
t3=(C_word)C_i_car(((C_word*)t0)[10]);
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3673,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm: 338  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t4,((C_word*)t0)[2],C_make_character(40));}

/* k3671 in k3723 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_3673(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3673,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3676,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3706,a[2]=t2,a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 340  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t3,lf[152],((C_word*)t0)[2],C_make_character(41));}
else{
t3=t2;
f_3676(2,t3,C_SCHEME_UNDEFINED);}}

/* k3704 in k3671 in k3723 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_3706(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_not(((C_word*)t0)[4]);
t3=(C_truep(t2)?t2:(C_word)C_i_pairp(((C_word*)t0)[3]));
if(C_truep(t3)){
/* c-backend.scm: 341  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(44));}
else{
t4=((C_word*)t0)[2];
f_3676(2,t4,C_SCHEME_UNDEFINED);}}

/* k3674 in k3671 in k3723 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_3676(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3676,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3679,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[4])){
t3=t2;
f_3679(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3694,a[2]=t2,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 343  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2542(t4,t3,((C_word*)t0)[2],((C_word*)t0)[5]);}}

/* k3692 in k3674 in k3671 in k3723 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_3694(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
/* c-backend.scm: 344  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(44));}
else{
t2=((C_word*)t0)[2];
f_3679(2,t2,C_SCHEME_UNDEFINED);}}

/* k3677 in k3674 in k3671 in k3723 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_3679(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3679,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3682,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
/* c-backend.scm: 345  expr-args */
t3=((C_word*)((C_word*)t0)[3])[1];
f_4080(t3,t2,((C_word*)t0)[4],((C_word*)t0)[2]);}
else{
t3=t2;
f_3682(2,t3,C_SCHEME_UNDEFINED);}}

/* k3680 in k3677 in k3674 in k3671 in k3723 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_3682(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 346  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(41));}

/* k3638 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_3640(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3640,2,t0,t1);}
t2=(C_word)C_eqp(t1,C_fix(0));
if(C_truep(((C_word*)t0)[11])){
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3583,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 310  lambda-literal-temporaries */
((C_proc3)C_retrieve_symbol_proc(lf[104]))(3,*((C_word*)lf[104]+1),t3,((C_word*)t0)[4]);}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3624,a[2]=t2,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 323  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t3,((C_word*)t0)[2],C_make_character(40));}}

/* k3622 in k3638 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_3624(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3624,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3627,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=t2;
f_3627(2,t3,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 324  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,lf[150]);}}

/* k3625 in k3622 in k3638 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_3627(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3627,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3630,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 325  expr-args */
t3=((C_word*)((C_word*)t0)[4])[1];
f_4080(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3628 in k3625 in k3622 in k3638 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_3630(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 326  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(41));}

/* k3581 in k3638 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_3583(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3583,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3586,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_fixnum_plus(t1,((C_word*)t0)[2]);
/* c-backend.scm: 311  iota */
((C_proc5)C_retrieve_symbol_proc(lf[64]))(5,*((C_word*)lf[64]+1),t2,((C_word*)t0)[6],t3,C_fix(1));}

/* k3584 in k3581 in k3638 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_3586(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3586,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3589,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3607,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 312  for-each */
((C_proc5)C_retrieve_proc(*((C_word*)lf[63]+1)))(5,*((C_word*)lf[63]+1),t2,t3,((C_word*)t0)[2],t1);}

/* a3606 in k3584 in k3581 in k3638 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_3607(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3607,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3611,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 314  gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),t4,C_SCHEME_TRUE,C_make_character(116),t3,C_make_character(61));}

/* k3609 in a3606 in k3584 in k3581 in k3638 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_3611(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3611,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3614,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 315  expr */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2542(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3612 in k3609 in a3606 in k3584 in k3581 in k3638 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_3614(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 316  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(59));}

/* k3587 in k3584 in k3581 in k3638 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_3589(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3589,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3592,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3597,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3605,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 320  iota */
((C_proc5)C_retrieve_symbol_proc(lf[64]))(5,*((C_word*)lf[64]+1),t4,((C_word*)t0)[2],C_fix(1),C_fix(1));}

/* k3603 in k3587 in k3584 in k3581 in k3638 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_3605(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 318  for-each */
((C_proc5)C_retrieve_proc(*((C_word*)lf[63]+1)))(5,*((C_word*)lf[63]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a3596 in k3587 in k3584 in k3581 in k3638 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_3597(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3597,4,t0,t1,t2,t3);}
/* c-backend.scm: 319  gen */
((C_proc8)C_retrieve_symbol_proc(lf[1]))(8,*((C_word*)lf[1]+1),t1,C_SCHEME_TRUE,C_make_character(116),t3,lf[149],t2,C_make_character(59));}

/* k3590 in k3587 in k3584 in k3581 in k3638 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_3592(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 321  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_SCHEME_TRUE,lf[148]);}

/* k3214 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_3216(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3216,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_3219,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(C_word)C_i_cddr(((C_word*)t0)[16]);
t4=(C_word)C_i_pairp(t3);
t5=t2;
f_3219(t5,(C_truep(t4)?(C_word)C_i_caddr(((C_word*)t0)[16]):C_SCHEME_FALSE));}
else{
t3=t2;
f_3219(t3,C_SCHEME_FALSE);}}

/* k3217 in k3214 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_fcall f_3219(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3219,NULL,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_i_cadddr(((C_word*)t0)[16]):C_SCHEME_FALSE);
t3=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_3225,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[16],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t2,a[11]=t1,a[12]=((C_word*)t0)[10],a[13]=((C_word*)t0)[11],a[14]=((C_word*)t0)[12],a[15]=((C_word*)t0)[13],a[16]=((C_word*)t0)[14],a[17]=((C_word*)t0)[15],tmp=(C_word)a,a+=18,tmp);
if(C_truep(t2)){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3529,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3533,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 227  find-lambda */
t6=((C_word*)t0)[2];
f_2497(t6,t5,t1);}
else{
t4=t3;
f_3225(t4,C_SCHEME_FALSE);}}

/* k3531 in k3217 in k3214 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_3533(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 227  lambda-literal-closure-size */
((C_proc3)C_retrieve_symbol_proc(lf[145]))(3,*((C_word*)lf[145]+1),((C_word*)t0)[2],t1);}

/* k3527 in k3217 in k3214 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_3529(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_3225(t2,(C_word)C_eqp(t1,C_fix(0)));}

/* k3223 in k3217 in k3214 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_fcall f_3225(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3225,NULL,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[17]);
t3=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_3231,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t1,a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[14],a[13]=((C_word*)t0)[15],a[14]=((C_word*)t0)[16],a[15]=t2,tmp=(C_word)a,a+=16,tmp);
if(C_truep(((C_word*)t0)[4])){
if(C_truep(C_retrieve(lf[137]))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3515,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=((C_word*)t0)[3];
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2527,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 71   ->string */
((C_proc3)C_retrieve_symbol_proc(lf[15]))(3,*((C_word*)lf[15]+1),t6,t5);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3522,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 232  uncommentify */
f_2529(t4,((C_word*)t0)[3]);}}
else{
t4=t3;
f_3231(2,t4,C_SCHEME_UNDEFINED);}}

/* k3520 in k3223 in k3217 in k3214 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_3522(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 232  gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_SCHEME_TRUE,lf[143],t1,lf[144]);}

/* k2525 in k3223 in k3217 in k3214 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_2527(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 71   string-translate */
((C_proc5)C_retrieve_symbol_proc(lf[140]))(5,*((C_word*)lf[140]+1),((C_word*)t0)[2],t1,lf[141],lf[142]);}

/* k3513 in k3223 in k3217 in k3214 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_3515(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 231  gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_SCHEME_TRUE,lf[138],t1,lf[139]);}

/* k3229 in k3223 in k3217 in k3214 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_3231(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3231,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[15],C_fix(1));
t3=(C_word)C_eqp(lf[37],t2);
if(C_truep(t3)){
t4=(C_word)C_slot(((C_word*)t0)[15],C_fix(2));
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3243,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[13],a[5]=((C_word*)t0)[14],tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_i_car(t4);
/* c-backend.scm: 235  gen */
((C_proc7)C_retrieve_symbol_proc(lf[1]))(7,*((C_word*)lf[1]+1),t5,C_SCHEME_TRUE,t6,C_make_character(40),((C_word*)t0)[10],lf[100]);}
else{
if(C_truep(((C_word*)t0)[9])){
t4=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_3262,a[2]=((C_word*)t0)[15],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[13],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[12],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[6],a[11]=((C_word*)t0)[7],a[12]=((C_word*)t0)[10],a[13]=((C_word*)t0)[8],a[14]=((C_word*)t0)[14],tmp=(C_word)a,a+=15,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3352,a[2]=((C_word*)t0)[5],a[3]=t4,a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 239  lambda-literal-id */
((C_proc3)C_retrieve_symbol_proc(lf[11]))(3,*((C_word*)lf[11]+1),t5,((C_word*)t0)[5]);}
else{
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3358,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[12],a[8]=((C_word*)t0)[13],a[9]=((C_word*)t0)[14],a[10]=((C_word*)t0)[15],tmp=(C_word)a,a+=11,tmp);
t5=(C_word)C_slot(((C_word*)t0)[15],C_fix(1));
t6=(C_word)C_eqp(lf[71],t5);
if(C_truep(t6)){
t7=C_retrieve(lf[129]);
if(C_truep(t7)){
t8=t4;
f_3358(t8,C_SCHEME_FALSE);}
else{
t8=C_retrieve(lf[134]);
if(C_truep(t8)){
t9=t4;
f_3358(t9,C_SCHEME_FALSE);}
else{
t9=(C_word)C_i_car(((C_word*)t0)[2]);
t10=t4;
f_3358(t10,(C_word)C_i_not(t9));}}}
else{
t7=t4;
f_3358(t7,C_SCHEME_FALSE);}}}}

/* k3356 in k3229 in k3223 in k3217 in k3214 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_fcall f_3358(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3358,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[10],C_fix(2));
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cadr(t2);
t5=(C_word)C_i_caddr(t2);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3373,a[2]=t3,a[3]=t2,a[4]=t4,a[5]=t5,a[6]=t7,a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],tmp=(C_word)a,a+=12,tmp);
/* c-backend.scm: 273  gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),t8,C_SCHEME_TRUE,lf[124],((C_word*)t0)[5],lf[125]);}
else{
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3442,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm: 292  gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,C_make_character(116),((C_word*)t0)[4],C_make_character(61));}}

/* k3440 in k3356 in k3229 in k3223 in k3217 in k3214 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_3442(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3442,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3445,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 293  expr */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2542(t3,t2,((C_word*)t0)[2],((C_word*)t0)[7]);}

/* k3443 in k3440 in k3356 in k3229 in k3223 in k3217 in k3214 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_3445(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3445,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3448,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 294  gen */
((C_proc7)C_retrieve_symbol_proc(lf[1]))(7,*((C_word*)lf[1]+1),t2,C_make_character(59),C_SCHEME_TRUE,lf[135],((C_word*)t0)[4],lf[136]);}

/* k3446 in k3443 in k3440 in k3356 in k3229 in k3223 in k3217 in k3214 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_3448(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3448,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3451,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=C_retrieve(lf[129]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3463,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t3)){
t5=t4;
f_3463(t5,t3);}
else{
t5=C_retrieve(lf[134]);
t6=t4;
f_3463(t6,(C_truep(t5)?t5:(C_word)C_i_car(((C_word*)t0)[2])));}}

/* k3461 in k3446 in k3443 in k3440 in k3356 in k3229 in k3223 in k3217 in k3214 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_fcall f_3463(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* c-backend.scm: 297  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),((C_word*)t0)[3],lf[130],((C_word*)t0)[2],lf[131]);}
else{
/* c-backend.scm: 298  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),((C_word*)t0)[3],lf[132],((C_word*)t0)[2],lf[133]);}}

/* k3449 in k3446 in k3443 in k3440 in k3356 in k3229 in k3223 in k3217 in k3214 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_3451(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3451,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3454,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 299  gen */
((C_proc7)C_retrieve_symbol_proc(lf[1]))(7,*((C_word*)lf[1]+1),t2,lf[127],((C_word*)t0)[3],lf[128],((C_word*)t0)[2],C_make_character(44));}

/* k3452 in k3449 in k3446 in k3443 in k3440 in k3356 in k3229 in k3223 in k3217 in k3214 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_3454(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3454,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3457,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 300  expr-args */
t3=((C_word*)((C_word*)t0)[4])[1];
f_4080(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3455 in k3452 in k3449 in k3446 in k3443 in k3440 in k3356 in k3229 in k3223 in k3217 in k3214 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_3457(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 301  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[126]);}

/* k3371 in k3356 in k3229 in k3223 in k3217 in k3214 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_3373(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3373,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3376,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[5])){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3389,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3414,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 275  number->string */
C_number_to_string(3,0,t4,((C_word*)t0)[2]);}
else{
if(C_truep(((C_word*)t0)[4])){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3421,a[2]=t2,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3428,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 282  number->string */
C_number_to_string(3,0,t4,((C_word*)t0)[2]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3432,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3439,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 286  number->string */
C_number_to_string(3,0,t4,((C_word*)t0)[2]);}}}

/* k3437 in k3371 in k3356 in k3229 in k3223 in k3217 in k3214 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_3439(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 286  string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[113]+1)))(5,*((C_word*)lf[113]+1),((C_word*)t0)[2],lf[122],t1,lf[123]);}

/* k3430 in k3371 in k3356 in k3229 in k3223 in k3217 in k3214 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_3432(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
/* c-backend.scm: 287  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),((C_word*)t0)[3],lf[120],((C_word*)t0)[2],lf[121]);}

/* k3426 in k3371 in k3356 in k3229 in k3223 in k3217 in k3214 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_3428(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 282  string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[113]+1)))(5,*((C_word*)lf[113]+1),((C_word*)t0)[2],lf[118],t1,lf[119]);}

/* k3419 in k3371 in k3356 in k3229 in k3223 in k3217 in k3214 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_3421(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
/* c-backend.scm: 283  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[116],((C_word*)((C_word*)t0)[3])[1],lf[117]);}

/* k3412 in k3371 in k3356 in k3229 in k3223 in k3217 in k3214 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_3414(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 275  string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[113]+1)))(5,*((C_word*)lf[113]+1),((C_word*)t0)[2],lf[114],t1,lf[115]);}

/* k3387 in k3371 in k3356 in k3229 in k3223 in k3217 in k3214 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_3389(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3389,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
if(C_truep(((C_word*)t0)[4])){
/* c-backend.scm: 277  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),((C_word*)t0)[3],lf[109],((C_word*)((C_word*)t0)[5])[1],lf[110]);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3402,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3406,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_i_cadddr(((C_word*)t0)[2]);
/* c-backend.scm: 279  symbol->string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[77]+1)))(3,*((C_word*)lf[77]+1),t4,t5);}}

/* k3404 in k3387 in k3371 in k3356 in k3229 in k3223 in k3217 in k3214 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_3406(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 279  c-ify-string */
((C_proc3)C_retrieve_symbol_proc(lf[76]))(3,*((C_word*)lf[76]+1),((C_word*)t0)[2],t1);}

/* k3400 in k3387 in k3371 in k3356 in k3229 in k3223 in k3217 in k3214 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_3402(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 278  gen */
((C_proc7)C_retrieve_symbol_proc(lf[1]))(7,*((C_word*)lf[1]+1),((C_word*)t0)[3],lf[111],((C_word*)((C_word*)t0)[2])[1],lf[112],t1,C_make_character(41));}

/* k3374 in k3371 in k3356 in k3229 in k3223 in k3217 in k3214 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_3376(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3376,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3379,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 288  gen */
((C_proc7)C_retrieve_symbol_proc(lf[1]))(7,*((C_word*)lf[1]+1),t2,lf[108],((C_word*)t0)[3],C_make_character(44),((C_word*)((C_word*)t0)[2])[1],C_make_character(44));}

/* k3377 in k3374 in k3371 in k3356 in k3229 in k3223 in k3217 in k3214 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_3379(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3379,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3382,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 289  expr-args */
t3=((C_word*)((C_word*)t0)[4])[1];
f_4080(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3380 in k3377 in k3374 in k3371 in k3356 in k3229 in k3223 in k3217 in k3214 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_3382(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 290  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[107]);}

/* k3350 in k3229 in k3223 in k3217 in k3214 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_3352(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(((C_word*)t0)[4],t1);
if(C_truep(t2)){
/* c-backend.scm: 240  lambda-literal-looping */
((C_proc3)C_retrieve_symbol_proc(lf[106]))(3,*((C_word*)lf[106]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[3];
f_3262(2,t3,C_SCHEME_FALSE);}}

/* k3260 in k3229 in k3223 in k3217 in k3214 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_3262(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3262,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3265,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[12],a[7]=((C_word*)t0)[13],a[8]=((C_word*)t0)[14],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 241  lambda-literal-temporaries */
((C_proc3)C_retrieve_symbol_proc(lf[104]))(3,*((C_word*)lf[104]+1),t2,((C_word*)t0)[7]);}
else{
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3312,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[13],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[14],tmp=(C_word)a,a+=11,tmp);
if(C_truep(((C_word*)t0)[5])){
t3=t2;
f_3312(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3336,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[10],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 256  gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),t3,C_SCHEME_TRUE,C_make_character(116),((C_word*)t0)[4],C_make_character(61));}}}

/* k3334 in k3260 in k3229 in k3223 in k3217 in k3214 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_3336(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3336,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3339,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 257  expr */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2542(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3337 in k3334 in k3260 in k3229 in k3223 in k3217 in k3214 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_3339(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 258  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(59));}

/* k3310 in k3260 in k3229 in k3223 in k3217 in k3214 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_3312(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3312,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3315,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
/* c-backend.scm: 259  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,((C_word*)t0)[2],C_make_character(40));}

/* k3313 in k3310 in k3260 in k3229 in k3223 in k3217 in k3214 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_3315(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3315,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3318,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=t2;
f_3318(2,t3,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 260  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t2,((C_word*)t0)[2],C_make_character(44));}}

/* k3316 in k3313 in k3310 in k3260 in k3229 in k3223 in k3217 in k3214 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_3318(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3318,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3321,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=t2;
f_3321(2,t3,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 261  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t2,C_make_character(116),((C_word*)t0)[2],C_make_character(44));}}

/* k3319 in k3316 in k3313 in k3310 in k3260 in k3229 in k3223 in k3217 in k3214 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_3321(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3321,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3324,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 262  expr-args */
t3=((C_word*)((C_word*)t0)[4])[1];
f_4080(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3322 in k3319 in k3316 in k3313 in k3310 in k3260 in k3229 in k3223 in k3217 in k3214 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_3324(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 263  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[105]);}

/* k3263 in k3260 in k3229 in k3223 in k3217 in k3214 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_3265(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3265,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3268,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(C_word)C_fixnum_plus(t1,((C_word*)t0)[6]);
/* c-backend.scm: 242  iota */
((C_proc5)C_retrieve_symbol_proc(lf[64]))(5,*((C_word*)lf[64]+1),t2,((C_word*)t0)[5],t3,C_fix(1));}

/* k3266 in k3263 in k3260 in k3229 in k3223 in k3217 in k3214 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_3268(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3268,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3271,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3295,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 243  for-each */
((C_proc5)C_retrieve_proc(*((C_word*)lf[63]+1)))(5,*((C_word*)lf[63]+1),t2,t3,((C_word*)t0)[2],t1);}

/* a3294 in k3266 in k3263 in k3260 in k3229 in k3223 in k3217 in k3214 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_3295(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3295,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3299,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 245  gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),t4,C_SCHEME_TRUE,C_make_character(116),t3,C_make_character(61));}

/* k3297 in a3294 in k3266 in k3263 in k3260 in k3229 in k3223 in k3217 in k3214 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_3299(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3299,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3302,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 246  expr */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2542(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3300 in k3297 in a3294 in k3266 in k3263 in k3260 in k3229 in k3223 in k3217 in k3214 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_3302(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 247  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(59));}

/* k3269 in k3266 in k3263 in k3260 in k3229 in k3223 in k3217 in k3214 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_3271(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3271,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3274,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3285,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3293,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 251  iota */
((C_proc5)C_retrieve_symbol_proc(lf[64]))(5,*((C_word*)lf[64]+1),t4,((C_word*)t0)[2],C_fix(1),C_fix(1));}

/* k3291 in k3269 in k3266 in k3263 in k3260 in k3229 in k3223 in k3217 in k3214 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_3293(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 249  for-each */
((C_proc5)C_retrieve_proc(*((C_word*)lf[63]+1)))(5,*((C_word*)lf[63]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a3284 in k3269 in k3266 in k3263 in k3260 in k3229 in k3223 in k3217 in k3214 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_3285(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3285,4,t0,t1,t2,t3);}
/* c-backend.scm: 250  gen */
((C_proc8)C_retrieve_symbol_proc(lf[1]))(8,*((C_word*)lf[1]+1),t1,C_SCHEME_TRUE,C_make_character(116),t3,lf[103],t2,C_make_character(59));}

/* k3272 in k3269 in k3266 in k3263 in k3260 in k3229 in k3223 in k3217 in k3214 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_3274(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3274,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3277,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=t2;
f_3277(2,t3,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 252  gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[102],((C_word*)t0)[2],C_make_character(59));}}

/* k3275 in k3272 in k3269 in k3266 in k3263 in k3260 in k3229 in k3223 in k3217 in k3214 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_3277(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 253  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_SCHEME_TRUE,lf[101]);}

/* k3241 in k3229 in k3223 in k3217 in k3214 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_3243(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3243,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3246,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 236  expr-args */
t3=((C_word*)((C_word*)t0)[4])[1];
f_4080(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3244 in k3241 in k3229 in k3223 in k3217 in k3214 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_3246(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 237  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[99]);}

/* k3181 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_3183(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 211  uncommentify */
f_2529(((C_word*)t0)[2],t1);}

/* k3177 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_3179(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 210  gen */
((C_proc7)C_retrieve_symbol_proc(lf[1]))(7,*((C_word*)lf[1]+1),((C_word*)t0)[3],lf[93],((C_word*)t0)[2],lf[94],t1,lf[95]);}

/* k3163 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_3165(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3165,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3168,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 212  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2542(t4,t2,t3,((C_word*)t0)[2]);}

/* k3166 in k3163 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_3168(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 213  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(41));}

/* k3160 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_3162(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 206  uncommentify */
f_2529(((C_word*)t0)[2],t1);}

/* k3156 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_3158(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 205  gen */
((C_proc7)C_retrieve_symbol_proc(lf[1]))(7,*((C_word*)lf[1]+1),((C_word*)t0)[3],lf[90],((C_word*)t0)[2],lf[91],t1,lf[92]);}

/* k3142 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_3144(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3144,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3147,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 207  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2542(t4,t2,t3,((C_word*)t0)[2]);}

/* k3145 in k3142 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_3147(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 208  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(59));}

/* k3094 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_3096(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3096,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3099,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3113,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3117,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 196  symbol->string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[77]+1)))(3,*((C_word*)lf[77]+1),t4,((C_word*)t0)[2]);}

/* k3115 in k3094 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_3117(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 196  uncommentify */
f_2529(((C_word*)t0)[2],t1);}

/* k3111 in k3094 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_3113(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 196  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[83],t1,lf[84]);}

/* k3097 in k3094 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_3099(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3099,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3102,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 197  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2542(t4,t2,t3,((C_word*)t0)[2]);}

/* k3100 in k3097 in k3094 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_3102(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 198  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(41));}

/* k3063 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_3065(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 185  c-ify-string */
((C_proc3)C_retrieve_symbol_proc(lf[76]))(3,*((C_word*)lf[76]+1),((C_word*)t0)[2],t1);}

/* k3059 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_3061(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 185  gen */
((C_proc7)C_retrieve_symbol_proc(lf[1]))(7,*((C_word*)lf[1]+1),((C_word*)t0)[3],lf[74],((C_word*)t0)[2],lf[75],t1,C_make_character(41));}

/* k3017 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_3019(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(((C_word*)t0)[5]);
/* c-backend.scm: 176  expr */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2542(t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k2985 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_2987(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2987,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2990,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 169  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2542(t4,t2,t3,((C_word*)t0)[2]);}

/* k2988 in k2985 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_2990(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 170  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[67]);}

/* k2950 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_2952(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2952,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2955,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2964,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2978,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 164  iota */
((C_proc5)C_retrieve_symbol_proc(lf[64]))(5,*((C_word*)lf[64]+1),t4,((C_word*)t0)[6],C_fix(1),C_fix(1));}

/* k2976 in k2950 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_2978(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 159  for-each */
((C_proc5)C_retrieve_proc(*((C_word*)lf[63]+1)))(5,*((C_word*)lf[63]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2963 in k2950 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_2964(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2964,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2968,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 161  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t4,lf[61],t3,lf[62]);}

/* k2966 in a2963 in k2950 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_2968(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2968,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2971,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 162  expr */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2542(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2969 in k2966 in a2963 in k2950 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_2971(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 163  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(44));}

/* k2953 in k2950 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_2955(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_increase(((C_word*)t0)[3]);
/* c-backend.scm: 165  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[59],t2,lf[60]);}

/* k2918 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_2920(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2920,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2923,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 151  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2542(t4,t2,t3,((C_word*)t0)[2]);}

/* k2921 in k2918 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_2923(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2923,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2926,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 152  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,lf[56]);}

/* k2924 in k2921 in k2918 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_2926(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2926,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2929,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 153  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2542(t4,t2,t3,((C_word*)t0)[2]);}

/* k2927 in k2924 in k2921 in k2918 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_2929(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 154  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(41));}

/* k2889 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_2891(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2891,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2894,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 144  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2542(t4,t2,t3,((C_word*)t0)[2]);}

/* k2892 in k2889 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_2894(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2894,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2897,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 145  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,lf[53]);}

/* k2895 in k2892 in k2889 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_2897(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2897,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2900,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 146  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2542(t4,t2,t3,((C_word*)t0)[2]);}

/* k2898 in k2895 in k2892 in k2889 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_2900(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 147  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(41));}

/* k2852 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_2854(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2854,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2857,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[5]);
/* c-backend.scm: 137  expr */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2542(t4,t2,t3,((C_word*)t0)[3]);}

/* k2855 in k2852 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_2857(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2857,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2860,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[2]);
t4=(C_word)C_fixnum_plus(t3,C_fix(1));
/* c-backend.scm: 138  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t2,lf[49],t4,lf[50]);}

/* k2858 in k2855 in k2852 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_2860(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2860,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2863,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 139  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2542(t4,t2,t3,((C_word*)t0)[2]);}

/* k2861 in k2858 in k2855 in k2852 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_2863(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 140  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(41));}

/* k2819 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_2821(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2821,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2824,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[5]);
/* c-backend.scm: 130  expr */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2542(t4,t2,t3,((C_word*)t0)[3]);}

/* k2822 in k2819 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_2824(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2824,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2827,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[2]);
/* c-backend.scm: 131  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t2,C_make_character(44),t3,C_make_character(44));}

/* k2825 in k2822 in k2819 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_2827(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2827,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2830,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 132  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2542(t4,t2,t3,((C_word*)t0)[2]);}

/* k2828 in k2825 in k2822 in k2819 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_2830(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 133  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(41));}

/* k2800 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_2802(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2802,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2805,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 125  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2542(t4,t2,t3,((C_word*)t0)[2]);}

/* k2803 in k2800 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_2805(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 126  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[44]);}

/* k2773 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_2775(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2775,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2778,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 120  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2542(t4,t2,t3,((C_word*)t0)[2]);}

/* k2776 in k2773 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_2778(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(C_word)C_fixnum_plus(t2,C_fix(1));
/* c-backend.scm: 121  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[41],t3,C_make_character(93));}

/* loop in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_fcall f_2724(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2724,NULL,5,t0,t1,t2,t3,t4);}
t5=t4;
if(C_truep((C_word)C_fixnum_greaterp(t5,C_fix(0)))){
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2734,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t4,a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 112  gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),t6,C_SCHEME_TRUE,C_make_character(116),t3,C_make_character(61));}
else{
t6=(C_word)C_i_car(t2);
/* c-backend.scm: 116  expr */
t7=((C_word*)((C_word*)t0)[2])[1];
f_2542(t7,t1,t6,t3);}}

/* k2732 in loop in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_2734(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2734,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2737,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[7]);
/* c-backend.scm: 113  expr */
t4=((C_word*)((C_word*)t0)[2])[1];
f_2542(t4,t2,t3,((C_word*)t0)[6]);}

/* k2735 in k2732 in loop in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_2737(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2737,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2740,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 114  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,C_make_character(59));}

/* k2738 in k2735 in k2732 in loop in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_2740(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[6]);
t3=(C_word)C_fixnum_increase(((C_word*)t0)[5]);
t4=(C_word)C_fixnum_decrease(((C_word*)t0)[4]);
/* c-backend.scm: 115  loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_2724(t5,((C_word*)t0)[2],t2,t3,t4);}

/* k2664 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_2666(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2666,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2669,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 99   expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2542(t4,t2,t3,((C_word*)t0)[2]);}

/* k2667 in k2664 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_2669(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2669,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2672,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 100  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,lf[35]);}

/* k2670 in k2667 in k2664 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_2672(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2672,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2675,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 101  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2542(t4,t2,t3,((C_word*)t0)[2]);}

/* k2673 in k2670 in k2667 in k2664 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_2675(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2675,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2678,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 102  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t2,C_make_character(125),C_SCHEME_TRUE,lf[34]);}

/* k2676 in k2673 in k2670 in k2667 in k2664 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_2678(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2678,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2681,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_caddr(((C_word*)t0)[4]);
/* c-backend.scm: 103  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2542(t4,t2,t3,((C_word*)t0)[2]);}

/* k2679 in k2676 in k2673 in k2670 in k2667 in k2664 in expr in expression in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_2681(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 104  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(125));}

/* uncommentify in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_fcall f_2529(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2529,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2537,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 72   ->string */
((C_proc3)C_retrieve_symbol_proc(lf[15]))(3,*((C_word*)lf[15]+1),t3,t2);}

/* k2535 in uncommentify in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_2537(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 72   string-translate* */
((C_proc4)C_retrieve_symbol_proc(lf[13]))(4,*((C_word*)lf[13]+1),((C_word*)t0)[2],t1,lf[14]);}

/* find-lambda in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_fcall f_2497(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2497,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2501,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2509,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 68   find */
((C_proc4)C_retrieve_symbol_proc(lf[12]))(4,*((C_word*)lf[12]+1),t3,t4,((C_word*)t0)[2]);}

/* a2508 in find-lambda in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_2509(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2509,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2517,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 68   lambda-literal-id */
((C_proc3)C_retrieve_symbol_proc(lf[11]))(3,*((C_word*)lf[11]+1),t3,t2);}

/* k2515 in a2508 in find-lambda in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_2517(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_eqp(((C_word*)t0)[2],t1));}

/* k2499 in find-lambda in ##compiler#generate-code in k2490 in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_2501(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
/* c-backend.scm: 69   bomb */
((C_proc4)C_retrieve_symbol_proc(lf[9]))(4,*((C_word*)lf[9]+1),((C_word*)t0)[3],lf[10],((C_word*)t0)[2]);}}

/* ##compiler#gen-list in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_2474(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2474,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2480,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2488,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 50   intersperse */
((C_proc4)C_retrieve_symbol_proc(lf[6]))(4,*((C_word*)lf[6]+1),t4,t2,C_make_character(32));}

/* k2486 in ##compiler#gen-list in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_2488(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2479 in ##compiler#gen-list in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_2480(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2480,3,t0,t1,t2);}
/* c-backend.scm: 49   display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[3]+1)))(4,*((C_word*)lf[3]+1),t1,t2,C_retrieve(lf[0]));}

/* ##compiler#gen in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_2453(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+2)){
C_save_and_reclaim((void*)tr2r,(void*)f_2453r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2453r(t0,t1,t2);}}

static void C_ccall f_2453r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(2);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2459,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t3,t2);}

/* a2458 in ##compiler#gen in k2448 in k2445 in k2442 in k2439 in k2436 in k2433 */
static void C_ccall f_2459(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2459,3,t0,t1,t2);}
t3=(C_word)C_eqp(C_SCHEME_TRUE,t2);
if(C_truep(t3)){
/* c-backend.scm: 43   newline */
((C_proc3)C_retrieve_proc(*((C_word*)lf[2]+1)))(3,*((C_word*)lf[2]+1),t1,C_retrieve(lf[0]));}
else{
/* c-backend.scm: 44   display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[3]+1)))(4,*((C_word*)lf[3]+1),t1,t2,C_retrieve(lf[0]));}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[665] = {
{"toplevel:c_backend_scm",(void*)C_backend_toplevel},
{"f_2435:c_backend_scm",(void*)f_2435},
{"f_2438:c_backend_scm",(void*)f_2438},
{"f_2441:c_backend_scm",(void*)f_2441},
{"f_2444:c_backend_scm",(void*)f_2444},
{"f_2447:c_backend_scm",(void*)f_2447},
{"f_2450:c_backend_scm",(void*)f_2450},
{"f_9167:c_backend_scm",(void*)f_9167},
{"f_9171:c_backend_scm",(void*)f_9171},
{"f_9163:c_backend_scm",(void*)f_9163},
{"f_2492:c_backend_scm",(void*)f_2492},
{"f_8863:c_backend_scm",(void*)f_8863},
{"f_9139:c_backend_scm",(void*)f_9139},
{"f_9137:c_backend_scm",(void*)f_9137},
{"f_9125:c_backend_scm",(void*)f_9125},
{"f_9095:c_backend_scm",(void*)f_9095},
{"f_9056:c_backend_scm",(void*)f_9056},
{"f_9043:c_backend_scm",(void*)f_9043},
{"f_9039:c_backend_scm",(void*)f_9039},
{"f_8925:c_backend_scm",(void*)f_8925},
{"f_8872:c_backend_scm",(void*)f_8872},
{"f_8465:c_backend_scm",(void*)f_8465},
{"f_8552:c_backend_scm",(void*)f_8552},
{"f_8633:c_backend_scm",(void*)f_8633},
{"f_8655:c_backend_scm",(void*)f_8655},
{"f_8467:c_backend_scm",(void*)f_8467},
{"f_7980:c_backend_scm",(void*)f_7980},
{"f_8010:c_backend_scm",(void*)f_8010},
{"f_8037:c_backend_scm",(void*)f_8037},
{"f_8232:c_backend_scm",(void*)f_8232},
{"f_8241:c_backend_scm",(void*)f_8241},
{"f_8250:c_backend_scm",(void*)f_8250},
{"f_8272:c_backend_scm",(void*)f_8272},
{"f_8349:c_backend_scm",(void*)f_8349},
{"f_7982:c_backend_scm",(void*)f_7982},
{"f_7135:c_backend_scm",(void*)f_7135},
{"f_7212:c_backend_scm",(void*)f_7212},
{"f_7314:c_backend_scm",(void*)f_7314},
{"f_7347:c_backend_scm",(void*)f_7347},
{"f_7443:c_backend_scm",(void*)f_7443},
{"f_7455:c_backend_scm",(void*)f_7455},
{"f_7470:c_backend_scm",(void*)f_7470},
{"f_7510:c_backend_scm",(void*)f_7510},
{"f_7527:c_backend_scm",(void*)f_7527},
{"f_7544:c_backend_scm",(void*)f_7544},
{"f_7583:c_backend_scm",(void*)f_7583},
{"f_7600:c_backend_scm",(void*)f_7600},
{"f_7617:c_backend_scm",(void*)f_7617},
{"f_7634:c_backend_scm",(void*)f_7634},
{"f_7651:c_backend_scm",(void*)f_7651},
{"f_7668:c_backend_scm",(void*)f_7668},
{"f_7685:c_backend_scm",(void*)f_7685},
{"f_7697:c_backend_scm",(void*)f_7697},
{"f_7704:c_backend_scm",(void*)f_7704},
{"f_7714:c_backend_scm",(void*)f_7714},
{"f_7712:c_backend_scm",(void*)f_7712},
{"f_7708:c_backend_scm",(void*)f_7708},
{"f_7675:c_backend_scm",(void*)f_7675},
{"f_7658:c_backend_scm",(void*)f_7658},
{"f_7641:c_backend_scm",(void*)f_7641},
{"f_7624:c_backend_scm",(void*)f_7624},
{"f_7607:c_backend_scm",(void*)f_7607},
{"f_7590:c_backend_scm",(void*)f_7590},
{"f_7555:c_backend_scm",(void*)f_7555},
{"f_7565:c_backend_scm",(void*)f_7565},
{"f_7563:c_backend_scm",(void*)f_7563},
{"f_7559:c_backend_scm",(void*)f_7559},
{"f_7551:c_backend_scm",(void*)f_7551},
{"f_7538:c_backend_scm",(void*)f_7538},
{"f_7521:c_backend_scm",(void*)f_7521},
{"f_7142:c_backend_scm",(void*)f_7142},
{"f_7137:c_backend_scm",(void*)f_7137},
{"f_7070:c_backend_scm",(void*)f_7070},
{"f_7074:c_backend_scm",(void*)f_7074},
{"f_7077:c_backend_scm",(void*)f_7077},
{"f_7080:c_backend_scm",(void*)f_7080},
{"f_7083:c_backend_scm",(void*)f_7083},
{"f_7089:c_backend_scm",(void*)f_7089},
{"f_7133:c_backend_scm",(void*)f_7133},
{"f_7092:c_backend_scm",(void*)f_7092},
{"f_7100:c_backend_scm",(void*)f_7100},
{"f_7121:c_backend_scm",(void*)f_7121},
{"f_7104:c_backend_scm",(void*)f_7104},
{"f_7095:c_backend_scm",(void*)f_7095},
{"f_6639:c_backend_scm",(void*)f_6639},
{"f_6645:c_backend_scm",(void*)f_6645},
{"f_6649:c_backend_scm",(void*)f_6649},
{"f_6652:c_backend_scm",(void*)f_6652},
{"f_6655:c_backend_scm",(void*)f_6655},
{"f_6658:c_backend_scm",(void*)f_6658},
{"f_6664:c_backend_scm",(void*)f_6664},
{"f_7005:c_backend_scm",(void*)f_7005},
{"f_7008:c_backend_scm",(void*)f_7008},
{"f_7068:c_backend_scm",(void*)f_7068},
{"f_7011:c_backend_scm",(void*)f_7011},
{"f_7014:c_backend_scm",(void*)f_7014},
{"f_7017:c_backend_scm",(void*)f_7017},
{"f_7020:c_backend_scm",(void*)f_7020},
{"f_7053:c_backend_scm",(void*)f_7053},
{"f_7061:c_backend_scm",(void*)f_7061},
{"f_7023:c_backend_scm",(void*)f_7023},
{"f_7051:c_backend_scm",(void*)f_7051},
{"f_7026:c_backend_scm",(void*)f_7026},
{"f_7029:c_backend_scm",(void*)f_7029},
{"f_7032:c_backend_scm",(void*)f_7032},
{"f_6666:c_backend_scm",(void*)f_6666},
{"f_6676:c_backend_scm",(void*)f_6676},
{"f_6685:c_backend_scm",(void*)f_6685},
{"f_6697:c_backend_scm",(void*)f_6697},
{"f_6709:c_backend_scm",(void*)f_6709},
{"f_6715:c_backend_scm",(void*)f_6715},
{"f_6749:c_backend_scm",(void*)f_6749},
{"f_6406:c_backend_scm",(void*)f_6406},
{"f_6412:c_backend_scm",(void*)f_6412},
{"f_6416:c_backend_scm",(void*)f_6416},
{"f_6419:c_backend_scm",(void*)f_6419},
{"f_6422:c_backend_scm",(void*)f_6422},
{"f_6637:c_backend_scm",(void*)f_6637},
{"f_6428:c_backend_scm",(void*)f_6428},
{"f_6431:c_backend_scm",(void*)f_6431},
{"f_6434:c_backend_scm",(void*)f_6434},
{"f_6437:c_backend_scm",(void*)f_6437},
{"f_6440:c_backend_scm",(void*)f_6440},
{"f_6443:c_backend_scm",(void*)f_6443},
{"f_6446:c_backend_scm",(void*)f_6446},
{"f_6449:c_backend_scm",(void*)f_6449},
{"f_6452:c_backend_scm",(void*)f_6452},
{"f_6455:c_backend_scm",(void*)f_6455},
{"f_6626:c_backend_scm",(void*)f_6626},
{"f_6458:c_backend_scm",(void*)f_6458},
{"f_6461:c_backend_scm",(void*)f_6461},
{"f_6464:c_backend_scm",(void*)f_6464},
{"f_6467:c_backend_scm",(void*)f_6467},
{"f_6470:c_backend_scm",(void*)f_6470},
{"f_6473:c_backend_scm",(void*)f_6473},
{"f_6476:c_backend_scm",(void*)f_6476},
{"f_6479:c_backend_scm",(void*)f_6479},
{"f_6604:c_backend_scm",(void*)f_6604},
{"f_6574:c_backend_scm",(void*)f_6574},
{"f_6594:c_backend_scm",(void*)f_6594},
{"f_6582:c_backend_scm",(void*)f_6582},
{"f_6586:c_backend_scm",(void*)f_6586},
{"f_6590:c_backend_scm",(void*)f_6590},
{"f_6482:c_backend_scm",(void*)f_6482},
{"f_6485:c_backend_scm",(void*)f_6485},
{"f_6515:c_backend_scm",(void*)f_6515},
{"f_6518:c_backend_scm",(void*)f_6518},
{"f_6556:c_backend_scm",(void*)f_6556},
{"f_6552:c_backend_scm",(void*)f_6552},
{"f_6521:c_backend_scm",(void*)f_6521},
{"f_6524:c_backend_scm",(void*)f_6524},
{"f_6527:c_backend_scm",(void*)f_6527},
{"f_6494:c_backend_scm",(void*)f_6494},
{"f_6497:c_backend_scm",(void*)f_6497},
{"f_6488:c_backend_scm",(void*)f_6488},
{"f_6388:c_backend_scm",(void*)f_6388},
{"f_6394:c_backend_scm",(void*)f_6394},
{"f_6398:c_backend_scm",(void*)f_6398},
{"f_6401:c_backend_scm",(void*)f_6401},
{"f_6356:c_backend_scm",(void*)f_6356},
{"f_6360:c_backend_scm",(void*)f_6360},
{"f_6365:c_backend_scm",(void*)f_6365},
{"f_6386:c_backend_scm",(void*)f_6386},
{"f_6340:c_backend_scm",(void*)f_6340},
{"f_6346:c_backend_scm",(void*)f_6346},
{"f_6354:c_backend_scm",(void*)f_6354},
{"f_6324:c_backend_scm",(void*)f_6324},
{"f_6330:c_backend_scm",(void*)f_6330},
{"f_6338:c_backend_scm",(void*)f_6338},
{"f_6235:c_backend_scm",(void*)f_6235},
{"f_6244:c_backend_scm",(void*)f_6244},
{"f_6273:c_backend_scm",(void*)f_6273},
{"f_6283:c_backend_scm",(void*)f_6283},
{"f_6276:c_backend_scm",(void*)f_6276},
{"f_6260:c_backend_scm",(void*)f_6260},
{"f_6158:c_backend_scm",(void*)f_6158},
{"f_6162:c_backend_scm",(void*)f_6162},
{"f_6176:c_backend_scm",(void*)f_6176},
{"f_6189:c_backend_scm",(void*)f_6189},
{"f_6221:c_backend_scm",(void*)f_6221},
{"f_6192:c_backend_scm",(void*)f_6192},
{"f_6195:c_backend_scm",(void*)f_6195},
{"f_6165:c_backend_scm",(void*)f_6165},
{"f_6168:c_backend_scm",(void*)f_6168},
{"f_6171:c_backend_scm",(void*)f_6171},
{"f_2494:c_backend_scm",(void*)f_2494},
{"f_6125:c_backend_scm",(void*)f_6125},
{"f_6129:c_backend_scm",(void*)f_6129},
{"f_6132:c_backend_scm",(void*)f_6132},
{"f_6135:c_backend_scm",(void*)f_6135},
{"f_6138:c_backend_scm",(void*)f_6138},
{"f_6141:c_backend_scm",(void*)f_6141},
{"f_6144:c_backend_scm",(void*)f_6144},
{"f_6147:c_backend_scm",(void*)f_6147},
{"f_6150:c_backend_scm",(void*)f_6150},
{"f_6153:c_backend_scm",(void*)f_6153},
{"f_5378:c_backend_scm",(void*)f_5378},
{"f_5384:c_backend_scm",(void*)f_5384},
{"f_5388:c_backend_scm",(void*)f_5388},
{"f_5391:c_backend_scm",(void*)f_5391},
{"f_5394:c_backend_scm",(void*)f_5394},
{"f_5397:c_backend_scm",(void*)f_5397},
{"f_5400:c_backend_scm",(void*)f_5400},
{"f_5403:c_backend_scm",(void*)f_5403},
{"f_6122:c_backend_scm",(void*)f_6122},
{"f_5406:c_backend_scm",(void*)f_5406},
{"f_5412:c_backend_scm",(void*)f_5412},
{"f_5415:c_backend_scm",(void*)f_5415},
{"f_5418:c_backend_scm",(void*)f_5418},
{"f_5421:c_backend_scm",(void*)f_5421},
{"f_5424:c_backend_scm",(void*)f_5424},
{"f_5427:c_backend_scm",(void*)f_5427},
{"f_5430:c_backend_scm",(void*)f_5430},
{"f_5433:c_backend_scm",(void*)f_5433},
{"f_5436:c_backend_scm",(void*)f_5436},
{"f_5439:c_backend_scm",(void*)f_5439},
{"f_5442:c_backend_scm",(void*)f_5442},
{"f_5445:c_backend_scm",(void*)f_5445},
{"f_6091:c_backend_scm",(void*)f_6091},
{"f_5448:c_backend_scm",(void*)f_5448},
{"f_6052:c_backend_scm",(void*)f_6052},
{"f_6055:c_backend_scm",(void*)f_6055},
{"f_6058:c_backend_scm",(void*)f_6058},
{"f_6074:c_backend_scm",(void*)f_6074},
{"f_6077:c_backend_scm",(void*)f_6077},
{"f_5451:c_backend_scm",(void*)f_5451},
{"f_5454:c_backend_scm",(void*)f_5454},
{"f_5457:c_backend_scm",(void*)f_5457},
{"f_6024:c_backend_scm",(void*)f_6024},
{"f_6027:c_backend_scm",(void*)f_6027},
{"f_5460:c_backend_scm",(void*)f_5460},
{"f_5463:c_backend_scm",(void*)f_5463},
{"f_5466:c_backend_scm",(void*)f_5466},
{"f_5469:c_backend_scm",(void*)f_5469},
{"f_5472:c_backend_scm",(void*)f_5472},
{"f_5475:c_backend_scm",(void*)f_5475},
{"f_5986:c_backend_scm",(void*)f_5986},
{"f_5996:c_backend_scm",(void*)f_5996},
{"f_5478:c_backend_scm",(void*)f_5478},
{"f_5929:c_backend_scm",(void*)f_5929},
{"f_5941:c_backend_scm",(void*)f_5941},
{"f_5944:c_backend_scm",(void*)f_5944},
{"f_5950:c_backend_scm",(void*)f_5950},
{"f_5851:c_backend_scm",(void*)f_5851},
{"f_5893:c_backend_scm",(void*)f_5893},
{"f_5854:c_backend_scm",(void*)f_5854},
{"f_5860:c_backend_scm",(void*)f_5860},
{"f_5863:c_backend_scm",(void*)f_5863},
{"f_5869:c_backend_scm",(void*)f_5869},
{"f_5787:c_backend_scm",(void*)f_5787},
{"f_5790:c_backend_scm",(void*)f_5790},
{"f_5793:c_backend_scm",(void*)f_5793},
{"f_5796:c_backend_scm",(void*)f_5796},
{"f_5799:c_backend_scm",(void*)f_5799},
{"f_5814:c_backend_scm",(void*)f_5814},
{"f_5802:c_backend_scm",(void*)f_5802},
{"f_5805:c_backend_scm",(void*)f_5805},
{"f_5773:c_backend_scm",(void*)f_5773},
{"f_5781:c_backend_scm",(void*)f_5781},
{"f_5698:c_backend_scm",(void*)f_5698},
{"f_5704:c_backend_scm",(void*)f_5704},
{"f_5707:c_backend_scm",(void*)f_5707},
{"f_5741:c_backend_scm",(void*)f_5741},
{"f_5744:c_backend_scm",(void*)f_5744},
{"f_5747:c_backend_scm",(void*)f_5747},
{"f_5710:c_backend_scm",(void*)f_5710},
{"f_5713:c_backend_scm",(void*)f_5713},
{"f_5716:c_backend_scm",(void*)f_5716},
{"f_5719:c_backend_scm",(void*)f_5719},
{"f_5728:c_backend_scm",(void*)f_5728},
{"f_5731:c_backend_scm",(void*)f_5731},
{"f_5481:c_backend_scm",(void*)f_5481},
{"f_5504:c_backend_scm",(void*)f_5504},
{"f_5639:c_backend_scm",(void*)f_5639},
{"f_5642:c_backend_scm",(void*)f_5642},
{"f_5654:c_backend_scm",(void*)f_5654},
{"f_5645:c_backend_scm",(void*)f_5645},
{"f_5510:c_backend_scm",(void*)f_5510},
{"f_5513:c_backend_scm",(void*)f_5513},
{"f_5516:c_backend_scm",(void*)f_5516},
{"f_5620:c_backend_scm",(void*)f_5620},
{"f_5519:c_backend_scm",(void*)f_5519},
{"f_5522:c_backend_scm",(void*)f_5522},
{"f_5525:c_backend_scm",(void*)f_5525},
{"f_5528:c_backend_scm",(void*)f_5528},
{"f_5593:c_backend_scm",(void*)f_5593},
{"f_5589:c_backend_scm",(void*)f_5589},
{"f_5531:c_backend_scm",(void*)f_5531},
{"f_5534:c_backend_scm",(void*)f_5534},
{"f_5537:c_backend_scm",(void*)f_5537},
{"f_5540:c_backend_scm",(void*)f_5540},
{"f_5543:c_backend_scm",(void*)f_5543},
{"f_5546:c_backend_scm",(void*)f_5546},
{"f_5564:c_backend_scm",(void*)f_5564},
{"f_5574:c_backend_scm",(void*)f_5574},
{"f_5549:c_backend_scm",(void*)f_5549},
{"f_5484:c_backend_scm",(void*)f_5484},
{"f_5494:c_backend_scm",(void*)f_5494},
{"f_5487:c_backend_scm",(void*)f_5487},
{"f_4988:c_backend_scm",(void*)f_4988},
{"f_4995:c_backend_scm",(void*)f_4995},
{"f_5069:c_backend_scm",(void*)f_5069},
{"f_5087:c_backend_scm",(void*)f_5087},
{"f_5116:c_backend_scm",(void*)f_5116},
{"f_5138:c_backend_scm",(void*)f_5138},
{"f_5094:c_backend_scm",(void*)f_5094},
{"f_5063:c_backend_scm",(void*)f_5063},
{"f_5059:c_backend_scm",(void*)f_5059},
{"f_5055:c_backend_scm",(void*)f_5055},
{"f_5026:c_backend_scm",(void*)f_5026},
{"f_5030:c_backend_scm",(void*)f_5030},
{"f_4945:c_backend_scm",(void*)f_4945},
{"f_4951:c_backend_scm",(void*)f_4951},
{"f_4980:c_backend_scm",(void*)f_4980},
{"f_4961:c_backend_scm",(void*)f_4961},
{"f_5147:c_backend_scm",(void*)f_5147},
{"f_5287:c_backend_scm",(void*)f_5287},
{"f_5154:c_backend_scm",(void*)f_5154},
{"f_5160:c_backend_scm",(void*)f_5160},
{"f_5243:c_backend_scm",(void*)f_5243},
{"f_5246:c_backend_scm",(void*)f_5246},
{"f_5256:c_backend_scm",(void*)f_5256},
{"f_5249:c_backend_scm",(void*)f_5249},
{"f_5210:c_backend_scm",(void*)f_5210},
{"f_5216:c_backend_scm",(void*)f_5216},
{"f_4982:c_backend_scm",(void*)f_4982},
{"f_5289:c_backend_scm",(void*)f_5289},
{"f_5296:c_backend_scm",(void*)f_5296},
{"f_5299:c_backend_scm",(void*)f_5299},
{"f_5304:c_backend_scm",(void*)f_5304},
{"f_5360:c_backend_scm",(void*)f_5360},
{"f_5356:c_backend_scm",(void*)f_5356},
{"f_5341:c_backend_scm",(void*)f_5341},
{"f_5320:c_backend_scm",(void*)f_5320},
{"f_5331:c_backend_scm",(void*)f_5331},
{"f_5327:c_backend_scm",(void*)f_5327},
{"f_5366:c_backend_scm",(void*)f_5366},
{"f_5373:c_backend_scm",(void*)f_5373},
{"f_5376:c_backend_scm",(void*)f_5376},
{"f_4659:c_backend_scm",(void*)f_4659},
{"f_4826:c_backend_scm",(void*)f_4826},
{"f_4830:c_backend_scm",(void*)f_4830},
{"f_4833:c_backend_scm",(void*)f_4833},
{"f_4836:c_backend_scm",(void*)f_4836},
{"f_4839:c_backend_scm",(void*)f_4839},
{"f_4842:c_backend_scm",(void*)f_4842},
{"f_4943:c_backend_scm",(void*)f_4943},
{"f_4845:c_backend_scm",(void*)f_4845},
{"f_4848:c_backend_scm",(void*)f_4848},
{"f_4854:c_backend_scm",(void*)f_4854},
{"f_4932:c_backend_scm",(void*)f_4932},
{"f_4888:c_backend_scm",(void*)f_4888},
{"f_4894:c_backend_scm",(void*)f_4894},
{"f_4912:c_backend_scm",(void*)f_4912},
{"f_4908:c_backend_scm",(void*)f_4908},
{"f_4904:c_backend_scm",(void*)f_4904},
{"f_4860:c_backend_scm",(void*)f_4860},
{"f_4863:c_backend_scm",(void*)f_4863},
{"f_4866:c_backend_scm",(void*)f_4866},
{"f_4869:c_backend_scm",(void*)f_4869},
{"f_4872:c_backend_scm",(void*)f_4872},
{"f_4882:c_backend_scm",(void*)f_4882},
{"f_4875:c_backend_scm",(void*)f_4875},
{"f_4778:c_backend_scm",(void*)f_4778},
{"f_4797:c_backend_scm",(void*)f_4797},
{"f_4801:c_backend_scm",(void*)f_4801},
{"f_4804:c_backend_scm",(void*)f_4804},
{"f_4807:c_backend_scm",(void*)f_4807},
{"f_4810:c_backend_scm",(void*)f_4810},
{"f_4824:c_backend_scm",(void*)f_4824},
{"f_4820:c_backend_scm",(void*)f_4820},
{"f_4813:c_backend_scm",(void*)f_4813},
{"f_4781:c_backend_scm",(void*)f_4781},
{"f_4795:c_backend_scm",(void*)f_4795},
{"f_4784:c_backend_scm",(void*)f_4784},
{"f_4791:c_backend_scm",(void*)f_4791},
{"f_4698:c_backend_scm",(void*)f_4698},
{"f_4700:c_backend_scm",(void*)f_4700},
{"f_4704:c_backend_scm",(void*)f_4704},
{"f_4707:c_backend_scm",(void*)f_4707},
{"f_4710:c_backend_scm",(void*)f_4710},
{"f_4713:c_backend_scm",(void*)f_4713},
{"f_4716:c_backend_scm",(void*)f_4716},
{"f_4719:c_backend_scm",(void*)f_4719},
{"f_4722:c_backend_scm",(void*)f_4722},
{"f_4725:c_backend_scm",(void*)f_4725},
{"f_4728:c_backend_scm",(void*)f_4728},
{"f_4731:c_backend_scm",(void*)f_4731},
{"f_4734:c_backend_scm",(void*)f_4734},
{"f_4737:c_backend_scm",(void*)f_4737},
{"f_4751:c_backend_scm",(void*)f_4751},
{"f_4747:c_backend_scm",(void*)f_4747},
{"f_4740:c_backend_scm",(void*)f_4740},
{"f_4662:c_backend_scm",(void*)f_4662},
{"f_4675:c_backend_scm",(void*)f_4675},
{"f_4685:c_backend_scm",(void*)f_4685},
{"f_4666:c_backend_scm",(void*)f_4666},
{"f_4408:c_backend_scm",(void*)f_4408},
{"f_4412:c_backend_scm",(void*)f_4412},
{"f_4436:c_backend_scm",(void*)f_4436},
{"f_4440:c_backend_scm",(void*)f_4440},
{"f_4443:c_backend_scm",(void*)f_4443},
{"f_4657:c_backend_scm",(void*)f_4657},
{"f_4446:c_backend_scm",(void*)f_4446},
{"f_4643:c_backend_scm",(void*)f_4643},
{"f_4449:c_backend_scm",(void*)f_4449},
{"f_4452:c_backend_scm",(void*)f_4452},
{"f_4455:c_backend_scm",(void*)f_4455},
{"f_4458:c_backend_scm",(void*)f_4458},
{"f_4461:c_backend_scm",(void*)f_4461},
{"f_4464:c_backend_scm",(void*)f_4464},
{"f_4635:c_backend_scm",(void*)f_4635},
{"f_4467:c_backend_scm",(void*)f_4467},
{"f_4470:c_backend_scm",(void*)f_4470},
{"f_4628:c_backend_scm",(void*)f_4628},
{"f_4609:c_backend_scm",(void*)f_4609},
{"f_4620:c_backend_scm",(void*)f_4620},
{"f_4473:c_backend_scm",(void*)f_4473},
{"f_4560:c_backend_scm",(void*)f_4560},
{"f_4563:c_backend_scm",(void*)f_4563},
{"f_4566:c_backend_scm",(void*)f_4566},
{"f_4569:c_backend_scm",(void*)f_4569},
{"f_4585:c_backend_scm",(void*)f_4585},
{"f_4588:c_backend_scm",(void*)f_4588},
{"f_4591:c_backend_scm",(void*)f_4591},
{"f_4594:c_backend_scm",(void*)f_4594},
{"f_4476:c_backend_scm",(void*)f_4476},
{"f_4479:c_backend_scm",(void*)f_4479},
{"f_4482:c_backend_scm",(void*)f_4482},
{"f_4532:c_backend_scm",(void*)f_4532},
{"f_4535:c_backend_scm",(void*)f_4535},
{"f_4485:c_backend_scm",(void*)f_4485},
{"f_4488:c_backend_scm",(void*)f_4488},
{"f_4520:c_backend_scm",(void*)f_4520},
{"f_4523:c_backend_scm",(void*)f_4523},
{"f_4494:c_backend_scm",(void*)f_4494},
{"f_4503:c_backend_scm",(void*)f_4503},
{"f_4506:c_backend_scm",(void*)f_4506},
{"f_4415:c_backend_scm",(void*)f_4415},
{"f_4420:c_backend_scm",(void*)f_4420},
{"f_4424:c_backend_scm",(void*)f_4424},
{"f_4434:c_backend_scm",(void*)f_4434},
{"f_4427:c_backend_scm",(void*)f_4427},
{"f_4259:c_backend_scm",(void*)f_4259},
{"f_4266:c_backend_scm",(void*)f_4266},
{"f_4402:c_backend_scm",(void*)f_4402},
{"f_4269:c_backend_scm",(void*)f_4269},
{"f_4272:c_backend_scm",(void*)f_4272},
{"f_4275:c_backend_scm",(void*)f_4275},
{"f_4280:c_backend_scm",(void*)f_4280},
{"f_4290:c_backend_scm",(void*)f_4290},
{"f_4296:c_backend_scm",(void*)f_4296},
{"f_4349:c_backend_scm",(void*)f_4349},
{"f_4359:c_backend_scm",(void*)f_4359},
{"f_4299:c_backend_scm",(void*)f_4299},
{"f_4322:c_backend_scm",(void*)f_4322},
{"f_4332:c_backend_scm",(void*)f_4332},
{"f_4302:c_backend_scm",(void*)f_4302},
{"f_4305:c_backend_scm",(void*)f_4305},
{"f_4112:c_backend_scm",(void*)f_4112},
{"f_4251:c_backend_scm",(void*)f_4251},
{"f_4132:c_backend_scm",(void*)f_4132},
{"f_4209:c_backend_scm",(void*)f_4209},
{"f_4213:c_backend_scm",(void*)f_4213},
{"f_4217:c_backend_scm",(void*)f_4217},
{"f_4221:c_backend_scm",(void*)f_4221},
{"f_4243:c_backend_scm",(void*)f_4243},
{"f_4239:c_backend_scm",(void*)f_4239},
{"f_4231:c_backend_scm",(void*)f_4231},
{"f_4229:c_backend_scm",(void*)f_4229},
{"f_4225:c_backend_scm",(void*)f_4225},
{"f_4150:c_backend_scm",(void*)f_4150},
{"f_4153:c_backend_scm",(void*)f_4153},
{"f_4156:c_backend_scm",(void*)f_4156},
{"f_4198:c_backend_scm",(void*)f_4198},
{"f_4159:c_backend_scm",(void*)f_4159},
{"f_4162:c_backend_scm",(void*)f_4162},
{"f_4165:c_backend_scm",(void*)f_4165},
{"f_4180:c_backend_scm",(void*)f_4180},
{"f_4185:c_backend_scm",(void*)f_4185},
{"f_4168:c_backend_scm",(void*)f_4168},
{"f_4115:c_backend_scm",(void*)f_4115},
{"f_4129:c_backend_scm",(void*)f_4129},
{"f_2539:c_backend_scm",(void*)f_2539},
{"f_4080:c_backend_scm",(void*)f_4080},
{"f_4086:c_backend_scm",(void*)f_4086},
{"f_4090:c_backend_scm",(void*)f_4090},
{"f_2542:c_backend_scm",(void*)f_2542},
{"f_4045:c_backend_scm",(void*)f_4045},
{"f_4048:c_backend_scm",(void*)f_4048},
{"f_4051:c_backend_scm",(void*)f_4051},
{"f_4054:c_backend_scm",(void*)f_4054},
{"f_4057:c_backend_scm",(void*)f_4057},
{"f_4060:c_backend_scm",(void*)f_4060},
{"f_3962:c_backend_scm",(void*)f_3962},
{"f_3965:c_backend_scm",(void*)f_3965},
{"f_3968:c_backend_scm",(void*)f_3968},
{"f_3981:c_backend_scm",(void*)f_3981},
{"f_4004:c_backend_scm",(void*)f_4004},
{"f_4007:c_backend_scm",(void*)f_4007},
{"f_4010:c_backend_scm",(void*)f_4010},
{"f_4013:c_backend_scm",(void*)f_4013},
{"f_3991:c_backend_scm",(void*)f_3991},
{"f_3994:c_backend_scm",(void*)f_3994},
{"f_3953:c_backend_scm",(void*)f_3953},
{"f_3925:c_backend_scm",(void*)f_3925},
{"f_3928:c_backend_scm",(void*)f_3928},
{"f_3945:c_backend_scm",(void*)f_3945},
{"f_3931:c_backend_scm",(void*)f_3931},
{"f_3934:c_backend_scm",(void*)f_3934},
{"f_3909:c_backend_scm",(void*)f_3909},
{"f_3913:c_backend_scm",(void*)f_3913},
{"f_3895:c_backend_scm",(void*)f_3895},
{"f_3898:c_backend_scm",(void*)f_3898},
{"f_3879:c_backend_scm",(void*)f_3879},
{"f_3883:c_backend_scm",(void*)f_3883},
{"f_3861:c_backend_scm",(void*)f_3861},
{"f_3864:c_backend_scm",(void*)f_3864},
{"f_3841:c_backend_scm",(void*)f_3841},
{"f_3805:c_backend_scm",(void*)f_3805},
{"f_3817:c_backend_scm",(void*)f_3817},
{"f_3808:c_backend_scm",(void*)f_3808},
{"f_3786:c_backend_scm",(void*)f_3786},
{"f_3789:c_backend_scm",(void*)f_3789},
{"f_3767:c_backend_scm",(void*)f_3767},
{"f_3770:c_backend_scm",(void*)f_3770},
{"f_3748:c_backend_scm",(void*)f_3748},
{"f_3751:c_backend_scm",(void*)f_3751},
{"f_3729:c_backend_scm",(void*)f_3729},
{"f_3725:c_backend_scm",(void*)f_3725},
{"f_3673:c_backend_scm",(void*)f_3673},
{"f_3706:c_backend_scm",(void*)f_3706},
{"f_3676:c_backend_scm",(void*)f_3676},
{"f_3694:c_backend_scm",(void*)f_3694},
{"f_3679:c_backend_scm",(void*)f_3679},
{"f_3682:c_backend_scm",(void*)f_3682},
{"f_3640:c_backend_scm",(void*)f_3640},
{"f_3624:c_backend_scm",(void*)f_3624},
{"f_3627:c_backend_scm",(void*)f_3627},
{"f_3630:c_backend_scm",(void*)f_3630},
{"f_3583:c_backend_scm",(void*)f_3583},
{"f_3586:c_backend_scm",(void*)f_3586},
{"f_3607:c_backend_scm",(void*)f_3607},
{"f_3611:c_backend_scm",(void*)f_3611},
{"f_3614:c_backend_scm",(void*)f_3614},
{"f_3589:c_backend_scm",(void*)f_3589},
{"f_3605:c_backend_scm",(void*)f_3605},
{"f_3597:c_backend_scm",(void*)f_3597},
{"f_3592:c_backend_scm",(void*)f_3592},
{"f_3216:c_backend_scm",(void*)f_3216},
{"f_3219:c_backend_scm",(void*)f_3219},
{"f_3533:c_backend_scm",(void*)f_3533},
{"f_3529:c_backend_scm",(void*)f_3529},
{"f_3225:c_backend_scm",(void*)f_3225},
{"f_3522:c_backend_scm",(void*)f_3522},
{"f_2527:c_backend_scm",(void*)f_2527},
{"f_3515:c_backend_scm",(void*)f_3515},
{"f_3231:c_backend_scm",(void*)f_3231},
{"f_3358:c_backend_scm",(void*)f_3358},
{"f_3442:c_backend_scm",(void*)f_3442},
{"f_3445:c_backend_scm",(void*)f_3445},
{"f_3448:c_backend_scm",(void*)f_3448},
{"f_3463:c_backend_scm",(void*)f_3463},
{"f_3451:c_backend_scm",(void*)f_3451},
{"f_3454:c_backend_scm",(void*)f_3454},
{"f_3457:c_backend_scm",(void*)f_3457},
{"f_3373:c_backend_scm",(void*)f_3373},
{"f_3439:c_backend_scm",(void*)f_3439},
{"f_3432:c_backend_scm",(void*)f_3432},
{"f_3428:c_backend_scm",(void*)f_3428},
{"f_3421:c_backend_scm",(void*)f_3421},
{"f_3414:c_backend_scm",(void*)f_3414},
{"f_3389:c_backend_scm",(void*)f_3389},
{"f_3406:c_backend_scm",(void*)f_3406},
{"f_3402:c_backend_scm",(void*)f_3402},
{"f_3376:c_backend_scm",(void*)f_3376},
{"f_3379:c_backend_scm",(void*)f_3379},
{"f_3382:c_backend_scm",(void*)f_3382},
{"f_3352:c_backend_scm",(void*)f_3352},
{"f_3262:c_backend_scm",(void*)f_3262},
{"f_3336:c_backend_scm",(void*)f_3336},
{"f_3339:c_backend_scm",(void*)f_3339},
{"f_3312:c_backend_scm",(void*)f_3312},
{"f_3315:c_backend_scm",(void*)f_3315},
{"f_3318:c_backend_scm",(void*)f_3318},
{"f_3321:c_backend_scm",(void*)f_3321},
{"f_3324:c_backend_scm",(void*)f_3324},
{"f_3265:c_backend_scm",(void*)f_3265},
{"f_3268:c_backend_scm",(void*)f_3268},
{"f_3295:c_backend_scm",(void*)f_3295},
{"f_3299:c_backend_scm",(void*)f_3299},
{"f_3302:c_backend_scm",(void*)f_3302},
{"f_3271:c_backend_scm",(void*)f_3271},
{"f_3293:c_backend_scm",(void*)f_3293},
{"f_3285:c_backend_scm",(void*)f_3285},
{"f_3274:c_backend_scm",(void*)f_3274},
{"f_3277:c_backend_scm",(void*)f_3277},
{"f_3243:c_backend_scm",(void*)f_3243},
{"f_3246:c_backend_scm",(void*)f_3246},
{"f_3183:c_backend_scm",(void*)f_3183},
{"f_3179:c_backend_scm",(void*)f_3179},
{"f_3165:c_backend_scm",(void*)f_3165},
{"f_3168:c_backend_scm",(void*)f_3168},
{"f_3162:c_backend_scm",(void*)f_3162},
{"f_3158:c_backend_scm",(void*)f_3158},
{"f_3144:c_backend_scm",(void*)f_3144},
{"f_3147:c_backend_scm",(void*)f_3147},
{"f_3096:c_backend_scm",(void*)f_3096},
{"f_3117:c_backend_scm",(void*)f_3117},
{"f_3113:c_backend_scm",(void*)f_3113},
{"f_3099:c_backend_scm",(void*)f_3099},
{"f_3102:c_backend_scm",(void*)f_3102},
{"f_3065:c_backend_scm",(void*)f_3065},
{"f_3061:c_backend_scm",(void*)f_3061},
{"f_3019:c_backend_scm",(void*)f_3019},
{"f_2987:c_backend_scm",(void*)f_2987},
{"f_2990:c_backend_scm",(void*)f_2990},
{"f_2952:c_backend_scm",(void*)f_2952},
{"f_2978:c_backend_scm",(void*)f_2978},
{"f_2964:c_backend_scm",(void*)f_2964},
{"f_2968:c_backend_scm",(void*)f_2968},
{"f_2971:c_backend_scm",(void*)f_2971},
{"f_2955:c_backend_scm",(void*)f_2955},
{"f_2920:c_backend_scm",(void*)f_2920},
{"f_2923:c_backend_scm",(void*)f_2923},
{"f_2926:c_backend_scm",(void*)f_2926},
{"f_2929:c_backend_scm",(void*)f_2929},
{"f_2891:c_backend_scm",(void*)f_2891},
{"f_2894:c_backend_scm",(void*)f_2894},
{"f_2897:c_backend_scm",(void*)f_2897},
{"f_2900:c_backend_scm",(void*)f_2900},
{"f_2854:c_backend_scm",(void*)f_2854},
{"f_2857:c_backend_scm",(void*)f_2857},
{"f_2860:c_backend_scm",(void*)f_2860},
{"f_2863:c_backend_scm",(void*)f_2863},
{"f_2821:c_backend_scm",(void*)f_2821},
{"f_2824:c_backend_scm",(void*)f_2824},
{"f_2827:c_backend_scm",(void*)f_2827},
{"f_2830:c_backend_scm",(void*)f_2830},
{"f_2802:c_backend_scm",(void*)f_2802},
{"f_2805:c_backend_scm",(void*)f_2805},
{"f_2775:c_backend_scm",(void*)f_2775},
{"f_2778:c_backend_scm",(void*)f_2778},
{"f_2724:c_backend_scm",(void*)f_2724},
{"f_2734:c_backend_scm",(void*)f_2734},
{"f_2737:c_backend_scm",(void*)f_2737},
{"f_2740:c_backend_scm",(void*)f_2740},
{"f_2666:c_backend_scm",(void*)f_2666},
{"f_2669:c_backend_scm",(void*)f_2669},
{"f_2672:c_backend_scm",(void*)f_2672},
{"f_2675:c_backend_scm",(void*)f_2675},
{"f_2678:c_backend_scm",(void*)f_2678},
{"f_2681:c_backend_scm",(void*)f_2681},
{"f_2529:c_backend_scm",(void*)f_2529},
{"f_2537:c_backend_scm",(void*)f_2537},
{"f_2497:c_backend_scm",(void*)f_2497},
{"f_2509:c_backend_scm",(void*)f_2509},
{"f_2517:c_backend_scm",(void*)f_2517},
{"f_2501:c_backend_scm",(void*)f_2501},
{"f_2474:c_backend_scm",(void*)f_2474},
{"f_2488:c_backend_scm",(void*)f_2488},
{"f_2480:c_backend_scm",(void*)f_2480},
{"f_2453:c_backend_scm",(void*)f_2453},
{"f_2459:c_backend_scm",(void*)f_2459},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
