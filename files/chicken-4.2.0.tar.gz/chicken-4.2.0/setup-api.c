/* Generated from setup-api.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2009-09-21 21:28
   Version 4.0.1 - SVN rev. 14292
   linux-unix-gnu-x86 [ manyargs dload ptables applyhook ]
   compiled 2009-05-12 on galinha (Linux)
   command line: setup-api.scm -no-trace -optimize-level 2 -include-path . -include-path ./ -feature chicken-compile-shared -dynamic -emit-import-library setup-api -ignore-repository -output-file setup-api.c
   used units: library eval data_structures ports extras srfi_69 srfi_1 regex utils posix srfi_13 extras ports data_structures files
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_69_toplevel)
C_externimport void C_ccall C_srfi_69_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_1_toplevel)
C_externimport void C_ccall C_srfi_1_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_regex_toplevel)
C_externimport void C_ccall C_regex_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_utils_toplevel)
C_externimport void C_ccall C_utils_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_posix_toplevel)
C_externimport void C_ccall C_posix_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_13_toplevel)
C_externimport void C_ccall C_srfi_13_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_files_toplevel)
C_externimport void C_ccall C_files_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[324];
static double C_possibly_force_alignment;
static C_char C_TLS li0[] C_aligned={C_lihdr(0,0,28),40,115,101,116,117,112,45,97,112,105,35,115,104,101,108,108,112,97,116,104,32,115,116,114,49,49,57,41,0,0,0,0};
static C_char C_TLS li1[] C_aligned={C_lihdr(0,0,25),40,115,101,116,117,112,45,97,112,105,35,99,114,111,115,115,45,99,104,105,99,107,101,110,41,0,0,0,0,0,0,0};
static C_char C_TLS li2[] C_aligned={C_lihdr(0,0,30),40,115,101,116,117,112,45,97,112,105,35,117,115,101,114,45,105,110,115,116,97,108,108,45,115,101,116,117,112,41,0,0};
static C_char C_TLS li3[] C_aligned={C_lihdr(0,0,34),40,115,101,116,117,112,45,97,112,105,35,115,117,100,111,45,105,110,115,116,97,108,108,32,46,32,97,114,103,115,49,53,51,41,0,0,0,0,0,0};
static C_char C_TLS li4[] C_aligned={C_lihdr(0,0,13),40,108,111,111,112,32,100,105,114,49,55,49,41,0,0,0};
static C_char C_TLS li5[] C_aligned={C_lihdr(0,0,27),40,99,114,101,97,116,101,45,100,105,114,101,99,116,111,114,121,45,48,32,100,105,114,49,54,55,41,0,0,0,0,0};
static C_char C_TLS li6[] C_aligned={C_lihdr(0,0,13),40,118,101,114,98,32,100,105,114,49,56,48,41,0,0,0};
static C_char C_TLS li7[] C_aligned={C_lihdr(0,0,15),40,102,95,52,56,57,53,32,100,105,114,49,56,52,41,0};
static C_char C_TLS li8[] C_aligned={C_lihdr(0,0,15),40,102,95,52,57,48,51,32,100,105,114,49,56,55,41,0};
static C_char C_TLS li9[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li10[] C_aligned={C_lihdr(0,0,7),40,97,50,48,51,53,41,0};
static C_char C_TLS li11[] C_aligned={C_lihdr(0,0,41),40,115,101,116,117,112,45,97,112,105,35,121,101,115,45,111,114,45,110,111,63,32,115,116,114,49,57,57,32,46,32,116,109,112,49,57,56,50,48,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li12[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li13[] C_aligned={C_lihdr(0,0,7),40,97,50,48,55,48,41,0};
static C_char C_TLS li14[] C_aligned={C_lihdr(0,0,7),40,97,50,48,54,48,41,0};
static C_char C_TLS li15[] C_aligned={C_lihdr(0,0,41),40,115,101,116,117,112,45,97,112,105,35,112,97,116,99,104,32,119,104,105,99,104,50,52,48,32,114,120,50,52,49,32,115,117,98,115,116,50,52,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li16[] C_aligned={C_lihdr(0,0,33),40,115,101,116,117,112,45,97,112,105,35,102,105,120,109,97,107,101,116,97,114,103,101,116,32,102,105,108,101,50,55,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li17[] C_aligned={C_lihdr(0,0,15),40,115,109,111,111,116,104,32,108,115,116,50,56,55,41,0};
static C_char C_TLS li18[] C_aligned={C_lihdr(0,0,14),40,97,50,50,53,51,32,99,109,100,50,57,49,41,0,0};
static C_char C_TLS li19[] C_aligned={C_lihdr(0,0,30),40,115,101,116,117,112,45,97,112,105,35,101,120,101,99,117,116,101,32,101,120,112,108,105,115,116,50,56,52,41,0,0};
static C_char C_TLS li20[] C_aligned={C_lihdr(0,0,37),40,115,101,116,117,112,45,97,112,105,35,109,97,107,101,58,102,111,114,109,45,101,114,114,111,114,32,115,51,57,55,32,112,51,57,56,41,0,0,0};
static C_char C_TLS li21[] C_aligned={C_lihdr(0,0,42),40,115,101,116,117,112,45,97,112,105,35,109,97,107,101,58,108,105,110,101,45,101,114,114,111,114,32,115,52,48,49,32,112,52,48,50,32,110,52,48,51,41,0,0,0,0,0,0};
static C_char C_TLS li22[] C_aligned={C_lihdr(0,0,7),40,97,50,54,49,52,41,0};
static C_char C_TLS li23[] C_aligned={C_lihdr(0,0,14),40,97,50,54,48,56,32,101,120,110,53,55,51,41,0,0};
static C_char C_TLS li24[] C_aligned={C_lihdr(0,0,7),40,97,50,54,52,51,41,0};
static C_char C_TLS li25[] C_aligned={C_lihdr(0,0,7),40,97,50,54,53,56,41,0};
static C_char C_TLS li26[] C_aligned={C_lihdr(0,0,20),40,97,50,54,53,50,32,46,32,97,114,103,115,53,54,55,53,55,57,41,0,0,0,0};
static C_char C_TLS li27[] C_aligned={C_lihdr(0,0,7),40,97,50,54,51,55,41,0};
static C_char C_TLS li28[] C_aligned={C_lihdr(0,0,15),40,97,50,54,48,50,32,107,53,54,54,53,55,49,41,0};
static C_char C_TLS li29[] C_aligned={C_lihdr(0,0,14),40,97,50,54,57,57,32,100,101,112,53,52,49,41,0,0};
static C_char C_TLS li30[] C_aligned={C_lihdr(0,0,12),40,97,50,55,50,56,32,100,53,51,50,41,0,0,0,0};
static C_char C_TLS li31[] C_aligned={C_lihdr(0,0,13),40,109,97,116,99,104,63,32,115,51,55,52,41,0,0,0};
static C_char C_TLS li32[] C_aligned={C_lihdr(0,0,15),40,108,111,111,112,32,108,105,110,101,115,51,55,57,41,0};
static C_char C_TLS li33[] C_aligned={C_lihdr(0,0,23),40,102,95,50,53,52,56,32,115,53,49,51,32,105,110,100,101,110,116,53,49,52,41,0};
static C_char C_TLS li34[] C_aligned={C_lihdr(0,0,15),40,97,50,55,55,49,32,105,116,101,109,54,48,48,41,0};
static C_char C_TLS li35[] C_aligned={C_lihdr(0,0,12),40,97,50,56,48,51,32,102,53,57,54,41,0,0,0,0};
static C_char C_TLS li36[] C_aligned={C_lihdr(0,0,14),40,97,50,52,52,49,32,100,101,112,52,54,54,41,0,0};
static C_char C_TLS li37[] C_aligned={C_lihdr(0,0,15),40,97,50,51,55,50,32,108,105,110,101,52,50,52,41,0};
static C_char C_TLS li38[] C_aligned={C_lihdr(0,0,49),40,115,101,116,117,112,45,97,112,105,35,109,97,107,101,58,109,97,107,101,47,112,114,111,99,47,104,101,108,112,101,114,32,115,112,101,99,53,48,51,32,97,114,103,118,53,48,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li39[] C_aligned={C_lihdr(0,0,45),40,115,101,116,117,112,45,97,112,105,35,109,97,107,101,47,112,114,111,99,32,103,54,49,48,54,49,49,54,50,50,32,46,32,114,118,97,114,54,49,50,54,50,51,41,0,0,0};
static C_char C_TLS li40[] C_aligned={C_lihdr(0,0,13),40,118,101,114,98,32,100,105,114,55,50,57,41,0,0,0};
static C_char C_TLS li41[] C_aligned={C_lihdr(0,0,15),40,102,95,52,56,53,50,32,100,105,114,55,51,51,41,0};
static C_char C_TLS li42[] C_aligned={C_lihdr(0,0,15),40,102,95,52,56,54,48,32,100,105,114,55,51,54,41,0};
static C_char C_TLS li43[] C_aligned={C_lihdr(0,0,7),40,97,50,57,56,55,41,0};
static C_char C_TLS li44[] C_aligned={C_lihdr(0,0,7),40,97,50,57,57,54,41,0};
static C_char C_TLS li45[] C_aligned={C_lihdr(0,0,45),40,115,101,116,117,112,45,97,112,105,35,119,114,105,116,101,45,105,110,102,111,32,105,100,55,52,55,32,102,105,108,101,115,55,52,56,32,105,110,102,111,55,52,57,41,0,0,0};
static C_char C_TLS li46[] C_aligned={C_lihdr(0,0,26),40,98,111,100,121,56,50,49,32,101,114,114,56,51,49,32,112,114,101,102,105,120,56,51,50,41,0,0,0,0,0,0};
static C_char C_TLS li47[] C_aligned={C_lihdr(0,0,26),40,100,101,102,45,112,114,101,102,105,120,56,50,52,32,37,101,114,114,56,49,57,56,54,52,41,0,0,0,0,0,0};
static C_char C_TLS li48[] C_aligned={C_lihdr(0,0,12),40,100,101,102,45,101,114,114,56,50,51,41,0,0,0,0};
static C_char C_TLS li49[] C_aligned={C_lihdr(0,0,47),40,115,101,116,117,112,45,97,112,105,35,99,111,112,121,45,102,105,108,101,32,102,114,111,109,56,49,48,32,116,111,56,49,49,32,46,32,116,109,112,56,48,57,56,49,50,41,0};
static C_char C_TLS li50[] C_aligned={C_lihdr(0,0,35),40,115,101,116,117,112,45,97,112,105,35,109,111,118,101,45,102,105,108,101,32,102,114,111,109,56,55,56,32,116,111,56,55,57,41,0,0,0,0,0};
static C_char C_TLS li51[] C_aligned={C_lihdr(0,0,31),40,115,101,116,117,112,45,97,112,105,35,114,101,109,111,118,101,45,102,105,108,101,42,32,100,105,114,56,57,50,41,0};
static C_char C_TLS li52[] C_aligned={C_lihdr(0,0,46),40,115,101,116,117,112,45,97,112,105,35,109,97,107,101,45,100,101,115,116,45,112,97,116,104,110,97,109,101,32,112,97,116,104,57,48,49,32,102,105,108,101,57,48,50,41,0,0};
static C_char C_TLS li53[] C_aligned={C_lihdr(0,0,12),40,97,51,50,56,50,32,102,57,48,55,41,0,0,0,0};
static C_char C_TLS li54[] C_aligned={C_lihdr(0,0,35),40,115,101,116,117,112,45,97,112,105,35,99,104,101,99,107,45,102,105,108,101,108,105,115,116,32,102,108,105,115,116,57,48,53,41,0,0,0,0,0};
static C_char C_TLS li55[] C_aligned={C_lihdr(0,0,13),40,97,51,52,51,51,32,102,49,48,53,48,41,0,0,0};
static C_char C_TLS li56[] C_aligned={C_lihdr(0,0,13),40,97,51,52,55,55,32,102,49,48,52,49,41,0,0,0};
static C_char C_TLS li57[] C_aligned={C_lihdr(0,0,12),40,97,51,52,57,56,32,102,57,56,54,41,0,0,0,0};
static C_char C_TLS li58[] C_aligned={C_lihdr(0,0,56),40,115,101,116,117,112,45,97,112,105,35,105,110,115,116,97,108,108,45,101,120,116,101,110,115,105,111,110,32,105,100,57,54,50,32,102,105,108,101,115,57,54,51,32,46,32,116,109,112,57,54,49,57,54,52,41};
static C_char C_TLS li59[] C_aligned={C_lihdr(0,0,13),40,101,120,105,102,121,32,102,49,48,57,49,41,0,0,0};
static C_char C_TLS li60[] C_aligned={C_lihdr(0,0,13),40,97,51,55,48,52,32,102,49,49,48,54,41,0,0,0};
static C_char C_TLS li61[] C_aligned={C_lihdr(0,0,13),40,97,51,55,53,49,32,102,49,49,48,50,41,0,0,0};
static C_char C_TLS li62[] C_aligned={C_lihdr(0,0,58),40,115,101,116,117,112,45,97,112,105,35,105,110,115,116,97,108,108,45,112,114,111,103,114,97,109,32,105,100,49,48,55,52,32,102,105,108,101,115,49,48,55,53,32,46,32,116,109,112,49,48,55,51,49,48,55,54,41,0,0,0,0,0,0};
static C_char C_TLS li63[] C_aligned={C_lihdr(0,0,13),40,97,51,56,55,52,32,102,49,49,53,54,41,0,0,0};
static C_char C_TLS li64[] C_aligned={C_lihdr(0,0,57),40,115,101,116,117,112,45,97,112,105,35,105,110,115,116,97,108,108,45,115,99,114,105,112,116,32,105,100,49,49,51,49,32,102,105,108,101,115,49,49,51,50,32,46,32,116,109,112,49,49,51,48,49,49,51,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li65[] C_aligned={C_lihdr(0,0,33),40,115,101,116,117,112,45,97,112,105,35,114,101,112,111,45,112,97,116,104,32,116,109,112,49,49,56,56,49,49,56,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li66[] C_aligned={C_lihdr(0,0,37),40,115,101,116,117,112,45,97,112,105,35,101,110,115,117,114,101,45,100,105,114,101,99,116,111,114,121,32,112,97,116,104,49,50,48,55,41,0,0,0};
static C_char C_TLS li67[] C_aligned={C_lihdr(0,0,7),40,97,52,49,53,48,41,0};
static C_char C_TLS li68[] C_aligned={C_lihdr(0,0,7),40,97,52,49,53,54,41,0};
static C_char C_TLS li69[] C_aligned={C_lihdr(0,0,7),40,97,52,49,53,57,41,0};
static C_char C_TLS li70[] C_aligned={C_lihdr(0,0,7),40,97,52,49,54,53,41,0};
static C_char C_TLS li71[] C_aligned={C_lihdr(0,0,7),40,97,52,49,54,56,41,0};
static C_char C_TLS li72[] C_aligned={C_lihdr(0,0,7),40,97,52,49,55,49,41,0};
static C_char C_TLS li73[] C_aligned={C_lihdr(0,0,46),40,115,101,116,117,112,45,97,112,105,35,116,114,121,45,99,111,109,112,105,108,101,32,99,111,100,101,49,50,51,51,32,46,32,116,109,112,49,50,51,50,49,50,51,52,41,0,0};
static C_char C_TLS li74[] C_aligned={C_lihdr(0,0,42),40,115,101,116,117,112,45,97,112,105,35,114,101,113,117,105,114,101,100,45,99,104,105,99,107,101,110,45,118,101,114,115,105,111,110,32,118,49,50,56,48,41,0,0,0,0,0,0};
static C_char C_TLS li75[] C_aligned={C_lihdr(0,0,43),40,115,101,116,117,112,45,97,112,105,35,117,112,103,114,97,100,101,45,109,101,115,115,97,103,101,32,101,120,116,49,50,56,53,32,109,115,103,49,50,56,54,41,0,0,0,0,0};
static C_char C_TLS li76[] C_aligned={C_lihdr(0,0,15),40,108,111,111,112,32,97,114,103,115,49,50,57,51,41,0};
static C_char C_TLS li77[] C_aligned={C_lihdr(0,0,49),40,115,101,116,117,112,45,97,112,105,35,114,101,113,117,105,114,101,100,45,101,120,116,101,110,115,105,111,110,45,118,101,114,115,105,111,110,32,46,32,97,114,103,115,49,50,56,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li78[] C_aligned={C_lihdr(0,0,42),40,115,101,116,117,112,45,97,112,105,35,102,105,110,100,45,108,105,98,114,97,114,121,32,110,97,109,101,49,51,51,48,32,112,114,111,99,49,51,51,49,41,0,0,0,0,0,0};
static C_char C_TLS li79[] C_aligned={C_lihdr(0,0,32),40,115,101,116,117,112,45,97,112,105,35,102,105,110,100,45,104,101,97,100,101,114,32,110,97,109,101,49,51,51,52,41};
static C_char C_TLS li80[] C_aligned={C_lihdr(0,0,13),40,97,52,51,52,57,32,120,49,51,52,51,41,0,0,0};
static C_char C_TLS li81[] C_aligned={C_lihdr(0,0,21),40,118,101,114,115,105,111,110,45,62,108,105,115,116,32,118,49,51,52,49,41,0,0,0};
static C_char C_TLS li82[] C_aligned={C_lihdr(0,0,20),40,108,111,111,112,32,112,49,49,51,53,51,32,112,50,49,51,53,52,41,0,0,0,0};
static C_char C_TLS li83[] C_aligned={C_lihdr(0,0,36),40,115,101,116,117,112,45,97,112,105,35,118,101,114,115,105,111,110,62,61,63,32,118,49,49,51,51,55,32,118,50,49,51,51,56,41,0,0,0,0};
static C_char C_TLS li84[] C_aligned={C_lihdr(0,0,26),40,115,101,116,117,112,45,97,112,105,35,101,120,116,101,110,115,105,111,110,45,110,97,109,101,41,0,0,0,0,0,0};
static C_char C_TLS li85[] C_aligned={C_lihdr(0,0,43),40,115,101,116,117,112,45,97,112,105,35,101,120,116,101,110,115,105,111,110,45,118,101,114,115,105,111,110,32,46,32,116,109,112,49,52,51,52,49,52,51,53,41,0,0,0,0,0};
static C_char C_TLS li86[] C_aligned={C_lihdr(0,0,29),40,115,101,116,117,112,45,97,112,105,35,114,101,97,100,45,105,110,102,111,32,101,103,103,49,52,53,50,41,0,0,0};
static C_char C_TLS li87[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li88[] C_aligned={C_lihdr(0,0,38),40,115,101,116,117,112,45,97,112,105,35,99,114,101,97,116,101,45,116,101,109,112,111,114,97,114,121,45,100,105,114,101,99,116,111,114,121,41,0,0};
static C_char C_TLS li89[] C_aligned={C_lihdr(0,0,13),40,97,52,54,55,53,32,102,49,53,50,56,41,0,0,0};
static C_char C_TLS li90[] C_aligned={C_lihdr(0,0,14),40,119,97,108,107,32,100,105,114,49,53,50,52,41,0,0};
static C_char C_TLS li91[] C_aligned={C_lihdr(0,0,50),40,115,101,116,117,112,45,97,112,105,35,114,101,109,111,118,101,45,100,105,114,101,99,116,111,114,121,32,100,105,114,49,53,48,50,32,46,32,116,109,112,49,53,48,49,49,53,48,51,41,0,0,0,0,0,0};
static C_char C_TLS li92[] C_aligned={C_lihdr(0,0,36),40,115,101,116,117,112,45,97,112,105,35,114,101,109,111,118,101,45,101,120,116,101,110,115,105,111,110,32,101,103,103,49,53,52,52,41,0,0,0,0};
static C_char C_TLS li93[] C_aligned={C_lihdr(0,0,27),40,115,101,116,117,112,45,97,112,105,35,36,115,121,115,116,101,109,32,115,116,114,49,53,53,51,41,0,0,0,0,0};
static C_char C_TLS li94[] C_aligned={C_lihdr(0,0,21),40,101,110,115,117,114,101,45,115,116,114,105,110,103,32,120,49,52,49,54,41,0,0,0};
static C_char C_TLS li95[] C_aligned={C_lihdr(0,0,13),40,97,52,55,56,49,32,120,49,51,57,54,41,0,0,0};
static C_char C_TLS li96[] C_aligned={C_lihdr(0,0,10),40,116,111,112,108,101,118,101,108,41,0,0,0,0,0,0};


C_noret_decl(C_toplevel)
C_externexport void C_ccall C_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1669)
static void C_ccall f_1669(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1672)
static void C_ccall f_1672(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1675)
static void C_ccall f_1675(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1678)
static void C_ccall f_1678(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1681)
static void C_ccall f_1681(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1684)
static void C_ccall f_1684(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1687)
static void C_ccall f_1687(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1690)
static void C_ccall f_1690(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1693)
static void C_ccall f_1693(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1696)
static void C_ccall f_1696(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1699)
static void C_ccall f_1699(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1702)
static void C_ccall f_1702(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1705)
static void C_ccall f_1705(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1708)
static void C_ccall f_1708(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1711)
static void C_ccall f_1711(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4997)
static void C_ccall f_4997(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4993)
static void C_ccall f_4993(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4989)
static void C_ccall f_4989(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4985)
static void C_ccall f_4985(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1720)
static void C_ccall f_1720(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1724)
static void C_ccall f_1724(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1728)
static void C_ccall f_1728(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1732)
static void C_ccall f_1732(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1736)
static void C_ccall f_1736(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4953)
static void C_ccall f_4953(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1742)
static void C_ccall f_1742(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1745)
static void C_ccall f_1745(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1749)
static void C_ccall f_1749(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1753)
static void C_ccall f_1753(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1756)
static void C_ccall f_1756(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1759)
static void C_ccall f_1759(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1763)
static void C_ccall f_1763(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1766)
static void C_ccall f_1766(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4934)
static void C_ccall f_4934(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1769)
static void C_ccall f_1769(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1773)
static void C_ccall f_1773(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4921)
static void C_ccall f_4921(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1776)
static void C_fcall f_1776(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1797)
static void C_ccall f_1797(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1801)
static void C_ccall f_1801(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1805)
static void C_ccall f_1805(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1809)
static void C_ccall f_1809(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1815)
static void C_ccall f_1815(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1819)
static void C_ccall f_1819(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1908)
static void C_ccall f_1908(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1960)
static void C_ccall f_1960(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2132)
static void C_ccall f_2132(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4891)
static void C_ccall f_4891(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2893)
static void C_ccall f_2893(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4782)
static void C_ccall f_4782(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4798)
static void C_fcall f_4798(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4835)
static void C_ccall f_4835(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4828)
static void C_ccall f_4828(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4832)
static void C_ccall f_4832(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4805)
static void C_fcall f_4805(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4506)
static void C_ccall f_4506(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4760)
static void C_fcall f_4760(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4777)
static void C_ccall f_4777(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4764)
static void C_ccall f_4764(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4729)
static void C_ccall f_4729(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4758)
static void C_ccall f_4758(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4736)
static void C_ccall f_4736(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4747)
static void C_ccall f_4747(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4743)
static void C_ccall f_4743(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4629)
static void C_ccall f_4629(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4629)
static void C_ccall f_4629r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4633)
static void C_ccall f_4633(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4708)
static void C_ccall f_4708(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4664)
static void C_fcall f_4664(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4668)
static void C_ccall f_4668(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4676)
static void C_ccall f_4676(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4689)
static void C_ccall f_4689(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4695)
static void C_ccall f_4695(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4671)
static void C_ccall f_4671(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4659)
static void C_ccall f_4659(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4655)
static void C_ccall f_4655(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4576)
static void C_ccall f_4576(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4580)
static void C_ccall f_4580(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4618)
static void C_ccall f_4618(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4624)
static void C_ccall f_4624(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4583)
static void C_fcall f_4583(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4588)
static void C_fcall f_4588(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4615)
static void C_ccall f_4615(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4611)
static void C_ccall f_4611(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4595)
static void C_ccall f_4595(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4601)
static void C_ccall f_4601(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4607)
static void C_ccall f_4607(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4562)
static void C_ccall f_4562(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4574)
static void C_ccall f_4574(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4570)
static void C_ccall f_4570(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4518)
static void C_ccall f_4518(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4518)
static void C_ccall f_4518r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4522)
static void C_ccall f_4522(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4541)
static void C_ccall f_4541(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4531)
static void C_ccall f_4531(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4508)
static void C_ccall f_4508(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4516)
static void C_ccall f_4516(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4341)
static void C_ccall f_4341(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4372)
static void C_ccall f_4372(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4376)
static void C_ccall f_4376(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4378)
static void C_fcall f_4378(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4458)
static void C_ccall f_4458(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4344)
static void C_fcall f_4344(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4365)
static void C_ccall f_4365(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4361)
static void C_ccall f_4361(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4350)
static void C_ccall f_4350(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4354)
static void C_ccall f_4354(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4331)
static void C_ccall f_4331(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4339)
static void C_ccall f_4339(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4317)
static void C_ccall f_4317(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4325)
static void C_ccall f_4325(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4329)
static void C_ccall f_4329(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4208)
static void C_ccall f_4208(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4208)
static void C_ccall f_4208r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4214)
static void C_fcall f_4214(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4227)
static void C_fcall f_4227(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4239)
static void C_ccall f_4239(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4245)
static void C_fcall f_4245(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4273)
static void C_ccall f_4273(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4284)
static void C_ccall f_4284(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4288)
static void C_ccall f_4288(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4260)
static void C_fcall f_4260(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4267)
static void C_ccall f_4267(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4198)
static void C_fcall f_4198(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4206)
static void C_ccall f_4206(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4178)
static void C_ccall f_4178(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4196)
static void C_ccall f_4196(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4185)
static void C_ccall f_4185(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4192)
static void C_ccall f_4192(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4066)
static void C_ccall f_4066(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4066)
static void C_ccall f_4066r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4070)
static void C_ccall f_4070(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4172)
static void C_ccall f_4172(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4073)
static void C_ccall f_4073(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4169)
static void C_ccall f_4169(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4076)
static void C_ccall f_4076(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4166)
static void C_ccall f_4166(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4079)
static void C_ccall f_4079(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4160)
static void C_ccall f_4160(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4082)
static void C_ccall f_4082(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4157)
static void C_ccall f_4157(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4085)
static void C_ccall f_4085(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4088)
static void C_ccall f_4088(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4091)
static void C_ccall f_4091(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4151)
static void C_ccall f_4151(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4094)
static void C_ccall f_4094(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4142)
static void C_ccall f_4142(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4128)
static void C_ccall f_4128(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4131)
static void C_ccall f_4131(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4097)
static void C_ccall f_4097(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4100)
static void C_ccall f_4100(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4114)
static void C_ccall f_4114(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4110)
static void C_ccall f_4110(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4103)
static void C_ccall f_4103(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4013)
static void C_fcall f_4013(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4017)
static void C_ccall f_4017(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4026)
static void C_ccall f_4026(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4038)
static void C_ccall f_4038(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4064)
static void C_ccall f_4064(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4032)
static void C_ccall f_4032(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4020)
static void C_ccall f_4020(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3958)
static void C_fcall f_3958(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3962)
static void C_ccall f_3962(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3971)
static void C_ccall f_3971(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3978)
static void C_ccall f_3978(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3982)
static void C_ccall f_3982(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3965)
static void C_ccall f_3965(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3968)
static void C_ccall f_3968(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3822)
static void C_ccall f_3822(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3822)
static void C_ccall f_3822r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3826)
static void C_ccall f_3826(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3832)
static void C_ccall f_3832(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3835)
static void C_ccall f_3835(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3838)
static void C_ccall f_3838(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3924)
static void C_ccall f_3924(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3841)
static void C_ccall f_3841(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3875)
static void C_ccall f_3875(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3882)
static void C_ccall f_3882(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3885)
static void C_ccall f_3885(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3911)
static void C_ccall f_3911(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3888)
static void C_ccall f_3888(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3844)
static void C_ccall f_3844(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3873)
static void C_ccall f_3873(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3847)
static void C_ccall f_3847(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3665)
static void C_ccall f_3665(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3665)
static void C_ccall f_3665r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3669)
static void C_ccall f_3669(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3685)
static void C_ccall f_3685(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3688)
static void C_ccall f_3688(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3691)
static void C_ccall f_3691(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3788)
static void C_ccall f_3788(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3694)
static void C_ccall f_3694(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3752)
static void C_ccall f_3752(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3766)
static void C_ccall f_3766(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3770)
static void C_ccall f_3770(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3697)
static void C_ccall f_3697(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3705)
static void C_ccall f_3705(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3712)
static void C_ccall f_3712(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3715)
static void C_ccall f_3715(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3741)
static void C_ccall f_3741(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3718)
static void C_ccall f_3718(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3700)
static void C_ccall f_3700(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3671)
static void C_fcall f_3671(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3331)
static void C_ccall f_3331(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3338)
static void C_ccall f_3338(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3341)
static void C_fcall f_3341(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3380)
static void C_ccall f_3380(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3380)
static void C_ccall f_3380r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3384)
static void C_ccall f_3384(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3390)
static void C_ccall f_3390(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3393)
static void C_ccall f_3393(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3396)
static void C_ccall f_3396(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3399)
static void C_ccall f_3399(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3499)
static void C_ccall f_3499(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3506)
static void C_ccall f_3506(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3628)
static void C_ccall f_3628(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3599)
static void C_fcall f_3599(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3618)
static void C_ccall f_3618(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3509)
static void C_ccall f_3509(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3512)
static void C_ccall f_3512(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3596)
static void C_ccall f_3596(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3515)
static void C_ccall f_3515(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3573)
static void C_ccall f_3573(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3565)
static void C_ccall f_3565(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3530)
static void C_fcall f_3530(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3549)
static void C_ccall f_3549(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3521)
static void C_ccall f_3521(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3402)
static void C_ccall f_3402(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3405)
static void C_ccall f_3405(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3497)
static void C_ccall f_3497(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3408)
static void C_ccall f_3408(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3470)
static void C_ccall f_3470(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3478)
static void C_ccall f_3478(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3486)
static void C_ccall f_3486(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3473)
static void C_ccall f_3473(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3414)
static void C_ccall f_3414(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3426)
static void C_ccall f_3426(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3434)
static void C_ccall f_3434(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3438)
static void C_ccall f_3438(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3441)
static void C_ccall f_3441(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3429)
static void C_ccall f_3429(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3420)
static void C_ccall f_3420(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3277)
static void C_fcall f_3277(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3283)
static void C_ccall f_3283(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3296)
static void C_ccall f_3296(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3299)
static void C_fcall f_3299(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3252)
static void C_fcall f_3252(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3272)
static void C_ccall f_3272(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3230)
static void C_ccall f_3230(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3250)
static void C_ccall f_3250(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3175)
static void C_ccall f_3175(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3182)
static void C_ccall f_3182(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3185)
static void C_ccall f_3185(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3204)
static void C_ccall f_3204(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3212)
static void C_ccall f_3212(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3025)
static void C_ccall f_3025(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3025)
static void C_ccall f_3025r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3127)
static void C_fcall f_3127(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3118)
static void C_fcall f_3118(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3126)
static void C_ccall f_3126(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3027)
static void C_fcall f_3027(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3034)
static void C_ccall f_3034(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3101)
static void C_ccall f_3101(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3091)
static void C_fcall f_3091(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3037)
static void C_ccall f_3037(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3040)
static void C_ccall f_3040(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3046)
static void C_ccall f_3046(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3049)
static void C_ccall f_3049(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3068)
static void C_ccall f_3068(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3076)
static void C_ccall f_3076(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3052)
static void C_ccall f_3052(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2911)
static void C_fcall f_2911(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3023)
static void C_ccall f_3023(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3019)
static void C_ccall f_3019(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3008)
static void C_ccall f_3008(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2918)
static void C_ccall f_2918(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2921)
static void C_ccall f_2921(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3005)
static void C_ccall f_3005(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2864)
static void C_ccall f_2864(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2924)
static void C_ccall f_2924(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2997)
static void C_ccall f_2997(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2956)
static void C_ccall f_2956(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2988)
static void C_ccall f_2988(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2959)
static void C_ccall f_2959(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2978)
static void C_ccall f_2978(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2986)
static void C_ccall f_2986(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2927)
static void C_ccall f_2927(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2953)
static void C_ccall f_2953(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4860)
static void C_ccall f_4860(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4864)
static void C_ccall f_4864(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4887)
static void C_ccall f_4887(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4852)
static void C_ccall f_4852(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4856)
static void C_ccall f_4856(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2896)
static void C_fcall f_2896(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2903)
static void C_ccall f_2903(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2817)
static void C_ccall f_2817(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2817)
static void C_ccall f_2817r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2849)
static void C_ccall f_2849(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2527)
static void C_fcall f_2527(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2815)
static void C_ccall f_2815(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2531)
static void C_fcall f_2531(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2359)
static void C_ccall f_2359(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2368)
static void C_ccall f_2368(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2373)
static void C_ccall f_2373(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2380)
static void C_ccall f_2380(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2383)
static void C_ccall f_2383(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2392)
static void C_ccall f_2392(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2395)
static void C_ccall f_2395(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2434)
static void C_ccall f_2434(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2442)
static void C_ccall f_2442(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2404)
static void C_ccall f_2404(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2534)
static void C_ccall f_2534(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2519)
static void C_ccall f_2519(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2537)
static void C_ccall f_2537(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2542)
static void C_ccall f_2542(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2546)
static void C_ccall f_2546(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2804)
static void C_ccall f_2804(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2799)
static void C_ccall f_2799(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2761)
static void C_ccall f_2761(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2767)
static void C_ccall f_2767(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2780)
static void C_ccall f_2780(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2772)
static void C_ccall f_2772(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2548)
static void C_ccall f_2548(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2284)
static void C_fcall f_2284(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2297)
static void C_fcall f_2297(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2303)
static void C_ccall f_2303(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2275)
static void C_ccall f_2275(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2552)
static void C_ccall f_2552(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2555)
static void C_ccall f_2555(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2755)
static void C_ccall f_2755(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2558)
static void C_ccall f_2558(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2749)
static void C_ccall f_2749(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2561)
static void C_ccall f_2561(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2746)
static void C_ccall f_2746(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2731)
static void C_ccall f_2731(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2732)
static void C_ccall f_2732(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2570)
static void C_ccall f_2570(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2700)
static void C_ccall f_2700(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2704)
static void C_ccall f_2704(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2720)
static void C_ccall f_2720(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2727)
static void C_ccall f_2727(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2707)
static void C_ccall f_2707(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2717)
static void C_ccall f_2717(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2576)
static void C_ccall f_2576(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2666)
static void C_ccall f_2666(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2695)
static void C_ccall f_2695(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2673)
static void C_ccall f_2673(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2595)
static void C_ccall f_2595(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2603)
static void C_ccall f_2603(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2638)
static void C_ccall f_2638(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2653)
static void C_ccall f_2653(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2653)
static void C_ccall f_2653r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2659)
static void C_ccall f_2659(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2644)
static void C_ccall f_2644(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2609)
static void C_ccall f_2609(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2615)
static void C_ccall f_2615(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2633)
static void C_ccall f_2633(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2630)
static void C_ccall f_2630(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2619)
static void C_ccall f_2619(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2601)
static void C_ccall f_2601(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2339)
static void C_fcall f_2339(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2347)
static void C_ccall f_2347(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2329)
static void C_fcall f_2329(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2337)
static void C_ccall f_2337(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2223)
static void C_ccall f_2223(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2271)
static void C_ccall f_2271(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2254)
static void C_ccall f_2254(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2264)
static void C_ccall f_2264(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2258)
static void C_ccall f_2258(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2226)
static void C_ccall f_2226(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2230)
static void C_ccall f_2230(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2191)
static void C_ccall f_2191(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2170)
static void C_ccall f_2170(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2152)
static void C_ccall f_2152(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2166)
static void C_ccall f_2166(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2163)
static void C_ccall f_2163(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2148)
static void C_ccall f_2148(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2241)
static void C_ccall f_2241(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2197)
static void C_fcall f_2197(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2221)
static void C_ccall f_2221(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2204)
static void C_fcall f_2204(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2042)
static void C_ccall f_2042(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2125)
static void C_ccall f_2125(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2046)
static void C_ccall f_2046(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2100)
static void C_ccall f_2100(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2103)
static void C_ccall f_2103(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2114)
static void C_ccall f_2114(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2118)
static void C_ccall f_2118(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2110)
static void C_ccall f_2110(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2061)
static void C_ccall f_2061(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2071)
static void C_ccall f_2071(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2077)
static void C_fcall f_2077(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2081)
static void C_ccall f_2081(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2097)
static void C_ccall f_2097(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2090)
static void C_ccall f_2090(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1962)
static void C_ccall f_1962(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1962)
static void C_ccall f_1962r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1966)
static void C_ccall f_1966(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2036)
static void C_ccall f_2036(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1969)
static void C_ccall f_1969(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1974)
static void C_fcall f_1974(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1978)
static void C_ccall f_1978(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1981)
static void C_ccall f_1981(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1984)
static void C_ccall f_1984(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1987)
static void C_ccall f_1987(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1990)
static void C_fcall f_1990(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2014)
static void C_ccall f_2014(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4903)
static void C_ccall f_4903(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4907)
static void C_ccall f_4907(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4918)
static void C_ccall f_4918(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4914)
static void C_ccall f_4914(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4895)
static void C_ccall f_4895(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4899)
static void C_ccall f_4899(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1943)
static void C_fcall f_1943(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1950)
static void C_ccall f_1950(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1911)
static void C_fcall f_1911(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1917)
static void C_fcall f_1917(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1941)
static void C_ccall f_1941(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1924)
static void C_fcall f_1924(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1934)
static void C_ccall f_1934(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1927)
static void C_ccall f_1927(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1886)
static void C_ccall f_1886(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1886)
static void C_ccall f_1886r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1860)
static void C_fcall f_1860(C_word t0) C_noret;
C_noret_decl(f_1788)
static void C_ccall f_1788(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1778)
static void C_ccall f_1778(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1786)
static void C_ccall f_1786(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_1776)
static void C_fcall trf_1776(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1776(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1776(t0,t1);}

C_noret_decl(trf_4798)
static void C_fcall trf_4798(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4798(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4798(t0,t1);}

C_noret_decl(trf_4805)
static void C_fcall trf_4805(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4805(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4805(t0,t1);}

C_noret_decl(trf_4760)
static void C_fcall trf_4760(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4760(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4760(t0,t1);}

C_noret_decl(trf_4664)
static void C_fcall trf_4664(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4664(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4664(t0,t1,t2);}

C_noret_decl(trf_4583)
static void C_fcall trf_4583(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4583(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4583(t0,t1);}

C_noret_decl(trf_4588)
static void C_fcall trf_4588(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4588(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4588(t0,t1);}

C_noret_decl(trf_4378)
static void C_fcall trf_4378(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4378(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4378(t0,t1,t2,t3);}

C_noret_decl(trf_4344)
static void C_fcall trf_4344(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4344(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4344(t0,t1);}

C_noret_decl(trf_4214)
static void C_fcall trf_4214(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4214(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4214(t0,t1,t2);}

C_noret_decl(trf_4227)
static void C_fcall trf_4227(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4227(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4227(t0,t1);}

C_noret_decl(trf_4245)
static void C_fcall trf_4245(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4245(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4245(t0,t1);}

C_noret_decl(trf_4260)
static void C_fcall trf_4260(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4260(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4260(t0,t1);}

C_noret_decl(trf_4198)
static void C_fcall trf_4198(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4198(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4198(t0,t1,t2);}

C_noret_decl(trf_4013)
static void C_fcall trf_4013(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4013(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4013(t0,t1);}

C_noret_decl(trf_3958)
static void C_fcall trf_3958(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3958(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3958(t0,t1);}

C_noret_decl(trf_3671)
static void C_fcall trf_3671(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3671(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3671(t0,t1);}

C_noret_decl(trf_3341)
static void C_fcall trf_3341(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3341(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3341(t0,t1);}

C_noret_decl(trf_3599)
static void C_fcall trf_3599(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3599(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3599(t0,t1);}

C_noret_decl(trf_3530)
static void C_fcall trf_3530(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3530(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3530(t0,t1);}

C_noret_decl(trf_3277)
static void C_fcall trf_3277(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3277(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3277(t0,t1);}

C_noret_decl(trf_3299)
static void C_fcall trf_3299(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3299(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3299(t0,t1);}

C_noret_decl(trf_3252)
static void C_fcall trf_3252(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3252(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3252(t0,t1,t2);}

C_noret_decl(trf_3127)
static void C_fcall trf_3127(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3127(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3127(t0,t1);}

C_noret_decl(trf_3118)
static void C_fcall trf_3118(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3118(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3118(t0,t1,t2);}

C_noret_decl(trf_3027)
static void C_fcall trf_3027(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3027(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3027(t0,t1,t2,t3);}

C_noret_decl(trf_3091)
static void C_fcall trf_3091(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3091(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3091(t0,t1);}

C_noret_decl(trf_2911)
static void C_fcall trf_2911(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2911(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2911(t0,t1,t2,t3);}

C_noret_decl(trf_2896)
static void C_fcall trf_2896(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2896(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2896(t0,t1);}

C_noret_decl(trf_2527)
static void C_fcall trf_2527(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2527(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2527(t0,t1,t2);}

C_noret_decl(trf_2531)
static void C_fcall trf_2531(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2531(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2531(t0,t1);}

C_noret_decl(trf_2284)
static void C_fcall trf_2284(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2284(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2284(t0,t1,t2);}

C_noret_decl(trf_2297)
static void C_fcall trf_2297(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2297(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2297(t0,t1);}

C_noret_decl(trf_2339)
static void C_fcall trf_2339(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2339(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2339(t0,t1,t2,t3);}

C_noret_decl(trf_2329)
static void C_fcall trf_2329(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2329(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2329(t0,t1,t2);}

C_noret_decl(trf_2197)
static void C_fcall trf_2197(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2197(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2197(t0,t1);}

C_noret_decl(trf_2204)
static void C_fcall trf_2204(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2204(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2204(t0,t1);}

C_noret_decl(trf_2077)
static void C_fcall trf_2077(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2077(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2077(t0,t1);}

C_noret_decl(trf_1974)
static void C_fcall trf_1974(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1974(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1974(t0,t1);}

C_noret_decl(trf_1990)
static void C_fcall trf_1990(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1990(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1990(t0,t1);}

C_noret_decl(trf_1943)
static void C_fcall trf_1943(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1943(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1943(t0,t1);}

C_noret_decl(trf_1911)
static void C_fcall trf_1911(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1911(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1911(t0,t1,t2);}

C_noret_decl(trf_1917)
static void C_fcall trf_1917(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1917(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1917(t0,t1,t2);}

C_noret_decl(trf_1924)
static void C_fcall trf_1924(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1924(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1924(t0,t1);}

C_noret_decl(trf_1860)
static void C_fcall trf_1860(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1860(void *dummy){
C_word t0=C_pick(0);
C_adjust_stack(-1);
f_1860(t0);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr2rv)
static void C_fcall tr2rv(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2rv(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n+1);
t2=C_restore_rest_vector(a,n);
(k)(t0,t1,t2);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_main_entry_point
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("toplevel"));
C_resize_stack(131072);
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(1402)){
C_save(t1);
C_rereclaim2(1402*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,324);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[2]=C_decode_literal(C_heaptop,"\376B\000\000\007chicken");
lf[3]=C_decode_literal(C_heaptop,"\376B\000\000\003csc");
lf[4]=C_decode_literal(C_heaptop,"\376B\000\000\003csi");
lf[5]=C_decode_literal(C_heaptop,"\376B\000\000\013chicken-bug");
lf[15]=C_h_intern(&lf[15],24,"setup-api#host-extension");
lf[18]=C_h_intern(&lf[18],24,"setup-api#chicken-prefix");
lf[19]=C_h_intern(&lf[19],19,"setup-api#shellpath");
lf[20]=C_h_intern(&lf[20],2,"qs");
lf[21]=C_h_intern(&lf[21],18,"normalize-pathname");
lf[22]=C_h_intern(&lf[22],23,"setup-api#cross-chicken");
lf[24]=C_h_intern(&lf[24],30,"setup-api#setup-root-directory");
lf[25]=C_h_intern(&lf[25],28,"setup-api#setup-verbose-mode");
lf[26]=C_h_intern(&lf[26],28,"setup-api#setup-install-mode");
lf[27]=C_h_intern(&lf[27],28,"setup-api#setup-verbose-flag");
lf[28]=C_h_intern(&lf[28],28,"setup-api#setup-install-flag");
lf[29]=C_h_intern(&lf[29],22,"setup-api#program-path");
lf[30]=C_h_intern(&lf[30],28,"setup-api#keep-intermediates");
lf[38]=C_h_intern(&lf[38],4,"copy");
lf[39]=C_decode_literal(C_heaptop,"\376B\000\000\011del /Q /S");
lf[40]=C_h_intern(&lf[40],4,"move");
lf[41]=C_decode_literal(C_heaptop,"\376B\000\000\005chmod");
lf[42]=C_decode_literal(C_heaptop,"\376B\000\000\006ranlib");
lf[43]=C_decode_literal(C_heaptop,"\376B\000\000\005cp -r");
lf[44]=C_decode_literal(C_heaptop,"\376B\000\000\006rm -fr");
lf[45]=C_h_intern(&lf[45],2,"mv");
lf[46]=C_decode_literal(C_heaptop,"\376B\000\000\005chmod");
lf[47]=C_decode_literal(C_heaptop,"\376B\000\000\006ranlib");
lf[48]=C_decode_literal(C_heaptop,"\376B\000\000\005mkdir");
lf[49]=C_h_intern(&lf[49],22,"setup-api#sudo-install");
lf[50]=C_h_intern(&lf[50],5,"print");
lf[51]=C_decode_literal(C_heaptop,"\376B\000\0001Warning: cannot install as superuser with Windows");
lf[52]=C_decode_literal(C_heaptop,"\376B\000\000\012sudo cp -r");
lf[53]=C_decode_literal(C_heaptop,"\376B\000\000\013sudo rm -fr");
lf[54]=C_decode_literal(C_heaptop,"\376B\000\000\007sudo mv");
lf[55]=C_decode_literal(C_heaptop,"\376B\000\000\012sudo chmod");
lf[56]=C_decode_literal(C_heaptop,"\376B\000\000\013sudo ranlib");
lf[57]=C_decode_literal(C_heaptop,"\376B\000\000\012sudo mkdir");
lf[58]=C_h_intern(&lf[58],16,"create-directory");
lf[59]=C_h_intern(&lf[59],18,"pathname-directory");
lf[60]=C_h_intern(&lf[60],10,"directory\077");
lf[61]=C_h_intern(&lf[61],6,"printf");
lf[62]=C_decode_literal(C_heaptop,"\376B\000\000\035  creating directory `~a\047~%~!");
lf[64]=C_h_intern(&lf[64],7,"sprintf");
lf[65]=C_decode_literal(C_heaptop,"\376B\000\000\013mkdir -p ~a");
lf[66]=C_h_intern(&lf[66],34,"setup-api#create-directory/parents");
lf[67]=C_h_intern(&lf[67],21,"setup-api#abort-setup");
lf[68]=C_h_intern(&lf[68],20,"setup-api#yes-or-no\077");
lf[69]=C_decode_literal(C_heaptop,"\376B\000\000\003yes");
lf[70]=C_decode_literal(C_heaptop,"\376B\000\000\002no");
lf[71]=C_decode_literal(C_heaptop,"\376B\000\000\005abort");
lf[72]=C_decode_literal(C_heaptop,"\376B\000\000(~%Please enter \042yes\042, \042no\042 or \042abort\042.~%");
lf[73]=C_decode_literal(C_heaptop,"\376B\000\000\005abort");
lf[74]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[75]=C_h_intern(&lf[75],9,"read-line");
lf[76]=C_h_intern(&lf[76],12,"flush-output");
lf[77]=C_decode_literal(C_heaptop,"\376B\000\000\005[~A] ");
lf[78]=C_decode_literal(C_heaptop,"\376B\000\000\024~%~A (yes/no/abort) ");
lf[79]=C_h_intern(&lf[79],15,"\003sysget-keyword");
lf[80]=C_h_intern(&lf[80],6,"\000abort");
lf[81]=C_h_intern(&lf[81],8,"\000default");
lf[82]=C_h_intern(&lf[82],15,"setup-api#patch");
lf[83]=C_h_intern(&lf[83],10,"write-line");
lf[84]=C_h_intern(&lf[84],17,"string-substitute");
lf[85]=C_h_intern(&lf[85],20,"with-input-from-file");
lf[86]=C_h_intern(&lf[86],19,"with-output-to-file");
lf[87]=C_decode_literal(C_heaptop,"\376B\000\000\010~A ~A ~A");
lf[88]=C_h_intern(&lf[88],21,"create-temporary-file");
lf[89]=C_decode_literal(C_heaptop,"\376B\000\000\021patching ~A ...~%");
lf[90]=C_h_intern(&lf[90],21,"setup-api#run-verbose");
lf[92]=C_h_intern(&lf[92],26,"pathname-replace-extension");
lf[93]=C_h_intern(&lf[93],26,"\003sysload-dynamic-extension");
lf[94]=C_decode_literal(C_heaptop,"\376B\000\000\002so");
lf[95]=C_decode_literal(C_heaptop,"\376B\000\000\002so");
lf[96]=C_h_intern(&lf[96],18,"pathname-extension");
lf[97]=C_h_intern(&lf[97],17,"setup-api#execute");
lf[98]=C_h_intern(&lf[98],18,"string-intersperse");
lf[99]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[100]=C_decode_literal(C_heaptop,"\376B\000\000\003csc");
lf[101]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[102]=C_decode_literal(C_heaptop,"\376B\000\000\002-k");
lf[103]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[104]=C_decode_literal(C_heaptop,"\376B\000\000\005-host");
lf[105]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[106]=C_h_intern(&lf[106],5,"cons*");
lf[107]=C_decode_literal(C_heaptop,"\376B\000\000\010-feature");
lf[108]=C_decode_literal(C_heaptop,"\376B\000\000\023compiling-extension");
lf[109]=C_decode_literal(C_heaptop,"\376B\000\000\013-setup-mode");
lf[110]=C_h_intern(&lf[110],13,"make-pathname");
lf[111]=C_h_intern(&lf[111],7,"\003sysmap");
lf[112]=C_h_intern(&lf[112],8,"->string");
lf[113]=C_decode_literal(C_heaptop,"\376B\000\000\010  ~A~%~!");
lf[114]=C_h_intern(&lf[114],12,"\003sysfor-each");
lf[116]=C_h_intern(&lf[116],5,"error");
lf[117]=C_decode_literal(C_heaptop,"\376B\000\000\006~a: ~s");
lf[119]=C_decode_literal(C_heaptop,"\376B\000\000\023~a: ~s for line: ~a");
lf[121]=C_h_intern(&lf[121],6,"signal");
lf[122]=C_decode_literal(C_heaptop,"\376B\000\000\035make: Failed to make ~a: ~a~%");
lf[123]=C_h_intern(&lf[123],22,"with-exception-handler");
lf[124]=C_h_intern(&lf[124],30,"call-with-current-continuation");
lf[125]=C_decode_literal(C_heaptop,"\376B\000\000\025make: ~amaking ~a~a~%");
lf[126]=C_h_intern(&lf[126],13,"string-append");
lf[127]=C_decode_literal(C_heaptop,"\376B\000\000\011 because ");
lf[128]=C_decode_literal(C_heaptop,"\376B\000\000\010 changed");
lf[129]=C_decode_literal(C_heaptop,"\376B\000\000# just because (reason: ~a date: ~a)");
lf[130]=C_decode_literal(C_heaptop,"\376B\000\000\011 because ");
lf[131]=C_decode_literal(C_heaptop,"\376B\000\000\017 does not exist");
lf[132]=C_h_intern(&lf[132],22,"file-modification-time");
lf[133]=C_decode_literal(C_heaptop,"\376B\000\000\034dependancy ~a was not made~%");
lf[134]=C_h_intern(&lf[134],12,"file-exists\077");
lf[135]=C_h_intern(&lf[135],3,"any");
lf[136]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[137]=C_decode_literal(C_heaptop,"\376B\000\000\031don\047t know how to make ~a");
lf[138]=C_decode_literal(C_heaptop,"\376B\000\000\025make: ~achecking ~a~%");
lf[139]=C_decode_literal(C_heaptop,"\376B\000\000\017make: made ~a~%");
lf[140]=C_h_intern(&lf[140],7,"reverse");
lf[141]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[142]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[143]=C_h_intern(&lf[143],4,"caar");
lf[144]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[145]=C_h_intern(&lf[145],27,"condition-property-accessor");
lf[146]=C_h_intern(&lf[146],3,"exn");
lf[147]=C_h_intern(&lf[147],7,"message");
lf[148]=C_h_intern(&lf[148],19,"condition-predicate");
lf[149]=C_decode_literal(C_heaptop,"\376B\000\000\047argument is not a string or string list");
lf[150]=C_h_intern(&lf[150],5,"every");
lf[151]=C_h_intern(&lf[151],7,"string\077");
lf[152]=C_decode_literal(C_heaptop,"\376B\000\000#command part of line is not a thunk");
lf[153]=C_decode_literal(C_heaptop,"\376B\000\000\037dependency item is not a string");
lf[154]=C_decode_literal(C_heaptop,"\376B\000\000!second part of line is not a list");
lf[155]=C_decode_literal(C_heaptop,"\376B\000\0004line does not start with a string or list of strings");
lf[156]=C_decode_literal(C_heaptop,"\376B\000\000$list is not a list with 2 or 3 parts");
lf[157]=C_decode_literal(C_heaptop,"\376B\000\000\036specification is an empty list");
lf[158]=C_decode_literal(C_heaptop,"\376B\000\000\033specification is not a list");
lf[159]=C_h_intern(&lf[159],12,"vector->list");
lf[160]=C_h_intern(&lf[160],19,"setup-api#make/proc");
lf[161]=C_h_intern(&lf[161],9,"\003syserror");
lf[162]=C_decode_literal(C_heaptop,"\376B\000\0000no matching clause in call to \047case-lambda\047 form");
lf[163]=C_h_intern(&lf[163],29,"setup-api#installation-prefix");
lf[164]=C_decode_literal(C_heaptop,"\376B\000\000\035  creating directory `~a\047~%~!");
lf[165]=C_h_intern(&lf[165],2,"-p");
lf[167]=C_h_intern(&lf[167],5,"files");
lf[168]=C_h_intern(&lf[168],3,"a+r");
lf[169]=C_h_intern(&lf[169],2,"pp");
lf[170]=C_decode_literal(C_heaptop,"\376B\000\000\012setup-info");
lf[171]=C_h_intern(&lf[171],15,"repository-path");
lf[173]=C_decode_literal(C_heaptop,"\376B\000\000\033writing info ~A -> ~S ...~%");
lf[174]=C_h_intern(&lf[174],10,"\003sysappend");
lf[175]=C_h_intern(&lf[175],19,"setup-api#copy-file");
lf[176]=C_decode_literal(C_heaptop,"\376B\000\000\023file does not exist");
lf[177]=C_h_intern(&lf[177],7,"warning");
lf[178]=C_decode_literal(C_heaptop,"\376B\000\000\023file does not exist");
lf[179]=C_h_intern(&lf[179],5,"glob\077");
lf[181]=C_h_intern(&lf[181],14,"string-prefix\077");
lf[182]=C_h_intern(&lf[182],19,"setup-api#move-file");
lf[183]=C_h_intern(&lf[183],22,"setup-api#remove-file*");
lf[185]=C_h_intern(&lf[185],18,"absolute-pathname\077");
lf[187]=C_decode_literal(C_heaptop,"\376B\000\000\032invalid file-specification");
lf[188]=C_h_intern(&lf[188],27,"setup-api#install-extension");
lf[189]=C_h_intern(&lf[189],13,"documentation");
lf[190]=C_h_intern(&lf[190],8,"examples");
lf[191]=C_h_intern(&lf[191],7,"newline");
lf[192]=C_h_intern(&lf[192],4,"a+rx");
lf[193]=C_decode_literal(C_heaptop,"\376B\000\000\037\012* Installing example files in ");
lf[194]=C_decode_literal(C_heaptop,"\376B\000\000\001:");
lf[195]=C_decode_literal(C_heaptop,"\376B\000\000%\012* Installing documentation files in ");
lf[196]=C_decode_literal(C_heaptop,"\376B\000\000\001:");
lf[197]=C_decode_literal(C_heaptop,"\376B\000\000\021share/chicken/doc");
lf[198]=C_h_intern(&lf[198],6,"static");
lf[199]=C_h_intern(&lf[199],6,"macosx");
lf[200]=C_decode_literal(C_heaptop,"\376B\000\000\001a");
lf[201]=C_h_intern(&lf[201],16,"software-version");
lf[202]=C_decode_literal(C_heaptop,"\376B\000\000\002so");
lf[203]=C_h_intern(&lf[203],25,"setup-api#install-program");
lf[204]=C_decode_literal(C_heaptop,"\376B\000\000\003exe");
lf[205]=C_decode_literal(C_heaptop,"\376B\000\000\002so");
lf[206]=C_decode_literal(C_heaptop,"\376B\000\000\001a");
lf[207]=C_decode_literal(C_heaptop,"\376B\000\000\003lib");
lf[208]=C_decode_literal(C_heaptop,"\376B\000\000\001a");
lf[209]=C_decode_literal(C_heaptop,"\376B\000\000\003bin");
lf[210]=C_h_intern(&lf[210],24,"setup-api#install-script");
lf[211]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[212]=C_decode_literal(C_heaptop,"\376B\000\000\003bin");
lf[213]=C_decode_literal(C_heaptop,"\376B\000\000\016lib/chicken/~a");
lf[214]=C_decode_literal(C_heaptop,"\376B\000\000Acannot create directory: a file with the same name already exists");
lf[215]=C_h_intern(&lf[215],3,"a+x");
lf[216]=C_h_intern(&lf[216],21,"setup-api#try-compile");
lf[217]=C_decode_literal(C_heaptop,"\376B\000\000\005~A ~A");
lf[218]=C_decode_literal(C_heaptop,"\376B\000\000\012succeeded.");
lf[219]=C_decode_literal(C_heaptop,"\376B\000\000\007failed.");
lf[220]=C_h_intern(&lf[220],6,"system");
lf[221]=C_decode_literal(C_heaptop,"\376B\000\000\004 ...");
lf[222]=C_decode_literal(C_heaptop,"\376B\000\000\002-c");
lf[223]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[224]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[225]=C_decode_literal(C_heaptop,"\376B\000\000\0042>&1");
lf[226]=C_h_intern(&lf[226],4,"conc");
lf[227]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[228]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[229]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[230]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[231]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[232]=C_decode_literal(C_heaptop,"\376B\000\000\014 >/dev/null ");
lf[233]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[234]=C_decode_literal(C_heaptop,"\376B\000\000\002-L");
lf[235]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[236]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[237]=C_h_intern(&lf[237],7,"display");
lf[238]=C_decode_literal(C_heaptop,"\376B\000\000\001o");
lf[239]=C_decode_literal(C_heaptop,"\376B\000\000\001c");
lf[240]=C_h_intern(&lf[240],13,"\000compile-only");
lf[241]=C_h_intern(&lf[241],5,"\000verb");
lf[242]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[243]=C_h_intern(&lf[243],8,"\000ldflags");
lf[244]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[245]=C_h_intern(&lf[245],7,"\000cflags");
lf[246]=C_h_intern(&lf[246],3,"\000cc");
lf[247]=C_h_intern(&lf[247],4,"\000c++");
lf[248]=C_h_intern(&lf[248],34,"setup-api#required-chicken-version");
lf[249]=C_decode_literal(C_heaptop,"\376B\000\000(CHICKEN version ~a or higher is required");
lf[250]=C_h_intern(&lf[250],20,"setup-api#version>=\077");
lf[251]=C_h_intern(&lf[251],15,"chicken-version");
lf[253]=C_decode_literal(C_heaptop,"\376B\000\000uthe required extension `~s\047 ~a - please run~%~%  chicken-install ~a~%~%and "
"repeat the current installation operation.");
lf[254]=C_h_intern(&lf[254],36,"setup-api#required-extension-version");
lf[255]=C_decode_literal(C_heaptop,"\376B\000\0007is older than ~a, which is what this extension requires");
lf[256]=C_decode_literal(C_heaptop,"\376B\000\000%has no associated version information");
lf[257]=C_h_intern(&lf[257],7,"version");
lf[258]=C_decode_literal(C_heaptop,"\376B\000\000\020is not installed");
lf[259]=C_h_intern(&lf[259],21,"extension-information");
lf[260]=C_h_intern(&lf[260],30,"required-extension-information");
lf[261]=C_decode_literal(C_heaptop,"\376B\000\000\023bad argument format");
lf[262]=C_h_intern(&lf[262],22,"setup-api#test-compile");
lf[263]=C_h_intern(&lf[263],22,"setup-api#find-library");
lf[264]=C_decode_literal(C_heaptop,"\376B\000\000\002-l");
lf[265]=C_decode_literal(C_heaptop,"\376B\000\000T#ifdef __cplusplus~%extern \042C\042~%#endif~%char ~a();~%int main() { ~a(); retu"
"rn 0; }~%");
lf[266]=C_h_intern(&lf[266],21,"setup-api#find-header");
lf[267]=C_decode_literal(C_heaptop,"\376B\000\000\047#include <~a>\012int main() { return 0; }\012");
lf[268]=C_h_intern(&lf[268],19,"string-split-fields");
lf[269]=C_decode_literal(C_heaptop,"\376B\000\000\006[-\134._]");
lf[270]=C_h_intern(&lf[270],6,"\000infix");
lf[271]=C_h_intern(&lf[271],8,"string>\077");
lf[272]=C_h_intern(&lf[272],36,"setup-api#extension-name-and-version");
lf[273]=C_h_intern(&lf[273],24,"setup-api#extension-name");
lf[274]=C_h_intern(&lf[274],27,"setup-api#extension-version");
lf[275]=C_h_intern(&lf[275],12,"string-null\077");
lf[276]=C_h_intern(&lf[276],19,"setup-api#read-info");
lf[277]=C_h_intern(&lf[277],4,"read");
lf[278]=C_decode_literal(C_heaptop,"\376B\000\000\013.setup-info");
lf[279]=C_h_intern(&lf[279],36,"setup-api#create-temporary-directory");
lf[280]=C_decode_literal(C_heaptop,"\376B\000\000\003tmp");
lf[281]=C_decode_literal(C_heaptop,"\376B\000\000\020chicken-install-");
lf[282]=C_decode_literal(C_heaptop,"\376B\000\000\004/tmp");
lf[283]=C_h_intern(&lf[283],24,"get-environment-variable");
lf[284]=C_decode_literal(C_heaptop,"\376B\000\000\003TMP");
lf[285]=C_decode_literal(C_heaptop,"\376B\000\000\004TEMP");
lf[286]=C_decode_literal(C_heaptop,"\376B\000\000\006TMPDIR");
lf[287]=C_h_intern(&lf[287],26,"setup-api#remove-directory");
lf[288]=C_decode_literal(C_heaptop,"\376B\000\000\016sudo rm -fr ~a");
lf[289]=C_h_intern(&lf[289],16,"delete-directory");
lf[290]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[291]=C_decode_literal(C_heaptop,"\376B\000\000\002..");
lf[292]=C_h_intern(&lf[292],11,"delete-file");
lf[293]=C_h_intern(&lf[293],9,"directory");
lf[294]=C_h_intern(&lf[294],16,"remove-directory");
lf[295]=C_decode_literal(C_heaptop,"\376B\000\000#cannot remove - directory not found");
lf[296]=C_h_intern(&lf[296],26,"setup-api#remove-extension");
lf[297]=C_decode_literal(C_heaptop,"\376B\000\000\012setup-info");
lf[298]=C_decode_literal(C_heaptop,"\376B\000\000-shell command failed with nonzero exit status");
lf[299]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[300]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[301]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\000\376\003\000\000\002\376B\000\000\000\376\377\016");
lf[302]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[303]=C_decode_literal(C_heaptop,"\376B\000\000\042invalid extension-name-and-version");
lf[304]=C_h_intern(&lf[304],14,"make-parameter");
lf[305]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\000\376\003\000\000\002\376B\000\000\000\376\377\016");
lf[306]=C_decode_literal(C_heaptop,"\376B\000\000\026CHICKEN_INSTALL_PREFIX");
lf[307]=C_h_intern(&lf[307],4,"exit");
lf[308]=C_h_intern(&lf[308],17,"current-directory");
lf[309]=C_decode_literal(C_heaptop,"\376B\000\000\012/usr/local");
lf[310]=C_h_intern(&lf[310],12,"string-match");
lf[311]=C_decode_literal(C_heaptop,"\376B\000\000\012(.*)/bin/\077");
lf[312]=C_decode_literal(C_heaptop,"\376B\000\000\016CHICKEN_PREFIX");
lf[313]=C_decode_literal(C_heaptop,"\376B\000\000\003doc");
lf[314]=C_h_intern(&lf[314],17,"\003syspeek-c-string");
lf[315]=C_decode_literal(C_heaptop,"\376B\000\000\021share/chicken/doc");
lf[316]=C_decode_literal(C_heaptop,"\376B\000\000\016CHICKEN_PREFIX");
lf[317]=C_decode_literal(C_heaptop,"\376B\000\000\003bin");
lf[318]=C_decode_literal(C_heaptop,"\376B\000\000\016CHICKEN_PREFIX");
lf[319]=C_h_intern(&lf[319],17,"register-feature!");
lf[320]=C_h_intern(&lf[320],13,"chicken-setup");
lf[321]=C_h_intern(&lf[321],7,"windows");
lf[322]=C_h_intern(&lf[322],14,"build-platform");
lf[323]=C_h_intern(&lf[323],13,"software-type");
C_register_lf2(lf,324,create_ptable());
t2=C_mutate(&lf[0] /* (set! c719 ...) */,lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1669,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t3);}

/* k1667 */
static void C_ccall f_1669(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1669,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1672,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1670 in k1667 */
static void C_ccall f_1672(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1672,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1675,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1673 in k1670 in k1667 */
static void C_ccall f_1675(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1675,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1678,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_1678(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1678,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1681,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_1681(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1681,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1684,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_1684(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1684,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1687,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_1_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_1687(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1687,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1690,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_regex_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_1690(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1690,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1693,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_utils_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_1693(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1693,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1696,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_posix_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_1696(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1696,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1699,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_13_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_1699(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1699,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1702,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_1702(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1702,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1705,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_1705(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1705,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1708,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_1708(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1708,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1711,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_files_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_1711(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1711,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4997,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t3=*((C_word*)lf[314]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_CHICKEN_PROGRAM),C_fix(0));}

/* k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_4997(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4997,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[2],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4993,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[314]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)C_CSC_PROGRAM),C_fix(0));}

/* k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_4993(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4993,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[3],t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4989,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[314]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)C_CSI_PROGRAM),C_fix(0));}

/* k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_4989(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4989,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[4],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4985,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[314]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)C_CHICKEN_BUG_PROGRAM),C_fix(0));}

/* k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_4985(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[21],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4985,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[5],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t5);
t7=C_mutate(&lf[6] /* (set! setup-api#*installed-executables* ...) */,t6);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1720,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t9=*((C_word*)lf[314]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t8,C_mpointer(&a,(void*)C_TARGET_CC),C_fix(0));}

/* k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_1720(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1720,2,t0,t1);}
t2=C_mutate(&lf[7] /* (set! setup-api#*cc* ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1724,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[314]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)C_TARGET_CXX),C_fix(0));}

/* k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_1724(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1724,2,t0,t1);}
t2=C_mutate(&lf[8] /* (set! setup-api#*cxx* ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1728,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[314]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)C_TARGET_CFLAGS),C_fix(0));}

/* k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_1728(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1728,2,t0,t1);}
t2=C_mutate(&lf[9] /* (set! setup-api#*target-cflags* ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1732,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[314]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)C_TARGET_MORE_LIBS),C_fix(0));}

/* k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_1732(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1732,2,t0,t1);}
t2=C_mutate(&lf[10] /* (set! setup-api#*target-libs* ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1736,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[314]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)C_TARGET_LIB_HOME),C_fix(0));}

/* k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_1736(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1736,2,t0,t1);}
t2=C_mutate(&lf[11] /* (set! setup-api#*target-lib-home* ...) */,t1);
t3=lf[12] /* setup-api#*sudo* */ =C_SCHEME_FALSE;;
t4=C_mutate(&lf[13] /* (set! setup-api#*windows-shell* ...) */,C_mk_bool(C_WINDOWS_SHELL));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1742,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4953,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 85   software-type */
((C_proc2)C_retrieve_symbol_proc(lf[323]))(2,*((C_word*)lf[323]+1),t6);}

/* k4951 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_4953(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(t1,lf[321]);
if(C_truep(t2)){
/* setup-api.scm: 86   build-platform */
((C_proc2)C_retrieve_symbol_proc(lf[322]))(2,*((C_word*)lf[322]+1),((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[2];
f_1742(2,t3,C_SCHEME_FALSE);}}

/* k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_1742(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1742,2,t0,t1);}
t2=C_mutate(&lf[14] /* (set! setup-api#*windows* ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1745,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 88   register-feature! */
((C_proc3)C_retrieve_symbol_proc(lf[319]))(3,*((C_word*)lf[319]+1),t3,lf[320]);}

/* k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_1745(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1745,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1749,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 90   make-parameter */
((C_proc3)C_retrieve_symbol_proc(lf[304]))(3,*((C_word*)lf[304]+1),t2,C_SCHEME_FALSE);}

/* k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_1749(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1749,2,t0,t1);}
t2=C_mutate((C_word*)lf[15]+1 /* (set! setup-api#host-extension ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1753,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 93   get-environment-variable */
((C_proc3)C_retrieve_symbol_proc(lf[283]))(3,*((C_word*)lf[283]+1),t3,lf[318]);}

/* k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_1753(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1753,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1756,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
/* setup-api.scm: 94   make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[110]))(4,*((C_word*)lf[110]+1),t2,t1,lf[317]);}
else{
t3=t2;
f_1756(2,t3,C_SCHEME_FALSE);}}

/* k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_1756(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1756,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1759,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
t3=t2;
f_1759(2,t3,t1);}
else{
/* ##sys#peek-c-string */
t3=*((C_word*)lf[314]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_INSTALL_BIN_HOME),C_fix(0));}}

/* k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_1759(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1759,2,t0,t1);}
t2=C_mutate(&lf[16] /* (set! setup-api#*chicken-bin-path* ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1763,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 98   get-environment-variable */
((C_proc3)C_retrieve_symbol_proc(lf[283]))(3,*((C_word*)lf[283]+1),t3,lf[316]);}

/* k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_1763(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1763,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1766,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
/* setup-api.scm: 99   make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[110]))(4,*((C_word*)lf[110]+1),t2,t1,lf[315]);}
else{
t3=t2;
f_1766(2,t3,C_SCHEME_FALSE);}}

/* k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_1766(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1766,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1769,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
t3=t2;
f_1769(2,t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4934,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[314]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)C_INSTALL_SHARE_HOME),C_fix(0));}}

/* k4932 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_4934(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 100  make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[110]))(4,*((C_word*)lf[110]+1),((C_word*)t0)[2],t1,lf[313]);}

/* k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_1769(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1769,2,t0,t1);}
t2=C_mutate(&lf[17] /* (set! setup-api#*doc-path* ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1773,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 105  get-environment-variable */
((C_proc3)C_retrieve_symbol_proc(lf[283]))(3,*((C_word*)lf[283]+1),t3,lf[312]);}

/* k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_1773(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1773,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1776,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
t3=t2;
f_1776(t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4921,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 106  string-match */
((C_proc4)C_retrieve_symbol_proc(lf[310]))(4,*((C_word*)lf[310]+1),t3,lf[311],C_retrieve2(lf[16],"setup-api#*chicken-bin-path*"));}}

/* k4919 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_4921(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_1776(t2,(C_truep(t1)?(C_word)C_i_cadr(t1):lf[309]));}

/* k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_fcall f_1776(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1776,NULL,2,t0,t1);}
t2=C_mutate((C_word*)lf[18]+1 /* (set! setup-api#chicken-prefix ...) */,t1);
t3=C_mutate((C_word*)lf[19]+1 /* (set! setup-api#shellpath ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1778,a[2]=((C_word)li0),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[22]+1 /* (set! setup-api#cross-chicken ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1788,a[2]=((C_word)li1),tmp=(C_word)a,a+=3,tmp));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1797,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 117  current-directory */
((C_proc2)C_retrieve_symbol_proc(lf[308]))(2,*((C_word*)lf[308]+1),t5);}

/* k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_1797(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1797,2,t0,t1);}
t2=C_mutate(&lf[23] /* (set! setup-api#*base-directory* ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1801,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 119  make-parameter */
((C_proc3)C_retrieve_symbol_proc(lf[304]))(3,*((C_word*)lf[304]+1),t3,C_retrieve2(lf[23],"setup-api#*base-directory*"));}

/* k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_1801(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1801,2,t0,t1);}
t2=C_mutate((C_word*)lf[24]+1 /* (set! setup-api#setup-root-directory ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1805,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 120  make-parameter */
((C_proc3)C_retrieve_symbol_proc(lf[304]))(3,*((C_word*)lf[304]+1),t3,C_SCHEME_FALSE);}

/* k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_1805(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1805,2,t0,t1);}
t2=C_mutate((C_word*)lf[25]+1 /* (set! setup-api#setup-verbose-mode ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1809,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 121  make-parameter */
((C_proc3)C_retrieve_symbol_proc(lf[304]))(3,*((C_word*)lf[304]+1),t3,C_SCHEME_TRUE);}

/* k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_1809(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1809,2,t0,t1);}
t2=C_mutate((C_word*)lf[26]+1 /* (set! setup-api#setup-install-mode ...) */,t1);
t3=C_mutate((C_word*)lf[27]+1 /* (set! setup-api#setup-verbose-flag ...) */,C_retrieve(lf[25]));
t4=C_mutate((C_word*)lf[28]+1 /* (set! setup-api#setup-install-flag ...) */,C_retrieve(lf[26]));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1815,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 124  make-parameter */
((C_proc3)C_retrieve_symbol_proc(lf[304]))(3,*((C_word*)lf[304]+1),t5,C_retrieve2(lf[16],"setup-api#*chicken-bin-path*"));}

/* k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_1815(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1815,2,t0,t1);}
t2=C_mutate((C_word*)lf[29]+1 /* (set! setup-api#program-path ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1819,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 125  make-parameter */
((C_proc3)C_retrieve_symbol_proc(lf[304]))(3,*((C_word*)lf[304]+1),t3,C_SCHEME_FALSE);}

/* k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_1819(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1819,2,t0,t1);}
t2=C_mutate((C_word*)lf[30]+1 /* (set! setup-api#keep-intermediates ...) */,t1);
t3=lf[31] /* setup-api#*copy-command* */ =C_SCHEME_UNDEFINED;;
t4=lf[32] /* setup-api#*remove-command* */ =C_SCHEME_UNDEFINED;;
t5=lf[33] /* setup-api#*move-command* */ =C_SCHEME_UNDEFINED;;
t6=lf[34] /* setup-api#*chmod-command* */ =C_SCHEME_UNDEFINED;;
t7=lf[35] /* setup-api#*ranlib-command* */ =C_SCHEME_UNDEFINED;;
t8=lf[36] /* setup-api#*mkdir-command* */ =C_SCHEME_UNDEFINED;;
t9=C_mutate(&lf[37] /* (set! setup-api#user-install-setup ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1860,a[2]=((C_word)li2),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[49]+1 /* (set! setup-api#sudo-install ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1886,a[2]=((C_word)li3),tmp=(C_word)a,a+=3,tmp));
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1908,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 181  user-install-setup */
f_1860(t11);}

/* k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_1908(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1908,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_retrieve(lf[58]);
t7=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1911,a[2]=t6,a[3]=((C_word)li5),tmp=(C_word)a,a+=4,tmp));
t8=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1943,a[2]=((C_word)li6),tmp=(C_word)a,a+=3,tmp));
t9=(C_truep(C_retrieve2(lf[13],"setup-api#*windows-shell*"))?(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4895,a[2]=t5,a[3]=t3,a[4]=((C_word)li7),tmp=(C_word)a,a+=5,tmp):(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4903,a[2]=t5,a[3]=((C_word)li8),tmp=(C_word)a,a+=4,tmp));
t10=C_mutate((C_word*)lf[66]+1 /* (set! setup-api#create-directory/parents ...) */,t9);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1960,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 203  make-parameter */
((C_proc3)C_retrieve_symbol_proc(lf[304]))(3,*((C_word*)lf[304]+1),t11,C_retrieve(lf[307]));}

/* k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_1960(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1960,2,t0,t1);}
t2=C_mutate((C_word*)lf[67]+1 /* (set! setup-api#abort-setup ...) */,t1);
t3=C_mutate((C_word*)lf[68]+1 /* (set! setup-api#yes-or-no? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1962,a[2]=((C_word)li11),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[82]+1 /* (set! setup-api#patch ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2042,a[2]=((C_word)li15),tmp=(C_word)a,a+=3,tmp));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2132,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 238  make-parameter */
((C_proc3)C_retrieve_symbol_proc(lf[304]))(3,*((C_word*)lf[304]+1),t5,C_SCHEME_TRUE);}

/* k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_2132(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[24],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2132,2,t0,t1);}
t2=C_mutate((C_word*)lf[90]+1 /* (set! setup-api#run-verbose ...) */,t1);
t3=C_mutate(&lf[91] /* (set! setup-api#fixmaketarget ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2197,a[2]=((C_word)li16),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[97]+1 /* (set! setup-api#execute ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2223,a[2]=((C_word)li19),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate(&lf[115] /* (set! setup-api#make:form-error ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2329,a[2]=((C_word)li20),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate(&lf[118] /* (set! setup-api#make:line-error ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2339,a[2]=((C_word)li21),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate(&lf[120] /* (set! setup-api#make:make/proc/helper ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2527,a[2]=((C_word)li38),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[160]+1 /* (set! setup-api#make/proc ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2817,a[2]=((C_word)li39),tmp=(C_word)a,a+=3,tmp));
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2893,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4891,a[2]=t9,tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 441  get-environment-variable */
((C_proc3)C_retrieve_symbol_proc(lf[283]))(3,*((C_word*)lf[283]+1),t10,lf[306]);}

/* k4889 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_4891(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?t1:C_SCHEME_FALSE);
/* setup-api.scm: 441  make-parameter */
((C_proc3)C_retrieve_symbol_proc(lf[304]))(3,*((C_word*)lf[304]+1),((C_word*)t0)[2],t2);}

/* k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_2893(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word ab[67],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2893,2,t0,t1);}
t2=C_mutate((C_word*)lf[163]+1 /* (set! setup-api#installation-prefix ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2896,a[2]=((C_word)li40),tmp=(C_word)a,a+=3,tmp);
t4=(C_truep(C_retrieve2(lf[14],"setup-api#*windows*"))?(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4852,a[2]=t3,a[3]=((C_word)li41),tmp=(C_word)a,a+=4,tmp):(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4860,a[2]=t3,a[3]=((C_word)li42),tmp=(C_word)a,a+=4,tmp));
t5=C_mutate((C_word*)lf[66]+1 /* (set! setup-api#create-directory/parents ...) */,t4);
t6=C_mutate(&lf[166] /* (set! setup-api#write-info ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2911,a[2]=((C_word)li45),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[175]+1 /* (set! setup-api#copy-file ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3025,a[2]=((C_word)li49),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[182]+1 /* (set! setup-api#move-file ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3175,a[2]=((C_word)li50),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[183]+1 /* (set! setup-api#remove-file* ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3230,a[2]=((C_word)li51),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate(&lf[184] /* (set! setup-api#make-dest-pathname ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3252,a[2]=((C_word)li52),tmp=(C_word)a,a+=3,tmp));
t11=C_mutate(&lf[186] /* (set! setup-api#check-filelist ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3277,a[2]=((C_word)li54),tmp=(C_word)a,a+=3,tmp));
t12=C_mutate((C_word*)lf[188]+1 /* (set! setup-api#install-extension ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3380,a[2]=((C_word)li58),tmp=(C_word)a,a+=3,tmp));
t13=C_mutate((C_word*)lf[203]+1 /* (set! setup-api#install-program ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3665,a[2]=((C_word)li62),tmp=(C_word)a,a+=3,tmp));
t14=C_mutate((C_word*)lf[210]+1 /* (set! setup-api#install-script ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3822,a[2]=((C_word)li64),tmp=(C_word)a,a+=3,tmp));
t15=C_mutate(&lf[172] /* (set! setup-api#repo-path ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3958,a[2]=((C_word)li65),tmp=(C_word)a,a+=3,tmp));
t16=C_mutate(&lf[180] /* (set! setup-api#ensure-directory ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4013,a[2]=((C_word)li66),tmp=(C_word)a,a+=3,tmp));
t17=C_mutate((C_word*)lf[216]+1 /* (set! setup-api#try-compile ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4066,a[2]=((C_word)li73),tmp=(C_word)a,a+=3,tmp));
t18=C_mutate((C_word*)lf[248]+1 /* (set! setup-api#required-chicken-version ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4178,a[2]=((C_word)li74),tmp=(C_word)a,a+=3,tmp));
t19=C_mutate(&lf[252] /* (set! setup-api#upgrade-message ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4198,a[2]=((C_word)li75),tmp=(C_word)a,a+=3,tmp));
t20=C_mutate((C_word*)lf[254]+1 /* (set! setup-api#required-extension-version ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4208,a[2]=((C_word)li77),tmp=(C_word)a,a+=3,tmp));
t21=C_mutate((C_word*)lf[262]+1 /* (set! setup-api#test-compile ...) */,C_retrieve(lf[216]));
t22=C_mutate((C_word*)lf[263]+1 /* (set! setup-api#find-library ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4317,a[2]=((C_word)li78),tmp=(C_word)a,a+=3,tmp));
t23=C_mutate((C_word*)lf[266]+1 /* (set! setup-api#find-header ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4331,a[2]=((C_word)li79),tmp=(C_word)a,a+=3,tmp));
t24=C_mutate((C_word*)lf[250]+1 /* (set! setup-api#version>=? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4341,a[2]=((C_word)li83),tmp=(C_word)a,a+=3,tmp));
t25=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4506,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t26=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4782,a[2]=((C_word)li95),tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 720  make-parameter */
((C_proc4)C_retrieve_symbol_proc(lf[304]))(4,*((C_word*)lf[304]+1),t25,lf[305],t26);}

/* a4781 in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_4782(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4782,3,t0,t1,t2);}
t3=(C_word)C_i_not(t2);
t4=(C_truep(t3)?t3:(C_word)C_i_nullp(t2));
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,lf[301]);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4798,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_listp(t2))){
t6=(C_word)C_i_length(t2);
t7=t5;
f_4798(t7,(C_word)C_i_nequalp(C_fix(2),t6));}
else{
t6=t5;
f_4798(t6,C_SCHEME_FALSE);}}}

/* k4796 in a4781 in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_fcall f_4798(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4798,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(C_word)C_i_cadr(((C_word*)t0)[3]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4805,a[2]=((C_word)li94),tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4828,a[2]=t3,a[3]=t4,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* setup-api.scm: 728  ensure-string */
f_4805(t5,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4835,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 730  warning */
((C_proc4)C_retrieve_symbol_proc(lf[177]))(4,*((C_word*)lf[177]+1),t2,lf[303],((C_word*)t0)[3]);}}

/* k4833 in k4796 in a4781 in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_4835(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 731  extension-name-and-version */
((C_proc2)C_retrieve_symbol_proc(lf[272]))(2,*((C_word*)lf[272]+1),((C_word*)t0)[2]);}

/* k4826 in k4796 in a4781 in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_4828(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4828,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4832,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 728  ensure-string */
f_4805(t2,((C_word*)t0)[2]);}

/* k4830 in k4826 in k4796 in a4781 in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_4832(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4832,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[2],t1));}

/* ensure-string in k4796 in a4781 in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_fcall f_4805(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4805,NULL,2,t1,t2);}
t3=(C_word)C_i_not(t2);
t4=(C_truep(t3)?t3:(C_word)C_i_nullp(t2));
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,lf[302]);}
else{
/* setup-api.scm: 727  ->string */
((C_proc3)C_retrieve_symbol_proc(lf[112]))(3,*((C_word*)lf[112]+1),t1,t2);}}

/* k4504 in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_4506(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[21],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4506,2,t0,t1);}
t2=C_mutate((C_word*)lf[272]+1 /* (set! setup-api#extension-name-and-version ...) */,t1);
t3=C_mutate((C_word*)lf[273]+1 /* (set! setup-api#extension-name ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4508,a[2]=((C_word)li84),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[274]+1 /* (set! setup-api#extension-version ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4518,a[2]=((C_word)li85),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[276]+1 /* (set! setup-api#read-info ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4562,a[2]=((C_word)li86),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[279]+1 /* (set! setup-api#create-temporary-directory ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4576,a[2]=((C_word)li88),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[287]+1 /* (set! setup-api#remove-directory ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4629,a[2]=((C_word)li91),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[296]+1 /* (set! setup-api#remove-extension ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4729,a[2]=((C_word)li92),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate(&lf[63] /* (set! setup-api#$system ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4760,a[2]=((C_word)li93),tmp=(C_word)a,a+=3,tmp));
t10=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_UNDEFINED);}

/* setup-api#$system in k4504 in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_fcall f_4760(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4760,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4764,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4777,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[13],"setup-api#*windows-shell*"))){
/* setup-api.scm: 786  string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[126]+1)))(5,*((C_word*)lf[126]+1),t4,lf[299],t2,lf[300]);}
else{
t5=t4;
f_4777(2,t5,t2);}}

/* k4775 in setup-api#$system in k4504 in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_4777(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 784  system */
((C_proc3)C_retrieve_symbol_proc(lf[220]))(3,*((C_word*)lf[220]+1),((C_word*)t0)[2],t1);}

/* k4762 in setup-api#$system in k4504 in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_4764(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_zerop(t1))){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
/* setup-api.scm: 789  error */
((C_proc5)C_retrieve_proc(*((C_word*)lf[116]+1)))(5,*((C_word*)lf[116]+1),((C_word*)t0)[3],lf[298],t1,((C_word*)t0)[2]);}}

/* setup-api#remove-extension in k4504 in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_4729(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4729,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4758,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 779  read-info */
((C_proc3)C_retrieve_symbol_proc(lf[276]))(3,*((C_word*)lf[276]+1),t3,t2);}

/* k4756 in setup-api#remove-extension in k4504 in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_4758(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4758,2,t0,t1);}
t2=(C_word)C_i_assq(lf[167],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4736,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t2)){
t4=(C_word)C_i_cdr(t2);
/* for-each */
t5=*((C_word*)lf[114]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,C_retrieve(lf[183]),t4);}
else{
t4=t3;
f_4736(2,t4,C_SCHEME_FALSE);}}

/* k4734 in k4756 in setup-api#remove-extension in k4504 in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_4736(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4736,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4743,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4747,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 781  repository-path */
((C_proc2)C_retrieve_symbol_proc(lf[171]))(2,*((C_word*)lf[171]+1),t3);}

/* k4745 in k4734 in k4756 in setup-api#remove-extension in k4504 in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_4747(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 781  make-pathname */
((C_proc5)C_retrieve_symbol_proc(lf[110]))(5,*((C_word*)lf[110]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2],lf[297]);}

/* k4741 in k4734 in k4756 in setup-api#remove-extension in k4504 in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_4743(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 781  remove-file* */
((C_proc3)C_retrieve_symbol_proc(lf[183]))(3,*((C_word*)lf[183]+1),((C_word*)t0)[2],t1);}

/* setup-api#remove-directory in k4504 in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_4629(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_4629r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4629r(t0,t1,t2,t3);}}

static void C_ccall f_4629r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4633,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_4633(2,t5,C_SCHEME_TRUE);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_4633(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[161]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k4631 in setup-api#remove-directory in k4504 in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_4633(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4633,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4708,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* setup-api.scm: 759  file-exists? */
((C_proc3)C_retrieve_symbol_proc(lf[134]))(3,*((C_word*)lf[134]+1),t2,((C_word*)t0)[2]);}

/* k4706 in k4631 in setup-api#remove-directory in k4504 in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_4708(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4708,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(C_retrieve2(lf[12],"setup-api#*sudo*"))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4655,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4659,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 764  shellpath */
((C_proc3)C_retrieve_symbol_proc(lf[19]))(3,*((C_word*)lf[19]+1),t3,((C_word*)t0)[3]);}
else{
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4664,a[2]=t3,a[3]=((C_word)li90),tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_4664(t5,((C_word*)t0)[4],((C_word*)t0)[3]);}}
else{
if(C_truep(((C_word*)t0)[2])){
/* setup-api.scm: 761  error */
((C_proc5)C_retrieve_proc(*((C_word*)lf[116]+1)))(5,*((C_word*)lf[116]+1),((C_word*)t0)[4],lf[294],lf[295],((C_word*)t0)[3]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}}

/* walk in k4706 in k4631 in setup-api#remove-directory in k4504 in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_fcall f_4664(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4664,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4668,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* setup-api.scm: 767  directory */
((C_proc4)C_retrieve_symbol_proc(lf[293]))(4,*((C_word*)lf[293]+1),t3,t2,C_SCHEME_TRUE);}

/* k4666 in walk in k4706 in k4631 in setup-api#remove-directory in k4504 in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_4668(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4668,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4671,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4676,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word)li89),tmp=(C_word)a,a+=5,tmp);
/* for-each */
t4=*((C_word*)lf[114]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,t1);}

/* a4675 in k4666 in walk in k4706 in k4631 in setup-api#remove-directory in k4504 in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_4676(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4676,3,t0,t1,t2);}
t3=(C_word)C_i_string_equal_p(lf[290],t2);
t4=(C_truep(t3)?t3:(C_word)C_i_string_equal_p(lf[291],t2));
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4689,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 771  make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[110]))(4,*((C_word*)lf[110]+1),t5,((C_word*)t0)[2],t2);}}

/* k4687 in a4675 in k4666 in walk in k4706 in k4631 in setup-api#remove-directory in k4504 in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_4689(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4689,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4695,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* setup-api.scm: 772  directory? */
((C_proc3)C_retrieve_symbol_proc(lf[60]))(3,*((C_word*)lf[60]+1),t2,t1);}

/* k4693 in k4687 in a4675 in k4666 in walk in k4706 in k4631 in setup-api#remove-directory in k4504 in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_4695(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* setup-api.scm: 773  walk */
t2=((C_word*)((C_word*)t0)[4])[1];
f_4664(t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* setup-api.scm: 774  delete-file */
((C_proc3)C_retrieve_symbol_proc(lf[292]))(3,*((C_word*)lf[292]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k4669 in k4666 in walk in k4706 in k4631 in setup-api#remove-directory in k4504 in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_4671(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 776  delete-directory */
((C_proc3)C_retrieve_symbol_proc(lf[289]))(3,*((C_word*)lf[289]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4657 in k4706 in k4631 in setup-api#remove-directory in k4504 in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_4659(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 764  sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[64]))(4,*((C_word*)lf[64]+1),((C_word*)t0)[2],lf[288],t1);}

/* k4653 in k4706 in k4631 in setup-api#remove-directory in k4504 in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_4655(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 764  $system */
f_4760(((C_word*)t0)[2],t1);}

/* setup-api#create-temporary-directory in k4504 in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_4576(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4576,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4580,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 748  get-environment-variable */
((C_proc3)C_retrieve_symbol_proc(lf[283]))(3,*((C_word*)lf[283]+1),t2,lf[286]);}

/* k4578 in setup-api#create-temporary-directory in k4504 in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_4580(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4580,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4583,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
t3=t2;
f_4583(t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4618,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 749  get-environment-variable */
((C_proc3)C_retrieve_symbol_proc(lf[283]))(3,*((C_word*)lf[283]+1),t3,lf[285]);}}

/* k4616 in k4578 in setup-api#create-temporary-directory in k4504 in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_4618(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4618,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
f_4583(t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4624,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 750  get-environment-variable */
((C_proc3)C_retrieve_symbol_proc(lf[283]))(3,*((C_word*)lf[283]+1),t2,lf[284]);}}

/* k4622 in k4616 in k4578 in setup-api#create-temporary-directory in k4504 in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_4624(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_4583(t2,(C_truep(t1)?t1:lf[282]));}

/* k4581 in k4578 in setup-api#create-temporary-directory in k4504 in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_fcall f_4583(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4583,NULL,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4588,a[2]=t1,a[3]=t3,a[4]=((C_word)li87),tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_4588(t5,((C_word*)t0)[2]);}

/* loop in k4581 in k4578 in setup-api#create-temporary-directory in k4504 in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_fcall f_4588(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4588,NULL,2,t0,t1);}
t2=(C_word)C_fudge(C_fix(16));
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4595,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4611,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4615,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 754  number->string */
C_number_to_string(4,0,t5,t2,C_fix(16));}

/* k4613 in loop in k4581 in k4578 in setup-api#create-temporary-directory in k4504 in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_4615(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 754  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[126]+1)))(4,*((C_word*)lf[126]+1),((C_word*)t0)[2],lf[281],t1);}

/* k4609 in loop in k4581 in k4578 in setup-api#create-temporary-directory in k4504 in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_4611(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 754  make-pathname */
((C_proc5)C_retrieve_symbol_proc(lf[110]))(5,*((C_word*)lf[110]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1,lf[280]);}

/* k4593 in loop in k4581 in k4578 in setup-api#create-temporary-directory in k4504 in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_4595(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4595,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4601,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* setup-api.scm: 755  file-exists? */
((C_proc3)C_retrieve_symbol_proc(lf[134]))(3,*((C_word*)lf[134]+1),t2,t1);}

/* k4599 in k4593 in loop in k4581 in k4578 in setup-api#create-temporary-directory in k4504 in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_4601(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4601,2,t0,t1);}
if(C_truep(t1)){
/* setup-api.scm: 755  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_4588(t2,((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4607,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 756  create-directory */
((C_proc3)C_retrieve_symbol_proc(lf[58]))(3,*((C_word*)lf[58]+1),t2,((C_word*)t0)[2]);}}

/* k4605 in k4599 in k4593 in loop in k4581 in k4578 in setup-api#create-temporary-directory in k4504 in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_4607(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* setup-api#read-info in k4504 in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_4562(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4562,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4570,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4574,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 744  repository-path */
((C_proc2)C_retrieve_symbol_proc(lf[171]))(2,*((C_word*)lf[171]+1),t4);}

/* k4572 in setup-api#read-info in k4504 in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_4574(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 744  make-pathname */
((C_proc5)C_retrieve_symbol_proc(lf[110]))(5,*((C_word*)lf[110]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2],lf[278]);}

/* k4568 in setup-api#read-info in k4504 in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_4570(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 743  with-input-from-file */
((C_proc4)C_retrieve_symbol_proc(lf[85]))(4,*((C_word*)lf[85]+1),((C_word*)t0)[2],t1,*((C_word*)lf[277]+1));}

/* setup-api#extension-version in k4504 in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_4518(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_4518r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4518r(t0,t1,t2);}}

static void C_ccall f_4518r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4522,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
t4=t3;
f_4522(2,t4,C_SCHEME_FALSE);}
else{
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t4))){
t5=t3;
f_4522(2,t5,(C_word)C_i_car(t2));}
else{
/* ##sys#error */
t5=*((C_word*)lf[161]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,lf[0],t2);}}}

/* k4520 in setup-api#extension-version in k4504 in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_4522(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4522,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4541,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 737  extension-name-and-version */
((C_proc2)C_retrieve_symbol_proc(lf[272]))(2,*((C_word*)lf[272]+1),t2);}

/* k4539 in k4520 in setup-api#extension-version in k4504 in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_4541(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4541,2,t0,t1);}
t2=(C_word)C_i_cadr(t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4531,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* setup-api.scm: 738  string-null? */
((C_proc3)C_retrieve_symbol_proc(lf[275]))(3,*((C_word*)lf[275]+1),t3,t2);}

/* k4529 in k4539 in k4520 in setup-api#extension-version in k4504 in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_4531(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
if(C_truep(((C_word*)t0)[4])){
/* setup-api.scm: 739  ->string */
((C_proc3)C_retrieve_symbol_proc(lf[112]))(3,*((C_word*)lf[112]+1),((C_word*)t0)[3],((C_word*)t0)[4]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* setup-api#extension-name in k4504 in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_4508(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4508,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4516,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 734  extension-name-and-version */
((C_proc2)C_retrieve_symbol_proc(lf[272]))(2,*((C_word*)lf[272]+1),t2);}

/* k4514 in setup-api#extension-name in k4504 in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_4516(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_car(t1));}

/* setup-api#version>=? in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_4341(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4341,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4344,a[2]=((C_word)li81),tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4372,a[2]=t3,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* setup-api.scm: 704  version->list */
f_4344(t5,t2);}

/* k4370 in setup-api#version>=? in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_4372(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4372,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4376,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 705  version->list */
f_4344(t2,((C_word*)t0)[2]);}

/* k4374 in k4370 in setup-api#version>=? in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_4376(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4376,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4378,a[2]=t3,a[3]=((C_word)li82),tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_4378(t5,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* loop in k4374 in k4370 in setup-api#version>=? in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_fcall f_4378(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word *a;
loop:
a=C_alloc(6);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4378,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_nullp(t3));}
else{
t4=(C_word)C_i_nullp(t3);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_numberp(t5))){
t6=(C_word)C_i_car(t3);
if(C_truep((C_word)C_i_numberp(t6))){
t7=(C_word)C_i_car(t2);
t8=(C_word)C_i_car(t3);
t9=(C_word)C_i_greaterp(t7,t8);
if(C_truep(t9)){
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,t9);}
else{
t10=(C_word)C_i_car(t2);
t11=(C_word)C_i_car(t3);
if(C_truep((C_word)C_i_nequalp(t10,t11))){
t12=(C_word)C_i_cdr(t2);
t13=(C_word)C_i_cdr(t3);
/* setup-api.scm: 712  loop */
t20=t1;
t21=t12;
t22=t13;
t1=t20;
t2=t21;
t3=t22;
goto loop;}
else{
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_FALSE);}}}
else{
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_SCHEME_FALSE);}}
else{
t6=(C_word)C_i_car(t3);
t7=(C_word)C_i_numberp(t6);
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}
else{
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4458,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t9=(C_word)C_i_car(t2);
t10=(C_word)C_i_car(t3);
/* setup-api.scm: 714  string>? */
((C_proc4)C_retrieve_proc(*((C_word*)lf[271]+1)))(4,*((C_word*)lf[271]+1),t8,t9,t10);}}}}}

/* k4456 in loop in k4374 in k4370 in setup-api#version>=? in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_4458(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_string_equal_p(t2,t3))){
t4=(C_word)C_i_cdr(((C_word*)t0)[4]);
t5=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* setup-api.scm: 717  loop */
t6=((C_word*)((C_word*)t0)[2])[1];
f_4378(t6,((C_word*)t0)[5],t4,t5);}
else{
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}}

/* version->list in setup-api#version>=? in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_fcall f_4344(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4344,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4350,a[2]=((C_word)li80),tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4361,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4365,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 703  ->string */
((C_proc3)C_retrieve_symbol_proc(lf[112]))(3,*((C_word*)lf[112]+1),t5,t2);}

/* k4363 in version->list in setup-api#version>=? in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_4365(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 703  string-split-fields */
((C_proc5)C_retrieve_symbol_proc(lf[268]))(5,*((C_word*)lf[268]+1),((C_word*)t0)[2],lf[269],t1,lf[270]);}

/* k4359 in version->list in setup-api#version>=? in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_4361(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[111]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a4349 in version->list in setup-api#version>=? in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_4350(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4350,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4354,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 702  string->number */
C_string_to_number(3,0,t3,t2);}

/* k4352 in a4349 in version->list in setup-api#version>=? in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_4354(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?t1:((C_word*)t0)[2]));}

/* setup-api#find-header in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_4331(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4331,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4339,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 697  sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[64]))(4,*((C_word*)lf[64]+1),t3,lf[267],t2);}

/* k4337 in setup-api#find-header in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_4339(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 696  test-compile */
((C_proc5)C_retrieve_symbol_proc(lf[262]))(5,*((C_word*)lf[262]+1),((C_word*)t0)[2],t1,lf[240],C_SCHEME_TRUE);}

/* setup-api#find-library in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_4317(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4317,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4325,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 692  sprintf */
((C_proc5)C_retrieve_symbol_proc(lf[64]))(5,*((C_word*)lf[64]+1),t4,lf[265],t3,t3);}

/* k4323 in setup-api#find-library in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_4325(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4325,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4329,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 693  conc */
((C_proc4)C_retrieve_symbol_proc(lf[226]))(4,*((C_word*)lf[226]+1),t2,lf[264],((C_word*)t0)[2]);}

/* k4327 in k4323 in setup-api#find-library in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_4329(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 691  test-compile */
((C_proc5)C_retrieve_symbol_proc(lf[262]))(5,*((C_word*)lf[262]+1),((C_word*)t0)[3],((C_word*)t0)[2],lf[243],t1);}

/* setup-api#required-extension-version in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_4208(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr2r,(void*)f_4208r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4208r(t0,t1,t2);}}

static void C_ccall f_4208r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4214,a[2]=t4,a[3]=((C_word)li76),tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_4214(t6,t1,t2);}

/* loop in setup-api#required-extension-version in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_fcall f_4214(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4214,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4227,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_listp(t2))){
t4=(C_word)C_i_length(t2);
t5=t3;
f_4227(t5,(C_word)C_i_greater_or_equalp(t4,C_fix(2)));}
else{
t4=t3;
f_4227(t4,C_SCHEME_FALSE);}}}

/* k4225 in loop in setup-api#required-extension-version in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_fcall f_4227(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4227,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
t4=(C_word)C_i_cddr(((C_word*)t0)[4]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4239,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* setup-api.scm: 674  extension-information */
((C_proc3)C_retrieve_symbol_proc(lf[259]))(3,*((C_word*)lf[259]+1),t5,t2);}
else{
/* setup-api.scm: 686  error */
((C_proc5)C_retrieve_proc(*((C_word*)lf[116]+1)))(5,*((C_word*)lf[116]+1),((C_word*)t0)[3],lf[260],lf[261],((C_word*)t0)[4]);}}

/* k4237 in k4225 in loop in setup-api#required-extension-version in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_4239(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4239,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4245,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_assq(lf[257],t1))){
t3=(C_word)C_i_assq(lf[257],t1);
t4=t2;
f_4245(t4,(C_word)C_i_cadr(t3));}
else{
t3=t2;
f_4245(t3,C_SCHEME_FALSE);}}
else{
/* setup-api.scm: 684  upgrade-message */
f_4198(((C_word*)t0)[6],((C_word*)t0)[5],lf[258]);}}

/* k4243 in k4237 in k4225 in loop in setup-api#required-extension-version in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_fcall f_4245(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4245,NULL,2,t0,t1);}
t2=t1;
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4260,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4273,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* setup-api.scm: 678  version>=? */
((C_proc4)C_retrieve_symbol_proc(lf[250]))(4,*((C_word*)lf[250]+1),t4,((C_word*)t0)[4],t1);}
else{
/* setup-api.scm: 677  upgrade-message */
f_4198(((C_word*)t0)[6],((C_word*)t0)[5],lf[256]);}}

/* k4271 in k4243 in k4237 in k4225 in loop in setup-api#required-extension-version in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_4273(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4273,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4284,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 678  ->string */
((C_proc3)C_retrieve_symbol_proc(lf[112]))(3,*((C_word*)lf[112]+1),t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
f_4260(t2,C_SCHEME_FALSE);}}

/* k4282 in k4271 in k4243 in k4237 in k4225 in loop in setup-api#required-extension-version in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_4284(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4284,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4288,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 678  ->string */
((C_proc3)C_retrieve_symbol_proc(lf[112]))(3,*((C_word*)lf[112]+1),t2,((C_word*)t0)[2]);}

/* k4286 in k4282 in k4271 in k4243 in k4237 in k4225 in loop in setup-api#required-extension-version in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_4288(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_string_equal_p(((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
f_4260(t3,(C_word)C_i_not(t2));}

/* k4258 in k4243 in k4237 in k4225 in loop in setup-api#required-extension-version in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_fcall f_4260(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4260,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4267,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 681  sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[64]))(4,*((C_word*)lf[64]+1),t2,lf[255],((C_word*)t0)[4]);}
else{
/* setup-api.scm: 683  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_4214(t2,((C_word*)t0)[6],((C_word*)t0)[2]);}}

/* k4265 in k4258 in k4243 in k4237 in k4225 in loop in setup-api#required-extension-version in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_4267(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 679  upgrade-message */
f_4198(((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* setup-api#upgrade-message in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_fcall f_4198(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4198,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4206,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 663  sprintf */
((C_proc6)C_retrieve_symbol_proc(lf[64]))(6,*((C_word*)lf[64]+1),t4,lf[253],t2,t3,t2);}

/* k4204 in setup-api#upgrade-message in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_4206(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 662  error */
((C_proc3)C_retrieve_proc(*((C_word*)lf[116]+1)))(3,*((C_word*)lf[116]+1),((C_word*)t0)[2],t1);}

/* setup-api#required-chicken-version in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_4178(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4178,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4185,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4196,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 658  chicken-version */
((C_proc2)C_retrieve_symbol_proc(lf[251]))(2,*((C_word*)lf[251]+1),t4);}

/* k4194 in setup-api#required-chicken-version in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_4196(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 658  version>=? */
((C_proc4)C_retrieve_symbol_proc(lf[250]))(4,*((C_word*)lf[250]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4183 in setup-api#required-chicken-version in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_4185(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4185,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4192,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 659  sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[64]))(4,*((C_word*)lf[64]+1),t2,lf[249],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k4190 in k4183 in setup-api#required-chicken-version in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_4192(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 659  error */
((C_proc3)C_retrieve_proc(*((C_word*)lf[116]+1)))(3,*((C_word*)lf[116]+1),((C_word*)t0)[2],t1);}

/* setup-api#try-compile in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_4066(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_4066r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4066r(t0,t1,t2,t3);}}

static void C_ccall f_4066r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4070,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* ##sys#get-keyword */
((C_proc4)C_retrieve_symbol_proc(lf[79]))(4,*((C_word*)lf[79]+1),t4,lf[247],t3);}

/* k4068 in setup-api#try-compile in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_4070(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4070,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4073,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4172,a[2]=t1,a[3]=((C_word)li72),tmp=(C_word)a,a+=4,tmp);
/* ##sys#get-keyword */
((C_proc5)C_retrieve_symbol_proc(lf[79]))(5,*((C_word*)lf[79]+1),t2,lf[246],((C_word*)t0)[2],t3);}

/* a4171 in k4068 in setup-api#try-compile in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_4172(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4172,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(((C_word*)t0)[2])?C_retrieve2(lf[8],"setup-api#*cxx*"):C_retrieve2(lf[7],"setup-api#*cc*")));}

/* k4071 in k4068 in setup-api#try-compile in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_4073(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4073,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4076,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4169,a[2]=((C_word)li71),tmp=(C_word)a,a+=3,tmp);
/* ##sys#get-keyword */
((C_proc5)C_retrieve_symbol_proc(lf[79]))(5,*((C_word*)lf[79]+1),t2,lf[245],((C_word*)t0)[2],t3);}

/* a4168 in k4071 in k4068 in setup-api#try-compile in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_4169(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4169,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[244]);}

/* k4074 in k4071 in k4068 in setup-api#try-compile in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_4076(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4076,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4079,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4166,a[2]=((C_word)li70),tmp=(C_word)a,a+=3,tmp);
/* ##sys#get-keyword */
((C_proc5)C_retrieve_symbol_proc(lf[79]))(5,*((C_word*)lf[79]+1),t2,lf[243],((C_word*)t0)[2],t3);}

/* a4165 in k4074 in k4071 in k4068 in setup-api#try-compile in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_4166(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4166,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[242]);}

/* k4077 in k4074 in k4071 in k4068 in setup-api#try-compile in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_4079(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4079,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4082,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4160,a[2]=((C_word)li69),tmp=(C_word)a,a+=3,tmp);
/* ##sys#get-keyword */
((C_proc5)C_retrieve_symbol_proc(lf[79]))(5,*((C_word*)lf[79]+1),t2,lf[241],((C_word*)t0)[2],t3);}

/* a4159 in k4077 in k4074 in k4071 in k4068 in setup-api#try-compile in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_4160(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4160,2,t0,t1);}
/* setup-api.scm: 635  setup-verbose-mode */
((C_proc2)C_retrieve_symbol_proc(lf[25]))(2,*((C_word*)lf[25]+1),t1);}

/* k4080 in k4077 in k4074 in k4071 in k4068 in setup-api#try-compile in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_4082(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4082,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4085,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4157,a[2]=((C_word)li68),tmp=(C_word)a,a+=3,tmp);
/* ##sys#get-keyword */
((C_proc5)C_retrieve_symbol_proc(lf[79]))(5,*((C_word*)lf[79]+1),t2,lf[240],((C_word*)t0)[2],t3);}

/* a4156 in k4080 in k4077 in k4074 in k4071 in k4068 in setup-api#try-compile in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_4157(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4157,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* k4083 in k4080 in k4077 in k4074 in k4071 in k4068 in setup-api#try-compile in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_4085(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4085,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4088,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* setup-api.scm: 636  create-temporary-file */
((C_proc3)C_retrieve_symbol_proc(lf[88]))(3,*((C_word*)lf[88]+1),t2,lf[239]);}

/* k4086 in k4083 in k4080 in k4077 in k4074 in k4071 in k4068 in setup-api#try-compile in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_4088(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4088,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4091,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* setup-api.scm: 637  pathname-replace-extension */
((C_proc4)C_retrieve_symbol_proc(lf[92]))(4,*((C_word*)lf[92]+1),t2,t1,lf[238]);}

/* k4089 in k4086 in k4083 in k4080 in k4077 in k4074 in k4071 in k4068 in setup-api#try-compile in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_4091(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4091,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4094,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4151,a[2]=((C_word*)t0)[2],a[3]=((C_word)li67),tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 639  with-output-to-file */
((C_proc4)C_retrieve_symbol_proc(lf[86]))(4,*((C_word*)lf[86]+1),t2,((C_word*)t0)[8],t3);}

/* a4150 in k4089 in k4086 in k4083 in k4080 in k4077 in k4074 in k4071 in k4068 in setup-api#try-compile in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_4151(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4151,2,t0,t1);}
/* display */
((C_proc3)C_retrieve_proc(*((C_word*)lf[237]+1)))(3,*((C_word*)lf[237]+1),t1,((C_word*)t0)[2]);}

/* k4092 in k4089 in k4086 in k4083 in k4080 in k4077 in k4074 in k4071 in k4068 in setup-api#try-compile in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_4094(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4094,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4097,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4128,a[2]=((C_word*)t0)[6],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_truep(((C_word*)t0)[5])?lf[222]:lf[223]);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4142,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=((C_word*)t0)[4],a[6]=t3,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[5])){
t6=t5;
f_4142(2,t6,lf[233]);}
else{
/* setup-api.scm: 648  conc */
((C_proc8)C_retrieve_symbol_proc(lf[226]))(8,*((C_word*)lf[226]+1),t5,lf[234],C_retrieve2(lf[11],"setup-api#*target-lib-home*"),lf[235],((C_word*)t0)[2],lf[236],C_retrieve2(lf[10],"setup-api#*target-libs*"));}}

/* k4140 in k4092 in k4089 in k4086 in k4083 in k4080 in k4077 in k4074 in k4071 in k4068 in setup-api#try-compile in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_4142(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(((C_word*)t0)[7])?lf[224]:lf[225]);
/* setup-api.scm: 641  conc */
((C_proc15)C_retrieve_symbol_proc(lf[226]))(15,*((C_word*)lf[226]+1),((C_word*)t0)[6],((C_word*)t0)[5],lf[227],((C_word*)t0)[4],lf[228],((C_word*)t0)[3],lf[229],C_retrieve2(lf[9],"setup-api#*target-cflags*"),lf[230],((C_word*)t0)[2],lf[231],t1,lf[232],t2);}

/* k4126 in k4092 in k4089 in k4086 in k4083 in k4080 in k4077 in k4074 in k4071 in k4068 in setup-api#try-compile in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_4128(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4128,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4131,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[2])){
/* setup-api.scm: 651  print */
((C_proc4)C_retrieve_proc(*((C_word*)lf[50]+1)))(4,*((C_word*)lf[50]+1),t2,t1,lf[221]);}
else{
t3=t2;
f_4131(2,t3,C_SCHEME_UNDEFINED);}}

/* k4129 in k4126 in k4092 in k4089 in k4086 in k4083 in k4080 in k4077 in k4074 in k4071 in k4068 in setup-api#try-compile in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_4131(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 640  system */
((C_proc3)C_retrieve_symbol_proc(lf[220]))(3,*((C_word*)lf[220]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4095 in k4092 in k4089 in k4086 in k4083 in k4080 in k4077 in k4074 in k4071 in k4068 in setup-api#try-compile in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_4097(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4097,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4100,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(C_word)C_i_zerop(t1);
t4=(C_truep(t3)?lf[218]:lf[219]);
/* setup-api.scm: 653  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[50]+1)))(3,*((C_word*)lf[50]+1),t2,t4);}
else{
t3=t2;
f_4100(2,t3,C_SCHEME_UNDEFINED);}}

/* k4098 in k4095 in k4092 in k4089 in k4086 in k4083 in k4080 in k4077 in k4074 in k4071 in k4068 in setup-api#try-compile in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_4100(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4100,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4103,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4110,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4114,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 654  shellpath */
((C_proc3)C_retrieve_symbol_proc(lf[19]))(3,*((C_word*)lf[19]+1),t4,((C_word*)t0)[2]);}

/* k4112 in k4098 in k4095 in k4092 in k4089 in k4086 in k4083 in k4080 in k4077 in k4074 in k4071 in k4068 in setup-api#try-compile in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_4114(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 654  sprintf */
((C_proc5)C_retrieve_symbol_proc(lf[64]))(5,*((C_word*)lf[64]+1),((C_word*)t0)[2],lf[217],C_retrieve2(lf[32],"setup-api#*remove-command*"),t1);}

/* k4108 in k4098 in k4095 in k4092 in k4089 in k4086 in k4083 in k4080 in k4077 in k4074 in k4071 in k4068 in setup-api#try-compile in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_4110(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 654  $system */
f_4760(((C_word*)t0)[2],t1);}

/* k4101 in k4098 in k4095 in k4092 in k4089 in k4086 in k4083 in k4080 in k4077 in k4074 in k4071 in k4068 in setup-api#try-compile in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_4103(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_zerop(((C_word*)t0)[2]));}

/* setup-api#ensure-directory in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_fcall f_4013(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4013,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4017,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 624  pathname-directory */
((C_proc3)C_retrieve_symbol_proc(lf[59]))(3,*((C_word*)lf[59]+1),t3,t2);}

/* k4015 in setup-api#ensure-directory in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_4017(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4017,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4020,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4026,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 625  file-exists? */
((C_proc3)C_retrieve_symbol_proc(lf[134]))(3,*((C_word*)lf[134]+1),t3,t1);}
else{
t3=t2;
f_4020(2,t3,C_SCHEME_FALSE);}}

/* k4024 in k4015 in setup-api#ensure-directory in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_4026(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4026,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4032,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 626  directory? */
((C_proc3)C_retrieve_symbol_proc(lf[60]))(3,*((C_word*)lf[60]+1),t2,((C_word*)t0)[2]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4038,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 629  create-directory/parents */
((C_proc3)C_retrieve_symbol_proc(lf[66]))(3,*((C_word*)lf[66]+1),t2,((C_word*)t0)[2]);}}

/* k4036 in k4024 in k4015 in setup-api#ensure-directory in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_4038(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4038,2,t0,t1);}
if(C_truep(C_retrieve2(lf[13],"setup-api#*windows-shell*"))){
t2=((C_word*)t0)[3];
f_4020(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4064,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 631  shellpath */
((C_proc3)C_retrieve_symbol_proc(lf[19]))(3,*((C_word*)lf[19]+1),t2,((C_word*)t0)[2]);}}

/* k4062 in k4036 in k4024 in k4015 in setup-api#ensure-directory in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_4064(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4064,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[215],t2);
t4=(C_word)C_a_i_cons(&a,2,C_retrieve2(lf[34],"setup-api#*chmod-command*"),t3);
t5=(C_word)C_a_i_list(&a,1,t4);
/* setup-api#execute */
((C_proc3)C_retrieve_symbol_proc(lf[97]))(3,*((C_word*)lf[97]+1),((C_word*)t0)[2],t5);}

/* k4030 in k4024 in k4015 in setup-api#ensure-directory in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_4032(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[2];
f_4020(2,t2,C_SCHEME_UNDEFINED);}
else{
/* setup-api.scm: 627  error */
((C_proc3)C_retrieve_proc(*((C_word*)lf[116]+1)))(3,*((C_word*)lf[116]+1),((C_word*)t0)[2],lf[214]);}}

/* k4018 in k4015 in setup-api#ensure-directory in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_4020(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* setup-api#repo-path in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_fcall f_3958(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3958,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3962,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
t4=t3;
f_3962(2,t4,C_SCHEME_FALSE);}
else{
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t4))){
t5=t3;
f_3962(2,t5,(C_word)C_i_car(t2));}
else{
/* ##sys#error */
t5=*((C_word*)lf[161]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,lf[0],t2);}}}

/* k3960 in setup-api#repo-path in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_3962(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3962,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3965,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3971,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
/* setup-api.scm: 615  installation-prefix */
((C_proc2)C_retrieve_symbol_proc(lf[163]))(2,*((C_word*)lf[163]+1),t3);}
else{
t4=t3;
f_3971(2,t4,C_SCHEME_FALSE);}}

/* k3969 in k3960 in setup-api#repo-path in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_3971(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3971,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3978,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 617  installation-prefix */
((C_proc2)C_retrieve_symbol_proc(lf[163]))(2,*((C_word*)lf[163]+1),t2);}
else{
/* setup-api.scm: 619  repository-path */
((C_proc2)C_retrieve_symbol_proc(lf[171]))(2,*((C_word*)lf[171]+1),((C_word*)t0)[2]);}}

/* k3976 in k3969 in k3960 in setup-api#repo-path in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_3978(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3978,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3982,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_fudge(C_fix(42));
/* setup-api.scm: 618  sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[64]))(4,*((C_word*)lf[64]+1),t2,lf[213],t3);}

/* k3980 in k3976 in k3969 in k3960 in setup-api#repo-path in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_3982(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 616  make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[110]))(4,*((C_word*)lf[110]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3963 in k3960 in setup-api#repo-path in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_3965(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3965,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3968,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 620  ensure-directory */
f_4013(t2,t1);}

/* k3966 in k3963 in k3960 in setup-api#repo-path in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_3968(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* setup-api#install-script in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_3822(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_3822r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3822r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3822r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3826,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_3826(2,t6,C_SCHEME_END_OF_LIST);}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_3826(2,t7,(C_word)C_i_car(t4));}
else{
/* ##sys#error */
t7=*((C_word*)lf[161]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* k3824 in setup-api#install-script in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_3826(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3826,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3832,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* setup-api.scm: 592  setup-install-mode */
((C_proc2)C_retrieve_symbol_proc(lf[26]))(2,*((C_word*)lf[26]+1),t2);}

/* k3830 in k3824 in setup-api#install-script in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_3832(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3832,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3835,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_listp(((C_word*)t0)[2]);
t4=(C_truep(t3)?((C_word*)t0)[2]:(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]));
/* setup-api.scm: 593  check-filelist */
f_3277(t2,t4);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k3833 in k3830 in k3824 in setup-api#install-script in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_3835(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3835,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3838,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* setup-api.scm: 598  installation-prefix */
((C_proc2)C_retrieve_symbol_proc(lf[163]))(2,*((C_word*)lf[163]+1),t2);}

/* k3836 in k3833 in k3830 in k3824 in setup-api#install-script in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_3838(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3838,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3841,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3924,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 596  make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[110]))(4,*((C_word*)lf[110]+1),t3,t1,lf[212]);}
else{
/* setup-api.scm: 597  program-path */
((C_proc2)C_retrieve_symbol_proc(lf[29]))(2,*((C_word*)lf[29]+1),t2);}}

/* k3922 in k3836 in k3833 in k3830 in k3824 in setup-api#install-script in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_3924(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 596  ensure-directory */
f_4013(((C_word*)t0)[2],t1);}

/* k3839 in k3836 in k3833 in k3830 in k3824 in setup-api#install-script in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_3841(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3841,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3844,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3875,a[2]=t1,a[3]=((C_word)li63),tmp=(C_word)a,a+=4,tmp);
/* map */
t4=*((C_word*)lf[111]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a3874 in k3839 in k3836 in k3833 in k3830 in k3824 in setup-api#install-script in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_3875(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3875,3,t0,t1,t2);}
t3=(C_word)C_i_pairp(t2);
t4=(C_truep(t3)?(C_word)C_i_car(t2):t2);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3882,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 601  make-dest-pathname */
f_3252(t5,((C_word*)t0)[2],t2);}

/* k3880 in a3874 in k3839 in k3836 in k3833 in k3830 in k3824 in setup-api#install-script in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_3882(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3882,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3885,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 602  copy-file */
((C_proc4)C_retrieve_symbol_proc(lf[175]))(4,*((C_word*)lf[175]+1),t2,((C_word*)t0)[2],t1);}

/* k3883 in k3880 in a3874 in k3839 in k3836 in k3833 in k3830 in k3824 in setup-api#install-script in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_3885(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3885,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3888,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[13],"setup-api#*windows-shell*"))){
t3=t2;
f_3888(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3911,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 604  shellpath */
((C_proc3)C_retrieve_symbol_proc(lf[19]))(3,*((C_word*)lf[19]+1),t3,((C_word*)t0)[2]);}}

/* k3909 in k3883 in k3880 in a3874 in k3839 in k3836 in k3833 in k3830 in k3824 in setup-api#install-script in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_3911(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3911,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[168],t2);
t4=(C_word)C_a_i_cons(&a,2,C_retrieve2(lf[34],"setup-api#*chmod-command*"),t3);
t5=(C_word)C_a_i_list(&a,1,t4);
/* setup-api#execute */
((C_proc3)C_retrieve_symbol_proc(lf[97]))(3,*((C_word*)lf[97]+1),((C_word*)t0)[2],t5);}

/* k3886 in k3883 in k3880 in a3874 in k3839 in k3836 in k3833 in k3830 in k3824 in setup-api#install-script in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_3888(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k3842 in k3839 in k3836 in k3833 in k3830 in k3824 in setup-api#install-script in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_3844(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3844,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3847,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_retrieve2(lf[13],"setup-api#*windows-shell*"))){
t3=t2;
f_3847(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3873,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 608  string-intersperse */
((C_proc4)C_retrieve_symbol_proc(lf[98]))(4,*((C_word*)lf[98]+1),t3,t1,lf[211]);}}

/* k3871 in k3842 in k3839 in k3836 in k3833 in k3830 in k3824 in setup-api#install-script in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_3873(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3873,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[192],t2);
t4=(C_word)C_a_i_cons(&a,2,C_retrieve2(lf[34],"setup-api#*chmod-command*"),t3);
t5=(C_word)C_a_i_list(&a,1,t4);
/* setup-api#execute */
((C_proc3)C_retrieve_symbol_proc(lf[97]))(3,*((C_word*)lf[97]+1),((C_word*)t0)[2],t5);}

/* k3845 in k3842 in k3839 in k3836 in k3833 in k3830 in k3824 in setup-api#install-script in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_3847(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 609  write-info */
f_2911(((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* setup-api#install-program in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_3665(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_3665r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3665r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3665r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3669,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_3669(2,t6,C_SCHEME_END_OF_LIST);}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_3669(2,t7,(C_word)C_i_car(t4));}
else{
/* ##sys#error */
t7=*((C_word*)lf[161]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* k3667 in setup-api#install-program in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_3669(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3669,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3671,a[2]=((C_word)li59),tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3685,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* setup-api.scm: 567  setup-install-mode */
((C_proc2)C_retrieve_symbol_proc(lf[26]))(2,*((C_word*)lf[26]+1),t3);}

/* k3683 in k3667 in setup-api#install-program in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_3685(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3685,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3688,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_listp(((C_word*)t0)[2]);
t4=(C_truep(t3)?((C_word*)t0)[2]:(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]));
/* setup-api.scm: 568  check-filelist */
f_3277(t2,t4);}
else{
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k3686 in k3683 in k3667 in setup-api#install-program in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_3688(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3688,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3691,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* setup-api.scm: 573  installation-prefix */
((C_proc2)C_retrieve_symbol_proc(lf[163]))(2,*((C_word*)lf[163]+1),t2);}

/* k3689 in k3686 in k3683 in k3667 in setup-api#install-program in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_3691(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3691,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3694,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3788,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 571  make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[110]))(4,*((C_word*)lf[110]+1),t3,t1,lf[209]);}
else{
/* setup-api.scm: 572  program-path */
((C_proc2)C_retrieve_symbol_proc(lf[29]))(2,*((C_word*)lf[29]+1),t2);}}

/* k3786 in k3689 in k3686 in k3683 in k3667 in setup-api#install-program in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_3788(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 571  ensure-directory */
f_4013(((C_word*)t0)[2],t1);}

/* k3692 in k3689 in k3686 in k3683 in k3667 in setup-api#install-program in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_3694(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3694,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3697,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_retrieve2(lf[14],"setup-api#*windows*"))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3752,a[2]=((C_word*)t0)[3],a[3]=((C_word)li61),tmp=(C_word)a,a+=4,tmp);
/* map */
t4=*((C_word*)lf[111]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}
else{
t3=t2;
f_3697(2,t3,((C_word*)t0)[2]);}}

/* a3751 in k3692 in k3689 in k3686 in k3683 in k3667 in setup-api#install-program in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_3752(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3752,3,t0,t1,t2);}
if(C_truep((C_word)C_i_listp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3766,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_car(t2);
/* setup-api.scm: 577  exify */
f_3671(t3,t4);}
else{
/* setup-api.scm: 578  exify */
f_3671(t1,t2);}}

/* k3764 in a3751 in k3692 in k3689 in k3686 in k3683 in k3667 in setup-api#install-program in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_3766(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3766,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3770,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[3]);
/* setup-api.scm: 577  exify */
f_3671(t2,t3);}

/* k3768 in k3764 in a3751 in k3692 in k3689 in k3686 in k3683 in k3667 in setup-api#install-program in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_3770(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3770,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[2],t1));}

/* k3695 in k3692 in k3689 in k3686 in k3683 in k3667 in setup-api#install-program in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_3697(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3697,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3700,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3705,a[2]=((C_word*)t0)[2],a[3]=((C_word)li60),tmp=(C_word)a,a+=4,tmp);
/* map */
t4=*((C_word*)lf[111]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,t1);}

/* a3704 in k3695 in k3692 in k3689 in k3686 in k3683 in k3667 in setup-api#install-program in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_3705(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3705,3,t0,t1,t2);}
t3=(C_word)C_i_pairp(t2);
t4=(C_truep(t3)?(C_word)C_i_car(t2):t2);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3712,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 583  make-dest-pathname */
f_3252(t5,((C_word*)t0)[2],t2);}

/* k3710 in a3704 in k3695 in k3692 in k3689 in k3686 in k3683 in k3667 in setup-api#install-program in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_3712(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3712,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3715,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 584  copy-file */
((C_proc4)C_retrieve_symbol_proc(lf[175]))(4,*((C_word*)lf[175]+1),t2,((C_word*)t0)[2],t1);}

/* k3713 in k3710 in a3704 in k3695 in k3692 in k3689 in k3686 in k3683 in k3667 in setup-api#install-program in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_3715(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3715,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3718,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[13],"setup-api#*windows-shell*"))){
t3=t2;
f_3718(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3741,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 586  shellpath */
((C_proc3)C_retrieve_symbol_proc(lf[19]))(3,*((C_word*)lf[19]+1),t3,((C_word*)t0)[2]);}}

/* k3739 in k3713 in k3710 in a3704 in k3695 in k3692 in k3689 in k3686 in k3683 in k3667 in setup-api#install-program in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_3741(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3741,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[168],t2);
t4=(C_word)C_a_i_cons(&a,2,C_retrieve2(lf[34],"setup-api#*chmod-command*"),t3);
t5=(C_word)C_a_i_list(&a,1,t4);
/* setup-api#execute */
((C_proc3)C_retrieve_symbol_proc(lf[97]))(3,*((C_word*)lf[97]+1),((C_word*)t0)[2],t5);}

/* k3716 in k3713 in k3710 in a3704 in k3695 in k3692 in k3689 in k3686 in k3683 in k3667 in setup-api#install-program in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_3718(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k3698 in k3695 in k3692 in k3689 in k3686 in k3683 in k3667 in setup-api#install-program in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_3700(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 589  write-info */
f_2911(((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* exify in k3667 in setup-api#install-program in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_fcall f_3671(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3671,NULL,2,t1,t2);}
t3=(C_truep(C_retrieve2(lf[13],"setup-api#*windows-shell*"))?lf[204]:C_SCHEME_FALSE);
t4=(C_word)C_a_i_list(&a,1,t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3331,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_3331(2,t6,C_SCHEME_FALSE);}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_3331(2,t7,(C_word)C_i_car(t4));}
else{
/* ##sys#error */
t7=*((C_word*)lf[161]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* k3329 in exify in k3667 in setup-api#install-program in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_3331(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3331,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3338,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* setup-api.scm: 509  pathname-extension */
((C_proc3)C_retrieve_symbol_proc(lf[96]))(3,*((C_word*)lf[96]+1),t2,((C_word*)t0)[2]);}

/* k3336 in k3329 in exify in k3667 in setup-api#install-program in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_3338(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3338,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3341,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=t1;
if(C_truep(t3)){
if(C_truep((C_word)C_i_equalp(lf[205],t1))){
t4=t2;
f_3341(t4,C_retrieve(lf[93]));}
else{
t4=(C_word)C_i_equalp(lf[206],t1);
t5=t2;
f_3341(t5,(C_truep(t4)?(C_truep(C_retrieve2(lf[13],"setup-api#*windows-shell*"))?lf[207]:lf[208]):t1));}}
else{
t4=t2;
f_3341(t4,((C_word*)t0)[2]);}}

/* k3339 in k3336 in k3329 in exify in k3667 in setup-api#install-program in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_fcall f_3341(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 508  pathname-replace-extension */
((C_proc4)C_retrieve_symbol_proc(lf[92]))(4,*((C_word*)lf[92]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* setup-api#install-extension in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_3380(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_3380r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3380r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3380r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3384,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_3384(2,t6,C_SCHEME_END_OF_LIST);}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_3384(2,t7,(C_word)C_i_car(t4));}
else{
/* ##sys#error */
t7=*((C_word*)lf[161]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* k3382 in setup-api#install-extension in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_3384(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3384,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3390,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* setup-api.scm: 519  setup-install-mode */
((C_proc2)C_retrieve_symbol_proc(lf[26]))(2,*((C_word*)lf[26]+1),t2);}

/* k3388 in k3382 in setup-api#install-extension in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_3390(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3390,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3393,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_listp(((C_word*)t0)[2]);
t4=(C_truep(t3)?((C_word*)t0)[2]:(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]));
/* setup-api.scm: 520  check-filelist */
f_3277(t2,t4);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k3391 in k3388 in k3382 in setup-api#install-extension in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_3393(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3393,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3396,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* setup-api.scm: 521  repo-path */
f_3958(t2,C_SCHEME_END_OF_LIST);}

/* k3394 in k3391 in k3388 in k3382 in setup-api#install-extension in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_3396(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3396,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3399,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* setup-api.scm: 522  repo-path */
f_3958(t2,(C_word)C_a_i_list(&a,1,C_SCHEME_TRUE));}

/* k3397 in k3394 in k3391 in k3388 in k3382 in setup-api#install-extension in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_3399(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3399,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3402,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3499,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],a[5]=((C_word)li57),tmp=(C_word)a,a+=6,tmp);
/* map */
t4=*((C_word*)lf[111]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a3498 in k3397 in k3394 in k3391 in k3388 in k3382 in setup-api#install-extension in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_3499(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3499,3,t0,t1,t2);}
t3=(C_word)C_i_pairp(t2);
t4=(C_truep(t3)?(C_word)C_i_car(t2):t2);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3506,a[2]=t4,a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* setup-api.scm: 525  make-dest-pathname */
f_3252(t5,((C_word*)t0)[2],t2);}

/* k3504 in a3498 in k3397 in k3394 in k3391 in k3388 in k3382 in setup-api#install-extension in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_3506(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3506,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3509,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3599,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[14],"setup-api#*windows*"))){
t4=t3;
f_3599(t4,C_SCHEME_FALSE);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3628,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 527  pathname-extension */
((C_proc3)C_retrieve_symbol_proc(lf[96]))(3,*((C_word*)lf[96]+1),t4,t1);}}

/* k3626 in k3504 in a3498 in k3397 in k3394 in k3391 in k3388 in k3382 in setup-api#install-extension in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_3628(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_3599(t2,(C_word)C_i_equalp(lf[202],t1));}

/* k3597 in k3504 in a3498 in k3397 in k3394 in k3391 in k3388 in k3382 in setup-api#install-extension in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_fcall f_3599(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3599,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3618,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 528  shellpath */
((C_proc3)C_retrieve_symbol_proc(lf[19]))(3,*((C_word*)lf[19]+1),t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_3509(2,t2,C_SCHEME_UNDEFINED);}}

/* k3616 in k3597 in k3504 in a3498 in k3397 in k3394 in k3391 in k3388 in k3382 in setup-api#install-extension in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_3618(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3618,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,C_retrieve2(lf[32],"setup-api#*remove-command*"),t2);
t4=(C_word)C_a_i_list(&a,1,t3);
/* setup-api#execute */
((C_proc3)C_retrieve_symbol_proc(lf[97]))(3,*((C_word*)lf[97]+1),((C_word*)t0)[2],t4);}

/* k3507 in k3504 in a3498 in k3397 in k3394 in k3391 in k3388 in k3382 in setup-api#install-extension in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_3509(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3509,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3512,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* setup-api.scm: 529  copy-file */
((C_proc4)C_retrieve_symbol_proc(lf[175]))(4,*((C_word*)lf[175]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k3510 in k3507 in k3504 in a3498 in k3397 in k3394 in k3391 in k3388 in k3382 in setup-api#install-extension in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_3512(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3512,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3515,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(C_retrieve2(lf[13],"setup-api#*windows-shell*"))){
t3=t2;
f_3515(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3596,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 531  shellpath */
((C_proc3)C_retrieve_symbol_proc(lf[19]))(3,*((C_word*)lf[19]+1),t3,((C_word*)t0)[3]);}}

/* k3594 in k3510 in k3507 in k3504 in a3498 in k3397 in k3394 in k3391 in k3388 in k3382 in setup-api#install-extension in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_3596(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3596,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[168],t2);
t4=(C_word)C_a_i_cons(&a,2,C_retrieve2(lf[34],"setup-api#*chmod-command*"),t3);
t5=(C_word)C_a_i_list(&a,1,t4);
/* setup-api#execute */
((C_proc3)C_retrieve_symbol_proc(lf[97]))(3,*((C_word*)lf[97]+1),((C_word*)t0)[2],t5);}

/* k3513 in k3510 in k3507 in k3504 in a3498 in k3397 in k3394 in k3391 in k3388 in k3382 in setup-api#install-extension in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_3515(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3515,2,t0,t1);}
t2=(C_word)C_i_assq(lf[198],((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3521,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t2)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3530,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3573,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* setup-api.scm: 533  software-version */
((C_proc2)C_retrieve_symbol_proc(lf[201]))(2,*((C_word*)lf[201]+1),t5);}
else{
t4=t3;
f_3521(2,t4,C_SCHEME_FALSE);}}

/* k3571 in k3513 in k3510 in k3507 in k3504 in a3498 in k3397 in k3394 in k3391 in k3388 in k3382 in setup-api#install-extension in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_3573(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3573,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[199]);
if(C_truep(t2)){
t3=(C_word)C_i_cadr(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_equalp(t3,((C_word*)t0)[4]))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3565,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 535  pathname-extension */
((C_proc3)C_retrieve_symbol_proc(lf[96]))(3,*((C_word*)lf[96]+1),t4,((C_word*)t0)[2]);}
else{
t4=((C_word*)t0)[3];
f_3530(t4,C_SCHEME_FALSE);}}
else{
t3=((C_word*)t0)[3];
f_3530(t3,C_SCHEME_FALSE);}}

/* k3563 in k3571 in k3513 in k3510 in k3507 in k3504 in a3498 in k3397 in k3394 in k3391 in k3388 in k3382 in setup-api#install-extension in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_3565(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_3530(t2,(C_word)C_i_equalp(t1,lf[200]));}

/* k3528 in k3513 in k3510 in k3507 in k3504 in a3498 in k3397 in k3394 in k3391 in k3388 in k3382 in setup-api#install-extension in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_fcall f_3530(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3530,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3549,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 536  shellpath */
((C_proc3)C_retrieve_symbol_proc(lf[19]))(3,*((C_word*)lf[19]+1),t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_3521(2,t2,C_SCHEME_UNDEFINED);}}

/* k3547 in k3528 in k3513 in k3510 in k3507 in k3504 in a3498 in k3397 in k3394 in k3391 in k3388 in k3382 in setup-api#install-extension in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_3549(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3549,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,C_retrieve2(lf[35],"setup-api#*ranlib-command*"),t2);
t4=(C_word)C_a_i_list(&a,1,t3);
/* setup-api#execute */
((C_proc3)C_retrieve_symbol_proc(lf[97]))(3,*((C_word*)lf[97]+1),((C_word*)t0)[2],t4);}

/* k3519 in k3513 in k3510 in k3507 in k3504 in a3498 in k3397 in k3394 in k3391 in k3388 in k3382 in setup-api#install-extension in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_3521(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 537  make-dest-pathname */
f_3252(((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3400 in k3397 in k3394 in k3391 in k3388 in k3382 in setup-api#install-extension in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_3402(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3402,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3405,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* setup-api.scm: 539  installation-prefix */
((C_proc2)C_retrieve_symbol_proc(lf[163]))(2,*((C_word*)lf[163]+1),t2);}

/* k3403 in k3400 in k3397 in k3394 in k3391 in k3388 in k3382 in setup-api#install-extension in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_3405(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3405,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3408,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3497,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 541  make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[110]))(4,*((C_word*)lf[110]+1),t3,t1,lf[197]);}
else{
t3=t2;
f_3408(2,t3,C_retrieve2(lf[17],"setup-api#*doc-path*"));}}

/* k3495 in k3403 in k3400 in k3397 in k3394 in k3391 in k3388 in k3382 in setup-api#install-extension in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_3497(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 541  ensure-directory */
f_4013(((C_word*)t0)[2],t1);}

/* k3406 in k3403 in k3400 in k3397 in k3394 in k3391 in k3388 in k3382 in setup-api#install-extension in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_3408(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3408,2,t0,t1);}
t2=(C_word)C_i_assq(lf[189],((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3414,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t2)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3470,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* setup-api.scm: 544  print */
((C_proc5)C_retrieve_proc(*((C_word*)lf[50]+1)))(5,*((C_word*)lf[50]+1),t4,lf[195],t1,lf[196]);}
else{
t4=t3;
f_3414(2,t4,C_SCHEME_FALSE);}}

/* k3468 in k3406 in k3403 in k3400 in k3397 in k3394 in k3391 in k3388 in k3382 in setup-api#install-extension in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_3470(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3470,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3473,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3478,a[2]=((C_word*)t0)[3],a[3]=((C_word)li56),tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* for-each */
t5=*((C_word*)lf[114]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,t3,t4);}

/* a3477 in k3468 in k3406 in k3403 in k3400 in k3397 in k3394 in k3391 in k3388 in k3382 in setup-api#install-extension in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_3478(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3478,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3486,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 547  make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[110]))(4,*((C_word*)lf[110]+1),t3,((C_word*)t0)[2],t2);}

/* k3484 in a3477 in k3468 in k3406 in k3403 in k3400 in k3397 in k3394 in k3391 in k3388 in k3382 in setup-api#install-extension in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_3486(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 547  copy-file */
((C_proc5)C_retrieve_symbol_proc(lf[175]))(5,*((C_word*)lf[175]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1,C_SCHEME_FALSE);}

/* k3471 in k3468 in k3406 in k3403 in k3400 in k3397 in k3394 in k3391 in k3388 in k3382 in setup-api#install-extension in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_3473(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 549  newline */
((C_proc2)C_retrieve_proc(*((C_word*)lf[191]+1)))(2,*((C_word*)lf[191]+1),((C_word*)t0)[2]);}

/* k3412 in k3406 in k3403 in k3400 in k3397 in k3394 in k3391 in k3388 in k3382 in setup-api#install-extension in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_3414(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3414,2,t0,t1);}
t2=(C_word)C_i_assq(lf[190],((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3420,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3426,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* setup-api.scm: 551  print */
((C_proc5)C_retrieve_proc(*((C_word*)lf[50]+1)))(5,*((C_word*)lf[50]+1),t4,lf[193],((C_word*)t0)[2],lf[194]);}
else{
t4=t3;
f_3420(2,t4,C_SCHEME_FALSE);}}

/* k3424 in k3412 in k3406 in k3403 in k3400 in k3397 in k3394 in k3391 in k3388 in k3382 in setup-api#install-extension in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_3426(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3426,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3429,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3434,a[2]=((C_word*)t0)[3],a[3]=((C_word)li55),tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* for-each */
t5=*((C_word*)lf[114]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,t3,t4);}

/* a3433 in k3424 in k3412 in k3406 in k3403 in k3400 in k3397 in k3394 in k3391 in k3388 in k3382 in setup-api#install-extension in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_3434(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3434,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3438,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 554  make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[110]))(4,*((C_word*)lf[110]+1),t3,((C_word*)t0)[2],t2);}

/* k3436 in a3433 in k3424 in k3412 in k3406 in k3403 in k3400 in k3397 in k3394 in k3391 in k3388 in k3382 in setup-api#install-extension in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_3438(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3438,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3441,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 555  copy-file */
((C_proc5)C_retrieve_symbol_proc(lf[175]))(5,*((C_word*)lf[175]+1),t2,((C_word*)t0)[2],t1,C_SCHEME_FALSE);}

/* k3439 in k3436 in a3433 in k3424 in k3412 in k3406 in k3403 in k3400 in k3397 in k3394 in k3391 in k3388 in k3382 in setup-api#install-extension in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_3441(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3441,2,t0,t1);}
if(C_truep(C_retrieve2(lf[13],"setup-api#*windows-shell*"))){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[192],t2);
t4=(C_word)C_a_i_cons(&a,2,C_retrieve2(lf[34],"setup-api#*chmod-command*"),t3);
t5=(C_word)C_a_i_list(&a,1,t4);
/* setup-api#execute */
((C_proc3)C_retrieve_symbol_proc(lf[97]))(3,*((C_word*)lf[97]+1),((C_word*)t0)[3],t5);}}

/* k3427 in k3424 in k3412 in k3406 in k3403 in k3400 in k3397 in k3394 in k3391 in k3388 in k3382 in setup-api#install-extension in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_3429(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 559  newline */
((C_proc2)C_retrieve_proc(*((C_word*)lf[191]+1)))(2,*((C_word*)lf[191]+1),((C_word*)t0)[2]);}

/* k3418 in k3412 in k3406 in k3403 in k3400 in k3397 in k3394 in k3391 in k3388 in k3382 in setup-api#install-extension in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_3420(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 560  write-info */
f_2911(((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* setup-api#check-filelist in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_fcall f_3277(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3277,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3283,a[2]=((C_word)li53),tmp=(C_word)a,a+=3,tmp);
/* map */
t4=*((C_word*)lf[111]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t3,t2);}

/* a3282 in setup-api#check-filelist in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_3283(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3283,3,t0,t1,t2);}
if(C_truep((C_word)C_i_stringp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3296,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_listp(t2))){
/* setup-api.scm: 502  every */
((C_proc4)C_retrieve_symbol_proc(lf[150]))(4,*((C_word*)lf[150]+1),t3,*((C_word*)lf[151]+1),t2);}
else{
t4=t3;
f_3296(2,t4,C_SCHEME_FALSE);}}}

/* k3294 in a3282 in setup-api#check-filelist in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_3296(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3296,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3299,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t3=(C_word)C_i_car(((C_word*)t0)[2]);
t4=(C_word)C_i_cdr(((C_word*)t0)[2]);
t5=t2;
f_3299(t5,(C_word)C_a_i_list(&a,2,t3,t4));}
else{
t3=t2;
f_3299(t3,C_SCHEME_FALSE);}}}

/* k3297 in k3294 in a3282 in setup-api#check-filelist in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_fcall f_3299(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
/* setup-api.scm: 504  error */
((C_proc4)C_retrieve_proc(*((C_word*)lf[116]+1)))(4,*((C_word*)lf[116]+1),((C_word*)t0)[3],lf[187],((C_word*)t0)[2]);}}

/* setup-api#make-dest-pathname in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_fcall f_3252(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
loop:
a=C_alloc(5);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3252,NULL,3,t1,t2,t3);}
if(C_truep((C_word)C_i_listp(t3))){
t4=(C_word)C_i_cadr(t3);
/* setup-api.scm: 494  make-dest-pathname */
t7=t1;
t8=t2;
t9=t4;
t1=t7;
t2=t8;
t3=t9;
goto loop;}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3272,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* setup-api.scm: 495  absolute-pathname? */
((C_proc3)C_retrieve_symbol_proc(lf[185]))(3,*((C_word*)lf[185]+1),t4,t3);}}

/* k3270 in setup-api#make-dest-pathname in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_3272(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}
else{
/* setup-api.scm: 497  make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[110]))(4,*((C_word*)lf[110]+1),((C_word*)t0)[4],((C_word*)t0)[2],((C_word*)t0)[3]);}}

/* setup-api#remove-file* in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_3230(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3230,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3250,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 490  shellpath */
((C_proc3)C_retrieve_symbol_proc(lf[19]))(3,*((C_word*)lf[19]+1),t3,t2);}

/* k3248 in setup-api#remove-file* in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_3250(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3250,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,C_retrieve2(lf[32],"setup-api#*remove-command*"),t2);
t4=(C_word)C_a_i_list(&a,1,t3);
/* setup-api#execute */
((C_proc3)C_retrieve_symbol_proc(lf[97]))(3,*((C_word*)lf[97]+1),((C_word*)t0)[2],t4);}

/* setup-api#move-file in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_3175(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3175,4,t0,t1,t2,t3);}
t4=(C_word)C_i_pairp(t2);
t5=(C_truep(t4)?(C_word)C_i_car(t2):t2);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3182,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t7=(C_word)C_i_cadr(t2);
/* setup-api.scm: 485  make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[110]))(4,*((C_word*)lf[110]+1),t6,t3,t7);}
else{
t7=t6;
f_3182(2,t7,t3);}}

/* k3180 in setup-api#move-file in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_3182(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3182,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3185,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* setup-api.scm: 486  ensure-directory */
f_4013(t2,t1);}

/* k3183 in k3180 in setup-api#move-file in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_3185(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3185,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3204,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 487  shellpath */
((C_proc3)C_retrieve_symbol_proc(lf[19]))(3,*((C_word*)lf[19]+1),t2,((C_word*)t0)[2]);}

/* k3202 in k3183 in k3180 in setup-api#move-file in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_3204(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3204,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3212,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 487  shellpath */
((C_proc3)C_retrieve_symbol_proc(lf[19]))(3,*((C_word*)lf[19]+1),t2,((C_word*)t0)[2]);}

/* k3210 in k3202 in k3183 in k3180 in setup-api#move-file in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_3212(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3212,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=(C_word)C_a_i_cons(&a,2,C_retrieve2(lf[33],"setup-api#*move-command*"),t3);
t5=(C_word)C_a_i_list(&a,1,t4);
/* setup-api#execute */
((C_proc3)C_retrieve_symbol_proc(lf[97]))(3,*((C_word*)lf[97]+1),((C_word*)t0)[2],t5);}

/* setup-api#copy-file in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_3025(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+13)){
C_save_and_reclaim((void*)tr4r,(void*)f_3025r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3025r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3025r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(13);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3027,a[2]=t3,a[3]=t2,a[4]=((C_word)li46),tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3118,a[2]=t5,a[3]=((C_word)li47),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3127,a[2]=t6,a[3]=((C_word)li48),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-err823867 */
t8=t7;
f_3127(t8,t1);}
else{
t8=(C_word)C_i_car(t4);
t9=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t9))){
/* def-prefix824863 */
t10=t6;
f_3118(t10,t1,t8);}
else{
t10=(C_word)C_i_car(t9);
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
/* body821830 */
t12=t5;
f_3027(t12,t1,t8,t10);}
else{
/* ##sys#error */
t12=*((C_word*)lf[161]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t1,lf[0],t11);}}}}

/* def-err823 in setup-api#copy-file in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_fcall f_3127(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3127,NULL,2,t0,t1);}
/* def-prefix824863 */
t2=((C_word*)t0)[2];
f_3118(t2,t1,C_SCHEME_TRUE);}

/* def-prefix824 in setup-api#copy-file in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_fcall f_3118(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3118,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3126,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* setup-api.scm: 468  installation-prefix */
((C_proc2)C_retrieve_symbol_proc(lf[163]))(2,*((C_word*)lf[163]+1),t3);}

/* k3124 in def-prefix824 in setup-api#copy-file in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_3126(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* body821830 */
t2=((C_word*)t0)[4];
f_3027(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* body821 in setup-api#copy-file in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_fcall f_3027(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3027,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_pairp(((C_word*)t0)[3]);
t5=(C_truep(t4)?(C_word)C_i_car(((C_word*)t0)[3]):((C_word*)t0)[3]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3034,a[2]=t3,a[3]=t2,a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
t7=(C_word)C_i_cadr(((C_word*)t0)[3]);
/* setup-api.scm: 471  make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[110]))(4,*((C_word*)lf[110]+1),t6,((C_word*)t0)[2],t7);}
else{
t7=t6;
f_3034(2,t7,((C_word*)t0)[2]);}}

/* k3032 in body821 in setup-api#copy-file in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_3034(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3034,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3037,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3091,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3101,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 472  string-prefix? */
((C_proc4)C_retrieve_symbol_proc(lf[181]))(4,*((C_word*)lf[181]+1),t4,((C_word*)t0)[2],t1);}
else{
t4=t3;
f_3091(t4,C_SCHEME_FALSE);}}

/* k3099 in k3032 in body821 in setup-api#copy-file in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_3101(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_3091(t2,(C_word)C_i_not(t1));}

/* k3089 in k3032 in body821 in setup-api#copy-file in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_fcall f_3091(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* setup-api.scm: 473  make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[110]))(4,*((C_word*)lf[110]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
f_3037(2,t2,((C_word*)t0)[2]);}}

/* k3035 in k3032 in body821 in setup-api#copy-file in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_3037(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3037,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3040,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* setup-api.scm: 475  ensure-directory */
f_4013(t2,t1);}

/* k3038 in k3035 in k3032 in body821 in setup-api#copy-file in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_3040(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3040,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3046,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* setup-api.scm: 476  glob? */
((C_proc3)C_retrieve_symbol_proc(lf[179]))(3,*((C_word*)lf[179]+1),t2,((C_word*)t0)[3]);}

/* k3044 in k3038 in k3035 in k3032 in body821 in setup-api#copy-file in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_3046(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3046,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3049,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t1)){
t3=t2;
f_3049(2,t3,t1);}
else{
/* setup-api.scm: 476  file-exists? */
((C_proc3)C_retrieve_symbol_proc(lf[134]))(3,*((C_word*)lf[134]+1),t2,((C_word*)t0)[3]);}}

/* k3047 in k3044 in k3038 in k3035 in k3032 in body821 in setup-api#copy-file in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_3049(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3049,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3052,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3068,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 478  shellpath */
((C_proc3)C_retrieve_symbol_proc(lf[19]))(3,*((C_word*)lf[19]+1),t3,((C_word*)t0)[3]);}
else{
if(C_truep(((C_word*)t0)[2])){
/* setup-api.scm: 480  error */
((C_proc4)C_retrieve_proc(*((C_word*)lf[116]+1)))(4,*((C_word*)lf[116]+1),((C_word*)t0)[5],lf[176],((C_word*)t0)[3]);}
else{
/* setup-api.scm: 481  warning */
((C_proc4)C_retrieve_symbol_proc(lf[177]))(4,*((C_word*)lf[177]+1),((C_word*)t0)[5],lf[178],((C_word*)t0)[3]);}}}

/* k3066 in k3047 in k3044 in k3038 in k3035 in k3032 in body821 in setup-api#copy-file in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_3068(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3068,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3076,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 478  shellpath */
((C_proc3)C_retrieve_symbol_proc(lf[19]))(3,*((C_word*)lf[19]+1),t2,((C_word*)t0)[2]);}

/* k3074 in k3066 in k3047 in k3044 in k3038 in k3035 in k3032 in body821 in setup-api#copy-file in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_3076(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3076,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=(C_word)C_a_i_cons(&a,2,C_retrieve2(lf[31],"setup-api#*copy-command*"),t3);
t5=(C_word)C_a_i_list(&a,1,t4);
/* setup-api#execute */
((C_proc3)C_retrieve_symbol_proc(lf[97]))(3,*((C_word*)lf[97]+1),((C_word*)t0)[2],t5);}

/* k3050 in k3047 in k3044 in k3038 in k3035 in k3032 in body821 in setup-api#copy-file in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_3052(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* setup-api#write-info in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_fcall f_2911(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2911,NULL,4,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3023,a[2]=t4,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* ##sys#append */
t6=*((C_word*)lf[174]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t3,C_SCHEME_END_OF_LIST);}

/* k3021 in setup-api#write-info in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_3023(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3023,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[167],t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3019,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* ##sys#append */
t4=*((C_word*)lf[174]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k3017 in k3021 in setup-api#write-info in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_3019(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3019,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2918,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3008,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* setup-api.scm: 458  setup-verbose-mode */
((C_proc2)C_retrieve_symbol_proc(lf[25]))(2,*((C_word*)lf[25]+1),t4);}

/* k3006 in k3017 in k3021 in setup-api#write-info in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_3008(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* setup-api.scm: 458  printf */
((C_proc5)C_retrieve_symbol_proc(lf[61]))(5,*((C_word*)lf[61]+1),((C_word*)t0)[4],lf[173],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
f_2918(2,t2,C_SCHEME_UNDEFINED);}}

/* k2916 in k3017 in k3021 in setup-api#write-info in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_2918(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2918,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2921,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 459  ->string */
((C_proc3)C_retrieve_symbol_proc(lf[112]))(3,*((C_word*)lf[112]+1),t2,((C_word*)t0)[2]);}

/* k2919 in k2916 in k3017 in k3021 in setup-api#write-info in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_2921(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2921,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2924,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3005,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 460  repo-path */
f_3958(t3,(C_word)C_a_i_list(&a,1,C_SCHEME_TRUE));}

/* k3003 in k2919 in k2916 in k3017 in k3021 in setup-api#write-info in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_3005(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3005,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=(C_word)C_a_i_list(&a,1,t1);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2864,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* setup-api.scm: 437  repository-path */
((C_proc2)C_retrieve_symbol_proc(lf[171]))(2,*((C_word*)lf[171]+1),t4);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_2864(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[161]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k2862 in k3003 in k2919 in k2916 in k3017 in k3021 in setup-api#write-info in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_2864(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 438  make-pathname */
((C_proc5)C_retrieve_symbol_proc(lf[110]))(5,*((C_word*)lf[110]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2],lf[170]);}

/* k2922 in k2919 in k2916 in k3017 in k3021 in setup-api#write-info in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_2924(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2924,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2927,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[12],"setup-api#*sudo*"))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2956,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* setup-api.scm: 462  create-temporary-file */
((C_proc2)C_retrieve_symbol_proc(lf[88]))(2,*((C_word*)lf[88]+1),t3);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2997,a[2]=((C_word*)t0)[2],a[3]=((C_word)li44),tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 465  with-output-to-file */
((C_proc4)C_retrieve_symbol_proc(lf[86]))(4,*((C_word*)lf[86]+1),t2,t1,t3);}}

/* a2996 in k2922 in k2919 in k2916 in k3017 in k3021 in setup-api#write-info in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_2997(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2997,2,t0,t1);}
/* pp */
((C_proc3)C_retrieve_symbol_proc(lf[169]))(3,*((C_word*)lf[169]+1),t1,((C_word*)t0)[2]);}

/* k2954 in k2922 in k2919 in k2916 in k3017 in k3021 in setup-api#write-info in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_2956(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2956,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2959,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2988,a[2]=((C_word*)t0)[2],a[3]=((C_word)li43),tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 463  with-output-to-file */
((C_proc4)C_retrieve_symbol_proc(lf[86]))(4,*((C_word*)lf[86]+1),t2,t1,t3);}

/* a2987 in k2954 in k2922 in k2919 in k2916 in k3017 in k3021 in setup-api#write-info in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_2988(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2988,2,t0,t1);}
/* pp */
((C_proc3)C_retrieve_symbol_proc(lf[169]))(3,*((C_word*)lf[169]+1),t1,((C_word*)t0)[2]);}

/* k2957 in k2954 in k2922 in k2919 in k2916 in k3017 in k3021 in setup-api#write-info in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_2959(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2959,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2978,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 464  shellpath */
((C_proc3)C_retrieve_symbol_proc(lf[19]))(3,*((C_word*)lf[19]+1),t2,((C_word*)t0)[2]);}

/* k2976 in k2957 in k2954 in k2922 in k2919 in k2916 in k3017 in k3021 in setup-api#write-info in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_2978(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2978,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2986,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 464  shellpath */
((C_proc3)C_retrieve_symbol_proc(lf[19]))(3,*((C_word*)lf[19]+1),t2,((C_word*)t0)[2]);}

/* k2984 in k2976 in k2957 in k2954 in k2922 in k2919 in k2916 in k3017 in k3021 in setup-api#write-info in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_2986(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2986,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=(C_word)C_a_i_cons(&a,2,C_retrieve2(lf[33],"setup-api#*move-command*"),t3);
t5=(C_word)C_a_i_list(&a,1,t4);
/* setup-api#execute */
((C_proc3)C_retrieve_symbol_proc(lf[97]))(3,*((C_word*)lf[97]+1),((C_word*)t0)[2],t5);}

/* k2925 in k2922 in k2919 in k2916 in k3017 in k3021 in setup-api#write-info in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_2927(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2927,2,t0,t1);}
if(C_truep(C_retrieve2(lf[13],"setup-api#*windows-shell*"))){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2953,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 466  shellpath */
((C_proc3)C_retrieve_symbol_proc(lf[19]))(3,*((C_word*)lf[19]+1),t2,((C_word*)t0)[2]);}}

/* k2951 in k2925 in k2922 in k2919 in k2916 in k3017 in k3021 in setup-api#write-info in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_2953(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2953,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[168],t2);
t4=(C_word)C_a_i_cons(&a,2,C_retrieve2(lf[34],"setup-api#*chmod-command*"),t3);
t5=(C_word)C_a_i_list(&a,1,t4);
/* setup-api#execute */
((C_proc3)C_retrieve_symbol_proc(lf[97]))(3,*((C_word*)lf[97]+1),((C_word*)t0)[2],t5);}

/* f_4860 in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_4860(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4860,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4864,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 452  verb */
f_2896(t3,t2);}

/* k4862 */
static void C_ccall f_4864(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4864,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4887,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 453  shellpath */
((C_proc3)C_retrieve_symbol_proc(lf[19]))(3,*((C_word*)lf[19]+1),t2,((C_word*)t0)[2]);}

/* k4885 in k4862 */
static void C_ccall f_4887(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4887,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[165],t2);
t4=(C_word)C_a_i_cons(&a,2,C_retrieve2(lf[36],"setup-api#*mkdir-command*"),t3);
t5=(C_word)C_a_i_list(&a,1,t4);
/* setup-api#execute */
((C_proc3)C_retrieve_symbol_proc(lf[97]))(3,*((C_word*)lf[97]+1),((C_word*)t0)[2],t5);}

/* f_4852 in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_4852(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4852,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4856,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 449  verb */
f_2896(t3,t2);}

/* k4854 */
static void C_ccall f_4856(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 450  create-directory */
((C_proc4)C_retrieve_symbol_proc(lf[58]))(4,*((C_word*)lf[58]+1),((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_TRUE);}

/* verb in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_fcall f_2896(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2896,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2903,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 446  setup-verbose-mode */
((C_proc2)C_retrieve_symbol_proc(lf[25]))(2,*((C_word*)lf[25]+1),t3);}

/* k2901 in verb in k2891 in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_2903(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* setup-api.scm: 446  printf */
((C_proc4)C_retrieve_symbol_proc(lf[61]))(4,*((C_word*)lf[61]+1),((C_word*)t0)[3],lf[164],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* setup-api#make/proc in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_2817(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_2817r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2817r(t0,t1,t2,t3);}}

static void C_ccall f_2817r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(4);
t4=(C_word)C_i_length(t3);
if(C_truep((C_word)C_i_nequalp(t4,C_fix(0)))){
t5=t2;
/* setup-api.scm: 396  make:make/proc/helper */
f_2527(t1,t5,C_SCHEME_END_OF_LIST);}
else{
if(C_truep((C_word)C_i_nequalp(t4,C_fix(1)))){
t5=t2;
t6=(C_word)C_i_car(t3);
t7=(C_word)C_i_cdr(t3);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2849,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_vectorp(t6))){
/* setup-api.scm: 401  vector->list */
((C_proc3)C_retrieve_proc(*((C_word*)lf[159]+1)))(3,*((C_word*)lf[159]+1),t8,t6);}
else{
t9=t8;
f_2849(2,t9,t6);}}
else{
/* ##sys#error */
t5=*((C_word*)lf[161]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t1,lf[162]);}}}

/* k2847 in setup-api#make/proc in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_2849(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 398  make:make/proc/helper */
f_2527(((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* setup-api#make:make/proc/helper in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_fcall f_2527(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2527,NULL,3,t1,t2,t3);}
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2531,a[2]=t4,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_vectorp(((C_word*)t4)[1]))){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2815,a[2]=t5,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 330  vector->list */
((C_proc3)C_retrieve_proc(*((C_word*)lf[159]+1)))(3,*((C_word*)lf[159]+1),t6,((C_word*)t4)[1]);}
else{
t6=t5;
f_2531(t6,C_SCHEME_UNDEFINED);}}

/* k2813 in setup-api#make:make/proc/helper in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_2815(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_2531(t3,t2);}

/* k2529 in setup-api#make:make/proc/helper in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_fcall f_2531(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2531,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2534,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[4];
t4=(C_word)C_i_listp(t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2359,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t4)){
t6=t5;
f_2359(2,t6,t4);}
else{
/* setup-api.scm: 302  make:form-error */
f_2329(t5,lf[158],t3);}}

/* k2357 in k2529 in setup-api#make:make/proc/helper in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_2359(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2359,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_pairp(((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2368,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t2)){
t4=t3;
f_2368(2,t4,t2);}
else{
/* setup-api.scm: 303  make:form-error */
f_2329(t3,lf[157],((C_word*)t0)[3]);}}
else{
t2=((C_word*)t0)[2];
f_2534(2,t2,C_SCHEME_FALSE);}}

/* k2366 in k2357 in k2529 in setup-api#make:make/proc/helper in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_2368(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2368,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2373,a[2]=((C_word)li37),tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 304  every */
((C_proc4)C_retrieve_symbol_proc(lf[150]))(4,*((C_word*)lf[150]+1),((C_word*)t0)[3],t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_2534(2,t2,C_SCHEME_FALSE);}}

/* a2372 in k2366 in k2357 in k2529 in setup-api#make:make/proc/helper in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_2373(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2373,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2380,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_listp(t2))){
t4=(C_word)C_i_length(t2);
/* setup-api.scm: 306  <= */
C_less_or_equal_p(5,0,t3,C_fix(2),t4,C_fix(3));}
else{
t4=t3;
f_2380(2,t4,C_SCHEME_FALSE);}}

/* k2378 in a2372 in k2366 in k2357 in k2529 in setup-api#make:make/proc/helper in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_2380(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2380,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2383,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=t2;
f_2383(2,t3,t1);}
else{
/* setup-api.scm: 307  make:form-error */
f_2329(t2,lf[156],((C_word*)t0)[3]);}}

/* k2381 in k2378 in a2372 in k2366 in k2357 in k2529 in setup-api#make:make/proc/helper in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_2383(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2383,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(C_word)C_i_stringp(t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2392,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t3)){
t5=t4;
f_2392(2,t5,t3);}
else{
t5=(C_word)C_i_car(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_listp(t5))){
t6=(C_word)C_i_car(((C_word*)t0)[3]);
/* setup-api.scm: 310  every */
((C_proc4)C_retrieve_symbol_proc(lf[150]))(4,*((C_word*)lf[150]+1),t4,*((C_word*)lf[151]+1),t6);}
else{
t6=t4;
f_2392(2,t6,C_SCHEME_FALSE);}}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k2390 in k2381 in k2378 in a2372 in k2366 in k2357 in k2529 in setup-api#make:make/proc/helper in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_2392(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2392,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2395,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=t2;
f_2395(2,t3,t1);}
else{
/* setup-api.scm: 311  make:form-error */
f_2329(t2,lf[155],((C_word*)t0)[3]);}}

/* k2393 in k2390 in k2381 in k2378 in a2372 in k2366 in k2357 in k2529 in setup-api#make:make/proc/helper in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_2395(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2395,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(C_word)C_i_cadr(((C_word*)t0)[3]);
t4=(C_word)C_i_listp(t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2404,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t4)){
t6=t5;
f_2404(2,t6,t4);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2434,a[2]=((C_word*)t0)[3],a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_i_cadr(((C_word*)t0)[3]);
/* setup-api.scm: 314  make:line-error */
f_2339(t6,lf[154],t7,t2);}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k2432 in k2393 in k2390 in k2381 in k2378 in a2372 in k2366 in k2357 in k2529 in setup-api#make:make/proc/helper in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_2434(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2434,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_2404(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2442,a[2]=((C_word)li36),tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[2]);
/* setup-api.scm: 315  every */
((C_proc4)C_retrieve_symbol_proc(lf[150]))(4,*((C_word*)lf[150]+1),((C_word*)t0)[3],t2,t3);}}

/* a2441 in k2432 in k2393 in k2390 in k2381 in k2378 in a2372 in k2366 in k2357 in k2529 in setup-api#make:make/proc/helper in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_2442(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2442,3,t0,t1,t2);}
t3=(C_word)C_i_stringp(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
/* setup-api.scm: 317  make:form-error */
f_2329(t1,lf[153],t2);}}

/* k2402 in k2393 in k2390 in k2381 in k2378 in a2372 in k2366 in k2357 in k2529 in setup-api#make:make/proc/helper in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_2404(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
t2=(C_word)C_i_cddr(((C_word*)t0)[4]);
t3=(C_word)C_i_nullp(t2);
if(C_truep(t3)){
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_i_caddr(((C_word*)t0)[4]);
t5=(C_word)C_i_closurep(t4);
if(C_truep(t5)){
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t6=(C_word)C_i_caddr(((C_word*)t0)[4]);
/* setup-api.scm: 321  make:line-error */
f_2339(((C_word*)t0)[3],lf[152],t6,((C_word*)t0)[2]);}}}

/* k2532 in k2529 in setup-api#make:make/proc/helper in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_2534(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2534,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2537,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)((C_word*)t0)[2])[1];
t4=(C_word)C_i_stringp(t3);
if(C_truep(t4)){
t5=t2;
f_2537(2,t5,t4);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2519,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 326  every */
((C_proc4)C_retrieve_symbol_proc(lf[150]))(4,*((C_word*)lf[150]+1),t5,*((C_word*)lf[151]+1),t3);}}

/* k2517 in k2532 in k2529 in setup-api#make:make/proc/helper in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_2519(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_2537(2,t2,t1);}
else{
/* setup-api.scm: 327  error */
((C_proc4)C_retrieve_proc(*((C_word*)lf[116]+1)))(4,*((C_word*)lf[116]+1),((C_word*)t0)[3],lf[149],((C_word*)t0)[2]);}}

/* k2535 in k2532 in k2529 in setup-api#make:make/proc/helper in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_2537(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2537,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t3,0,C_SCHEME_END_OF_LIST);
t11=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2542,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=t9,a[7]=t7,a[8]=t5,tmp=(C_word)a,a+=9,tmp);
/* setup-api.scm: 334  condition-predicate */
((C_proc3)C_retrieve_symbol_proc(lf[148]))(3,*((C_word*)lf[148]+1),t11,lf[146]);}

/* k2540 in k2535 in k2532 in k2529 in setup-api#make:make/proc/helper in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_2542(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2542,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[8])+1,t1);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2546,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* setup-api.scm: 335  condition-property-accessor */
((C_proc4)C_retrieve_symbol_proc(lf[145]))(4,*((C_word*)lf[145]+1),t3,lf[146],lf[147]);}

/* k2544 in k2540 in k2535 in k2532 in k2529 in setup-api#make:make/proc/helper in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_2546(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2546,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[8])+1,t1);
t3=C_mutate(((C_word *)((C_word*)t0)[7])+1,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2548,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[6],a[7]=((C_word)li33),tmp=(C_word)a,a+=8,tmp));
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2761,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_stringp(((C_word*)((C_word*)t0)[2])[1]))){
/* setup-api.scm: 386  make-file */
t5=((C_word*)((C_word*)t0)[7])[1];
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)((C_word*)t0)[2])[1],lf[141]);}
else{
if(C_truep((C_word)C_i_nullp(((C_word*)((C_word*)t0)[2])[1]))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2799,a[2]=t4,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 387  caar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[143]+1)))(3,*((C_word*)lf[143]+1),t5,((C_word*)t0)[4]);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2804,a[2]=((C_word*)t0)[7],a[3]=((C_word)li35),tmp=(C_word)a,a+=4,tmp);
/* for-each */
t6=*((C_word*)lf[114]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,((C_word*)((C_word*)t0)[2])[1]);}}}

/* a2803 in k2544 in k2540 in k2535 in k2532 in k2529 in setup-api#make:make/proc/helper in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_2804(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2804,3,t0,t1,t2);}
/* setup-api.scm: 388  make-file */
t3=((C_word*)((C_word*)t0)[2])[1];
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,lf[144]);}

/* k2797 in k2544 in k2540 in k2535 in k2532 in k2529 in setup-api#make:make/proc/helper in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_2799(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 387  make-file */
t2=((C_word*)((C_word*)t0)[3])[1];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,lf[142]);}

/* k2759 in k2544 in k2540 in k2535 in k2532 in k2529 in setup-api#make:make/proc/helper in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_2761(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2761,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2767,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 389  setup-verbose-mode */
((C_proc2)C_retrieve_symbol_proc(lf[25]))(2,*((C_word*)lf[25]+1),t2);}

/* k2765 in k2759 in k2544 in k2540 in k2535 in k2532 in k2529 in setup-api#make:make/proc/helper in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_2767(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2767,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2772,a[2]=((C_word)li34),tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2780,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 392  reverse */
((C_proc3)C_retrieve_proc(*((C_word*)lf[140]+1)))(3,*((C_word*)lf[140]+1),t3,((C_word*)((C_word*)t0)[2])[1]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k2778 in k2765 in k2759 in k2544 in k2540 in k2535 in k2532 in k2529 in setup-api#make:make/proc/helper in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_2780(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[114]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2771 in k2765 in k2759 in k2544 in k2540 in k2535 in k2532 in k2529 in setup-api#make:make/proc/helper in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_2772(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2772,3,t0,t1,t2);}
/* setup-api.scm: 391  printf */
((C_proc4)C_retrieve_symbol_proc(lf[61]))(4,*((C_word*)lf[61]+1),t1,lf[139],t2);}

/* f_2548 in k2544 in k2540 in k2535 in k2532 in k2529 in setup-api#make:make/proc/helper in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_2548(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[20],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2548,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2552,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t2,a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t5=t2;
t6=((C_word*)t0)[2];
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2275,a[2]=t5,a[3]=((C_word)li31),tmp=(C_word)a,a+=4,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2284,a[2]=t7,a[3]=t9,a[4]=((C_word)li32),tmp=(C_word)a,a+=5,tmp));
t11=((C_word*)t9)[1];
f_2284(t11,t4,t6);}

/* loop */
static void C_fcall f_2284(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2284,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2297,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t3,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_i_car(t3);
if(C_truep((C_word)C_i_stringp(t5))){
t6=(C_word)C_i_car(t3);
t7=t4;
f_2297(t7,(C_word)C_a_i_list(&a,1,t6));}
else{
t6=t4;
f_2297(t6,(C_word)C_i_car(t3));}}}

/* k2295 in loop */
static void C_fcall f_2297(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2297,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2303,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* setup-api.scm: 294  any */
((C_proc4)C_retrieve_symbol_proc(lf[135]))(4,*((C_word*)lf[135]+1),t2,((C_word*)t0)[2],t1);}

/* k2301 in k2295 in loop */
static void C_ccall f_2303(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[4]);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* setup-api.scm: 296  loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_2284(t3,((C_word*)t0)[5],t2);}}

/* match? */
static void C_ccall f_2275(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2275,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_string_equal_p(t2,((C_word*)t0)[2]));}

/* k2550 */
static void C_ccall f_2552(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2552,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2555,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
/* setup-api.scm: 339  fixmaketarget */
f_2197(t2,((C_word*)t0)[7]);}

/* k2553 in k2550 */
static void C_ccall f_2555(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2555,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2558,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2755,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 340  file-exists? */
((C_proc3)C_retrieve_symbol_proc(lf[134]))(3,*((C_word*)lf[134]+1),t3,t1);}

/* k2753 in k2553 in k2550 */
static void C_ccall f_2755(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* setup-api.scm: 341  file-modification-time */
((C_proc3)C_retrieve_symbol_proc(lf[132]))(3,*((C_word*)lf[132]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_2558(2,t2,C_SCHEME_FALSE);}}

/* k2556 in k2553 in k2550 */
static void C_ccall f_2558(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2558,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2561,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t1,a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2749,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* setup-api.scm: 342  setup-verbose-mode */
((C_proc2)C_retrieve_symbol_proc(lf[25]))(2,*((C_word*)lf[25]+1),t3);}

/* k2747 in k2556 in k2553 in k2550 */
static void C_ccall f_2749(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* setup-api.scm: 343  printf */
((C_proc5)C_retrieve_symbol_proc(lf[61]))(5,*((C_word*)lf[61]+1),((C_word*)t0)[4],lf[138],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
f_2561(2,t2,C_SCHEME_UNDEFINED);}}

/* k2559 in k2556 in k2553 in k2550 */
static void C_ccall f_2561(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2561,2,t0,t1);}
if(C_truep(((C_word*)t0)[11])){
t2=(C_word)C_i_cadr(((C_word*)t0)[11]);
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2570,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2731,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* setup-api.scm: 346  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[126]+1)))(4,*((C_word*)lf[126]+1),t4,lf[136],((C_word*)t0)[4]);}
else{
if(C_truep(((C_word*)t0)[10])){
t2=((C_word*)t0)[9];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2746,a[2]=((C_word*)t0)[9],tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 384  sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[64]))(4,*((C_word*)lf[64]+1),t2,lf[137],((C_word*)t0)[3]);}}}

/* k2744 in k2559 in k2556 in k2553 in k2550 */
static void C_ccall f_2746(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 384  error */
((C_proc3)C_retrieve_proc(*((C_word*)lf[116]+1)))(3,*((C_word*)lf[116]+1),((C_word*)t0)[2],t1);}

/* k2729 in k2559 in k2556 in k2553 in k2550 */
static void C_ccall f_2731(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2731,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2732,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word)li30),tmp=(C_word)a,a+=5,tmp);
/* for-each */
t3=*((C_word*)lf[114]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a2728 in k2729 in k2559 in k2556 in k2553 in k2550 */
static void C_ccall f_2732(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2732,3,t0,t1,t2);}
/* setup-api.scm: 347  make-file */
t3=((C_word*)((C_word*)t0)[3])[1];
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,((C_word*)t0)[2]);}

/* k2568 in k2559 in k2556 in k2553 in k2550 */
static void C_ccall f_2570(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2570,2,t0,t1);}
t2=(C_word)C_i_not(((C_word*)t0)[11]);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2576,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
if(C_truep(t2)){
t4=t3;
f_2576(2,t4,t2);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2700,a[2]=((C_word*)t0)[11],a[3]=((C_word)li29),tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 351  any */
((C_proc4)C_retrieve_symbol_proc(lf[135]))(4,*((C_word*)lf[135]+1),t3,t4,((C_word*)t0)[2]);}}

/* a2699 in k2568 in k2559 in k2556 in k2553 in k2550 */
static void C_ccall f_2700(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2700,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2704,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 352  fixmaketarget */
f_2197(t3,t2);}

/* k2702 in a2699 in k2568 in k2559 in k2556 in k2553 in k2550 */
static void C_ccall f_2704(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2704,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2707,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2720,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 353  file-exists? */
((C_proc3)C_retrieve_symbol_proc(lf[134]))(3,*((C_word*)lf[134]+1),t3,t1);}

/* k2718 in k2702 in a2699 in k2568 in k2559 in k2556 in k2553 in k2550 */
static void C_ccall f_2720(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2720,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_2707(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2727,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 354  sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[64]))(4,*((C_word*)lf[64]+1),t2,lf[133],((C_word*)t0)[2]);}}

/* k2725 in k2718 in k2702 in a2699 in k2568 in k2559 in k2556 in k2553 in k2550 */
static void C_ccall f_2727(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 354  error */
((C_proc3)C_retrieve_proc(*((C_word*)lf[116]+1)))(3,*((C_word*)lf[116]+1),((C_word*)t0)[2],t1);}

/* k2705 in k2702 in a2699 in k2568 in k2559 in k2556 in k2553 in k2550 */
static void C_ccall f_2707(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2707,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2717,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* setup-api.scm: 355  file-modification-time */
((C_proc3)C_retrieve_symbol_proc(lf[132]))(3,*((C_word*)lf[132]+1),t2,((C_word*)t0)[2]);}

/* k2715 in k2705 in k2702 in a2699 in k2568 in k2559 in k2556 in k2553 in k2550 */
static void C_ccall f_2717(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_greaterp(t1,((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?((C_word*)t0)[2]:C_SCHEME_FALSE));}

/* k2574 in k2568 in k2559 in k2556 in k2553 in k2550 */
static void C_ccall f_2576(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2576,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cddr(((C_word*)t0)[10]);
if(C_truep((C_word)C_i_nullp(t2))){
t3=((C_word*)t0)[9];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],((C_word*)((C_word*)t0)[7])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[7])+1,t3);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2595,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2666,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t5,tmp=(C_word)a,a+=7,tmp);
/* setup-api.scm: 362  setup-verbose-mode */
((C_proc2)C_retrieve_symbol_proc(lf[25]))(2,*((C_word*)lf[25]+1),t6);}}
else{
t2=((C_word*)t0)[9];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k2664 in k2574 in k2568 in k2559 in k2556 in k2553 in k2550 */
static void C_ccall f_2666(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2666,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2673,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[3];
if(C_truep(t3)){
if(C_truep((C_word)C_i_stringp(((C_word*)t0)[2]))){
/* setup-api.scm: 370  string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[126]+1)))(5,*((C_word*)lf[126]+1),t2,lf[127],((C_word*)t0)[2],lf[128]);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2695,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 372  sprintf */
((C_proc5)C_retrieve_symbol_proc(lf[64]))(5,*((C_word*)lf[64]+1),t4,lf[129],((C_word*)t0)[2],((C_word*)t0)[3]);}}
else{
/* setup-api.scm: 368  string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[126]+1)))(5,*((C_word*)lf[126]+1),t2,lf[130],((C_word*)t0)[4],lf[131]);}}
else{
t2=((C_word*)t0)[6];
f_2595(2,t2,C_SCHEME_UNDEFINED);}}

/* k2693 in k2664 in k2574 in k2568 in k2559 in k2556 in k2553 in k2550 */
static void C_ccall f_2695(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 372  string-append */
((C_proc3)C_retrieve_proc(*((C_word*)lf[126]+1)))(3,*((C_word*)lf[126]+1),((C_word*)t0)[2],t1);}

/* k2671 in k2664 in k2574 in k2568 in k2559 in k2556 in k2553 in k2550 */
static void C_ccall f_2673(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 363  printf */
((C_proc6)C_retrieve_symbol_proc(lf[61]))(6,*((C_word*)lf[61]+1),((C_word*)t0)[4],lf[125],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2593 in k2574 in k2568 in k2559 in k2556 in k2553 in k2550 */
static void C_ccall f_2595(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2595,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2601,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2603,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word)li28),tmp=(C_word)a,a+=7,tmp);
/* call-with-current-continuation */
((C_proc3)C_retrieve_proc(*((C_word*)lf[124]+1)))(3,*((C_word*)lf[124]+1),t2,t3);}

/* a2602 in k2593 in k2574 in k2568 in k2559 in k2556 in k2553 in k2550 */
static void C_ccall f_2603(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2603,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2609,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word)li23),tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2638,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li27),tmp=(C_word)a,a+=5,tmp);
/* with-exception-handler */
((C_proc4)C_retrieve_symbol_proc(lf[123]))(4,*((C_word*)lf[123]+1),t1,t3,t4);}

/* a2637 in a2602 in k2593 in k2574 in k2568 in k2559 in k2556 in k2553 in k2550 */
static void C_ccall f_2638(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2638,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2644,a[2]=((C_word*)t0)[3],a[3]=((C_word)li24),tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2653,a[2]=((C_word*)t0)[2],a[3]=((C_word)li26),tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a2652 in a2637 in a2602 in k2593 in k2574 in k2568 in k2559 in k2556 in k2553 in k2550 */
static void C_ccall f_2653(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_2653r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2653r(t0,t1,t2);}}

static void C_ccall f_2653r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2659,a[2]=t2,a[3]=((C_word)li25),tmp=(C_word)a,a+=4,tmp);
/* k566571 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a2658 in a2652 in a2637 in a2602 in k2593 in k2574 in k2568 in k2559 in k2556 in k2553 in k2550 */
static void C_ccall f_2659(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2659,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a2643 in a2637 in a2602 in k2593 in k2574 in k2568 in k2559 in k2556 in k2553 in k2550 */
static void C_ccall f_2644(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2644,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[2]);
t3=t2;
((C_proc2)C_retrieve_proc(t3))(2,t3,t1);}

/* a2608 in a2602 in k2593 in k2574 in k2568 in k2559 in k2556 in k2553 in k2550 */
static void C_ccall f_2609(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2609,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2615,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=((C_word)li22),tmp=(C_word)a,a+=7,tmp);
/* k566571 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a2614 in a2608 in a2602 in k2593 in k2574 in k2568 in k2559 in k2556 in k2553 in k2550 */
static void C_ccall f_2615(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2615,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2619,a[2]=((C_word*)t0)[5],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2630,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2633,a[2]=((C_word*)t0)[5],a[3]=t4,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* setup-api.scm: 378  exn? */
t6=((C_word*)((C_word*)t0)[2])[1];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[5]);}

/* k2631 in a2614 in a2608 in a2602 in k2593 in k2574 in k2568 in k2559 in k2556 in k2553 in k2550 */
static void C_ccall f_2633(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* setup-api.scm: 379  exn-message */
t2=((C_word*)((C_word*)t0)[4])[1];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_2630(2,t2,((C_word*)t0)[2]);}}

/* k2628 in a2614 in a2608 in a2602 in k2593 in k2574 in k2568 in k2559 in k2556 in k2553 in k2550 */
static void C_ccall f_2630(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 376  printf */
((C_proc5)C_retrieve_symbol_proc(lf[61]))(5,*((C_word*)lf[61]+1),((C_word*)t0)[3],lf[122],((C_word*)t0)[2],t1);}

/* k2617 in a2614 in a2608 in a2602 in k2593 in k2574 in k2568 in k2559 in k2556 in k2553 in k2550 */
static void C_ccall f_2619(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 381  signal */
((C_proc3)C_retrieve_symbol_proc(lf[121]))(3,*((C_word*)lf[121]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2599 in k2593 in k2574 in k2568 in k2559 in k2556 in k2553 in k2550 */
static void C_ccall f_2601(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* setup-api#make:line-error in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_fcall f_2339(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2339,NULL,4,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2347,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 299  sprintf */
((C_proc6)C_retrieve_symbol_proc(lf[64]))(6,*((C_word*)lf[64]+1),t5,lf[119],t2,t3,t4);}

/* k2345 in setup-api#make:line-error in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_2347(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 299  error */
((C_proc3)C_retrieve_proc(*((C_word*)lf[116]+1)))(3,*((C_word*)lf[116]+1),((C_word*)t0)[2],t1);}

/* setup-api#make:form-error in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_fcall f_2329(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2329,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2337,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 298  sprintf */
((C_proc5)C_retrieve_symbol_proc(lf[64]))(5,*((C_word*)lf[64]+1),t4,lf[117],t2,t3);}

/* k2335 in setup-api#make:form-error in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_2337(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 298  error */
((C_proc3)C_retrieve_proc(*((C_word*)lf[116]+1)))(3,*((C_word*)lf[116]+1),((C_word*)t0)[2],t1);}

/* setup-api#execute in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_2223(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2223,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2226,a[2]=((C_word)li17),tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2254,a[2]=((C_word)li18),tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2271,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* map */
t6=*((C_word*)lf[111]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t3,t2);}

/* k2269 in setup-api#execute in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_2271(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[114]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2253 in setup-api#execute in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_2254(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2254,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2258,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2264,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 268  run-verbose */
((C_proc2)C_retrieve_symbol_proc(lf[90]))(2,*((C_word*)lf[90]+1),t4);}

/* k2262 in a2253 in setup-api#execute in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_2264(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* setup-api.scm: 268  printf */
((C_proc4)C_retrieve_symbol_proc(lf[61]))(4,*((C_word*)lf[61]+1),((C_word*)t0)[3],lf[113],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_2258(2,t2,C_SCHEME_UNDEFINED);}}

/* k2256 in a2253 in setup-api#execute in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_2258(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 269  $system */
f_4760(((C_word*)t0)[3],((C_word*)t0)[2]);}

/* smooth in setup-api#execute in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_2226(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2226,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2230,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* map */
t4=*((C_word*)lf[111]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_retrieve(lf[112]),t2);}

/* k2228 in smooth in setup-api#execute in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_2230(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2230,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2241,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(t1);
if(C_truep((C_word)C_i_string_equal_p(t3,lf[100]))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2148,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2152,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2170,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(C_word)C_i_assoc(t3,C_retrieve2(lf[6],"setup-api#*installed-executables*"));
t8=(C_word)C_i_cdr(t7);
/* setup-api.scm: 244  make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[110]))(4,*((C_word*)lf[110]+1),t6,C_retrieve2(lf[16],"setup-api#*chicken-bin-path*"),t8);}
else{
t4=(C_word)C_i_assoc(t3,C_retrieve2(lf[6],"setup-api#*installed-executables*"));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2191,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t6=(C_word)C_i_cdr(t4);
/* setup-api.scm: 253  make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[110]))(4,*((C_word*)lf[110]+1),t5,C_retrieve2(lf[16],"setup-api#*chicken-bin-path*"),t6);}
else{
t5=t2;
f_2241(2,t5,t3);}}}

/* k2189 in k2228 in smooth in setup-api#execute in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_2191(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 253  shellpath */
((C_proc3)C_retrieve_symbol_proc(lf[19]))(3,*((C_word*)lf[19]+1),((C_word*)t0)[2],t1);}

/* k2168 in k2228 in smooth in setup-api#execute in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_2170(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 243  shellpath */
((C_proc3)C_retrieve_symbol_proc(lf[19]))(3,*((C_word*)lf[19]+1),((C_word*)t0)[2],t1);}

/* k2150 in k2228 in smooth in setup-api#execute in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_2152(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2152,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2166,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 248  keep-intermediates */
((C_proc2)C_retrieve_symbol_proc(lf[30]))(2,*((C_word*)lf[30]+1),t2);}

/* k2164 in k2150 in k2228 in smooth in setup-api#execute in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_2166(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2166,2,t0,t1);}
t2=(C_truep(t1)?lf[102]:lf[103]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2163,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* setup-api.scm: 249  host-extension */
((C_proc2)C_retrieve_symbol_proc(lf[15]))(2,*((C_word*)lf[15]+1),t3);}

/* k2161 in k2164 in k2150 in k2228 in smooth in setup-api#execute in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_2163(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?lf[104]:lf[105]);
/* setup-api.scm: 243  cons* */
((C_proc9)C_retrieve_symbol_proc(lf[106]))(9,*((C_word*)lf[106]+1),((C_word*)t0)[4],((C_word*)t0)[3],lf[107],lf[108],lf[109],((C_word*)t0)[2],t2,C_SCHEME_END_OF_LIST);}

/* k2146 in k2228 in smooth in setup-api#execute in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_2148(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 242  string-intersperse */
((C_proc4)C_retrieve_symbol_proc(lf[98]))(4,*((C_word*)lf[98]+1),((C_word*)t0)[2],t1,lf[101]);}

/* k2239 in k2228 in smooth in setup-api#execute in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_2241(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2241,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
/* setup-api.scm: 265  string-intersperse */
((C_proc4)C_retrieve_symbol_proc(lf[98]))(4,*((C_word*)lf[98]+1),((C_word*)t0)[2],t3,lf[99]);}

/* setup-api#fixmaketarget in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_fcall f_2197(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2197,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2204,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2221,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 257  pathname-extension */
((C_proc3)C_retrieve_symbol_proc(lf[96]))(3,*((C_word*)lf[96]+1),t4,t2);}

/* k2219 in setup-api#fixmaketarget in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_2221(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep((C_word)C_i_equalp(lf[94],t1))){
t2=(C_word)C_i_string_equal_p(lf[95],C_retrieve(lf[93]));
t3=((C_word*)t0)[2];
f_2204(t3,(C_word)C_i_not(t2));}
else{
t2=((C_word*)t0)[2];
f_2204(t2,C_SCHEME_FALSE);}}

/* k2202 in setup-api#fixmaketarget in k2130 in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_fcall f_2204(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* setup-api.scm: 259  pathname-replace-extension */
((C_proc4)C_retrieve_symbol_proc(lf[92]))(4,*((C_word*)lf[92]+1),((C_word*)t0)[3],((C_word*)t0)[2],C_retrieve(lf[93]));}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* setup-api#patch in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_2042(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2042,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2046,a[2]=t1,a[3]=t4,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2125,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 221  setup-verbose-mode */
((C_proc2)C_retrieve_symbol_proc(lf[25]))(2,*((C_word*)lf[25]+1),t6);}

/* k2123 in setup-api#patch in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_2125(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* setup-api.scm: 221  printf */
((C_proc4)C_retrieve_symbol_proc(lf[61]))(4,*((C_word*)lf[61]+1),((C_word*)t0)[3],lf[89],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_2046(2,t2,C_SCHEME_UNDEFINED);}}

/* k2044 in setup-api#patch in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_2046(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2046,2,t0,t1);}
if(C_truep((C_word)C_i_listp(((C_word*)t0)[5]))){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2061,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word)li14),tmp=(C_word)a,a+=6,tmp);
/* setup-api.scm: 223  with-output-to-file */
((C_proc4)C_retrieve_symbol_proc(lf[86]))(4,*((C_word*)lf[86]+1),((C_word*)t0)[2],t2,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2100,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* setup-api.scm: 232  create-temporary-file */
((C_proc2)C_retrieve_symbol_proc(lf[88]))(2,*((C_word*)lf[88]+1),t2);}}

/* k2098 in k2044 in setup-api#patch in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_2100(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2100,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2103,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_a_i_list(&a,2,t1,t1);
/* setup-api.scm: 233  patch */
((C_proc5)C_retrieve_symbol_proc(lf[82]))(5,*((C_word*)lf[82]+1),t2,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2101 in k2098 in k2044 in setup-api#patch in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_2103(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2103,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2110,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2114,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 235  shellpath */
((C_proc3)C_retrieve_symbol_proc(lf[19]))(3,*((C_word*)lf[19]+1),t3,((C_word*)t0)[2]);}

/* k2112 in k2101 in k2098 in k2044 in setup-api#patch in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_2114(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2114,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2118,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 236  shellpath */
((C_proc3)C_retrieve_symbol_proc(lf[19]))(3,*((C_word*)lf[19]+1),t2,((C_word*)t0)[2]);}

/* k2116 in k2112 in k2101 in k2098 in k2044 in setup-api#patch in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_2118(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 235  sprintf */
((C_proc6)C_retrieve_symbol_proc(lf[64]))(6,*((C_word*)lf[64]+1),((C_word*)t0)[3],lf[87],C_retrieve2(lf[33],"setup-api#*move-command*"),((C_word*)t0)[2],t1);}

/* k2108 in k2101 in k2098 in k2044 in setup-api#patch in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_2110(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 234  $system */
f_4760(((C_word*)t0)[2],t1);}

/* a2060 in k2044 in setup-api#patch in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_2061(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2061,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2071,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word)li13),tmp=(C_word)a,a+=5,tmp);
/* setup-api.scm: 225  with-input-from-file */
((C_proc4)C_retrieve_symbol_proc(lf[85]))(4,*((C_word*)lf[85]+1),t1,t2,t3);}

/* a2070 in a2060 in k2044 in setup-api#patch in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_2071(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2071,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2077,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word)li12),tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_2077(t5,t1);}

/* loop in a2070 in a2060 in k2044 in setup-api#patch in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_fcall f_2077(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2077,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2081,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* setup-api.scm: 228  read-line */
((C_proc2)C_retrieve_symbol_proc(lf[75]))(2,*((C_word*)lf[75]+1),t2);}

/* k2079 in loop in a2070 in a2060 in k2044 in setup-api#patch in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_2081(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2081,2,t0,t1);}
if(C_truep((C_word)C_eofp(t1))){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2090,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2097,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 230  string-substitute */
((C_proc6)C_retrieve_symbol_proc(lf[84]))(6,*((C_word*)lf[84]+1),t3,((C_word*)t0)[3],((C_word*)t0)[2],t1,C_SCHEME_TRUE);}}

/* k2095 in k2079 in loop in a2070 in a2060 in k2044 in setup-api#patch in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_2097(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 230  write-line */
((C_proc3)C_retrieve_symbol_proc(lf[83]))(3,*((C_word*)lf[83]+1),((C_word*)t0)[2],t1);}

/* k2088 in k2079 in loop in a2070 in a2060 in k2044 in setup-api#patch in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_2090(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 231  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_2077(t2,((C_word*)t0)[2]);}

/* setup-api#yes-or-no? in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_1962(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_1962r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1962r(t0,t1,t2,t3);}}

static void C_ccall f_1962r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1966,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* ##sys#get-keyword */
((C_proc4)C_retrieve_symbol_proc(lf[79]))(4,*((C_word*)lf[79]+1),t4,lf[81],t3);}

/* k1964 in setup-api#yes-or-no? in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_1966(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1966,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1969,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2036,a[2]=((C_word)li10),tmp=(C_word)a,a+=3,tmp);
/* ##sys#get-keyword */
((C_proc5)C_retrieve_symbol_proc(lf[79]))(5,*((C_word*)lf[79]+1),t2,lf[80],((C_word*)t0)[2],t3);}

/* a2035 in k1964 in setup-api#yes-or-no? in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_2036(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2036,2,t0,t1);}
/* setup-api.scm: 205  abort-setup */
((C_proc2)C_retrieve_symbol_proc(lf[67]))(2,*((C_word*)lf[67]+1),t1);}

/* k1967 in k1964 in setup-api#yes-or-no? in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_1969(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1969,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1974,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t1,a[6]=((C_word)li9),tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_1974(t5,((C_word*)t0)[2]);}

/* loop in k1967 in k1964 in setup-api#yes-or-no? in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_fcall f_1974(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1974,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1978,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* setup-api.scm: 207  printf */
((C_proc4)C_retrieve_symbol_proc(lf[61]))(4,*((C_word*)lf[61]+1),t2,lf[78],((C_word*)t0)[2]);}

/* k1976 in loop in k1967 in k1964 in setup-api#yes-or-no? in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_1978(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1978,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1981,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[2])){
/* setup-api.scm: 208  printf */
((C_proc4)C_retrieve_symbol_proc(lf[61]))(4,*((C_word*)lf[61]+1),t2,lf[77],((C_word*)t0)[2]);}
else{
t3=t2;
f_1981(2,t3,C_SCHEME_UNDEFINED);}}

/* k1979 in k1976 in loop in k1967 in k1964 in setup-api#yes-or-no? in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_1981(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1981,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1984,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* setup-api.scm: 209  flush-output */
((C_proc2)C_retrieve_proc(*((C_word*)lf[76]+1)))(2,*((C_word*)lf[76]+1),t2);}

/* k1982 in k1979 in k1976 in loop in k1967 in k1964 in setup-api#yes-or-no? in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_1984(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1984,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1987,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* setup-api.scm: 210  read-line */
((C_proc2)C_retrieve_symbol_proc(lf[75]))(2,*((C_word*)lf[75]+1),t2);}

/* k1985 in k1982 in k1979 in k1976 in loop in k1967 in k1964 in setup-api#yes-or-no? in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_1987(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1987,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1990,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_eofp(((C_word*)t3)[1]))){
t5=C_set_block_item(t3,0,lf[73]);
t6=t4;
f_1990(t6,t5);}
else{
t5=(C_truep(((C_word*)t0)[2])?(C_word)C_i_string_equal_p(lf[74],((C_word*)t3)[1]):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=C_set_block_item(t3,0,((C_word*)t0)[2]);
t7=t4;
f_1990(t7,t6);}
else{
t6=t4;
f_1990(t6,C_SCHEME_UNDEFINED);}}}

/* k1988 in k1985 in k1982 in k1979 in k1976 in loop in k1967 in k1964 in setup-api#yes-or-no? in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_fcall f_1990(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1990,NULL,2,t0,t1);}
if(C_truep((C_word)C_i_string_ci_equal_p(lf[69],((C_word*)((C_word*)t0)[5])[1]))){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}
else{
if(C_truep((C_word)C_i_string_ci_equal_p(lf[70],((C_word*)((C_word*)t0)[5])[1]))){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_i_string_ci_equal_p(lf[71],((C_word*)((C_word*)t0)[5])[1]))){
/* setup-api.scm: 215  abort */
t2=((C_word*)t0)[3];
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2014,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 217  printf */
((C_proc3)C_retrieve_symbol_proc(lf[61]))(3,*((C_word*)lf[61]+1),t2,lf[72]);}}}}

/* k2012 in k1988 in k1985 in k1982 in k1979 in k1976 in loop in k1967 in k1964 in setup-api#yes-or-no? in k1958 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_2014(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 218  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_1974(t2,((C_word*)t0)[2]);}

/* f_4903 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_4903(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4903,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4907,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 200  verb */
f_1943(t3,t2);}

/* k4905 */
static void C_ccall f_4907(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4907,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4914,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4918,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 201  shellpath */
((C_proc3)C_retrieve_symbol_proc(lf[19]))(3,*((C_word*)lf[19]+1),t3,((C_word*)t0)[2]);}

/* k4916 in k4905 */
static void C_ccall f_4918(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 201  sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[64]))(4,*((C_word*)lf[64]+1),((C_word*)t0)[2],lf[65],t1);}

/* k4912 in k4905 */
static void C_ccall f_4914(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 201  $system */
f_4760(((C_word*)t0)[2],t1);}

/* f_4895 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_4895(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4895,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4899,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* setup-api.scm: 197  verb */
f_1943(t3,t2);}

/* k4897 */
static void C_ccall f_4899(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 198  create-directory-0 */
t2=((C_word*)((C_word*)t0)[4])[1];
f_1911(t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* verb in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_fcall f_1943(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1943,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1950,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 194  setup-verbose-mode */
((C_proc2)C_retrieve_symbol_proc(lf[25]))(2,*((C_word*)lf[25]+1),t3);}

/* k1948 in verb in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_1950(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* setup-api.scm: 194  printf */
((C_proc4)C_retrieve_symbol_proc(lf[61]))(4,*((C_word*)lf[61]+1),((C_word*)t0)[3],lf[62],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* create-directory-0 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_fcall f_1911(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1911,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1917,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=((C_word)li4),tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_1917(t6,t1,t2);}

/* loop in create-directory-0 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_fcall f_1917(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1917,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1924,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1941,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 190  directory? */
((C_proc3)C_retrieve_symbol_proc(lf[60]))(3,*((C_word*)lf[60]+1),t4,t2);}
else{
t4=t3;
f_1924(t4,C_SCHEME_FALSE);}}

/* k1939 in loop in create-directory-0 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_1941(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_1924(t2,(C_word)C_i_not(t1));}

/* k1922 in loop in create-directory-0 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_fcall f_1924(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1924,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1927,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1934,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 191  pathname-directory */
((C_proc3)C_retrieve_symbol_proc(lf[59]))(3,*((C_word*)lf[59]+1),t3,((C_word*)t0)[3]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k1932 in k1922 in loop in create-directory-0 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_1934(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 191  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_1917(t2,((C_word*)t0)[2],t1);}

/* k1925 in k1922 in loop in create-directory-0 in k1906 in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_1927(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 192  create-directory */
t2=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* setup-api#sudo-install in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_1886(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2rv,(void*)f_1886r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_1886r(t0,t1,t2);}}

static void C_ccall f_1886r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
if(C_truep((C_word)C_vemptyp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_retrieve2(lf[12],"setup-api#*sudo*"));}
else{
if(C_truep((C_word)C_i_vector_ref(t2,C_fix(0)))){
t3=t1;
t4=lf[12] /* setup-api#*sudo* */ =C_SCHEME_TRUE;;
if(C_truep(C_retrieve2(lf[13],"setup-api#*windows-shell*"))){
t5=lf[12] /* setup-api#*sudo* */ =C_SCHEME_FALSE;;
/* setup-api.scm: 153  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[50]+1)))(3,*((C_word*)lf[50]+1),t3,lf[51]);}
else{
t5=C_mutate(&lf[31] /* (set! setup-api#*copy-command* ...) */,lf[52]);
t6=C_mutate(&lf[32] /* (set! setup-api#*remove-command* ...) */,lf[53]);
t7=C_mutate(&lf[33] /* (set! setup-api#*move-command* ...) */,lf[54]);
t8=C_mutate(&lf[34] /* (set! setup-api#*chmod-command* ...) */,lf[55]);
t9=C_mutate(&lf[35] /* (set! setup-api#*ranlib-command* ...) */,lf[56]);
t10=C_mutate(&lf[36] /* (set! setup-api#*mkdir-command* ...) */,lf[57]);
t11=t3;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,t10);}}
else{
/* setup-api.scm: 178  user-install-setup */
f_1860(t1);}}}

/* setup-api#user-install-setup in k1817 in k1813 in k1807 in k1803 in k1799 in k1795 in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_fcall f_1860(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1860,NULL,1,t1);}
t2=lf[12] /* setup-api#*sudo* */ =C_SCHEME_FALSE;;
if(C_truep(C_retrieve2(lf[13],"setup-api#*windows-shell*"))){
t3=t1;
t4=C_mutate(&lf[31] /* (set! setup-api#*copy-command* ...) */,lf[38]);
t5=C_mutate(&lf[32] /* (set! setup-api#*remove-command* ...) */,lf[39]);
t6=C_mutate(&lf[33] /* (set! setup-api#*move-command* ...) */,lf[40]);
t7=C_mutate(&lf[34] /* (set! setup-api#*chmod-command* ...) */,lf[41]);
t8=C_mutate(&lf[35] /* (set! setup-api#*ranlib-command* ...) */,lf[42]);
t9=t3;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}
else{
t3=t1;
t4=C_mutate(&lf[31] /* (set! setup-api#*copy-command* ...) */,lf[43]);
t5=C_mutate(&lf[32] /* (set! setup-api#*remove-command* ...) */,lf[44]);
t6=C_mutate(&lf[33] /* (set! setup-api#*move-command* ...) */,lf[45]);
t7=C_mutate(&lf[34] /* (set! setup-api#*chmod-command* ...) */,lf[46]);
t8=C_mutate(&lf[35] /* (set! setup-api#*ranlib-command* ...) */,lf[47]);
t9=C_mutate(&lf[36] /* (set! setup-api#*mkdir-command* ...) */,lf[48]);
t10=t3;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,t9);}}

/* setup-api#cross-chicken in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_1788(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1788,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_fudge(C_fix(39)));}

/* setup-api#shellpath in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_1778(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1778,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1786,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 112  normalize-pathname */
((C_proc3)C_retrieve_symbol_proc(lf[21]))(3,*((C_word*)lf[21]+1),t3,t2);}

/* k1784 in setup-api#shellpath in k1774 in k1771 in k1767 in k1764 in k1761 in k1757 in k1754 in k1751 in k1747 in k1743 in k1740 in k1734 in k1730 in k1726 in k1722 in k1718 in k4983 in k4987 in k4991 in k4995 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 */
static void C_ccall f_1786(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 112  qs */
((C_proc3)C_retrieve_symbol_proc(lf[20]))(3,*((C_word*)lf[20]+1),((C_word*)t0)[2],t1);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[417] = {
{"toplevel:setup_api_scm",(void*)C_toplevel},
{"f_1669:setup_api_scm",(void*)f_1669},
{"f_1672:setup_api_scm",(void*)f_1672},
{"f_1675:setup_api_scm",(void*)f_1675},
{"f_1678:setup_api_scm",(void*)f_1678},
{"f_1681:setup_api_scm",(void*)f_1681},
{"f_1684:setup_api_scm",(void*)f_1684},
{"f_1687:setup_api_scm",(void*)f_1687},
{"f_1690:setup_api_scm",(void*)f_1690},
{"f_1693:setup_api_scm",(void*)f_1693},
{"f_1696:setup_api_scm",(void*)f_1696},
{"f_1699:setup_api_scm",(void*)f_1699},
{"f_1702:setup_api_scm",(void*)f_1702},
{"f_1705:setup_api_scm",(void*)f_1705},
{"f_1708:setup_api_scm",(void*)f_1708},
{"f_1711:setup_api_scm",(void*)f_1711},
{"f_4997:setup_api_scm",(void*)f_4997},
{"f_4993:setup_api_scm",(void*)f_4993},
{"f_4989:setup_api_scm",(void*)f_4989},
{"f_4985:setup_api_scm",(void*)f_4985},
{"f_1720:setup_api_scm",(void*)f_1720},
{"f_1724:setup_api_scm",(void*)f_1724},
{"f_1728:setup_api_scm",(void*)f_1728},
{"f_1732:setup_api_scm",(void*)f_1732},
{"f_1736:setup_api_scm",(void*)f_1736},
{"f_4953:setup_api_scm",(void*)f_4953},
{"f_1742:setup_api_scm",(void*)f_1742},
{"f_1745:setup_api_scm",(void*)f_1745},
{"f_1749:setup_api_scm",(void*)f_1749},
{"f_1753:setup_api_scm",(void*)f_1753},
{"f_1756:setup_api_scm",(void*)f_1756},
{"f_1759:setup_api_scm",(void*)f_1759},
{"f_1763:setup_api_scm",(void*)f_1763},
{"f_1766:setup_api_scm",(void*)f_1766},
{"f_4934:setup_api_scm",(void*)f_4934},
{"f_1769:setup_api_scm",(void*)f_1769},
{"f_1773:setup_api_scm",(void*)f_1773},
{"f_4921:setup_api_scm",(void*)f_4921},
{"f_1776:setup_api_scm",(void*)f_1776},
{"f_1797:setup_api_scm",(void*)f_1797},
{"f_1801:setup_api_scm",(void*)f_1801},
{"f_1805:setup_api_scm",(void*)f_1805},
{"f_1809:setup_api_scm",(void*)f_1809},
{"f_1815:setup_api_scm",(void*)f_1815},
{"f_1819:setup_api_scm",(void*)f_1819},
{"f_1908:setup_api_scm",(void*)f_1908},
{"f_1960:setup_api_scm",(void*)f_1960},
{"f_2132:setup_api_scm",(void*)f_2132},
{"f_4891:setup_api_scm",(void*)f_4891},
{"f_2893:setup_api_scm",(void*)f_2893},
{"f_4782:setup_api_scm",(void*)f_4782},
{"f_4798:setup_api_scm",(void*)f_4798},
{"f_4835:setup_api_scm",(void*)f_4835},
{"f_4828:setup_api_scm",(void*)f_4828},
{"f_4832:setup_api_scm",(void*)f_4832},
{"f_4805:setup_api_scm",(void*)f_4805},
{"f_4506:setup_api_scm",(void*)f_4506},
{"f_4760:setup_api_scm",(void*)f_4760},
{"f_4777:setup_api_scm",(void*)f_4777},
{"f_4764:setup_api_scm",(void*)f_4764},
{"f_4729:setup_api_scm",(void*)f_4729},
{"f_4758:setup_api_scm",(void*)f_4758},
{"f_4736:setup_api_scm",(void*)f_4736},
{"f_4747:setup_api_scm",(void*)f_4747},
{"f_4743:setup_api_scm",(void*)f_4743},
{"f_4629:setup_api_scm",(void*)f_4629},
{"f_4633:setup_api_scm",(void*)f_4633},
{"f_4708:setup_api_scm",(void*)f_4708},
{"f_4664:setup_api_scm",(void*)f_4664},
{"f_4668:setup_api_scm",(void*)f_4668},
{"f_4676:setup_api_scm",(void*)f_4676},
{"f_4689:setup_api_scm",(void*)f_4689},
{"f_4695:setup_api_scm",(void*)f_4695},
{"f_4671:setup_api_scm",(void*)f_4671},
{"f_4659:setup_api_scm",(void*)f_4659},
{"f_4655:setup_api_scm",(void*)f_4655},
{"f_4576:setup_api_scm",(void*)f_4576},
{"f_4580:setup_api_scm",(void*)f_4580},
{"f_4618:setup_api_scm",(void*)f_4618},
{"f_4624:setup_api_scm",(void*)f_4624},
{"f_4583:setup_api_scm",(void*)f_4583},
{"f_4588:setup_api_scm",(void*)f_4588},
{"f_4615:setup_api_scm",(void*)f_4615},
{"f_4611:setup_api_scm",(void*)f_4611},
{"f_4595:setup_api_scm",(void*)f_4595},
{"f_4601:setup_api_scm",(void*)f_4601},
{"f_4607:setup_api_scm",(void*)f_4607},
{"f_4562:setup_api_scm",(void*)f_4562},
{"f_4574:setup_api_scm",(void*)f_4574},
{"f_4570:setup_api_scm",(void*)f_4570},
{"f_4518:setup_api_scm",(void*)f_4518},
{"f_4522:setup_api_scm",(void*)f_4522},
{"f_4541:setup_api_scm",(void*)f_4541},
{"f_4531:setup_api_scm",(void*)f_4531},
{"f_4508:setup_api_scm",(void*)f_4508},
{"f_4516:setup_api_scm",(void*)f_4516},
{"f_4341:setup_api_scm",(void*)f_4341},
{"f_4372:setup_api_scm",(void*)f_4372},
{"f_4376:setup_api_scm",(void*)f_4376},
{"f_4378:setup_api_scm",(void*)f_4378},
{"f_4458:setup_api_scm",(void*)f_4458},
{"f_4344:setup_api_scm",(void*)f_4344},
{"f_4365:setup_api_scm",(void*)f_4365},
{"f_4361:setup_api_scm",(void*)f_4361},
{"f_4350:setup_api_scm",(void*)f_4350},
{"f_4354:setup_api_scm",(void*)f_4354},
{"f_4331:setup_api_scm",(void*)f_4331},
{"f_4339:setup_api_scm",(void*)f_4339},
{"f_4317:setup_api_scm",(void*)f_4317},
{"f_4325:setup_api_scm",(void*)f_4325},
{"f_4329:setup_api_scm",(void*)f_4329},
{"f_4208:setup_api_scm",(void*)f_4208},
{"f_4214:setup_api_scm",(void*)f_4214},
{"f_4227:setup_api_scm",(void*)f_4227},
{"f_4239:setup_api_scm",(void*)f_4239},
{"f_4245:setup_api_scm",(void*)f_4245},
{"f_4273:setup_api_scm",(void*)f_4273},
{"f_4284:setup_api_scm",(void*)f_4284},
{"f_4288:setup_api_scm",(void*)f_4288},
{"f_4260:setup_api_scm",(void*)f_4260},
{"f_4267:setup_api_scm",(void*)f_4267},
{"f_4198:setup_api_scm",(void*)f_4198},
{"f_4206:setup_api_scm",(void*)f_4206},
{"f_4178:setup_api_scm",(void*)f_4178},
{"f_4196:setup_api_scm",(void*)f_4196},
{"f_4185:setup_api_scm",(void*)f_4185},
{"f_4192:setup_api_scm",(void*)f_4192},
{"f_4066:setup_api_scm",(void*)f_4066},
{"f_4070:setup_api_scm",(void*)f_4070},
{"f_4172:setup_api_scm",(void*)f_4172},
{"f_4073:setup_api_scm",(void*)f_4073},
{"f_4169:setup_api_scm",(void*)f_4169},
{"f_4076:setup_api_scm",(void*)f_4076},
{"f_4166:setup_api_scm",(void*)f_4166},
{"f_4079:setup_api_scm",(void*)f_4079},
{"f_4160:setup_api_scm",(void*)f_4160},
{"f_4082:setup_api_scm",(void*)f_4082},
{"f_4157:setup_api_scm",(void*)f_4157},
{"f_4085:setup_api_scm",(void*)f_4085},
{"f_4088:setup_api_scm",(void*)f_4088},
{"f_4091:setup_api_scm",(void*)f_4091},
{"f_4151:setup_api_scm",(void*)f_4151},
{"f_4094:setup_api_scm",(void*)f_4094},
{"f_4142:setup_api_scm",(void*)f_4142},
{"f_4128:setup_api_scm",(void*)f_4128},
{"f_4131:setup_api_scm",(void*)f_4131},
{"f_4097:setup_api_scm",(void*)f_4097},
{"f_4100:setup_api_scm",(void*)f_4100},
{"f_4114:setup_api_scm",(void*)f_4114},
{"f_4110:setup_api_scm",(void*)f_4110},
{"f_4103:setup_api_scm",(void*)f_4103},
{"f_4013:setup_api_scm",(void*)f_4013},
{"f_4017:setup_api_scm",(void*)f_4017},
{"f_4026:setup_api_scm",(void*)f_4026},
{"f_4038:setup_api_scm",(void*)f_4038},
{"f_4064:setup_api_scm",(void*)f_4064},
{"f_4032:setup_api_scm",(void*)f_4032},
{"f_4020:setup_api_scm",(void*)f_4020},
{"f_3958:setup_api_scm",(void*)f_3958},
{"f_3962:setup_api_scm",(void*)f_3962},
{"f_3971:setup_api_scm",(void*)f_3971},
{"f_3978:setup_api_scm",(void*)f_3978},
{"f_3982:setup_api_scm",(void*)f_3982},
{"f_3965:setup_api_scm",(void*)f_3965},
{"f_3968:setup_api_scm",(void*)f_3968},
{"f_3822:setup_api_scm",(void*)f_3822},
{"f_3826:setup_api_scm",(void*)f_3826},
{"f_3832:setup_api_scm",(void*)f_3832},
{"f_3835:setup_api_scm",(void*)f_3835},
{"f_3838:setup_api_scm",(void*)f_3838},
{"f_3924:setup_api_scm",(void*)f_3924},
{"f_3841:setup_api_scm",(void*)f_3841},
{"f_3875:setup_api_scm",(void*)f_3875},
{"f_3882:setup_api_scm",(void*)f_3882},
{"f_3885:setup_api_scm",(void*)f_3885},
{"f_3911:setup_api_scm",(void*)f_3911},
{"f_3888:setup_api_scm",(void*)f_3888},
{"f_3844:setup_api_scm",(void*)f_3844},
{"f_3873:setup_api_scm",(void*)f_3873},
{"f_3847:setup_api_scm",(void*)f_3847},
{"f_3665:setup_api_scm",(void*)f_3665},
{"f_3669:setup_api_scm",(void*)f_3669},
{"f_3685:setup_api_scm",(void*)f_3685},
{"f_3688:setup_api_scm",(void*)f_3688},
{"f_3691:setup_api_scm",(void*)f_3691},
{"f_3788:setup_api_scm",(void*)f_3788},
{"f_3694:setup_api_scm",(void*)f_3694},
{"f_3752:setup_api_scm",(void*)f_3752},
{"f_3766:setup_api_scm",(void*)f_3766},
{"f_3770:setup_api_scm",(void*)f_3770},
{"f_3697:setup_api_scm",(void*)f_3697},
{"f_3705:setup_api_scm",(void*)f_3705},
{"f_3712:setup_api_scm",(void*)f_3712},
{"f_3715:setup_api_scm",(void*)f_3715},
{"f_3741:setup_api_scm",(void*)f_3741},
{"f_3718:setup_api_scm",(void*)f_3718},
{"f_3700:setup_api_scm",(void*)f_3700},
{"f_3671:setup_api_scm",(void*)f_3671},
{"f_3331:setup_api_scm",(void*)f_3331},
{"f_3338:setup_api_scm",(void*)f_3338},
{"f_3341:setup_api_scm",(void*)f_3341},
{"f_3380:setup_api_scm",(void*)f_3380},
{"f_3384:setup_api_scm",(void*)f_3384},
{"f_3390:setup_api_scm",(void*)f_3390},
{"f_3393:setup_api_scm",(void*)f_3393},
{"f_3396:setup_api_scm",(void*)f_3396},
{"f_3399:setup_api_scm",(void*)f_3399},
{"f_3499:setup_api_scm",(void*)f_3499},
{"f_3506:setup_api_scm",(void*)f_3506},
{"f_3628:setup_api_scm",(void*)f_3628},
{"f_3599:setup_api_scm",(void*)f_3599},
{"f_3618:setup_api_scm",(void*)f_3618},
{"f_3509:setup_api_scm",(void*)f_3509},
{"f_3512:setup_api_scm",(void*)f_3512},
{"f_3596:setup_api_scm",(void*)f_3596},
{"f_3515:setup_api_scm",(void*)f_3515},
{"f_3573:setup_api_scm",(void*)f_3573},
{"f_3565:setup_api_scm",(void*)f_3565},
{"f_3530:setup_api_scm",(void*)f_3530},
{"f_3549:setup_api_scm",(void*)f_3549},
{"f_3521:setup_api_scm",(void*)f_3521},
{"f_3402:setup_api_scm",(void*)f_3402},
{"f_3405:setup_api_scm",(void*)f_3405},
{"f_3497:setup_api_scm",(void*)f_3497},
{"f_3408:setup_api_scm",(void*)f_3408},
{"f_3470:setup_api_scm",(void*)f_3470},
{"f_3478:setup_api_scm",(void*)f_3478},
{"f_3486:setup_api_scm",(void*)f_3486},
{"f_3473:setup_api_scm",(void*)f_3473},
{"f_3414:setup_api_scm",(void*)f_3414},
{"f_3426:setup_api_scm",(void*)f_3426},
{"f_3434:setup_api_scm",(void*)f_3434},
{"f_3438:setup_api_scm",(void*)f_3438},
{"f_3441:setup_api_scm",(void*)f_3441},
{"f_3429:setup_api_scm",(void*)f_3429},
{"f_3420:setup_api_scm",(void*)f_3420},
{"f_3277:setup_api_scm",(void*)f_3277},
{"f_3283:setup_api_scm",(void*)f_3283},
{"f_3296:setup_api_scm",(void*)f_3296},
{"f_3299:setup_api_scm",(void*)f_3299},
{"f_3252:setup_api_scm",(void*)f_3252},
{"f_3272:setup_api_scm",(void*)f_3272},
{"f_3230:setup_api_scm",(void*)f_3230},
{"f_3250:setup_api_scm",(void*)f_3250},
{"f_3175:setup_api_scm",(void*)f_3175},
{"f_3182:setup_api_scm",(void*)f_3182},
{"f_3185:setup_api_scm",(void*)f_3185},
{"f_3204:setup_api_scm",(void*)f_3204},
{"f_3212:setup_api_scm",(void*)f_3212},
{"f_3025:setup_api_scm",(void*)f_3025},
{"f_3127:setup_api_scm",(void*)f_3127},
{"f_3118:setup_api_scm",(void*)f_3118},
{"f_3126:setup_api_scm",(void*)f_3126},
{"f_3027:setup_api_scm",(void*)f_3027},
{"f_3034:setup_api_scm",(void*)f_3034},
{"f_3101:setup_api_scm",(void*)f_3101},
{"f_3091:setup_api_scm",(void*)f_3091},
{"f_3037:setup_api_scm",(void*)f_3037},
{"f_3040:setup_api_scm",(void*)f_3040},
{"f_3046:setup_api_scm",(void*)f_3046},
{"f_3049:setup_api_scm",(void*)f_3049},
{"f_3068:setup_api_scm",(void*)f_3068},
{"f_3076:setup_api_scm",(void*)f_3076},
{"f_3052:setup_api_scm",(void*)f_3052},
{"f_2911:setup_api_scm",(void*)f_2911},
{"f_3023:setup_api_scm",(void*)f_3023},
{"f_3019:setup_api_scm",(void*)f_3019},
{"f_3008:setup_api_scm",(void*)f_3008},
{"f_2918:setup_api_scm",(void*)f_2918},
{"f_2921:setup_api_scm",(void*)f_2921},
{"f_3005:setup_api_scm",(void*)f_3005},
{"f_2864:setup_api_scm",(void*)f_2864},
{"f_2924:setup_api_scm",(void*)f_2924},
{"f_2997:setup_api_scm",(void*)f_2997},
{"f_2956:setup_api_scm",(void*)f_2956},
{"f_2988:setup_api_scm",(void*)f_2988},
{"f_2959:setup_api_scm",(void*)f_2959},
{"f_2978:setup_api_scm",(void*)f_2978},
{"f_2986:setup_api_scm",(void*)f_2986},
{"f_2927:setup_api_scm",(void*)f_2927},
{"f_2953:setup_api_scm",(void*)f_2953},
{"f_4860:setup_api_scm",(void*)f_4860},
{"f_4864:setup_api_scm",(void*)f_4864},
{"f_4887:setup_api_scm",(void*)f_4887},
{"f_4852:setup_api_scm",(void*)f_4852},
{"f_4856:setup_api_scm",(void*)f_4856},
{"f_2896:setup_api_scm",(void*)f_2896},
{"f_2903:setup_api_scm",(void*)f_2903},
{"f_2817:setup_api_scm",(void*)f_2817},
{"f_2849:setup_api_scm",(void*)f_2849},
{"f_2527:setup_api_scm",(void*)f_2527},
{"f_2815:setup_api_scm",(void*)f_2815},
{"f_2531:setup_api_scm",(void*)f_2531},
{"f_2359:setup_api_scm",(void*)f_2359},
{"f_2368:setup_api_scm",(void*)f_2368},
{"f_2373:setup_api_scm",(void*)f_2373},
{"f_2380:setup_api_scm",(void*)f_2380},
{"f_2383:setup_api_scm",(void*)f_2383},
{"f_2392:setup_api_scm",(void*)f_2392},
{"f_2395:setup_api_scm",(void*)f_2395},
{"f_2434:setup_api_scm",(void*)f_2434},
{"f_2442:setup_api_scm",(void*)f_2442},
{"f_2404:setup_api_scm",(void*)f_2404},
{"f_2534:setup_api_scm",(void*)f_2534},
{"f_2519:setup_api_scm",(void*)f_2519},
{"f_2537:setup_api_scm",(void*)f_2537},
{"f_2542:setup_api_scm",(void*)f_2542},
{"f_2546:setup_api_scm",(void*)f_2546},
{"f_2804:setup_api_scm",(void*)f_2804},
{"f_2799:setup_api_scm",(void*)f_2799},
{"f_2761:setup_api_scm",(void*)f_2761},
{"f_2767:setup_api_scm",(void*)f_2767},
{"f_2780:setup_api_scm",(void*)f_2780},
{"f_2772:setup_api_scm",(void*)f_2772},
{"f_2548:setup_api_scm",(void*)f_2548},
{"f_2284:setup_api_scm",(void*)f_2284},
{"f_2297:setup_api_scm",(void*)f_2297},
{"f_2303:setup_api_scm",(void*)f_2303},
{"f_2275:setup_api_scm",(void*)f_2275},
{"f_2552:setup_api_scm",(void*)f_2552},
{"f_2555:setup_api_scm",(void*)f_2555},
{"f_2755:setup_api_scm",(void*)f_2755},
{"f_2558:setup_api_scm",(void*)f_2558},
{"f_2749:setup_api_scm",(void*)f_2749},
{"f_2561:setup_api_scm",(void*)f_2561},
{"f_2746:setup_api_scm",(void*)f_2746},
{"f_2731:setup_api_scm",(void*)f_2731},
{"f_2732:setup_api_scm",(void*)f_2732},
{"f_2570:setup_api_scm",(void*)f_2570},
{"f_2700:setup_api_scm",(void*)f_2700},
{"f_2704:setup_api_scm",(void*)f_2704},
{"f_2720:setup_api_scm",(void*)f_2720},
{"f_2727:setup_api_scm",(void*)f_2727},
{"f_2707:setup_api_scm",(void*)f_2707},
{"f_2717:setup_api_scm",(void*)f_2717},
{"f_2576:setup_api_scm",(void*)f_2576},
{"f_2666:setup_api_scm",(void*)f_2666},
{"f_2695:setup_api_scm",(void*)f_2695},
{"f_2673:setup_api_scm",(void*)f_2673},
{"f_2595:setup_api_scm",(void*)f_2595},
{"f_2603:setup_api_scm",(void*)f_2603},
{"f_2638:setup_api_scm",(void*)f_2638},
{"f_2653:setup_api_scm",(void*)f_2653},
{"f_2659:setup_api_scm",(void*)f_2659},
{"f_2644:setup_api_scm",(void*)f_2644},
{"f_2609:setup_api_scm",(void*)f_2609},
{"f_2615:setup_api_scm",(void*)f_2615},
{"f_2633:setup_api_scm",(void*)f_2633},
{"f_2630:setup_api_scm",(void*)f_2630},
{"f_2619:setup_api_scm",(void*)f_2619},
{"f_2601:setup_api_scm",(void*)f_2601},
{"f_2339:setup_api_scm",(void*)f_2339},
{"f_2347:setup_api_scm",(void*)f_2347},
{"f_2329:setup_api_scm",(void*)f_2329},
{"f_2337:setup_api_scm",(void*)f_2337},
{"f_2223:setup_api_scm",(void*)f_2223},
{"f_2271:setup_api_scm",(void*)f_2271},
{"f_2254:setup_api_scm",(void*)f_2254},
{"f_2264:setup_api_scm",(void*)f_2264},
{"f_2258:setup_api_scm",(void*)f_2258},
{"f_2226:setup_api_scm",(void*)f_2226},
{"f_2230:setup_api_scm",(void*)f_2230},
{"f_2191:setup_api_scm",(void*)f_2191},
{"f_2170:setup_api_scm",(void*)f_2170},
{"f_2152:setup_api_scm",(void*)f_2152},
{"f_2166:setup_api_scm",(void*)f_2166},
{"f_2163:setup_api_scm",(void*)f_2163},
{"f_2148:setup_api_scm",(void*)f_2148},
{"f_2241:setup_api_scm",(void*)f_2241},
{"f_2197:setup_api_scm",(void*)f_2197},
{"f_2221:setup_api_scm",(void*)f_2221},
{"f_2204:setup_api_scm",(void*)f_2204},
{"f_2042:setup_api_scm",(void*)f_2042},
{"f_2125:setup_api_scm",(void*)f_2125},
{"f_2046:setup_api_scm",(void*)f_2046},
{"f_2100:setup_api_scm",(void*)f_2100},
{"f_2103:setup_api_scm",(void*)f_2103},
{"f_2114:setup_api_scm",(void*)f_2114},
{"f_2118:setup_api_scm",(void*)f_2118},
{"f_2110:setup_api_scm",(void*)f_2110},
{"f_2061:setup_api_scm",(void*)f_2061},
{"f_2071:setup_api_scm",(void*)f_2071},
{"f_2077:setup_api_scm",(void*)f_2077},
{"f_2081:setup_api_scm",(void*)f_2081},
{"f_2097:setup_api_scm",(void*)f_2097},
{"f_2090:setup_api_scm",(void*)f_2090},
{"f_1962:setup_api_scm",(void*)f_1962},
{"f_1966:setup_api_scm",(void*)f_1966},
{"f_2036:setup_api_scm",(void*)f_2036},
{"f_1969:setup_api_scm",(void*)f_1969},
{"f_1974:setup_api_scm",(void*)f_1974},
{"f_1978:setup_api_scm",(void*)f_1978},
{"f_1981:setup_api_scm",(void*)f_1981},
{"f_1984:setup_api_scm",(void*)f_1984},
{"f_1987:setup_api_scm",(void*)f_1987},
{"f_1990:setup_api_scm",(void*)f_1990},
{"f_2014:setup_api_scm",(void*)f_2014},
{"f_4903:setup_api_scm",(void*)f_4903},
{"f_4907:setup_api_scm",(void*)f_4907},
{"f_4918:setup_api_scm",(void*)f_4918},
{"f_4914:setup_api_scm",(void*)f_4914},
{"f_4895:setup_api_scm",(void*)f_4895},
{"f_4899:setup_api_scm",(void*)f_4899},
{"f_1943:setup_api_scm",(void*)f_1943},
{"f_1950:setup_api_scm",(void*)f_1950},
{"f_1911:setup_api_scm",(void*)f_1911},
{"f_1917:setup_api_scm",(void*)f_1917},
{"f_1941:setup_api_scm",(void*)f_1941},
{"f_1924:setup_api_scm",(void*)f_1924},
{"f_1934:setup_api_scm",(void*)f_1934},
{"f_1927:setup_api_scm",(void*)f_1927},
{"f_1886:setup_api_scm",(void*)f_1886},
{"f_1860:setup_api_scm",(void*)f_1860},
{"f_1788:setup_api_scm",(void*)f_1788},
{"f_1778:setup_api_scm",(void*)f_1778},
{"f_1786:setup_api_scm",(void*)f_1786},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
