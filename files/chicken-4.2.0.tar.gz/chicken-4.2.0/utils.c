/* Generated from utils.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2009-09-21 21:26
   Version 4.0.1 - SVN rev. 14292
   linux-unix-gnu-x86 [ manyargs dload ptables applyhook ]
   compiled 2009-05-12 on galinha (Linux)
   command line: utils.scm -no-trace -optimize-level 2 -include-path . -include-path ./ -explicit-use -output-file utils.c
   unit: utils
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_13_toplevel)
C_externimport void C_ccall C_srfi_13_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_posix_toplevel)
C_externimport void C_ccall C_posix_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_files_toplevel)
C_externimport void C_ccall C_files_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[62];
static double C_possibly_force_alignment;
static C_char C_TLS li0[] C_aligned={C_lihdr(0,0,25),40,115,121,115,116,101,109,42,32,102,115,116,114,50,51,32,46,32,97,114,103,115,50,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li1[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li2[] C_aligned={C_lihdr(0,0,31),40,102,111,114,45,101,97,99,104,45,108,105,110,101,32,112,114,111,99,51,55,32,46,32,112,111,114,116,51,56,41,0};
static C_char C_TLS li3[] C_aligned={C_lihdr(0,0,6),40,97,51,52,49,41,0,0};
static C_char C_TLS li4[] C_aligned={C_lihdr(0,0,12),40,97,51,54,50,32,97,114,103,54,57,41,0,0,0,0};
static C_char C_TLS li5[] C_aligned={C_lihdr(0,0,28),40,102,111,114,45,101,97,99,104,45,97,114,103,118,45,108,105,110,101,32,116,104,117,110,107,53,53,41,0,0,0,0};
static C_char C_TLS li6[] C_aligned={C_lihdr(0,0,6),40,97,51,56,54,41,0,0};
static C_char C_TLS li7[] C_aligned={C_lihdr(0,0,19),40,114,101,97,100,45,97,108,108,32,46,32,102,105,108,101,55,52,41,0,0,0,0,0};
static C_char C_TLS li8[] C_aligned={C_lihdr(0,0,11),40,97,52,52,50,32,99,49,50,55,41,0,0,0,0,0};
static C_char C_TLS li9[] C_aligned={C_lihdr(0,0,23),40,113,115,32,115,116,114,49,48,49,32,46,32,116,109,112,49,48,48,49,48,50,41,0};
static C_char C_TLS li10[] C_aligned={C_lihdr(0,0,6),40,97,53,54,48,41,0,0};
static C_char C_TLS li11[] C_aligned={C_lihdr(0,0,12),40,97,53,53,52,32,101,120,50,50,52,41,0,0,0,0};
static C_char C_TLS li12[] C_aligned={C_lihdr(0,0,6),40,97,53,55,53,41,0,0};
static C_char C_TLS li13[] C_aligned={C_lihdr(0,0,6),40,97,53,56,55,41,0,0};
static C_char C_TLS li14[] C_aligned={C_lihdr(0,0,19),40,97,53,56,49,32,46,32,97,114,103,115,50,49,55,50,51,49,41,0,0,0,0,0};
static C_char C_TLS li15[] C_aligned={C_lihdr(0,0,6),40,97,53,54,57,41,0,0};
static C_char C_TLS li16[] C_aligned={C_lihdr(0,0,14),40,97,53,52,56,32,107,50,49,54,50,50,50,41,0,0};
static C_char C_TLS li17[] C_aligned={C_lihdr(0,0,6),40,97,54,49,55,41,0,0};
static C_char C_TLS li18[] C_aligned={C_lihdr(0,0,12),40,97,54,49,49,32,101,120,49,57,57,41,0,0,0,0};
static C_char C_TLS li19[] C_aligned={C_lihdr(0,0,6),40,97,54,50,54,41,0,0};
static C_char C_TLS li20[] C_aligned={C_lihdr(0,0,6),40,97,54,51,56,41,0,0};
static C_char C_TLS li21[] C_aligned={C_lihdr(0,0,19),40,97,54,51,50,32,46,32,97,114,103,115,49,57,50,50,48,52,41,0,0,0,0,0};
static C_char C_TLS li22[] C_aligned={C_lihdr(0,0,6),40,97,54,50,48,41,0,0};
static C_char C_TLS li23[] C_aligned={C_lihdr(0,0,14),40,97,54,48,53,32,107,49,57,49,49,57,55,41,0,0};
static C_char C_TLS li24[] C_aligned={C_lihdr(0,0,6),40,97,53,57,54,41,0,0};
static C_char C_TLS li25[] C_aligned={C_lihdr(0,0,6),40,97,54,57,48,41,0,0};
static C_char C_TLS li26[] C_aligned={C_lihdr(0,0,6),40,97,54,57,51,41,0,0};
static C_char C_TLS li27[] C_aligned={C_lihdr(0,0,38),40,99,111,109,112,105,108,101,45,102,105,108,101,32,102,105,108,101,110,97,109,101,49,53,51,32,46,32,116,109,112,49,53,50,49,53,52,41,0,0};
static C_char C_TLS li28[] C_aligned={C_lihdr(0,0,10),40,116,111,112,108,101,118,101,108,41,0,0,0,0,0,0};


C_noret_decl(C_utils_toplevel)
C_externexport void C_ccall C_utils_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_256)
static void C_ccall f_256(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_259)
static void C_ccall f_259(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_262)
static void C_ccall f_262(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_265)
static void C_ccall f_265(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_268)
static void C_ccall f_268(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_499)
static void C_ccall f_499(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_503)
static void C_ccall f_503(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_506)
static void C_ccall f_506(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_507)
static void C_ccall f_507(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_507)
static void C_ccall f_507r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_694)
static void C_ccall f_694(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_511)
static void C_ccall f_511(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_514)
static void C_ccall f_514(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_691)
static void C_ccall f_691(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_517)
static void C_ccall f_517(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_689)
static void C_ccall f_689(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_520)
static void C_ccall f_520(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_526)
static void C_ccall f_526(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_529)
static void C_ccall f_529(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_651)
static void C_ccall f_651(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_679)
static void C_ccall f_679(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_675)
static void C_ccall f_675(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_655)
static void C_ccall f_655(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_659)
static void C_ccall f_659(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_663)
static void C_ccall f_663(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_532)
static void C_ccall f_532(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_597)
static void C_ccall f_597(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_606)
static void C_ccall f_606(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_621)
static void C_ccall f_621(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_633)
static void C_ccall f_633(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_633)
static void C_ccall f_633r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_639)
static void C_ccall f_639(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_627)
static void C_ccall f_627(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_612)
static void C_ccall f_612(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_618)
static void C_ccall f_618(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_604)
static void C_ccall f_604(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_535)
static void C_ccall f_535(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_549)
static void C_ccall f_549(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_570)
static void C_ccall f_570(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_582)
static void C_ccall f_582(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_582)
static void C_ccall f_582r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_588)
static void C_ccall f_588(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_576)
static void C_ccall f_576(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_580)
static void C_ccall f_580(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_555)
static void C_ccall f_555(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_561)
static void C_ccall f_561(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_565)
static void C_ccall f_565(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_547)
static void C_ccall f_547(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_412)
static void C_ccall f_412(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_412)
static void C_ccall f_412r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_416)
static void C_ccall f_416(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_466)
static void C_ccall f_466(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_443)
static void C_ccall f_443(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_441)
static void C_ccall f_441(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_369)
static void C_ccall f_369(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_369)
static void C_ccall f_369r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_373)
static void C_ccall f_373(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_379)
static void C_ccall f_379(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_387)
static void C_ccall f_387(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_324)
static void C_ccall f_324(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_349)
static void C_ccall f_349(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_363)
static void C_ccall f_363(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_342)
static void C_ccall f_342(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_288)
static void C_ccall f_288(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_288)
static void C_ccall f_288r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_295)
static void C_ccall f_295(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_300)
static void C_fcall f_300(C_word t0,C_word t1) C_noret;
C_noret_decl(f_304)
static void C_ccall f_304(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_313)
static void C_ccall f_313(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_270)
static void C_ccall f_270(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_270)
static void C_ccall f_270r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_274)
static void C_ccall f_274(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_277)
static void C_ccall f_277(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_300)
static void C_fcall trf_300(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_300(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_300(t0,t1);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr3rv)
static void C_fcall tr3rv(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3rv(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n+1);
t3=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_utils_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_utils_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("utils_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(522)){
C_save(t1);
C_rereclaim2(522*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,62);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[2]=C_h_intern(&lf[2],7,"sprintf");
lf[3]=C_h_intern(&lf[3],6,"system");
lf[4]=C_h_intern(&lf[4],7,"system*");
lf[5]=C_h_intern(&lf[5],9,"\003syserror");
lf[6]=C_decode_literal(C_heaptop,"\376B\000\0003shell invocation failed with non-zero return status");
lf[7]=C_h_intern(&lf[7],9,"read-line");
lf[8]=C_h_intern(&lf[8],13,"for-each-line");
lf[9]=C_h_intern(&lf[9],18,"\003sysstandard-input");
lf[10]=C_h_intern(&lf[10],14,"\003syscheck-port");
lf[11]=C_h_intern(&lf[11],18,"for-each-argv-line");
lf[12]=C_decode_literal(C_heaptop,"\376B\000\000\001-");
lf[13]=C_h_intern(&lf[13],20,"with-input-from-file");
lf[14]=C_h_intern(&lf[14],12,"\003sysfor-each");
lf[15]=C_h_intern(&lf[15],22,"command-line-arguments");
lf[16]=C_h_intern(&lf[16],8,"read-all");
lf[17]=C_h_intern(&lf[17],20,"\003sysread-string/port");
lf[18]=C_h_intern(&lf[18],5,"port\077");
lf[19]=C_h_intern(&lf[19],2,"qs");
lf[20]=C_h_intern(&lf[20],7,"mingw32");
lf[21]=C_h_intern(&lf[21],4,"msvc");
lf[22]=C_h_intern(&lf[22],13,"string-append");
lf[23]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[24]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[25]=C_decode_literal(C_heaptop,"\376B\000\000\002\047\047");
lf[26]=C_h_intern(&lf[26],18,"string-concatenate");
lf[27]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000#\376\003\000\000\002\376\377\012\000\000\042\376\003\000\000\002\376\377\012\000\000\047\376\003\000\000\002\376\377\012\000\000`\376\003\000\000\002\376\377\012\000\000\264\376\003\000\000\002\376\377\012\000\000~\376\003\000\000\002\376\377\012\000\000&\376\003\000"
"\000\002\376\377\012\000\000%\376\003\000\000\002\376\377\012\000\000$\376\003\000\000\002\376\377\012\000\000!\376\003\000\000\002\376\377\012\000\000*\376\003\000\000\002\376\377\012\000\000;\376\003\000\000\002\376\377\012\000\000<\376\003\000\000\002\376\377\012\000\000>\376\003\000\000\002\376"
"\377\012\000\000\134\376\003\000\000\002\376\377\012\000\000(\376\003\000\000\002\376\377\012\000\000)\376\003\000\000\002\376\377\012\000\000[\376\003\000\000\002\376\377\012\000\000]\376\003\000\000\002\376\377\012\000\000{\376\003\000\000\002\376\377\012\000\000}\376\377\016");
lf[28]=C_h_intern(&lf[28],7,"\003sysmap");
lf[29]=C_h_intern(&lf[29],16,"\003sysstring->list");
lf[30]=C_h_intern(&lf[30],14,"build-platform");
lf[31]=C_h_intern(&lf[31],20,"compile-file-options");
lf[32]=C_h_intern(&lf[32],4,"load");
lf[33]=C_h_intern(&lf[33],12,"compile-file");
lf[34]=C_decode_literal(C_heaptop,"\376B\000\000\003csc");
lf[35]=C_h_intern(&lf[35],5,"abort");
lf[36]=C_h_intern(&lf[36],12,"delete-file*");
lf[37]=C_h_intern(&lf[37],22,"with-exception-handler");
lf[38]=C_h_intern(&lf[38],30,"call-with-current-continuation");
lf[39]=C_h_intern(&lf[39],7,"on-exit");
lf[40]=C_decode_literal(C_heaptop,"\376B\000\000\025~a~a -s ~a ~a -o ~a~a");
lf[41]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[42]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[43]=C_h_intern(&lf[43],18,"string-intersperse");
lf[44]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[45]=C_h_intern(&lf[45],6,"append");
lf[46]=C_h_intern(&lf[46],5,"print");
lf[47]=C_decode_literal(C_heaptop,"\376B\000\000\014; compiling ");
lf[48]=C_decode_literal(C_heaptop,"\376B\000\000\004 ...");
lf[49]=C_h_intern(&lf[49],21,"create-temporary-file");
lf[50]=C_decode_literal(C_heaptop,"\376B\000\000\002so");
lf[51]=C_h_intern(&lf[51],12,"file-exists\077");
lf[52]=C_h_intern(&lf[52],13,"make-pathname");
lf[53]=C_h_intern(&lf[53],15,"\003sysget-keyword");
lf[54]=C_h_intern(&lf[54],5,"\000load");
lf[55]=C_h_intern(&lf[55],12,"\000output-file");
lf[56]=C_h_intern(&lf[56],8,"\000options");
lf[57]=C_h_intern(&lf[57],17,"\003syspeek-c-string");
lf[58]=C_h_intern(&lf[58],14,"make-parameter");
lf[59]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002-S\376\003\000\000\002\376B\000\000\003-O2\376\003\000\000\002\376B\000\000\003-d2\376\377\016");
lf[60]=C_h_intern(&lf[60],17,"register-feature!");
lf[61]=C_h_intern(&lf[61],5,"utils");
C_register_lf2(lf,62,create_ptable());
t2=C_mutate(&lf[0] /* (set! c85 ...) */,lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_256,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t3);}

/* k254 */
static void C_ccall f_256(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_256,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_259,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_13_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k257 in k254 */
static void C_ccall f_259(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_259,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_262,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_posix_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k260 in k257 in k254 */
static void C_ccall f_262(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_262,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_265,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_files_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k263 in k260 in k257 in k254 */
static void C_ccall f_265(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_265,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_268,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* utils.scm: 52   register-feature! */
((C_proc3)C_retrieve_proc(*((C_word*)lf[60]+1)))(3,*((C_word*)lf[60]+1),t2,lf[61]);}

/* k266 in k263 in k260 in k257 in k254 */
static void C_ccall f_268(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_268,2,t0,t1);}
t2=*((C_word*)lf[2]+1);
t3=*((C_word*)lf[3]+1);
t4=C_mutate((C_word*)lf[4]+1 /* (set! system* ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_270,a[2]=t2,a[3]=t3,a[4]=((C_word)li0),tmp=(C_word)a,a+=5,tmp));
t5=*((C_word*)lf[7]+1);
t6=C_mutate((C_word*)lf[8]+1 /* (set! for-each-line ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_288,a[2]=t5,a[3]=((C_word)li2),tmp=(C_word)a,a+=4,tmp));
t7=C_mutate((C_word*)lf[11]+1 /* (set! for-each-argv-line ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_324,a[2]=((C_word)li5),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[16]+1 /* (set! read-all ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_369,a[2]=((C_word)li7),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[19]+1 /* (set! qs ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_412,a[2]=((C_word)li9),tmp=(C_word)a,a+=3,tmp));
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_499,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* utils.scm: 126  make-parameter */
((C_proc3)C_retrieve_proc(*((C_word*)lf[58]+1)))(3,*((C_word*)lf[58]+1),t10,lf[59]);}

/* k497 in k266 in k263 in k260 in k257 in k254 */
static void C_ccall f_499(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_499,2,t0,t1);}
t2=C_mutate((C_word*)lf[31]+1 /* (set! compile-file-options ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_503,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[57]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)C_CSC_PROGRAM),C_fix(0));}

/* k501 in k497 in k266 in k263 in k260 in k257 in k254 */
static void C_ccall f_503(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_503,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_506,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* ##sys#peek-c-string */
t3=*((C_word*)lf[57]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_INSTALL_BIN_HOME),C_fix(0));}

/* k504 in k501 in k497 in k266 in k263 in k260 in k257 in k254 */
static void C_ccall f_506(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_506,2,t0,t1);}
t2=*((C_word*)lf[32]+1);
t3=C_mutate((C_word*)lf[33]+1 /* (set! compile-file ...) */,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_507,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,a[5]=((C_word)li27),tmp=(C_word)a,a+=6,tmp));
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* compile-file in k504 in k501 in k497 in k266 in k263 in k260 in k257 in k254 */
static void C_ccall f_507(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+11)){
C_save_and_reclaim((void*)tr3r,(void*)f_507r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_507r(t0,t1,t2,t3);}}

static void C_ccall f_507r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(11);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_511,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_694,a[2]=((C_word)li26),tmp=(C_word)a,a+=3,tmp);
/* ##sys#get-keyword */
((C_proc5)C_retrieve_proc(*((C_word*)lf[53]+1)))(5,*((C_word*)lf[53]+1),t4,lf[56],t3,t5);}

/* a693 in compile-file in k504 in k501 in k497 in k266 in k263 in k260 in k257 in k254 */
static void C_ccall f_694(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_694,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_LIST);}

/* k509 in compile-file in k504 in k501 in k497 in k266 in k263 in k260 in k257 in k254 */
static void C_ccall f_511(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_511,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_514,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* ##sys#get-keyword */
((C_proc4)C_retrieve_proc(*((C_word*)lf[53]+1)))(4,*((C_word*)lf[53]+1),t2,lf[55],((C_word*)t0)[2]);}

/* k512 in k509 in compile-file in k504 in k501 in k497 in k266 in k263 in k260 in k257 in k254 */
static void C_ccall f_514(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_514,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_517,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_691,a[2]=((C_word)li25),tmp=(C_word)a,a+=3,tmp);
/* ##sys#get-keyword */
((C_proc5)C_retrieve_proc(*((C_word*)lf[53]+1)))(5,*((C_word*)lf[53]+1),t2,lf[54],((C_word*)t0)[2],t3);}

/* a690 in k512 in k509 in compile-file in k504 in k501 in k497 in k266 in k263 in k260 in k257 in k254 */
static void C_ccall f_691(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_691,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* k515 in k512 in k509 in compile-file in k504 in k501 in k497 in k266 in k263 in k260 in k257 in k254 */
static void C_ccall f_517(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_517,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_520,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_689,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* utils.scm: 133  make-pathname */
((C_proc4)C_retrieve_proc(*((C_word*)lf[52]+1)))(4,*((C_word*)lf[52]+1),t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k687 in k515 in k512 in k509 in compile-file in k504 in k501 in k497 in k266 in k263 in k260 in k257 in k254 */
static void C_ccall f_689(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 133  file-exists? */
((C_proc3)C_retrieve_proc(*((C_word*)lf[51]+1)))(3,*((C_word*)lf[51]+1),((C_word*)t0)[2],t1);}

/* k518 in k515 in k512 in k509 in compile-file in k504 in k501 in k497 in k266 in k263 in k260 in k257 in k254 */
static void C_ccall f_520(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_520,2,t0,t1);}
t2=(C_truep(t1)?t1:lf[34]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_526,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t4=((C_word*)t0)[6];
if(C_truep(t4)){
t5=t3;
f_526(2,t5,C_SCHEME_FALSE);}
else{
/* utils.scm: 134  create-temporary-file */
((C_proc3)C_retrieve_proc(*((C_word*)lf[49]+1)))(3,*((C_word*)lf[49]+1),t3,lf[50]);}}

/* k524 in k518 in k515 in k512 in k509 in compile-file in k504 in k501 in k497 in k266 in k263 in k260 in k257 in k254 */
static void C_ccall f_526(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_526,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_529,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* utils.scm: 136  print */
t3=*((C_word*)lf[46]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[47],((C_word*)t0)[4],lf[48]);}

/* k527 in k524 in k518 in k515 in k512 in k509 in compile-file in k504 in k501 in k497 in k266 in k263 in k260 in k257 in k254 */
static void C_ccall f_529(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_529,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_532,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_651,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* utils.scm: 140  qs */
((C_proc3)C_retrieve_proc(*((C_word*)lf[19]+1)))(3,*((C_word*)lf[19]+1),t3,((C_word*)t0)[2]);}

/* k649 in k527 in k524 in k518 in k515 in k512 in k509 in compile-file in k504 in k501 in k497 in k266 in k263 in k260 in k257 in k254 */
static void C_ccall f_651(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_651,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_655,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_675,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_679,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 141  compile-file-options */
((C_proc2)C_retrieve_proc(*((C_word*)lf[31]+1)))(2,*((C_word*)lf[31]+1),t4);}

/* k677 in k649 in k527 in k524 in k518 in k515 in k512 in k509 in compile-file in k504 in k501 in k497 in k266 in k263 in k260 in k257 in k254 */
static void C_ccall f_679(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 141  append */
t2=*((C_word*)lf[45]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k673 in k649 in k527 in k524 in k518 in k515 in k512 in k509 in compile-file in k504 in k501 in k497 in k266 in k263 in k260 in k257 in k254 */
static void C_ccall f_675(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 141  string-intersperse */
((C_proc4)C_retrieve_proc(*((C_word*)lf[43]+1)))(4,*((C_word*)lf[43]+1),((C_word*)t0)[2],t1,lf[44]);}

/* k653 in k649 in k527 in k524 in k518 in k515 in k512 in k509 in compile-file in k504 in k501 in k497 in k266 in k263 in k260 in k257 in k254 */
static void C_ccall f_655(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_655,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_659,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* utils.scm: 142  qs */
((C_proc3)C_retrieve_proc(*((C_word*)lf[19]+1)))(3,*((C_word*)lf[19]+1),t2,((C_word*)t0)[2]);}

/* k657 in k653 in k649 in k527 in k524 in k518 in k515 in k512 in k509 in compile-file in k504 in k501 in k497 in k266 in k263 in k260 in k257 in k254 */
static void C_ccall f_659(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_659,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_663,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(C_truep(((C_word*)t0)[3])?((C_word*)t0)[3]:((C_word*)t0)[2]);
/* utils.scm: 143  qs */
((C_proc3)C_retrieve_proc(*((C_word*)lf[19]+1)))(3,*((C_word*)lf[19]+1),t2,t3);}

/* k661 in k657 in k653 in k649 in k527 in k524 in k518 in k515 in k512 in k509 in compile-file in k504 in k501 in k497 in k266 in k263 in k260 in k257 in k254 */
static void C_ccall f_663(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 137  system* */
((C_proc9)C_retrieve_proc(*((C_word*)lf[4]+1)))(9,*((C_word*)lf[4]+1),((C_word*)t0)[5],lf[40],lf[41],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1,lf[42]);}

/* k530 in k527 in k524 in k518 in k515 in k512 in k509 in compile-file in k504 in k501 in k497 in k266 in k263 in k260 in k257 in k254 */
static void C_ccall f_532(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_532,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_535,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[5])){
t3=t2;
f_535(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_597,a[2]=((C_word*)t0)[4],a[3]=((C_word)li24),tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 146  on-exit */
((C_proc3)C_retrieve_proc(*((C_word*)lf[39]+1)))(3,*((C_word*)lf[39]+1),t2,t3);}}

/* a596 in k530 in k527 in k524 in k518 in k515 in k512 in k509 in compile-file in k504 in k501 in k497 in k266 in k263 in k260 in k257 in k254 */
static void C_ccall f_597(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_597,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_604,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_606,a[2]=((C_word*)t0)[2],a[3]=((C_word)li23),tmp=(C_word)a,a+=4,tmp);
/* call-with-current-continuation */
t4=*((C_word*)lf[38]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}

/* a605 in a596 in k530 in k527 in k524 in k518 in k515 in k512 in k509 in compile-file in k504 in k501 in k497 in k266 in k263 in k260 in k257 in k254 */
static void C_ccall f_606(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_606,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_612,a[2]=t2,a[3]=((C_word)li18),tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_621,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li22),tmp=(C_word)a,a+=5,tmp);
/* with-exception-handler */
((C_proc4)C_retrieve_proc(*((C_word*)lf[37]+1)))(4,*((C_word*)lf[37]+1),t1,t3,t4);}

/* a620 in a605 in a596 in k530 in k527 in k524 in k518 in k515 in k512 in k509 in compile-file in k504 in k501 in k497 in k266 in k263 in k260 in k257 in k254 */
static void C_ccall f_621(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_621,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_627,a[2]=((C_word*)t0)[3],a[3]=((C_word)li19),tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_633,a[2]=((C_word*)t0)[2],a[3]=((C_word)li21),tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a632 in a620 in a605 in a596 in k530 in k527 in k524 in k518 in k515 in k512 in k509 in compile-file in k504 in k501 in k497 in k266 in k263 in k260 in k257 in k254 */
static void C_ccall f_633(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_633r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_633r(t0,t1,t2);}}

static void C_ccall f_633r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_639,a[2]=t2,a[3]=((C_word)li20),tmp=(C_word)a,a+=4,tmp);
/* k191197 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a638 in a632 in a620 in a605 in a596 in k530 in k527 in k524 in k518 in k515 in k512 in k509 in compile-file in k504 in k501 in k497 in k266 in k263 in k260 in k257 in k254 */
static void C_ccall f_639(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_639,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a626 in a620 in a605 in a596 in k530 in k527 in k524 in k518 in k515 in k512 in k509 in compile-file in k504 in k501 in k497 in k266 in k263 in k260 in k257 in k254 */
static void C_ccall f_627(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_627,2,t0,t1);}
/* utils.scm: 148  delete-file* */
((C_proc3)C_retrieve_proc(*((C_word*)lf[36]+1)))(3,*((C_word*)lf[36]+1),t1,((C_word*)t0)[2]);}

/* a611 in a605 in a596 in k530 in k527 in k524 in k518 in k515 in k512 in k509 in compile-file in k504 in k501 in k497 in k266 in k263 in k260 in k257 in k254 */
static void C_ccall f_612(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_612,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_618,a[2]=((C_word)li17),tmp=(C_word)a,a+=3,tmp);
/* k191197 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a617 in a611 in a605 in a596 in k530 in k527 in k524 in k518 in k515 in k512 in k509 in compile-file in k504 in k501 in k497 in k266 in k263 in k260 in k257 in k254 */
static void C_ccall f_618(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_618,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* k602 in a596 in k530 in k527 in k524 in k518 in k515 in k512 in k509 in compile-file in k504 in k501 in k497 in k266 in k263 in k260 in k257 in k254 */
static void C_ccall f_604(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k533 in k530 in k527 in k524 in k518 in k515 in k512 in k509 in compile-file in k504 in k501 in k497 in k266 in k263 in k260 in k257 in k254 */
static void C_ccall f_535(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_535,2,t0,t1);}
if(C_truep(((C_word*)t0)[6])){
t2=(C_truep(((C_word*)t0)[5])?((C_word*)t0)[5]:((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_547,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_549,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word)li16),tmp=(C_word)a,a+=5,tmp);
/* call-with-current-continuation */
t5=*((C_word*)lf[38]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* a548 in k533 in k530 in k527 in k524 in k518 in k515 in k512 in k509 in compile-file in k504 in k501 in k497 in k266 in k263 in k260 in k257 in k254 */
static void C_ccall f_549(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_549,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_555,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word)li11),tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_570,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word)li15),tmp=(C_word)a,a+=6,tmp);
/* with-exception-handler */
((C_proc4)C_retrieve_proc(*((C_word*)lf[37]+1)))(4,*((C_word*)lf[37]+1),t1,t3,t4);}

/* a569 in a548 in k533 in k530 in k527 in k524 in k518 in k515 in k512 in k509 in compile-file in k504 in k501 in k497 in k266 in k263 in k260 in k257 in k254 */
static void C_ccall f_570(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_570,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_576,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word)li12),tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_582,a[2]=((C_word*)t0)[2],a[3]=((C_word)li14),tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a581 in a569 in a548 in k533 in k530 in k527 in k524 in k518 in k515 in k512 in k509 in compile-file in k504 in k501 in k497 in k266 in k263 in k260 in k257 in k254 */
static void C_ccall f_582(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_582r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_582r(t0,t1,t2);}}

static void C_ccall f_582r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_588,a[2]=t2,a[3]=((C_word)li13),tmp=(C_word)a,a+=4,tmp);
/* k216222 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a587 in a581 in a569 in a548 in k533 in k530 in k527 in k524 in k518 in k515 in k512 in k509 in compile-file in k504 in k501 in k497 in k266 in k263 in k260 in k257 in k254 */
static void C_ccall f_588(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_588,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a575 in a569 in a548 in k533 in k530 in k527 in k524 in k518 in k515 in k512 in k509 in compile-file in k504 in k501 in k497 in k266 in k263 in k260 in k257 in k254 */
static void C_ccall f_576(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_576,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_580,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 155  load-file */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[3]);}

/* k578 in a575 in a569 in a548 in k533 in k530 in k527 in k524 in k518 in k515 in k512 in k509 in compile-file in k504 in k501 in k497 in k266 in k263 in k260 in k257 in k254 */
static void C_ccall f_580(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* a554 in a548 in k533 in k530 in k527 in k524 in k518 in k515 in k512 in k509 in compile-file in k504 in k501 in k497 in k266 in k263 in k260 in k257 in k254 */
static void C_ccall f_555(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_555,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_561,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word)li10),tmp=(C_word)a,a+=5,tmp);
/* k216222 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a560 in a554 in a548 in k533 in k530 in k527 in k524 in k518 in k515 in k512 in k509 in compile-file in k504 in k501 in k497 in k266 in k263 in k260 in k257 in k254 */
static void C_ccall f_561(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_561,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_565,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 153  delete-file* */
((C_proc3)C_retrieve_proc(*((C_word*)lf[36]+1)))(3,*((C_word*)lf[36]+1),t2,((C_word*)t0)[2]);}

/* k563 in a560 in a554 in a548 in k533 in k530 in k527 in k524 in k518 in k515 in k512 in k509 in compile-file in k504 in k501 in k497 in k266 in k263 in k260 in k257 in k254 */
static void C_ccall f_565(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 154  abort */
((C_proc3)C_retrieve_proc(*((C_word*)lf[35]+1)))(3,*((C_word*)lf[35]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k545 in k533 in k530 in k527 in k524 in k518 in k515 in k512 in k509 in compile-file in k504 in k501 in k497 in k266 in k263 in k260 in k257 in k254 */
static void C_ccall f_547(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* qs in k266 in k263 in k260 in k257 in k254 */
static void C_ccall f_412(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_412r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_412r(t0,t1,t2,t3);}}

static void C_ccall f_412r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_416,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* utils.scm: 107  build-platform */
((C_proc2)C_retrieve_proc(*((C_word*)lf[30]+1)))(2,*((C_word*)lf[30]+1),t4);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_416(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k414 in qs in k266 in k263 in k260 in k257 in k254 */
static void C_ccall f_416(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_416,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[20]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(t1,lf[21]));
if(C_truep(t3)){
/* utils.scm: 110  string-append */
t4=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[3],lf[23],((C_word*)t0)[2],lf[24]);}
else{
t4=(C_word)C_i_string_length(((C_word*)t0)[2]);
t5=(C_word)C_eqp(t4,C_fix(0));
if(C_truep(t5)){
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,lf[25]);}
else{
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_441,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_443,a[2]=((C_word)li8),tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_466,a[2]=t7,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* string->list */
t9=*((C_word*)lf[29]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,((C_word*)t0)[2]);}}}

/* k464 in k414 in qs in k266 in k263 in k260 in k257 in k254 */
static void C_ccall f_466(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[28]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a442 in k414 in qs in k266 in k263 in k260 in k257 in k254 */
static void C_ccall f_443(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_443,3,t0,t1,t2);}
t3=(C_word)C_u_i_char_whitespacep(t2);
t4=(C_truep(t3)?t3:(C_word)C_i_memq(t2,lf[27]));
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_truep(t4)?(C_word)C_a_i_string(&a,2,C_make_character(92),t2):(C_word)C_a_i_string(&a,1,t2)));}

/* k439 in k414 in qs in k266 in k263 in k260 in k257 in k254 */
static void C_ccall f_441(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 114  string-concatenate */
((C_proc3)C_retrieve_proc(*((C_word*)lf[26]+1)))(3,*((C_word*)lf[26]+1),((C_word*)t0)[2],t1);}

/* read-all in k266 in k263 in k260 in k257 in k254 */
static void C_ccall f_369(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_369r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_369r(t0,t1,t2);}}

static void C_ccall f_369r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_373,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
t4=t3;
f_373(2,t4,*((C_word*)lf[9]+1));}
else{
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t4))){
t5=t3;
f_373(2,t5,(C_word)C_i_car(t2));}
else{
/* ##sys#error */
t5=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,lf[0],t2);}}}

/* k371 in read-all in k266 in k263 in k260 in k257 in k254 */
static void C_ccall f_373(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_373,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_379,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 100  port? */
t3=*((C_word*)lf[18]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}

/* k377 in k371 in read-all in k266 in k263 in k260 in k257 in k254 */
static void C_ccall f_379(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_379,2,t0,t1);}
if(C_truep(t1)){
/* read-string/port */
t2=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],C_SCHEME_FALSE,((C_word*)t0)[2]);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_387,a[2]=((C_word)li6),tmp=(C_word)a,a+=3,tmp);
/* utils.scm: 102  with-input-from-file */
t3=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}}

/* a386 in k377 in k371 in read-all in k266 in k263 in k260 in k257 in k254 */
static void C_ccall f_387(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_387,2,t0,t1);}
/* read-string/port */
t2=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,C_SCHEME_FALSE,*((C_word*)lf[9]+1));}

/* for-each-argv-line in k266 in k263 in k260 in k257 in k254 */
static void C_ccall f_324(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_324,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_349,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 88   command-line-arguments */
t4=*((C_word*)lf[15]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k347 in for-each-argv-line in k266 in k263 in k260 in k257 in k254 */
static void C_ccall f_349(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_349,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
/* utils.scm: 91   for-each-line */
t2=*((C_word*)lf[8]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_363,a[2]=((C_word*)t0)[2],a[3]=((C_word)li4),tmp=(C_word)a,a+=4,tmp);
/* for-each */
t3=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,t1);}}

/* a362 in k347 in for-each-argv-line in k266 in k263 in k260 in k257 in k254 */
static void C_ccall f_363(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_363,3,t0,t1,t2);}
t3=((C_word*)t0)[2];
if(C_truep((C_word)C_i_string_equal_p(t2,lf[12]))){
/* utils.scm: 86   for-each-line */
t4=*((C_word*)lf[8]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_342,a[2]=t3,a[3]=((C_word)li3),tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 87   with-input-from-file */
t5=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t2,t4);}}

/* a341 in a362 in k347 in for-each-argv-line in k266 in k263 in k260 in k257 in k254 */
static void C_ccall f_342(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_342,2,t0,t1);}
/* for-each-line */
t2=*((C_word*)lf[8]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* for-each-line in k266 in k263 in k260 in k257 in k254 */
static void C_ccall f_288(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr3rv,(void*)f_288r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_288r(t0,t1,t2,t3);}}

static void C_ccall f_288r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(6);
t4=(C_word)C_notvemptyp(t3);
t5=(C_truep(t4)?(C_word)C_i_vector_ref(t3,C_fix(0)):*((C_word*)lf[9]+1));
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_295,a[2]=t1,a[3]=t5,a[4]=((C_word*)t0)[2],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* utils.scm: 73   ##sys#check-port */
t7=*((C_word*)lf[10]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,t5,lf[8]);}

/* k293 in for-each-line in k266 in k263 in k260 in k257 in k254 */
static void C_ccall f_295(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_295,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_300,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t3,a[6]=((C_word)li1),tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_300(t5,((C_word*)t0)[2]);}

/* loop in k293 in for-each-line in k266 in k263 in k260 in k257 in k254 */
static void C_fcall f_300(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_300,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_304,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* utils.scm: 75   read-line */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k302 in loop in k293 in for-each-line in k266 in k263 in k260 in k257 in k254 */
static void C_ccall f_304(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_304,2,t0,t1);}
if(C_truep((C_word)C_eofp(t1))){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_313,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 77   proc */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}}

/* k311 in k302 in loop in k293 in for-each-line in k266 in k263 in k260 in k257 in k254 */
static void C_ccall f_313(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 78   loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_300(t2,((C_word*)t0)[2]);}

/* system* in k266 in k263 in k260 in k257 in k254 */
static void C_ccall f_270(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_270r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_270r(t0,t1,t2,t3);}}

static void C_ccall f_270r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_274,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_apply(5,0,t4,((C_word*)t0)[2],t2,t3);}

/* k272 in system* in k266 in k263 in k260 in k257 in k254 */
static void C_ccall f_274(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_274,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_277,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 62   system */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k275 in k272 in system* in k266 in k263 in k260 in k257 in k254 */
static void C_ccall f_277(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(t1,C_fix(0));
if(C_truep(t2)){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
/* utils.scm: 64   ##sys#error */
t3=*((C_word*)lf[5]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],lf[6],((C_word*)t0)[2],t1);}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[68] = {
{"toplevel:utils_scm",(void*)C_utils_toplevel},
{"f_256:utils_scm",(void*)f_256},
{"f_259:utils_scm",(void*)f_259},
{"f_262:utils_scm",(void*)f_262},
{"f_265:utils_scm",(void*)f_265},
{"f_268:utils_scm",(void*)f_268},
{"f_499:utils_scm",(void*)f_499},
{"f_503:utils_scm",(void*)f_503},
{"f_506:utils_scm",(void*)f_506},
{"f_507:utils_scm",(void*)f_507},
{"f_694:utils_scm",(void*)f_694},
{"f_511:utils_scm",(void*)f_511},
{"f_514:utils_scm",(void*)f_514},
{"f_691:utils_scm",(void*)f_691},
{"f_517:utils_scm",(void*)f_517},
{"f_689:utils_scm",(void*)f_689},
{"f_520:utils_scm",(void*)f_520},
{"f_526:utils_scm",(void*)f_526},
{"f_529:utils_scm",(void*)f_529},
{"f_651:utils_scm",(void*)f_651},
{"f_679:utils_scm",(void*)f_679},
{"f_675:utils_scm",(void*)f_675},
{"f_655:utils_scm",(void*)f_655},
{"f_659:utils_scm",(void*)f_659},
{"f_663:utils_scm",(void*)f_663},
{"f_532:utils_scm",(void*)f_532},
{"f_597:utils_scm",(void*)f_597},
{"f_606:utils_scm",(void*)f_606},
{"f_621:utils_scm",(void*)f_621},
{"f_633:utils_scm",(void*)f_633},
{"f_639:utils_scm",(void*)f_639},
{"f_627:utils_scm",(void*)f_627},
{"f_612:utils_scm",(void*)f_612},
{"f_618:utils_scm",(void*)f_618},
{"f_604:utils_scm",(void*)f_604},
{"f_535:utils_scm",(void*)f_535},
{"f_549:utils_scm",(void*)f_549},
{"f_570:utils_scm",(void*)f_570},
{"f_582:utils_scm",(void*)f_582},
{"f_588:utils_scm",(void*)f_588},
{"f_576:utils_scm",(void*)f_576},
{"f_580:utils_scm",(void*)f_580},
{"f_555:utils_scm",(void*)f_555},
{"f_561:utils_scm",(void*)f_561},
{"f_565:utils_scm",(void*)f_565},
{"f_547:utils_scm",(void*)f_547},
{"f_412:utils_scm",(void*)f_412},
{"f_416:utils_scm",(void*)f_416},
{"f_466:utils_scm",(void*)f_466},
{"f_443:utils_scm",(void*)f_443},
{"f_441:utils_scm",(void*)f_441},
{"f_369:utils_scm",(void*)f_369},
{"f_373:utils_scm",(void*)f_373},
{"f_379:utils_scm",(void*)f_379},
{"f_387:utils_scm",(void*)f_387},
{"f_324:utils_scm",(void*)f_324},
{"f_349:utils_scm",(void*)f_349},
{"f_363:utils_scm",(void*)f_363},
{"f_342:utils_scm",(void*)f_342},
{"f_288:utils_scm",(void*)f_288},
{"f_295:utils_scm",(void*)f_295},
{"f_300:utils_scm",(void*)f_300},
{"f_304:utils_scm",(void*)f_304},
{"f_313:utils_scm",(void*)f_313},
{"f_270:utils_scm",(void*)f_270},
{"f_274:utils_scm",(void*)f_274},
{"f_277:utils_scm",(void*)f_277},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
