/* Generated from chicken.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2009-09-21 21:28
   Version 4.0.1 - SVN rev. 14292
   linux-unix-gnu-x86 [ manyargs dload ptables applyhook ]
   compiled 2009-05-12 on galinha (Linux)
   command line: chicken.scm -no-trace -optimize-level 2 -include-path . -include-path ./ -no-lambda-info -inline -local -extend private-namespace.scm -output-file chicken.c
   used units: library eval data_structures ports extras srfi_69 chicken_syntax srfi_1 srfi_4 utils files support compiler optimizer scrutinizer driver platform backend srfi_69
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_69_toplevel)
C_externimport void C_ccall C_srfi_69_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_chicken_syntax_toplevel)
C_externimport void C_ccall C_chicken_syntax_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_1_toplevel)
C_externimport void C_ccall C_srfi_1_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_4_toplevel)
C_externimport void C_ccall C_srfi_4_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_utils_toplevel)
C_externimport void C_ccall C_utils_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_files_toplevel)
C_externimport void C_ccall C_files_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_support_toplevel)
C_externimport void C_ccall C_support_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_compiler_toplevel)
C_externimport void C_ccall C_compiler_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_optimizer_toplevel)
C_externimport void C_ccall C_optimizer_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_scrutinizer_toplevel)
C_externimport void C_ccall C_scrutinizer_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_driver_toplevel)
C_externimport void C_ccall C_driver_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_platform_toplevel)
C_externimport void C_ccall C_platform_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_backend_toplevel)
C_externimport void C_ccall C_backend_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_69_toplevel)
C_externimport void C_ccall C_srfi_69_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[91];
static double C_possibly_force_alignment;


C_noret_decl(C_toplevel)
C_externexport void C_ccall C_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_338)
static void C_ccall f_338(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_341)
static void C_ccall f_341(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_344)
static void C_ccall f_344(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_347)
static void C_ccall f_347(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_350)
static void C_ccall f_350(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_353)
static void C_ccall f_353(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_356)
static void C_ccall f_356(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_359)
static void C_ccall f_359(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_362)
static void C_ccall f_362(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_365)
static void C_ccall f_365(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_368)
static void C_ccall f_368(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_371)
static void C_ccall f_371(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_374)
static void C_ccall f_374(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_377)
static void C_ccall f_377(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_380)
static void C_ccall f_380(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_383)
static void C_ccall f_383(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_386)
static void C_ccall f_386(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_389)
static void C_ccall f_389(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_392)
static void C_ccall f_392(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_396)
static void C_ccall f_396(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1258)
static void C_ccall f_1258(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1265)
static void C_ccall f_1265(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1268)
static void C_fcall f_1268(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1271)
static void C_fcall f_1271(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1376)
static void C_ccall f_1376(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1389)
static void C_ccall f_1389(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1487)
static void C_ccall f_1487(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1485)
static void C_ccall f_1485(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1449)
static void C_ccall f_1449(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1473)
static void C_ccall f_1473(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1457)
static void C_ccall f_1457(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1461)
static void C_ccall f_1461(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1277)
static void C_ccall f_1277(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1287)
static void C_ccall f_1287(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1361)
static void C_ccall f_1361(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1341)
static void C_ccall f_1341(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1311)
static void C_fcall f_1311(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1307)
static void C_ccall f_1307(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1256)
static void C_ccall f_1256(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_399)
static void C_ccall f_399(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1117)
static void C_ccall f_1117(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1121)
static void C_ccall f_1121(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1133)
static void C_ccall f_1133(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1233)
static void C_ccall f_1233(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1136)
static void C_ccall f_1136(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1143)
static void C_ccall f_1143(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1213)
static void C_ccall f_1213(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1229)
static void C_ccall f_1229(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1193)
static void C_ccall f_1193(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1167)
static void C_fcall f_1167(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1163)
static void C_ccall f_1163(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1115)
static void C_ccall f_1115(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_402)
static void C_ccall f_402(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_967)
static void C_ccall f_967(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_971)
static void C_ccall f_971(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_980)
static void C_ccall f_980(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1103)
static void C_ccall f_1103(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1111)
static void C_ccall f_1111(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_983)
static void C_ccall f_983(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1079)
static void C_ccall f_1079(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_994)
static void C_ccall f_994(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1077)
static void C_ccall f_1077(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1004)
static void C_ccall f_1004(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1002)
static void C_ccall f_1002(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_965)
static void C_ccall f_965(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_405)
static void C_ccall f_405(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_899)
static void C_ccall f_899(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_903)
static void C_ccall f_903(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_906)
static void C_ccall f_906(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_913)
static void C_ccall f_913(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_937)
static void C_ccall f_937(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_957)
static void C_ccall f_957(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_953)
static void C_ccall f_953(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_897)
static void C_ccall f_897(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_408)
static void C_ccall f_408(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_825)
static void C_ccall f_825(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_829)
static void C_ccall f_829(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_832)
static void C_ccall f_832(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_842)
static void C_ccall f_842(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_858)
static void C_ccall f_858(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_878)
static void C_ccall f_878(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_823)
static void C_ccall f_823(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_411)
static void C_ccall f_411(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_796)
static void C_ccall f_796(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_800)
static void C_ccall f_800(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_815)
static void C_ccall f_815(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_794)
static void C_ccall f_794(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_414)
static void C_ccall f_414(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_417)
static void C_ccall f_417(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_787)
static void C_ccall f_787(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_783)
static void C_ccall f_783(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_775)
static void C_ccall f_775(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_765)
static void C_ccall f_765(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_773)
static void C_ccall f_773(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_421)
static void C_ccall f_421(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_550)
static void C_ccall f_550(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_562)
static void C_fcall f_562(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_755)
static void C_ccall f_755(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_748)
static void C_ccall f_748(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_711)
static void C_ccall f_711(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_657)
static void C_ccall f_657(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_674)
static void C_ccall f_674(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_660)
static void C_ccall f_660(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_584)
static void C_ccall f_584(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_637)
static void C_ccall f_637(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_627)
static void C_ccall f_627(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_587)
static void C_ccall f_587(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_554)
static void C_ccall f_554(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_557)
static void C_ccall f_557(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_538)
static void C_ccall f_538(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_545)
static void C_ccall f_545(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_530)
static void C_ccall f_530(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_536)
static void C_ccall f_536(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_533)
static void C_ccall f_533(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_423)
static void C_ccall f_423(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_429)
static void C_fcall f_429(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_464)
static void C_fcall f_464(C_word t0,C_word t1) C_noret;
C_noret_decl(f_490)
static void C_ccall f_490(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_486)
static void C_ccall f_486(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_443)
static void C_ccall f_443(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_1268)
static void C_fcall trf_1268(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1268(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1268(t0,t1);}

C_noret_decl(trf_1271)
static void C_fcall trf_1271(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1271(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1271(t0,t1);}

C_noret_decl(trf_1311)
static void C_fcall trf_1311(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1311(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1311(t0,t1);}

C_noret_decl(trf_1167)
static void C_fcall trf_1167(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1167(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1167(t0,t1);}

C_noret_decl(trf_562)
static void C_fcall trf_562(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_562(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_562(t0,t1,t2);}

C_noret_decl(trf_429)
static void C_fcall trf_429(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_429(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_429(t0,t1,t2,t3,t4);}

C_noret_decl(trf_464)
static void C_fcall trf_464(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_464(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_464(t0,t1);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_main_entry_point
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("toplevel"));
C_resize_stack(131072);
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(1108)){
C_save(t1);
C_rereclaim2(1108*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,91);
lf[0]=C_h_intern(&lf[0],33,"\003syschicken-ffi-macro-environment");
lf[1]=C_h_intern(&lf[1],27,"\010compilercompiler-arguments");
lf[2]=C_h_intern(&lf[2],29,"\010compilerprocess-command-line");
lf[3]=C_h_intern(&lf[3],7,"reverse");
lf[4]=C_h_intern(&lf[4],14,"string->symbol");
lf[5]=C_h_intern(&lf[5],9,"substring");
lf[6]=C_h_intern(&lf[6],25,"\003sysimplicit-exit-handler");
lf[7]=C_h_intern(&lf[7],17,"user-options-pass");
lf[8]=C_h_intern(&lf[8],4,"exit");
lf[9]=C_h_intern(&lf[9],19,"compile-source-file");
lf[10]=C_h_intern(&lf[10],14,"optimize-level");
lf[11]=C_h_intern(&lf[11],22,"optimize-leaf-routines");
lf[12]=C_h_intern(&lf[12],5,"cons*");
lf[13]=C_h_intern(&lf[13],5,"local");
lf[14]=C_h_intern(&lf[14],6,"inline");
lf[15]=C_h_intern(&lf[15],6,"unsafe");
lf[16]=C_h_intern(&lf[16],25,"\010compilercompiler-warning");
lf[17]=C_h_intern(&lf[17],5,"usage");
lf[18]=C_decode_literal(C_heaptop,"\376B\000\000\047invalid optimization level ~S - ignored");
lf[19]=C_h_intern(&lf[19],11,"debug-level");
lf[20]=C_h_intern(&lf[20],14,"no-lambda-info");
lf[21]=C_h_intern(&lf[21],8,"no-trace");
lf[22]=C_decode_literal(C_heaptop,"\376B\000\000 invalid debug level ~S - ignored");
lf[23]=C_h_intern(&lf[23],14,"benchmark-mode");
lf[24]=C_h_intern(&lf[24],17,"fixnum-arithmetic");
lf[25]=C_h_intern(&lf[25],18,"disable-interrupts");
lf[26]=C_h_intern(&lf[26],5,"block");
lf[27]=C_h_intern(&lf[27],11,"lambda-lift");
lf[28]=C_h_intern(&lf[28],31,"\010compilervalid-compiler-options");
lf[29]=C_h_intern(&lf[29],45,"\010compilervalid-compiler-options-with-argument");
lf[30]=C_h_intern(&lf[30],4,"quit");
lf[31]=C_decode_literal(C_heaptop,"\376B\000\000 missing argument to `-~s\047 option");
lf[32]=C_decode_literal(C_heaptop,"\376B\000\000&invalid compiler option `~a\047 - ignored");
lf[33]=C_h_intern(&lf[33],4,"conc");
lf[34]=C_decode_literal(C_heaptop,"\376B\000\000\001-");
lf[35]=C_h_intern(&lf[35],6,"append");
lf[36]=C_h_intern(&lf[36],4,"argv");
lf[37]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[38]=C_h_intern(&lf[38],6,"remove");
lf[39]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[40]=C_h_intern(&lf[40],12,"string-split");
lf[41]=C_h_intern(&lf[41],24,"get-environment-variable");
lf[42]=C_decode_literal(C_heaptop,"\376B\000\000\017CHICKEN_OPTIONS");
lf[43]=C_h_intern(&lf[43],16,"\003sysmacro-subset");
lf[44]=C_h_intern(&lf[44],28,"\003sysextend-macro-environment");
lf[45]=C_h_intern(&lf[45],15,"foreign-declare");
lf[46]=C_h_intern(&lf[46],12,"\004coredeclare");
lf[47]=C_h_intern(&lf[47],10,"\003sysappend");
lf[48]=C_h_intern(&lf[48],16,"\003syscheck-syntax");
lf[49]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\006string\376\377\001\000\000\000\000");
lf[50]=C_h_intern(&lf[50],18,"\003syser-transformer");
lf[51]=C_h_intern(&lf[51],13,"foreign-value");
lf[52]=C_h_intern(&lf[52],14,"symbol->string");
lf[53]=C_h_intern(&lf[53],12,"syntax-error");
lf[54]=C_decode_literal(C_heaptop,"\376B\000\000*bad argument type - not a string or symbol");
lf[55]=C_h_intern(&lf[55],23,"define-foreign-variable");
lf[56]=C_h_intern(&lf[56],5,"begin");
lf[57]=C_h_intern(&lf[57],6,"gensym");
lf[58]=C_h_intern(&lf[58],5,"code_");
lf[59]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[60]=C_h_intern(&lf[60],12,"foreign-code");
lf[61]=C_h_intern(&lf[61],11,"\004coreinline");
lf[62]=C_h_intern(&lf[62],7,"sprintf");
lf[63]=C_decode_literal(C_heaptop,"\376B\000\0007static C_word ~A() { ~A\012; return C_SCHEME_UNDEFINED; }\012");
lf[64]=C_h_intern(&lf[64],18,"string-intersperse");
lf[65]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[66]=C_h_intern(&lf[66],7,"declare");
lf[67]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\006string\376\377\001\000\000\000\000");
lf[68]=C_h_intern(&lf[68],12,"let-location");
lf[69]=C_h_intern(&lf[69],17,"\004corelet-location");
lf[70]=C_h_intern(&lf[70],10,"fold-right");
lf[71]=C_h_intern(&lf[71],10,"append-map");
lf[72]=C_h_intern(&lf[72],7,"\003sysmap");
lf[73]=C_h_intern(&lf[73],3,"let");
lf[74]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\000\000\000\002\376\003\000\000\002\376\001\000\000\010variable\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\003\376\001\000\000\001_\376\377\001\000\000\000\000\376\377\001\000\000\000\001\376\377\001\000\000"
"\000\000\376\001\000\000\001_");
lf[75]=C_h_intern(&lf[75],15,"define-location");
lf[76]=C_h_intern(&lf[76],9,"\004coreset!");
lf[77]=C_h_intern(&lf[77],24,"define-external-variable");
lf[78]=C_h_intern(&lf[78],9,"\003syserror");
lf[79]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[80]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\010variable\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\003\376\001\000\000\001_\376\377\001\000\000\000\000\376\377\001\000\000\000\001");
lf[81]=C_h_intern(&lf[81],15,"define-external");
lf[82]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\003\376\001\000\000\001_\376\377\001\000\000\000\000\376\377\001\000\000\000\001");
lf[83]=C_h_intern(&lf[83],5,"quote");
lf[84]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[85]=C_h_intern(&lf[85],29,"\004coreforeign-callback-wrapper");
lf[86]=C_h_intern(&lf[86],6,"lambda");
lf[87]=C_h_intern(&lf[87],6,"define");
lf[88]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006string\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\000\000\000\002\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\006symbol\376\377\016\376\377\001\000\000\000\000\376"
"\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[89]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\000\000\000\002\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\006symbol\376\377\016\376\377\001\000\000\000\000\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376"
"\001\000\000\001_\376\377\001\000\000\000\001");
lf[90]=C_h_intern(&lf[90],21,"\003sysmacro-environment");
C_register_lf2(lf,91,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_338,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k336 */
static void C_ccall f_338(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_338,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_341,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k339 in k336 */
static void C_ccall f_341(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_341,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_344,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k342 in k339 in k336 */
static void C_ccall f_344(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_344,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_347,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k345 in k342 in k339 in k336 */
static void C_ccall f_347(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_347,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_350,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k348 in k345 in k342 in k339 in k336 */
static void C_ccall f_350(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_350,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_353,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k351 in k348 in k345 in k342 in k339 in k336 */
static void C_ccall f_353(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_353,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_356,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_chicken_syntax_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k354 in k351 in k348 in k345 in k342 in k339 in k336 */
static void C_ccall f_356(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_356,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_359,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_1_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 */
static void C_ccall f_359(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_359,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_362,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_4_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 */
static void C_ccall f_362(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_362,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_365,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_utils_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 */
static void C_ccall f_365(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_365,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_368,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_files_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k366 in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 */
static void C_ccall f_368(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_368,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_371,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_support_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 */
static void C_ccall f_371(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_371,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_374,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_compiler_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 */
static void C_ccall f_374(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_374,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_377,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_optimizer_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 */
static void C_ccall f_377(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_377,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_380,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_scrutinizer_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 */
static void C_ccall f_380(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_380,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_383,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_driver_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 */
static void C_ccall f_383(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_383,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_386,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_platform_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 */
static void C_ccall f_386(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_386,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_389,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_backend_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 */
static void C_ccall f_389(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_389,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_392,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 */
static void C_ccall f_392(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_392,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_396,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#macro-environment */
((C_proc2)C_retrieve_symbol_proc(lf[90]))(2,*((C_word*)lf[90]+1),t2);}

/* k394 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 */
static void C_ccall f_396(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_396,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_399,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1256,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1258,tmp=(C_word)a,a+=2,tmp);
/* ##sys#er-transformer */
((C_proc3)C_retrieve_symbol_proc(lf[50]))(3,*((C_word*)lf[50]+1),t3,t4);}

/* a1257 in k394 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 */
static void C_ccall f_1258(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1258,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_cdr(t2);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1265,a[2]=t3,a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* r55 */
t7=t3;
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,lf[83]);}

/* k1263 in a1257 in k394 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 */
static void C_ccall f_1265(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1265,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1268,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
t3=(C_word)C_i_car(((C_word*)t0)[4]);
t4=t2;
f_1268(t4,(C_word)C_i_stringp(t3));}
else{
t3=t2;
f_1268(t3,C_SCHEME_FALSE);}}

/* k1266 in k1263 in a1257 in k394 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 */
static void C_fcall f_1268(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1268,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1271,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=t1;
if(C_truep(t3)){
t4=t2;
f_1271(t4,C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
t4=(C_word)C_i_car(((C_word*)t0)[4]);
t5=t2;
f_1271(t5,(C_word)C_i_symbolp(t4));}
else{
t4=t2;
f_1271(t4,C_SCHEME_FALSE);}}}

/* k1269 in k1266 in k1263 in a1257 in k394 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 */
static void C_fcall f_1271(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1271,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1277,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* ##sys#check-syntax */
((C_proc5)C_retrieve_symbol_proc(lf[48]))(5,*((C_word*)lf[48]+1),t2,lf[81],((C_word*)t0)[5],lf[82]);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1376,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[2])){
/* ##sys#check-syntax */
((C_proc5)C_retrieve_symbol_proc(lf[48]))(5,*((C_word*)lf[48]+1),t2,lf[81],((C_word*)t0)[5],lf[88]);}
else{
/* ##sys#check-syntax */
((C_proc5)C_retrieve_symbol_proc(lf[48]))(5,*((C_word*)lf[48]+1),t2,lf[81],((C_word*)t0)[5],lf[89]);}}}

/* k1374 in k1269 in k1266 in k1263 in a1257 in k394 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 */
static void C_ccall f_1376(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1376,2,t0,t1);}
t2=(C_truep(((C_word*)t0)[5])?(C_word)C_i_cadr(((C_word*)t0)[4]):(C_word)C_i_car(((C_word*)t0)[4]));
t3=(C_word)C_i_cdr(t2);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1389,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* r55 */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[87]);}

/* k1387 in k1374 in k1269 in k1266 in k1263 in a1257 in k394 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 */
static void C_ccall f_1389(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1389,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[7]);
t3=(C_word)C_i_car(((C_word*)t0)[7]);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[83],t4);
t6=(C_truep(((C_word*)t0)[6])?(C_word)C_i_car(((C_word*)t0)[5]):lf[84]);
t7=(C_truep(((C_word*)t0)[6])?(C_word)C_i_caddr(((C_word*)t0)[5]):(C_word)C_i_cadr(((C_word*)t0)[5]));
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,lf[83],t8);
t10=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_1485,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[4],a[8]=t2,a[9]=t5,a[10]=t6,a[11]=t9,tmp=(C_word)a,a+=12,tmp);
t11=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1487,tmp=(C_word)a,a+=2,tmp);
/* map */
t12=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t10,t11,((C_word*)t0)[3]);}

/* a1486 in k1387 in k1374 in k1269 in k1266 in k1263 in a1257 in k394 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 */
static void C_ccall f_1487(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1487,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_car(t2));}

/* k1483 in k1387 in k1374 in k1269 in k1266 in k1263 in a1257 in k394 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 */
static void C_ccall f_1485(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1485,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[83],t2);
t4=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_1449,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=t3,tmp=(C_word)a,a+=12,tmp);
/* r55 */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[86]);}

/* k1447 in k1483 in k1387 in k1374 in k1269 in k1266 in k1263 in a1257 in k394 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 */
static void C_ccall f_1449(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1449,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_1457,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=t1,tmp=(C_word)a,a+=12,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1473,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a1472 in k1447 in k1483 in k1387 in k1374 in k1269 in k1266 in k1263 in a1257 in k394 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 */
static void C_ccall f_1473(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1473,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_cadr(t2));}

/* k1455 in k1447 in k1483 in k1387 in k1374 in k1269 in k1266 in k1263 in a1257 in k394 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 */
static void C_ccall f_1457(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1457,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1461,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=t1,tmp=(C_word)a,a+=11,tmp);
t3=(C_truep(((C_word*)t0)[3])?(C_word)C_i_cdddr(((C_word*)t0)[2]):(C_word)C_i_cddr(((C_word*)t0)[2]));
/* ##sys#append */
t4=*((C_word*)lf[47]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}

/* k1459 in k1455 in k1447 in k1483 in k1387 in k1374 in k1269 in k1266 in k1263 in a1257 in k394 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 */
static void C_ccall f_1461(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1461,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t5);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t6);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t7);
t9=(C_word)C_a_i_cons(&a,2,lf[85],t8);
t10=(C_word)C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST);
t11=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t10);
t12=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t11));}

/* k1275 in k1269 in k1266 in k1263 in a1257 in k394 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 */
static void C_ccall f_1277(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1277,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1287,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* r55 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[56]);}

/* k1285 in k1275 in k1269 in k1266 in k1263 in a1257 in k394 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 */
static void C_ccall f_1287(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1287,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1361,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* r55 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[55]);}

/* k1359 in k1285 in k1275 in k1269 in k1266 in k1263 in a1257 in k394 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 */
static void C_ccall f_1361(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1361,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[6]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t3);
t5=(C_word)C_a_i_cons(&a,2,t1,t4);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1341,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t5,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* r55 */
t7=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,lf[77]);}

/* k1339 in k1359 in k1285 in k1275 in k1269 in k1266 in k1263 in a1257 in k394 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 */
static void C_ccall f_1341(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1341,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[6]);
t3=(C_word)C_a_i_cons(&a,2,C_SCHEME_TRUE,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,t2,t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t4);
t6=(C_word)C_a_i_cons(&a,2,t1,t5);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1307,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t6,tmp=(C_word)a,a+=6,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1311,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
t9=(C_word)C_i_cddr(((C_word*)t0)[6]);
if(C_truep((C_word)C_i_pairp(t9))){
t10=(C_word)C_i_caddr(((C_word*)t0)[6]);
t11=(C_word)C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t11);
t13=(C_word)C_a_i_cons(&a,2,lf[76],t12);
t14=t8;
f_1311(t14,(C_word)C_a_i_cons(&a,2,t13,C_SCHEME_END_OF_LIST));}
else{
t10=t8;
f_1311(t10,C_SCHEME_END_OF_LIST);}}

/* k1309 in k1339 in k1359 in k1285 in k1275 in k1269 in k1266 in k1263 in a1257 in k394 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 */
static void C_fcall f_1311(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[47]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k1305 in k1339 in k1359 in k1285 in k1275 in k1269 in k1266 in k1263 in a1257 in k394 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 */
static void C_ccall f_1307(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1307,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* k1254 in k394 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 */
static void C_ccall f_1256(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#extend-macro-environment */
((C_proc5)C_retrieve_symbol_proc(lf[44]))(5,*((C_word*)lf[44]+1),((C_word*)t0)[2],lf[81],C_SCHEME_END_OF_LIST,t1);}

/* k397 in k394 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 */
static void C_ccall f_399(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_399,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_402,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1115,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1117,tmp=(C_word)a,a+=2,tmp);
/* ##sys#er-transformer */
((C_proc3)C_retrieve_symbol_proc(lf[50]))(3,*((C_word*)lf[50]+1),t3,t4);}

/* a1116 in k397 in k394 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 */
static void C_ccall f_1117(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1117,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1121,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* ##sys#check-syntax */
((C_proc5)C_retrieve_symbol_proc(lf[48]))(5,*((C_word*)lf[48]+1),t5,lf[75],t2,lf[80]);}

/* k1119 in a1116 in k397 in k394 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 */
static void C_ccall f_1121(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1121,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_caddr(((C_word*)t0)[4]);
t4=(C_word)C_i_cdddr(((C_word*)t0)[4]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1133,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_1133(2,t6,C_SCHEME_FALSE);}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_1133(2,t7,(C_word)C_i_car(t4));}
else{
/* ##sys#error */
t7=*((C_word*)lf[78]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[79],t4);}}}

/* k1131 in k1119 in a1116 in k397 in k394 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 */
static void C_ccall f_1133(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1133,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1136,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1233,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* gensym */
((C_proc2)C_retrieve_symbol_proc(lf[57]))(2,*((C_word*)lf[57]+1),t3);}

/* k1231 in k1131 in k1119 in a1116 in k397 in k394 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 */
static void C_ccall f_1233(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* r108 */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1134 in k1131 in k1119 in a1116 in k397 in k394 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 */
static void C_ccall f_1136(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1136,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1143,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* r108 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[56]);}

/* k1141 in k1134 in k1131 in k1119 in a1116 in k397 in k394 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 */
static void C_ccall f_1143(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1143,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1213,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* r108 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[55]);}

/* k1211 in k1141 in k1134 in k1131 in k1119 in a1116 in k397 in k394 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 */
static void C_ccall f_1213(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1213,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1229,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* symbol->string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[52]+1)))(3,*((C_word*)lf[52]+1),t2,((C_word*)t0)[6]);}

/* k1227 in k1211 in k1141 in k1134 in k1131 in k1119 in a1116 in k397 in k394 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 */
static void C_ccall f_1229(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1229,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t4);
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1193,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t5,a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
/* r108 */
t7=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,lf[77]);}

/* k1191 in k1227 in k1211 in k1141 in k1134 in k1131 in k1119 in a1116 in k397 in k394 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 */
static void C_ccall f_1193(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1193,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t4);
t6=(C_word)C_a_i_cons(&a,2,t1,t5);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1163,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t6,tmp=(C_word)a,a+=6,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1167,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t9=(C_word)C_i_car(((C_word*)t0)[2]);
t10=(C_word)C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST);
t11=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t10);
t12=(C_word)C_a_i_cons(&a,2,lf[76],t11);
t13=t8;
f_1167(t13,(C_word)C_a_i_cons(&a,2,t12,C_SCHEME_END_OF_LIST));}
else{
t9=t8;
f_1167(t9,C_SCHEME_END_OF_LIST);}}

/* k1165 in k1191 in k1227 in k1211 in k1141 in k1134 in k1131 in k1119 in a1116 in k397 in k394 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 */
static void C_fcall f_1167(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[47]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k1161 in k1191 in k1227 in k1211 in k1141 in k1134 in k1131 in k1119 in a1116 in k397 in k394 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 */
static void C_ccall f_1163(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1163,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* k1113 in k397 in k394 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 */
static void C_ccall f_1115(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#extend-macro-environment */
((C_proc5)C_retrieve_symbol_proc(lf[44]))(5,*((C_word*)lf[44]+1),((C_word*)t0)[2],lf[75],C_SCHEME_END_OF_LIST,t1);}

/* k400 in k397 in k394 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 */
static void C_ccall f_402(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_402,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_405,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_965,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_967,tmp=(C_word)a,a+=2,tmp);
/* ##sys#er-transformer */
((C_proc3)C_retrieve_symbol_proc(lf[50]))(3,*((C_word*)lf[50]+1),t3,t4);}

/* a966 in k400 in k397 in k394 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 */
static void C_ccall f_967(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_967,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_971,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* ##sys#check-syntax */
((C_proc5)C_retrieve_symbol_proc(lf[48]))(5,*((C_word*)lf[48]+1),t5,lf[68],t2,lf[74]);}

/* k969 in a966 in k400 in k397 in k394 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 */
static void C_ccall f_971(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_971,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_cddr(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_980,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t2,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* r135 */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[73]);}

/* k978 in k969 in a966 in k400 in k397 in k394 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 */
static void C_ccall f_980(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_980,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_983,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1103,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* map */
t4=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[4]);}

/* a1102 in k978 in k969 in a966 in k400 in k397 in k394 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 */
static void C_ccall f_1103(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1103,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1111,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* gensym */
((C_proc2)C_retrieve_symbol_proc(lf[57]))(2,*((C_word*)lf[57]+1),t3);}

/* k1109 in a1102 in k978 in k969 in a966 in k400 in k397 in k394 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 */
static void C_ccall f_1111(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* r135 */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k981 in k978 in k969 in a966 in k400 in k397 in k394 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 */
static void C_ccall f_983(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_983,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_994,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1079,tmp=(C_word)a,a+=2,tmp);
/* append-map */
((C_proc5)C_retrieve_symbol_proc(lf[71]))(5,*((C_word*)lf[71]+1),t2,t3,((C_word*)t0)[3],t1);}

/* a1078 in k981 in k978 in k969 in a966 in k400 in k397 in k394 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 */
static void C_ccall f_1079(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1079,4,t0,t1,t2,t3);}
t4=(C_word)C_i_cddr(t2);
if(C_truep((C_word)C_i_pairp(t4))){
t5=(C_word)C_i_cddr(t2);
t6=(C_word)C_a_i_cons(&a,2,t3,t5);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_list(&a,1,t6));}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_END_OF_LIST);}}

/* k992 in k981 in k978 in k969 in a966 in k400 in k397 in k394 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 */
static void C_ccall f_994(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_994,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1002,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1004,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1077,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* ##sys#append */
t5=*((C_word*)lf[47]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k1075 in k992 in k981 in k978 in k969 in a966 in k400 in k397 in k394 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 */
static void C_ccall f_1077(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1077,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t2);
/* fold-right */
((C_proc6)C_retrieve_symbol_proc(lf[70]))(6,*((C_word*)lf[70]+1),((C_word*)t0)[5],((C_word*)t0)[4],t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a1003 in k992 in k981 in k978 in k969 in a966 in k400 in k397 in k394 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 */
static void C_ccall f_1004(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[15],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1004,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_length(t2);
t6=(C_word)C_eqp(C_fix(3),t5);
if(C_truep(t6)){
t7=(C_word)C_i_car(t2);
t8=(C_word)C_i_cadr(t2);
t9=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,t3,t9);
t11=(C_word)C_a_i_cons(&a,2,t8,t10);
t12=(C_word)C_a_i_cons(&a,2,t7,t11);
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,(C_word)C_a_i_cons(&a,2,lf[69],t12));}
else{
t7=(C_word)C_i_car(t2);
t8=(C_word)C_i_cadr(t2);
t9=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,t8,t9);
t11=(C_word)C_a_i_cons(&a,2,t7,t10);
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,(C_word)C_a_i_cons(&a,2,lf[69],t11));}}

/* k1000 in k992 in k981 in k978 in k969 in a966 in k400 in k397 in k394 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 */
static void C_ccall f_1002(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1002,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* k963 in k400 in k397 in k394 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 */
static void C_ccall f_965(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#extend-macro-environment */
((C_proc5)C_retrieve_symbol_proc(lf[44]))(5,*((C_word*)lf[44]+1),((C_word*)t0)[2],lf[68],C_SCHEME_END_OF_LIST,t1);}

/* k403 in k400 in k397 in k394 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 */
static void C_ccall f_405(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_405,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_408,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_897,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_899,tmp=(C_word)a,a+=2,tmp);
/* ##sys#er-transformer */
((C_proc3)C_retrieve_symbol_proc(lf[50]))(3,*((C_word*)lf[50]+1),t3,t4);}

/* a898 in k403 in k400 in k397 in k394 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 */
static void C_ccall f_899(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_899,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_903,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* ##sys#check-syntax */
((C_proc5)C_retrieve_symbol_proc(lf[48]))(5,*((C_word*)lf[48]+1),t5,lf[60],t2,lf[67]);}

/* k901 in a898 in k403 in k400 in k397 in k394 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 */
static void C_ccall f_903(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_903,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_906,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* gensym */
((C_proc3)C_retrieve_symbol_proc(lf[57]))(3,*((C_word*)lf[57]+1),t2,lf[58]);}

/* k904 in k901 in a898 in k403 in k400 in k397 in k394 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 */
static void C_ccall f_906(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_906,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_913,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* r175 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[56]);}

/* k911 in k904 in k901 in a898 in k403 in k400 in k397 in k394 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 */
static void C_ccall f_913(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_913,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_937,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* r175 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[66]);}

/* k935 in k911 in k904 in k901 in a898 in k403 in k400 in k397 in k394 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 */
static void C_ccall f_937(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_937,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_953,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_957,a[2]=((C_word*)t0)[5],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* string-intersperse */
((C_proc4)C_retrieve_symbol_proc(lf[64]))(4,*((C_word*)lf[64]+1),t3,t4,lf[65]);}

/* k955 in k935 in k911 in k904 in k901 in a898 in k403 in k400 in k397 in k394 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 */
static void C_ccall f_957(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* sprintf */
((C_proc5)C_retrieve_symbol_proc(lf[62]))(5,*((C_word*)lf[62]+1),((C_word*)t0)[3],lf[63],((C_word*)t0)[2],t1);}

/* k951 in k935 in k911 in k904 in k901 in a898 in k403 in k400 in k397 in k394 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 */
static void C_ccall f_953(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_953,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[45],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,lf[61],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,t5,t8);
t10=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t9));}

/* k895 in k403 in k400 in k397 in k394 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 */
static void C_ccall f_897(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#extend-macro-environment */
((C_proc5)C_retrieve_symbol_proc(lf[44]))(5,*((C_word*)lf[44]+1),((C_word*)t0)[2],lf[60],C_SCHEME_END_OF_LIST,t1);}

/* k406 in k403 in k400 in k397 in k394 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 */
static void C_ccall f_408(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_408,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_411,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_823,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_825,tmp=(C_word)a,a+=2,tmp);
/* ##sys#er-transformer */
((C_proc3)C_retrieve_symbol_proc(lf[50]))(3,*((C_word*)lf[50]+1),t3,t4);}

/* a824 in k406 in k403 in k400 in k397 in k394 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 */
static void C_ccall f_825(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_825,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_829,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* ##sys#check-syntax */
((C_proc5)C_retrieve_symbol_proc(lf[48]))(5,*((C_word*)lf[48]+1),t5,lf[51],t2,lf[59]);}

/* k827 in a824 in k406 in k403 in k400 in k397 in k394 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 */
static void C_ccall f_829(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_829,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_832,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* gensym */
((C_proc3)C_retrieve_symbol_proc(lf[57]))(3,*((C_word*)lf[57]+1),t2,lf[58]);}

/* k830 in k827 in a824 in k406 in k403 in k400 in k397 in k394 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 */
static void C_ccall f_832(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_832,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_842,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* r186 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[56]);}

/* k840 in k830 in k827 in a824 in k406 in k403 in k400 in k397 in k394 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 */
static void C_ccall f_842(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_842,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_858,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* r186 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[55]);}

/* k856 in k840 in k830 in k827 in a824 in k406 in k403 in k400 in k397 in k394 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 */
static void C_ccall f_858(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_858,2,t0,t1);}
t2=(C_word)C_i_caddr(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_878,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_stringp(((C_word*)t0)[2]))){
t4=t3;
f_878(2,t4,((C_word*)t0)[2]);}
else{
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[2]))){
/* symbol->string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[52]+1)))(3,*((C_word*)lf[52]+1),t3,((C_word*)t0)[2]);}
else{
/* syntax-error */
((C_proc5)C_retrieve_symbol_proc(lf[53]))(5,*((C_word*)lf[53]+1),t3,lf[51],lf[54],((C_word*)t0)[2]);}}}

/* k876 in k856 in k840 in k830 in k827 in a824 in k406 in k403 in k400 in k397 in k394 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 */
static void C_ccall f_878(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_878,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,t5,t6);
t8=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t7));}

/* k821 in k406 in k403 in k400 in k397 in k394 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 */
static void C_ccall f_823(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#extend-macro-environment */
((C_proc5)C_retrieve_symbol_proc(lf[44]))(5,*((C_word*)lf[44]+1),((C_word*)t0)[2],lf[51],C_SCHEME_END_OF_LIST,t1);}

/* k409 in k406 in k403 in k400 in k397 in k394 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 */
static void C_ccall f_411(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_411,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_414,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_794,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_796,tmp=(C_word)a,a+=2,tmp);
/* ##sys#er-transformer */
((C_proc3)C_retrieve_symbol_proc(lf[50]))(3,*((C_word*)lf[50]+1),t3,t4);}

/* a795 in k409 in k406 in k403 in k400 in k397 in k394 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 */
static void C_ccall f_796(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_796,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_800,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* ##sys#check-syntax */
((C_proc5)C_retrieve_symbol_proc(lf[48]))(5,*((C_word*)lf[48]+1),t5,lf[45],t2,lf[49]);}

/* k798 in a795 in k409 in k406 in k403 in k400 in k397 in k394 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 */
static void C_ccall f_800(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_800,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_815,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* ##sys#append */
t4=*((C_word*)lf[47]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}

/* k813 in k798 in a795 in k409 in k406 in k403 in k400 in k397 in k394 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 */
static void C_ccall f_815(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_815,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[45],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[46],t3));}

/* k792 in k409 in k406 in k403 in k400 in k397 in k394 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 */
static void C_ccall f_794(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#extend-macro-environment */
((C_proc5)C_retrieve_symbol_proc(lf[44]))(5,*((C_word*)lf[44]+1),((C_word*)t0)[2],lf[45],C_SCHEME_END_OF_LIST,t1);}

/* k412 in k409 in k406 in k403 in k400 in k397 in k394 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 */
static void C_ccall f_414(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_414,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_417,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* ##sys#macro-subset */
((C_proc3)C_retrieve_symbol_proc(lf[43]))(3,*((C_word*)lf[43]+1),t2,((C_word*)t0)[2]);}

/* k415 in k412 in k409 in k406 in k403 in k400 in k397 in k394 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 */
static void C_ccall f_417(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_417,2,t0,t1);}
t2=C_mutate((C_word*)lf[0]+1 /* (set! chicken-ffi-macro-environment ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_421,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_765,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_775,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_783,a[2]=t5,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_787,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* chicken.scm: 47   get-environment-variable */
((C_proc3)C_retrieve_symbol_proc(lf[41]))(3,*((C_word*)lf[41]+1),t7,lf[42]);}

/* k785 in k415 in k412 in k409 in k406 in k403 in k400 in k397 in k394 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 */
static void C_ccall f_787(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?t1:lf[39]);
/* chicken.scm: 47   string-split */
((C_proc3)C_retrieve_symbol_proc(lf[40]))(3,*((C_word*)lf[40]+1),((C_word*)t0)[2],t2);}

/* k781 in k415 in k412 in k409 in k406 in k403 in k400 in k397 in k394 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 */
static void C_ccall f_783(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 45   remove */
((C_proc4)C_retrieve_symbol_proc(lf[38]))(4,*((C_word*)lf[38]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a774 in k415 in k412 in k409 in k406 in k403 in k400 in k397 in k394 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 */
static void C_ccall f_775(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_775,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_string_equal_p(t2,lf[37]));}

/* k763 in k415 in k412 in k409 in k406 in k403 in k400 in k397 in k394 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 */
static void C_ccall f_765(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_765,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_773,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 48   argv */
((C_proc2)C_retrieve_symbol_proc(lf[36]))(2,*((C_word*)lf[36]+1),t2);}

/* k771 in k763 in k415 in k412 in k409 in k406 in k403 in k400 in k397 in k394 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 */
static void C_ccall f_773(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(t1);
/* chicken.scm: 44   append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[35]+1)))(4,*((C_word*)lf[35]+1),((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k419 in k415 in k412 in k409 in k406 in k403 in k400 in k397 in k394 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 */
static void C_ccall f_421(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_421,2,t0,t1);}
t2=C_mutate((C_word*)lf[1]+1 /* (set! compiler-arguments ...) */,t1);
t3=C_mutate((C_word*)lf[2]+1 /* (set! process-command-line ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_423,tmp=(C_word)a,a+=2,tmp));
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_530,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_538,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_550,tmp=(C_word)a,a+=2,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t4,t5,t6);}

/* a549 in k419 in k415 in k412 in k409 in k406 in k403 in k400 in k397 in k394 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 */
static void C_ccall f_550(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_550,4,t0,t1,t2,t3);}
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_554,a[2]=t4,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_562,a[2]=t4,a[3]=t7,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_562(t9,t5,((C_word*)t4)[1]);}

/* loop in a549 in k419 in k415 in k412 in k409 in k406 in k403 in k400 in k397 in k394 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 */
static void C_fcall f_562(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word *a;
loop:
a=C_alloc(8);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_562,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=(C_word)C_eqp(lf[10],t3);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_584,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_i_car(t4);
/* chicken.scm: 81   string->number */
C_string_to_number(3,0,t6,t7);}
else{
t6=(C_word)C_eqp(lf[19],t3);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_657,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t8=(C_word)C_i_car(t4);
/* chicken.scm: 97   string->number */
C_string_to_number(3,0,t7,t8);}
else{
t7=(C_word)C_eqp(lf[23],t3);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_711,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 106  cons* */
((C_proc12)C_retrieve_symbol_proc(lf[12]))(12,*((C_word*)lf[12]+1),t8,lf[24],lf[25],lf[21],lf[15],lf[11],lf[26],lf[27],lf[20],lf[14],((C_word*)((C_word*)t0)[2])[1]);}
else{
if(C_truep((C_word)C_i_memq(t3,C_retrieve(lf[28])))){
/* chicken.scm: 111  loop */
t17=t1;
t18=t4;
t1=t17;
t2=t18;
goto loop;}
else{
if(C_truep((C_word)C_i_memq(t3,C_retrieve(lf[29])))){
if(C_truep((C_word)C_i_pairp(t4))){
t8=(C_word)C_i_cdr(t4);
/* chicken.scm: 114  loop */
t17=t1;
t18=t8;
t1=t17;
t2=t18;
goto loop;}
else{
/* chicken.scm: 115  quit */
((C_proc4)C_retrieve_symbol_proc(lf[30]))(4,*((C_word*)lf[30]+1),t1,lf[31],t3);}}
else{
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_748,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_755,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_stringp(t3))){
t10=t9;
f_755(2,t10,t3);}
else{
/* chicken.scm: 119  conc */
((C_proc4)C_retrieve_symbol_proc(lf[33]))(4,*((C_word*)lf[33]+1),t9,lf[34],t3);}}}}}}}}

/* k753 in loop in a549 in k419 in k415 in k412 in k409 in k406 in k403 in k400 in k397 in k394 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 */
static void C_ccall f_755(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 117  compiler-warning */
((C_proc5)C_retrieve_symbol_proc(lf[16]))(5,*((C_word*)lf[16]+1),((C_word*)t0)[2],lf[17],lf[32],t1);}

/* k746 in loop in a549 in k419 in k415 in k412 in k409 in k406 in k403 in k400 in k397 in k394 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 */
static void C_ccall f_748(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 120  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_562(t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k709 in loop in a549 in k419 in k415 in k412 in k409 in k406 in k403 in k400 in k397 in k394 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 */
static void C_ccall f_711(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
/* chicken.scm: 110  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_562(t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k655 in loop in a549 in k419 in k415 in k412 in k409 in k406 in k403 in k400 in k397 in k394 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 */
static void C_ccall f_657(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_657,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_660,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
switch(t1){
case C_fix(0):
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_674,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 99   cons* */
((C_proc5)C_retrieve_symbol_proc(lf[12]))(5,*((C_word*)lf[12]+1),t3,lf[20],lf[21],((C_word*)((C_word*)t0)[2])[1]);
case C_fix(1):
t3=(C_word)C_a_i_cons(&a,2,lf[21],((C_word*)((C_word*)t0)[2])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t3);
t5=t2;
f_660(2,t5,t4);
case C_fix(2):
t3=t2;
f_660(2,t3,C_SCHEME_FALSE);
default:
t3=(C_word)C_i_car(((C_word*)t0)[5]);
/* chicken.scm: 102  compiler-warning */
((C_proc5)C_retrieve_symbol_proc(lf[16]))(5,*((C_word*)lf[16]+1),t2,lf[17],lf[22],t3);}}

/* k672 in k655 in loop in a549 in k419 in k415 in k412 in k409 in k406 in k403 in k400 in k397 in k394 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 */
static void C_ccall f_674(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_660(2,t3,t2);}

/* k658 in k655 in loop in a549 in k419 in k415 in k412 in k409 in k406 in k403 in k400 in k397 in k394 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 */
static void C_ccall f_660(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* chicken.scm: 103  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_562(t3,((C_word*)t0)[2],t2);}

/* k582 in loop in a549 in k419 in k415 in k412 in k409 in k406 in k403 in k400 in k397 in k394 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 */
static void C_ccall f_584(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_584,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_587,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
switch(t1){
case C_fix(0):
t3=t2;
f_587(2,t3,C_SCHEME_FALSE);
case C_fix(1):
t3=(C_word)C_a_i_cons(&a,2,lf[11],((C_word*)((C_word*)t0)[2])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t3);
t5=t2;
f_587(2,t5,t4);
case C_fix(2):
t3=(C_word)C_a_i_cons(&a,2,lf[11],((C_word*)((C_word*)t0)[2])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t3);
t5=t2;
f_587(2,t5,t4);
case C_fix(3):
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_627,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 90   cons* */
((C_proc6)C_retrieve_symbol_proc(lf[12]))(6,*((C_word*)lf[12]+1),t3,lf[11],lf[13],lf[14],((C_word*)((C_word*)t0)[2])[1]);
case C_fix(4):
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_637,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 93   cons* */
((C_proc7)C_retrieve_symbol_proc(lf[12]))(7,*((C_word*)lf[12]+1),t3,lf[11],lf[13],lf[14],lf[15],((C_word*)((C_word*)t0)[2])[1]);
default:
t3=(C_word)C_i_car(((C_word*)t0)[5]);
/* chicken.scm: 94   compiler-warning */
((C_proc5)C_retrieve_symbol_proc(lf[16]))(5,*((C_word*)lf[16]+1),t2,lf[17],lf[18],t3);}}

/* k635 in k582 in loop in a549 in k419 in k415 in k412 in k409 in k406 in k403 in k400 in k397 in k394 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 */
static void C_ccall f_637(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_587(2,t3,t2);}

/* k625 in k582 in loop in a549 in k419 in k415 in k412 in k409 in k406 in k403 in k400 in k397 in k394 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 */
static void C_ccall f_627(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_587(2,t3,t2);}

/* k585 in k582 in loop in a549 in k419 in k415 in k412 in k409 in k406 in k403 in k400 in k397 in k394 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 */
static void C_ccall f_587(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* chicken.scm: 95   loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_562(t3,((C_word*)t0)[2],t2);}

/* k552 in a549 in k419 in k415 in k412 in k409 in k406 in k403 in k400 in k397 in k394 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 */
static void C_ccall f_554(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_554,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_557,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
C_apply(5,0,t2,C_retrieve(lf[9]),((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* k555 in k552 in a549 in k419 in k415 in k412 in k409 in k406 in k403 in k400 in k397 in k394 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 */
static void C_ccall f_557(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 122  exit */
((C_proc2)C_retrieve_symbol_proc(lf[8]))(2,*((C_word*)lf[8]+1),((C_word*)t0)[2]);}

/* a537 in k419 in k415 in k412 in k409 in k406 in k403 in k400 in k397 in k394 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 */
static void C_ccall f_538(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_538,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_545,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* chicken.scm: 75   user-options-pass */
((C_proc2)C_retrieve_symbol_proc(lf[7]))(2,*((C_word*)lf[7]+1),t2);}

/* k543 in a537 in k419 in k415 in k412 in k409 in k406 in k403 in k400 in k397 in k394 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 */
static void C_ccall f_545(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?t1:C_retrieve(lf[2]));
t3=t2;
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],C_retrieve(lf[1]));}

/* k528 in k419 in k415 in k412 in k409 in k406 in k403 in k400 in k397 in k394 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 */
static void C_ccall f_530(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_530,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_533,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_536,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#implicit-exit-handler */
((C_proc2)C_retrieve_symbol_proc(lf[6]))(2,*((C_word*)lf[6]+1),t3);}

/* k534 in k528 in k419 in k415 in k412 in k409 in k406 in k403 in k400 in k397 in k394 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 */
static void C_ccall f_536(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k531 in k528 in k419 in k415 in k412 in k409 in k406 in k403 in k400 in k397 in k394 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 */
static void C_ccall f_533(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* ##compiler#process-command-line in k419 in k415 in k412 in k409 in k406 in k403 in k400 in k397 in k394 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 */
static void C_ccall f_423(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_423,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_429,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_429(t6,t1,t2,C_SCHEME_END_OF_LIST,C_SCHEME_FALSE);}

/* loop in ##compiler#process-command-line in k419 in k415 in k412 in k409 in k406 in k403 in k400 in k397 in k394 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 */
static void C_fcall f_429(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word *a;
loop:
a=C_alloc(9);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_429,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_443,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 60   reverse */
((C_proc3)C_retrieve_proc(*((C_word*)lf[3]+1)))(3,*((C_word*)lf[3]+1),t5,t3);}
else{
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_string_length(t5);
t7=(C_word)C_i_string_ref(t5,C_fix(0));
t8=(C_word)C_eqp(C_make_character(45),t7);
t9=(C_truep(t8)?(C_word)C_fixnum_greaterp(t6,C_fix(1)):C_SCHEME_FALSE);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_464,a[2]=t6,a[3]=t5,a[4]=t4,a[5]=t3,a[6]=t1,a[7]=((C_word*)t0)[2],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_fixnum_greaterp(t6,C_fix(1)))){
t11=(C_word)C_i_string_ref(t5,C_fix(1));
t12=t10;
f_464(t12,(C_word)C_eqp(C_make_character(58),t11));}
else{
t11=t10;
f_464(t11,C_SCHEME_FALSE);}}
else{
if(C_truep(t4)){
t10=(C_word)C_i_cdr(t2);
t11=(C_word)C_a_i_cons(&a,2,t5,t3);
/* chicken.scm: 69   loop */
t17=t1;
t18=t10;
t19=t11;
t20=t4;
t1=t17;
t2=t18;
t3=t19;
t4=t20;
goto loop;}
else{
t10=(C_word)C_i_cdr(t2);
/* chicken.scm: 70   loop */
t17=t1;
t18=t10;
t19=t3;
t20=t5;
t1=t17;
t2=t18;
t3=t19;
t4=t20;
goto loop;}}}}

/* k462 in loop in ##compiler#process-command-line in k419 in k415 in k412 in k409 in k406 in k403 in k400 in k397 in k394 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 */
static void C_fcall f_464(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_464,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[8]);
/* chicken.scm: 66   loop */
t3=((C_word*)((C_word*)t0)[7])[1];
f_429(t3,((C_word*)t0)[6],t2,((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[8]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_486,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_490,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* chicken.scm: 67   substring */
((C_proc5)C_retrieve_proc(*((C_word*)lf[5]+1)))(5,*((C_word*)lf[5]+1),t4,((C_word*)t0)[3],C_fix(1),((C_word*)t0)[2]);}}

/* k488 in k462 in loop in ##compiler#process-command-line in k419 in k415 in k412 in k409 in k406 in k403 in k400 in k397 in k394 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 */
static void C_ccall f_490(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 67   string->symbol */
((C_proc3)C_retrieve_proc(*((C_word*)lf[4]+1)))(3,*((C_word*)lf[4]+1),((C_word*)t0)[2],t1);}

/* k484 in k462 in loop in ##compiler#process-command-line in k419 in k415 in k412 in k409 in k406 in k403 in k400 in k397 in k394 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 */
static void C_ccall f_486(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_486,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[6]);
/* chicken.scm: 67   loop */
t3=((C_word*)((C_word*)t0)[5])[1];
f_429(t3,((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k441 in loop in ##compiler#process-command-line in k419 in k415 in k412 in k409 in k406 in k403 in k400 in k397 in k394 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 */
static void C_ccall f_443(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 60   values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[122] = {
{"toplevel:chicken_scm",(void*)C_toplevel},
{"f_338:chicken_scm",(void*)f_338},
{"f_341:chicken_scm",(void*)f_341},
{"f_344:chicken_scm",(void*)f_344},
{"f_347:chicken_scm",(void*)f_347},
{"f_350:chicken_scm",(void*)f_350},
{"f_353:chicken_scm",(void*)f_353},
{"f_356:chicken_scm",(void*)f_356},
{"f_359:chicken_scm",(void*)f_359},
{"f_362:chicken_scm",(void*)f_362},
{"f_365:chicken_scm",(void*)f_365},
{"f_368:chicken_scm",(void*)f_368},
{"f_371:chicken_scm",(void*)f_371},
{"f_374:chicken_scm",(void*)f_374},
{"f_377:chicken_scm",(void*)f_377},
{"f_380:chicken_scm",(void*)f_380},
{"f_383:chicken_scm",(void*)f_383},
{"f_386:chicken_scm",(void*)f_386},
{"f_389:chicken_scm",(void*)f_389},
{"f_392:chicken_scm",(void*)f_392},
{"f_396:chicken_scm",(void*)f_396},
{"f_1258:chicken_scm",(void*)f_1258},
{"f_1265:chicken_scm",(void*)f_1265},
{"f_1268:chicken_scm",(void*)f_1268},
{"f_1271:chicken_scm",(void*)f_1271},
{"f_1376:chicken_scm",(void*)f_1376},
{"f_1389:chicken_scm",(void*)f_1389},
{"f_1487:chicken_scm",(void*)f_1487},
{"f_1485:chicken_scm",(void*)f_1485},
{"f_1449:chicken_scm",(void*)f_1449},
{"f_1473:chicken_scm",(void*)f_1473},
{"f_1457:chicken_scm",(void*)f_1457},
{"f_1461:chicken_scm",(void*)f_1461},
{"f_1277:chicken_scm",(void*)f_1277},
{"f_1287:chicken_scm",(void*)f_1287},
{"f_1361:chicken_scm",(void*)f_1361},
{"f_1341:chicken_scm",(void*)f_1341},
{"f_1311:chicken_scm",(void*)f_1311},
{"f_1307:chicken_scm",(void*)f_1307},
{"f_1256:chicken_scm",(void*)f_1256},
{"f_399:chicken_scm",(void*)f_399},
{"f_1117:chicken_scm",(void*)f_1117},
{"f_1121:chicken_scm",(void*)f_1121},
{"f_1133:chicken_scm",(void*)f_1133},
{"f_1233:chicken_scm",(void*)f_1233},
{"f_1136:chicken_scm",(void*)f_1136},
{"f_1143:chicken_scm",(void*)f_1143},
{"f_1213:chicken_scm",(void*)f_1213},
{"f_1229:chicken_scm",(void*)f_1229},
{"f_1193:chicken_scm",(void*)f_1193},
{"f_1167:chicken_scm",(void*)f_1167},
{"f_1163:chicken_scm",(void*)f_1163},
{"f_1115:chicken_scm",(void*)f_1115},
{"f_402:chicken_scm",(void*)f_402},
{"f_967:chicken_scm",(void*)f_967},
{"f_971:chicken_scm",(void*)f_971},
{"f_980:chicken_scm",(void*)f_980},
{"f_1103:chicken_scm",(void*)f_1103},
{"f_1111:chicken_scm",(void*)f_1111},
{"f_983:chicken_scm",(void*)f_983},
{"f_1079:chicken_scm",(void*)f_1079},
{"f_994:chicken_scm",(void*)f_994},
{"f_1077:chicken_scm",(void*)f_1077},
{"f_1004:chicken_scm",(void*)f_1004},
{"f_1002:chicken_scm",(void*)f_1002},
{"f_965:chicken_scm",(void*)f_965},
{"f_405:chicken_scm",(void*)f_405},
{"f_899:chicken_scm",(void*)f_899},
{"f_903:chicken_scm",(void*)f_903},
{"f_906:chicken_scm",(void*)f_906},
{"f_913:chicken_scm",(void*)f_913},
{"f_937:chicken_scm",(void*)f_937},
{"f_957:chicken_scm",(void*)f_957},
{"f_953:chicken_scm",(void*)f_953},
{"f_897:chicken_scm",(void*)f_897},
{"f_408:chicken_scm",(void*)f_408},
{"f_825:chicken_scm",(void*)f_825},
{"f_829:chicken_scm",(void*)f_829},
{"f_832:chicken_scm",(void*)f_832},
{"f_842:chicken_scm",(void*)f_842},
{"f_858:chicken_scm",(void*)f_858},
{"f_878:chicken_scm",(void*)f_878},
{"f_823:chicken_scm",(void*)f_823},
{"f_411:chicken_scm",(void*)f_411},
{"f_796:chicken_scm",(void*)f_796},
{"f_800:chicken_scm",(void*)f_800},
{"f_815:chicken_scm",(void*)f_815},
{"f_794:chicken_scm",(void*)f_794},
{"f_414:chicken_scm",(void*)f_414},
{"f_417:chicken_scm",(void*)f_417},
{"f_787:chicken_scm",(void*)f_787},
{"f_783:chicken_scm",(void*)f_783},
{"f_775:chicken_scm",(void*)f_775},
{"f_765:chicken_scm",(void*)f_765},
{"f_773:chicken_scm",(void*)f_773},
{"f_421:chicken_scm",(void*)f_421},
{"f_550:chicken_scm",(void*)f_550},
{"f_562:chicken_scm",(void*)f_562},
{"f_755:chicken_scm",(void*)f_755},
{"f_748:chicken_scm",(void*)f_748},
{"f_711:chicken_scm",(void*)f_711},
{"f_657:chicken_scm",(void*)f_657},
{"f_674:chicken_scm",(void*)f_674},
{"f_660:chicken_scm",(void*)f_660},
{"f_584:chicken_scm",(void*)f_584},
{"f_637:chicken_scm",(void*)f_637},
{"f_627:chicken_scm",(void*)f_627},
{"f_587:chicken_scm",(void*)f_587},
{"f_554:chicken_scm",(void*)f_554},
{"f_557:chicken_scm",(void*)f_557},
{"f_538:chicken_scm",(void*)f_538},
{"f_545:chicken_scm",(void*)f_545},
{"f_530:chicken_scm",(void*)f_530},
{"f_536:chicken_scm",(void*)f_536},
{"f_533:chicken_scm",(void*)f_533},
{"f_423:chicken_scm",(void*)f_423},
{"f_429:chicken_scm",(void*)f_429},
{"f_464:chicken_scm",(void*)f_464},
{"f_490:chicken_scm",(void*)f_490},
{"f_486:chicken_scm",(void*)f_486},
{"f_443:chicken_scm",(void*)f_443},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
