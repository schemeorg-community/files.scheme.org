/* Generated from csi.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2009-09-21 21:28
   Version 4.0.1 - SVN rev. 14292
   linux-unix-gnu-x86 [ manyargs dload ptables applyhook ]
   compiled 2009-05-12 on galinha (Linux)
   command line: csi.scm -no-trace -optimize-level 2 -include-path . -include-path ./ -no-lambda-info -inline -local -output-file csi.c -extend ./private-namespace.scm
   used units: library eval data_structures ports extras srfi_69 chicken_syntax srfi_69 ports extras
*/

#include "chicken.h"

#if (defined(_MSC_VER) && defined(_WIN32)) || defined(HAVE_DIRECT_H)
# include <direct.h>
#else
# define _getcwd(buf, len)       NULL
#endif

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_69_toplevel)
C_externimport void C_ccall C_srfi_69_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_chicken_syntax_toplevel)
C_externimport void C_ccall C_chicken_syntax_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_69_toplevel)
C_externimport void C_ccall C_srfi_69_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[389];
static double C_possibly_force_alignment;


/* from k1803 */
static C_word C_fcall stub123(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub123(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_data_pointer_or_null(C_a0);
int t1=(int )C_unfix(C_a1);
C_r=C_mpointer(&C_a,(void*)_getcwd(t0,t1));
return C_r;}

C_noret_decl(C_toplevel)
C_externexport void C_ccall C_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1620)
static void C_ccall f_1620(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1623)
static void C_ccall f_1623(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1626)
static void C_ccall f_1626(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1629)
static void C_ccall f_1629(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1632)
static void C_ccall f_1632(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1635)
static void C_ccall f_1635(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1638)
static void C_ccall f_1638(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1641)
static void C_ccall f_1641(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1644)
static void C_ccall f_1644(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1647)
static void C_ccall f_1647(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1791)
static void C_ccall f_1791(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5654)
static void C_ccall f_5654(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2028)
static void C_ccall f_2028(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2057)
static void C_ccall f_2057(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3368)
static void C_ccall f_3368(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5646)
static void C_ccall f_5646(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5652)
static void C_ccall f_5652(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5649)
static void C_ccall f_5649(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4829)
static void C_ccall f_4829(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5640)
static void C_ccall f_5640(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3075)
static void C_ccall f_3075(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3105)
static void C_ccall f_3105(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3123)
static void C_ccall f_3123(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3162)
static void C_ccall f_3162(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3162)
static void C_ccall f_3162r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3168)
static void C_ccall f_3168(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3129)
static void C_ccall f_3129(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3137)
static void C_ccall f_3137(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3139)
static void C_fcall f_3139(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3156)
static void C_ccall f_3156(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3111)
static void C_ccall f_3111(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3117)
static void C_ccall f_3117(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3103)
static void C_ccall f_3103(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3100)
static void C_ccall f_3100(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3080)
static void C_ccall f_3080(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3090)
static void C_ccall f_3090(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3093)
static void C_ccall f_3093(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4833)
static void C_ccall f_4833(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5636)
static void C_ccall f_5636(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4836)
static void C_ccall f_4836(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4839)
static void C_ccall f_4839(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4842)
static void C_ccall f_4842(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5632)
static void C_ccall f_5632(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5619)
static void C_ccall f_5619(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5579)
static void C_fcall f_5579(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5529)
static void C_ccall f_5529(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5532)
static void C_ccall f_5532(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5535)
static void C_ccall f_5535(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5538)
static void C_ccall f_5538(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5547)
static void C_ccall f_5547(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4845)
static void C_fcall f_4845(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4848)
static void C_ccall f_4848(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5523)
static void C_ccall f_5523(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4851)
static void C_fcall f_4851(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4854)
static void C_ccall f_4854(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5514)
static void C_ccall f_5514(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5510)
static void C_ccall f_5510(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4860)
static void C_ccall f_4860(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5012)
static void C_fcall f_5012(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5499)
static void C_ccall f_5499(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5502)
static void C_ccall f_5502(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5015)
static void C_ccall f_5015(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5490)
static void C_ccall f_5490(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5493)
static void C_ccall f_5493(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5018)
static void C_ccall f_5018(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5021)
static void C_fcall f_5021(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5483)
static void C_ccall f_5483(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5476)
static void C_ccall f_5476(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5024)
static void C_ccall f_5024(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5463)
static void C_ccall f_5463(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5466)
static void C_ccall f_5466(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5027)
static void C_fcall f_5027(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5457)
static void C_ccall f_5457(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5030)
static void C_ccall f_5030(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5442)
static void C_ccall f_5442(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5445)
static void C_ccall f_5445(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5448)
static void C_ccall f_5448(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5033)
static void C_ccall f_5033(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5439)
static void C_ccall f_5439(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5036)
static void C_ccall f_5036(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5435)
static void C_ccall f_5435(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5039)
static void C_ccall f_5039(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5431)
static void C_ccall f_5431(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5419)
static void C_ccall f_5419(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5427)
static void C_ccall f_5427(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5423)
static void C_ccall f_5423(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5415)
static void C_ccall f_5415(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5043)
static void C_ccall f_5043(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5046)
static void C_ccall f_5046(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5346)
static void C_ccall f_5346(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5349)
static void C_ccall f_5349(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5049)
static void C_ccall f_5049(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5334)
static void C_ccall f_5334(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5337)
static void C_ccall f_5337(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5052)
static void C_ccall f_5052(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5313)
static void C_ccall f_5313(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5316)
static void C_ccall f_5316(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5319)
static void C_ccall f_5319(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5322)
static void C_ccall f_5322(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5325)
static void C_ccall f_5325(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5055)
static void C_ccall f_5055(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5304)
static void C_ccall f_5304(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4909)
static void C_ccall f_4909(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4915)
static void C_ccall f_4915(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4937)
static void C_ccall f_4937(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4921)
static void C_ccall f_4921(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4924)
static void C_ccall f_4924(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4930)
static void C_ccall f_4930(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5058)
static void C_ccall f_5058(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5063)
static void C_fcall f_5063(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5276)
static void C_ccall f_5276(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5280)
static void C_ccall f_5280(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5283)
static void C_ccall f_5283(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5223)
static void C_ccall f_5223(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5244)
static void C_ccall f_5244(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5244)
static void C_ccall f_5244r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_5255)
static void C_fcall f_5255(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5234)
static void C_ccall f_5234(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5242)
static void C_ccall f_5242(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5213)
static void C_ccall f_5213(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5213)
static void C_ccall f_5213r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_5203)
static void C_ccall f_5203(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5187)
static void C_ccall f_5187(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5187)
static void C_ccall f_5187r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_5177)
static void C_ccall f_5177(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5157)
static void C_ccall f_5157(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5141)
static void C_ccall f_5141(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5117)
static void C_ccall f_5117(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5088)
static void C_ccall f_5088(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5076)
static void C_ccall f_5076(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4942)
static void C_fcall f_4942(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4989)
static void C_ccall f_4989(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4946)
static void C_ccall f_4946(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4949)
static void C_ccall f_4949(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4956)
static void C_ccall f_4956(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4958)
static void C_fcall f_4958(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4981)
static void C_ccall f_4981(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4979)
static void C_ccall f_4979(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4968)
static void C_ccall f_4968(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4975)
static void C_ccall f_4975(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4862)
static void C_fcall f_4862(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4868)
static void C_fcall f_4868(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4895)
static void C_ccall f_4895(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4684)
static void C_fcall f_4684(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4690)
static void C_fcall f_4690(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4712)
static void C_fcall f_4712(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4769)
static void C_ccall f_4769(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4762)
static void C_ccall f_4762(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4728)
static void C_ccall f_4728(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4751)
static void C_ccall f_4751(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4741)
static void C_ccall f_4741(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4745)
static void C_ccall f_4745(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4801)
static C_word C_fcall f_4801(C_word t0);
C_noret_decl(f_4627)
static void C_fcall f_4627(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4633)
static void C_fcall f_4633(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4645)
static void C_fcall f_4645(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4568)
static void C_ccall f_4568(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4568)
static void C_ccall f_4568r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4572)
static void C_ccall f_4572(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4577)
static void C_fcall f_4577(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4606)
static void C_ccall f_4606(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4593)
static void C_ccall f_4593(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4359)
static void C_ccall f_4359(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_4391)
static void C_fcall f_4391(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4566)
static void C_ccall f_4566(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4401)
static void C_ccall f_4401(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4404)
static void C_ccall f_4404(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4476)
static void C_fcall f_4476(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4537)
static void C_ccall f_4537(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4559)
static void C_ccall f_4559(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4555)
static void C_ccall f_4555(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4540)
static void C_ccall f_4540(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4495)
static void C_ccall f_4495(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4513)
static void C_fcall f_4513(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4523)
static void C_ccall f_4523(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4407)
static void C_ccall f_4407(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4410)
static void C_ccall f_4410(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4425)
static void C_fcall f_4425(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4438)
static void C_ccall f_4438(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4441)
static void C_ccall f_4441(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4413)
static void C_ccall f_4413(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4416)
static void C_ccall f_4416(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4362)
static void C_fcall f_4362(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_4366)
static void C_ccall f_4366(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4382)
static void C_ccall f_4382(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4198)
static void C_ccall f_4198(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4198)
static void C_ccall f_4198r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4311)
static void C_fcall f_4311(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4306)
static void C_fcall f_4306(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4200)
static void C_fcall f_4200(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4225)
static void C_ccall f_4225(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4268)
static void C_fcall f_4268(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4278)
static void C_ccall f_4278(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4249)
static void C_ccall f_4249(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4232)
static void C_ccall f_4232(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4203)
static void C_fcall f_4203(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4189)
static void C_ccall f_4189(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4193)
static void C_ccall f_4193(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3370)
static void C_ccall f_3370(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3370)
static void C_ccall f_3370r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3374)
static void C_ccall f_3374(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4168)
static void C_ccall f_4168(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3502)
static void C_ccall f_3502(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3601)
static void C_ccall f_3601(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3809)
static void C_ccall f_3809(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3837)
static void C_ccall f_3837(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3846)
static void C_ccall f_3846(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3940)
static void C_ccall f_3940(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4074)
static void C_ccall f_4074(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4089)
static void C_ccall f_4089(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4128)
static void C_ccall f_4128(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4117)
static void C_ccall f_4117(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4113)
static void C_ccall f_4113(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4096)
static void C_ccall f_4096(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4007)
static void C_ccall f_4007(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4012)
static void C_ccall f_4012(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4016)
static void C_ccall f_4016(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4025)
static void C_fcall f_4025(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4060)
static void C_ccall f_4060(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4052)
static void C_ccall f_4052(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4035)
static void C_ccall f_4035(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3971)
static void C_ccall f_3971(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3974)
static void C_ccall f_3974(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3979)
static void C_ccall f_3979(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3959)
static void C_ccall f_3959(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3946)
static void C_ccall f_3946(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3934)
static void C_ccall f_3934(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3853)
static void C_ccall f_3853(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3864)
static void C_fcall f_3864(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3828)
static void C_ccall f_3828(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3769)
static void C_fcall f_3769(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3783)
static void C_ccall f_3783(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3779)
static void C_ccall f_3779(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3725)
static void C_ccall f_3725(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3631)
static void C_ccall f_3631(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3705)
static void C_fcall f_3705(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3634)
static void C_ccall f_3634(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3702)
static void C_ccall f_3702(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3699)
static void C_ccall f_3699(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3637)
static void C_ccall f_3637(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3649)
static void C_ccall f_3649(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3654)
static void C_fcall f_3654(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3664)
static void C_ccall f_3664(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3679)
static void C_ccall f_3679(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3667)
static void C_ccall f_3667(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3670)
static void C_ccall f_3670(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3571)
static void C_ccall f_3571(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3577)
static void C_ccall f_3577(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3505)
static void C_ccall f_3505(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3376)
static void C_ccall f_3376(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_3499)
static void C_ccall f_3499(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3383)
static void C_ccall f_3383(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3388)
static void C_fcall f_3388(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3411)
static void C_ccall f_3411(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3420)
static void C_fcall f_3420(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3484)
static void C_ccall f_3484(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3430)
static void C_ccall f_3430(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3433)
static void C_ccall f_3433(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3174)
static void C_ccall f_3174(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3174)
static void C_ccall f_3174r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3182)
static void C_ccall f_3182(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3184)
static void C_ccall f_3184(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3188)
static void C_ccall f_3188(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3191)
static void C_ccall f_3191(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3194)
static void C_ccall f_3194(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3211)
static void C_ccall f_3211(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3354)
static void C_ccall f_3354(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3350)
static void C_ccall f_3350(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3346)
static void C_ccall f_3346(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3313)
static void C_ccall f_3313(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3317)
static void C_ccall f_3317(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3322)
static void C_ccall f_3322(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3330)
static void C_ccall f_3330(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3214)
static void C_ccall f_3214(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3242)
static void C_ccall f_3242(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3250)
static void C_ccall f_3250(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3254)
static void C_ccall f_3254(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3258)
static void C_ccall f_3258(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3262)
static void C_ccall f_3262(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3266)
static void C_ccall f_3266(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3217)
static void C_ccall f_3217(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3220)
static void C_ccall f_3220(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3223)
static void C_ccall f_3223(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3226)
static void C_ccall f_3226(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3196)
static void C_fcall f_3196(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3204)
static void C_ccall f_3204(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3047)
static void C_ccall f_3047(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3057)
static void C_ccall f_3057(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3051)
static void C_ccall f_3051(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2756)
static void C_ccall f_2756(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2761)
static void C_ccall f_2761(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2764)
static void C_ccall f_2764(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2767)
static void C_ccall f_2767(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2770)
static void C_ccall f_2770(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2781)
static void C_ccall f_2781(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2785)
static void C_ccall f_2785(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2773)
static void C_ccall f_2773(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2776)
static void C_ccall f_2776(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2733)
static void C_ccall f_2733(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2737)
static void C_ccall f_2737(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2741)
static void C_ccall f_2741(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2744)
static void C_ccall f_2744(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2747)
static void C_ccall f_2747(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2705)
static void C_fcall f_2705(C_word t0) C_noret;
C_noret_decl(f_2709)
static void C_ccall f_2709(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2714)
static void C_fcall f_2714(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2724)
static void C_ccall f_2724(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2731)
static void C_ccall f_2731(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2664)
static void C_ccall f_2664(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2670)
static void C_fcall f_2670(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2686)
static void C_ccall f_2686(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2696)
static void C_ccall f_2696(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2650)
static void C_ccall f_2650(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2658)
static void C_ccall f_2658(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2662)
static void C_ccall f_2662(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2100)
static void C_ccall f_2100(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2117)
static void C_fcall f_2117(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2631)
static void C_ccall f_2631(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2631)
static void C_ccall f_2631r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2635)
static void C_ccall f_2635(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2625)
static void C_ccall f_2625(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2123)
static void C_ccall f_2123(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2611)
static void C_ccall f_2611(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2587)
static void C_ccall f_2587(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2595)
static void C_ccall f_2595(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2590)
static void C_ccall f_2590(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2568)
static void C_ccall f_2568(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2571)
static void C_ccall f_2571(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2574)
static void C_ccall f_2574(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2537)
static void C_ccall f_2537(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2540)
static void C_ccall f_2540(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2547)
static void C_ccall f_2547(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2521)
static void C_ccall f_2521(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2493)
static void C_ccall f_2493(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2470)
static void C_ccall f_2470(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2483)
static void C_ccall f_2483(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2461)
static void C_ccall f_2461(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2457)
static void C_ccall f_2457(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2431)
static void C_ccall f_2431(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2427)
static void C_ccall f_2427(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2423)
static void C_ccall f_2423(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3018)
static void C_ccall f_3018(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3022)
static void C_ccall f_3022(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3041)
static void C_ccall f_3041(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2410)
static void C_ccall f_2410(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2406)
static void C_ccall f_2406(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2402)
static void C_ccall f_2402(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2950)
static void C_ccall f_2950(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2954)
static void C_ccall f_2954(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2999)
static void C_ccall f_2999(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3006)
static void C_ccall f_3006(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2960)
static void C_fcall f_2960(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2981)
static void C_ccall f_2981(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2981)
static void C_ccall f_2981r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2985)
static void C_ccall f_2985(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2937)
static void C_ccall f_2937(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2389)
static void C_ccall f_2389(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2385)
static void C_ccall f_2385(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2381)
static void C_ccall f_2381(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2896)
static void C_ccall f_2896(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2900)
static void C_ccall f_2900(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2919)
static void C_ccall f_2919(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2368)
static void C_ccall f_2368(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2364)
static void C_ccall f_2364(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2360)
static void C_ccall f_2360(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2815)
static void C_ccall f_2815(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2819)
static void C_ccall f_2819(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2858)
static void C_ccall f_2858(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2858)
static void C_ccall f_2858r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2862)
static void C_ccall f_2862(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2873)
static void C_ccall f_2873(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2873)
static void C_ccall f_2873r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2877)
static void C_ccall f_2877(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2867)
static void C_ccall f_2867(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2802)
static void C_ccall f_2802(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2307)
static void C_ccall f_2307(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2340)
static void C_ccall f_2340(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2340)
static void C_ccall f_2340r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2344)
static void C_ccall f_2344(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2312)
static void C_ccall f_2312(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2316)
static void C_ccall f_2316(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2327)
static void C_ccall f_2327(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2327)
static void C_ccall f_2327r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2338)
static void C_ccall f_2338(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2331)
static void C_ccall f_2331(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2321)
static void C_ccall f_2321(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2298)
static void C_ccall f_2298(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2273)
static void C_ccall f_2273(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2281)
static void C_ccall f_2281(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2287)
static void C_ccall f_2287(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2291)
static void C_ccall f_2291(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2276)
static void C_ccall f_2276(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2264)
static void C_ccall f_2264(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2254)
static void C_ccall f_2254(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2257)
static void C_ccall f_2257(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2215)
static void C_ccall f_2215(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2218)
static void C_ccall f_2218(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2221)
static void C_ccall f_2221(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2224)
static void C_ccall f_2224(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2200)
static void C_ccall f_2200(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2203)
static void C_ccall f_2203(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2185)
static void C_ccall f_2185(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2188)
static void C_ccall f_2188(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2167)
static void C_ccall f_2167(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2170)
static void C_ccall f_2170(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2173)
static void C_ccall f_2173(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2144)
static void C_ccall f_2144(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2158)
static void C_ccall f_2158(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2154)
static void C_ccall f_2154(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2147)
static void C_ccall f_2147(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2129)
static void C_ccall f_2129(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2059)
static void C_ccall f_2059(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2059)
static void C_ccall f_2059r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2063)
static void C_ccall f_2063(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2043)
static void C_ccall f_2043(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2050)
static void C_ccall f_2050(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2030)
static void C_ccall f_2030(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2003)
static void C_ccall f_2003(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1964)
static void C_ccall f_1964(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1988)
static void C_ccall f_1988(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1974)
static void C_fcall f_1974(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1858)
static void C_ccall f_1858(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1862)
static void C_ccall f_1862(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1903)
static void C_ccall f_1903(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1909)
static void C_ccall f_1909(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1916)
static void C_ccall f_1916(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1918)
static void C_fcall f_1918(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1945)
static void C_ccall f_1945(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1928)
static void C_ccall f_1928(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1931)
static void C_ccall f_1931(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1886)
static void C_ccall f_1886(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1900)
static void C_ccall f_1900(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1896)
static void C_ccall f_1896(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1837)
static C_word C_fcall f_1837(C_word t0,C_word t1);
C_noret_decl(f_1810)
static void C_fcall f_1810(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1817)
static void C_ccall f_1817(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1820)
static void C_ccall f_1820(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1826)
static void C_ccall f_1826(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1760)
static void C_ccall f_1760(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1764)
static void C_ccall f_1764(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1773)
static void C_fcall f_1773(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1734)
static void C_ccall f_1734(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1746)
static void C_ccall f_1746(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1701)
static void C_ccall f_1701(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1722)
static void C_ccall f_1722(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1685)
static void C_ccall f_1685(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1689)
static void C_ccall f_1689(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1692)
static void C_ccall f_1692(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1699)
static void C_ccall f_1699(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1657)
static void C_ccall f_1657(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1661)
static void C_ccall f_1661(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1671)
static void C_ccall f_1671(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1664)
static void C_ccall f_1664(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_3139)
static void C_fcall trf_3139(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3139(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3139(t0,t1,t2,t3);}

C_noret_decl(trf_5579)
static void C_fcall trf_5579(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5579(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5579(t0,t1);}

C_noret_decl(trf_4845)
static void C_fcall trf_4845(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4845(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4845(t0,t1);}

C_noret_decl(trf_4851)
static void C_fcall trf_4851(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4851(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4851(t0,t1);}

C_noret_decl(trf_5012)
static void C_fcall trf_5012(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5012(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5012(t0,t1);}

C_noret_decl(trf_5021)
static void C_fcall trf_5021(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5021(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5021(t0,t1);}

C_noret_decl(trf_5027)
static void C_fcall trf_5027(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5027(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5027(t0,t1);}

C_noret_decl(trf_5063)
static void C_fcall trf_5063(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5063(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5063(t0,t1,t2);}

C_noret_decl(trf_5255)
static void C_fcall trf_5255(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5255(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5255(t0,t1);}

C_noret_decl(trf_4942)
static void C_fcall trf_4942(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4942(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4942(t0,t1,t2);}

C_noret_decl(trf_4958)
static void C_fcall trf_4958(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4958(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4958(t0,t1,t2);}

C_noret_decl(trf_4862)
static void C_fcall trf_4862(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4862(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4862(t0,t1,t2);}

C_noret_decl(trf_4868)
static void C_fcall trf_4868(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4868(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4868(t0,t1,t2);}

C_noret_decl(trf_4684)
static void C_fcall trf_4684(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4684(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4684(t0,t1);}

C_noret_decl(trf_4690)
static void C_fcall trf_4690(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4690(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4690(t0,t1,t2);}

C_noret_decl(trf_4712)
static void C_fcall trf_4712(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4712(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4712(t0,t1);}

C_noret_decl(trf_4627)
static void C_fcall trf_4627(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4627(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4627(t0,t1,t2);}

C_noret_decl(trf_4633)
static void C_fcall trf_4633(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4633(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4633(t0,t1,t2);}

C_noret_decl(trf_4645)
static void C_fcall trf_4645(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4645(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4645(t0,t1,t2);}

C_noret_decl(trf_4577)
static void C_fcall trf_4577(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4577(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4577(t0,t1,t2);}

C_noret_decl(trf_4391)
static void C_fcall trf_4391(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4391(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4391(t0,t1,t2);}

C_noret_decl(trf_4476)
static void C_fcall trf_4476(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4476(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4476(t0,t1,t2,t3);}

C_noret_decl(trf_4513)
static void C_fcall trf_4513(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4513(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4513(t0,t1,t2);}

C_noret_decl(trf_4425)
static void C_fcall trf_4425(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4425(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4425(t0,t1,t2,t3);}

C_noret_decl(trf_4362)
static void C_fcall trf_4362(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4362(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_4362(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_4311)
static void C_fcall trf_4311(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4311(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4311(t0,t1);}

C_noret_decl(trf_4306)
static void C_fcall trf_4306(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4306(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4306(t0,t1,t2);}

C_noret_decl(trf_4200)
static void C_fcall trf_4200(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4200(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4200(t0,t1,t2,t3);}

C_noret_decl(trf_4268)
static void C_fcall trf_4268(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4268(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4268(t0,t1);}

C_noret_decl(trf_4203)
static void C_fcall trf_4203(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4203(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4203(t0,t1,t2);}

C_noret_decl(trf_4025)
static void C_fcall trf_4025(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4025(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4025(t0,t1,t2);}

C_noret_decl(trf_3864)
static void C_fcall trf_3864(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3864(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3864(t0,t1);}

C_noret_decl(trf_3769)
static void C_fcall trf_3769(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3769(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3769(t0,t1);}

C_noret_decl(trf_3705)
static void C_fcall trf_3705(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3705(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3705(t0,t1);}

C_noret_decl(trf_3654)
static void C_fcall trf_3654(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3654(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3654(t0,t1,t2);}

C_noret_decl(trf_3388)
static void C_fcall trf_3388(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3388(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3388(t0,t1,t2);}

C_noret_decl(trf_3420)
static void C_fcall trf_3420(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3420(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3420(t0,t1,t2,t3);}

C_noret_decl(trf_3196)
static void C_fcall trf_3196(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3196(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3196(t0,t1);}

C_noret_decl(trf_2705)
static void C_fcall trf_2705(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2705(void *dummy){
C_word t0=C_pick(0);
C_adjust_stack(-1);
f_2705(t0);}

C_noret_decl(trf_2714)
static void C_fcall trf_2714(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2714(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2714(t0,t1,t2);}

C_noret_decl(trf_2670)
static void C_fcall trf_2670(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2670(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2670(t0,t1,t2);}

C_noret_decl(trf_2117)
static void C_fcall trf_2117(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2117(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2117(t0,t1);}

C_noret_decl(trf_2960)
static void C_fcall trf_2960(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2960(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2960(t0,t1);}

C_noret_decl(trf_1974)
static void C_fcall trf_1974(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1974(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1974(t0,t1);}

C_noret_decl(trf_1918)
static void C_fcall trf_1918(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1918(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1918(t0,t1,t2);}

C_noret_decl(trf_1810)
static void C_fcall trf_1810(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1810(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1810(t0,t1);}

C_noret_decl(trf_1773)
static void C_fcall trf_1773(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1773(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1773(t0,t1);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr2rv)
static void C_fcall tr2rv(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2rv(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n+1);
t2=C_restore_rest_vector(a,n);
(k)(t0,t1,t2);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_main_entry_point
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("toplevel"));
C_resize_stack(131072);
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(2679)){
C_save(t1);
C_rereclaim2(2679*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,389);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[3]=C_decode_literal(C_heaptop,"\376B\000\000\006.csirc");
lf[4]=C_h_intern(&lf[4],27,"\003sysrepl-print-length-limit");
lf[5]=C_h_intern(&lf[5],4,"\000csi");
lf[6]=C_h_intern(&lf[6],12,"\003sysfeatures");
lf[7]=C_h_intern(&lf[7],15,"\003csiprint-usage");
lf[8]=C_h_intern(&lf[8],7,"display");
lf[9]=C_decode_literal(C_heaptop,"\376B\000\004V    -b  -batch                    terminate after command-line processing\012 "
"   -w  -no-warnings              disable all warnings\012    -k  -keyword-style STY"
"LE      enable alternative keyword-syntax\012                                   (pr"
"efix, suffix or none)\012        -no-parentheses-synonyms  disables list delimiter "
"synonyms\012        -no-symbol-escape         disables support for escaped symbols\012"
"        -r5rs-syntax              disables the Chicken extensions to\012           "
"                        R5RS syntax\012    -s  -script PATHNAME          use interp"
"reter for shell scripts\012        -ss PATHNAME              shell script with `mai"
"n\047 procedure\012        -sx PATHNAME              same as `-s\047, but print each expr"
"ession\012                                   as it is evaluated\012        -setup-mode"
"               prefer the current directory when locating extensions\012    -R  -re"
"quire-extension NAME   require extension and import before\012                     "
"              executing code\012    -I  -include-path PATHNAME    add PATHNAME to i"
"nclude path\012    --                            ignore all following options\012");
lf[10]=C_decode_literal(C_heaptop,"\376B\000\000\003 \047\012");
lf[11]=C_decode_literal(C_heaptop,"\376B\000\000D    -n  -no-init                  do not load initialization file ` ");
lf[12]=C_h_intern(&lf[12],19,"\003sysprint-to-string");
lf[13]=C_decode_literal(C_heaptop,"\376B\000\002\344usage: csi [FILENAME | OPTION ...]\012\012  `csi\047 is the CHICKEN interpreter.\012  \012"
"  FILENAME is a Scheme source file name with optional extension. OPTION may be\012 "
" one of the following:\012\012    -h  -help  --help             display this text and "
"exit\012    -v  -version                  display version and exit\012        -release"
"                  print release number and exit\012    -i  -case-insensitive       "
"  enable case-insensitive reading\012    -e  -eval EXPRESSION          evaluate giv"
"en expression\012    -p  -print EXPRESSION         evaluate and print result(s)\012   "
" -P  -pretty-print EXPRESSION  evaluate and print result(s) prettily\012    -D  -fe"
"ature SYMBOL           register feature identifier\012    -q  -quiet               "
"     do not print banner\012");
lf[14]=C_h_intern(&lf[14],16,"\003csiprint-banner");
lf[15]=C_h_intern(&lf[15],5,"print");
lf[16]=C_decode_literal(C_heaptop,"\376B\000\000\077(c)2008-2009 The Chicken Team\012(c)2000-2007 Felix L. Winkelmann\012");
lf[17]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[18]=C_h_intern(&lf[18],15,"chicken-version");
lf[19]=C_decode_literal(C_heaptop,"\376B\000\000\007CHICKEN");
lf[20]=C_h_intern(&lf[20],7,"newline");
lf[21]=C_h_intern(&lf[21],9,"read-char");
lf[22]=C_h_intern(&lf[22],4,"read");
lf[23]=C_h_intern(&lf[23],18,"\003sysuser-read-hook");
lf[24]=C_h_intern(&lf[24],5,"quote");
lf[25]=C_h_intern(&lf[25],17,"\003csihistory-count");
lf[26]=C_h_intern(&lf[26],15,"\003csihistory-ref");
lf[27]=C_h_intern(&lf[27],21,"\003syssharp-number-hook");
lf[28]=C_h_intern(&lf[28],9,"substring");
lf[29]=C_h_intern(&lf[29],18,"\003csichop-separator");
lf[30]=C_h_intern(&lf[30],4,"sub1");
lf[31]=C_h_intern(&lf[31],1,"@");
lf[32]=C_h_intern(&lf[32],12,"file-exists\077");
lf[33]=C_h_intern(&lf[33],13,"string-append");
lf[34]=C_decode_literal(C_heaptop,"\376B\000\000\004.bat");
lf[35]=C_h_intern(&lf[35],22,"\003csilookup-script-file");
lf[36]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[37]=C_h_intern(&lf[37],25,"\003syspeek-nonnull-c-string");
lf[38]=C_h_intern(&lf[38],12,"string-split");
lf[39]=C_decode_literal(C_heaptop,"\376B\000\000\001;");
lf[40]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[41]=C_h_intern(&lf[41],24,"get-environment-variable");
lf[42]=C_decode_literal(C_heaptop,"\376B\000\000\004PATH");
lf[43]=C_h_intern(&lf[43],16,"\003csihistory-list");
lf[44]=C_h_intern(&lf[44],13,"vector-resize");
lf[45]=C_h_intern(&lf[45],15,"\003csihistory-add");
lf[46]=C_h_intern(&lf[46],19,"\003sysundefined-value");
lf[47]=C_h_intern(&lf[47],9,"\003syserror");
lf[48]=C_decode_literal(C_heaptop,"\376B\000\000 history entry index out of range");
lf[49]=C_h_intern(&lf[49],14,"\003csitty-input\077");
lf[50]=C_h_intern(&lf[50],13,"\003systty-port\077");
lf[51]=C_h_intern(&lf[51],18,"\003sysstandard-input");
lf[52]=C_h_intern(&lf[52],18,"\003sysbreak-on-error");
lf[53]=C_h_intern(&lf[53],20,"\003sysread-prompt-hook");
lf[55]=C_h_intern(&lf[55],16,"toplevel-command");
lf[56]=C_h_intern(&lf[56],19,"\003syshash-table-set!");
lf[57]=C_h_intern(&lf[57],4,"eval");
lf[58]=C_h_intern(&lf[58],12,"load-noisily");
lf[59]=C_h_intern(&lf[59],10,"singlestep");
lf[60]=C_h_intern(&lf[60],9,"read-line");
lf[61]=C_h_intern(&lf[61],6,"length");
lf[62]=C_h_intern(&lf[62],5,"write");
lf[63]=C_h_intern(&lf[63],6,"printf");
lf[64]=C_h_intern(&lf[64],6,"expand");
lf[65]=C_h_intern(&lf[65],12,"pretty-print");
lf[66]=C_h_intern(&lf[66],8,"integer\077");
lf[67]=C_h_intern(&lf[67],6,"values");
lf[68]=C_h_intern(&lf[68],18,"\003sysrepl-eval-hook");
lf[69]=C_h_intern(&lf[69],22,"\003csitrace-indent-level");
lf[70]=C_h_intern(&lf[70],4,"exit");
lf[71]=C_h_intern(&lf[71],1,"x");
lf[72]=C_h_intern(&lf[72],16,"\003sysstrip-syntax");
lf[73]=C_h_intern(&lf[73],1,"p");
lf[74]=C_h_intern(&lf[74],1,"d");
lf[75]=C_h_intern(&lf[75],12,"\003csidescribe");
lf[76]=C_h_intern(&lf[76],2,"du");
lf[77]=C_h_intern(&lf[77],8,"\003csidump");
lf[78]=C_h_intern(&lf[78],3,"dur");
lf[79]=C_h_intern(&lf[79],1,"r");
lf[80]=C_h_intern(&lf[80],10,"\003csireport");
lf[81]=C_h_intern(&lf[81],1,"q");
lf[82]=C_h_intern(&lf[82],1,"l");
lf[83]=C_h_intern(&lf[83],12,"\003sysfor-each");
lf[84]=C_h_intern(&lf[84],4,"load");
lf[85]=C_h_intern(&lf[85],2,"ln");
lf[86]=C_h_intern(&lf[86],6,"print*");
lf[87]=C_decode_literal(C_heaptop,"\376B\000\000\004==> ");
lf[88]=C_h_intern(&lf[88],8,"\000printer");
lf[89]=C_h_intern(&lf[89],1,"t");
lf[90]=C_h_intern(&lf[90],17,"\003sysdisplay-times");
lf[91]=C_h_intern(&lf[91],14,"\003sysstop-timer");
lf[92]=C_h_intern(&lf[92],15,"\003sysstart-timer");
lf[93]=C_h_intern(&lf[93],2,"tr");
lf[95]=C_h_intern(&lf[95],8,"\003syswarn");
lf[96]=C_decode_literal(C_heaptop,"\376B\000\000\030procedure already traced");
lf[98]=C_decode_literal(C_heaptop,"\376B\000\000 procedure already has breakpoint");
lf[99]=C_h_intern(&lf[99],25,"\003csitraced-procedure-exit");
lf[100]=C_h_intern(&lf[100],26,"\003csitraced-procedure-entry");
lf[101]=C_decode_literal(C_heaptop,"\376B\000\000\032cannot trace non-procedure");
lf[102]=C_h_intern(&lf[102],7,"\003sysmap");
lf[104]=C_h_intern(&lf[104],3,"utr");
lf[105]=C_h_intern(&lf[105],7,"\003csidel");
lf[106]=C_h_intern(&lf[106],3,"eq\077");
lf[107]=C_decode_literal(C_heaptop,"\376B\000\000\024procedure not traced");
lf[108]=C_h_intern(&lf[108],2,"br");
lf[109]=C_h_intern(&lf[109],1,"a");
lf[110]=C_h_intern(&lf[110],15,"\003sysbreak-entry");
lf[111]=C_decode_literal(C_heaptop,"\376B\000\000&cannot set breakpoint on non-procedure");
lf[112]=C_decode_literal(C_heaptop,"\376B\000\000\024un-tracing procedure");
lf[113]=C_h_intern(&lf[113],3,"ubr");
lf[114]=C_decode_literal(C_heaptop,"\376B\000\000\033procedure has no breakpoint");
lf[115]=C_h_intern(&lf[115],3,"uba");
lf[116]=C_h_intern(&lf[116],14,"do-unbreak-all");
lf[117]=C_h_intern(&lf[117],8,"breakall");
lf[118]=C_h_intern(&lf[118],19,"\003sysbreak-in-thread");
lf[119]=C_h_intern(&lf[119],9,"breakonly");
lf[120]=C_h_intern(&lf[120],4,"info");
lf[121]=C_decode_literal(C_heaptop,"\376B\000\000\021Breakpoints: ~s~%");
lf[122]=C_h_intern(&lf[122],3,"car");
lf[123]=C_decode_literal(C_heaptop,"\376B\000\000\014Traced: ~s~%");
lf[124]=C_h_intern(&lf[124],1,"c");
lf[125]=C_h_intern(&lf[125],19,"\003syslast-breakpoint");
lf[126]=C_h_intern(&lf[126],16,"\003sysbreak-resume");
lf[127]=C_decode_literal(C_heaptop,"\376B\000\000\026no breakpoint pending\012");
lf[128]=C_h_intern(&lf[128],3,"exn");
lf[129]=C_h_intern(&lf[129],18,"\003syslast-exception");
lf[130]=C_h_intern(&lf[130],4,"step");
lf[131]=C_h_intern(&lf[131],6,"lambda");
lf[132]=C_h_intern(&lf[132],1,"s");
lf[133]=C_h_intern(&lf[133],6,"system");
lf[134]=C_h_intern(&lf[134],1,"\077");
lf[135]=C_decode_literal(C_heaptop,"\376B\000\000\002 ,");
lf[136]=C_h_intern(&lf[136],23,"\003syshash-table-for-each");
lf[137]=C_decode_literal(C_heaptop,"\376B\000\004OToplevel commands:\012\012 ,\077                Show this text\012 ,p EXP            Pr"
"etty print evaluated expression EXP\012 ,d EXP            Describe result of evalua"
"ted expression EXP\012 ,du EXP           Dump data of expression EXP\012 ,dur EXP N   "
"     Dump range\012 ,q                Quit interpreter\012 ,l FILENAME ...   Load one "
"or more files\012 ,ln FILENAME ...  Load one or more files and print result of each"
" top-level expression\012 ,r                Show system information\012 ,s TEXT ...   "
"    Execute shell-command\012 ,tr NAME ...      Trace procedures\012 ,utr NAME ...    "
" Untrace procedures\012 ,br NAME ...      Set breakpoints\012 ,ubr NAME ...     Remove"
" breakpoints\012 ,uba              Remove all breakpoints\012 ,breakall         Break "
"in all threads (default)\012 ,breakonly THREAD Break only in specified thread\012 ,c  "
"              Continue from breakpoint\012 ,info             List traced procedures"
" and breakpoints\012 ,step EXPR        Execute EXPR in single-stepping mode\012 ,exn  "
"            Describe last exception\012 ,t EXP            Evaluate form and print e"
"lapsed time\012 ,x EXP            Pretty print expanded expression EXP\012");
lf[138]=C_decode_literal(C_heaptop,"\376B\000\0005Undefined toplevel command ~s - enter `,\077\047 for help~%");
lf[139]=C_h_intern(&lf[139],18,"\003syshash-table-ref");
lf[140]=C_h_intern(&lf[140],7,"unquote");
lf[141]=C_h_intern(&lf[141],23,"\003syscurrent-environment");
lf[142]=C_h_intern(&lf[142],14,"string->symbol");
lf[144]=C_h_intern(&lf[144],19,"\003syswrite-char/port");
lf[145]=C_h_intern(&lf[145],19,"\003sysstandard-output");
lf[146]=C_h_intern(&lf[146],12,"flush-output");
lf[147]=C_h_intern(&lf[147],16,"\003syswrite-char-0");
lf[148]=C_h_intern(&lf[148],4,"add1");
lf[149]=C_decode_literal(C_heaptop,"\376B\000\000\004 -> ");
lf[150]=C_h_intern(&lf[150],4,"chop");
lf[151]=C_h_intern(&lf[151],4,"sort");
lf[152]=C_h_intern(&lf[152],19,"with-output-to-port");
lf[153]=C_h_intern(&lf[153],19,"current-output-port");
lf[154]=C_h_intern(&lf[154],8,"truncate");
lf[155]=C_decode_literal(C_heaptop,"\376B\000\000\025symbol gc is enabled\012");
lf[156]=C_decode_literal(C_heaptop,"\376B\000\000\027interrupts are enabled\012");
lf[157]=C_decode_literal(C_heaptop,"\376B\000\000\010(64-bit)");
lf[158]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[159]=C_decode_literal(C_heaptop,"\376B\000\000\010 (fixed)");
lf[160]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[161]=C_decode_literal(C_heaptop,"\376B\000\000\010downward");
lf[162]=C_decode_literal(C_heaptop,"\376B\000\000\006upward");
lf[163]=C_decode_literal(C_heaptop,"\376B\000\002\001~%~\012                   Machine type:    \011~A ~A~%~\012                   Softwa"
"re type:   \011~A~%~\012                   Software version:\011~A~%~\012                   "
"Build platform:  \011~A~%~\012                   Include path:    \011~A~%~\012             "
"      Symbol-table load:\011~S~%  ~\012                     Avg bucket length:\011~S~%  ~"
"\012                     Total symbol count:\011~S~%~\012                   Memory:\011heap "
"size is ~S bytes~A with ~S bytes currently in use~%~  \012                     nurs"
"ery size is ~S bytes, stack grows ~A~%");
lf[164]=C_h_intern(&lf[164],21,"\003sysinclude-pathnames");
lf[165]=C_h_intern(&lf[165],14,"build-platform");
lf[166]=C_h_intern(&lf[166],16,"software-version");
lf[167]=C_h_intern(&lf[167],13,"software-type");
lf[168]=C_h_intern(&lf[168],12,"machine-type");
lf[169]=C_decode_literal(C_heaptop,"\376B\000\000\004~a~a");
lf[170]=C_h_intern(&lf[170],11,"make-string");
lf[171]=C_decode_literal(C_heaptop,"\376B\000\000\003\012  ");
lf[172]=C_h_intern(&lf[172],8,"string<\077");
lf[173]=C_h_intern(&lf[173],15,"keyword->string");
lf[174]=C_decode_literal(C_heaptop,"\376B\000\000\011Features:");
lf[175]=C_h_intern(&lf[175],17,"memory-statistics");
lf[176]=C_h_intern(&lf[176],21,"\003syssymbol-table-info");
lf[177]=C_h_intern(&lf[177],2,"gc");
lf[179]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010u8vector\376\003\000\000\002\376B\000\000\030vector of unsigned bytes\376\003\000\000\002\376\001\000\000\017u8vector-leng"
"th\376\003\000\000\002\376\001\000\000\014u8vector-ref\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010s8vector\376\003\000\000\002\376B\000\000\026vector of signed byt"
"es\376\003\000\000\002\376\001\000\000\017s8vector-length\376\003\000\000\002\376\001\000\000\014s8vector-ref\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011u16vector\376\003\000\000"
"\002\376B\000\000\037vector of unsigned 16-bit words\376\003\000\000\002\376\001\000\000\020u16vector-length\376\003\000\000\002\376\001\000\000\015u16vect"
"or-ref\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011s16vector\376\003\000\000\002\376B\000\000\035vector of signed 16-bit words\376\003\000\000\002\376\001\000"
"\000\020s16vector-length\376\003\000\000\002\376\001\000\000\015s16vector-ref\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011u32vector\376\003\000\000\002\376B\000\000\037ve"
"ctor of unsigned 32-bit words\376\003\000\000\002\376\001\000\000\020u32vector-length\376\003\000\000\002\376\001\000\000\015u32vector-ref\376\377"
"\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011s32vector\376\003\000\000\002\376B\000\000\035vector of signed 32-bit words\376\003\000\000\002\376\001\000\000\020s32vec"
"tor-length\376\003\000\000\002\376\001\000\000\015s32vector-ref\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011f32vector\376\003\000\000\002\376B\000\000\027vector of "
"32-bit floats\376\003\000\000\002\376\001\000\000\020f32vector-length\376\003\000\000\002\376\001\000\000\015f32vector-ref\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011"
"f64vector\376\003\000\000\002\376B\000\000\027vector of 64-bit floats\376\003\000\000\002\376\001\000\000\020f64vector-length\376\003\000\000\002\376\001\000\000\015f6"
"4vector-ref\376\377\016\376\377\016");
lf[181]=C_h_intern(&lf[181],7,"sprintf");
lf[182]=C_h_intern(&lf[182],7,"fprintf");
lf[183]=C_h_intern(&lf[183],8,"list-ref");
lf[184]=C_h_intern(&lf[184],10,"string-ref");
lf[185]=C_decode_literal(C_heaptop,"\376B\000\000 ~% (~A elements not displayed)~%");
lf[186]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[187]=C_decode_literal(C_heaptop,"\376B\000\000\001s");
lf[188]=C_decode_literal(C_heaptop,"\376B\000\000.\011(followed by ~A identical instance~a)~% ...~%");
lf[189]=C_decode_literal(C_heaptop,"\376B\000\000\007 ~S: ~S");
lf[190]=C_decode_literal(C_heaptop,"\376B\000\000\021~A of length ~S~%");
lf[191]=C_decode_literal(C_heaptop,"\376B\000\000$character ~S, code: ~S, #x~X, #o~O~%");
lf[192]=C_decode_literal(C_heaptop,"\376B\000\000\016boolean true~%");
lf[193]=C_decode_literal(C_heaptop,"\376B\000\000\017boolean false~%");
lf[194]=C_decode_literal(C_heaptop,"\376B\000\000\014empty list~%");
lf[195]=C_decode_literal(C_heaptop,"\376B\000\000\024end-of-file object~%");
lf[196]=C_decode_literal(C_heaptop,"\376B\000\000\024unspecified object~%");
lf[197]=C_decode_literal(C_heaptop,"\376B\000\000\016, character ~S");
lf[198]=C_decode_literal(C_heaptop,"\376B\000\000\042exact integer ~S, #x~X, #o~O, #b~B");
lf[199]=C_h_intern(&lf[199],28,"\003sysarbitrary-unbound-symbol");
lf[200]=C_decode_literal(C_heaptop,"\376B\000\000\017unbound value~%");
lf[201]=C_decode_literal(C_heaptop,"\376B\000\000\013number ~S~%");
lf[202]=C_decode_literal(C_heaptop,"\376B\000\000\006string");
lf[203]=C_h_intern(&lf[203],8,"\003syssize");
lf[204]=C_decode_literal(C_heaptop,"\376B\000\000\006vector");
lf[205]=C_h_intern(&lf[205],8,"\003sysslot");
lf[206]=C_h_intern(&lf[206],27,"\003syswith-print-length-limit");
lf[207]=C_decode_literal(C_heaptop,"\376B\000\000\005  ~s\011");
lf[208]=C_decode_literal(C_heaptop,"\376B\000\000\020  \012properties:\012\012");
lf[209]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[210]=C_decode_literal(C_heaptop,"\376B\000\000\013uninterned ");
lf[211]=C_decode_literal(C_heaptop,"\376B\000\000\027~asymbol with name ~S~%");
lf[212]=C_h_intern(&lf[212],18,"\003syssymbol->string");
lf[213]=C_h_intern(&lf[213],20,"\003sysinterned-symbol\077");
lf[214]=C_decode_literal(C_heaptop,"\376B\000\000\010keyword ");
lf[215]=C_decode_literal(C_heaptop,"\376B\000\000\010unbound ");
lf[216]=C_h_intern(&lf[216],32,"\003syssymbol-has-toplevel-binding\077");
lf[217]=C_decode_literal(C_heaptop,"\376B\000\000\004list");
lf[218]=C_decode_literal(C_heaptop,"\376B\000\000\035pair with car ~S and cdr ~S~%");
lf[219]=C_h_intern(&lf[219],15,"describe-object");
lf[220]=C_decode_literal(C_heaptop,"\376B\000\000\036procedure with code pointer ~X");
lf[221]=C_h_intern(&lf[221],25,"\003syspeek-unsigned-integer");
lf[222]=C_h_intern(&lf[222],9,"\000tinyclos");
lf[223]=C_h_intern(&lf[223],19,"\010tinyclosentity-tag");
lf[224]=C_decode_literal(C_heaptop,"\376B\000\000\005input");
lf[225]=C_decode_literal(C_heaptop,"\376B\000\000\006output");
lf[226]=C_decode_literal(C_heaptop,"\376B\000\0005~A port of type ~A with name ~S and file pointer ~X~%");
lf[227]=C_decode_literal(C_heaptop,"\376B\000\000/locative~%  pointer ~X~%  index ~A~%  type ~A~%");
lf[228]=C_decode_literal(C_heaptop,"\376B\000\000\004slot");
lf[229]=C_decode_literal(C_heaptop,"\376B\000\000\004char");
lf[230]=C_decode_literal(C_heaptop,"\376B\000\000\010u8vector");
lf[231]=C_decode_literal(C_heaptop,"\376B\000\000\010s8vector");
lf[232]=C_decode_literal(C_heaptop,"\376B\000\000\011u16vector");
lf[233]=C_decode_literal(C_heaptop,"\376B\000\000\011s16vector");
lf[234]=C_decode_literal(C_heaptop,"\376B\000\000\011u32vector");
lf[235]=C_decode_literal(C_heaptop,"\376B\000\000\011s32vector");
lf[236]=C_decode_literal(C_heaptop,"\376B\000\000\011f32vector");
lf[237]=C_decode_literal(C_heaptop,"\376B\000\000\011f64vector");
lf[238]=C_decode_literal(C_heaptop,"\376B\000\000\024machine pointer ~X~%");
lf[239]=C_h_intern(&lf[239],11,"\003csihexdump");
lf[240]=C_h_intern(&lf[240],8,"\003sysbyte");
lf[241]=C_decode_literal(C_heaptop,"\376B\000\000\022blob of size ~S:~%");
lf[242]=C_decode_literal(C_heaptop,"\376B\000\000\030lambda information: ~s~%");
lf[243]=C_h_intern(&lf[243],23,"\003syslambda-info->string");
lf[244]=C_h_intern(&lf[244],10,"hash-table");
lf[245]=C_decode_literal(C_heaptop,"\376B\000\000\013 ~S\011-> ~S~%");
lf[246]=C_h_intern(&lf[246],15,"hash-table-walk");
lf[247]=C_decode_literal(C_heaptop,"\376B\000\000\025  hash function: ~a~%");
lf[248]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[249]=C_decode_literal(C_heaptop,"\376B\000\000\001s");
lf[250]=C_decode_literal(C_heaptop,"\376B\000\000:hash-table with ~S element~a~%  comparison procedure: ~A~%");
lf[251]=C_h_intern(&lf[251],9,"condition");
lf[252]=C_decode_literal(C_heaptop,"\376B\000\000\011\011~s: ~s~%");
lf[253]=C_h_intern(&lf[253],4,"cdar");
lf[254]=C_h_intern(&lf[254],4,"caar");
lf[255]=C_decode_literal(C_heaptop,"\376B\000\000\005 ~s~%");
lf[256]=C_decode_literal(C_heaptop,"\376B\000\000\017condition: ~s~%");
lf[257]=C_h_intern(&lf[257],6,"unveil");
lf[258]=C_h_intern(&lf[258],6,"append");
lf[259]=C_decode_literal(C_heaptop,"\376B\000\000\031structure of type `~S\047:~%");
lf[260]=C_decode_literal(C_heaptop,"\376B\000\000\020unknown object~%");
lf[261]=C_h_intern(&lf[261],15,"meroon-instance");
lf[262]=C_h_intern(&lf[262],9,"provided\077");
lf[263]=C_h_intern(&lf[263],6,"meroon");
lf[264]=C_h_intern(&lf[264],15,"\003sysbytevector\077");
lf[265]=C_h_intern(&lf[265],13,"\003syslocative\077");
lf[266]=C_h_intern(&lf[266],9,"instance\077");
lf[267]=C_h_intern(&lf[267],5,"port\077");
lf[268]=C_h_intern(&lf[268],11,"\003sysnumber\077");
lf[269]=C_decode_literal(C_heaptop,"\376B\000\000\034statically allocated (0x~X) ");
lf[270]=C_h_intern(&lf[270],17,"\003sysblock-address");
lf[271]=C_h_intern(&lf[271],14,"set-describer!");
lf[272]=C_h_intern(&lf[272],16,"\003syscheck-symbol");
lf[273]=C_h_intern(&lf[273],6,"symbol");
lf[274]=C_h_intern(&lf[274],3,"min");
lf[275]=C_h_intern(&lf[275],4,"dump");
lf[276]=C_decode_literal(C_heaptop,"\376B\000\000\034cannot dump immediate object");
lf[277]=C_h_intern(&lf[277],13,"\003syspeek-byte");
lf[278]=C_decode_literal(C_heaptop,"\376B\000\000\022cannot dump object");
lf[279]=C_h_intern(&lf[279],10,"write-char");
lf[280]=C_decode_literal(C_heaptop,"\376B\000\000\003   ");
lf[281]=C_h_intern(&lf[281],5,"fxmod");
lf[282]=C_h_intern(&lf[282],11,"\003csideldups");
lf[283]=C_h_intern(&lf[283],6,"equal\077");
lf[286]=C_decode_literal(C_heaptop,"\376B\000\000\002-s");
lf[287]=C_decode_literal(C_heaptop,"\376B\000\000\003-ss");
lf[288]=C_decode_literal(C_heaptop,"\376B\000\000\007-script");
lf[289]=C_decode_literal(C_heaptop,"\376B\000\000\003-sx");
lf[290]=C_decode_literal(C_heaptop,"\376B\000\000\002--");
lf[291]=C_decode_literal(C_heaptop,"\376B\000\000\016invalid option");
lf[292]=C_h_intern(&lf[292],16,"\003sysstring->list");
lf[293]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\003-ss\376\003\000\000\002\376B\000\000\003-sx\376\003\000\000\002\376B\000\000\007-script\376\003\000\000\002\376B\000\000\010-version\376\003\000\000\002\376B\000\000\005-help\376\003\000\000"
"\002\376B\000\000\006--help\376\003\000\000\002\376B\000\000\010-feature\376\003\000\000\002\376B\000\000\005-eval\376\003\000\000\002\376B\000\000\021-case-insensitive\376\003\000\000\002\376B\000"
"\000\016-keyword-style\376\003\000\000\002\376B\000\000\030-no-parentheses-synonyms\376\003\000\000\002\376B\000\000\021-no-symbol-escape\376\003\000"
"\000\002\376B\000\000\014-r5rs-syntax\376\003\000\000\002\376B\000\000\013-setup-mode\376\003\000\000\002\376B\000\000\022-require-extension\376\003\000\000\002\376B\000\000\006-b"
"atch\376\003\000\000\002\376B\000\000\006-quiet\376\003\000\000\002\376B\000\000\014-no-warnings\376\003\000\000\002\376B\000\000\010-no-init\376\003\000\000\002\376B\000\000\015-include-p"
"ath\376\003\000\000\002\376B\000\000\010-release\376\003\000\000\002\376B\000\000\006-print\376\003\000\000\002\376B\000\000\015-pretty-print\376\003\000\000\002\376B\000\000\002--\376\377\016");
lf[294]=C_h_intern(&lf[294],7,"\003csirun");
lf[295]=C_decode_literal(C_heaptop,"\376B\000\000\047missing argument to command-line option");
lf[296]=C_h_intern(&lf[296],8,"\003syslist");
lf[297]=C_h_intern(&lf[297],17,"open-input-string");
lf[298]=C_h_intern(&lf[298],4,"repl");
lf[299]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002--\376\003\000\000\002\376B\000\000\002-b\376\003\000\000\002\376B\000\000\006-batch\376\003\000\000\002\376B\000\000\002-q\376\003\000\000\002\376B\000\000\006-quiet\376\003\000\000\002\376B\000\000\002-n"
"\376\003\000\000\002\376B\000\000\010-no-init\376\003\000\000\002\376B\000\000\002-w\376\003\000\000\002\376B\000\000\014-no-warnings\376\003\000\000\002\376B\000\000\002-i\376\003\000\000\002\376B\000\000\021-case-"
"insensitive\376\003\000\000\002\376B\000\000\030-no-parentheses-synonyms\376\003\000\000\002\376B\000\000\021-no-symbol-escape\376\003\000\000\002\376B\000"
"\000\014-r5rs-syntax\376\003\000\000\002\376B\000\000\013-setup-mode\376\003\000\000\002\376B\000\000\003-ss\376\003\000\000\002\376B\000\000\003-sx\376\003\000\000\002\376B\000\000\002-s\376\003\000\000\002\376B"
"\000\000\007-script\376\377\016");
lf[300]=C_decode_literal(C_heaptop,"\376B\000\000\002-D");
lf[301]=C_decode_literal(C_heaptop,"\376B\000\000\010-feature");
lf[302]=C_decode_literal(C_heaptop,"\376B\000\000\002-I");
lf[303]=C_decode_literal(C_heaptop,"\376B\000\000\015-include-path");
lf[304]=C_decode_literal(C_heaptop,"\376B\000\000\002-k");
lf[305]=C_decode_literal(C_heaptop,"\376B\000\000\016-keyword-style");
lf[306]=C_decode_literal(C_heaptop,"\376B\000\000\002-R");
lf[307]=C_decode_literal(C_heaptop,"\376B\000\000\022-require-extension");
lf[308]=C_h_intern(&lf[308],22,"\004corerequire-extension");
lf[309]=C_decode_literal(C_heaptop,"\376B\000\000\002-e");
lf[310]=C_decode_literal(C_heaptop,"\376B\000\000\005-eval");
lf[311]=C_decode_literal(C_heaptop,"\376B\000\000\002-p");
lf[312]=C_decode_literal(C_heaptop,"\376B\000\000\006-print");
lf[313]=C_h_intern(&lf[313],8,"for-each");
lf[314]=C_decode_literal(C_heaptop,"\376B\000\000\002-P");
lf[315]=C_decode_literal(C_heaptop,"\376B\000\000\015-pretty-print");
lf[316]=C_decode_literal(C_heaptop,"\376B\000\000\003-ss");
lf[317]=C_h_intern(&lf[317],4,"main");
lf[318]=C_h_intern(&lf[318],22,"command-line-arguments");
lf[319]=C_decode_literal(C_heaptop,"\376B\000\000\003-sx");
lf[320]=C_h_intern(&lf[320],18,"\003sysstandard-error");
lf[321]=C_h_intern(&lf[321],8,"\003sysload");
lf[322]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[323]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[324]=C_decode_literal(C_heaptop,"\376B\000\000\004HOME");
lf[325]=C_h_intern(&lf[325],17,"\003sysstring-append");
lf[326]=C_decode_literal(C_heaptop,"\376B\000\000\002./");
lf[327]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002-n\376\003\000\000\002\376B\000\000\010-no-init\376\377\016");
lf[328]=C_h_intern(&lf[328],13,"symbol-escape");
lf[329]=C_h_intern(&lf[329],20,"parentheses-synonyms");
lf[330]=C_h_intern(&lf[330],13,"keyword-style");
lf[331]=C_h_intern(&lf[331],5,"\000none");
lf[332]=C_h_intern(&lf[332],14,"case-sensitive");
lf[333]=C_decode_literal(C_heaptop,"\376B\000\000/Disabled the Chicken extensions to R5RS syntax\012");
lf[334]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\014-r5rs-syntax\376\377\016");
lf[335]=C_decode_literal(C_heaptop,"\376B\000\000%Disabled support for escaped symbols\012");
lf[336]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\021-no-symbol-escape\376\377\016");
lf[337]=C_decode_literal(C_heaptop,"\376B\000\000*Disabled support for parentheses synonyms\012");
lf[338]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\030-no-parentheses-synonyms\376\377\016");
lf[339]=C_decode_literal(C_heaptop,"\376B\000\000\006prefix");
lf[340]=C_h_intern(&lf[340],7,"\000prefix");
lf[341]=C_decode_literal(C_heaptop,"\376B\000\000\004none");
lf[342]=C_decode_literal(C_heaptop,"\376B\000\000\006suffix");
lf[343]=C_h_intern(&lf[343],7,"\000suffix");
lf[344]=C_decode_literal(C_heaptop,"\376B\000\000+missing argument to `-keyword-style\047 option");
lf[345]=C_h_intern(&lf[345],8,"string=\077");
lf[346]=C_decode_literal(C_heaptop,"\376B\000\000\002-I");
lf[347]=C_decode_literal(C_heaptop,"\376B\000\000\015-include-path");
lf[348]=C_h_intern(&lf[348],17,"register-feature!");
lf[349]=C_decode_literal(C_heaptop,"\376B\000\000\002-D");
lf[350]=C_decode_literal(C_heaptop,"\376B\000\000\010-feature");
lf[351]=C_h_intern(&lf[351],16,"case-insensitive");
lf[352]=C_decode_literal(C_heaptop,"\376B\000\000-Identifiers and symbols are case insensitive\012");
lf[353]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002-i\376\003\000\000\002\376B\000\000\021-case-insensitive\376\377\016");
lf[354]=C_h_intern(&lf[354],12,"load-verbose");
lf[355]=C_h_intern(&lf[355],20,"\003syswarnings-enabled");
lf[356]=C_decode_literal(C_heaptop,"\376B\000\000\026Warnings are disabled\012");
lf[357]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002-w\376\003\000\000\002\376B\000\000\014-no-warnings\376\377\016");
lf[358]=C_decode_literal(C_heaptop,"\376B\000\000\010-release");
lf[359]=C_decode_literal(C_heaptop,"\376B\000\000\013-setup-mode");
lf[360]=C_h_intern(&lf[360],14,"\003syssetup-mode");
lf[361]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002-v\376\003\000\000\002\376B\000\000\010-version\376\377\016");
lf[362]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002-h\376\003\000\000\002\376B\000\000\005-help\376\003\000\000\002\376B\000\000\006--help\376\377\016");
lf[363]=C_h_intern(&lf[363],20,"\003syseval-debug-level");
lf[364]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[365]=C_decode_literal(C_heaptop,"\376B\000\000\001;");
lf[366]=C_decode_literal(C_heaptop,"\376B\000\000\024CHICKEN_INCLUDE_PATH");
lf[367]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002-q\376\003\000\000\002\376B\000\000\006-quiet\376\377\016");
lf[368]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002-b\376\003\000\000\002\376B\000\000\006-batch\376\377\016");
lf[369]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002-e\376\003\000\000\002\376B\000\000\002-p\376\003\000\000\002\376B\000\000\002-P\376\003\000\000\002\376B\000\000\005-eval\376\003\000\000\002\376B\000\000\006-print\376\003\000\000\002\376B\000\000\015-pr"
"etty-print\376\377\016");
lf[370]=C_h_intern(&lf[370],20,"\003syswindows-platform");
lf[371]=C_h_intern(&lf[371],6,"script");
lf[372]=C_h_intern(&lf[372],12,"program-name");
lf[373]=C_decode_literal(C_heaptop,"\376B\000\000\042missing or invalid script argument");
lf[374]=C_decode_literal(C_heaptop,"\376B\000\000\002--");
lf[375]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\003-ss\376\003\000\000\002\376B\000\000\003-sx\376\003\000\000\002\376B\000\000\002-s\376\003\000\000\002\376B\000\000\007-script\376\377\016");
lf[376]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002-k\376\003\000\000\002\376B\000\000\016-keyword-style\376\377\016");
lf[377]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[378]=C_h_intern(&lf[378],17,"get-output-string");
lf[379]=C_h_intern(&lf[379],18,"open-output-string");
lf[380]=C_decode_literal(C_heaptop,"\376B\000\000\025invalid option syntax");
lf[381]=C_h_intern(&lf[381],7,"reverse");
lf[382]=C_h_intern(&lf[382],22,"with-exception-handler");
lf[383]=C_h_intern(&lf[383],30,"call-with-current-continuation");
lf[384]=C_decode_literal(C_heaptop,"\376B\000\000\013CSI_OPTIONS");
lf[385]=C_h_intern(&lf[385],25,"\003sysimplicit-exit-handler");
lf[386]=C_h_intern(&lf[386],11,"make-vector");
lf[387]=C_decode_literal(C_heaptop,"\376B\000\000\006#;~A> ");
lf[388]=C_h_intern(&lf[388],11,"repl-prompt");
C_register_lf2(lf,389,create_ptable());
t2=C_mutate(&lf[0] /* (set! c270 ...) */,lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1620,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t3);}

/* k1618 */
static void C_ccall f_1620(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1620,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1623,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1621 in k1618 */
static void C_ccall f_1623(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1623,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1626,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1624 in k1621 in k1618 */
static void C_ccall f_1626(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1626,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1629,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_1629(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1629,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1632,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_1632(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1632,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1635,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_1635(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1635,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1638,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_chicken_syntax_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_1638(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1638,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1641,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_1641(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1641,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1644,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_1644(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1644,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1647,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_1647(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1647,2,t0,t1);}
t2=C_mutate(&lf[2] /* (set! constant46 ...) */,lf[3]);
t3=C_set_block_item(lf[4] /* repl-print-length-limit */,0,C_fix(2048));
t4=(C_word)C_a_i_cons(&a,2,lf[5],C_retrieve(lf[6]));
t5=C_mutate((C_word*)lf[6]+1 /* (set! features ...) */,t4);
t6=C_mutate((C_word*)lf[7]+1 /* (set! print-usage ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1657,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate((C_word*)lf[14]+1 /* (set! print-banner ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1685,tmp=(C_word)a,a+=2,tmp));
t8=*((C_word*)lf[21]+1);
t9=*((C_word*)lf[22]+1);
t10=C_retrieve(lf[23]);
t11=C_mutate((C_word*)lf[23]+1 /* (set! user-read-hook ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1701,a[2]=t10,tmp=(C_word)a,a+=3,tmp));
t12=C_mutate((C_word*)lf[27]+1 /* (set! sharp-number-hook ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1734,tmp=(C_word)a,a+=2,tmp));
t13=*((C_word*)lf[28]+1);
t14=C_mutate((C_word*)lf[29]+1 /* (set! chop-separator ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1760,a[2]=t13,tmp=(C_word)a,a+=3,tmp));
t15=C_set_block_item(lf[31] /* @ */,0,C_SCHEME_FALSE);
t16=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1791,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 179  make-string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[170]+1)))(3,*((C_word*)lf[170]+1),t16,C_fix(256));}

/* k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_1791(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[50],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1791,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1810,tmp=(C_word)a,a+=2,tmp);
t3=C_mutate((C_word*)lf[35]+1 /* (set! lookup-script-file ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1858,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t4=C_SCHEME_UNDEFINED;
t5=(C_word)C_a_i_vector(&a,32,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4);
t6=C_mutate((C_word*)lf[43]+1 /* (set! history-list ...) */,t5);
t7=C_set_block_item(lf[25] /* history-count */,0,C_fix(1));
t8=C_retrieve(lf[44]);
t9=C_mutate((C_word*)lf[45]+1 /* (set! history-add ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1964,a[2]=t8,tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[26]+1 /* (set! history-ref ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2003,tmp=(C_word)a,a+=2,tmp));
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2028,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t12=C_retrieve(lf[181]);
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5654,a[2]=t12,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 231  repl-prompt */
((C_proc3)C_retrieve_symbol_proc(lf[388]))(3,*((C_word*)lf[388]+1),t11,t13);}

/* a5653 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_5654(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5654,2,t0,t1);}
/* csi.scm: 234  sprintf */
t2=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,lf[387],C_retrieve(lf[25]));}

/* k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_2028(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2028,2,t0,t1);}
t2=C_mutate((C_word*)lf[49]+1 /* (set! tty-input? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2030,tmp=(C_word)a,a+=2,tmp));
t3=C_set_block_item(lf[52] /* break-on-error */,0,C_SCHEME_FALSE);
t4=C_retrieve(lf[53]);
t5=C_mutate((C_word*)lf[53]+1 /* (set! read-prompt-hook ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2043,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2057,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 246  make-vector */
((C_proc4)C_retrieve_proc(*((C_word*)lf[386]+1)))(4,*((C_word*)lf[386]+1),t6,C_fix(37),C_SCHEME_END_OF_LIST);}

/* k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_2057(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word ab[37],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2057,2,t0,t1);}
t2=C_mutate(&lf[54] /* (set! command-table ...) */,t1);
t3=C_mutate((C_word*)lf[55]+1 /* (set! toplevel-command ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2059,tmp=(C_word)a,a+=2,tmp));
t4=C_retrieve(lf[57]);
t5=C_retrieve(lf[58]);
t6=*((C_word*)lf[22]+1);
t7=C_retrieve(lf[59]);
t8=C_retrieve(lf[60]);
t9=*((C_word*)lf[61]+1);
t10=*((C_word*)lf[8]+1);
t11=*((C_word*)lf[62]+1);
t12=C_retrieve(lf[38]);
t13=C_retrieve(lf[63]);
t14=C_retrieve(lf[64]);
t15=C_retrieve(lf[65]);
t16=*((C_word*)lf[66]+1);
t17=*((C_word*)lf[67]+1);
t18=C_mutate((C_word*)lf[68]+1 /* (set! repl-eval-hook ...) */,(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2100,a[2]=t7,a[3]=t10,a[4]=t13,a[5]=t17,a[6]=t5,a[7]=t8,a[8]=t12,a[9]=t4,a[10]=t6,a[11]=t14,a[12]=t15,tmp=(C_word)a,a+=13,tmp));
t19=C_mutate(&lf[103] /* (set! resolve-var ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2650,tmp=(C_word)a,a+=2,tmp));
t20=C_mutate((C_word*)lf[105]+1 /* (set! del ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2664,tmp=(C_word)a,a+=2,tmp));
t21=C_set_block_item(lf[69] /* trace-indent-level */,0,C_fix(0));
t22=lf[94] /* traced-procedures */ =C_SCHEME_END_OF_LIST;;
t23=lf[97] /* broken-procedures */ =C_SCHEME_END_OF_LIST;;
t24=C_mutate(&lf[143] /* (set! trace-indent ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2705,tmp=(C_word)a,a+=2,tmp));
t25=C_mutate((C_word*)lf[100]+1 /* (set! traced-procedure-entry ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2733,tmp=(C_word)a,a+=2,tmp));
t26=C_mutate((C_word*)lf[99]+1 /* (set! traced-procedure-exit ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2756,tmp=(C_word)a,a+=2,tmp));
t27=C_mutate((C_word*)lf[116]+1 /* (set! do-unbreak-all ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3047,tmp=(C_word)a,a+=2,tmp));
t28=C_retrieve(lf[63]);
t29=C_retrieve(lf[150]);
t30=C_retrieve(lf[151]);
t31=C_retrieve(lf[152]);
t32=*((C_word*)lf[153]+1);
t33=C_mutate((C_word*)lf[80]+1 /* (set! report ...) */,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3174,a[2]=t32,a[3]=t31,a[4]=t30,a[5]=t29,a[6]=t28,tmp=(C_word)a,a+=7,tmp));
t34=C_mutate(&lf[178] /* (set! bytevector-data ...) */,lf[179]);
t35=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3368,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 608  make-vector */
((C_proc4)C_retrieve_proc(*((C_word*)lf[386]+1)))(4,*((C_word*)lf[386]+1),t35,C_fix(37),C_SCHEME_END_OF_LIST);}

/* k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_3368(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3368,2,t0,t1);}
t2=C_mutate(&lf[180] /* (set! describer-table ...) */,t1);
t3=C_retrieve(lf[181]);
t4=C_retrieve(lf[63]);
t5=C_retrieve(lf[182]);
t6=*((C_word*)lf[61]+1);
t7=*((C_word*)lf[183]+1);
t8=*((C_word*)lf[184]+1);
t9=C_mutate((C_word*)lf[75]+1 /* (set! describe ...) */,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3370,a[2]=t3,a[3]=t7,a[4]=t6,a[5]=t8,a[6]=t5,tmp=(C_word)a,a+=7,tmp));
t10=C_mutate((C_word*)lf[271]+1 /* (set! set-describer! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4189,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate((C_word*)lf[77]+1 /* (set! dump ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4198,tmp=(C_word)a,a+=2,tmp));
t12=*((C_word*)lf[8]+1);
t13=*((C_word*)lf[33]+1);
t14=*((C_word*)lf[170]+1);
t15=*((C_word*)lf[279]+1);
t16=C_mutate((C_word*)lf[239]+1 /* (set! hexdump ...) */,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4359,a[2]=t12,a[3]=t15,a[4]=t14,a[5]=t13,tmp=(C_word)a,a+=6,tmp));
t17=C_mutate((C_word*)lf[282]+1 /* (set! deldups ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4568,tmp=(C_word)a,a+=2,tmp));
t18=C_mutate(&lf[284] /* (set! member* ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4627,tmp=(C_word)a,a+=2,tmp));
t19=C_mutate(&lf[285] /* (set! canonicalize-args ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4684,tmp=(C_word)a,a+=2,tmp));
t20=C_mutate((C_word*)lf[294]+1 /* (set! run ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4829,tmp=(C_word)a,a+=2,tmp));
t21=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5646,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 1015 run */
((C_proc2)C_retrieve_symbol_proc(lf[294]))(2,*((C_word*)lf[294]+1),t21);}

/* k5644 in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_5646(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5646,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5649,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5652,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#implicit-exit-handler */
((C_proc2)C_retrieve_symbol_proc(lf[385]))(2,*((C_word*)lf[385]+1),t3);}

/* k5650 in k5644 in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_5652(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k5647 in k5644 in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_5649(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* ##csi#run in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_4829(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4829,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4833,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5640,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 876  get-environment-variable */
((C_proc3)C_retrieve_symbol_proc(lf[41]))(3,*((C_word*)lf[41]+1),t3,lf[384]);}

/* k5638 in ##csi#run in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_5640(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5640,2,t0,t1);}
t2=(C_truep(t1)?t1:lf[377]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3075,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 526  open-input-string */
((C_proc3)C_retrieve_symbol_proc(lf[297]))(3,*((C_word*)lf[297]+1),t3,t2);}

/* k3073 in k5638 in ##csi#run in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_3075(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3075,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3080,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3100,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3103,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3105,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* call-with-current-continuation */
((C_proc3)C_retrieve_proc(*((C_word*)lf[383]+1)))(3,*((C_word*)lf[383]+1),t4,t5);}

/* a3104 in k3073 in k5638 in ##csi#run in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_3105(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3105,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3111,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3123,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* with-exception-handler */
((C_proc4)C_retrieve_symbol_proc(lf[382]))(4,*((C_word*)lf[382]+1),t1,t3,t4);}

/* a3122 in a3104 in k3073 in k5638 in ##csi#run in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_3123(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3123,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3129,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3162,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a3161 in a3122 in a3104 in k3073 in k5638 in ##csi#run in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_3162(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_3162r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3162r(t0,t1,t2);}}

static void C_ccall f_3162r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3168,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* k617622 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a3167 in a3161 in a3122 in a3104 in k3073 in k5638 in ##csi#run in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_3168(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3168,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a3128 in a3122 in a3104 in k3073 in k5638 in ##csi#run in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_3129(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3129,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3137,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 534  read */
((C_proc3)C_retrieve_proc(*((C_word*)lf[22]+1)))(3,*((C_word*)lf[22]+1),t2,((C_word*)t0)[2]);}

/* k3135 in a3128 in a3122 in a3104 in k3073 in k5638 in ##csi#run in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_3137(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3137,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3139,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_3139(t5,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* doloop628 in k3135 in a3128 in a3122 in a3104 in k3073 in k5638 in ##csi#run in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_fcall f_3139(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3139,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_eofp(t2))){
/* csi.scm: 536  reverse */
((C_proc3)C_retrieve_proc(*((C_word*)lf[381]+1)))(3,*((C_word*)lf[381]+1),t1,t3);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3156,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 534  read */
((C_proc3)C_retrieve_proc(*((C_word*)lf[22]+1)))(3,*((C_word*)lf[22]+1),t4,((C_word*)t0)[2]);}}

/* k3154 in doloop628 in k3135 in a3128 in a3122 in a3104 in k3073 in k5638 in ##csi#run in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_3156(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3156,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[4]);
t3=((C_word*)((C_word*)t0)[3])[1];
f_3139(t3,((C_word*)t0)[2],t1,t2);}

/* a3110 in a3104 in k3073 in k5638 in ##csi#run in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_3111(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3111,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3117,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* k617622 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a3116 in a3110 in a3104 in k3073 in k5638 in ##csi#run in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_3117(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3117,2,t0,t1);}
/* csi.scm: 533  ##sys#error */
t2=*((C_word*)lf[47]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[380],((C_word*)t0)[2]);}

/* k3101 in k3073 in k5638 in ##csi#run in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_3103(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k3098 in k3073 in k5638 in ##csi#run in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_3100(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[102]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a3079 in k3073 in k5638 in ##csi#run in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_3080(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3080,3,t0,t1,t2);}
if(C_truep((C_word)C_i_stringp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3090,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 530  open-output-string */
((C_proc2)C_retrieve_symbol_proc(lf[379]))(2,*((C_word*)lf[379]+1),t3);}}

/* k3088 in a3079 in k3073 in k5638 in ##csi#run in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_3090(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3090,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3093,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 531  write */
((C_proc4)C_retrieve_proc(*((C_word*)lf[62]+1)))(4,*((C_word*)lf[62]+1),t2,((C_word*)t0)[2],t1);}

/* k3091 in k3088 in a3079 in k3073 in k5638 in ##csi#run in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_3093(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 532  get-output-string */
((C_proc3)C_retrieve_symbol_proc(lf[378]))(3,*((C_word*)lf[378]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4831 in ##csi#run in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_4833(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4833,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4836,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5636,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 877  command-line-arguments */
((C_proc2)C_retrieve_symbol_proc(lf[318]))(2,*((C_word*)lf[318]+1),t3);}

/* k5634 in k4831 in ##csi#run in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_5636(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 877  canonicalize-args */
f_4684(((C_word*)t0)[2],t1);}

/* k4834 in k4831 in ##csi#run in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_4836(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4836,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4839,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 879  member* */
f_4627(t4,lf[376],((C_word*)t3)[1]);}

/* k4837 in k4834 in k4831 in ##csi#run in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_4839(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4839,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4842,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 880  member* */
f_4627(t2,lf[375],((C_word*)((C_word*)t0)[4])[1]);}

/* k4840 in k4837 in k4834 in k4831 in ##csi#run in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_4842(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4842,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4845,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5529,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cdr(t1);
t5=(C_word)C_i_pairp(t4);
t6=(C_word)C_i_not(t5);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5579,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep(t6)){
t8=t7;
f_5579(t8,t6);}
else{
t8=(C_word)C_i_cadr(t1);
t9=(C_word)C_i_string_length(t8);
t10=(C_word)C_i_zerop(t9);
if(C_truep(t10)){
t11=t7;
f_5579(t11,t10);}
else{
t11=(C_word)C_i_cadr(t1);
t12=(C_word)C_i_string_ref(t11,C_fix(0));
t13=t7;
f_5579(t13,(C_word)C_eqp(C_make_character(45),t12));}}}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5619,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5632,a[2]=((C_word*)t0)[5],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 894  canonicalize-args */
f_4684(t4,((C_word*)t0)[2]);}}

/* k5630 in k4840 in k4837 in k4834 in k4831 in ##csi#run in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_5632(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 894  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[258]+1)))(4,*((C_word*)lf[258]+1),((C_word*)t0)[3],t1,((C_word*)((C_word*)t0)[2])[1]);}

/* k5617 in k4840 in k4837 in k4834 in k4831 in ##csi#run in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_5619(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=(C_word)C_i_member(lf[374],((C_word*)((C_word*)t0)[3])[1]);
t4=((C_word*)t0)[2];
f_4845(t4,(C_truep(t3)?(C_word)C_i_set_cdr(t3,C_SCHEME_END_OF_LIST):C_SCHEME_FALSE));}

/* k5577 in k4840 in k4837 in k4834 in k4831 in ##csi#run in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_fcall f_5579(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* csi.scm: 885  ##sys#error */
t2=*((C_word*)lf[47]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],lf[373]);}
else{
t2=((C_word*)t0)[2];
f_5529(2,t2,C_SCHEME_UNDEFINED);}}

/* k5527 in k4840 in k4837 in k4834 in k4831 in ##csi#run in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_5529(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5529,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5532,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[3]);
/* csi.scm: 886  program-name */
((C_proc3)C_retrieve_symbol_proc(lf[372]))(3,*((C_word*)lf[372]+1),t2,t3);}

/* k5530 in k5527 in k4840 in k4837 in k4834 in k4831 in ##csi#run in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_5532(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5532,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5535,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cddr(((C_word*)t0)[3]);
/* csi.scm: 887  command-line-arguments */
((C_proc3)C_retrieve_symbol_proc(lf[318]))(3,*((C_word*)lf[318]+1),t2,t3);}

/* k5533 in k5530 in k5527 in k4840 in k4837 in k4834 in k4831 in ##csi#run in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_5535(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5535,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5538,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 888  register-feature! */
((C_proc3)C_retrieve_symbol_proc(lf[348]))(3,*((C_word*)lf[348]+1),t2,lf[371]);}

/* k5536 in k5533 in k5530 in k5527 in k4840 in k4837 in k4834 in k4831 in ##csi#run in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_5538(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5538,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
t3=(C_word)C_i_set_cdr(t2,C_SCHEME_END_OF_LIST);
if(C_truep(*((C_word*)lf[370]+1))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5547,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_cadr(((C_word*)t0)[3]);
/* csi.scm: 891  lookup-script-file */
((C_proc3)C_retrieve_symbol_proc(lf[35]))(3,*((C_word*)lf[35]+1),t4,t5);}
else{
t4=((C_word*)t0)[2];
f_4845(t4,C_SCHEME_UNDEFINED);}}

/* k5545 in k5536 in k5533 in k5530 in k5527 in k4840 in k4837 in k4834 in k4831 in ##csi#run in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_5547(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
f_4845(t3,(C_word)C_i_set_car(t2,t1));}
else{
t2=((C_word*)t0)[2];
f_4845(t2,C_SCHEME_FALSE);}}

/* k4843 in k4840 in k4837 in k4834 in k4831 in ##csi#run in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_fcall f_4845(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4845,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4848,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 897  member* */
f_4627(t2,lf[369],((C_word*)((C_word*)t0)[4])[1]);}

/* k4846 in k4843 in k4840 in k4837 in k4834 in k4831 in ##csi#run in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_4848(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4848,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4851,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[5])){
t3=t2;
f_4851(t3,((C_word*)t0)[5]);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5523,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 898  member* */
f_4627(t3,lf[368],((C_word*)((C_word*)t0)[4])[1]);}}

/* k5521 in k4846 in k4843 in k4840 in k4837 in k4834 in k4831 in ##csi#run in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_5523(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_4851(t2,(C_truep(t1)?t1:((C_word*)t0)[2]));}

/* k4849 in k4846 in k4843 in k4840 in k4837 in k4834 in k4831 in ##csi#run in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_fcall f_4851(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4851,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4854,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* csi.scm: 899  member* */
f_4627(t2,lf[367],((C_word*)((C_word*)t0)[4])[1]);}

/* k4852 in k4849 in k4846 in k4843 in k4840 in k4837 in k4834 in k4831 in ##csi#run in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_4854(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4854,2,t0,t1);}
t2=(C_truep(((C_word*)t0)[7])?((C_word*)t0)[7]:(C_truep(t1)?t1:((C_word*)t0)[6]));
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4860,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5510,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5514,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 901  get-environment-variable */
((C_proc3)C_retrieve_symbol_proc(lf[41]))(3,*((C_word*)lf[41]+1),t5,lf[366]);}

/* k5512 in k4852 in k4849 in k4846 in k4843 in k4840 in k4837 in k4834 in k4831 in ##csi#run in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_5514(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?t1:lf[364]);
/* csi.scm: 901  string-split */
((C_proc4)C_retrieve_symbol_proc(lf[38]))(4,*((C_word*)lf[38]+1),((C_word*)t0)[2],t2,lf[365]);}

/* k5508 in k4852 in k4849 in k4846 in k4843 in k4840 in k4837 in k4834 in k4831 in ##csi#run in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_5510(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[102]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve(lf[29]),t1);}

/* k4858 in k4852 in k4849 in k4846 in k4843 in k4840 in k4837 in k4834 in k4831 in ##csi#run in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_4860(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4860,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4862,a[2]=((C_word*)t0)[8],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4942,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5012,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=t3,a[10]=((C_word*)t0)[7],tmp=(C_word)a,a+=11,tmp);
if(C_truep(((C_word*)t0)[2])){
t5=C_set_block_item(lf[363] /* eval-debug-level */,0,C_fix(0));
t6=t4;
f_5012(t6,t5);}
else{
t5=t4;
f_5012(t5,C_SCHEME_UNDEFINED);}}

/* k5010 in k4858 in k4852 in k4849 in k4846 in k4843 in k4840 in k4837 in k4834 in k4831 in ##csi#run in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_fcall f_5012(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5012,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5015,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5499,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 924  member* */
f_4627(t3,lf[362],((C_word*)((C_word*)t0)[6])[1]);}

/* k5497 in k5010 in k4858 in k4852 in k4849 in k4846 in k4843 in k4840 in k4837 in k4834 in k4831 in ##csi#run in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_5499(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5499,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5502,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 925  print-usage */
((C_proc2)C_retrieve_symbol_proc(lf[7]))(2,*((C_word*)lf[7]+1),t2);}
else{
t2=((C_word*)t0)[2];
f_5015(2,t2,C_SCHEME_UNDEFINED);}}

/* k5500 in k5497 in k5010 in k4858 in k4852 in k4849 in k4846 in k4843 in k4840 in k4837 in k4834 in k4831 in ##csi#run in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_5502(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 926  exit */
((C_proc3)C_retrieve_symbol_proc(lf[70]))(3,*((C_word*)lf[70]+1),((C_word*)t0)[2],C_fix(0));}

/* k5013 in k5010 in k4858 in k4852 in k4849 in k4846 in k4843 in k4840 in k4837 in k4834 in k4831 in ##csi#run in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_5015(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5015,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5018,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5490,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 927  member* */
f_4627(t3,lf[361],((C_word*)((C_word*)t0)[6])[1]);}

/* k5488 in k5013 in k5010 in k4858 in k4852 in k4849 in k4846 in k4843 in k4840 in k4837 in k4834 in k4831 in ##csi#run in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_5490(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5490,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5493,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 928  print-banner */
((C_proc2)C_retrieve_symbol_proc(lf[14]))(2,*((C_word*)lf[14]+1),t2);}
else{
t2=((C_word*)t0)[2];
f_5018(2,t2,C_SCHEME_UNDEFINED);}}

/* k5491 in k5488 in k5013 in k5010 in k4858 in k4852 in k4849 in k4846 in k4843 in k4840 in k4837 in k4834 in k4831 in ##csi#run in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_5493(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 929  exit */
((C_proc3)C_retrieve_symbol_proc(lf[70]))(3,*((C_word*)lf[70]+1),((C_word*)t0)[2],C_fix(0));}

/* k5016 in k5013 in k5010 in k4858 in k4852 in k4849 in k4846 in k4843 in k4840 in k4837 in k4834 in k4831 in ##csi#run in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_5018(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5018,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5021,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
if(C_truep((C_word)C_i_member(lf[359],((C_word*)((C_word*)t0)[6])[1]))){
t3=C_set_block_item(lf[360] /* setup-mode */,0,C_SCHEME_TRUE);
t4=t2;
f_5021(t4,t3);}
else{
t3=t2;
f_5021(t3,C_SCHEME_UNDEFINED);}}

/* k5019 in k5016 in k5013 in k5010 in k4858 in k4852 in k4849 in k4846 in k4843 in k4840 in k4837 in k4834 in k4831 in ##csi#run in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_fcall f_5021(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5021,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5024,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
if(C_truep((C_word)C_i_member(lf[358],((C_word*)((C_word*)t0)[6])[1]))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5476,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5483,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 933  chicken-version */
((C_proc2)C_retrieve_symbol_proc(lf[18]))(2,*((C_word*)lf[18]+1),t4);}
else{
t3=t2;
f_5024(2,t3,C_SCHEME_UNDEFINED);}}

/* k5481 in k5019 in k5016 in k5013 in k5010 in k4858 in k4852 in k4849 in k4846 in k4843 in k4840 in k4837 in k4834 in k4831 in ##csi#run in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_5483(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 933  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[15]+1)))(3,*((C_word*)lf[15]+1),((C_word*)t0)[2],t1);}

/* k5474 in k5019 in k5016 in k5013 in k5010 in k4858 in k4852 in k4849 in k4846 in k4843 in k4840 in k4837 in k4834 in k4831 in ##csi#run in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_5476(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 934  exit */
((C_proc3)C_retrieve_symbol_proc(lf[70]))(3,*((C_word*)lf[70]+1),((C_word*)t0)[2],C_fix(0));}

/* k5022 in k5019 in k5016 in k5013 in k5010 in k4858 in k4852 in k4849 in k4846 in k4843 in k4840 in k4837 in k4834 in k4831 in ##csi#run in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_5024(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5024,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5027,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5463,a[2]=((C_word*)t0)[5],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 935  member* */
f_4627(t3,lf[357],((C_word*)((C_word*)t0)[6])[1]);}

/* k5461 in k5022 in k5019 in k5016 in k5013 in k5010 in k4858 in k4852 in k4849 in k4846 in k4843 in k4840 in k4837 in k4834 in k4831 in ##csi#run in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_5463(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5463,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5466,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=t2;
f_5466(2,t3,C_SCHEME_UNDEFINED);}
else{
/* csi.scm: 936  display */
((C_proc3)C_retrieve_proc(*((C_word*)lf[8]+1)))(3,*((C_word*)lf[8]+1),t2,lf[356]);}}
else{
t2=((C_word*)t0)[3];
f_5027(t2,C_SCHEME_UNDEFINED);}}

/* k5464 in k5461 in k5022 in k5019 in k5016 in k5013 in k5010 in k4858 in k4852 in k4849 in k4846 in k4843 in k4840 in k4837 in k4834 in k4831 in ##csi#run in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_5466(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_set_block_item(lf[355] /* warnings-enabled */,0,C_SCHEME_FALSE);
t3=((C_word*)t0)[2];
f_5027(t3,t2);}

/* k5025 in k5022 in k5019 in k5016 in k5013 in k5010 in k4858 in k4852 in k4849 in k4846 in k4843 in k4840 in k4837 in k4834 in k4831 in ##csi#run in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_fcall f_5027(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5027,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5030,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
if(C_truep(((C_word*)t0)[5])){
t3=t2;
f_5030(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5457,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 939  load-verbose */
((C_proc3)C_retrieve_symbol_proc(lf[354]))(3,*((C_word*)lf[354]+1),t3,C_SCHEME_TRUE);}}

/* k5455 in k5025 in k5022 in k5019 in k5016 in k5013 in k5010 in k4858 in k4852 in k4849 in k4846 in k4843 in k4840 in k4837 in k4834 in k4831 in ##csi#run in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_5457(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 940  print-banner */
((C_proc2)C_retrieve_symbol_proc(lf[14]))(2,*((C_word*)lf[14]+1),((C_word*)t0)[2]);}

/* k5028 in k5025 in k5022 in k5019 in k5016 in k5013 in k5010 in k4858 in k4852 in k4849 in k4846 in k4843 in k4840 in k4837 in k4834 in k4831 in ##csi#run in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_5030(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5030,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5033,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5442,a[2]=((C_word*)t0)[5],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 941  member* */
f_4627(t3,lf[353],((C_word*)((C_word*)t0)[6])[1]);}

/* k5440 in k5028 in k5025 in k5022 in k5019 in k5016 in k5013 in k5010 in k4858 in k4852 in k4849 in k4846 in k4843 in k4840 in k4837 in k4834 in k4831 in ##csi#run in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_5442(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5442,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5445,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=t2;
f_5445(2,t3,C_SCHEME_UNDEFINED);}
else{
/* csi.scm: 942  display */
((C_proc3)C_retrieve_proc(*((C_word*)lf[8]+1)))(3,*((C_word*)lf[8]+1),t2,lf[352]);}}
else{
t2=((C_word*)t0)[3];
f_5033(2,t2,C_SCHEME_UNDEFINED);}}

/* k5443 in k5440 in k5028 in k5025 in k5022 in k5019 in k5016 in k5013 in k5010 in k4858 in k4852 in k4849 in k4846 in k4843 in k4840 in k4837 in k4834 in k4831 in ##csi#run in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_5445(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5445,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5448,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 943  register-feature! */
((C_proc3)C_retrieve_symbol_proc(lf[348]))(3,*((C_word*)lf[348]+1),t2,lf[351]);}

/* k5446 in k5443 in k5440 in k5028 in k5025 in k5022 in k5019 in k5016 in k5013 in k5010 in k4858 in k4852 in k4849 in k4846 in k4843 in k4840 in k4837 in k4834 in k4831 in ##csi#run in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_5448(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 944  case-sensitive */
((C_proc3)C_retrieve_symbol_proc(lf[332]))(3,*((C_word*)lf[332]+1),((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k5031 in k5028 in k5025 in k5022 in k5019 in k5016 in k5013 in k5010 in k4858 in k4852 in k4849 in k4846 in k4843 in k4840 in k4837 in k4834 in k4831 in ##csi#run in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_5033(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5033,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5036,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5439,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 945  collect-options */
t4=((C_word*)t0)[2];
f_4862(t4,t3,lf[350]);}

/* k5437 in k5031 in k5028 in k5025 in k5022 in k5019 in k5016 in k5013 in k5010 in k4858 in k4852 in k4849 in k4846 in k4843 in k4840 in k4837 in k4834 in k4831 in ##csi#run in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_5439(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[83]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve(lf[348]),t1);}

/* k5034 in k5031 in k5028 in k5025 in k5022 in k5019 in k5016 in k5013 in k5010 in k4858 in k4852 in k4849 in k4846 in k4843 in k4840 in k4837 in k4834 in k4831 in ##csi#run in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_5036(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5036,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5039,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5435,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 946  collect-options */
t4=((C_word*)t0)[2];
f_4862(t4,t3,lf[349]);}

/* k5433 in k5034 in k5031 in k5028 in k5025 in k5022 in k5019 in k5016 in k5013 in k5010 in k4858 in k4852 in k4849 in k4846 in k4843 in k4840 in k4837 in k4834 in k4831 in ##csi#run in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_5435(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[83]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve(lf[348]),t1);}

/* k5037 in k5034 in k5031 in k5028 in k5025 in k5022 in k5019 in k5016 in k5013 in k5010 in k4858 in k4852 in k4849 in k4846 in k4843 in k4840 in k4837 in k4834 in k4831 in ##csi#run in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_5039(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5039,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5043,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5415,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5419,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5431,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 949  collect-options */
t6=((C_word*)t0)[2];
f_4862(t6,t5,lf[347]);}

/* k5429 in k5037 in k5034 in k5031 in k5028 in k5025 in k5022 in k5019 in k5016 in k5013 in k5010 in k4858 in k4852 in k4849 in k4846 in k4843 in k4840 in k4837 in k4834 in k4831 in ##csi#run in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_5431(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[102]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve(lf[29]),t1);}

/* k5417 in k5037 in k5034 in k5031 in k5028 in k5025 in k5022 in k5019 in k5016 in k5013 in k5010 in k4858 in k4852 in k4849 in k4846 in k4843 in k4840 in k4837 in k4834 in k4831 in ##csi#run in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_5419(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5419,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5423,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5427,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 950  collect-options */
t4=((C_word*)t0)[2];
f_4862(t4,t3,lf[346]);}

/* k5425 in k5417 in k5037 in k5034 in k5031 in k5028 in k5025 in k5022 in k5019 in k5016 in k5013 in k5010 in k4858 in k4852 in k4849 in k4846 in k4843 in k4840 in k4837 in k4834 in k4831 in ##csi#run in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_5427(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[102]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve(lf[29]),t1);}

/* k5421 in k5417 in k5037 in k5034 in k5031 in k5028 in k5025 in k5022 in k5019 in k5016 in k5013 in k5010 in k4858 in k4852 in k4849 in k4846 in k4843 in k4840 in k4837 in k4834 in k4831 in ##csi#run in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_5423(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 949  append */
((C_proc6)C_retrieve_proc(*((C_word*)lf[258]+1)))(6,*((C_word*)lf[258]+1),((C_word*)t0)[4],((C_word*)t0)[3],t1,C_retrieve(lf[164]),((C_word*)t0)[2]);}

/* k5413 in k5037 in k5034 in k5031 in k5028 in k5025 in k5022 in k5019 in k5016 in k5013 in k5010 in k4858 in k4852 in k4849 in k4846 in k4843 in k4840 in k4837 in k4834 in k4831 in ##csi#run in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_5415(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 948  deldups */
((C_proc4)C_retrieve_symbol_proc(lf[282]))(4,*((C_word*)lf[282]+1),((C_word*)t0)[2],t1,*((C_word*)lf[345]+1));}

/* k5041 in k5037 in k5034 in k5031 in k5028 in k5025 in k5022 in k5019 in k5016 in k5013 in k5010 in k4858 in k4852 in k4849 in k4846 in k4843 in k4840 in k4837 in k4834 in k4831 in ##csi#run in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_5043(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5043,2,t0,t1);}
t2=C_mutate((C_word*)lf[164]+1 /* (set! include-pathnames ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5046,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[2])){
t4=(C_word)C_i_cdr(((C_word*)t0)[2]);
if(C_truep((C_word)C_i_pairp(t4))){
t5=(C_word)C_i_cadr(((C_word*)t0)[2]);
if(C_truep((C_word)C_i_string_equal_p(lf[339],t5))){
/* csi.scm: 958  keyword-style */
((C_proc3)C_retrieve_symbol_proc(lf[330]))(3,*((C_word*)lf[330]+1),t3,lf[340]);}
else{
t6=(C_word)C_i_cadr(((C_word*)t0)[2]);
if(C_truep((C_word)C_i_string_equal_p(lf[341],t6))){
/* csi.scm: 960  keyword-style */
((C_proc3)C_retrieve_symbol_proc(lf[330]))(3,*((C_word*)lf[330]+1),t3,lf[331]);}
else{
t7=(C_word)C_i_cadr(((C_word*)t0)[2]);
if(C_truep((C_word)C_i_string_equal_p(lf[342],t7))){
/* csi.scm: 962  keyword-style */
((C_proc3)C_retrieve_symbol_proc(lf[330]))(3,*((C_word*)lf[330]+1),t3,lf[343]);}
else{
t8=t3;
f_5046(2,t8,C_SCHEME_UNDEFINED);}}}}
else{
/* csi.scm: 956  ##sys#error */
t5=*((C_word*)lf[47]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,lf[344]);}}
else{
t4=t3;
f_5046(2,t4,C_SCHEME_UNDEFINED);}}

/* k5044 in k5041 in k5037 in k5034 in k5031 in k5028 in k5025 in k5022 in k5019 in k5016 in k5013 in k5010 in k4858 in k4852 in k4849 in k4846 in k4843 in k4840 in k4837 in k4834 in k4831 in ##csi#run in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_5046(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5046,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5049,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5346,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 963  member* */
f_4627(t3,lf[338],((C_word*)((C_word*)t0)[3])[1]);}

/* k5344 in k5044 in k5041 in k5037 in k5034 in k5031 in k5028 in k5025 in k5022 in k5019 in k5016 in k5013 in k5010 in k4858 in k4852 in k4849 in k4846 in k4843 in k4840 in k4837 in k4834 in k4831 in ##csi#run in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_5346(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5346,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5349,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=t2;
f_5349(2,t3,C_SCHEME_UNDEFINED);}
else{
/* csi.scm: 964  display */
((C_proc3)C_retrieve_proc(*((C_word*)lf[8]+1)))(3,*((C_word*)lf[8]+1),t2,lf[337]);}}
else{
t2=((C_word*)t0)[3];
f_5049(2,t2,C_SCHEME_UNDEFINED);}}

/* k5347 in k5344 in k5044 in k5041 in k5037 in k5034 in k5031 in k5028 in k5025 in k5022 in k5019 in k5016 in k5013 in k5010 in k4858 in k4852 in k4849 in k4846 in k4843 in k4840 in k4837 in k4834 in k4831 in ##csi#run in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_5349(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 965  parentheses-synonyms */
((C_proc3)C_retrieve_symbol_proc(lf[329]))(3,*((C_word*)lf[329]+1),((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k5047 in k5044 in k5041 in k5037 in k5034 in k5031 in k5028 in k5025 in k5022 in k5019 in k5016 in k5013 in k5010 in k4858 in k4852 in k4849 in k4846 in k4843 in k4840 in k4837 in k4834 in k4831 in ##csi#run in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_5049(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5049,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5052,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5334,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 966  member* / */
f_4627(t3,lf[336],((C_word*)((C_word*)t0)[3])[1]);}

/* k5332 in k5047 in k5044 in k5041 in k5037 in k5034 in k5031 in k5028 in k5025 in k5022 in k5019 in k5016 in k5013 in k5010 in k4858 in k4852 in k4849 in k4846 in k4843 in k4840 in k4837 in k4834 in k4831 in ##csi#run in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_5334(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5334,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5337,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=t2;
f_5337(2,t3,C_SCHEME_UNDEFINED);}
else{
/* csi.scm: 967  display */
((C_proc3)C_retrieve_proc(*((C_word*)lf[8]+1)))(3,*((C_word*)lf[8]+1),t2,lf[335]);}}
else{
t2=((C_word*)t0)[3];
f_5052(2,t2,C_SCHEME_UNDEFINED);}}

/* k5335 in k5332 in k5047 in k5044 in k5041 in k5037 in k5034 in k5031 in k5028 in k5025 in k5022 in k5019 in k5016 in k5013 in k5010 in k4858 in k4852 in k4849 in k4846 in k4843 in k4840 in k4837 in k4834 in k4831 in ##csi#run in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_5337(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 968  symbol-escape */
((C_proc3)C_retrieve_symbol_proc(lf[328]))(3,*((C_word*)lf[328]+1),((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k5050 in k5047 in k5044 in k5041 in k5037 in k5034 in k5031 in k5028 in k5025 in k5022 in k5019 in k5016 in k5013 in k5010 in k4858 in k4852 in k4849 in k4846 in k4843 in k4840 in k4837 in k4834 in k4831 in ##csi#run in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_5052(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5052,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5055,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5313,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 969  member* */
f_4627(t3,lf[334],((C_word*)((C_word*)t0)[3])[1]);}

/* k5311 in k5050 in k5047 in k5044 in k5041 in k5037 in k5034 in k5031 in k5028 in k5025 in k5022 in k5019 in k5016 in k5013 in k5010 in k4858 in k4852 in k4849 in k4846 in k4843 in k4840 in k4837 in k4834 in k4831 in ##csi#run in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_5313(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5313,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5316,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=t2;
f_5316(2,t3,C_SCHEME_UNDEFINED);}
else{
/* csi.scm: 970  display */
((C_proc3)C_retrieve_proc(*((C_word*)lf[8]+1)))(3,*((C_word*)lf[8]+1),t2,lf[333]);}}
else{
t2=((C_word*)t0)[3];
f_5055(2,t2,C_SCHEME_UNDEFINED);}}

/* k5314 in k5311 in k5050 in k5047 in k5044 in k5041 in k5037 in k5034 in k5031 in k5028 in k5025 in k5022 in k5019 in k5016 in k5013 in k5010 in k4858 in k4852 in k4849 in k4846 in k4843 in k4840 in k4837 in k4834 in k4831 in ##csi#run in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_5316(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5316,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5319,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 971  case-sensitive */
((C_proc3)C_retrieve_symbol_proc(lf[332]))(3,*((C_word*)lf[332]+1),t2,C_SCHEME_FALSE);}

/* k5317 in k5314 in k5311 in k5050 in k5047 in k5044 in k5041 in k5037 in k5034 in k5031 in k5028 in k5025 in k5022 in k5019 in k5016 in k5013 in k5010 in k4858 in k4852 in k4849 in k4846 in k4843 in k4840 in k4837 in k4834 in k4831 in ##csi#run in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_5319(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5319,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5322,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 972  keyword-style */
((C_proc3)C_retrieve_symbol_proc(lf[330]))(3,*((C_word*)lf[330]+1),t2,lf[331]);}

/* k5320 in k5317 in k5314 in k5311 in k5050 in k5047 in k5044 in k5041 in k5037 in k5034 in k5031 in k5028 in k5025 in k5022 in k5019 in k5016 in k5013 in k5010 in k4858 in k4852 in k4849 in k4846 in k4843 in k4840 in k4837 in k4834 in k4831 in ##csi#run in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_5322(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5322,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5325,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 973  parentheses-synonyms */
((C_proc3)C_retrieve_symbol_proc(lf[329]))(3,*((C_word*)lf[329]+1),t2,C_SCHEME_FALSE);}

/* k5323 in k5320 in k5317 in k5314 in k5311 in k5050 in k5047 in k5044 in k5041 in k5037 in k5034 in k5031 in k5028 in k5025 in k5022 in k5019 in k5016 in k5013 in k5010 in k4858 in k4852 in k4849 in k4846 in k4843 in k4840 in k4837 in k4834 in k4831 in ##csi#run in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_5325(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 974  symbol-escape */
((C_proc3)C_retrieve_symbol_proc(lf[328]))(3,*((C_word*)lf[328]+1),((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k5053 in k5050 in k5047 in k5044 in k5041 in k5037 in k5034 in k5031 in k5028 in k5025 in k5022 in k5019 in k5016 in k5013 in k5010 in k4858 in k4852 in k4849 in k4846 in k4843 in k4840 in k4837 in k4834 in k4831 in ##csi#run in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_5055(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5055,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5058,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5304,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 975  member* */
f_4627(t3,lf[327],((C_word*)((C_word*)t0)[2])[1]);}

/* k5302 in k5053 in k5050 in k5047 in k5044 in k5041 in k5037 in k5034 in k5031 in k5028 in k5025 in k5022 in k5019 in k5016 in k5013 in k5010 in k4858 in k4852 in k4849 in k4846 in k4843 in k4840 in k4837 in k4834 in k4831 in ##csi#run in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_5304(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5304,2,t0,t1);}
t2=(C_truep(t1)?t1:((C_word*)t0)[3]);
if(C_truep(t2)){
t3=((C_word*)t0)[2];
f_5058(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4909,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 911  ##sys#string-append */
((C_proc4)C_retrieve_symbol_proc(lf[325]))(4,*((C_word*)lf[325]+1),t3,lf[326],lf[2]);}}

/* k4907 in k5302 in k5053 in k5050 in k5047 in k5044 in k5041 in k5037 in k5034 in k5031 in k5028 in k5025 in k5022 in k5019 in k5016 in k5013 in k5010 in k4858 in k4852 in k4849 in k4846 in k4843 in k4840 in k4837 in k4834 in k4831 in ##csi#run in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_4909(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4909,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4915,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 912  file-exists? */
((C_proc3)C_retrieve_symbol_proc(lf[32]))(3,*((C_word*)lf[32]+1),t2,t1);}

/* k4913 in k4907 in k5302 in k5053 in k5050 in k5047 in k5044 in k5041 in k5037 in k5034 in k5031 in k5028 in k5025 in k5022 in k5019 in k5016 in k5013 in k5010 in k4858 in k4852 in k4849 in k4846 in k4843 in k4840 in k4837 in k4834 in k4831 in ##csi#run in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_4915(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4915,2,t0,t1);}
if(C_truep(t1)){
/* csi.scm: 913  load */
((C_proc3)C_retrieve_symbol_proc(lf[84]))(3,*((C_word*)lf[84]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4921,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4937,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 914  get-environment-variable */
((C_proc3)C_retrieve_symbol_proc(lf[41]))(3,*((C_word*)lf[41]+1),t3,lf[324]);}}

/* k4935 in k4913 in k4907 in k5302 in k5053 in k5050 in k5047 in k5044 in k5041 in k5037 in k5034 in k5031 in k5028 in k5025 in k5022 in k5019 in k5016 in k5013 in k5010 in k4858 in k4852 in k4849 in k4846 in k4843 in k4840 in k4837 in k4834 in k4831 in ##csi#run in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_4937(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?t1:lf[323]);
/* csi.scm: 914  chop-separator */
((C_proc3)C_retrieve_symbol_proc(lf[29]))(3,*((C_word*)lf[29]+1),((C_word*)t0)[2],t2);}

/* k4919 in k4913 in k4907 in k5302 in k5053 in k5050 in k5047 in k5044 in k5041 in k5037 in k5034 in k5031 in k5028 in k5025 in k5022 in k5019 in k5016 in k5013 in k5010 in k4858 in k4852 in k4849 in k4846 in k4843 in k4840 in k4837 in k4834 in k4831 in ##csi#run in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_4921(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4921,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4924,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 915  string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[33]+1)))(5,*((C_word*)lf[33]+1),t2,t1,lf[322],lf[2]);}

/* k4922 in k4919 in k4913 in k4907 in k5302 in k5053 in k5050 in k5047 in k5044 in k5041 in k5037 in k5034 in k5031 in k5028 in k5025 in k5022 in k5019 in k5016 in k5013 in k5010 in k4858 in k4852 in k4849 in k4846 in k4843 in k4840 in k4837 in k4834 in k4831 in ##csi#run in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_4924(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4924,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4930,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 916  file-exists? */
((C_proc3)C_retrieve_symbol_proc(lf[32]))(3,*((C_word*)lf[32]+1),t2,t1);}

/* k4928 in k4922 in k4919 in k4913 in k4907 in k5302 in k5053 in k5050 in k5047 in k5044 in k5041 in k5037 in k5034 in k5031 in k5028 in k5025 in k5022 in k5019 in k5016 in k5013 in k5010 in k4858 in k4852 in k4849 in k4846 in k4843 in k4840 in k4837 in k4834 in k4831 in ##csi#run in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_4930(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* csi.scm: 917  load */
((C_proc3)C_retrieve_symbol_proc(lf[84]))(3,*((C_word*)lf[84]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_5058(2,t2,C_SCHEME_UNDEFINED);}}

/* k5056 in k5053 in k5050 in k5047 in k5044 in k5041 in k5037 in k5034 in k5031 in k5028 in k5025 in k5022 in k5019 in k5016 in k5013 in k5010 in k4858 in k4852 in k4849 in k4846 in k4843 in k4840 in k4837 in k4834 in k4831 in ##csi#run in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_5058(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5058,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5063,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_5063(t5,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* doloop1422 in k5056 in k5053 in k5050 in k5047 in k5044 in k5041 in k5037 in k5034 in k5031 in k5028 in k5025 in k5022 in k5019 in k5016 in k5013 in k5010 in k4858 in k4852 in k4849 in k4846 in k4843 in k4840 in k4837 in k4834 in k4831 in ##csi#run in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_fcall f_5063(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5063,NULL,3,t0,t1,t2);}
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
if(C_truep((C_word)C_i_nullp(((C_word*)t3)[1]))){
if(C_truep(((C_word*)t0)[5])){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5076,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 979  repl */
((C_proc2)C_retrieve_symbol_proc(lf[298]))(2,*((C_word*)lf[298]+1),t4);}}
else{
t4=(C_word)C_i_car(((C_word*)t3)[1]);
t5=(C_word)C_i_member(t4,lf[299]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5088,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t5)){
t7=t6;
f_5088(2,t7,t5);}
else{
if(C_truep((C_truep((C_word)C_i_equalp(t4,lf[300]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t4,lf[301]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t4,lf[302]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t4,lf[303]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t4,lf[304]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t4,lf[305]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))))))){
t7=(C_word)C_i_cdr(((C_word*)t3)[1]);
t8=C_set_block_item(t3,0,t7);
t9=t6;
f_5088(2,t9,t8);}
else{
t7=(C_word)C_i_string_equal_p(lf[306],t4);
t8=(C_truep(t7)?t7:(C_word)C_i_string_equal_p(lf[307],t4));
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5117,a[2]=t6,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5141,a[2]=t9,tmp=(C_word)a,a+=3,tmp);
t11=(C_word)C_i_cadr(((C_word*)t3)[1]);
/* csi.scm: 986  string->symbol */
((C_proc3)C_retrieve_proc(*((C_word*)lf[142]+1)))(3,*((C_word*)lf[142]+1),t10,t11);}
else{
t9=(C_word)C_i_string_equal_p(lf[309],t4);
t10=(C_truep(t9)?t9:(C_word)C_i_string_equal_p(lf[310],t4));
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5157,a[2]=t6,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t12=(C_word)C_i_cadr(((C_word*)t3)[1]);
/* csi.scm: 989  evalstring */
f_4942(t11,t12,C_SCHEME_END_OF_LIST);}
else{
t11=(C_word)C_i_string_equal_p(lf[311],t4);
t12=(C_truep(t11)?t11:(C_word)C_i_string_equal_p(lf[312],t4));
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5177,a[2]=t6,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t14=(C_word)C_i_cadr(((C_word*)t3)[1]);
t15=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5187,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 992  evalstring */
f_4942(t13,t14,(C_word)C_a_i_list(&a,1,t15));}
else{
t13=(C_word)C_i_string_equal_p(lf[314],t4);
t14=(C_truep(t13)?t13:(C_word)C_i_string_equal_p(lf[315],t4));
if(C_truep(t14)){
t15=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5203,a[2]=t6,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t16=(C_word)C_i_cadr(((C_word*)t3)[1]);
t17=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5213,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 995  evalstring */
f_4942(t15,t16,(C_word)C_a_i_list(&a,1,t17));}
else{
t15=(C_truep(((C_word*)t0)[2])?(C_word)C_i_car(((C_word*)t0)[2]):C_SCHEME_FALSE);
t16=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5223,a[2]=t6,a[3]=t15,tmp=(C_word)a,a+=4,tmp);
t17=(C_word)C_i_equalp(lf[319],t15);
t18=(C_truep(t17)?(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5276,tmp=(C_word)a,a+=2,tmp):C_SCHEME_FALSE);
/* csi.scm: 999  ##sys#load */
((C_proc5)C_retrieve_symbol_proc(lf[321]))(5,*((C_word*)lf[321]+1),t16,t4,t18,C_SCHEME_FALSE);}}}}}}}}

/* f_5276 in doloop1422 in k5056 in k5053 in k5050 in k5047 in k5044 in k5041 in k5037 in k5034 in k5031 in k5028 in k5025 in k5022 in k5019 in k5016 in k5013 in k5010 in k4858 in k4852 in k4849 in k4846 in k4843 in k4840 in k4837 in k4834 in k4831 in ##csi#run in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_5276(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5276,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5280,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 1003 pretty-print */
((C_proc4)C_retrieve_symbol_proc(lf[65]))(4,*((C_word*)lf[65]+1),t3,t2,*((C_word*)lf[320]+1));}

/* k5278 */
static void C_ccall f_5280(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5280,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5283,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 1004 newline */
((C_proc3)C_retrieve_proc(*((C_word*)lf[20]+1)))(3,*((C_word*)lf[20]+1),t2,*((C_word*)lf[320]+1));}

/* k5281 in k5278 */
static void C_ccall f_5283(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 1005 eval */
((C_proc3)C_retrieve_symbol_proc(lf[57]))(3,*((C_word*)lf[57]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5221 in doloop1422 in k5056 in k5053 in k5050 in k5047 in k5044 in k5041 in k5037 in k5034 in k5031 in k5028 in k5025 in k5022 in k5019 in k5016 in k5013 in k5010 in k4858 in k4852 in k4849 in k4846 in k4843 in k4840 in k4837 in k4834 in k4831 in ##csi#run in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_5223(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5223,2,t0,t1);}
if(C_truep((C_word)C_i_equalp(lf[316],((C_word*)t0)[3]))){
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5234,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5244,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 1008 call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}
else{
t2=((C_word*)t0)[2];
f_5088(2,t2,C_SCHEME_UNDEFINED);}}

/* a5243 in k5221 in doloop1422 in k5056 in k5053 in k5050 in k5047 in k5044 in k5041 in k5037 in k5034 in k5031 in k5028 in k5025 in k5022 in k5019 in k5016 in k5013 in k5010 in k4858 in k4852 in k4849 in k4846 in k4843 in k4840 in k4837 in k4834 in k4831 in ##csi#run in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_5244(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2rv,(void*)f_5244r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_5244r(t0,t1,t2);}}

static void C_ccall f_5244r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5255,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_notvemptyp(t2))){
t4=(C_word)C_i_vector_ref(t2,C_fix(0));
t5=t3;
f_5255(t5,(C_word)C_fixnump(t4));}
else{
t4=t3;
f_5255(t4,C_SCHEME_FALSE);}}

/* k5253 in a5243 in k5221 in doloop1422 in k5056 in k5053 in k5050 in k5047 in k5044 in k5041 in k5037 in k5034 in k5031 in k5028 in k5025 in k5022 in k5019 in k5016 in k5013 in k5010 in k4858 in k4852 in k4849 in k4846 in k4843 in k4840 in k4837 in k4834 in k4831 in ##csi#run in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_fcall f_5255(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?(C_word)C_i_vector_ref(((C_word*)t0)[3],C_fix(0)):C_fix(0));
/* csi.scm: 1010 exit */
((C_proc3)C_retrieve_symbol_proc(lf[70]))(3,*((C_word*)lf[70]+1),((C_word*)t0)[2],t2);}

/* a5233 in k5221 in doloop1422 in k5056 in k5053 in k5050 in k5047 in k5044 in k5041 in k5037 in k5034 in k5031 in k5028 in k5025 in k5022 in k5019 in k5016 in k5013 in k5010 in k4858 in k4852 in k4849 in k4846 in k4843 in k4840 in k4837 in k4834 in k4831 in ##csi#run in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_5234(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5234,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5242,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 1008 command-line-arguments */
((C_proc2)C_retrieve_symbol_proc(lf[318]))(2,*((C_word*)lf[318]+1),t2);}

/* k5240 in a5233 in k5221 in doloop1422 in k5056 in k5053 in k5050 in k5047 in k5044 in k5041 in k5037 in k5034 in k5031 in k5028 in k5025 in k5022 in k5019 in k5016 in k5013 in k5010 in k4858 in k4852 in k4849 in k4846 in k4843 in k4840 in k4837 in k4834 in k4831 in ##csi#run in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_5242(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* main */
((C_proc3)C_retrieve_symbol_proc(lf[317]))(3,*((C_word*)lf[317]+1),((C_word*)t0)[2],t1);}

/* a5212 in doloop1422 in k5056 in k5053 in k5050 in k5047 in k5044 in k5041 in k5037 in k5034 in k5031 in k5028 in k5025 in k5022 in k5019 in k5016 in k5013 in k5010 in k4858 in k4852 in k4849 in k4846 in k4843 in k4840 in k4837 in k4834 in k4831 in ##csi#run in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_5213(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_5213r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_5213r(t0,t1,t2);}}

static void C_ccall f_5213r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_apply(5,0,t1,*((C_word*)lf[313]+1),C_retrieve(lf[65]),t2);}

/* k5201 in doloop1422 in k5056 in k5053 in k5050 in k5047 in k5044 in k5041 in k5037 in k5034 in k5031 in k5028 in k5025 in k5022 in k5019 in k5016 in k5013 in k5010 in k4858 in k4852 in k4849 in k4846 in k4843 in k4840 in k4837 in k4834 in k4831 in ##csi#run in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_5203(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
f_5088(2,t4,t3);}

/* a5186 in doloop1422 in k5056 in k5053 in k5050 in k5047 in k5044 in k5041 in k5037 in k5034 in k5031 in k5028 in k5025 in k5022 in k5019 in k5016 in k5013 in k5010 in k4858 in k4852 in k4849 in k4846 in k4843 in k4840 in k4837 in k4834 in k4831 in ##csi#run in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_5187(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_5187r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_5187r(t0,t1,t2);}}

static void C_ccall f_5187r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_apply(5,0,t1,*((C_word*)lf[313]+1),*((C_word*)lf[15]+1),t2);}

/* k5175 in doloop1422 in k5056 in k5053 in k5050 in k5047 in k5044 in k5041 in k5037 in k5034 in k5031 in k5028 in k5025 in k5022 in k5019 in k5016 in k5013 in k5010 in k4858 in k4852 in k4849 in k4846 in k4843 in k4840 in k4837 in k4834 in k4831 in ##csi#run in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_5177(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
f_5088(2,t4,t3);}

/* k5155 in doloop1422 in k5056 in k5053 in k5050 in k5047 in k5044 in k5041 in k5037 in k5034 in k5031 in k5028 in k5025 in k5022 in k5019 in k5016 in k5013 in k5010 in k4858 in k4852 in k4849 in k4846 in k4843 in k4840 in k4837 in k4834 in k4831 in ##csi#run in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_5157(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
f_5088(2,t4,t3);}

/* k5139 in doloop1422 in k5056 in k5053 in k5050 in k5047 in k5044 in k5041 in k5037 in k5034 in k5031 in k5028 in k5025 in k5022 in k5019 in k5016 in k5013 in k5010 in k4858 in k4852 in k4849 in k4846 in k4843 in k4840 in k4837 in k4834 in k4831 in ##csi#run in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_5141(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5141,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,C_SCHEME_TRUE,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,t2,t3);
t5=(C_word)C_a_i_cons(&a,2,lf[308],t4);
/* csi.scm: 986  eval */
((C_proc3)C_retrieve_symbol_proc(lf[57]))(3,*((C_word*)lf[57]+1),((C_word*)t0)[2],t5);}

/* k5115 in doloop1422 in k5056 in k5053 in k5050 in k5047 in k5044 in k5041 in k5037 in k5034 in k5031 in k5028 in k5025 in k5022 in k5019 in k5016 in k5013 in k5010 in k4858 in k4852 in k4849 in k4846 in k4843 in k4840 in k4837 in k4834 in k4831 in ##csi#run in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_5117(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
f_5088(2,t4,t3);}

/* k5086 in doloop1422 in k5056 in k5053 in k5050 in k5047 in k5044 in k5041 in k5037 in k5034 in k5031 in k5028 in k5025 in k5022 in k5019 in k5016 in k5013 in k5010 in k4858 in k4852 in k4849 in k4846 in k4843 in k4840 in k4837 in k4834 in k4831 in ##csi#run in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_5088(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[4])[1]);
t3=((C_word*)((C_word*)t0)[3])[1];
f_5063(t3,((C_word*)t0)[2],t2);}

/* k5074 in doloop1422 in k5056 in k5053 in k5050 in k5047 in k5044 in k5041 in k5037 in k5034 in k5031 in k5028 in k5025 in k5022 in k5019 in k5016 in k5013 in k5010 in k4858 in k4852 in k4849 in k4846 in k4843 in k4840 in k4837 in k4834 in k4831 in ##csi#run in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_5076(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 980  ##sys#write-char-0 */
((C_proc4)C_retrieve_symbol_proc(lf[147]))(4,*((C_word*)lf[147]+1),((C_word*)t0)[2],C_make_character(10),*((C_word*)lf[145]+1));}

/* evalstring in k4858 in k4852 in k4849 in k4846 in k4843 in k4840 in k4837 in k4834 in k4831 in ##csi#run in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_fcall f_4942(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4942,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4946,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_4946(2,t5,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4989,tmp=(C_word)a,a+=2,tmp));}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_4946(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[47]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* f_4989 in evalstring in k4858 in k4852 in k4849 in k4846 in k4843 in k4840 in k4837 in k4834 in k4831 in ##csi#run in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_4989(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4989,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_retrieve(lf[46]));}

/* k4944 in evalstring in k4858 in k4852 in k4849 in k4846 in k4843 in k4840 in k4837 in k4834 in k4831 in ##csi#run in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_4946(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4946,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4949,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 919  open-input-string */
((C_proc3)C_retrieve_symbol_proc(lf[297]))(3,*((C_word*)lf[297]+1),t2,((C_word*)t0)[2]);}

/* k4947 in k4944 in evalstring in k4858 in k4852 in k4849 in k4846 in k4843 in k4840 in k4837 in k4834 in k4831 in ##csi#run in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_4949(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4949,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4956,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 920  read */
((C_proc3)C_retrieve_proc(*((C_word*)lf[22]+1)))(3,*((C_word*)lf[22]+1),t2,t1);}

/* k4954 in k4947 in k4944 in evalstring in k4858 in k4852 in k4849 in k4846 in k4843 in k4840 in k4837 in k4834 in k4831 in ##csi#run in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_4956(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4956,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4958,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_4958(t5,((C_word*)t0)[2],t1);}

/* doloop1346 in k4954 in k4947 in k4944 in evalstring in k4858 in k4852 in k4849 in k4846 in k4843 in k4840 in k4837 in k4834 in k4831 in ##csi#run in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_fcall f_4958(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4958,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_eofp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4968,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4979,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4981,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t4,t5,*((C_word*)lf[296]+1));}}

/* a4980 in doloop1346 in k4954 in k4947 in k4944 in evalstring in k4858 in k4852 in k4849 in k4846 in k4843 in k4840 in k4837 in k4834 in k4831 in ##csi#run in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_4981(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4981,2,t0,t1);}
/* csi.scm: 922  eval */
((C_proc3)C_retrieve_symbol_proc(lf[57]))(3,*((C_word*)lf[57]+1),t1,((C_word*)t0)[2]);}

/* k4977 in doloop1346 in k4954 in k4947 in k4944 in evalstring in k4858 in k4852 in k4849 in k4846 in k4843 in k4840 in k4837 in k4834 in k4831 in ##csi#run in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_4979(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 922  rec */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k4966 in doloop1346 in k4954 in k4947 in k4944 in evalstring in k4858 in k4852 in k4849 in k4846 in k4843 in k4840 in k4837 in k4834 in k4831 in ##csi#run in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_4968(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4968,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4975,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 920  read */
((C_proc3)C_retrieve_proc(*((C_word*)lf[22]+1)))(3,*((C_word*)lf[22]+1),t2,((C_word*)t0)[2]);}

/* k4973 in k4966 in doloop1346 in k4954 in k4947 in k4944 in evalstring in k4858 in k4852 in k4849 in k4846 in k4843 in k4840 in k4837 in k4834 in k4831 in ##csi#run in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_4975(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[3])[1];
f_4958(t2,((C_word*)t0)[2],t1);}

/* collect-options in k4858 in k4852 in k4849 in k4846 in k4843 in k4840 in k4837 in k4834 in k4831 in ##csi#run in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_fcall f_4862(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4862,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4868,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_4868(t6,t1,((C_word*)((C_word*)t0)[2])[1]);}

/* loop in collect-options in k4858 in k4852 in k4849 in k4846 in k4843 in k4840 in k4837 in k4834 in k4831 in ##csi#run in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_fcall f_4868(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4868,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_member(((C_word*)t0)[3],t2);
if(C_truep(t3)){
t4=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t4))){
/* csi.scm: 907  ##sys#error */
t5=*((C_word*)lf[47]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,lf[295],((C_word*)t0)[3]);}
else{
t5=(C_word)C_i_cadr(t3);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4895,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_i_cddr(t3);
/* csi.scm: 908  loop */
t9=t6;
t10=t7;
t1=t9;
t2=t10;
goto loop;}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}}

/* k4893 in loop in collect-options in k4858 in k4852 in k4849 in k4846 in k4843 in k4840 in k4837 in k4834 in k4831 in ##csi#run in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_4895(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4895,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* canonicalize-args in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_fcall f_4684(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4684,NULL,2,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4690,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_4690(t6,t1,t2);}

/* loop in canonicalize-args in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_fcall f_4690(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4690,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_i_car(t2);
if(C_truep((C_truep((C_word)C_i_equalp(t3,lf[286]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t3,lf[287]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t3,lf[288]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t3,lf[289]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t3,lf[290]))?C_SCHEME_TRUE:C_SCHEME_FALSE))))))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4712,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_block_size(t3);
if(C_truep((C_word)C_fixnum_greaterp(t5,C_fix(2)))){
t6=(C_word)C_eqp(C_make_character(45),(C_word)C_subchar(t3,C_fix(0)));
if(C_truep(t6)){
t7=(C_word)C_i_member(t3,lf[293]);
t8=t4;
f_4712(t8,(C_word)C_i_not(t7));}
else{
t7=t4;
f_4712(t7,C_SCHEME_FALSE);}}
else{
t6=t4;
f_4712(t6,C_SCHEME_FALSE);}}}}

/* k4710 in loop in canonicalize-args in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_fcall f_4712(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4712,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_eqp(C_make_character(58),(C_word)C_subchar(((C_word*)t0)[5],C_fix(1)));
if(C_truep(t2)){
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* csi.scm: 853  loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_4690(t4,((C_word*)t0)[2],t3);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4728,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4762,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 854  substring */
((C_proc4)C_retrieve_proc(*((C_word*)lf[28]+1)))(4,*((C_word*)lf[28]+1),t4,((C_word*)t0)[5],C_fix(1));}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4769,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* csi.scm: 858  loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_4690(t4,t2,t3);}}

/* k4767 in k4710 in loop in canonicalize-args in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_4769(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4769,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k4760 in k4710 in loop in canonicalize-args in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_4762(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* string->list */
t2=C_retrieve(lf[292]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4726 in k4710 in loop in canonicalize-args in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_4728(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4728,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4801,tmp=(C_word)a,a+=2,tmp);
t4=f_4801(t2);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4741,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4751,tmp=(C_word)a,a+=2,tmp);
/* map */
t7=*((C_word*)lf[102]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,t1);}
else{
/* csi.scm: 857  ##sys#error */
t5=*((C_word*)lf[47]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,((C_word*)t0)[5],lf[291],((C_word*)t0)[2]);}}

/* a4750 in k4726 in k4710 in loop in canonicalize-args in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_4751(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4751,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_string(&a,2,C_make_character(45),t2));}

/* k4739 in k4726 in k4710 in loop in canonicalize-args in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_4741(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4741,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4745,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* csi.scm: 856  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_4690(t4,t2,t3);}

/* k4743 in k4739 in k4726 in k4710 in loop in canonicalize-args in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_4745(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 856  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[258]+1)))(4,*((C_word*)lf[258]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* loop in k4726 in k4710 in loop in canonicalize-args in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static C_word C_fcall f_4801(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
loop:
C_stack_check;
t2=(C_word)C_i_nullp(t1);
if(C_truep(t2)){
return(t2);}
else{
t3=(C_word)C_i_car(t1);
if(C_truep((C_truep((C_word)C_eqp(t3,C_make_character(107)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(115)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(118)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(104)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(68)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(101)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(105)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(82)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(98)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(110)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(113)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(119)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(45)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(73)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(112)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(80)))?C_SCHEME_TRUE:C_SCHEME_FALSE)))))))))))))))))){
t4=(C_word)C_i_cdr(t1);
t6=t4;
t1=t6;
goto loop;}
else{
return(C_SCHEME_FALSE);}}}

/* member* in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_fcall f_4627(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4627,NULL,3,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4633,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_4633(t7,t1,t3);}

/* loop in member* in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_fcall f_4633(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4633,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4645,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_4645(t6,t1,((C_word*)t0)[2]);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* find in loop in member* in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_fcall f_4645(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
loop:
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4645,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* csi.scm: 829  loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_4633(t4,t1,t3);}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_car(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_equalp(t3,t4))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,((C_word*)t0)[4]);}
else{
t5=(C_word)C_i_cdr(t2);
/* csi.scm: 831  find */
t8=t1;
t9=t5;
t1=t8;
t2=t9;
goto loop;}}}

/* ##csi#deldups in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_4568(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_4568r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4568r(t0,t1,t2,t3);}}

static void C_ccall f_4568r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4572,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_4572(2,t5,*((C_word*)lf[283]+1));}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_4572(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[47]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k4570 in ##csi#deldups in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_4572(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4572,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4577,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_4577(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* recur in k4570 in ##csi#deldups in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_fcall f_4577(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4577,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4593,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4606,a[2]=t5,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 822  del */
((C_proc5)C_retrieve_symbol_proc(lf[105]))(5,*((C_word*)lf[105]+1),t6,t3,t4,((C_word*)t0)[2]);}}

/* k4604 in recur in k4570 in ##csi#deldups in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_4606(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 822  recur */
t2=((C_word*)((C_word*)t0)[3])[1];
f_4577(t2,((C_word*)t0)[2],t1);}

/* k4591 in recur in k4570 in ##csi#deldups in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_4593(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4593,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[5],t1);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?((C_word*)t0)[3]:(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1)));}

/* ##csi#hexdump in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_4359(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[16],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_4359,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4362,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4391,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=t4,a[6]=((C_word*)t0)[3],a[7]=t5,a[8]=t8,a[9]=t3,tmp=(C_word)a,a+=10,tmp));
t10=((C_word*)t8)[1];
f_4391(t10,t1,C_fix(0));}

/* doloop944 in ##csi#hexdump in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_fcall f_4391(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4391,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[9]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4401,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[7],a[9]=t1,a[10]=((C_word*)t0)[8],a[11]=t2,tmp=(C_word)a,a+=12,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4566,a[2]=((C_word*)t0)[7],a[3]=t3,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 790  justify */
t5=((C_word*)t0)[2];
f_4362(t5,t4,t2,C_fix(4),C_fix(10),C_make_character(32));}}

/* k4564 in doloop944 in ##csi#hexdump in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_4566(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 790  display */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4399 in doloop944 in ##csi#hexdump in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_4401(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4401,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4404,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
/* csi.scm: 791  write-char */
t3=((C_word*)t0)[6];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_make_character(58),((C_word*)t0)[8]);}

/* k4402 in k4399 in doloop944 in ##csi#hexdump in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_4404(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4404,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4407,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4476,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[2],a[6]=t4,a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[3],a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp));
t6=((C_word*)t4)[1];
f_4476(t6,t2,C_fix(0),((C_word*)t0)[11]);}

/* doloop966 in k4402 in k4399 in doloop944 in ##csi#hexdump in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_fcall f_4476(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4476,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_fixnum_greater_or_equal_p(t2,C_fix(16));
t5=(C_truep(t4)?t4:(C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[9]));
if(C_truep(t5)){
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[9]))){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4495,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 796  fxmod */
((C_proc4)C_retrieve_proc(*((C_word*)lf[281]+1)))(4,*((C_word*)lf[281]+1),t6,((C_word*)t0)[9],C_fix(16));}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}
else{
t6=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4537,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=t1,a[8]=((C_word*)t0)[6],a[9]=t3,a[10]=t2,tmp=(C_word)a,a+=11,tmp);
/* csi.scm: 801  write-char */
t7=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,C_make_character(32),((C_word*)t0)[7]);}}

/* k4535 in doloop966 in k4402 in k4399 in doloop944 in ##csi#hexdump in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_4537(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4537,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4540,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4555,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4559,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 802  ref */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[2],((C_word*)t0)[9]);}

/* k4557 in k4535 in doloop966 in k4402 in k4399 in doloop944 in ##csi#hexdump in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_4559(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 802  justify */
t2=((C_word*)t0)[3];
f_4362(t2,((C_word*)t0)[2],t1,C_fix(2),C_fix(16),C_make_character(48));}

/* k4553 in k4535 in doloop966 in k4402 in k4399 in doloop944 in ##csi#hexdump in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_4555(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 802  display */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4538 in k4535 in doloop966 in k4402 in k4399 in doloop944 in ##csi#hexdump in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_4540(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_4476(t4,((C_word*)t0)[2],t2,t3);}

/* k4493 in doloop966 in k4402 in k4399 in doloop944 in ##csi#hexdump in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_4495(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4495,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_eqp(t1,C_fix(0));
if(C_truep(t2)){
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=(C_word)C_fixnum_difference(C_fix(16),t1);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4513,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t5,tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_4513(t7,((C_word*)t0)[4],t3);}}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* doloop986 in k4493 in doloop966 in k4402 in k4399 in doloop944 in ##csi#hexdump in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_fcall f_4513(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4513,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4523,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 800  display */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,lf[280],((C_word*)t0)[2]);}}

/* k4521 in doloop986 in k4493 in doloop966 in k4402 in k4399 in doloop944 in ##csi#hexdump in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_4523(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_difference(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4513(t3,((C_word*)t0)[2],t2);}

/* k4405 in k4402 in k4399 in doloop944 in ##csi#hexdump in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_4407(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4407,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4410,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* csi.scm: 803  write-char */
t3=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_make_character(32),((C_word*)t0)[6]);}

/* k4408 in k4405 in k4402 in k4399 in doloop944 in ##csi#hexdump in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_4410(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4410,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4413,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4425,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],a[6]=t4,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp));
t6=((C_word*)t4)[1];
f_4425(t6,t2,C_fix(0),((C_word*)t0)[9]);}

/* doloop1003 in k4408 in k4405 in k4402 in k4399 in doloop944 in ##csi#hexdump in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_fcall f_4425(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4425,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_fixnum_greater_or_equal_p(t2,C_fix(16));
t5=(C_truep(t4)?t4:(C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[7]));
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}
else{
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4438,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[6],a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* csi.scm: 807  ref */
t7=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,((C_word*)t0)[2],t3);}}

/* k4436 in doloop1003 in k4408 in k4405 in k4402 in k4399 in doloop944 in ##csi#hexdump in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_4438(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4438,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4441,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_fixnum_greater_or_equal_p(t1,C_fix(32));
t4=(C_truep(t3)?(C_word)C_fixnum_lessp(t1,C_fix(128)):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=(C_word)C_make_character((C_word)C_unfix(t1));
/* csi.scm: 809  write-char */
t6=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t6))(4,t6,t2,t5,((C_word*)t0)[2]);}
else{
/* csi.scm: 810  write-char */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t2,C_make_character(46),((C_word*)t0)[2]);}}

/* k4439 in k4436 in doloop1003 in k4408 in k4405 in k4402 in k4399 in doloop944 in ##csi#hexdump in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_4441(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_4425(t4,((C_word*)t0)[2],t2,t3);}

/* k4411 in k4408 in k4405 in k4402 in k4399 in doloop944 in ##csi#hexdump in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_4413(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4413,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4416,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 811  ##sys#write-char-0 */
((C_proc4)C_retrieve_symbol_proc(lf[147]))(4,*((C_word*)lf[147]+1),t2,C_make_character(10),((C_word*)t0)[2]);}

/* k4414 in k4411 in k4408 in k4405 in k4402 in k4399 in doloop944 in ##csi#hexdump in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_4416(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(16));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4391(t3,((C_word*)t0)[2],t2);}

/* justify in ##csi#hexdump in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_fcall f_4362(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4362,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4366,a[2]=t5,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* csi.scm: 782  number->string */
C_number_to_string(4,0,t6,t2,t4);}

/* k4364 in justify in ##csi#hexdump in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_4366(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4366,2,t0,t1);}
t2=(C_word)C_block_size(t1);
if(C_truep((C_word)C_fixnum_lessp(t2,((C_word*)t0)[6]))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4382,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_fixnum_difference(((C_word*)t0)[6],t2);
/* csi.scm: 785  make-string */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t4,((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}}

/* k4380 in k4364 in justify in ##csi#hexdump in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_4382(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 785  string-append */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* ##csi#dump in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_4198(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr3r,(void*)f_4198r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4198r(t0,t1,t2,t3);}}

static void C_ccall f_4198r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(9);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4200,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4306,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4311,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-len891924 */
t7=t6;
f_4311(t7,t1);}
else{
t7=(C_word)C_i_car(t3);
t8=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t8))){
/* def-out892920 */
t9=t5;
f_4306(t9,t1,t7);}
else{
t9=(C_word)C_i_car(t8);
t10=(C_word)C_i_cdr(t8);
if(C_truep((C_word)C_i_nullp(t10))){
/* body889898 */
t11=t4;
f_4200(t11,t1,t7,t9);}
else{
/* ##sys#error */
t11=*((C_word*)lf[47]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t1,lf[0],t10);}}}}

/* def-len891 in ##csi#dump in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_fcall f_4311(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4311,NULL,2,t0,t1);}
/* def-out892920 */
t2=((C_word*)t0)[2];
f_4306(t2,t1,C_SCHEME_FALSE);}

/* def-out892 in ##csi#dump in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_fcall f_4306(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4306,NULL,3,t0,t1,t2);}
/* body889898 */
t3=((C_word*)t0)[2];
f_4200(t3,t1,t2,*((C_word*)lf[145]+1));}

/* body889 in ##csi#dump in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_fcall f_4200(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4200,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4203,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_immp(((C_word*)t0)[2]))){
/* csi.scm: 764  ##sys#error */
t5=*((C_word*)lf[47]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,lf[275],lf[276],((C_word*)t0)[2]);}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4225,a[2]=t4,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 765  ##sys#bytevector? */
((C_proc3)C_retrieve_proc(*((C_word*)lf[264]+1)))(3,*((C_word*)lf[264]+1),t5,((C_word*)t0)[2]);}}

/* k4223 in body889 in ##csi#dump in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_4225(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4225,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4232,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[4]);
/* csi.scm: 765  bestlen */
t4=((C_word*)t0)[2];
f_4203(t4,t2,t3);}
else{
if(C_truep((C_word)C_i_stringp(((C_word*)t0)[4]))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4249,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[4]);
/* csi.scm: 766  bestlen */
t4=((C_word*)t0)[2];
f_4203(t4,t2,t3);}
else{
t2=(C_word)C_immp(((C_word*)t0)[4]);
t3=(C_truep(t2)?C_SCHEME_FALSE:(C_word)C_anypointerp(((C_word*)t0)[4]));
if(C_truep(t3)){
/* csi.scm: 768  hexdump */
((C_proc6)C_retrieve_symbol_proc(lf[239]))(6,*((C_word*)lf[239]+1),((C_word*)t0)[5],((C_word*)t0)[4],C_fix(32),*((C_word*)lf[277]+1),((C_word*)t0)[3]);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4268,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_structurep(((C_word*)t0)[4]))){
t5=(C_word)C_slot(((C_word*)t0)[4],C_fix(0));
t6=t4;
f_4268(t6,(C_word)C_i_assq(t5,C_retrieve2(lf[178],"bytevector-data")));}
else{
t5=t4;
f_4268(t5,C_SCHEME_FALSE);}}}}}

/* k4266 in k4223 in body889 in ##csi#dump in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_fcall f_4268(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4268,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4278,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_block_size(t2);
/* csi.scm: 771  bestlen */
t5=((C_word*)t0)[2];
f_4203(t5,t3,t4);}
else{
/* csi.scm: 772  ##sys#error */
t2=*((C_word*)lf[47]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],lf[275],lf[278],((C_word*)t0)[5]);}}

/* k4276 in k4266 in k4223 in body889 in ##csi#dump in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_4278(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 771  hexdump */
((C_proc6)C_retrieve_symbol_proc(lf[239]))(6,*((C_word*)lf[239]+1),((C_word*)t0)[4],((C_word*)t0)[3],t1,*((C_word*)lf[240]+1),((C_word*)t0)[2]);}

/* k4247 in k4223 in body889 in ##csi#dump in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_4249(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 766  hexdump */
((C_proc6)C_retrieve_symbol_proc(lf[239]))(6,*((C_word*)lf[239]+1),((C_word*)t0)[4],((C_word*)t0)[3],t1,*((C_word*)lf[240]+1),((C_word*)t0)[2]);}

/* k4230 in k4223 in body889 in ##csi#dump in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_4232(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 765  hexdump */
((C_proc6)C_retrieve_symbol_proc(lf[239]))(6,*((C_word*)lf[239]+1),((C_word*)t0)[4],((C_word*)t0)[3],t1,*((C_word*)lf[240]+1),((C_word*)t0)[2]);}

/* bestlen in body889 in ##csi#dump in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_fcall f_4203(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4203,NULL,3,t0,t1,t2);}
if(C_truep(((C_word*)t0)[2])){
/* csi.scm: 763  min */
((C_proc4)C_retrieve_proc(*((C_word*)lf[274]+1)))(4,*((C_word*)lf[274]+1),t1,((C_word*)t0)[2],t2);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* set-describer! in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_4189(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4189,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4193,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 752  ##sys#check-symbol */
((C_proc5)C_retrieve_proc(*((C_word*)lf[272]+1)))(5,*((C_word*)lf[272]+1),t4,t2,lf[273],lf[271]);}

/* k4191 in set-describer! in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_4193(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 753  ##sys#hash-table-set! */
((C_proc5)C_retrieve_symbol_proc(lf[56]))(5,*((C_word*)lf[56]+1),((C_word*)t0)[4],C_retrieve2(lf[180],"describer-table"),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##csi#describe in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_3370(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr3r,(void*)f_3370r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3370r(t0,t1,t2,t3);}}

static void C_ccall f_3370r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(9);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3374,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=t2,a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_3374(2,t5,*((C_word*)lf[145]+1));}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_3374(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[47]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k3372 in ##csi#describe in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_3374(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3374,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3376,a[2]=((C_word*)t0)[7],a[3]=t1,a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3502,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=t1,a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[6],tmp=(C_word)a,a+=11,tmp);
if(C_truep((C_word)C_permanentp(((C_word*)t0)[7]))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4168,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 639  ##sys#block-address */
((C_proc3)C_retrieve_symbol_proc(lf[270]))(3,*((C_word*)lf[270]+1),t4,((C_word*)t0)[7]);}
else{
t4=t3;
f_3502(2,t4,C_SCHEME_UNDEFINED);}}

/* k4166 in k3372 in ##csi#describe in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_4168(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 639  fprintf */
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[269],t1);}

/* k3500 in k3372 in ##csi#describe in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_3502(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3502,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3505,a[2]=((C_word*)t0)[10],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_charp(((C_word*)t0)[9]))){
t3=(C_word)C_fix((C_word)C_character_code(((C_word*)t0)[9]));
/* csi.scm: 642  fprintf */
t4=((C_word*)t0)[8];
((C_proc8)C_retrieve_proc(t4))(8,t4,t2,((C_word*)t0)[7],lf[191],((C_word*)t0)[9],t3,t3,t3);}
else{
switch(((C_word*)t0)[9]){
case C_SCHEME_TRUE:
/* csi.scm: 643  fprintf */
t3=((C_word*)t0)[8];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[7],lf[192]);
case C_SCHEME_FALSE:
/* csi.scm: 644  fprintf */
t3=((C_word*)t0)[8];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[7],lf[193]);
default:
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[9]))){
/* csi.scm: 645  fprintf */
t3=((C_word*)t0)[8];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[7],lf[194]);}
else{
if(C_truep((C_word)C_eofp(((C_word*)t0)[9]))){
/* csi.scm: 646  fprintf */
t3=((C_word*)t0)[8];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[7],lf[195]);}
else{
t3=C_retrieve(lf[46]);
t4=(C_word)C_eqp(t3,((C_word*)t0)[9]);
if(C_truep(t4)){
/* csi.scm: 647  fprintf */
t5=((C_word*)t0)[8];
((C_proc4)C_retrieve_proc(t5))(4,t5,t2,((C_word*)t0)[7],lf[196]);}
else{
if(C_truep((C_word)C_fixnump(((C_word*)t0)[9]))){
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3571,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=t2,a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 649  fprintf */
t6=((C_word*)t0)[8];
((C_proc8)C_retrieve_proc(t6))(8,t6,t5,((C_word*)t0)[7],lf[198],((C_word*)t0)[9],((C_word*)t0)[9],((C_word*)t0)[9],((C_word*)t0)[9]);}
else{
t5=(C_word)C_slot(lf[199],C_fix(0));
t6=(C_word)C_eqp(((C_word*)t0)[9],t5);
if(C_truep(t6)){
/* csi.scm: 654  fprintf */
t7=((C_word*)t0)[8];
((C_proc4)C_retrieve_proc(t7))(4,t7,t2,((C_word*)t0)[7],lf[200]);}
else{
t7=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3601,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[7],a[9]=t2,a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp);
/* csi.scm: 655  ##sys#number? */
((C_proc3)C_retrieve_symbol_proc(lf[268]))(3,*((C_word*)lf[268]+1),t7,((C_word*)t0)[9]);}}}}}}}}

/* k3599 in k3500 in k3372 in ##csi#describe in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_3601(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3601,2,t0,t1);}
if(C_truep(t1)){
/* csi.scm: 655  fprintf */
t2=((C_word*)t0)[10];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[9],((C_word*)t0)[8],lf[201],((C_word*)t0)[7]);}
else{
if(C_truep((C_word)C_i_stringp(((C_word*)t0)[7]))){
/* csi.scm: 656  descseq */
t2=((C_word*)t0)[6];
f_3376(6,t2,((C_word*)t0)[9],lf[202],*((C_word*)lf[203]+1),((C_word*)t0)[5],C_fix(0));}
else{
if(C_truep((C_word)C_i_vectorp(((C_word*)t0)[7]))){
/* csi.scm: 657  descseq */
t2=((C_word*)t0)[6];
f_3376(6,t2,((C_word*)t0)[9],lf[204],*((C_word*)lf[203]+1),*((C_word*)lf[205]+1),C_fix(0));}
else{
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[7]))){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3631,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3725,a[2]=((C_word*)t0)[8],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 659  ##sys#symbol-has-toplevel-binding? */
((C_proc3)C_retrieve_symbol_proc(lf[216]))(3,*((C_word*)lf[216]+1),t3,((C_word*)t0)[7]);}
else{
if(C_truep((C_word)C_i_listp(((C_word*)t0)[7]))){
/* csi.scm: 676  descseq */
t2=((C_word*)t0)[6];
f_3376(6,t2,((C_word*)t0)[9],lf[217],((C_word*)t0)[4],((C_word*)t0)[3],C_fix(0));}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[7]))){
t2=(C_word)C_i_car(((C_word*)t0)[7]);
t3=(C_word)C_i_cdr(((C_word*)t0)[7]);
/* csi.scm: 677  fprintf */
t4=((C_word*)t0)[10];
((C_proc6)C_retrieve_proc(t4))(6,t4,((C_word*)t0)[9],((C_word*)t0)[8],lf[218],t2,t3);}
else{
if(C_truep((C_word)C_i_closurep(((C_word*)t0)[7]))){
t2=(C_word)C_block_size(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3769,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_greaterp(t2,C_fix(3)))){
if(C_truep((C_word)C_i_memq(lf[222],C_retrieve(lf[6])))){
t4=(C_word)C_fixnum_difference(t2,C_fix(1));
t5=(C_word)C_slot(((C_word*)t0)[7],t4);
t6=t3;
f_3769(t6,(C_word)C_eqp(C_retrieve(lf[223]),t5));}
else{
t4=t3;
f_3769(t4,C_SCHEME_FALSE);}}
else{
t4=t3;
f_3769(t4,C_SCHEME_FALSE);}}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3809,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* csi.scm: 687  port? */
((C_proc3)C_retrieve_symbol_proc(lf[267]))(3,*((C_word*)lf[267]+1),t2,((C_word*)t0)[7]);}}}}}}}}

/* k3807 in k3599 in k3500 in k3372 in ##csi#describe in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_3809(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3809,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t3=(C_truep(t2)?lf[224]:lf[225]);
t4=(C_word)C_slot(((C_word*)t0)[6],C_fix(7));
t5=(C_word)C_slot(((C_word*)t0)[6],C_fix(3));
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3828,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
/* csi.scm: 693  ##sys#peek-unsigned-integer */
((C_proc4)C_retrieve_symbol_proc(lf[221]))(4,*((C_word*)lf[221]+1),t6,((C_word*)t0)[6],C_fix(0));}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3837,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_memq(lf[222],C_retrieve(lf[6])))){
/* csi.scm: 694  instance? */
((C_proc3)C_retrieve_symbol_proc(lf[266]))(3,*((C_word*)lf[266]+1),t2,((C_word*)t0)[6]);}
else{
t3=t2;
f_3837(2,t3,C_SCHEME_FALSE);}}}

/* k3835 in k3807 in k3599 in k3500 in k3372 in ##csi#describe in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_3837(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3837,2,t0,t1);}
if(C_truep(t1)){
/* csi.scm: 695  describe-object */
((C_proc4)C_retrieve_symbol_proc(lf[219]))(4,*((C_word*)lf[219]+1),((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3846,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* csi.scm: 696  ##sys#locative? */
((C_proc3)C_retrieve_symbol_proc(lf[265]))(3,*((C_word*)lf[265]+1),t2,((C_word*)t0)[5]);}}

/* k3844 in k3835 in k3807 in k3599 in k3500 in k3372 in ##csi#describe in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_3846(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3846,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3853,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 698  ##sys#peek-unsigned-integer */
((C_proc4)C_retrieve_symbol_proc(lf[221]))(4,*((C_word*)lf[221]+1),t2,((C_word*)t0)[6],C_fix(0));}
else{
if(C_truep((C_word)C_anypointerp(((C_word*)t0)[6]))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3934,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 711  ##sys#peek-unsigned-integer */
((C_proc4)C_retrieve_symbol_proc(lf[221]))(4,*((C_word*)lf[221]+1),t2,((C_word*)t0)[6],C_fix(0));}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3940,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* csi.scm: 712  ##sys#bytevector? */
((C_proc3)C_retrieve_proc(*((C_word*)lf[264]+1)))(3,*((C_word*)lf[264]+1),t2,((C_word*)t0)[6]);}}}

/* k3938 in k3844 in k3835 in k3807 in k3599 in k3500 in k3372 in ##csi#describe in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_3940(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3940,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_block_size(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3946,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 714  fprintf */
t4=((C_word*)t0)[3];
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[4],lf[241],t2);}
else{
if(C_truep((C_word)C_lambdainfop(((C_word*)t0)[6]))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3959,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 717  ##sys#lambda-info->string */
((C_proc3)C_retrieve_symbol_proc(lf[243]))(3,*((C_word*)lf[243]+1),t2,((C_word*)t0)[6]);}
else{
if(C_truep((C_word)C_i_structurep(((C_word*)t0)[6],lf[244]))){
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(2));
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3971,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_eqp(t2,C_fix(1));
t5=(C_truep(t4)?lf[248]:lf[249]);
t6=(C_word)C_slot(((C_word*)t0)[6],C_fix(3));
/* csi.scm: 720  fprintf */
t7=((C_word*)t0)[3];
((C_proc7)C_retrieve_proc(t7))(7,t7,t3,((C_word*)t0)[4],lf[250],t2,t5,t6);}
else{
if(C_truep((C_word)C_i_structurep(((C_word*)t0)[6],lf[251]))){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4007,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
/* csi.scm: 727  fprintf */
t4=((C_word*)t0)[3];
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,((C_word*)t0)[4],lf[256],t3);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4074,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_structurep(((C_word*)t0)[6],lf[261]))){
/* csi.scm: 737  provided? */
((C_proc3)C_retrieve_symbol_proc(lf[262]))(3,*((C_word*)lf[262]+1),t2,lf[263]);}
else{
t3=t2;
f_4074(2,t3,C_SCHEME_FALSE);}}}}}}

/* k4072 in k3938 in k3844 in k3835 in k3807 in k3599 in k3500 in k3372 in ##csi#describe in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_4074(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4074,2,t0,t1);}
if(C_truep(t1)){
/* csi.scm: 738  unveil */
((C_proc4)C_retrieve_symbol_proc(lf[257]))(4,*((C_word*)lf[257]+1),((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
if(C_truep((C_word)C_structurep(((C_word*)t0)[5]))){
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(0));
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4089,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
/* csi.scm: 741  ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[139]))(4,*((C_word*)lf[139]+1),t3,C_retrieve2(lf[180],"describer-table"),t2);}
else{
/* csi.scm: 748  fprintf */
t2=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[6],((C_word*)t0)[4],lf[260]);}}}

/* k4087 in k4072 in k3938 in k3844 in k3835 in k3807 in k3599 in k3500 in k3372 in ##csi#describe in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_4089(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4089,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4096,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[5],t1);}
else{
t2=(C_word)C_i_assq(((C_word*)t0)[4],C_retrieve2(lf[178],"bytevector-data"));
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4113,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4117,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_i_cdr(t2);
/* map */
t6=*((C_word*)lf[102]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,C_retrieve(lf[57]),t5);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4128,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_slot(((C_word*)t0)[7],C_fix(0));
/* csi.scm: 746  fprintf */
t5=((C_word*)t0)[2];
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,((C_word*)t0)[6],lf[259],t4);}}}

/* k4126 in k4087 in k4072 in k3938 in k3844 in k3835 in k3807 in k3599 in k3500 in k3372 in ##csi#describe in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_4128(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 747  descseq */
t2=((C_word*)t0)[3];
f_3376(6,t2,((C_word*)t0)[2],C_SCHEME_FALSE,*((C_word*)lf[203]+1),*((C_word*)lf[205]+1),C_fix(1));}

/* k4115 in k4087 in k4072 in k3938 in k3844 in k3835 in k3807 in k3599 in k3500 in k3372 in ##csi#describe in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_4117(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4117,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,C_fix(0));
/* csi.scm: 744  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[258]+1)))(4,*((C_word*)lf[258]+1),((C_word*)t0)[2],t1,t2);}

/* k4111 in k4087 in k4072 in k3938 in k3844 in k3835 in k3807 in k3599 in k3500 in k3372 in ##csi#describe in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_4113(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* f_4096 in k4087 in k4072 in k3938 in k3844 in k3835 in k3807 in k3599 in k3500 in k3372 in ##csi#describe in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_4096(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4096,3,t0,t1,t2);}
/* g859860861 */
t3=t2;
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4005 in k3938 in k3844 in k3835 in k3807 in k3599 in k3500 in k3372 in ##csi#describe in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_4007(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4007,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4012,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* for-each */
t4=*((C_word*)lf[83]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[2],t2,t3);}

/* a4011 in k4005 in k3938 in k3844 in k3835 in k3807 in k3599 in k3500 in k3372 in ##csi#describe in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_4012(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4012,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4016,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* csi.scm: 730  fprintf */
t4=((C_word*)t0)[3];
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[2],lf[255],t2);}

/* k4014 in a4011 in k4005 in k3938 in k3844 in k3835 in k3807 in k3599 in k3500 in k3372 in ##csi#describe in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_4016(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4016,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(2));
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4025,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t4,tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_4025(t6,((C_word*)t0)[2],t2);}

/* loop in k4014 in a4011 in k4005 in k3938 in k3844 in k3835 in k3807 in k3599 in k3500 in k3372 in ##csi#describe in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_fcall f_4025(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4025,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4035,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4060,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* csi.scm: 733  caar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[254]+1)))(3,*((C_word*)lf[254]+1),t4,t2);}}

/* k4058 in loop in k4014 in a4011 in k4005 in k3938 in k3844 in k3835 in k3807 in k3599 in k3500 in k3372 in ##csi#describe in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_4060(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4060,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[6],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4052,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 734  cdar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[253]+1)))(3,*((C_word*)lf[253]+1),t3,((C_word*)t0)[5]);}
else{
t3=((C_word*)t0)[3];
f_4035(2,t3,C_SCHEME_UNDEFINED);}}

/* k4050 in k4058 in loop in k4014 in a4011 in k4005 in k3938 in k3844 in k3835 in k3807 in k3599 in k3500 in k3372 in ##csi#describe in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_4052(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* csi.scm: 734  fprintf */
t3=((C_word*)t0)[4];
((C_proc6)C_retrieve_proc(t3))(6,t3,((C_word*)t0)[3],((C_word*)t0)[2],lf[252],t1,t2);}

/* k4033 in loop in k4014 in a4011 in k4005 in k3938 in k3844 in k3835 in k3807 in k3599 in k3500 in k3372 in ##csi#describe in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_4035(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cddr(((C_word*)t0)[4]);
/* csi.scm: 735  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_4025(t3,((C_word*)t0)[2],t2);}

/* k3969 in k3938 in k3844 in k3835 in k3807 in k3599 in k3500 in k3372 in ##csi#describe in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_3971(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3971,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3974,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_slot(((C_word*)t0)[2],C_fix(4));
/* csi.scm: 722  fprintf */
t4=((C_word*)t0)[5];
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,((C_word*)t0)[4],lf[247],t3);}

/* k3972 in k3969 in k3938 in k3844 in k3835 in k3807 in k3599 in k3500 in k3372 in ##csi#describe in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_3974(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3974,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3979,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 723  hash-table-walk */
((C_proc4)C_retrieve_symbol_proc(lf[246]))(4,*((C_word*)lf[246]+1),((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* a3978 in k3972 in k3969 in k3938 in k3844 in k3835 in k3807 in k3599 in k3500 in k3372 in ##csi#describe in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_3979(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3979,4,t0,t1,t2,t3);}
/* csi.scm: 725  fprintf */
t4=((C_word*)t0)[3];
((C_proc6)C_retrieve_proc(t4))(6,t4,t1,((C_word*)t0)[2],lf[245],t2,t3);}

/* k3957 in k3938 in k3844 in k3835 in k3807 in k3599 in k3500 in k3372 in ##csi#describe in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_3959(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 717  fprintf */
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[242],t1);}

/* k3944 in k3938 in k3844 in k3835 in k3807 in k3599 in k3500 in k3372 in ##csi#describe in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_3946(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 715  hexdump */
((C_proc6)C_retrieve_symbol_proc(lf[239]))(6,*((C_word*)lf[239]+1),((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],*((C_word*)lf[240]+1),((C_word*)t0)[2]);}

/* k3932 in k3844 in k3835 in k3807 in k3599 in k3500 in k3372 in ##csi#describe in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_3934(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 711  fprintf */
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[238],t1);}

/* k3851 in k3844 in k3835 in k3807 in k3599 in k3500 in k3372 in ##csi#describe in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_3853(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3853,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_slot(((C_word*)t0)[5],C_fix(2));
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3864,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
switch(t3){
case C_fix(0):
t5=t4;
f_3864(t5,lf[228]);
case C_fix(1):
t5=t4;
f_3864(t5,lf[229]);
case C_fix(2):
t5=t4;
f_3864(t5,lf[230]);
case C_fix(3):
t5=t4;
f_3864(t5,lf[231]);
case C_fix(4):
t5=t4;
f_3864(t5,lf[232]);
case C_fix(5):
t5=t4;
f_3864(t5,lf[233]);
case C_fix(6):
t5=t4;
f_3864(t5,lf[234]);
case C_fix(7):
t5=t4;
f_3864(t5,lf[235]);
case C_fix(8):
t5=t4;
f_3864(t5,lf[236]);
default:
t5=(C_word)C_eqp(t3,C_fix(9));
t6=t4;
f_3864(t6,(C_truep(t5)?lf[237]:C_SCHEME_UNDEFINED));}}

/* k3862 in k3851 in k3844 in k3835 in k3807 in k3599 in k3500 in k3372 in ##csi#describe in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_fcall f_3864(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 697  fprintf */
t2=((C_word*)t0)[6];
((C_proc7)C_retrieve_proc(t2))(7,t2,((C_word*)t0)[5],((C_word*)t0)[4],lf[227],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3826 in k3807 in k3599 in k3500 in k3372 in ##csi#describe in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_3828(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 688  fprintf */
t2=((C_word*)t0)[7];
((C_proc8)C_retrieve_proc(t2))(8,t2,((C_word*)t0)[6],((C_word*)t0)[5],lf[226],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3767 in k3599 in k3500 in k3372 in ##csi#describe in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_fcall f_3769(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3769,NULL,2,t0,t1);}
if(C_truep(t1)){
/* csi.scm: 683  describe-object */
((C_proc4)C_retrieve_symbol_proc(lf[219]))(4,*((C_word*)lf[219]+1),((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3779,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3783,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 685  ##sys#peek-unsigned-integer */
((C_proc4)C_retrieve_symbol_proc(lf[221]))(4,*((C_word*)lf[221]+1),t3,((C_word*)t0)[5],C_fix(0));}}

/* k3781 in k3767 in k3599 in k3500 in k3372 in ##csi#describe in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_3783(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 685  sprintf */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[220],t1);}

/* k3777 in k3767 in k3599 in k3500 in k3372 in ##csi#describe in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_3779(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 684  descseq */
t2=((C_word*)t0)[3];
f_3376(6,t2,((C_word*)t0)[2],t1,*((C_word*)lf[203]+1),*((C_word*)lf[205]+1),C_fix(1));}

/* k3723 in k3599 in k3500 in k3372 in ##csi#describe in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_3725(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_3631(2,t2,C_SCHEME_UNDEFINED);}
else{
/* csi.scm: 659  display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[8]+1)))(4,*((C_word*)lf[8]+1),((C_word*)t0)[3],lf[215],((C_word*)t0)[2]);}}

/* k3629 in k3599 in k3500 in k3372 in ##csi#describe in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_3631(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3631,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3634,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3705,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[5]))){
t4=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t5=(C_word)C_subbyte(t4,C_fix(0));
t6=t3;
f_3705(t6,(C_word)C_eqp(C_fix(0),t5));}
else{
t4=t3;
f_3705(t4,C_SCHEME_FALSE);}}

/* k3703 in k3629 in k3599 in k3500 in k3372 in ##csi#describe in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_fcall f_3705(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* csi.scm: 661  display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[8]+1)))(4,*((C_word*)lf[8]+1),((C_word*)t0)[3],lf[214],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_3634(2,t2,C_SCHEME_UNDEFINED);}}

/* k3632 in k3629 in k3599 in k3500 in k3372 in ##csi#describe in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_3634(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3634,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3637,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3702,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 663  ##sys#interned-symbol? */
((C_proc3)C_retrieve_symbol_proc(lf[213]))(3,*((C_word*)lf[213]+1),t3,((C_word*)t0)[5]);}

/* k3700 in k3632 in k3629 in k3599 in k3500 in k3372 in ##csi#describe in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_3702(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3702,2,t0,t1);}
t2=(C_truep(t1)?lf[209]:lf[210]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3699,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 664  ##sys#symbol->string */
((C_proc3)C_retrieve_symbol_proc(lf[212]))(3,*((C_word*)lf[212]+1),t3,((C_word*)t0)[2]);}

/* k3697 in k3700 in k3632 in k3629 in k3599 in k3500 in k3372 in ##csi#describe in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_3699(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 662  fprintf */
t2=((C_word*)t0)[5];
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[4],((C_word*)t0)[3],lf[211],((C_word*)t0)[2],t1);}

/* k3635 in k3632 in k3629 in k3599 in k3500 in k3372 in ##csi#describe in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_3637(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3637,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(2));
if(C_truep((C_word)C_i_nullp(t2))){
t3=((C_word*)t0)[4];
f_3505(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3649,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 667  display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[8]+1)))(4,*((C_word*)lf[8]+1),t3,lf[208],((C_word*)t0)[3]);}}

/* k3647 in k3635 in k3632 in k3629 in k3599 in k3500 in k3372 in ##csi#describe in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_3649(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3649,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3654,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_3654(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* doloop781 in k3647 in k3635 in k3632 in k3629 in k3599 in k3500 in k3372 in ##csi#describe in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_fcall f_3654(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3654,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3664,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_i_car(t2);
/* csi.scm: 670  fprintf */
t5=((C_word*)t0)[2];
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,((C_word*)t0)[3],lf[207],t4);}}

/* k3662 in doloop781 in k3647 in k3635 in k3632 in k3629 in k3599 in k3500 in k3372 in ##csi#describe in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_3664(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3664,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3667,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3679,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 671  ##sys#with-print-length-limit */
((C_proc4)C_retrieve_symbol_proc(lf[206]))(4,*((C_word*)lf[206]+1),t2,C_fix(1000),t3);}

/* a3678 in k3662 in doloop781 in k3647 in k3635 in k3632 in k3629 in k3599 in k3500 in k3372 in ##csi#describe in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_3679(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3679,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[3]);
/* csi.scm: 674  write */
((C_proc4)C_retrieve_proc(*((C_word*)lf[62]+1)))(4,*((C_word*)lf[62]+1),t1,t2,((C_word*)t0)[2]);}

/* k3665 in k3662 in doloop781 in k3647 in k3635 in k3632 in k3629 in k3599 in k3500 in k3372 in ##csi#describe in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_3667(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3667,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3670,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 675  newline */
((C_proc3)C_retrieve_proc(*((C_word*)lf[20]+1)))(3,*((C_word*)lf[20]+1),t2,((C_word*)t0)[2]);}

/* k3668 in k3665 in k3662 in doloop781 in k3647 in k3635 in k3632 in k3629 in k3599 in k3500 in k3372 in ##csi#describe in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_3670(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cddr(((C_word*)t0)[4]);
t3=((C_word*)((C_word*)t0)[3])[1];
f_3654(t3,((C_word*)t0)[2],t2);}

/* k3569 in k3500 in k3372 in ##csi#describe in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_3571(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3571,2,t0,t1);}
t2=(C_word)C_make_character((C_word)C_unfix(((C_word*)t0)[5]));
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3577,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_fixnum_lessp(((C_word*)t0)[5],C_fix(65536)))){
/* csi.scm: 651  fprintf */
t4=((C_word*)t0)[3];
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[2],lf[197],t2);}
else{
t4=t3;
f_3577(2,t4,C_SCHEME_UNDEFINED);}}

/* k3575 in k3569 in k3500 in k3372 in ##csi#describe in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_3577(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 652  ##sys#write-char-0 */
((C_proc4)C_retrieve_symbol_proc(lf[147]))(4,*((C_word*)lf[147]+1),((C_word*)t0)[2],C_make_character(10),*((C_word*)lf[145]+1));}

/* k3503 in k3500 in k3372 in ##csi#describe in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_3505(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_retrieve(lf[46]));}

/* descseq in k3372 in ##csi#describe in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_3376(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_3376,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3499,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t4,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=t5,tmp=(C_word)a,a+=9,tmp);
/* csi.scm: 619  plen */
t7=t3;
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[2]);}

/* k3497 in descseq in k3372 in ##csi#describe in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_3499(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3499,2,t0,t1);}
t2=(C_word)C_fixnum_difference(t1,((C_word*)t0)[8]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3383,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)t0)[2])){
/* csi.scm: 620  fprintf */
t4=((C_word*)t0)[7];
((C_proc6)C_retrieve_proc(t4))(6,t4,t3,((C_word*)t0)[6],lf[190],((C_word*)t0)[2],t2);}
else{
t4=t3;
f_3383(2,t4,C_SCHEME_UNDEFINED);}}

/* k3381 in k3497 in descseq in k3372 in ##csi#describe in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_3383(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3383,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3388,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp));
t5=((C_word*)t3)[1];
f_3388(t5,((C_word*)t0)[2],C_fix(0));}

/* loop1 in k3381 in k3497 in descseq in k3372 in ##csi#describe in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_fcall f_3388(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3388,NULL,3,t0,t1,t2);}
t3=(C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[8]);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,C_fix(40)))){
t4=(C_word)C_fixnum_difference(((C_word*)t0)[8],t2);
/* csi.scm: 624  fprintf */
t5=((C_word*)t0)[7];
((C_proc5)C_retrieve_proc(t5))(5,t5,t1,((C_word*)t0)[6],lf[185],t4);}
else{
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3411,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[8],a[9]=t2,a[10]=((C_word*)t0)[5],tmp=(C_word)a,a+=11,tmp);
t5=(C_word)C_fixnum_plus(((C_word*)t0)[5],t2);
/* csi.scm: 626  pref */
t6=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,((C_word*)t0)[2],t5);}}}

/* k3409 in loop1 in k3381 in k3497 in descseq in k3372 in ##csi#describe in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_3411(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3411,2,t0,t1);}
t2=(C_word)C_fixnum_plus(((C_word*)t0)[10],C_fix(1));
t3=(C_word)C_fixnum_plus(((C_word*)t0)[9],t2);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3420,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t5,a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp));
t7=((C_word*)t5)[1];
f_3420(t7,((C_word*)t0)[2],C_fix(1),t3);}

/* loop2 in k3409 in loop1 in k3381 in k3497 in descseq in k3372 in ##csi#describe in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_fcall f_3420(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3420,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[10]))){
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3430,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t1,a[5]=((C_word*)t0)[8],a[6]=t2,a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
/* csi.scm: 629  fprintf */
t5=((C_word*)t0)[7];
((C_proc6)C_retrieve_proc(t5))(6,t5,t4,((C_word*)t0)[6],lf[189],((C_word*)t0)[9],((C_word*)t0)[5]);}
else{
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3484,a[2]=((C_word*)t0)[10],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=t2,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
/* csi.scm: 636  pref */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[2],t3);}}

/* k3482 in loop2 in k3409 in loop1 in k3381 in k3497 in descseq in k3372 in ##csi#describe in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_3484(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_eqp(((C_word*)t0)[7],t1);
if(C_truep(t2)){
t3=(C_word)C_fixnum_plus(((C_word*)t0)[6],C_fix(1));
t4=(C_word)C_fixnum_plus(((C_word*)t0)[5],C_fix(1));
/* csi.scm: 636  loop2 */
t5=((C_word*)((C_word*)t0)[4])[1];
f_3420(t5,((C_word*)t0)[3],t3,t4);}
else{
/* csi.scm: 637  loop2 */
t3=((C_word*)((C_word*)t0)[4])[1];
f_3420(t3,((C_word*)t0)[3],((C_word*)t0)[6],((C_word*)t0)[2]);}}

/* k3428 in loop2 in k3409 in loop1 in k3381 in k3497 in descseq in k3372 in ##csi#describe in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_3430(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3430,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3433,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_greaterp(((C_word*)t0)[6],C_fix(1)))){
t3=(C_word)C_fixnum_difference(((C_word*)t0)[6],C_fix(1));
t4=(C_word)C_eqp(((C_word*)t0)[6],C_fix(2));
t5=(C_truep(t4)?lf[186]:lf[187]);
/* csi.scm: 631  fprintf */
t6=((C_word*)t0)[3];
((C_proc6)C_retrieve_proc(t6))(6,t6,t2,((C_word*)t0)[2],lf[188],t3,t5);}
else{
/* csi.scm: 634  newline */
((C_proc3)C_retrieve_proc(*((C_word*)lf[20]+1)))(3,*((C_word*)lf[20]+1),t2,((C_word*)t0)[2]);}}

/* k3431 in k3428 in loop2 in k3409 in loop1 in k3381 in k3497 in descseq in k3372 in ##csi#describe in k3366 in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_3433(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[5],((C_word*)t0)[4]);
/* csi.scm: 635  loop1 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_3388(t3,((C_word*)t0)[2],t2);}

/* ##csi#report in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_3174(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr2rv,(void*)f_3174r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_3174r(t0,t1,t2);}}

static void C_ccall f_3174r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(7);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3182,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_notvemptyp(t2))){
t4=t3;
f_3182(2,t4,(C_word)C_i_vector_ref(t2,C_fix(0)));}
else{
/* csi.scm: 548  current-output-port */
t4=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}}

/* k3180 in ##csi#report in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_3182(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3182,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3184,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 548  with-output-to-port */
t3=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[2],t1,t2);}

/* a3183 in k3180 in ##csi#report in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_3184(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3184,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3188,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 550  gc */
((C_proc2)C_retrieve_symbol_proc(lf[177]))(2,*((C_word*)lf[177]+1),t2);}

/* k3186 in a3183 in k3180 in ##csi#report in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_3188(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3188,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3191,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 551  ##sys#symbol-table-info */
((C_proc2)C_retrieve_symbol_proc(lf[176]))(2,*((C_word*)lf[176]+1),t2);}

/* k3189 in k3186 in a3183 in k3180 in ##csi#report in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_3191(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3191,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3194,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* csi.scm: 552  memory-statistics */
((C_proc2)C_retrieve_symbol_proc(lf[175]))(2,*((C_word*)lf[175]+1),t2);}

/* k3192 in k3189 in k3186 in a3183 in k3180 in ##csi#report in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_3194(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3194,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3196,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3211,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=t1,a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
/* csi.scm: 554  printf */
t4=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[174]);}

/* k3209 in k3192 in k3189 in k3186 in a3183 in k3180 in ##csi#report in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_3211(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3211,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3214,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3313,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3346,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3350,a[2]=t4,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3354,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* map */
t7=*((C_word*)lf[102]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,C_retrieve(lf[173]),C_retrieve(lf[6]));}

/* k3352 in k3209 in k3192 in k3189 in k3186 in a3183 in k3180 in ##csi#report in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_3354(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 562  sort */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,*((C_word*)lf[172]+1));}

/* k3348 in k3209 in k3192 in k3189 in k3186 in a3183 in k3180 in ##csi#report in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_3350(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 562  chop */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_fix(5));}

/* k3344 in k3209 in k3192 in k3189 in k3186 in a3183 in k3180 in ##csi#report in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_3346(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[83]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a3312 in k3209 in k3192 in k3189 in k3186 in a3183 in k3180 in ##csi#report in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_3313(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3313,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3317,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 557  display */
((C_proc3)C_retrieve_proc(*((C_word*)lf[8]+1)))(3,*((C_word*)lf[8]+1),t3,lf[171]);}

/* k3315 in a3312 in k3209 in k3192 in k3189 in k3186 in a3183 in k3180 in ##csi#report in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_3317(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3317,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3322,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* for-each */
t3=*((C_word*)lf[83]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a3321 in k3315 in a3312 in k3209 in k3192 in k3189 in k3186 in a3183 in k3180 in ##csi#report in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_3322(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3322,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3330,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_string_length(t2);
t5=(C_word)C_fixnum_difference(C_fix(16),t4);
t6=(C_word)C_i_fixnum_max(C_fix(1),t5);
/* csi.scm: 560  make-string */
((C_proc4)C_retrieve_proc(*((C_word*)lf[170]+1)))(4,*((C_word*)lf[170]+1),t3,t6,C_make_character(32));}

/* k3328 in a3321 in k3315 in a3312 in k3209 in k3192 in k3189 in k3186 in a3183 in k3180 in ##csi#report in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_3330(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 560  printf */
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[169],((C_word*)t0)[2],t1);}

/* k3212 in k3209 in k3192 in k3189 in k3186 in a3183 in k3180 in ##csi#report in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_3214(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3214,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3217,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3242,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* csi.scm: 574  machine-type */
((C_proc2)C_retrieve_symbol_proc(lf[168]))(2,*((C_word*)lf[168]+1),t3);}

/* k3240 in k3212 in k3209 in k3192 in k3189 in k3186 in a3183 in k3180 in ##csi#report in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_3242(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3242,2,t0,t1);}
t2=(C_word)C_fudge(C_fix(3));
t3=(C_truep(t2)?lf[157]:lf[158]);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3250,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
/* csi.scm: 576  software-type */
((C_proc2)C_retrieve_symbol_proc(lf[167]))(2,*((C_word*)lf[167]+1),t4);}

/* k3248 in k3240 in k3212 in k3209 in k3192 in k3189 in k3186 in a3183 in k3180 in ##csi#report in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_3250(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3250,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3254,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* csi.scm: 577  software-version */
((C_proc2)C_retrieve_symbol_proc(lf[166]))(2,*((C_word*)lf[166]+1),t2);}

/* k3252 in k3248 in k3240 in k3212 in k3209 in k3192 in k3189 in k3186 in a3183 in k3180 in ##csi#report in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_3254(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3254,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3258,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* csi.scm: 578  build-platform */
((C_proc2)C_retrieve_symbol_proc(lf[165]))(2,*((C_word*)lf[165]+1),t2);}

/* k3256 in k3252 in k3248 in k3240 in k3212 in k3209 in k3192 in k3189 in k3186 in a3183 in k3180 in ##csi#report in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_3258(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3258,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3262,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
t3=(C_word)C_i_vector_ref(((C_word*)t0)[10],C_fix(0));
/* csi.scm: 580  shorten */
f_3196(t2,t3);}

/* k3260 in k3256 in k3252 in k3248 in k3240 in k3212 in k3209 in k3192 in k3189 in k3186 in a3183 in k3180 in ##csi#report in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_3262(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3262,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3266,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
t3=(C_word)C_i_vector_ref(((C_word*)t0)[11],C_fix(1));
/* csi.scm: 581  shorten */
f_3196(t2,t3);}

/* k3264 in k3260 in k3256 in k3252 in k3248 in k3240 in k3212 in k3209 in k3192 in k3189 in k3186 in a3183 in k3180 in ##csi#report in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_3266(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
t2=(C_word)C_i_vector_ref(((C_word*)t0)[11],C_fix(2));
t3=(C_word)C_i_vector_ref(((C_word*)t0)[10],C_fix(0));
t4=(C_word)C_fudge(C_fix(17));
t5=(C_truep(t4)?lf[159]:lf[160]);
t6=(C_word)C_i_vector_ref(((C_word*)t0)[10],C_fix(1));
t7=(C_word)C_i_vector_ref(((C_word*)t0)[10],C_fix(2));
t8=(C_word)C_fudge(C_fix(18));
t9=(C_word)C_i_nequalp(C_fix(1),t8);
t10=(C_truep(t9)?lf[161]:lf[162]);
/* csi.scm: 563  printf */
t11=((C_word*)t0)[9];
((C_proc17)C_retrieve_proc(t11))(17,t11,((C_word*)t0)[8],lf[163],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],C_retrieve(lf[164]),((C_word*)t0)[2],t1,t2,t3,t5,t6,t7,t10);}

/* k3215 in k3212 in k3209 in k3192 in k3189 in k3186 in a3183 in k3180 in ##csi#report in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_3217(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3217,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3220,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 588  ##sys#write-char-0 */
((C_proc4)C_retrieve_symbol_proc(lf[147]))(4,*((C_word*)lf[147]+1),t2,C_make_character(10),*((C_word*)lf[145]+1));}

/* k3218 in k3215 in k3212 in k3209 in k3192 in k3189 in k3186 in a3183 in k3180 in ##csi#report in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_3220(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3220,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3223,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_fudge(C_fix(14)))){
/* csi.scm: 589  display */
((C_proc3)C_retrieve_proc(*((C_word*)lf[8]+1)))(3,*((C_word*)lf[8]+1),t2,lf[156]);}
else{
t3=t2;
f_3223(2,t3,C_SCHEME_UNDEFINED);}}

/* k3221 in k3218 in k3215 in k3212 in k3209 in k3192 in k3189 in k3186 in a3183 in k3180 in ##csi#report in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_3223(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3223,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3226,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_fudge(C_fix(15)))){
/* csi.scm: 590  display */
((C_proc3)C_retrieve_proc(*((C_word*)lf[8]+1)))(3,*((C_word*)lf[8]+1),t2,lf[155]);}
else{
t3=t2;
f_3226(2,t3,C_SCHEME_UNDEFINED);}}

/* k3224 in k3221 in k3218 in k3215 in k3212 in k3209 in k3192 in k3189 in k3186 in a3183 in k3180 in ##csi#report in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_3226(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* shorten in k3192 in k3189 in k3186 in a3183 in k3180 in ##csi#report in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_fcall f_3196(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3196,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3204,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_a_i_times(&a,2,t2,C_fix(100));
/* csi.scm: 553  truncate */
((C_proc3)C_retrieve_proc(*((C_word*)lf[154]+1)))(3,*((C_word*)lf[154]+1),t3,t4);}

/* k3202 in shorten in k3192 in k3189 in k3186 in a3183 in k3180 in ##csi#report in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_3204(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3204,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_divide(&a,2,t1,C_fix(100)));}

/* do-unbreak-all in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_3047(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3047,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3051,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3057,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[83]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_retrieve2(lf[97],"broken-procedures"));}

/* a3056 in do-unbreak-all in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_3057(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3057,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_i_setslot(t3,C_fix(0),t4));}

/* k3049 in do-unbreak-all in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_3051(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=lf[97] /* broken-procedures */ =C_SCHEME_END_OF_LIST;;
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_retrieve(lf[46]));}

/* ##csi#traced-procedure-exit in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_2756(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2756,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2761,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 430  sub1 */
((C_proc3)C_retrieve_proc(*((C_word*)lf[30]+1)))(3,*((C_word*)lf[30]+1),t4,C_retrieve(lf[69]));}

/* k2759 in ##csi#traced-procedure-exit in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_2761(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2761,2,t0,t1);}
t2=C_mutate((C_word*)lf[69]+1 /* (set! trace-indent-level ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2764,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 431  trace-indent */
f_2705(t3);}

/* k2762 in k2759 in ##csi#traced-procedure-exit in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_2764(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2764,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2767,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 432  write */
((C_proc3)C_retrieve_proc(*((C_word*)lf[62]+1)))(3,*((C_word*)lf[62]+1),t2,((C_word*)t0)[2]);}

/* k2765 in k2762 in k2759 in ##csi#traced-procedure-exit in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_2767(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2767,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2770,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 433  display */
((C_proc3)C_retrieve_proc(*((C_word*)lf[8]+1)))(3,*((C_word*)lf[8]+1),t2,lf[149]);}

/* k2768 in k2765 in k2762 in k2759 in ##csi#traced-procedure-exit in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_2770(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2770,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2773,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2781,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[83]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a2780 in k2768 in k2765 in k2762 in k2759 in ##csi#traced-procedure-exit in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_2781(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2781,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2785,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 436  write */
((C_proc3)C_retrieve_proc(*((C_word*)lf[62]+1)))(3,*((C_word*)lf[62]+1),t3,t2);}

/* k2783 in a2780 in k2768 in k2765 in k2762 in k2759 in ##csi#traced-procedure-exit in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_2785(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* write-char/port */
t2=C_retrieve(lf[144]);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_make_character(32),*((C_word*)lf[145]+1));}

/* k2771 in k2768 in k2765 in k2762 in k2759 in ##csi#traced-procedure-exit in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_2773(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2773,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2776,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 439  ##sys#write-char-0 */
((C_proc4)C_retrieve_symbol_proc(lf[147]))(4,*((C_word*)lf[147]+1),t2,C_make_character(10),*((C_word*)lf[145]+1));}

/* k2774 in k2771 in k2768 in k2765 in k2762 in k2759 in ##csi#traced-procedure-exit in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_2776(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 440  flush-output */
((C_proc2)C_retrieve_proc(*((C_word*)lf[146]+1)))(2,*((C_word*)lf[146]+1),((C_word*)t0)[2]);}

/* ##csi#traced-procedure-entry in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_2733(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2733,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2737,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 422  trace-indent */
f_2705(t4);}

/* k2735 in ##csi#traced-procedure-entry in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_2737(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2737,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2741,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 423  add1 */
((C_proc3)C_retrieve_proc(*((C_word*)lf[148]+1)))(3,*((C_word*)lf[148]+1),t2,C_retrieve(lf[69]));}

/* k2739 in k2735 in ##csi#traced-procedure-entry in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_2741(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2741,2,t0,t1);}
t2=C_mutate((C_word*)lf[69]+1 /* (set! trace-indent-level ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2744,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]);
/* csi.scm: 424  write */
((C_proc3)C_retrieve_proc(*((C_word*)lf[62]+1)))(3,*((C_word*)lf[62]+1),t3,t4);}

/* k2742 in k2739 in k2735 in ##csi#traced-procedure-entry in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_2744(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2744,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2747,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 425  ##sys#write-char-0 */
((C_proc4)C_retrieve_symbol_proc(lf[147]))(4,*((C_word*)lf[147]+1),t2,C_make_character(10),*((C_word*)lf[145]+1));}

/* k2745 in k2742 in k2739 in k2735 in ##csi#traced-procedure-entry in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_2747(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 426  flush-output */
((C_proc2)C_retrieve_proc(*((C_word*)lf[146]+1)))(2,*((C_word*)lf[146]+1),((C_word*)t0)[2]);}

/* ##csi#trace-indent in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_fcall f_2705(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2705,NULL,1,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2709,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* write-char/port */
t3=C_retrieve(lf[144]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(124),*((C_word*)lf[145]+1));}

/* k2707 in ##csi#trace-indent in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_2709(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2709,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2714,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_2714(t5,((C_word*)t0)[2],C_retrieve(lf[69]));}

/* doloop464 in k2707 in ##csi#trace-indent in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_fcall f_2714(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2714,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_less_or_equalp(t2,C_fix(0)))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2724,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* write-char/port */
t4=C_retrieve(lf[144]);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_make_character(32),*((C_word*)lf[145]+1));}}

/* k2722 in doloop464 in k2707 in ##csi#trace-indent in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_2724(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2724,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2731,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 416  sub1 */
((C_proc3)C_retrieve_proc(*((C_word*)lf[30]+1)))(3,*((C_word*)lf[30]+1),t2,((C_word*)t0)[2]);}

/* k2729 in k2722 in doloop464 in k2707 in ##csi#trace-indent in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_2731(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[3])[1];
f_2714(t2,((C_word*)t0)[2],t1);}

/* ##csi#del in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_2664(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2664,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2670,a[2]=t2,a[3]=t4,a[4]=t6,tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_2670(t8,t1,t3);}

/* loop in ##csi#del in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_fcall f_2670(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2670,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2686,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 405  tst */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[2],t3);}}

/* k2684 in loop in ##csi#del in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_2686(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2686,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_cdr(((C_word*)t0)[4]));}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2696,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* csi.scm: 407  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_2670(t4,t2,t3);}}

/* k2694 in k2684 in loop in ##csi#del in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_2696(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2696,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* resolve-var in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_2650(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2650,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2658,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 395  string->symbol */
((C_proc3)C_retrieve_proc(*((C_word*)lf[142]+1)))(3,*((C_word*)lf[142]+1),t3,t2);}

/* k2656 in resolve-var in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_2658(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2658,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2662,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 395  ##sys#current-environment */
((C_proc2)C_retrieve_symbol_proc(lf[141]))(2,*((C_word*)lf[141]+1),t2);}

/* k2660 in k2656 in resolve-var in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_2662(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 395  ##sys#strip-syntax */
((C_proc5)C_retrieve_symbol_proc(lf[72]))(5,*((C_word*)lf[72]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1,C_SCHEME_TRUE);}

/* ##sys#repl-eval-hook in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_2100(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2100,3,t0,t1,t2);}
t3=C_set_block_item(lf[69] /* trace-indent-level */,0,C_fix(0));
if(C_truep((C_word)C_eofp(t2))){
/* csi.scm: 270  exit */
((C_proc2)C_retrieve_symbol_proc(lf[70]))(2,*((C_word*)lf[70]+1),t1);}
else{
t4=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_2117,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=t1,a[14]=t2,tmp=(C_word)a,a+=15,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t5=(C_word)C_slot(t2,C_fix(0));
t6=t4;
f_2117(t6,(C_word)C_eqp(lf[140],t5));}
else{
t5=t4;
f_2117(t5,C_SCHEME_FALSE);}}}

/* k2115 in ##sys#repl-eval-hook in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_fcall f_2117(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2117,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[14]);
t3=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_2123,a[2]=((C_word*)t0)[14],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=t2,a[15]=((C_word*)t0)[13],tmp=(C_word)a,a+=16,tmp);
if(C_truep((C_word)C_i_symbolp(t2))){
/* csi.scm: 274  ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[139]))(4,*((C_word*)lf[139]+1),t3,C_retrieve2(lf[54],"command-table"),t2);}
else{
t4=t3;
f_2123(2,t4,C_SCHEME_FALSE);}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2625,a[2]=((C_word*)t0)[14],a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2631,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[13],t2,t3);}}

/* a2630 in k2115 in ##sys#repl-eval-hook in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_2631(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_2631r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2631r(t0,t1,t2);}}

static void C_ccall f_2631r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2635,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 391  history-add */
((C_proc3)C_retrieve_symbol_proc(lf[45]))(3,*((C_word*)lf[45]+1),t3,t2);}

/* k2633 in a2630 in k2115 in ##sys#repl-eval-hook in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_2635(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a2624 in k2115 in ##sys#repl-eval-hook in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_2625(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2625,2,t0,t1);}
/* csi.scm: 390  eval */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* k2121 in k2115 in ##sys#repl-eval-hook in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_2123(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2123,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2129,a[2]=((C_word*)t0)[15],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(t1);
t4=t3;
((C_proc2)C_retrieve_proc(t4))(2,t4,t2);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[14],lf[71]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2144,a[2]=((C_word*)t0)[12],a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[15],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 281  read */
t4=((C_word*)t0)[11];
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[14],lf[73]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2167,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[15],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 285  read */
t5=((C_word*)t0)[11];
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[14],lf[74]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2185,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[15],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 290  read */
t6=((C_word*)t0)[11];
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[14],lf[76]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2200,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[15],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 294  read */
t7=((C_word*)t0)[11];
((C_proc2)C_retrieve_proc(t7))(2,t7,t6);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[14],lf[78]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2215,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[15],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 298  read */
t8=((C_word*)t0)[11];
((C_proc2)C_retrieve_proc(t8))(2,t8,t7);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[14],lf[79]);
if(C_truep(t7)){
/* csi.scm: 303  report */
((C_proc2)C_retrieve_symbol_proc(lf[80]))(2,*((C_word*)lf[80]+1),((C_word*)t0)[15]);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[14],lf[81]);
if(C_truep(t8)){
/* csi.scm: 304  exit */
((C_proc2)C_retrieve_symbol_proc(lf[70]))(2,*((C_word*)lf[70]+1),((C_word*)t0)[15]);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[14],lf[82]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2254,a[2]=((C_word*)t0)[15],tmp=(C_word)a,a+=3,tmp);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2264,a[2]=t10,a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 306  read-line */
t12=((C_word*)t0)[8];
((C_proc2)C_retrieve_proc(t12))(2,t12,t11);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[14],lf[85]);
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2273,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[15],tmp=(C_word)a,a+=5,tmp);
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2298,a[2]=t11,a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 310  read-line */
t13=((C_word*)t0)[8];
((C_proc2)C_retrieve_proc(t13))(2,t13,t12);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[14],lf[89]);
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2307,a[2]=((C_word*)t0)[15],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 314  read */
t13=((C_word*)t0)[11];
((C_proc2)C_retrieve_proc(t13))(2,t13,t12);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[14],lf[93]);
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2360,a[2]=((C_word*)t0)[15],tmp=(C_word)a,a+=3,tmp);
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2364,a[2]=t13,tmp=(C_word)a,a+=3,tmp);
t15=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2368,a[2]=t14,a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 318  read-line */
t16=((C_word*)t0)[8];
((C_proc2)C_retrieve_proc(t16))(2,t16,t15);}
else{
t13=(C_word)C_eqp(((C_word*)t0)[14],lf[104]);
if(C_truep(t13)){
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2381,a[2]=((C_word*)t0)[15],tmp=(C_word)a,a+=3,tmp);
t15=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2385,a[2]=t14,tmp=(C_word)a,a+=3,tmp);
t16=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2389,a[2]=t15,a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 319  read-line */
t17=((C_word*)t0)[8];
((C_proc2)C_retrieve_proc(t17))(2,t17,t16);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[14],lf[108]);
if(C_truep(t14)){
t15=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2402,a[2]=((C_word*)t0)[15],tmp=(C_word)a,a+=3,tmp);
t16=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2406,a[2]=t15,tmp=(C_word)a,a+=3,tmp);
t17=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2410,a[2]=t16,a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 320  read-line */
t18=((C_word*)t0)[8];
((C_proc2)C_retrieve_proc(t18))(2,t18,t17);}
else{
t15=(C_word)C_eqp(((C_word*)t0)[14],lf[113]);
if(C_truep(t15)){
t16=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2423,a[2]=((C_word*)t0)[15],tmp=(C_word)a,a+=3,tmp);
t17=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2427,a[2]=t16,tmp=(C_word)a,a+=3,tmp);
t18=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2431,a[2]=t17,a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 321  read-line */
t19=((C_word*)t0)[8];
((C_proc2)C_retrieve_proc(t19))(2,t19,t18);}
else{
t16=(C_word)C_eqp(((C_word*)t0)[14],lf[115]);
if(C_truep(t16)){
/* csi.scm: 322  do-unbreak-all */
((C_proc2)C_retrieve_symbol_proc(lf[116]))(2,*((C_word*)lf[116]+1),((C_word*)t0)[15]);}
else{
t17=(C_word)C_eqp(((C_word*)t0)[14],lf[117]);
if(C_truep(t17)){
t18=C_set_block_item(lf[118] /* break-in-thread */,0,C_SCHEME_FALSE);
t19=((C_word*)t0)[15];
((C_proc2)(void*)(*((C_word*)t19+1)))(2,t19,t18);}
else{
t18=(C_word)C_eqp(((C_word*)t0)[14],lf[119]);
if(C_truep(t18)){
t19=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2457,a[2]=((C_word*)t0)[15],tmp=(C_word)a,a+=3,tmp);
t20=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2461,a[2]=t19,a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 326  read */
t21=((C_word*)t0)[11];
((C_proc2)C_retrieve_proc(t21))(2,t21,t20);}
else{
t19=(C_word)C_eqp(((C_word*)t0)[14],lf[120]);
if(C_truep(t19)){
t20=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2470,a[2]=((C_word*)t0)[15],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(C_retrieve2(lf[94],"traced-procedures")))){
t21=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2493,a[2]=t20,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* map */
t22=*((C_word*)lf[102]+1);
((C_proc4)(void*)(*((C_word*)t22+1)))(4,t22,t21,*((C_word*)lf[122]+1),C_retrieve2(lf[94],"traced-procedures"));}
else{
t21=t20;
f_2470(2,t21,C_SCHEME_UNDEFINED);}}
else{
t20=(C_word)C_eqp(((C_word*)t0)[14],lf[124]);
if(C_truep(t20)){
if(C_truep(C_retrieve(lf[125]))){
t21=C_retrieve(lf[125]);
t22=C_set_block_item(lf[125] /* last-breakpoint */,0,C_SCHEME_FALSE);
/* csi.scm: 336  ##sys#break-resume */
((C_proc3)C_retrieve_symbol_proc(lf[126]))(3,*((C_word*)lf[126]+1),((C_word*)t0)[15],t21);}
else{
/* csi.scm: 337  display */
t21=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t21))(3,t21,((C_word*)t0)[15],lf[127]);}}
else{
t21=(C_word)C_eqp(((C_word*)t0)[14],lf[128]);
if(C_truep(t21)){
if(C_truep(C_retrieve(lf[129]))){
t22=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2521,a[2]=((C_word*)t0)[15],tmp=(C_word)a,a+=3,tmp);
t23=(C_word)C_a_i_list(&a,1,C_retrieve(lf[129]));
/* csi.scm: 340  history-add */
((C_proc3)C_retrieve_symbol_proc(lf[45]))(3,*((C_word*)lf[45]+1),t22,t23);}
else{
t22=((C_word*)t0)[15];
((C_proc2)(void*)(*((C_word*)t22+1)))(2,t22,C_SCHEME_UNDEFINED);}}
else{
t22=(C_word)C_eqp(((C_word*)t0)[14],lf[130]);
if(C_truep(t22)){
t23=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2537,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[15],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 343  read */
t24=((C_word*)t0)[11];
((C_proc2)C_retrieve_proc(t24))(2,t24,t23);}
else{
t23=(C_word)C_eqp(((C_word*)t0)[14],lf[132]);
if(C_truep(t23)){
t24=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2568,a[2]=((C_word*)t0)[15],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 347  read-line */
t25=((C_word*)t0)[8];
((C_proc2)C_retrieve_proc(t25))(2,t25,t24);}
else{
t24=(C_word)C_eqp(((C_word*)t0)[14],lf[134]);
if(C_truep(t24)){
t25=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2587,a[2]=((C_word*)t0)[15],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 352  display */
t26=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t26))(3,t26,t25,lf[137]);}
else{
t25=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2611,a[2]=((C_word*)t0)[15],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 387  printf */
t26=((C_word*)t0)[5];
((C_proc4)C_retrieve_proc(t26))(4,t26,t25,lf[138],((C_word*)t0)[2]);}}}}}}}}}}}}}}}}}}}}}}}}}

/* k2609 in k2121 in k2115 in ##sys#repl-eval-hook in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_2611(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_retrieve(lf[46]));}

/* k2585 in k2121 in k2115 in ##sys#repl-eval-hook in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_2587(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2587,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2590,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2595,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 378  ##sys#hash-table-for-each */
((C_proc4)C_retrieve_symbol_proc(lf[136]))(4,*((C_word*)lf[136]+1),t2,t3,C_retrieve2(lf[54],"command-table"));}

/* a2594 in k2585 in k2121 in k2115 in ##sys#repl-eval-hook in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_2595(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2595,4,t0,t1,t2,t3);}
t4=(C_word)C_i_cdr(t3);
if(C_truep(t4)){
/* csi.scm: 382  print */
((C_proc4)C_retrieve_proc(*((C_word*)lf[15]+1)))(4,*((C_word*)lf[15]+1),t1,C_make_character(32),t4);}
else{
/* csi.scm: 383  print */
((C_proc4)C_retrieve_proc(*((C_word*)lf[15]+1)))(4,*((C_word*)lf[15]+1),t1,lf[135],t2);}}

/* k2588 in k2585 in k2121 in k2115 in ##sys#repl-eval-hook in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_2590(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_retrieve(lf[46]));}

/* k2566 in k2121 in k2115 in ##sys#repl-eval-hook in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_2568(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2568,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2571,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 348  system */
((C_proc3)C_retrieve_symbol_proc(lf[133]))(3,*((C_word*)lf[133]+1),t2,t1);}

/* k2569 in k2566 in k2121 in k2115 in ##sys#repl-eval-hook in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_2571(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2571,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2574,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_a_i_list(&a,1,t1);
/* csi.scm: 349  history-add */
((C_proc3)C_retrieve_symbol_proc(lf[45]))(3,*((C_word*)lf[45]+1),t2,t3);}

/* k2572 in k2569 in k2566 in k2121 in k2115 in ##sys#repl-eval-hook in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_2574(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k2535 in k2121 in k2115 in ##sys#repl-eval-hook in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_2537(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2537,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2540,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 344  read-line */
t3=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k2538 in k2535 in k2121 in k2115 in ##sys#repl-eval-hook in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_2540(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2540,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2547,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t3);
t5=(C_word)C_a_i_cons(&a,2,lf[131],t4);
/* csi.scm: 345  eval */
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t2,t5);}

/* k2545 in k2538 in k2535 in k2121 in k2115 in ##sys#repl-eval-hook in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_2547(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 345  singlestep */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2519 in k2121 in k2115 in ##sys#repl-eval-hook in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_2521(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 341  describe */
((C_proc3)C_retrieve_symbol_proc(lf[75]))(3,*((C_word*)lf[75]+1),((C_word*)t0)[2],C_retrieve(lf[129]));}

/* k2491 in k2121 in k2115 in ##sys#repl-eval-hook in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_2493(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 329  printf */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[123],t1);}

/* k2468 in k2121 in k2115 in ##sys#repl-eval-hook in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_2470(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2470,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(C_retrieve2(lf[97],"broken-procedures")))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2483,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* map */
t3=*((C_word*)lf[102]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[122]+1),C_retrieve2(lf[97],"broken-procedures"));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k2481 in k2468 in k2121 in k2115 in ##sys#repl-eval-hook in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_2483(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 331  printf */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[121],t1);}

/* k2459 in k2121 in k2115 in ##sys#repl-eval-hook in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_2461(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 326  eval */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2455 in k2121 in k2115 in ##sys#repl-eval-hook in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_2457(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[118]+1 /* (set! break-in-thread ...) */,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2429 in k2121 in k2115 in ##sys#repl-eval-hook in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_2431(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 321  string-split */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2425 in k2121 in k2115 in ##sys#repl-eval-hook in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_2427(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[102]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve2(lf[103],"resolve-var"),t1);}

/* k2421 in k2121 in k2115 in ##sys#repl-eval-hook in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_2423(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2423,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3018,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[83]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,t1);}

/* a3017 in k2421 in k2121 in k2115 in ##sys#repl-eval-hook in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_3018(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3018,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3022,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 507  expand */
((C_proc3)C_retrieve_symbol_proc(lf[64]))(3,*((C_word*)lf[64]+1),t3,t2);}

/* k3020 in a3017 in k2421 in k2121 in k2115 in ##sys#repl-eval-hook in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_3022(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3022,2,t0,t1);}
t2=(C_word)C_i_assq(t1,C_retrieve2(lf[97],"broken-procedures"));
if(C_truep(t2)){
t3=(C_word)C_i_cdr(t2);
t4=(C_word)C_i_setslot(t1,C_fix(0),t3);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3041,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 512  del */
((C_proc5)C_retrieve_symbol_proc(lf[105]))(5,*((C_word*)lf[105]+1),t5,t2,C_retrieve2(lf[97],"broken-procedures"),*((C_word*)lf[106]+1));}
else{
/* csi.scm: 509  ##sys#warn */
((C_proc4)C_retrieve_symbol_proc(lf[95]))(4,*((C_word*)lf[95]+1),((C_word*)t0)[2],lf[114],t1);}}

/* k3039 in k3020 in a3017 in k2421 in k2121 in k2115 in ##sys#repl-eval-hook in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_3041(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[97] /* (set! broken-procedures ...) */,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2408 in k2121 in k2115 in ##sys#repl-eval-hook in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_2410(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 320  string-split */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2404 in k2121 in k2115 in ##sys#repl-eval-hook in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_2406(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[102]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve2(lf[103],"resolve-var"),t1);}

/* k2400 in k2121 in k2115 in ##sys#repl-eval-hook in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_2402(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2402,2,t0,t1);}
t2=((C_word*)t0)[2];
if(C_truep((C_word)C_i_nullp(t1))){
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2937,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[83]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_retrieve2(lf[97],"broken-procedures"));}
else{
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2950,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[83]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,t1);}}

/* a2949 in k2400 in k2121 in k2115 in ##sys#repl-eval-hook in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_2950(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2950,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2954,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 486  expand */
((C_proc3)C_retrieve_symbol_proc(lf[64]))(3,*((C_word*)lf[64]+1),t3,t2);}

/* k2952 in a2949 in k2400 in k2121 in k2115 in ##sys#repl-eval-hook in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_2954(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2954,2,t0,t1);}
t2=(C_word)C_i_assq(t1,C_retrieve2(lf[94],"traced-procedures"));
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2960,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t2)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2999,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 489  ##sys#warn */
((C_proc4)C_retrieve_symbol_proc(lf[95]))(4,*((C_word*)lf[95]+1),t4,lf[112],t1);}
else{
t4=t3;
f_2960(t4,C_SCHEME_UNDEFINED);}}

/* k2997 in k2952 in a2949 in k2400 in k2121 in k2115 in ##sys#repl-eval-hook in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_2999(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2999,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
t3=(C_word)C_i_setslot(((C_word*)t0)[3],C_fix(0),t2);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3006,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 491  del */
((C_proc5)C_retrieve_symbol_proc(lf[105]))(5,*((C_word*)lf[105]+1),t4,((C_word*)t0)[4],C_retrieve2(lf[94],"traced-procedures"),*((C_word*)lf[106]+1));}

/* k3004 in k2997 in k2952 in a2949 in k2400 in k2121 in k2115 in ##sys#repl-eval-hook in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_3006(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[94] /* (set! traced-procedures ...) */,t1);
t3=((C_word*)t0)[2];
f_2960(t3,t2);}

/* k2958 in k2952 in a2949 in k2400 in k2121 in k2115 in ##sys#repl-eval-hook in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_fcall f_2960(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2960,NULL,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(0));
if(C_truep((C_word)C_i_closurep(t2))){
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_retrieve2(lf[97],"broken-procedures"));
t5=C_mutate(&lf[97] /* (set! broken-procedures ...) */,t4);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2981,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_i_setslot(((C_word*)t0)[3],C_fix(0),t6));}
else{
/* csi.scm: 493  ##sys#error */
t3=*((C_word*)lf[47]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],lf[111],((C_word*)t0)[3]);}}

/* a2980 in k2958 in k2952 in a2949 in k2400 in k2121 in k2115 in ##sys#repl-eval-hook in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_2981(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_2981r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2981r(t0,t1,t2);}}

static void C_ccall f_2981r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2985,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 499  ##sys#break-entry */
((C_proc4)C_retrieve_symbol_proc(lf[110]))(4,*((C_word*)lf[110]+1),t3,((C_word*)t0)[2],t2);}

/* k2983 in a2980 in k2958 in k2952 in a2949 in k2400 in k2121 in k2115 in ##sys#repl-eval-hook in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_2985(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a2936 in k2400 in k2121 in k2115 in ##sys#repl-eval-hook in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_2937(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2937,3,t0,t1,t2);}
t3=(C_word)C_i_car(C_retrieve(lf[109]));
/* csi.scm: 483  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[15]+1)))(3,*((C_word*)lf[15]+1),t1,t3);}

/* k2387 in k2121 in k2115 in ##sys#repl-eval-hook in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_2389(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 319  string-split */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2383 in k2121 in k2115 in ##sys#repl-eval-hook in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_2385(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[102]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve2(lf[103],"resolve-var"),t1);}

/* k2379 in k2121 in k2115 in ##sys#repl-eval-hook in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_2381(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2381,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2896,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[83]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,t1);}

/* a2895 in k2379 in k2121 in k2115 in ##sys#repl-eval-hook in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_2896(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2896,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2900,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 472  expand */
((C_proc3)C_retrieve_symbol_proc(lf[64]))(3,*((C_word*)lf[64]+1),t3,t2);}

/* k2898 in a2895 in k2379 in k2121 in k2115 in ##sys#repl-eval-hook in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_2900(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2900,2,t0,t1);}
t2=(C_word)C_i_assq(t1,C_retrieve2(lf[94],"traced-procedures"));
if(C_truep(t2)){
t3=(C_word)C_i_cdr(t2);
t4=(C_word)C_i_setslot(t1,C_fix(0),t3);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2919,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 477  del */
((C_proc5)C_retrieve_symbol_proc(lf[105]))(5,*((C_word*)lf[105]+1),t5,t2,C_retrieve2(lf[94],"traced-procedures"),*((C_word*)lf[106]+1));}
else{
/* csi.scm: 474  ##sys#warn */
((C_proc4)C_retrieve_symbol_proc(lf[95]))(4,*((C_word*)lf[95]+1),((C_word*)t0)[2],lf[107],t1);}}

/* k2917 in k2898 in a2895 in k2379 in k2121 in k2115 in ##sys#repl-eval-hook in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_2919(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[94] /* (set! traced-procedures ...) */,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2366 in k2121 in k2115 in ##sys#repl-eval-hook in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_2368(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 318  string-split */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2362 in k2121 in k2115 in ##sys#repl-eval-hook in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_2364(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[102]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve2(lf[103],"resolve-var"),t1);}

/* k2358 in k2121 in k2115 in ##sys#repl-eval-hook in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_2360(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2360,2,t0,t1);}
t2=((C_word*)t0)[2];
if(C_truep((C_word)C_i_nullp(t1))){
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2802,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[83]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_retrieve2(lf[94],"traced-procedures"));}
else{
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2815,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[83]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,t1);}}

/* a2814 in k2358 in k2121 in k2115 in ##sys#repl-eval-hook in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_2815(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2815,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2819,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 448  expand */
((C_proc3)C_retrieve_symbol_proc(lf[64]))(3,*((C_word*)lf[64]+1),t3,t2);}

/* k2817 in a2814 in k2358 in k2121 in k2115 in ##sys#repl-eval-hook in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_2819(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2819,2,t0,t1);}
if(C_truep((C_word)C_i_assq(t1,C_retrieve2(lf[94],"traced-procedures")))){
/* csi.scm: 450  ##sys#warn */
((C_proc4)C_retrieve_symbol_proc(lf[95]))(4,*((C_word*)lf[95]+1),((C_word*)t0)[2],lf[96],t1);}
else{
if(C_truep((C_word)C_i_assq(t1,C_retrieve2(lf[97],"broken-procedures")))){
/* csi.scm: 452  ##sys#warn */
((C_proc3)C_retrieve_symbol_proc(lf[95]))(3,*((C_word*)lf[95]+1),((C_word*)t0)[2],lf[98]);}
else{
t2=(C_word)C_slot(t1,C_fix(0));
if(C_truep((C_word)C_i_closurep(t2))){
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_retrieve2(lf[94],"traced-procedures"));
t5=C_mutate(&lf[94] /* (set! traced-procedures ...) */,t4);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2858,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_i_setslot(t1,C_fix(0),t6));}
else{
/* csi.scm: 455  ##sys#error */
t3=*((C_word*)lf[47]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],lf[101],t1);}}}}

/* a2857 in k2817 in a2814 in k2358 in k2121 in k2115 in ##sys#repl-eval-hook in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_2858(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr2r,(void*)f_2858r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2858r(t0,t1,t2);}}

static void C_ccall f_2858r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(6);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2862,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 461  traced-procedure-entry */
((C_proc4)C_retrieve_symbol_proc(lf[100]))(4,*((C_word*)lf[100]+1),t3,((C_word*)t0)[2],t2);}

/* k2860 in a2857 in k2817 in a2814 in k2358 in k2121 in k2115 in ##sys#repl-eval-hook in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_2862(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2862,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2867,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2873,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 462  call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a2872 in k2860 in a2857 in k2817 in a2814 in k2358 in k2121 in k2115 in ##sys#repl-eval-hook in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_2873(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_2873r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2873r(t0,t1,t2);}}

static void C_ccall f_2873r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2877,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 464  traced-procedure-exit */
((C_proc4)C_retrieve_symbol_proc(lf[99]))(4,*((C_word*)lf[99]+1),t3,((C_word*)t0)[2],t2);}

/* k2875 in a2872 in k2860 in a2857 in k2817 in a2814 in k2358 in k2121 in k2115 in ##sys#repl-eval-hook in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_2877(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a2866 in k2860 in a2857 in k2817 in a2814 in k2358 in k2121 in k2115 in ##sys#repl-eval-hook in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_2867(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2867,2,t0,t1);}
C_apply(4,0,t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a2801 in k2358 in k2121 in k2115 in ##sys#repl-eval-hook in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_2802(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2802,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
/* csi.scm: 445  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[15]+1)))(3,*((C_word*)lf[15]+1),t1,t3);}

/* k2305 in k2121 in k2115 in ##sys#repl-eval-hook in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_2307(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2307,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2312,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2340,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a2339 in k2305 in k2121 in k2115 in ##sys#repl-eval-hook in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_2340(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_2340r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2340r(t0,t1,t2);}}

static void C_ccall f_2340r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2344,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 316  history-add */
((C_proc3)C_retrieve_symbol_proc(lf[45]))(3,*((C_word*)lf[45]+1),t3,t2);}

/* k2342 in a2339 in k2305 in k2121 in k2115 in ##sys#repl-eval-hook in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_2344(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a2311 in k2305 in k2121 in k2115 in ##sys#repl-eval-hook in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_2312(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2312,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2316,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* ##sys#start-timer */
t3=*((C_word*)lf[92]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2314 in a2311 in k2305 in k2121 in k2115 in ##sys#repl-eval-hook in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_2316(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2316,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2321,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2327,tmp=(C_word)a,a+=2,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a2326 in k2314 in a2311 in k2305 in k2121 in k2115 in ##sys#repl-eval-hook in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_2327(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr2r,(void*)f_2327r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2327r(t0,t1,t2);}}

static void C_ccall f_2327r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(7);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2331,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2338,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* ##sys#stop-timer */
t5=*((C_word*)lf[91]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* k2336 in a2326 in k2314 in a2311 in k2305 in k2121 in k2115 in ##sys#repl-eval-hook in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_2338(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#display-times */
((C_proc3)C_retrieve_symbol_proc(lf[90]))(3,*((C_word*)lf[90]+1),((C_word*)t0)[2],t1);}

/* k2329 in a2326 in k2314 in a2311 in k2305 in k2121 in k2115 in ##sys#repl-eval-hook in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_2331(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a2320 in k2314 in a2311 in k2305 in k2121 in k2115 in ##sys#repl-eval-hook in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_2321(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2321,2,t0,t1);}
/* csi.scm: 315  eval */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* k2296 in k2121 in k2115 in ##sys#repl-eval-hook in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_2298(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 310  string-split */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2271 in k2121 in k2115 in ##sys#repl-eval-hook in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_2273(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2273,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2276,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2281,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t4=*((C_word*)lf[83]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,t1);}

/* a2280 in k2271 in k2121 in k2115 in ##sys#repl-eval-hook in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_2281(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2281,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2287,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* load-noisily278 */
t4=((C_word*)t0)[2];
((C_proc5)C_retrieve_proc(t4))(5,t4,t1,t2,lf[88],t3);}

/* a2286 in a2280 in k2271 in k2121 in k2115 in ##sys#repl-eval-hook in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_2287(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2287,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2291,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 311  pretty-print */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k2289 in a2286 in a2280 in k2271 in k2121 in k2115 in ##sys#repl-eval-hook in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_2291(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 311  print* */
((C_proc3)C_retrieve_proc(*((C_word*)lf[86]+1)))(3,*((C_word*)lf[86]+1),((C_word*)t0)[2],lf[87]);}

/* k2274 in k2271 in k2121 in k2115 in ##sys#repl-eval-hook in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_2276(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_retrieve(lf[46]));}

/* k2262 in k2121 in k2115 in ##sys#repl-eval-hook in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_2264(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 306  string-split */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2252 in k2121 in k2115 in ##sys#repl-eval-hook in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_2254(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2254,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2257,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* for-each */
t3=*((C_word*)lf[83]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_retrieve(lf[84]),t1);}

/* k2255 in k2252 in k2121 in k2115 in ##sys#repl-eval-hook in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_2257(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_retrieve(lf[46]));}

/* k2213 in k2121 in k2115 in ##sys#repl-eval-hook in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_2215(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2215,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2218,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 299  read */
t3=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k2216 in k2213 in k2121 in k2115 in ##sys#repl-eval-hook in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_2218(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2218,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2221,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 300  eval */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k2219 in k2216 in k2213 in k2121 in k2115 in ##sys#repl-eval-hook in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_2221(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2221,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2224,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 301  eval */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k2222 in k2219 in k2216 in k2213 in k2121 in k2115 in ##sys#repl-eval-hook in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_2224(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 302  dump */
((C_proc4)C_retrieve_symbol_proc(lf[77]))(4,*((C_word*)lf[77]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2198 in k2121 in k2115 in ##sys#repl-eval-hook in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_2200(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2200,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2203,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 295  eval */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k2201 in k2198 in k2121 in k2115 in ##sys#repl-eval-hook in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_2203(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 296  dump */
((C_proc3)C_retrieve_symbol_proc(lf[77]))(3,*((C_word*)lf[77]+1),((C_word*)t0)[2],t1);}

/* k2183 in k2121 in k2115 in ##sys#repl-eval-hook in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_2185(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2185,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2188,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 291  eval */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k2186 in k2183 in k2121 in k2115 in ##sys#repl-eval-hook in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_2188(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 292  describe */
((C_proc3)C_retrieve_symbol_proc(lf[75]))(3,*((C_word*)lf[75]+1),((C_word*)t0)[2],t1);}

/* k2165 in k2121 in k2115 in ##sys#repl-eval-hook in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_2167(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2167,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2170,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 286  eval */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k2168 in k2165 in k2121 in k2115 in ##sys#repl-eval-hook in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_2170(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2170,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2173,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 287  pretty-print */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k2171 in k2168 in k2165 in k2121 in k2115 in ##sys#repl-eval-hook in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_2173(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_retrieve(lf[46]));}

/* k2142 in k2121 in k2115 in ##sys#repl-eval-hook in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_2144(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2144,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2147,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2154,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2158,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 282  expand */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t1);}

/* k2156 in k2142 in k2121 in k2115 in ##sys#repl-eval-hook in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_2158(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 282  ##sys#strip-syntax */
((C_proc3)C_retrieve_symbol_proc(lf[72]))(3,*((C_word*)lf[72]+1),((C_word*)t0)[2],t1);}

/* k2152 in k2142 in k2121 in k2115 in ##sys#repl-eval-hook in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_2154(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 282  pretty-print */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2145 in k2142 in k2121 in k2115 in ##sys#repl-eval-hook in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_2147(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_retrieve(lf[46]));}

/* k2127 in k2121 in k2115 in ##sys#repl-eval-hook in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_2129(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_retrieve(lf[46]));}

/* toplevel-command in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_2059(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_2059r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_2059r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2059r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2063,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_2063(2,t6,C_SCHEME_FALSE);}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_2063(2,t7,(C_word)C_i_car(t4));}
else{
/* ##sys#error */
t7=*((C_word*)lf[47]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* k2061 in toplevel-command in k2055 in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_2063(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2063,2,t0,t1);}
t2=(C_word)C_i_check_symbol_2(((C_word*)t0)[4],lf[55]);
t3=(C_truep(t1)?(C_word)C_i_check_string_2(t1,lf[55]):C_SCHEME_UNDEFINED);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
/* csi.scm: 251  ##sys#hash-table-set! */
((C_proc5)C_retrieve_symbol_proc(lf[56]))(5,*((C_word*)lf[56]+1),((C_word*)t0)[2],C_retrieve2(lf[54],"command-table"),((C_word*)t0)[4],t4);}

/* ##sys#read-prompt-hook in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_2043(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2043,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2050,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 244  tty-input? */
((C_proc2)C_retrieve_symbol_proc(lf[49]))(2,*((C_word*)lf[49]+1),t2);}

/* k2048 in ##sys#read-prompt-hook in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_2050(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* csi.scm: 244  old */
t2=((C_word*)t0)[3];
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* ##csi#tty-input? in k2026 in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_2030(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2030,2,t0,t1);}
t2=(C_word)C_fudge(C_fix(12));
if(C_truep(t2)){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
/* csi.scm: 237  ##sys#tty-port? */
((C_proc3)C_retrieve_symbol_proc(lf[50]))(3,*((C_word*)lf[50]+1),t1,*((C_word*)lf[51]+1));}}

/* ##csi#history-ref in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_2003(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2003,3,t0,t1,t2);}
t3=(C_word)C_i_inexact_to_exact(t2);
t4=(C_word)C_fixnum_greaterp(t3,C_fix(0));
t5=(C_truep(t4)?(C_word)C_fixnum_less_or_equal_p(t3,C_retrieve(lf[25])):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_i_vector_ref(C_retrieve(lf[43]),t3));}
else{
/* csi.scm: 229  ##sys#error */
t6=*((C_word*)lf[47]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t1,lf[48],t2);}}

/* ##csi#history-add in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_1964(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1964,3,t0,t1,t2);}
t3=(C_word)C_i_nullp(t2);
t4=(C_truep(t3)?C_retrieve(lf[46]):(C_word)C_slot(t2,C_fix(0)));
t5=(C_word)C_block_size(C_retrieve(lf[43]));
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1974,a[2]=t1,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(C_retrieve(lf[25]),t5))){
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1988,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_fixnum_times(C_fix(2),t5);
/* csi.scm: 220  vector-resize */
t9=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t9))(4,t9,t7,C_retrieve(lf[43]),t8);}
else{
t7=t6;
f_1974(t7,C_SCHEME_UNDEFINED);}}

/* k1986 in ##csi#history-add in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_1988(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[43]+1 /* (set! history-list ...) */,t1);
t3=((C_word*)t0)[2];
f_1974(t3,t2);}

/* k1972 in ##csi#history-add in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_fcall f_1974(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_i_vector_set(C_retrieve(lf[43]),C_retrieve(lf[25]),((C_word*)t0)[3]);
t3=(C_word)C_fixnum_plus(C_retrieve(lf[25]),C_fix(1));
t4=C_mutate((C_word*)lf[25]+1 /* (set! history-count ...) */,t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,((C_word*)t0)[3]);}

/* ##csi#lookup-script-file in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_1858(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1858,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1862,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 193  get-environment-variable */
((C_proc3)C_retrieve_symbol_proc(lf[41]))(3,*((C_word*)lf[41]+1),t3,lf[42]);}

/* k1860 in ##csi#lookup-script-file in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_1862(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1862,2,t0,t1);}
t2=(C_word)C_block_size(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_greaterp(t2,C_fix(0)))){
t3=(C_word)C_i_string_ref(((C_word*)t0)[5],C_fix(0));
t4=(C_word)C_eqp(t3,C_make_character(92));
t5=(C_truep(t4)?t4:(C_word)C_eqp(t3,C_make_character(47)));
if(C_truep(t5)){
/* csi.scm: 195  addext */
f_1810(((C_word*)t0)[3],((C_word*)t0)[5]);}
else{
t6=((C_word*)t0)[5];
t7=(C_word)C_block_size(t6);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1837,a[2]=t6,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
t9=f_1837(t8,C_fix(0));
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1886,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t11=((C_word*)t0)[2];
t12=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t13=(C_truep(t11)?(C_word)C_i_foreign_block_argumentp(t11):C_SCHEME_FALSE);
t14=(C_word)C_i_foreign_fixnum_argumentp(C_fix(256));
t15=(C_word)stub123(t12,t13,t14);
/* ##sys#peek-nonnull-c-string */
t16=*((C_word*)lf[37]+1);
((C_proc4)(void*)(*((C_word*)t16+1)))(4,t16,t10,t15,C_fix(0));}
else{
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1903,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 199  addext */
f_1810(t10,((C_word*)t0)[5]);}}}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k1901 in k1860 in ##csi#lookup-script-file in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_1903(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1903,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1909,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 201  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[33]+1)))(4,*((C_word*)lf[33]+1),t2,lf[40],((C_word*)t0)[2]);}}

/* k1907 in k1901 in k1860 in ##csi#lookup-script-file in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_1909(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1909,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1916,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 202  string-split */
((C_proc4)C_retrieve_symbol_proc(lf[38]))(4,*((C_word*)lf[38]+1),t2,((C_word*)t0)[2],lf[39]);}

/* k1914 in k1907 in k1901 in k1860 in ##csi#lookup-script-file in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_1916(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1916,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1918,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_1918(t5,((C_word*)t0)[2],t1);}

/* loop in k1914 in k1907 in k1901 in k1860 in ##csi#lookup-script-file in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_fcall f_1918(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1918,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1928,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1945,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_slot(t2,C_fix(0));
/* csi.scm: 204  chop-separator */
((C_proc3)C_retrieve_symbol_proc(lf[29]))(3,*((C_word*)lf[29]+1),t4,t5);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k1943 in loop in k1914 in k1907 in k1901 in k1860 in ##csi#lookup-script-file in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_1945(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 204  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[33]+1)))(4,*((C_word*)lf[33]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k1926 in loop in k1914 in k1907 in k1901 in k1860 in ##csi#lookup-script-file in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_1928(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1928,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1931,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 205  addext */
f_1810(t2,t1);}

/* k1929 in k1926 in loop in k1914 in k1907 in k1901 in k1860 in ##csi#lookup-script-file in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_1931(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* csi.scm: 206  loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_1918(t3,((C_word*)t0)[4],t2);}}

/* k1884 in k1860 in ##csi#lookup-script-file in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_1886(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1886,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1896,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1900,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 198  chop-separator */
((C_proc3)C_retrieve_symbol_proc(lf[29]))(3,*((C_word*)lf[29]+1),t3,t1);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k1898 in k1884 in k1860 in ##csi#lookup-script-file in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_1900(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 198  string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[33]+1)))(5,*((C_word*)lf[33]+1),((C_word*)t0)[3],t1,lf[36],((C_word*)t0)[2]);}

/* k1894 in k1884 in k1860 in ##csi#lookup-script-file in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_1896(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 198  addext */
f_1810(((C_word*)t0)[2],t1);}

/* loop in k1860 in ##csi#lookup-script-file in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static C_word C_fcall f_1837(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
loop:
C_stack_check;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[3]))){
return(C_SCHEME_FALSE);}
else{
t2=(C_word)C_subchar(((C_word*)t0)[2],t1);
t3=(C_word)C_eqp(t2,C_make_character(92));
t4=(C_truep(t3)?t3:(C_word)C_eqp(t2,C_make_character(47)));
if(C_truep(t4)){
return(t1);}
else{
t5=(C_word)C_fixnum_plus(t1,C_fix(1));
t7=t5;
t1=t7;
goto loop;}}}

/* addext in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_fcall f_1810(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1810,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1817,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 182  file-exists? */
((C_proc3)C_retrieve_symbol_proc(lf[32]))(3,*((C_word*)lf[32]+1),t3,t2);}

/* k1815 in addext in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_1817(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1817,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1820,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 184  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[33]+1)))(4,*((C_word*)lf[33]+1),t2,((C_word*)t0)[2],lf[34]);}}

/* k1818 in k1815 in addext in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_1820(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1820,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1826,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 185  file-exists? */
((C_proc3)C_retrieve_symbol_proc(lf[32]))(3,*((C_word*)lf[32]+1),t2,t1);}

/* k1824 in k1818 in k1815 in addext in k1789 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_1826(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?((C_word*)t0)[2]:C_SCHEME_FALSE));}

/* ##csi#chop-separator in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_1760(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1760,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1764,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_block_size(t2);
/* csi.scm: 167  sub1 */
((C_proc3)C_retrieve_proc(*((C_word*)lf[30]+1)))(3,*((C_word*)lf[30]+1),t3,t4);}

/* k1762 in ##csi#chop-separator in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_1764(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1764,2,t0,t1);}
t2=(C_word)C_i_string_ref(((C_word*)t0)[4],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1773,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_greaterp(t1,C_fix(0)))){
t4=(C_word)C_eqp(t2,C_make_character(92));
t5=t3;
f_1773(t5,(C_truep(t4)?t4:(C_word)C_eqp(t2,C_make_character(47))));}
else{
t4=t3;
f_1773(t4,C_SCHEME_FALSE);}}

/* k1771 in k1762 in ##csi#chop-separator in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_fcall f_1773(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* csi.scm: 170  substring */
t2=((C_word*)t0)[5];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],C_fix(0),((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}}

/* ##sys#sharp-number-hook in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_1734(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1734,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1746,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 156  history-ref */
((C_proc3)C_retrieve_symbol_proc(lf[26]))(3,*((C_word*)lf[26]+1),t4,t3);}

/* k1744 in ##sys#sharp-number-hook in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_1746(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1746,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[24],t2));}

/* ##sys#user-read-hook in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_1701(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1701,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(C_make_character(41),t2);
t5=(C_truep(t4)?t4:(C_word)C_u_i_char_whitespacep(t2));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1722,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t7=(C_word)C_fixnum_difference(C_retrieve(lf[25]),C_fix(1));
/* csi.scm: 151  history-ref */
((C_proc3)C_retrieve_symbol_proc(lf[26]))(3,*((C_word*)lf[26]+1),t6,t7);}
else{
/* csi.scm: 152  old-hook */
t6=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t6))(4,t6,t1,t2,t3);}}

/* k1720 in ##sys#user-read-hook in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_1722(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1722,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[24],t2));}

/* ##csi#print-banner in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_1685(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1685,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1689,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 121  newline */
((C_proc2)C_retrieve_proc(*((C_word*)lf[20]+1)))(2,*((C_word*)lf[20]+1),t2);}

/* k1687 in ##csi#print-banner in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_1689(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1689,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1692,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 139  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[15]+1)))(3,*((C_word*)lf[15]+1),t2,lf[19]);}

/* k1690 in k1687 in ##csi#print-banner in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_1692(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1692,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1699,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 140  chicken-version */
((C_proc3)C_retrieve_symbol_proc(lf[18]))(3,*((C_word*)lf[18]+1),t2,C_SCHEME_TRUE);}

/* k1697 in k1690 in k1687 in ##csi#print-banner in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_1699(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 140  print */
((C_proc5)C_retrieve_proc(*((C_word*)lf[15]+1)))(5,*((C_word*)lf[15]+1),((C_word*)t0)[2],lf[16],t1,lf[17]);}

/* ##csi#print-usage in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_1657(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1657,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1661,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 73   display */
((C_proc3)C_retrieve_proc(*((C_word*)lf[8]+1)))(3,*((C_word*)lf[8]+1),t2,lf[13]);}

/* k1659 in ##csi#print-usage in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_1661(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1661,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1664,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1671,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_a_i_cons(&a,2,lf[10],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[2],t4);
t6=(C_word)C_a_i_cons(&a,2,lf[11],t5);
/* csi.scm: 93   ##sys#print-to-string */
((C_proc3)C_retrieve_symbol_proc(lf[12]))(3,*((C_word*)lf[12]+1),t3,t6);}

/* k1669 in k1659 in ##csi#print-usage in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_1671(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 93   display */
((C_proc3)C_retrieve_proc(*((C_word*)lf[8]+1)))(3,*((C_word*)lf[8]+1),((C_word*)t0)[2],t1);}

/* k1662 in k1659 in ##csi#print-usage in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1627 in k1624 in k1621 in k1618 */
static void C_ccall f_1664(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 98   display */
((C_proc3)C_retrieve_proc(*((C_word*)lf[8]+1)))(3,*((C_word*)lf[8]+1),((C_word*)t0)[2],lf[9]);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[440] = {
{"toplevel:csi_scm",(void*)C_toplevel},
{"f_1620:csi_scm",(void*)f_1620},
{"f_1623:csi_scm",(void*)f_1623},
{"f_1626:csi_scm",(void*)f_1626},
{"f_1629:csi_scm",(void*)f_1629},
{"f_1632:csi_scm",(void*)f_1632},
{"f_1635:csi_scm",(void*)f_1635},
{"f_1638:csi_scm",(void*)f_1638},
{"f_1641:csi_scm",(void*)f_1641},
{"f_1644:csi_scm",(void*)f_1644},
{"f_1647:csi_scm",(void*)f_1647},
{"f_1791:csi_scm",(void*)f_1791},
{"f_5654:csi_scm",(void*)f_5654},
{"f_2028:csi_scm",(void*)f_2028},
{"f_2057:csi_scm",(void*)f_2057},
{"f_3368:csi_scm",(void*)f_3368},
{"f_5646:csi_scm",(void*)f_5646},
{"f_5652:csi_scm",(void*)f_5652},
{"f_5649:csi_scm",(void*)f_5649},
{"f_4829:csi_scm",(void*)f_4829},
{"f_5640:csi_scm",(void*)f_5640},
{"f_3075:csi_scm",(void*)f_3075},
{"f_3105:csi_scm",(void*)f_3105},
{"f_3123:csi_scm",(void*)f_3123},
{"f_3162:csi_scm",(void*)f_3162},
{"f_3168:csi_scm",(void*)f_3168},
{"f_3129:csi_scm",(void*)f_3129},
{"f_3137:csi_scm",(void*)f_3137},
{"f_3139:csi_scm",(void*)f_3139},
{"f_3156:csi_scm",(void*)f_3156},
{"f_3111:csi_scm",(void*)f_3111},
{"f_3117:csi_scm",(void*)f_3117},
{"f_3103:csi_scm",(void*)f_3103},
{"f_3100:csi_scm",(void*)f_3100},
{"f_3080:csi_scm",(void*)f_3080},
{"f_3090:csi_scm",(void*)f_3090},
{"f_3093:csi_scm",(void*)f_3093},
{"f_4833:csi_scm",(void*)f_4833},
{"f_5636:csi_scm",(void*)f_5636},
{"f_4836:csi_scm",(void*)f_4836},
{"f_4839:csi_scm",(void*)f_4839},
{"f_4842:csi_scm",(void*)f_4842},
{"f_5632:csi_scm",(void*)f_5632},
{"f_5619:csi_scm",(void*)f_5619},
{"f_5579:csi_scm",(void*)f_5579},
{"f_5529:csi_scm",(void*)f_5529},
{"f_5532:csi_scm",(void*)f_5532},
{"f_5535:csi_scm",(void*)f_5535},
{"f_5538:csi_scm",(void*)f_5538},
{"f_5547:csi_scm",(void*)f_5547},
{"f_4845:csi_scm",(void*)f_4845},
{"f_4848:csi_scm",(void*)f_4848},
{"f_5523:csi_scm",(void*)f_5523},
{"f_4851:csi_scm",(void*)f_4851},
{"f_4854:csi_scm",(void*)f_4854},
{"f_5514:csi_scm",(void*)f_5514},
{"f_5510:csi_scm",(void*)f_5510},
{"f_4860:csi_scm",(void*)f_4860},
{"f_5012:csi_scm",(void*)f_5012},
{"f_5499:csi_scm",(void*)f_5499},
{"f_5502:csi_scm",(void*)f_5502},
{"f_5015:csi_scm",(void*)f_5015},
{"f_5490:csi_scm",(void*)f_5490},
{"f_5493:csi_scm",(void*)f_5493},
{"f_5018:csi_scm",(void*)f_5018},
{"f_5021:csi_scm",(void*)f_5021},
{"f_5483:csi_scm",(void*)f_5483},
{"f_5476:csi_scm",(void*)f_5476},
{"f_5024:csi_scm",(void*)f_5024},
{"f_5463:csi_scm",(void*)f_5463},
{"f_5466:csi_scm",(void*)f_5466},
{"f_5027:csi_scm",(void*)f_5027},
{"f_5457:csi_scm",(void*)f_5457},
{"f_5030:csi_scm",(void*)f_5030},
{"f_5442:csi_scm",(void*)f_5442},
{"f_5445:csi_scm",(void*)f_5445},
{"f_5448:csi_scm",(void*)f_5448},
{"f_5033:csi_scm",(void*)f_5033},
{"f_5439:csi_scm",(void*)f_5439},
{"f_5036:csi_scm",(void*)f_5036},
{"f_5435:csi_scm",(void*)f_5435},
{"f_5039:csi_scm",(void*)f_5039},
{"f_5431:csi_scm",(void*)f_5431},
{"f_5419:csi_scm",(void*)f_5419},
{"f_5427:csi_scm",(void*)f_5427},
{"f_5423:csi_scm",(void*)f_5423},
{"f_5415:csi_scm",(void*)f_5415},
{"f_5043:csi_scm",(void*)f_5043},
{"f_5046:csi_scm",(void*)f_5046},
{"f_5346:csi_scm",(void*)f_5346},
{"f_5349:csi_scm",(void*)f_5349},
{"f_5049:csi_scm",(void*)f_5049},
{"f_5334:csi_scm",(void*)f_5334},
{"f_5337:csi_scm",(void*)f_5337},
{"f_5052:csi_scm",(void*)f_5052},
{"f_5313:csi_scm",(void*)f_5313},
{"f_5316:csi_scm",(void*)f_5316},
{"f_5319:csi_scm",(void*)f_5319},
{"f_5322:csi_scm",(void*)f_5322},
{"f_5325:csi_scm",(void*)f_5325},
{"f_5055:csi_scm",(void*)f_5055},
{"f_5304:csi_scm",(void*)f_5304},
{"f_4909:csi_scm",(void*)f_4909},
{"f_4915:csi_scm",(void*)f_4915},
{"f_4937:csi_scm",(void*)f_4937},
{"f_4921:csi_scm",(void*)f_4921},
{"f_4924:csi_scm",(void*)f_4924},
{"f_4930:csi_scm",(void*)f_4930},
{"f_5058:csi_scm",(void*)f_5058},
{"f_5063:csi_scm",(void*)f_5063},
{"f_5276:csi_scm",(void*)f_5276},
{"f_5280:csi_scm",(void*)f_5280},
{"f_5283:csi_scm",(void*)f_5283},
{"f_5223:csi_scm",(void*)f_5223},
{"f_5244:csi_scm",(void*)f_5244},
{"f_5255:csi_scm",(void*)f_5255},
{"f_5234:csi_scm",(void*)f_5234},
{"f_5242:csi_scm",(void*)f_5242},
{"f_5213:csi_scm",(void*)f_5213},
{"f_5203:csi_scm",(void*)f_5203},
{"f_5187:csi_scm",(void*)f_5187},
{"f_5177:csi_scm",(void*)f_5177},
{"f_5157:csi_scm",(void*)f_5157},
{"f_5141:csi_scm",(void*)f_5141},
{"f_5117:csi_scm",(void*)f_5117},
{"f_5088:csi_scm",(void*)f_5088},
{"f_5076:csi_scm",(void*)f_5076},
{"f_4942:csi_scm",(void*)f_4942},
{"f_4989:csi_scm",(void*)f_4989},
{"f_4946:csi_scm",(void*)f_4946},
{"f_4949:csi_scm",(void*)f_4949},
{"f_4956:csi_scm",(void*)f_4956},
{"f_4958:csi_scm",(void*)f_4958},
{"f_4981:csi_scm",(void*)f_4981},
{"f_4979:csi_scm",(void*)f_4979},
{"f_4968:csi_scm",(void*)f_4968},
{"f_4975:csi_scm",(void*)f_4975},
{"f_4862:csi_scm",(void*)f_4862},
{"f_4868:csi_scm",(void*)f_4868},
{"f_4895:csi_scm",(void*)f_4895},
{"f_4684:csi_scm",(void*)f_4684},
{"f_4690:csi_scm",(void*)f_4690},
{"f_4712:csi_scm",(void*)f_4712},
{"f_4769:csi_scm",(void*)f_4769},
{"f_4762:csi_scm",(void*)f_4762},
{"f_4728:csi_scm",(void*)f_4728},
{"f_4751:csi_scm",(void*)f_4751},
{"f_4741:csi_scm",(void*)f_4741},
{"f_4745:csi_scm",(void*)f_4745},
{"f_4801:csi_scm",(void*)f_4801},
{"f_4627:csi_scm",(void*)f_4627},
{"f_4633:csi_scm",(void*)f_4633},
{"f_4645:csi_scm",(void*)f_4645},
{"f_4568:csi_scm",(void*)f_4568},
{"f_4572:csi_scm",(void*)f_4572},
{"f_4577:csi_scm",(void*)f_4577},
{"f_4606:csi_scm",(void*)f_4606},
{"f_4593:csi_scm",(void*)f_4593},
{"f_4359:csi_scm",(void*)f_4359},
{"f_4391:csi_scm",(void*)f_4391},
{"f_4566:csi_scm",(void*)f_4566},
{"f_4401:csi_scm",(void*)f_4401},
{"f_4404:csi_scm",(void*)f_4404},
{"f_4476:csi_scm",(void*)f_4476},
{"f_4537:csi_scm",(void*)f_4537},
{"f_4559:csi_scm",(void*)f_4559},
{"f_4555:csi_scm",(void*)f_4555},
{"f_4540:csi_scm",(void*)f_4540},
{"f_4495:csi_scm",(void*)f_4495},
{"f_4513:csi_scm",(void*)f_4513},
{"f_4523:csi_scm",(void*)f_4523},
{"f_4407:csi_scm",(void*)f_4407},
{"f_4410:csi_scm",(void*)f_4410},
{"f_4425:csi_scm",(void*)f_4425},
{"f_4438:csi_scm",(void*)f_4438},
{"f_4441:csi_scm",(void*)f_4441},
{"f_4413:csi_scm",(void*)f_4413},
{"f_4416:csi_scm",(void*)f_4416},
{"f_4362:csi_scm",(void*)f_4362},
{"f_4366:csi_scm",(void*)f_4366},
{"f_4382:csi_scm",(void*)f_4382},
{"f_4198:csi_scm",(void*)f_4198},
{"f_4311:csi_scm",(void*)f_4311},
{"f_4306:csi_scm",(void*)f_4306},
{"f_4200:csi_scm",(void*)f_4200},
{"f_4225:csi_scm",(void*)f_4225},
{"f_4268:csi_scm",(void*)f_4268},
{"f_4278:csi_scm",(void*)f_4278},
{"f_4249:csi_scm",(void*)f_4249},
{"f_4232:csi_scm",(void*)f_4232},
{"f_4203:csi_scm",(void*)f_4203},
{"f_4189:csi_scm",(void*)f_4189},
{"f_4193:csi_scm",(void*)f_4193},
{"f_3370:csi_scm",(void*)f_3370},
{"f_3374:csi_scm",(void*)f_3374},
{"f_4168:csi_scm",(void*)f_4168},
{"f_3502:csi_scm",(void*)f_3502},
{"f_3601:csi_scm",(void*)f_3601},
{"f_3809:csi_scm",(void*)f_3809},
{"f_3837:csi_scm",(void*)f_3837},
{"f_3846:csi_scm",(void*)f_3846},
{"f_3940:csi_scm",(void*)f_3940},
{"f_4074:csi_scm",(void*)f_4074},
{"f_4089:csi_scm",(void*)f_4089},
{"f_4128:csi_scm",(void*)f_4128},
{"f_4117:csi_scm",(void*)f_4117},
{"f_4113:csi_scm",(void*)f_4113},
{"f_4096:csi_scm",(void*)f_4096},
{"f_4007:csi_scm",(void*)f_4007},
{"f_4012:csi_scm",(void*)f_4012},
{"f_4016:csi_scm",(void*)f_4016},
{"f_4025:csi_scm",(void*)f_4025},
{"f_4060:csi_scm",(void*)f_4060},
{"f_4052:csi_scm",(void*)f_4052},
{"f_4035:csi_scm",(void*)f_4035},
{"f_3971:csi_scm",(void*)f_3971},
{"f_3974:csi_scm",(void*)f_3974},
{"f_3979:csi_scm",(void*)f_3979},
{"f_3959:csi_scm",(void*)f_3959},
{"f_3946:csi_scm",(void*)f_3946},
{"f_3934:csi_scm",(void*)f_3934},
{"f_3853:csi_scm",(void*)f_3853},
{"f_3864:csi_scm",(void*)f_3864},
{"f_3828:csi_scm",(void*)f_3828},
{"f_3769:csi_scm",(void*)f_3769},
{"f_3783:csi_scm",(void*)f_3783},
{"f_3779:csi_scm",(void*)f_3779},
{"f_3725:csi_scm",(void*)f_3725},
{"f_3631:csi_scm",(void*)f_3631},
{"f_3705:csi_scm",(void*)f_3705},
{"f_3634:csi_scm",(void*)f_3634},
{"f_3702:csi_scm",(void*)f_3702},
{"f_3699:csi_scm",(void*)f_3699},
{"f_3637:csi_scm",(void*)f_3637},
{"f_3649:csi_scm",(void*)f_3649},
{"f_3654:csi_scm",(void*)f_3654},
{"f_3664:csi_scm",(void*)f_3664},
{"f_3679:csi_scm",(void*)f_3679},
{"f_3667:csi_scm",(void*)f_3667},
{"f_3670:csi_scm",(void*)f_3670},
{"f_3571:csi_scm",(void*)f_3571},
{"f_3577:csi_scm",(void*)f_3577},
{"f_3505:csi_scm",(void*)f_3505},
{"f_3376:csi_scm",(void*)f_3376},
{"f_3499:csi_scm",(void*)f_3499},
{"f_3383:csi_scm",(void*)f_3383},
{"f_3388:csi_scm",(void*)f_3388},
{"f_3411:csi_scm",(void*)f_3411},
{"f_3420:csi_scm",(void*)f_3420},
{"f_3484:csi_scm",(void*)f_3484},
{"f_3430:csi_scm",(void*)f_3430},
{"f_3433:csi_scm",(void*)f_3433},
{"f_3174:csi_scm",(void*)f_3174},
{"f_3182:csi_scm",(void*)f_3182},
{"f_3184:csi_scm",(void*)f_3184},
{"f_3188:csi_scm",(void*)f_3188},
{"f_3191:csi_scm",(void*)f_3191},
{"f_3194:csi_scm",(void*)f_3194},
{"f_3211:csi_scm",(void*)f_3211},
{"f_3354:csi_scm",(void*)f_3354},
{"f_3350:csi_scm",(void*)f_3350},
{"f_3346:csi_scm",(void*)f_3346},
{"f_3313:csi_scm",(void*)f_3313},
{"f_3317:csi_scm",(void*)f_3317},
{"f_3322:csi_scm",(void*)f_3322},
{"f_3330:csi_scm",(void*)f_3330},
{"f_3214:csi_scm",(void*)f_3214},
{"f_3242:csi_scm",(void*)f_3242},
{"f_3250:csi_scm",(void*)f_3250},
{"f_3254:csi_scm",(void*)f_3254},
{"f_3258:csi_scm",(void*)f_3258},
{"f_3262:csi_scm",(void*)f_3262},
{"f_3266:csi_scm",(void*)f_3266},
{"f_3217:csi_scm",(void*)f_3217},
{"f_3220:csi_scm",(void*)f_3220},
{"f_3223:csi_scm",(void*)f_3223},
{"f_3226:csi_scm",(void*)f_3226},
{"f_3196:csi_scm",(void*)f_3196},
{"f_3204:csi_scm",(void*)f_3204},
{"f_3047:csi_scm",(void*)f_3047},
{"f_3057:csi_scm",(void*)f_3057},
{"f_3051:csi_scm",(void*)f_3051},
{"f_2756:csi_scm",(void*)f_2756},
{"f_2761:csi_scm",(void*)f_2761},
{"f_2764:csi_scm",(void*)f_2764},
{"f_2767:csi_scm",(void*)f_2767},
{"f_2770:csi_scm",(void*)f_2770},
{"f_2781:csi_scm",(void*)f_2781},
{"f_2785:csi_scm",(void*)f_2785},
{"f_2773:csi_scm",(void*)f_2773},
{"f_2776:csi_scm",(void*)f_2776},
{"f_2733:csi_scm",(void*)f_2733},
{"f_2737:csi_scm",(void*)f_2737},
{"f_2741:csi_scm",(void*)f_2741},
{"f_2744:csi_scm",(void*)f_2744},
{"f_2747:csi_scm",(void*)f_2747},
{"f_2705:csi_scm",(void*)f_2705},
{"f_2709:csi_scm",(void*)f_2709},
{"f_2714:csi_scm",(void*)f_2714},
{"f_2724:csi_scm",(void*)f_2724},
{"f_2731:csi_scm",(void*)f_2731},
{"f_2664:csi_scm",(void*)f_2664},
{"f_2670:csi_scm",(void*)f_2670},
{"f_2686:csi_scm",(void*)f_2686},
{"f_2696:csi_scm",(void*)f_2696},
{"f_2650:csi_scm",(void*)f_2650},
{"f_2658:csi_scm",(void*)f_2658},
{"f_2662:csi_scm",(void*)f_2662},
{"f_2100:csi_scm",(void*)f_2100},
{"f_2117:csi_scm",(void*)f_2117},
{"f_2631:csi_scm",(void*)f_2631},
{"f_2635:csi_scm",(void*)f_2635},
{"f_2625:csi_scm",(void*)f_2625},
{"f_2123:csi_scm",(void*)f_2123},
{"f_2611:csi_scm",(void*)f_2611},
{"f_2587:csi_scm",(void*)f_2587},
{"f_2595:csi_scm",(void*)f_2595},
{"f_2590:csi_scm",(void*)f_2590},
{"f_2568:csi_scm",(void*)f_2568},
{"f_2571:csi_scm",(void*)f_2571},
{"f_2574:csi_scm",(void*)f_2574},
{"f_2537:csi_scm",(void*)f_2537},
{"f_2540:csi_scm",(void*)f_2540},
{"f_2547:csi_scm",(void*)f_2547},
{"f_2521:csi_scm",(void*)f_2521},
{"f_2493:csi_scm",(void*)f_2493},
{"f_2470:csi_scm",(void*)f_2470},
{"f_2483:csi_scm",(void*)f_2483},
{"f_2461:csi_scm",(void*)f_2461},
{"f_2457:csi_scm",(void*)f_2457},
{"f_2431:csi_scm",(void*)f_2431},
{"f_2427:csi_scm",(void*)f_2427},
{"f_2423:csi_scm",(void*)f_2423},
{"f_3018:csi_scm",(void*)f_3018},
{"f_3022:csi_scm",(void*)f_3022},
{"f_3041:csi_scm",(void*)f_3041},
{"f_2410:csi_scm",(void*)f_2410},
{"f_2406:csi_scm",(void*)f_2406},
{"f_2402:csi_scm",(void*)f_2402},
{"f_2950:csi_scm",(void*)f_2950},
{"f_2954:csi_scm",(void*)f_2954},
{"f_2999:csi_scm",(void*)f_2999},
{"f_3006:csi_scm",(void*)f_3006},
{"f_2960:csi_scm",(void*)f_2960},
{"f_2981:csi_scm",(void*)f_2981},
{"f_2985:csi_scm",(void*)f_2985},
{"f_2937:csi_scm",(void*)f_2937},
{"f_2389:csi_scm",(void*)f_2389},
{"f_2385:csi_scm",(void*)f_2385},
{"f_2381:csi_scm",(void*)f_2381},
{"f_2896:csi_scm",(void*)f_2896},
{"f_2900:csi_scm",(void*)f_2900},
{"f_2919:csi_scm",(void*)f_2919},
{"f_2368:csi_scm",(void*)f_2368},
{"f_2364:csi_scm",(void*)f_2364},
{"f_2360:csi_scm",(void*)f_2360},
{"f_2815:csi_scm",(void*)f_2815},
{"f_2819:csi_scm",(void*)f_2819},
{"f_2858:csi_scm",(void*)f_2858},
{"f_2862:csi_scm",(void*)f_2862},
{"f_2873:csi_scm",(void*)f_2873},
{"f_2877:csi_scm",(void*)f_2877},
{"f_2867:csi_scm",(void*)f_2867},
{"f_2802:csi_scm",(void*)f_2802},
{"f_2307:csi_scm",(void*)f_2307},
{"f_2340:csi_scm",(void*)f_2340},
{"f_2344:csi_scm",(void*)f_2344},
{"f_2312:csi_scm",(void*)f_2312},
{"f_2316:csi_scm",(void*)f_2316},
{"f_2327:csi_scm",(void*)f_2327},
{"f_2338:csi_scm",(void*)f_2338},
{"f_2331:csi_scm",(void*)f_2331},
{"f_2321:csi_scm",(void*)f_2321},
{"f_2298:csi_scm",(void*)f_2298},
{"f_2273:csi_scm",(void*)f_2273},
{"f_2281:csi_scm",(void*)f_2281},
{"f_2287:csi_scm",(void*)f_2287},
{"f_2291:csi_scm",(void*)f_2291},
{"f_2276:csi_scm",(void*)f_2276},
{"f_2264:csi_scm",(void*)f_2264},
{"f_2254:csi_scm",(void*)f_2254},
{"f_2257:csi_scm",(void*)f_2257},
{"f_2215:csi_scm",(void*)f_2215},
{"f_2218:csi_scm",(void*)f_2218},
{"f_2221:csi_scm",(void*)f_2221},
{"f_2224:csi_scm",(void*)f_2224},
{"f_2200:csi_scm",(void*)f_2200},
{"f_2203:csi_scm",(void*)f_2203},
{"f_2185:csi_scm",(void*)f_2185},
{"f_2188:csi_scm",(void*)f_2188},
{"f_2167:csi_scm",(void*)f_2167},
{"f_2170:csi_scm",(void*)f_2170},
{"f_2173:csi_scm",(void*)f_2173},
{"f_2144:csi_scm",(void*)f_2144},
{"f_2158:csi_scm",(void*)f_2158},
{"f_2154:csi_scm",(void*)f_2154},
{"f_2147:csi_scm",(void*)f_2147},
{"f_2129:csi_scm",(void*)f_2129},
{"f_2059:csi_scm",(void*)f_2059},
{"f_2063:csi_scm",(void*)f_2063},
{"f_2043:csi_scm",(void*)f_2043},
{"f_2050:csi_scm",(void*)f_2050},
{"f_2030:csi_scm",(void*)f_2030},
{"f_2003:csi_scm",(void*)f_2003},
{"f_1964:csi_scm",(void*)f_1964},
{"f_1988:csi_scm",(void*)f_1988},
{"f_1974:csi_scm",(void*)f_1974},
{"f_1858:csi_scm",(void*)f_1858},
{"f_1862:csi_scm",(void*)f_1862},
{"f_1903:csi_scm",(void*)f_1903},
{"f_1909:csi_scm",(void*)f_1909},
{"f_1916:csi_scm",(void*)f_1916},
{"f_1918:csi_scm",(void*)f_1918},
{"f_1945:csi_scm",(void*)f_1945},
{"f_1928:csi_scm",(void*)f_1928},
{"f_1931:csi_scm",(void*)f_1931},
{"f_1886:csi_scm",(void*)f_1886},
{"f_1900:csi_scm",(void*)f_1900},
{"f_1896:csi_scm",(void*)f_1896},
{"f_1837:csi_scm",(void*)f_1837},
{"f_1810:csi_scm",(void*)f_1810},
{"f_1817:csi_scm",(void*)f_1817},
{"f_1820:csi_scm",(void*)f_1820},
{"f_1826:csi_scm",(void*)f_1826},
{"f_1760:csi_scm",(void*)f_1760},
{"f_1764:csi_scm",(void*)f_1764},
{"f_1773:csi_scm",(void*)f_1773},
{"f_1734:csi_scm",(void*)f_1734},
{"f_1746:csi_scm",(void*)f_1746},
{"f_1701:csi_scm",(void*)f_1701},
{"f_1722:csi_scm",(void*)f_1722},
{"f_1685:csi_scm",(void*)f_1685},
{"f_1689:csi_scm",(void*)f_1689},
{"f_1692:csi_scm",(void*)f_1692},
{"f_1699:csi_scm",(void*)f_1699},
{"f_1657:csi_scm",(void*)f_1657},
{"f_1661:csi_scm",(void*)f_1661},
{"f_1671:csi_scm",(void*)f_1671},
{"f_1664:csi_scm",(void*)f_1664},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
