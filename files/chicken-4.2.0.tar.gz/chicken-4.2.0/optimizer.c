/* Generated from optimizer.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2009-09-21 21:29
   Version 4.0.1 - SVN rev. 14292
   linux-unix-gnu-x86 [ manyargs dload ptables applyhook ]
   compiled 2009-05-12 on galinha (Linux)
   command line: optimizer.scm -no-trace -optimize-level 2 -include-path . -include-path ./ -no-lambda-info -inline -local -extend private-namespace.scm -output-file optimizer.c
   unit: optimizer
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_69_toplevel)
C_externimport void C_ccall C_srfi_69_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[316];
static double C_possibly_force_alignment;


C_noret_decl(C_optimizer_toplevel)
C_externexport void C_ccall C_optimizer_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3676)
static void C_ccall f_3676(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3679)
static void C_ccall f_3679(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3682)
static void C_ccall f_3682(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3685)
static void C_ccall f_3685(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3688)
static void C_ccall f_3688(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3691)
static void C_ccall f_3691(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3928)
static void C_ccall f_3928(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13049)
static void C_ccall f_13049(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_13057)
static void C_ccall f_13057(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13062)
static void C_fcall f_13062(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_13107)
static void C_ccall f_13107(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13111)
static void C_ccall f_13111(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13072)
static void C_ccall f_13072(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13096)
static void C_ccall f_13096(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13081)
static void C_fcall f_13081(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5661)
static void C_ccall f_5661(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12088)
static void C_ccall f_12088(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8) C_noret;
C_noret_decl(f_12122)
static void C_ccall f_12122(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12224)
static void C_ccall f_12224(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_12234)
static void C_fcall f_12234(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_12298)
static void C_ccall f_12298(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12327)
static void C_fcall f_12327(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_12450)
static void C_ccall f_12450(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12343)
static void C_fcall f_12343(C_word t0,C_word t1) C_noret;
C_noret_decl(f_12390)
static void C_ccall f_12390(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_12380)
static void C_ccall f_12380(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12388)
static void C_ccall f_12388(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12520)
static void C_ccall f_12520(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9,C_word t10) C_noret;
C_noret_decl(f_12533)
static void C_ccall f_12533(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12568)
static void C_ccall f_12568(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12552)
static void C_ccall f_12552(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12556)
static void C_ccall f_12556(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12545)
static void C_ccall f_12545(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12734)
static void C_ccall f_12734(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9,C_word t10,C_word t11,C_word t12,C_word t13) C_noret;
C_noret_decl(f_12747)
static void C_ccall f_12747(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12753)
static void C_ccall f_12753(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12799)
static void C_ccall f_12799(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12791)
static void C_ccall f_12791(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12775)
static void C_ccall f_12775(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12779)
static void C_ccall f_12779(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12783)
static void C_ccall f_12783(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5664)
static void C_ccall f_5664(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11766)
static void C_ccall f_11766(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8) C_noret;
C_noret_decl(f_11788)
static void C_ccall f_11788(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11843)
static void C_ccall f_11843(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11813)
static void C_ccall f_11813(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11835)
static void C_ccall f_11835(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11839)
static void C_ccall f_11839(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11831)
static void C_ccall f_11831(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11811)
static void C_ccall f_11811(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11937)
static void C_ccall f_11937(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9) C_noret;
C_noret_decl(f_11951)
static void C_ccall f_11951(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5667)
static void C_ccall f_5667(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5995)
static void C_ccall f_5995(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11740)
static void C_ccall f_11740(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11582)
static void C_ccall f_11582(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_11586)
static void C_ccall f_11586(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11589)
static void C_ccall f_11589(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11592)
static void C_ccall f_11592(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11595)
static void C_ccall f_11595(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11598)
static void C_ccall f_11598(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11601)
static void C_ccall f_11601(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11607)
static void C_fcall f_11607(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10694)
static void C_ccall f_10694(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11533)
static void C_ccall f_11533(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_11543)
static void C_ccall f_11543(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11550)
static void C_ccall f_11550(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11566)
static void C_ccall f_11566(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10697)
static void C_ccall f_10697(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11531)
static void C_ccall f_11531(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11527)
static void C_ccall f_11527(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11523)
static void C_ccall f_11523(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11519)
static void C_ccall f_11519(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11515)
static void C_ccall f_11515(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11511)
static void C_ccall f_11511(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11507)
static void C_ccall f_11507(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11375)
static void C_ccall f_11375(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_11379)
static void C_ccall f_11379(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11382)
static void C_ccall f_11382(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11392)
static void C_ccall f_11392(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11436)
static void C_ccall f_11436(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11416)
static void C_ccall f_11416(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10703)
static void C_ccall f_10703(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11348)
static void C_ccall f_11348(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_11358)
static void C_ccall f_11358(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10706)
static void C_ccall f_10706(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11335)
static void C_ccall f_11335(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_11339)
static void C_ccall f_11339(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10709)
static void C_ccall f_10709(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10711)
static void C_ccall f_10711(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7) C_noret;
C_noret_decl(f_10717)
static void C_ccall f_10717(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11317)
static void C_ccall f_11317(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11321)
static void C_ccall f_11321(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11306)
static void C_ccall f_11306(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11313)
static void C_ccall f_11313(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10739)
static void C_fcall f_10739(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10742)
static void C_ccall f_10742(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10773)
static void C_ccall f_10773(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10776)
static void C_ccall f_10776(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10779)
static void C_ccall f_10779(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10782)
static void C_ccall f_10782(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10785)
static void C_ccall f_10785(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10788)
static void C_ccall f_10788(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10791)
static void C_ccall f_10791(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10885)
static void C_fcall f_10885(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10946)
static void C_ccall f_10946(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11250)
static C_word C_fcall f_11250(C_word t0,C_word t1);
C_noret_decl(f_11164)
static void C_ccall f_11164(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11167)
static void C_ccall f_11167(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11134)
static void C_ccall f_11134(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11097)
static void C_ccall f_11097(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11060)
static void C_ccall f_11060(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11023)
static void C_ccall f_11023(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10998)
static void C_ccall f_10998(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10973)
static void C_ccall f_10973(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10952)
static void C_ccall f_10952(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10895)
static void C_ccall f_10895(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10898)
static void C_ccall f_10898(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10917)
static void C_ccall f_10917(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10913)
static void C_ccall f_10913(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10822)
static void C_fcall f_10822(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10865)
static void C_ccall f_10865(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10836)
static void C_fcall f_10836(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10875)
static C_word C_fcall f_10875(C_word *a,C_word t0,C_word t1);
C_noret_decl(f_10803)
static void C_fcall f_10803(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10793)
static C_word C_fcall f_10793(C_word t0);
C_noret_decl(f_10747)
static void C_fcall f_10747(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_10751)
static void C_ccall f_10751(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10764)
static void C_ccall f_10764(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10754)
static void C_ccall f_10754(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10642)
static void C_ccall f_10642(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_10642)
static void C_ccall f_10642r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_10646)
static void C_ccall f_10646(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10672)
static void C_ccall f_10672(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10654)
static void C_ccall f_10654(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10628)
static void C_ccall f_10628(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10632)
static void C_ccall f_10632(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10636)
static void C_ccall f_10636(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8984)
static void C_ccall f_8984(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10530)
static void C_ccall f_10530(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10533)
static void C_ccall f_10533(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10536)
static void C_ccall f_10536(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10539)
static void C_ccall f_10539(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10542)
static void C_ccall f_10542(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10545)
static void C_ccall f_10545(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10622)
static void C_ccall f_10622(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10548)
static void C_ccall f_10548(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10551)
static void C_ccall f_10551(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10554)
static void C_ccall f_10554(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10616)
static void C_ccall f_10616(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10557)
static void C_ccall f_10557(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10560)
static void C_ccall f_10560(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10613)
static void C_ccall f_10613(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9593)
static void C_fcall f_9593(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9611)
static void C_ccall f_9611(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9617)
static void C_ccall f_9617(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9597)
static void C_ccall f_9597(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10563)
static void C_ccall f_10563(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10605)
static void C_ccall f_10605(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10603)
static void C_ccall f_10603(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10566)
static void C_ccall f_10566(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10569)
static void C_ccall f_10569(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10572)
static void C_ccall f_10572(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10596)
static void C_ccall f_10596(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10575)
static void C_ccall f_10575(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10578)
static void C_ccall f_10578(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10581)
static void C_ccall f_10581(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10584)
static void C_ccall f_10584(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10587)
static void C_ccall f_10587(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10590)
static void C_ccall f_10590(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10383)
static void C_fcall f_10383(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10389)
static void C_ccall f_10389(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10501)
static void C_ccall f_10501(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10510)
static void C_ccall f_10510(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10513)
static void C_ccall f_10513(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10408)
static void C_ccall f_10408(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10413)
static void C_fcall f_10413(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10454)
static void C_fcall f_10454(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10451)
static void C_ccall f_10451(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10436)
static void C_ccall f_10436(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10447)
static void C_ccall f_10447(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10443)
static void C_ccall f_10443(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10296)
static void C_fcall f_10296(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10302)
static void C_ccall f_10302(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10358)
static void C_ccall f_10358(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10354)
static void C_ccall f_10354(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10324)
static void C_ccall f_10324(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10047)
static void C_fcall f_10047(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10061)
static void C_ccall f_10061(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10068)
static void C_ccall f_10068(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10071)
static void C_ccall f_10071(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10080)
static void C_ccall f_10080(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_10087)
static void C_ccall f_10087(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10090)
static void C_ccall f_10090(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10186)
static void C_ccall f_10186(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10272)
static void C_ccall f_10272(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_10291)
static void C_ccall f_10291(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10287)
static void C_ccall f_10287(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10253)
static void C_ccall f_10253(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10242)
static void C_ccall f_10242(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10229)
static void C_ccall f_10229(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10212)
static void C_ccall f_10212(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10205)
static void C_ccall f_10205(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10171)
static void C_ccall f_10171(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10093)
static void C_ccall f_10093(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10142)
static void C_ccall f_10142(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10130)
static void C_ccall f_10130(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10126)
static void C_ccall f_10126(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10059)
static void C_ccall f_10059(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9846)
static void C_fcall f_9846(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10033)
static void C_ccall f_10033(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9911)
static void C_ccall f_9911(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9988)
static void C_ccall f_9988(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9993)
static void C_ccall f_9993(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10031)
static void C_ccall f_10031(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9855)
static void C_ccall f_9855(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9893)
static void C_ccall f_9893(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9898)
static void C_ccall f_9898(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9875)
static void C_ccall f_9875(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9853)
static void C_ccall f_9853(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10023)
static void C_ccall f_10023(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10009)
static void C_ccall f_10009(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10007)
static void C_ccall f_10007(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9913)
static void C_ccall f_9913(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9981)
static void C_ccall f_9981(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9979)
static void C_ccall f_9979(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9967)
static void C_ccall f_9967(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9933)
static void C_ccall f_9933(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9957)
static void C_ccall f_9957(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9955)
static void C_ccall f_9955(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9951)
static void C_ccall f_9951(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9943)
static void C_ccall f_9943(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9627)
static void C_fcall f_9627(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9633)
static void C_fcall f_9633(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9652)
static void C_fcall f_9652(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9819)
static void C_ccall f_9819(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9749)
static void C_ccall f_9749(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9765)
static void C_ccall f_9765(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9795)
static void C_ccall f_9795(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9799)
static void C_ccall f_9799(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9785)
static void C_ccall f_9785(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9738)
static void C_ccall f_9738(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9743)
static void C_ccall f_9743(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9714)
static void C_ccall f_9714(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9726)
static void C_ccall f_9726(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9663)
static void C_fcall f_9663(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9684)
static void C_ccall f_9684(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9681)
static void C_ccall f_9681(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9631)
static void C_ccall f_9631(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9383)
static void C_fcall f_9383(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9389)
static void C_fcall f_9389(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9408)
static void C_fcall f_9408(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9510)
static void C_ccall f_9510(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9501)
static void C_ccall f_9501(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9467)
static void C_fcall f_9467(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9476)
static void C_ccall f_9476(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9488)
static void C_ccall f_9488(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9419)
static void C_fcall f_9419(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9440)
static void C_ccall f_9440(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9437)
static void C_ccall f_9437(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9387)
static void C_ccall f_9387(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9284)
static void C_fcall f_9284(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9290)
static void C_ccall f_9290(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9334)
static void C_ccall f_9334(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9339)
static void C_fcall f_9339(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9346)
static void C_ccall f_9346(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9373)
static void C_ccall f_9373(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9369)
static void C_ccall f_9369(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9361)
static void C_ccall f_9361(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9359)
static void C_ccall f_9359(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9324)
static void C_ccall f_9324(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9302)
static void C_ccall f_9302(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9309)
static void C_ccall f_9309(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9087)
static void C_fcall f_9087(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9241)
static void C_ccall f_9241(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9266)
static void C_ccall f_9266(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9256)
static void C_ccall f_9256(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9260)
static void C_ccall f_9260(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9239)
static void C_ccall f_9239(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9090)
static void C_fcall f_9090(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9229)
static void C_ccall f_9229(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9212)
static void C_ccall f_9212(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9224)
static void C_ccall f_9224(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9158)
static void C_fcall f_9158(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9182)
static void C_ccall f_9182(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9176)
static void C_ccall f_9176(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9140)
static void C_ccall f_9140(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9115)
static void C_fcall f_9115(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9118)
static void C_fcall f_9118(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9123)
static void C_ccall f_9123(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8987)
static void C_fcall f_8987(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8993)
static void C_ccall f_8993(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9024)
static void C_fcall f_9024(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9028)
static void C_ccall f_9028(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9032)
static void C_ccall f_9032(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8991)
static void C_ccall f_8991(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7889)
static void C_ccall f_7889(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8979)
static void C_ccall f_8979(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8982)
static void C_ccall f_8982(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7892)
static void C_fcall f_7892(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8048)
static void C_ccall f_8048(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8028)
static void C_ccall f_8028(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8002)
static void C_ccall f_8002(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7948)
static void C_ccall f_7948(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7954)
static void C_ccall f_7954(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7960)
static void C_ccall f_7960(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7917)
static void C_ccall f_7917(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8054)
static void C_fcall f_8054(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_8464)
static void C_ccall f_8464(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8471)
static void C_ccall f_8471(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8057)
static void C_fcall f_8057(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_8451)
static void C_ccall f_8451(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8427)
static void C_ccall f_8427(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8438)
static void C_ccall f_8438(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8394)
static void C_ccall f_8394(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8333)
static void C_fcall f_8333(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8305)
static void C_fcall f_8305(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8310)
static void C_ccall f_8310(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8252)
static void C_ccall f_8252(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8258)
static void C_fcall f_8258(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8263)
static void C_ccall f_8263(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8211)
static void C_ccall f_8211(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8217)
static void C_fcall f_8217(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8222)
static void C_ccall f_8222(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8195)
static void C_ccall f_8195(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8191)
static void C_ccall f_8191(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8161)
static void C_ccall f_8161(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8124)
static void C_ccall f_8124(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8140)
static void C_ccall f_8140(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8106)
static void C_ccall f_8106(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8473)
static void C_fcall f_8473(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7) C_noret;
C_noret_decl(f_8969)
static void C_ccall f_8969(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8967)
static void C_ccall f_8967(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8477)
static void C_ccall f_8477(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8487)
static void C_ccall f_8487(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8493)
static void C_fcall f_8493(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8499)
static void C_ccall f_8499(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8502)
static void C_ccall f_8502(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8508)
static void C_ccall f_8508(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8684)
static void C_ccall f_8684(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8906)
static void C_ccall f_8906(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8909)
static void C_ccall f_8909(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8859)
static void C_ccall f_8859(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8862)
static void C_ccall f_8862(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8728)
static void C_ccall f_8728(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8783)
static void C_ccall f_8783(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8786)
static void C_ccall f_8786(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8813)
static void C_ccall f_8813(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8789)
static void C_ccall f_8789(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8792)
static void C_ccall f_8792(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8737)
static void C_ccall f_8737(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8740)
static void C_ccall f_8740(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8743)
static void C_ccall f_8743(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8511)
static void C_ccall f_8511(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8666)
static void C_ccall f_8666(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8664)
static void C_ccall f_8664(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8607)
static void C_ccall f_8607(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8617)
static void C_ccall f_8617(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8514)
static void C_ccall f_8514(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8526)
static void C_ccall f_8526(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8565)
static void C_ccall f_8565(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8529)
static void C_ccall f_8529(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8532)
static void C_ccall f_8532(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8537)
static void C_ccall f_8537(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8563)
static void C_ccall f_8563(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8544)
static void C_ccall f_8544(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6017)
static void C_ccall f_6017(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8) C_noret;
C_noret_decl(f_7763)
static void C_ccall f_7763(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7785)
static void C_ccall f_7785(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7797)
static void C_ccall f_7797(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7811)
static void C_fcall f_7811(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7860)
static void C_ccall f_7860(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6042)
static void C_fcall f_6042(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7831)
static void C_ccall f_7831(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7835)
static void C_ccall f_7835(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7805)
static void C_ccall f_7805(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7791)
static void C_ccall f_7791(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7789)
static void C_ccall f_7789(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7778)
static void C_ccall f_7778(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7706)
static void C_ccall f_7706(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7738)
static void C_ccall f_7738(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7725)
static void C_fcall f_7725(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7558)
static void C_ccall f_7558(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7564)
static void C_ccall f_7564(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7648)
static void C_ccall f_7648(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7573)
static void C_ccall f_7573(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7617)
static void C_ccall f_7617(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7615)
static void C_ccall f_7615(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7589)
static void C_ccall f_7589(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7491)
static void C_ccall f_7491(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7519)
static void C_ccall f_7519(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7531)
static void C_ccall f_7531(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7509)
static void C_ccall f_7509(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7504)
static void C_ccall f_7504(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7349)
static void C_ccall f_7349(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7430)
static void C_ccall f_7430(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7358)
static void C_ccall f_7358(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7411)
static void C_ccall f_7411(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7409)
static void C_ccall f_7409(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7374)
static void C_ccall f_7374(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7320)
static void C_ccall f_7320(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7330)
static void C_ccall f_7330(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7258)
static void C_ccall f_7258(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7278)
static void C_fcall f_7278(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7185)
static void C_ccall f_7185(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7215)
static void C_fcall f_7215(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7098)
static void C_ccall f_7098(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7117)
static void C_ccall f_7117(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7110)
static void C_ccall f_7110(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7021)
static void C_ccall f_7021(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6962)
static void C_ccall f_6962(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6977)
static void C_fcall f_6977(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6980)
static void C_ccall f_6980(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6892)
static void C_ccall f_6892(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6935)
static void C_ccall f_6935(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6928)
static void C_ccall f_6928(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6833)
static void C_ccall f_6833(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6845)
static void C_fcall f_6845(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6858)
static void C_ccall f_6858(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6851)
static void C_ccall f_6851(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6746)
static void C_ccall f_6746(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6768)
static void C_ccall f_6768(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6776)
static void C_ccall f_6776(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6780)
static void C_ccall f_6780(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6602)
static void C_ccall f_6602(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6624)
static void C_fcall f_6624(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6627)
static void C_fcall f_6627(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6686)
static void C_ccall f_6686(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6630)
static void C_ccall f_6630(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6633)
static void C_ccall f_6633(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6664)
static void C_ccall f_6664(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6662)
static void C_ccall f_6662(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6638)
static void C_ccall f_6638(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6618)
static void C_ccall f_6618(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6581)
static void C_ccall f_6581(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6526)
static void C_ccall f_6526(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6550)
static void C_ccall f_6550(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6539)
static void C_ccall f_6539(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6461)
static void C_ccall f_6461(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6374)
static void C_ccall f_6374(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6416)
static void C_ccall f_6416(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6318)
static void C_ccall f_6318(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6331)
static void C_ccall f_6331(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6339)
static void C_ccall f_6339(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6280)
static void C_ccall f_6280(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6290)
static void C_ccall f_6290(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6182)
static void C_ccall f_6182(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6239)
static void C_ccall f_6239(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6210)
static void C_fcall f_6210(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6207)
static void C_fcall f_6207(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6074)
static void C_ccall f_6074(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6137)
static void C_ccall f_6137(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6077)
static void C_fcall f_6077(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5997)
static void C_ccall f_5997(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5997)
static void C_ccall f_5997r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6001)
static void C_ccall f_6001(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6011)
static void C_ccall f_6011(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5669)
static void C_ccall f_5669(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5673)
static void C_ccall f_5673(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5982)
static void C_ccall f_5982(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5991)
static void C_ccall f_5991(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5987)
static void C_ccall f_5987(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5720)
static void C_ccall f_5720(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5924)
static void C_ccall f_5924(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5956)
static void C_ccall f_5956(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5969)
static void C_ccall f_5969(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5934)
static void C_ccall f_5934(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5950)
static void C_ccall f_5950(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5938)
static void C_ccall f_5938(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5942)
static void C_ccall f_5942(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5723)
static void C_ccall f_5723(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5865)
static void C_ccall f_5865(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5908)
static void C_ccall f_5908(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5914)
static void C_ccall f_5914(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5872)
static void C_ccall f_5872(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5882)
static void C_ccall f_5882(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5895)
static void C_ccall f_5895(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5880)
static void C_ccall f_5880(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5876)
static void C_ccall f_5876(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5726)
static void C_ccall f_5726(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5729)
static void C_ccall f_5729(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5749)
static void C_ccall f_5749(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5762)
static void C_fcall f_5762(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5805)
static void C_ccall f_5805(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5837)
static void C_ccall f_5837(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5803)
static void C_ccall f_5803(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5785)
static void C_ccall f_5785(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5732)
static void C_ccall f_5732(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5741)
static void C_ccall f_5741(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5675)
static void C_fcall f_5675(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5681)
static void C_fcall f_5681(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5705)
static void C_ccall f_5705(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5654)
static void C_ccall f_5654(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5654)
static void C_ccall f_5654r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5413)
static void C_ccall f_5413(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5427)
static void C_ccall f_5427(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5442)
static void C_ccall f_5442(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5649)
static void C_ccall f_5649(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5447)
static void C_ccall f_5447(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5638)
static void C_ccall f_5638(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5460)
static void C_ccall f_5460(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5463)
static void C_ccall f_5463(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5469)
static void C_fcall f_5469(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5484)
static void C_fcall f_5484(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5490)
static void C_ccall f_5490(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5496)
static void C_fcall f_5496(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5505)
static void C_fcall f_5505(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5512)
static void C_ccall f_5512(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5515)
static void C_ccall f_5515(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5533)
static void C_ccall f_5533(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5518)
static void C_ccall f_5518(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5430)
static void C_ccall f_5430(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5433)
static void C_ccall f_5433(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5420)
static void C_fcall f_5420(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5416)
static C_word C_fcall f_5416(C_word t0);
C_noret_decl(f_3931)
static void C_ccall f_3931(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5317)
static void C_ccall f_5317(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5323)
static void C_ccall f_5323(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5327)
static void C_ccall f_5327(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5330)
static void C_ccall f_5330(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5366)
static void C_ccall f_5366(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5371)
static void C_ccall f_5371(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5375)
static void C_ccall f_5375(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5333)
static void C_ccall f_5333(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5336)
static void C_ccall f_5336(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5339)
static void C_ccall f_5339(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5342)
static void C_ccall f_5342(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5298)
static void C_fcall f_5298(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_5302)
static void C_ccall f_5302(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5308)
static void C_ccall f_5308(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4270)
static void C_fcall f_4270(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5214)
static void C_ccall f_5214(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5217)
static void C_ccall f_5217(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5290)
static void C_ccall f_5290(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5286)
static void C_ccall f_5286(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5258)
static void C_fcall f_5258(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5279)
static void C_ccall f_5279(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5271)
static void C_ccall f_5271(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5229)
static void C_fcall f_5229(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5248)
static void C_ccall f_5248(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5235)
static void C_ccall f_5235(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5189)
static void C_ccall f_5189(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5164)
static void C_ccall f_5164(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5154)
static void C_ccall f_5154(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4597)
static void C_ccall f_4597(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4606)
static void C_ccall f_4606(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4787)
static void C_fcall f_4787(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4798)
static void C_ccall f_4798(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5110)
static void C_ccall f_5110(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5116)
static void C_ccall f_5116(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5119)
static void C_ccall f_5119(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4808)
static void C_fcall f_4808(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4855)
static void C_ccall f_4855(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5097)
static void C_ccall f_5097(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5014)
static void C_fcall f_5014(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5017)
static void C_ccall f_5017(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5029)
static void C_ccall f_5029(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5040)
static void C_ccall f_5040(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5067)
static void C_ccall f_5067(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5059)
static void C_ccall f_5059(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5044)
static void C_ccall f_5044(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5034)
static void C_ccall f_5034(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4869)
static void C_fcall f_4869(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_4902)
static void C_ccall f_4902(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4908)
static void C_ccall f_4908(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4914)
static void C_ccall f_4914(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4951)
static void C_ccall f_4951(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4927)
static void C_ccall f_4927(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4931)
static void C_ccall f_4931(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4896)
static void C_ccall f_4896(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4885)
static void C_ccall f_4885(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4846)
static void C_ccall f_4846(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4811)
static void C_ccall f_4811(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4814)
static void C_ccall f_4814(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4817)
static void C_ccall f_4817(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4827)
static void C_ccall f_4827(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4773)
static void C_ccall f_4773(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4669)
static void C_ccall f_4669(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4690)
static void C_ccall f_4690(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4747)
static void C_ccall f_4747(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4739)
static void C_ccall f_4739(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4693)
static void C_fcall f_4693(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4718)
static void C_ccall f_4718(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4716)
static void C_ccall f_4716(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4702)
static void C_ccall f_4702(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4648)
static void C_fcall f_4648(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4615)
static void C_ccall f_4615(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4618)
static void C_ccall f_4618(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4628)
static void C_ccall f_4628(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4421)
static void C_ccall f_4421(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4513)
static void C_ccall f_4513(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4518)
static void C_ccall f_4518(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4525)
static void C_ccall f_4525(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4554)
static void C_ccall f_4554(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4538)
static void C_ccall f_4538(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4426)
static void C_ccall f_4426(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4444)
static void C_ccall f_4444(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4451)
static void C_ccall f_4451(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4487)
static void C_ccall f_4487(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4490)
static void C_ccall f_4490(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4480)
static void C_ccall f_4480(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4464)
static void C_ccall f_4464(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4432)
static void C_ccall f_4432(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4438)
static void C_ccall f_4438(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4370)
static void C_ccall f_4370(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4399)
static void C_ccall f_4399(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4406)
static void C_ccall f_4406(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4373)
static void C_fcall f_4373(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4390)
static void C_ccall f_4390(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4295)
static void C_fcall f_4295(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4299)
static void C_ccall f_4299(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4311)
static void C_ccall f_4311(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4334)
static void C_fcall f_4334(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4317)
static void C_ccall f_4317(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4328)
static void C_ccall f_4328(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4056)
static void C_ccall f_4056(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4070)
static void C_ccall f_4070(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4241)
static void C_ccall f_4241(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4247)
static void C_ccall f_4247(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4140)
static void C_ccall f_4140(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4222)
static void C_ccall f_4222(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4220)
static void C_ccall f_4220(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4151)
static void C_ccall f_4151(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4174)
static void C_ccall f_4174(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4206)
static void C_ccall f_4206(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4206)
static void C_ccall f_4206r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4212)
static void C_ccall f_4212(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4180)
static void C_ccall f_4180(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4184)
static void C_ccall f_4184(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4187)
static void C_ccall f_4187(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4204)
static void C_ccall f_4204(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4157)
static void C_ccall f_4157(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4163)
static void C_ccall f_4163(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4167)
static void C_fcall f_4167(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4171)
static void C_ccall f_4171(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4149)
static void C_ccall f_4149(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4079)
static void C_ccall f_4079(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3964)
static void C_fcall f_3964(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3968)
static void C_ccall f_3968(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3979)
static void C_ccall f_3979(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3989)
static void C_ccall f_3989(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4038)
static void C_ccall f_4038(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4036)
static void C_ccall f_4036(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3995)
static void C_ccall f_3995(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4001)
static void C_ccall f_4001(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4028)
static void C_ccall f_4028(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4007)
static void C_fcall f_4007(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3971)
static void C_ccall f_3971(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3960)
static C_word C_fcall f_3960(C_word t0);
C_noret_decl(f_3940)
static void C_ccall f_3940(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3934)
static void C_fcall f_3934(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3693)
static void C_ccall f_3693(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3714)
static void C_ccall f_3714(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3758)
static void C_ccall f_3758(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3773)
static void C_fcall f_3773(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3825)
static void C_fcall f_3825(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3889)
static void C_ccall f_3889(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3844)
static void C_ccall f_3844(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3855)
static void C_ccall f_3855(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3828)
static void C_ccall f_3828(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3798)
static void C_fcall f_3798(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3761)
static void C_fcall f_3761(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3767)
static void C_ccall f_3767(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3717)
static void C_ccall f_3717(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3720)
static void C_ccall f_3720(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3725)
static void C_ccall f_3725(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3730)
static void C_ccall f_3730(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3730)
static void C_ccall f_3730r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3734)
static void C_ccall f_3734(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3696)
static void C_ccall f_3696(C_word c,C_word t0,C_word t1,C_word t2) C_noret;

C_noret_decl(trf_13062)
static void C_fcall trf_13062(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_13062(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_13062(t0,t1,t2);}

C_noret_decl(trf_13081)
static void C_fcall trf_13081(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_13081(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_13081(t0,t1);}

C_noret_decl(trf_12234)
static void C_fcall trf_12234(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12234(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_12234(t0,t1,t2,t3);}

C_noret_decl(trf_12327)
static void C_fcall trf_12327(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12327(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_12327(t0,t1,t2,t3,t4);}

C_noret_decl(trf_12343)
static void C_fcall trf_12343(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12343(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_12343(t0,t1);}

C_noret_decl(trf_11607)
static void C_fcall trf_11607(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11607(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11607(t0,t1);}

C_noret_decl(trf_10739)
static void C_fcall trf_10739(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10739(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10739(t0,t1);}

C_noret_decl(trf_10885)
static void C_fcall trf_10885(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10885(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10885(t0,t1,t2);}

C_noret_decl(trf_10822)
static void C_fcall trf_10822(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10822(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10822(t0,t1,t2);}

C_noret_decl(trf_10836)
static void C_fcall trf_10836(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10836(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10836(t0,t1);}

C_noret_decl(trf_10803)
static void C_fcall trf_10803(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10803(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10803(t0,t1);}

C_noret_decl(trf_10747)
static void C_fcall trf_10747(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10747(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_10747(t0,t1,t2,t3,t4);}

C_noret_decl(trf_9593)
static void C_fcall trf_9593(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9593(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_9593(t0,t1,t2,t3);}

C_noret_decl(trf_10383)
static void C_fcall trf_10383(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10383(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10383(t0,t1,t2);}

C_noret_decl(trf_10413)
static void C_fcall trf_10413(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10413(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_10413(t0,t1,t2,t3);}

C_noret_decl(trf_10454)
static void C_fcall trf_10454(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10454(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10454(t0,t1);}

C_noret_decl(trf_10296)
static void C_fcall trf_10296(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10296(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10296(t0,t1,t2);}

C_noret_decl(trf_10047)
static void C_fcall trf_10047(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10047(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_10047(t0,t1,t2,t3);}

C_noret_decl(trf_9846)
static void C_fcall trf_9846(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9846(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9846(t0,t1,t2);}

C_noret_decl(trf_9627)
static void C_fcall trf_9627(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9627(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9627(t0,t1,t2);}

C_noret_decl(trf_9633)
static void C_fcall trf_9633(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9633(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_9633(t0,t1,t2,t3);}

C_noret_decl(trf_9652)
static void C_fcall trf_9652(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9652(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9652(t0,t1);}

C_noret_decl(trf_9663)
static void C_fcall trf_9663(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9663(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_9663(t0,t1,t2,t3);}

C_noret_decl(trf_9383)
static void C_fcall trf_9383(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9383(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9383(t0,t1,t2);}

C_noret_decl(trf_9389)
static void C_fcall trf_9389(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9389(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_9389(t0,t1,t2,t3);}

C_noret_decl(trf_9408)
static void C_fcall trf_9408(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9408(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9408(t0,t1);}

C_noret_decl(trf_9467)
static void C_fcall trf_9467(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9467(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9467(t0,t1);}

C_noret_decl(trf_9419)
static void C_fcall trf_9419(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9419(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_9419(t0,t1,t2,t3);}

C_noret_decl(trf_9284)
static void C_fcall trf_9284(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9284(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_9284(t0,t1,t2,t3);}

C_noret_decl(trf_9339)
static void C_fcall trf_9339(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9339(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_9339(t0,t1,t2,t3);}

C_noret_decl(trf_9087)
static void C_fcall trf_9087(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9087(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9087(t0,t1,t2);}

C_noret_decl(trf_9090)
static void C_fcall trf_9090(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9090(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_9090(t0,t1,t2,t3);}

C_noret_decl(trf_9158)
static void C_fcall trf_9158(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9158(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_9158(t0,t1,t2,t3);}

C_noret_decl(trf_9115)
static void C_fcall trf_9115(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9115(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9115(t0,t1);}

C_noret_decl(trf_9118)
static void C_fcall trf_9118(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9118(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9118(t0,t1);}

C_noret_decl(trf_8987)
static void C_fcall trf_8987(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8987(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8987(t0,t1);}

C_noret_decl(trf_9024)
static void C_fcall trf_9024(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9024(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9024(t0,t1);}

C_noret_decl(trf_7892)
static void C_fcall trf_7892(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7892(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_7892(t0,t1,t2,t3,t4);}

C_noret_decl(trf_8054)
static void C_fcall trf_8054(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8054(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_8054(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_8057)
static void C_fcall trf_8057(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8057(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_8057(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_8333)
static void C_fcall trf_8333(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8333(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8333(t0,t1);}

C_noret_decl(trf_8305)
static void C_fcall trf_8305(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8305(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8305(t0,t1);}

C_noret_decl(trf_8258)
static void C_fcall trf_8258(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8258(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8258(t0,t1);}

C_noret_decl(trf_8217)
static void C_fcall trf_8217(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8217(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8217(t0,t1);}

C_noret_decl(trf_8473)
static void C_fcall trf_8473(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8473(void *dummy){
C_word t7=C_pick(0);
C_word t6=C_pick(1);
C_word t5=C_pick(2);
C_word t4=C_pick(3);
C_word t3=C_pick(4);
C_word t2=C_pick(5);
C_word t1=C_pick(6);
C_word t0=C_pick(7);
C_adjust_stack(-8);
f_8473(t0,t1,t2,t3,t4,t5,t6,t7);}

C_noret_decl(trf_8493)
static void C_fcall trf_8493(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8493(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8493(t0,t1);}

C_noret_decl(trf_7811)
static void C_fcall trf_7811(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7811(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7811(t0,t1,t2,t3);}

C_noret_decl(trf_6042)
static void C_fcall trf_6042(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6042(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6042(t0,t1);}

C_noret_decl(trf_7725)
static void C_fcall trf_7725(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7725(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7725(t0,t1);}

C_noret_decl(trf_7278)
static void C_fcall trf_7278(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7278(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7278(t0,t1);}

C_noret_decl(trf_7215)
static void C_fcall trf_7215(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7215(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7215(t0,t1);}

C_noret_decl(trf_6977)
static void C_fcall trf_6977(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6977(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6977(t0,t1);}

C_noret_decl(trf_6845)
static void C_fcall trf_6845(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6845(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6845(t0,t1);}

C_noret_decl(trf_6624)
static void C_fcall trf_6624(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6624(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6624(t0,t1);}

C_noret_decl(trf_6627)
static void C_fcall trf_6627(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6627(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6627(t0,t1);}

C_noret_decl(trf_6210)
static void C_fcall trf_6210(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6210(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6210(t0,t1);}

C_noret_decl(trf_6207)
static void C_fcall trf_6207(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6207(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6207(t0,t1);}

C_noret_decl(trf_6077)
static void C_fcall trf_6077(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6077(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6077(t0,t1);}

C_noret_decl(trf_5762)
static void C_fcall trf_5762(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5762(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5762(t0,t1);}

C_noret_decl(trf_5675)
static void C_fcall trf_5675(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5675(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5675(t0,t1,t2,t3);}

C_noret_decl(trf_5681)
static void C_fcall trf_5681(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5681(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5681(t0,t1,t2,t3);}

C_noret_decl(trf_5469)
static void C_fcall trf_5469(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5469(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5469(t0,t1);}

C_noret_decl(trf_5484)
static void C_fcall trf_5484(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5484(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5484(t0,t1);}

C_noret_decl(trf_5496)
static void C_fcall trf_5496(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5496(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5496(t0,t1);}

C_noret_decl(trf_5505)
static void C_fcall trf_5505(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5505(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5505(t0,t1);}

C_noret_decl(trf_5420)
static void C_fcall trf_5420(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5420(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5420(t0,t1,t2,t3);}

C_noret_decl(trf_5298)
static void C_fcall trf_5298(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5298(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_5298(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_4270)
static void C_fcall trf_4270(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4270(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4270(t0,t1,t2);}

C_noret_decl(trf_5258)
static void C_fcall trf_5258(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5258(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5258(t0,t1);}

C_noret_decl(trf_5229)
static void C_fcall trf_5229(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5229(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5229(t0,t1);}

C_noret_decl(trf_4787)
static void C_fcall trf_4787(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4787(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4787(t0,t1);}

C_noret_decl(trf_4808)
static void C_fcall trf_4808(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4808(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4808(t0,t1);}

C_noret_decl(trf_5014)
static void C_fcall trf_5014(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5014(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5014(t0,t1);}

C_noret_decl(trf_4869)
static void C_fcall trf_4869(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4869(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_4869(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_4693)
static void C_fcall trf_4693(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4693(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4693(t0,t1);}

C_noret_decl(trf_4648)
static void C_fcall trf_4648(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4648(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4648(t0,t1);}

C_noret_decl(trf_4373)
static void C_fcall trf_4373(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4373(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4373(t0,t1);}

C_noret_decl(trf_4295)
static void C_fcall trf_4295(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4295(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4295(t0,t1,t2);}

C_noret_decl(trf_4334)
static void C_fcall trf_4334(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4334(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4334(t0,t1);}

C_noret_decl(trf_4167)
static void C_fcall trf_4167(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4167(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4167(t0,t1);}

C_noret_decl(trf_3964)
static void C_fcall trf_3964(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3964(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3964(t0,t1,t2);}

C_noret_decl(trf_4007)
static void C_fcall trf_4007(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4007(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4007(t0,t1);}

C_noret_decl(trf_3934)
static void C_fcall trf_3934(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3934(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3934(t0,t1,t2,t3);}

C_noret_decl(trf_3773)
static void C_fcall trf_3773(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3773(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3773(t0,t1,t2,t3);}

C_noret_decl(trf_3825)
static void C_fcall trf_3825(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3825(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3825(t0,t1);}

C_noret_decl(trf_3798)
static void C_fcall trf_3798(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3798(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3798(t0,t1);}

C_noret_decl(trf_3761)
static void C_fcall trf_3761(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3761(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3761(t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr8)
static void C_fcall tr8(C_proc8 k) C_regparm C_noret;
C_regparm static void C_fcall tr8(C_proc8 k){
C_word t7=C_pick(0);
C_word t6=C_pick(1);
C_word t5=C_pick(2);
C_word t4=C_pick(3);
C_word t3=C_pick(4);
C_word t2=C_pick(5);
C_word t1=C_pick(6);
C_word t0=C_pick(7);
C_adjust_stack(-8);
(k)(8,t0,t1,t2,t3,t4,t5,t6,t7);}

C_noret_decl(tr10)
static void C_fcall tr10(C_proc10 k) C_regparm C_noret;
C_regparm static void C_fcall tr10(C_proc10 k){
C_word t9=C_pick(0);
C_word t8=C_pick(1);
C_word t7=C_pick(2);
C_word t6=C_pick(3);
C_word t5=C_pick(4);
C_word t4=C_pick(5);
C_word t3=C_pick(6);
C_word t2=C_pick(7);
C_word t1=C_pick(8);
C_word t0=C_pick(9);
C_adjust_stack(-10);
(k)(10,t0,t1,t2,t3,t4,t5,t6,t7,t8,t9);}

C_noret_decl(tr14)
static void C_fcall tr14(C_proc14 k) C_regparm C_noret;
C_regparm static void C_fcall tr14(C_proc14 k){
C_word t13=C_pick(0);
C_word t12=C_pick(1);
C_word t11=C_pick(2);
C_word t10=C_pick(3);
C_word t9=C_pick(4);
C_word t8=C_pick(5);
C_word t7=C_pick(6);
C_word t6=C_pick(7);
C_word t5=C_pick(8);
C_word t4=C_pick(9);
C_word t3=C_pick(10);
C_word t2=C_pick(11);
C_word t1=C_pick(12);
C_word t0=C_pick(13);
C_adjust_stack(-14);
(k)(14,t0,t1,t2,t3,t4,t5,t6,t7,t8,t9,t10,t11,t12,t13);}

C_noret_decl(tr11)
static void C_fcall tr11(C_proc11 k) C_regparm C_noret;
C_regparm static void C_fcall tr11(C_proc11 k){
C_word t10=C_pick(0);
C_word t9=C_pick(1);
C_word t8=C_pick(2);
C_word t7=C_pick(3);
C_word t6=C_pick(4);
C_word t5=C_pick(5);
C_word t4=C_pick(6);
C_word t3=C_pick(7);
C_word t2=C_pick(8);
C_word t1=C_pick(9);
C_word t0=C_pick(10);
C_adjust_stack(-11);
(k)(11,t0,t1,t2,t3,t4,t5,t6,t7,t8,t9,t10);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr9)
static void C_fcall tr9(C_proc9 k) C_regparm C_noret;
C_regparm static void C_fcall tr9(C_proc9 k){
C_word t8=C_pick(0);
C_word t7=C_pick(1);
C_word t6=C_pick(2);
C_word t5=C_pick(3);
C_word t4=C_pick(4);
C_word t3=C_pick(5);
C_word t2=C_pick(6);
C_word t1=C_pick(7);
C_word t0=C_pick(8);
C_adjust_stack(-9);
(k)(9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}

C_noret_decl(tr7)
static void C_fcall tr7(C_proc7 k) C_regparm C_noret;
C_regparm static void C_fcall tr7(C_proc7 k){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
(k)(7,t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_optimizer_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_optimizer_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("optimizer_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(2546)){
C_save(t1);
C_rereclaim2(2546*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,316);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[2]=C_h_intern(&lf[2],34,"\010compilerscan-toplevel-assignments");
lf[3]=C_h_intern(&lf[3],8,"\003sysput!");
lf[4]=C_h_intern(&lf[4],9,"\003syserror");
lf[5]=C_h_intern(&lf[5],21,"\010compileralways-bound");
lf[6]=C_h_intern(&lf[6],12,"\003sysfor-each");
lf[7]=C_h_intern(&lf[7],18,"\010compilerdebugging");
lf[8]=C_h_intern(&lf[8],1,"o");
lf[9]=C_decode_literal(C_heaptop,"\376B\000\000\014safe globals");
lf[10]=C_h_intern(&lf[10],13,"\004corevariable");
lf[11]=C_h_intern(&lf[11],2,"if");
lf[12]=C_h_intern(&lf[12],3,"let");
lf[13]=C_h_intern(&lf[13],6,"append");
lf[14]=C_h_intern(&lf[14],6,"lambda");
lf[15]=C_h_intern(&lf[15],13,"\004corecallunit");
lf[16]=C_h_intern(&lf[16],9,"\004corecall");
lf[17]=C_h_intern(&lf[17],4,"set!");
lf[18]=C_h_intern(&lf[18],9,"\004corecond");
lf[19]=C_h_intern(&lf[19],11,"\004coreswitch");
lf[20]=C_h_intern(&lf[20],30,"call-with-current-continuation");
lf[21]=C_h_intern(&lf[21],1,"p");
lf[22]=C_decode_literal(C_heaptop,"\376B\000\000 scanning toplevel assignments...");
lf[23]=C_h_intern(&lf[23],24,"\010compilersimplifications");
lf[24]=C_h_intern(&lf[24],23,"\010compilersimplified-ops");
lf[25]=C_h_intern(&lf[25],41,"\010compilerperform-high-level-optimizations");
lf[26]=C_h_intern(&lf[26],12,"\010compilerget");
lf[27]=C_h_intern(&lf[27],5,"quote");
lf[28]=C_h_intern(&lf[28],10,"alist-cons");
lf[29]=C_h_intern(&lf[29],4,"caar");
lf[30]=C_h_intern(&lf[30],7,"\003sysmap");
lf[31]=C_h_intern(&lf[31],19,"\010compilermatch-node");
lf[32]=C_h_intern(&lf[32],3,"any");
lf[33]=C_h_intern(&lf[33],18,"\003syshash-table-ref");
lf[34]=C_h_intern(&lf[34],30,"\010compilerbroken-constant-nodes");
lf[35]=C_h_intern(&lf[35],11,"lset-adjoin");
lf[36]=C_h_intern(&lf[36],3,"eq\077");
lf[37]=C_h_intern(&lf[37],4,"node");
lf[38]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[39]=C_h_intern(&lf[39],14,"\010compilerqnode");
lf[40]=C_decode_literal(C_heaptop,"\376B\000\000\033folding constant expression");
lf[41]=C_h_intern(&lf[41],4,"eval");
lf[42]=C_h_intern(&lf[42],22,"with-exception-handler");
lf[43]=C_h_intern(&lf[43],5,"every");
lf[44]=C_h_intern(&lf[44],9,"foldable\077");
lf[45]=C_h_intern(&lf[45],7,"\003sysget");
lf[46]=C_h_intern(&lf[46],18,"\010compilerintrinsic");
lf[47]=C_h_intern(&lf[47],5,"value");
lf[48]=C_decode_literal(C_heaptop,"\376B\000\000\035substituted constant variable");
lf[49]=C_h_intern(&lf[49],16,"\010compilervarnode");
lf[50]=C_h_intern(&lf[50],11,"collapsable");
lf[51]=C_h_intern(&lf[51],10,"replacable");
lf[52]=C_h_intern(&lf[52],9,"replacing");
lf[53]=C_h_intern(&lf[53],12,"contractable");
lf[54]=C_h_intern(&lf[54],9,"removable");
lf[55]=C_h_intern(&lf[55],11,"\004corelambda");
lf[56]=C_h_intern(&lf[56],6,"unused");
lf[57]=C_h_intern(&lf[57],9,"partition");
lf[58]=C_h_intern(&lf[58],26,"\010compilerbuild-lambda-list");
lf[59]=C_decode_literal(C_heaptop,"\376B\000\000\047merged explicitly consed rest parameter");
lf[60]=C_h_intern(&lf[60],13,"explicit-rest");
lf[61]=C_decode_literal(C_heaptop,"\376B\000\000 removed unused formal parameters");
lf[62]=C_h_intern(&lf[62],30,"\010compilerdecompose-lambda-list");
lf[63]=C_decode_literal(C_heaptop,"\376B\000\000\047merged explicitly consed rest parameter");
lf[64]=C_h_intern(&lf[64],21,"has-unused-parameters");
lf[65]=C_h_intern(&lf[65],31,"\010compilerinline-lambda-bindings");
lf[66]=C_decode_literal(C_heaptop,"\376B\000\000\024contracted procedure");
lf[67]=C_h_intern(&lf[67],24,"\010compilercheck-signature");
lf[68]=C_h_intern(&lf[68],30,"\010compilerconstant-declarations");
lf[69]=C_h_intern(&lf[69],14,"\004coreundefined");
lf[70]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[71]=C_h_intern(&lf[71],1,"x");
lf[72]=C_decode_literal(C_heaptop,"\376B\000\0005removed call to constant procedure with unused result");
lf[73]=C_h_intern(&lf[73],37,"\010compilerexpression-has-side-effects\077");
lf[74]=C_h_intern(&lf[74],8,"assigned");
lf[75]=C_h_intern(&lf[75],10,"references");
lf[76]=C_h_intern(&lf[76],7,"unknown");
lf[77]=C_decode_literal(C_heaptop,"\376B\000\000\022inlining procedure");
lf[78]=C_decode_literal(C_heaptop,"\376B\000\000#procedure can be inlined (globally)");
lf[79]=C_decode_literal(C_heaptop,"\376B\000\000\030procedure can be inlined");
lf[80]=C_h_intern(&lf[80],1,"i");
lf[81]=C_h_intern(&lf[81],22,"\010compilerinline-global");
lf[82]=C_h_intern(&lf[82],14,"append-reverse");
lf[83]=C_h_intern(&lf[83],6,"gensym");
lf[84]=C_h_intern(&lf[84],1,"t");
lf[85]=C_decode_literal(C_heaptop,"\376B\000\000+removed unused parameter to known procedure");
lf[86]=C_h_intern(&lf[86],8,"split-at");
lf[87]=C_decode_literal(C_heaptop,"\376B\000\000\012C_a_i_list");
lf[88]=C_h_intern(&lf[88],20,"\004coreinline_allocate");
lf[89]=C_decode_literal(C_heaptop,"\376B\000\000\042consed rest parameter at call site");
lf[90]=C_h_intern(&lf[90],21,"\010compilerllist-length");
lf[91]=C_h_intern(&lf[91],23,"\010compilerinline-locally");
lf[92]=C_h_intern(&lf[92],3,"yes");
lf[93]=C_h_intern(&lf[93],2,"no");
lf[94]=C_h_intern(&lf[94],24,"\010compilerinline-max-size");
lf[95]=C_h_intern(&lf[95],15,"\010compilerinline");
lf[96]=C_h_intern(&lf[96],9,"inlinable");
lf[97]=C_h_intern(&lf[97],6,"simple");
lf[98]=C_h_intern(&lf[98],11,"local-value");
lf[99]=C_decode_literal(C_heaptop,"\376B\000\0006removed side-effect free assignment to unused variable");
lf[100]=C_h_intern(&lf[100],26,"\010compilervariable-visible\077");
lf[101]=C_h_intern(&lf[101],6,"global");
lf[102]=C_decode_literal(C_heaptop,"\376B\000\000\031removed conditional forms");
lf[103]=C_decode_literal(C_heaptop,"\376B\000\000\025removed binding forms");
lf[104]=C_decode_literal(C_heaptop,"\376B\000\000\022replaced variables");
lf[105]=C_h_intern(&lf[105],5,"print");
lf[106]=C_h_intern(&lf[106],7,"newline");
lf[107]=C_h_intern(&lf[107],6,"print*");
lf[108]=C_decode_literal(C_heaptop,"\376B\000\000\027  call simplifications:");
lf[109]=C_decode_literal(C_heaptop,"\376B\000\000\017simplifications");
lf[110]=C_decode_literal(C_heaptop,"\376B\000\000\022traversal phase...");
lf[111]=C_h_intern(&lf[111],34,"\010compilerperform-pre-optimization!");
lf[112]=C_decode_literal(C_heaptop,"\376B\000\000\023Removed `not\047 forms");
lf[113]=C_h_intern(&lf[113],24,"node-subexpressions-set!");
lf[114]=C_h_intern(&lf[114],7,"reverse");
lf[115]=C_h_intern(&lf[115],20,"node-parameters-set!");
lf[116]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[117]=C_h_intern(&lf[117],3,"not");
lf[118]=C_h_intern(&lf[118],10,"call-sites");
lf[119]=C_decode_literal(C_heaptop,"\376B\000\000\031pre-optimization phase...");
lf[120]=C_h_intern(&lf[120],24,"register-simplifications");
lf[121]=C_h_intern(&lf[121],19,"\003syshash-table-set!");
lf[122]=C_h_intern(&lf[122],38,"\010compilerreorganize-recursive-bindings");
lf[123]=C_decode_literal(C_heaptop,"\376B\000\000\026eliminated assignments");
lf[124]=C_h_intern(&lf[124],10,"fold-right");
lf[125]=C_h_intern(&lf[125],4,"fold");
lf[126]=C_h_intern(&lf[126],16,"topological-sort");
lf[127]=C_h_intern(&lf[127],6,"lset<=");
lf[128]=C_h_intern(&lf[128],10,"filter-map");
lf[129]=C_h_intern(&lf[129],6,"filter");
lf[130]=C_h_intern(&lf[130],10,"append-map");
lf[131]=C_h_intern(&lf[131],28,"\010compilerscan-used-variables");
lf[132]=C_h_intern(&lf[132],8,"for-each");
lf[133]=C_h_intern(&lf[133],3,"map");
lf[134]=C_h_intern(&lf[134],4,"cons");
lf[135]=C_h_intern(&lf[135],27,"\010compilersubstitution-table");
lf[136]=C_h_intern(&lf[136],16,"\010compilerrewrite");
lf[137]=C_h_intern(&lf[137],28,"\010compilersimplify-named-call");
lf[138]=C_h_intern(&lf[138],37,"\010compilerinline-substitutions-enabled");
lf[139]=C_h_intern(&lf[139],11,"\004coreinline");
lf[140]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[141]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[142]=C_h_intern(&lf[142],6,"unsafe");
lf[143]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[144]=C_h_intern(&lf[144],6,"vector");
lf[145]=C_h_intern(&lf[145],14,"rest-parameter");
lf[146]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[147]=C_h_intern(&lf[147],11,"number-type");
lf[148]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[149]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[150]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[151]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[152]=C_h_intern(&lf[152],6,"fixnum");
lf[153]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[154]=C_h_intern(&lf[154],21,"\010compilerfold-boolean");
lf[155]=C_h_intern(&lf[155],6,"flonum");
lf[156]=C_h_intern(&lf[156],7,"generic");
lf[157]=C_h_intern(&lf[157],5,"cons*");
lf[158]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[159]=C_h_intern(&lf[159],9,"\004coreproc");
lf[160]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[161]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[162]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[163]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[164]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[165]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[166]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[167]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[168]=C_h_intern(&lf[168],19,"\010compilerfold-inner");
lf[169]=C_h_intern(&lf[169],6,"remove");
lf[170]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[171]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[172]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[173]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[174]=C_h_intern(&lf[174],5,"fifth");
lf[175]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[176]=C_h_intern(&lf[176],13,"\010compilerbomb");
lf[177]=C_decode_literal(C_heaptop,"\376B\000\000\023bad type (optimize)");
lf[178]=C_h_intern(&lf[178],34,"\010compilertransform-direct-lambdas!");
lf[179]=C_h_intern(&lf[179],19,"\010compilercopy-node!");
lf[180]=C_h_intern(&lf[180],16,"\004coredirect_call");
lf[181]=C_h_intern(&lf[181],4,"quit");
lf[182]=C_decode_literal(C_heaptop,"\376B\000\000;known procedure called with wrong number of arguments: `~A\047");
lf[183]=C_h_intern(&lf[183],15,"lset-difference");
lf[184]=C_h_intern(&lf[184],15,"node-class-set!");
lf[185]=C_h_intern(&lf[185],12,"\004corerecurse");
lf[186]=C_decode_literal(C_heaptop,"\376B\000\000Gknown procedure called recursively with wrong number of arguments: `~A\047");
lf[187]=C_h_intern(&lf[187],4,"take");
lf[188]=C_decode_literal(C_heaptop,"\376B\000\000Gknown procedure called recursively with wrong number of arguments: `~A\047");
lf[189]=C_decode_literal(C_heaptop,"\376B\000\000\014missing kvar");
lf[190]=C_h_intern(&lf[190],11,"\004corereturn");
lf[191]=C_decode_literal(C_heaptop,"\376B\000\000\017bad call (leaf)");
lf[192]=C_h_intern(&lf[192],18,"\004coredirect_lambda");
lf[193]=C_h_intern(&lf[193],6,"cdaddr");
lf[194]=C_h_intern(&lf[194],6,"caaddr");
lf[195]=C_decode_literal(C_heaptop,"\376B\000\000\026invalid parameter list");
lf[196]=C_decode_literal(C_heaptop,"\376B\000\0006direct leaf routine with hoistable closures/allocation");
lf[197]=C_h_intern(&lf[197],6,"unzip1");
lf[198]=C_h_intern(&lf[198],16,"\003sysmake-promise");
lf[199]=C_decode_literal(C_heaptop,"\376B\000\000\036direct leaf routine/allocation");
lf[200]=C_h_intern(&lf[200],5,"boxed");
lf[201]=C_h_intern(&lf[201],15,"\004coreinline_ref");
lf[202]=C_h_intern(&lf[202],37,"\010compilerestimate-foreign-result-size");
lf[203]=C_h_intern(&lf[203],19,"\004coreinline_loc_ref");
lf[204]=C_h_intern(&lf[204],5,"lset=");
lf[205]=C_h_intern(&lf[205],6,"delete");
lf[206]=C_decode_literal(C_heaptop,"\376B\000\000(direct leaf routine optimization pass...");
lf[207]=C_h_intern(&lf[207],32,"\010compilerperform-lambda-lifting!");
lf[208]=C_h_intern(&lf[208],23,"\003syshash-table-for-each");
lf[209]=C_h_intern(&lf[209],1,"+");
lf[210]=C_h_intern(&lf[210],17,"delete-duplicates");
lf[211]=C_h_intern(&lf[211],14,"\004coreprimitive");
lf[212]=C_h_intern(&lf[212],7,"delete!");
lf[213]=C_h_intern(&lf[213],11,"concatenate");
lf[214]=C_h_intern(&lf[214],5,"count");
lf[215]=C_h_intern(&lf[215],22,"\010compilerhide-variable");
lf[216]=C_decode_literal(C_heaptop,"\376B\000\000\037moving liftables to toplevel...");
lf[217]=C_decode_literal(C_heaptop,"\376B\000\000\032removing local bindings...");
lf[218]=C_decode_literal(C_heaptop,"\376B\000\000\026changing call sites...");
lf[219]=C_h_intern(&lf[219],12,"pretty-print");
lf[220]=C_h_intern(&lf[220],1,"l");
lf[221]=C_decode_literal(C_heaptop,"\376B\000\000\026additional parameters:");
lf[222]=C_decode_literal(C_heaptop,"\376B\000\000\035gathering extra parameters...");
lf[223]=C_decode_literal(C_heaptop,"\376B\000\000\031liftable local procedures");
lf[224]=C_decode_literal(C_heaptop,"\376B\000\000Aeliminating liftables by access-lists and non-liftable callees...");
lf[225]=C_decode_literal(C_heaptop,"\376B\000\000\014accessibles:");
lf[226]=C_decode_literal(C_heaptop,"\376B\000\000\031computing access-lists...");
lf[227]=C_decode_literal(C_heaptop,"\376B\000\000\013call-graph:");
lf[228]=C_decode_literal(C_heaptop,"\376B\000\000\034eliminating non-liftables...");
lf[229]=C_decode_literal(C_heaptop,"\376B\000\000\026building call graph...");
lf[230]=C_decode_literal(C_heaptop,"\376B\000\000\026gathering liftables...");
lf[231]=C_h_intern(&lf[231],35,"\010compilercompiler-syntax-statistics");
lf[232]=C_h_intern(&lf[232],24,"\003syscompiler-syntax-hook");
lf[233]=C_h_intern(&lf[233],13,"alist-update!");
lf[234]=C_h_intern(&lf[234],9,"alist-ref");
lf[235]=C_h_intern(&lf[235],14,"\010compilerr-c-s");
lf[236]=C_h_intern(&lf[236],24,"\010compilercompiler-syntax");
lf[237]=C_h_intern(&lf[237],18,"\003syser-transformer");
lf[238]=C_h_intern(&lf[238],7,"display");
lf[239]=C_h_intern(&lf[239],5,"write");
lf[240]=C_h_intern(&lf[240],7,"fprintf");
lf[241]=C_h_intern(&lf[241],14,"number->string");
lf[242]=C_h_intern(&lf[242],10,"write-char");
lf[243]=C_h_intern(&lf[243],18,"open-output-string");
lf[244]=C_h_intern(&lf[244],17,"get-output-string");
lf[245]=C_h_intern(&lf[245],30,"\010compilercompile-format-string");
lf[246]=C_h_intern(&lf[246],17,"extended-bindings");
lf[247]=C_h_intern(&lf[247],25,"\010compilercompiler-warning");
lf[248]=C_h_intern(&lf[248],6,"syntax");
lf[249]=C_decode_literal(C_heaptop,"\376B\000\000\036(~a) in format string ~s~a, ~\077");
lf[250]=C_h_intern(&lf[250],7,"sprintf");
lf[251]=C_decode_literal(C_heaptop,"\376B\000\000\013 in line ~a");
lf[252]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[253]=C_h_intern(&lf[253],17,"\010compilerget-line");
lf[254]=C_decode_literal(C_heaptop,"\376B\000\000/too few arguments to formatted output procedure");
lf[255]=C_h_intern(&lf[255],20,"reverse-list->string");
lf[256]=C_h_intern(&lf[256],10,"\003sysappend");
lf[257]=C_decode_literal(C_heaptop,"\376B\000\0000too many arguments to formatted output procedure");
lf[258]=C_h_intern(&lf[258],16,"\003sysflush-output");
lf[259]=C_h_intern(&lf[259],9,"\003sysapply");
lf[260]=C_decode_literal(C_heaptop,"\376B\000\000$illegal format-string character `~c\047");
lf[261]=C_h_intern(&lf[261],3,"out");
lf[262]=C_h_intern(&lf[262],5,"cadar");
lf[263]=C_h_intern(&lf[263],7,"call/cc");
lf[264]=C_h_intern(&lf[264],6,"printf");
lf[265]=C_h_intern(&lf[265],19,"\003sysstandard-output");
lf[266]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006printf\376\003\000\000\002\376\001\000\000\010#%printf\376\377\016");
lf[267]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\007fprintf\376\003\000\000\002\376\001\000\000\011#%fprintf\376\377\016");
lf[268]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\007sprintf\376\003\000\000\002\376\001\000\000\011#%sprintf\376\377\016");
lf[269]=C_h_intern(&lf[269],6,"format");
lf[270]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\007sprintf\376\003\000\000\002\376\001\000\000\011#%sprintf\376\003\000\000\002\376\001\000\000\006format\376\003\000\000\002\376\001\000\000\010#%format\376\377\016");
lf[271]=C_h_intern(&lf[271],19,"\003sysprimitive-alias");
lf[272]=C_h_intern(&lf[272],4,"list");
lf[273]=C_h_intern(&lf[273],3,"tmp");
lf[274]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001o\376\003\000\000\002\376\001\000\000\003#%o\376\377\016");
lf[275]=C_h_intern(&lf[275],8,"\003sysslot");
lf[276]=C_h_intern(&lf[276],8,"\004coreapp");
lf[277]=C_h_intern(&lf[277],17,"standard-bindings");
lf[278]=C_h_intern(&lf[278],5,"pair\077");
lf[279]=C_h_intern(&lf[279],5,"begin");
lf[280]=C_h_intern(&lf[280],3,"lst");
lf[281]=C_h_intern(&lf[281],4,"loop");
lf[282]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010for-each\376\003\000\000\002\376\001\000\000\014\003sysfor-each\376\003\000\000\002\376\001\000\000\012#%for-each\376\377\016");
lf[283]=C_h_intern(&lf[283],11,"make-vector");
lf[284]=C_h_intern(&lf[284],3,"var");
lf[285]=C_h_intern(&lf[285],1,"y");
lf[286]=C_h_intern(&lf[286],2,"d2");
lf[287]=C_h_intern(&lf[287],1,"z");
lf[288]=C_h_intern(&lf[288],2,"d3");
lf[289]=C_h_intern(&lf[289],2,"d1");
lf[290]=C_h_intern(&lf[290],2,"op");
lf[291]=C_h_intern(&lf[291],5,"clist");
lf[292]=C_h_intern(&lf[292],34,"\010compilermembership-test-operators");
lf[293]=C_h_intern(&lf[293],32,"\010compilermembership-unfold-limit");
lf[294]=C_h_intern(&lf[294],4,"var1");
lf[295]=C_h_intern(&lf[295],4,"var0");
lf[296]=C_h_intern(&lf[296],6,"const1");
lf[297]=C_h_intern(&lf[297],4,"var2");
lf[298]=C_h_intern(&lf[298],6,"const2");
lf[299]=C_h_intern(&lf[299],4,"rest");
lf[300]=C_h_intern(&lf[300],5,"body2");
lf[301]=C_h_intern(&lf[301],5,"body1");
lf[302]=C_h_intern(&lf[302],27,"\010compilereq-inline-operator");
lf[303]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\001\000\000\000\002\376\377\016");
lf[304]=C_h_intern(&lf[304],19,"\010compilerimmediate\077");
lf[305]=C_h_intern(&lf[305],5,"const");
lf[306]=C_h_intern(&lf[306],1,"n");
lf[307]=C_h_intern(&lf[307],7,"clauses");
lf[308]=C_h_intern(&lf[308],4,"body");
lf[309]=C_h_intern(&lf[309],1,"d");
lf[310]=C_h_intern(&lf[310],4,"more");
lf[311]=C_h_intern(&lf[311],4,"args");
lf[312]=C_h_intern(&lf[312],1,"a");
lf[313]=C_h_intern(&lf[313],1,"b");
lf[314]=C_h_intern(&lf[314],1,"c");
lf[315]=C_h_intern(&lf[315],4,"cdar");
C_register_lf2(lf,316,create_ptable());
t2=C_mutate(&lf[0] /* (set! c145 ...) */,lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3676,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t3);}

/* k3674 */
static void C_ccall f_3676(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3676,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3679,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k3677 in k3674 */
static void C_ccall f_3679(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3679,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3682,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k3680 in k3677 in k3674 */
static void C_ccall f_3682(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3682,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3685,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_3685(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3685,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3688,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_3688(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3688,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3691,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_3691(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3691,2,t0,t1);}
t2=C_mutate((C_word*)lf[2]+1 /* (set! scan-toplevel-assignments ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3693,tmp=(C_word)a,a+=2,tmp));
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3928,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 103  make-vector */
((C_proc4)C_retrieve_proc(*((C_word*)lf[283]+1)))(4,*((C_word*)lf[283]+1),t3,C_fix(301),C_SCHEME_END_OF_LIST);}

/* k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_3928(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word ab[53],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3928,2,t0,t1);}
t2=C_mutate((C_word*)lf[23]+1 /* (set! simplifications ...) */,t1);
t3=C_set_block_item(lf[24] /* simplified-ops */,0,C_SCHEME_END_OF_LIST);
t4=C_mutate((C_word*)lf[25]+1 /* (set! perform-high-level-optimizations ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3931,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[111]+1 /* (set! perform-pre-optimization! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5413,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[120]+1 /* (set! register-simplifications ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5654,tmp=(C_word)a,a+=2,tmp));
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5661,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_a_i_cons(&a,2,lf[312],C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,lf[10],t9);
t11=(C_word)C_a_i_cons(&a,2,lf[313],lf[314]);
t12=(C_word)C_a_i_cons(&a,2,t10,t11);
t13=(C_word)C_a_i_cons(&a,2,lf[309],t12);
t14=(C_word)C_a_i_cons(&a,2,lf[16],t13);
t15=(C_word)C_a_i_cons(&a,2,lf[309],C_SCHEME_END_OF_LIST);
t16=(C_word)C_a_i_cons(&a,2,lf[314],t15);
t17=(C_word)C_a_i_cons(&a,2,lf[313],t16);
t18=(C_word)C_a_i_cons(&a,2,lf[312],t17);
t19=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_13049,tmp=(C_word)a,a+=2,tmp);
t20=(C_word)C_a_i_cons(&a,2,t19,C_SCHEME_END_OF_LIST);
t21=(C_word)C_a_i_cons(&a,2,t18,t20);
t22=(C_word)C_a_i_cons(&a,2,t14,t21);
/* optimizer.scm: 467  register-simplifications */
((C_proc4)C_retrieve_symbol_proc(lf[120]))(4,*((C_word*)lf[120]+1),t7,lf[16],t22);}

/* a13048 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_13049(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(c!=7) C_bad_argc_2(c,7,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr7,(void*)f_13049,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_13057,a[2]=t1,a[3]=t5,a[4]=t4,a[5]=t6,a[6]=t2,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 473  ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[33]))(4,*((C_word*)lf[33]+1),t7,C_retrieve(lf[135]),t3);}

/* k13055 in a13048 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_13057(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13057,2,t0,t1);}
t2=(C_truep(t1)?t1:C_SCHEME_END_OF_LIST);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_13062,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t4,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp));
t6=((C_word*)t4)[1];
f_13062(t6,((C_word*)t0)[2],t2);}

/* loop in k13055 in a13048 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_fcall f_13062(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_13062,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13072,a[2]=((C_word*)t0)[6],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_13107,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=t3,tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 475  caar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[29]+1)))(3,*((C_word*)lf[29]+1),t4,t2);}}

/* k13105 in loop in k13055 in a13048 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_13107(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13107,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_13111,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 475  cdar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[315]+1)))(3,*((C_word*)lf[315]+1),t2,((C_word*)t0)[2]);}

/* k13109 in k13105 in loop in k13055 in a13048 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_13111(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 475  simplify-named-call */
((C_proc9)C_retrieve_symbol_proc(lf[137]))(9,*((C_word*)lf[137]+1),((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k13070 in loop in k13055 in a13048 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_13072(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13072,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_assq(((C_word*)t0)[5],C_retrieve(lf[24]));
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_13081,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t2)){
t4=(C_word)C_i_cdr(t2);
t5=(C_word)C_fixnum_increase(t4);
t6=t3;
f_13081(t6,(C_word)C_i_set_cdr(t2,t5));}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13096,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 480  alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[28]))(5,*((C_word*)lf[28]+1),t4,((C_word*)t0)[5],C_fix(1),C_retrieve(lf[24]));}}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* optimizer.scm: 482  loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_13062(t3,((C_word*)t0)[4],t2);}}

/* k13094 in k13070 in loop in k13055 in a13048 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_13096(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[24]+1 /* (set! simplified-ops ...) */,t1);
t3=((C_word*)t0)[2];
f_13081(t3,t2);}

/* k13079 in k13070 in loop in k13055 in a13048 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_fcall f_13081(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_5661(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word t98;
C_word t99;
C_word t100;
C_word t101;
C_word t102;
C_word t103;
C_word t104;
C_word t105;
C_word t106;
C_word t107;
C_word t108;
C_word t109;
C_word t110;
C_word t111;
C_word t112;
C_word t113;
C_word t114;
C_word t115;
C_word t116;
C_word t117;
C_word t118;
C_word t119;
C_word t120;
C_word t121;
C_word t122;
C_word t123;
C_word t124;
C_word t125;
C_word t126;
C_word t127;
C_word t128;
C_word t129;
C_word t130;
C_word t131;
C_word t132;
C_word t133;
C_word t134;
C_word t135;
C_word t136;
C_word t137;
C_word t138;
C_word t139;
C_word t140;
C_word t141;
C_word t142;
C_word t143;
C_word t144;
C_word t145;
C_word t146;
C_word t147;
C_word t148;
C_word ab[434],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5661,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5664,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_a_i_cons(&a,2,lf[294],C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[290],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[295],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,lf[10],t6);
t8=(C_word)C_a_i_cons(&a,2,lf[296],C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,lf[27],t9);
t11=(C_word)C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,t7,t11);
t13=(C_word)C_a_i_cons(&a,2,t4,t12);
t14=(C_word)C_a_i_cons(&a,2,lf[139],t13);
t15=(C_word)C_a_i_cons(&a,2,lf[294],C_SCHEME_END_OF_LIST);
t16=(C_word)C_a_i_cons(&a,2,t15,C_SCHEME_END_OF_LIST);
t17=(C_word)C_a_i_cons(&a,2,lf[10],t16);
t18=(C_word)C_a_i_cons(&a,2,lf[297],C_SCHEME_END_OF_LIST);
t19=(C_word)C_a_i_cons(&a,2,lf[290],C_SCHEME_END_OF_LIST);
t20=(C_word)C_a_i_cons(&a,2,lf[295],C_SCHEME_END_OF_LIST);
t21=(C_word)C_a_i_cons(&a,2,t20,C_SCHEME_END_OF_LIST);
t22=(C_word)C_a_i_cons(&a,2,lf[10],t21);
t23=(C_word)C_a_i_cons(&a,2,lf[298],C_SCHEME_END_OF_LIST);
t24=(C_word)C_a_i_cons(&a,2,t23,C_SCHEME_END_OF_LIST);
t25=(C_word)C_a_i_cons(&a,2,lf[27],t24);
t26=(C_word)C_a_i_cons(&a,2,t25,C_SCHEME_END_OF_LIST);
t27=(C_word)C_a_i_cons(&a,2,t22,t26);
t28=(C_word)C_a_i_cons(&a,2,t19,t27);
t29=(C_word)C_a_i_cons(&a,2,lf[139],t28);
t30=(C_word)C_a_i_cons(&a,2,lf[297],C_SCHEME_END_OF_LIST);
t31=(C_word)C_a_i_cons(&a,2,t30,C_SCHEME_END_OF_LIST);
t32=(C_word)C_a_i_cons(&a,2,lf[10],t31);
t33=(C_word)C_a_i_cons(&a,2,lf[299],C_SCHEME_END_OF_LIST);
t34=(C_word)C_a_i_cons(&a,2,lf[300],t33);
t35=(C_word)C_a_i_cons(&a,2,t32,t34);
t36=(C_word)C_a_i_cons(&a,2,lf[286],t35);
t37=(C_word)C_a_i_cons(&a,2,lf[11],t36);
t38=(C_word)C_a_i_cons(&a,2,t37,C_SCHEME_END_OF_LIST);
t39=(C_word)C_a_i_cons(&a,2,t29,t38);
t40=(C_word)C_a_i_cons(&a,2,t18,t39);
t41=(C_word)C_a_i_cons(&a,2,lf[12],t40);
t42=(C_word)C_a_i_cons(&a,2,t41,C_SCHEME_END_OF_LIST);
t43=(C_word)C_a_i_cons(&a,2,lf[301],t42);
t44=(C_word)C_a_i_cons(&a,2,t17,t43);
t45=(C_word)C_a_i_cons(&a,2,lf[289],t44);
t46=(C_word)C_a_i_cons(&a,2,lf[11],t45);
t47=(C_word)C_a_i_cons(&a,2,t46,C_SCHEME_END_OF_LIST);
t48=(C_word)C_a_i_cons(&a,2,t14,t47);
t49=(C_word)C_a_i_cons(&a,2,t3,t48);
t50=(C_word)C_a_i_cons(&a,2,lf[12],t49);
t51=(C_word)C_a_i_cons(&a,2,lf[299],C_SCHEME_END_OF_LIST);
t52=(C_word)C_a_i_cons(&a,2,lf[286],t51);
t53=(C_word)C_a_i_cons(&a,2,lf[289],t52);
t54=(C_word)C_a_i_cons(&a,2,lf[300],t53);
t55=(C_word)C_a_i_cons(&a,2,lf[301],t54);
t56=(C_word)C_a_i_cons(&a,2,lf[298],t55);
t57=(C_word)C_a_i_cons(&a,2,lf[296],t56);
t58=(C_word)C_a_i_cons(&a,2,lf[290],t57);
t59=(C_word)C_a_i_cons(&a,2,lf[297],t58);
t60=(C_word)C_a_i_cons(&a,2,lf[294],t59);
t61=(C_word)C_a_i_cons(&a,2,lf[295],t60);
t62=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12734,tmp=(C_word)a,a+=2,tmp);
t63=(C_word)C_a_i_cons(&a,2,t62,C_SCHEME_END_OF_LIST);
t64=(C_word)C_a_i_cons(&a,2,t61,t63);
t65=(C_word)C_a_i_cons(&a,2,t50,t64);
t66=(C_word)C_a_i_cons(&a,2,lf[284],C_SCHEME_END_OF_LIST);
t67=(C_word)C_a_i_cons(&a,2,lf[290],C_SCHEME_END_OF_LIST);
t68=(C_word)C_a_i_cons(&a,2,lf[295],C_SCHEME_END_OF_LIST);
t69=(C_word)C_a_i_cons(&a,2,t68,C_SCHEME_END_OF_LIST);
t70=(C_word)C_a_i_cons(&a,2,lf[10],t69);
t71=(C_word)C_a_i_cons(&a,2,lf[305],C_SCHEME_END_OF_LIST);
t72=(C_word)C_a_i_cons(&a,2,t71,C_SCHEME_END_OF_LIST);
t73=(C_word)C_a_i_cons(&a,2,lf[27],t72);
t74=(C_word)C_a_i_cons(&a,2,t73,C_SCHEME_END_OF_LIST);
t75=(C_word)C_a_i_cons(&a,2,t70,t74);
t76=(C_word)C_a_i_cons(&a,2,t67,t75);
t77=(C_word)C_a_i_cons(&a,2,lf[139],t76);
t78=(C_word)C_a_i_cons(&a,2,lf[284],C_SCHEME_END_OF_LIST);
t79=(C_word)C_a_i_cons(&a,2,t78,C_SCHEME_END_OF_LIST);
t80=(C_word)C_a_i_cons(&a,2,lf[10],t79);
t81=(C_word)C_a_i_cons(&a,2,lf[306],C_SCHEME_END_OF_LIST);
t82=(C_word)C_a_i_cons(&a,2,lf[295],C_SCHEME_END_OF_LIST);
t83=(C_word)C_a_i_cons(&a,2,t82,C_SCHEME_END_OF_LIST);
t84=(C_word)C_a_i_cons(&a,2,lf[10],t83);
t85=(C_word)C_a_i_cons(&a,2,t84,lf[307]);
t86=(C_word)C_a_i_cons(&a,2,t81,t85);
t87=(C_word)C_a_i_cons(&a,2,lf[19],t86);
t88=(C_word)C_a_i_cons(&a,2,t87,C_SCHEME_END_OF_LIST);
t89=(C_word)C_a_i_cons(&a,2,lf[308],t88);
t90=(C_word)C_a_i_cons(&a,2,t80,t89);
t91=(C_word)C_a_i_cons(&a,2,lf[309],t90);
t92=(C_word)C_a_i_cons(&a,2,lf[11],t91);
t93=(C_word)C_a_i_cons(&a,2,t92,C_SCHEME_END_OF_LIST);
t94=(C_word)C_a_i_cons(&a,2,t77,t93);
t95=(C_word)C_a_i_cons(&a,2,t66,t94);
t96=(C_word)C_a_i_cons(&a,2,lf[12],t95);
t97=(C_word)C_a_i_cons(&a,2,lf[307],C_SCHEME_END_OF_LIST);
t98=(C_word)C_a_i_cons(&a,2,lf[306],t97);
t99=(C_word)C_a_i_cons(&a,2,lf[308],t98);
t100=(C_word)C_a_i_cons(&a,2,lf[309],t99);
t101=(C_word)C_a_i_cons(&a,2,lf[305],t100);
t102=(C_word)C_a_i_cons(&a,2,lf[295],t101);
t103=(C_word)C_a_i_cons(&a,2,lf[290],t102);
t104=(C_word)C_a_i_cons(&a,2,lf[284],t103);
t105=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12520,tmp=(C_word)a,a+=2,tmp);
t106=(C_word)C_a_i_cons(&a,2,t105,C_SCHEME_END_OF_LIST);
t107=(C_word)C_a_i_cons(&a,2,t104,t106);
t108=(C_word)C_a_i_cons(&a,2,t96,t107);
t109=(C_word)C_a_i_cons(&a,2,lf[294],C_SCHEME_END_OF_LIST);
t110=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);
t111=(C_word)C_a_i_cons(&a,2,lf[69],t110);
t112=(C_word)C_a_i_cons(&a,2,lf[310],C_SCHEME_END_OF_LIST);
t113=(C_word)C_a_i_cons(&a,2,t111,t112);
t114=(C_word)C_a_i_cons(&a,2,t109,t113);
t115=(C_word)C_a_i_cons(&a,2,lf[12],t114);
t116=(C_word)C_a_i_cons(&a,2,lf[310],C_SCHEME_END_OF_LIST);
t117=(C_word)C_a_i_cons(&a,2,lf[294],t116);
t118=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12224,tmp=(C_word)a,a+=2,tmp);
t119=(C_word)C_a_i_cons(&a,2,t118,C_SCHEME_END_OF_LIST);
t120=(C_word)C_a_i_cons(&a,2,t117,t119);
t121=(C_word)C_a_i_cons(&a,2,t115,t120);
t122=(C_word)C_a_i_cons(&a,2,lf[284],C_SCHEME_END_OF_LIST);
t123=(C_word)C_a_i_cons(&a,2,lf[290],C_SCHEME_END_OF_LIST);
t124=(C_word)C_a_i_cons(&a,2,t123,lf[311]);
t125=(C_word)C_a_i_cons(&a,2,lf[139],t124);
t126=(C_word)C_a_i_cons(&a,2,lf[284],C_SCHEME_END_OF_LIST);
t127=(C_word)C_a_i_cons(&a,2,t126,C_SCHEME_END_OF_LIST);
t128=(C_word)C_a_i_cons(&a,2,lf[10],t127);
t129=(C_word)C_a_i_cons(&a,2,lf[285],C_SCHEME_END_OF_LIST);
t130=(C_word)C_a_i_cons(&a,2,lf[71],t129);
t131=(C_word)C_a_i_cons(&a,2,t128,t130);
t132=(C_word)C_a_i_cons(&a,2,lf[309],t131);
t133=(C_word)C_a_i_cons(&a,2,lf[11],t132);
t134=(C_word)C_a_i_cons(&a,2,t133,C_SCHEME_END_OF_LIST);
t135=(C_word)C_a_i_cons(&a,2,t125,t134);
t136=(C_word)C_a_i_cons(&a,2,t122,t135);
t137=(C_word)C_a_i_cons(&a,2,lf[12],t136);
t138=(C_word)C_a_i_cons(&a,2,lf[285],C_SCHEME_END_OF_LIST);
t139=(C_word)C_a_i_cons(&a,2,lf[71],t138);
t140=(C_word)C_a_i_cons(&a,2,lf[309],t139);
t141=(C_word)C_a_i_cons(&a,2,lf[311],t140);
t142=(C_word)C_a_i_cons(&a,2,lf[290],t141);
t143=(C_word)C_a_i_cons(&a,2,lf[284],t142);
t144=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12088,tmp=(C_word)a,a+=2,tmp);
t145=(C_word)C_a_i_cons(&a,2,t144,C_SCHEME_END_OF_LIST);
t146=(C_word)C_a_i_cons(&a,2,t143,t145);
t147=(C_word)C_a_i_cons(&a,2,t137,t146);
/* optimizer.scm: 485  register-simplifications */
((C_proc7)C_retrieve_symbol_proc(lf[120]))(7,*((C_word*)lf[120]+1),t2,lf[12],t65,t108,t121,t147);}

/* a12087 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_12088(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
if(c!=9) C_bad_argc_2(c,9,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr9,(void*)f_12088,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
if(C_truep((C_word)C_i_equalp(t4,C_retrieve(lf[302])))){
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
else{
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_12122,a[2]=t1,a[3]=t8,a[4]=t7,a[5]=t5,a[6]=t4,a[7]=t6,tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 620  get */
((C_proc5)C_retrieve_symbol_proc(lf[26]))(5,*((C_word*)lf[26]+1),t9,t2,t3,lf[75]);}}

/* k12120 in a12087 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_12122(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12122,2,t0,t1);}
t2=(C_word)C_i_length(t1);
t3=(C_word)C_eqp(C_fix(1),t2);
if(C_truep(t3)){
t4=((C_word*)t0)[7];
t5=(C_word)C_a_i_list(&a,1,((C_word*)t0)[6]);
t6=((C_word*)t0)[5];
t7=(C_word)C_a_i_record(&a,4,lf[37],lf[139],t5,t6);
t8=(C_word)C_a_i_list(&a,3,t7,((C_word*)t0)[4],((C_word*)t0)[3]);
t9=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_a_i_record(&a,4,lf[37],lf[11],t4,t8));}
else{
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* a12223 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_12224(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_12224,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_a_i_list(&a,1,t3);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12234,a[2]=t2,a[3]=t7,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_12234(t9,t1,t5,t4);}

/* loop1 in a12223 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_fcall f_12234(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word *a;
loop:
a=C_alloc(7);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_12234,NULL,4,t0,t1,t2,t3);}
t4=t3;
t5=(C_word)C_slot(t4,C_fix(1));
t6=t3;
t7=(C_word)C_slot(t6,C_fix(2));
t8=t3;
t9=(C_word)C_slot(t8,C_fix(3));
t10=(C_word)C_eqp(t5,lf[12]);
if(C_truep(t10)){
t11=(C_word)C_i_cdr(t7);
if(C_truep((C_word)C_i_nullp(t11))){
t12=(C_word)C_i_car(t9);
t13=(C_word)C_slot(t12,C_fix(2));
t14=(C_word)C_slot(t12,C_fix(3));
t15=(C_word)C_slot(t12,C_fix(1));
t16=(C_word)C_eqp(t15,lf[69]);
if(C_truep(t16)){
t17=(C_word)C_i_car(t7);
t18=(C_word)C_a_i_cons(&a,2,t17,t2);
t19=(C_word)C_i_cadr(t9);
/* optimizer.scm: 566  loop1 */
t23=t1;
t24=t18;
t25=t19;
t1=t23;
t2=t24;
t3=t25;
goto loop;}
else{
t17=(C_word)C_eqp(t15,lf[17]);
if(C_truep(t17)){
t18=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_12298,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t9,a[5]=t14,a[6]=t13,tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 568  reverse */
((C_proc3)C_retrieve_proc(*((C_word*)lf[114]+1)))(3,*((C_word*)lf[114]+1),t18,t2);}
else{
t18=t1;
((C_proc2)(void*)(*((C_word*)t18+1)))(2,t18,C_SCHEME_FALSE);}}}
else{
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_FALSE);}}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_FALSE);}}

/* k12296 in loop1 in a12223 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_12298(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12298,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(C_word)C_i_car(t1);
t4=(C_word)C_eqp(t2,t3);
if(C_truep(t4)){
t5=(C_word)C_i_car(((C_word*)t0)[5]);
t6=(C_word)C_a_i_list(&a,1,t5);
t7=(C_word)C_i_cdr(t1);
t8=(C_word)C_i_cadr(((C_word*)t0)[4]);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12327,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t10,tmp=(C_word)a,a+=5,tmp));
t12=((C_word*)t10)[1];
f_12327(t12,((C_word*)t0)[2],t6,t7,t8);}
else{
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* loop2 in k12296 in loop1 in a12223 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_fcall f_12327(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12327,NULL,5,t0,t1,t2,t3,t4);}
t5=t4;
t6=(C_word)C_slot(t5,C_fix(1));
t7=t4;
t8=(C_word)C_slot(t7,C_fix(2));
t9=t4;
t10=(C_word)C_slot(t9,C_fix(3));
t11=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_12343,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=t3,a[7]=t2,a[8]=t10,tmp=(C_word)a,a+=9,tmp);
t12=(C_word)C_eqp(t6,lf[12]);
if(C_truep(t12)){
t13=(C_word)C_i_cdr(t8);
if(C_truep((C_word)C_i_nullp(t13))){
t14=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12450,a[2]=t10,a[3]=t3,a[4]=t11,tmp=(C_word)a,a+=5,tmp);
t15=(C_word)C_i_car(t8);
/* optimizer.scm: 579  get */
((C_proc5)C_retrieve_symbol_proc(lf[26]))(5,*((C_word*)lf[26]+1),t14,((C_word*)t0)[2],t15,lf[75]);}
else{
t14=t11;
f_12343(t14,C_SCHEME_FALSE);}}
else{
t13=t11;
f_12343(t13,C_SCHEME_FALSE);}}

/* k12448 in loop2 in k12296 in loop1 in a12223 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_12450(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_12343(t2,C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
t2=(C_word)C_i_car(((C_word*)t0)[2]);
t3=(C_word)C_slot(t2,C_fix(1));
t4=(C_word)C_eqp(lf[17],t3);
if(C_truep(t4)){
t5=(C_word)C_i_car(((C_word*)t0)[3]);
t6=(C_word)C_i_car(((C_word*)t0)[2]);
t7=(C_word)C_slot(t6,C_fix(2));
t8=(C_word)C_i_car(t7);
t9=((C_word*)t0)[4];
f_12343(t9,(C_word)C_eqp(t5,t8));}
else{
t5=((C_word*)t0)[4];
f_12343(t5,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[4];
f_12343(t2,C_SCHEME_FALSE);}}}

/* k12341 in loop2 in k12296 in loop1 in a12223 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_fcall f_12343(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12343,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[8]);
t3=(C_word)C_slot(t2,C_fix(3));
t4=(C_word)C_i_car(t3);
t5=(C_word)C_a_i_cons(&a,2,t4,((C_word*)t0)[7]);
t6=(C_word)C_i_cdr(((C_word*)t0)[6]);
t7=(C_word)C_i_cadr(((C_word*)t0)[8]);
/* optimizer.scm: 583  loop2 */
t8=((C_word*)((C_word*)t0)[5])[1];
f_12327(t8,((C_word*)t0)[4],t5,t6,t7);}
else{
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[6]))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12380,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12390,tmp=(C_word)a,a+=2,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[4],t2,t3);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}}

/* a12389 in k12341 in loop2 in k12296 in loop1 in a12223 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_12390(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_12390,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?t2:C_SCHEME_FALSE));}

/* a12379 in k12341 in loop2 in k12296 in loop1 in a12223 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_12380(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12380,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12388,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 588  reverse */
((C_proc3)C_retrieve_proc(*((C_word*)lf[114]+1)))(3,*((C_word*)lf[114]+1),t2,((C_word*)t0)[2]);}

/* k12386 in a12379 in k12341 in loop2 in k12296 in loop1 in a12223 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_12388(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 588  reorganize-recursive-bindings */
((C_proc5)C_retrieve_symbol_proc(lf[122]))(5,*((C_word*)lf[122]+1),((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* a12519 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_12520(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9,C_word t10){
C_word tmp;
C_word t11;
C_word t12;
C_word ab[10],*a=ab;
if(c!=11) C_bad_argc_2(c,11,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr11,(void*)f_12520,11,t0,t1,t2,t3,t4,t5,t6,t7,t8,t9,t10);}
if(C_truep((C_word)C_i_equalp(t4,C_retrieve(lf[302])))){
t11=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_12533,a[2]=t3,a[3]=t2,a[4]=t5,a[5]=t6,a[6]=t10,a[7]=t8,a[8]=t1,a[9]=t9,tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm: 532  immediate? */
((C_proc3)C_retrieve_symbol_proc(lf[304]))(3,*((C_word*)lf[304]+1),t11,t6);}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_FALSE);}}

/* k12531 in a12519 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_12533(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12533,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_12568,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 533  get */
((C_proc5)C_retrieve_symbol_proc(lf[26]))(5,*((C_word*)lf[26]+1),t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[75]);}
else{
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k12566 in k12531 in a12519 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_12568(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12568,2,t0,t1);}
t2=(C_word)C_i_length(t1);
t3=(C_word)C_eqp(C_fix(1),t2);
if(C_truep(t3)){
t4=(C_word)C_fixnum_increase(((C_word*)t0)[7]);
t5=(C_word)C_a_i_list(&a,1,t4);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12545,a[2]=t5,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_12552,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t6,tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 537  varnode */
((C_proc3)C_retrieve_symbol_proc(lf[49]))(3,*((C_word*)lf[49]+1),t7,((C_word*)t0)[2]);}
else{
t4=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k12550 in k12566 in k12531 in a12519 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_12552(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12552,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_12556,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 538  qnode */
((C_proc3)C_retrieve_symbol_proc(lf[39]))(3,*((C_word*)lf[39]+1),t2,((C_word*)t0)[2]);}

/* k12554 in k12550 in k12566 in k12531 in a12519 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_12556(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 537  cons* */
((C_proc6)C_retrieve_symbol_proc(lf[157]))(6,*((C_word*)lf[157]+1),((C_word*)t0)[5],((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k12543 in k12566 in k12531 in a12519 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_12545(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12545,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[37],lf[19],((C_word*)t0)[2],t1));}

/* a12733 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_12734(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9,C_word t10,C_word t11,C_word t12,C_word t13){
C_word tmp;
C_word t14;
C_word t15;
C_word ab[12],*a=ab;
if(c!=14) C_bad_argc_2(c,14,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr14,(void*)f_12734,14,t0,t1,t2,t3,t4,t5,t6,t7,t8,t9,t10,t11,t12,t13);}
if(C_truep((C_word)C_i_equalp(t6,C_retrieve(lf[302])))){
t14=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_12747,a[2]=t4,a[3]=t5,a[4]=t2,a[5]=t3,a[6]=t7,a[7]=t8,a[8]=t1,a[9]=t13,a[10]=t10,a[11]=t9,tmp=(C_word)a,a+=12,tmp);
/* optimizer.scm: 505  immediate? */
((C_proc3)C_retrieve_symbol_proc(lf[304]))(3,*((C_word*)lf[304]+1),t14,t7);}
else{
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,C_SCHEME_FALSE);}}

/* k12745 in a12733 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_12747(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12747,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_12753,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
/* optimizer.scm: 506  immediate? */
((C_proc3)C_retrieve_symbol_proc(lf[304]))(3,*((C_word*)lf[304]+1),t2,((C_word*)t0)[7]);}
else{
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k12751 in k12745 in a12733 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_12753(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12753,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_12799,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
/* optimizer.scm: 507  get */
((C_proc5)C_retrieve_symbol_proc(lf[26]))(5,*((C_word*)lf[26]+1),t2,((C_word*)t0)[4],((C_word*)t0)[2],lf[75]);}
else{
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k12797 in k12751 in k12745 in a12733 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_12799(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12799,2,t0,t1);}
t2=(C_word)C_i_length(t1);
t3=(C_word)C_eqp(C_fix(1),t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_12791,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 508  get */
((C_proc5)C_retrieve_symbol_proc(lf[26]))(5,*((C_word*)lf[26]+1),t4,((C_word*)t0)[3],((C_word*)t0)[2],lf[75]);}
else{
t4=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k12789 in k12797 in k12751 in k12745 in a12733 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_12791(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12791,2,t0,t1);}
t2=(C_word)C_i_length(t1);
t3=(C_word)C_eqp(C_fix(1),t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_12775,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 512  varnode */
((C_proc3)C_retrieve_symbol_proc(lf[49]))(3,*((C_word*)lf[49]+1),t4,((C_word*)t0)[2]);}
else{
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k12773 in k12789 in k12797 in k12751 in k12745 in a12733 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_12775(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12775,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_12779,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 513  qnode */
((C_proc3)C_retrieve_symbol_proc(lf[39]))(3,*((C_word*)lf[39]+1),t2,((C_word*)t0)[2]);}

/* k12777 in k12773 in k12789 in k12797 in k12751 in k12745 in a12733 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_12779(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12779,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_12783,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 515  qnode */
((C_proc3)C_retrieve_symbol_proc(lf[39]))(3,*((C_word*)lf[39]+1),t2,((C_word*)t0)[2]);}

/* k12781 in k12777 in k12773 in k12789 in k12797 in k12751 in k12745 in a12733 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_12783(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12783,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,6,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[37],lf[19],lf[303],t2));}

/* k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_5664(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word ab[160],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5664,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5667,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_a_i_cons(&a,2,lf[284],C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[10],t4);
t6=(C_word)C_a_i_cons(&a,2,lf[285],C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,t5,t6);
t8=(C_word)C_a_i_cons(&a,2,lf[286],t7);
t9=(C_word)C_a_i_cons(&a,2,lf[16],t8);
t10=(C_word)C_a_i_cons(&a,2,lf[284],C_SCHEME_END_OF_LIST);
t11=(C_word)C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,lf[10],t11);
t13=(C_word)C_a_i_cons(&a,2,lf[287],C_SCHEME_END_OF_LIST);
t14=(C_word)C_a_i_cons(&a,2,t12,t13);
t15=(C_word)C_a_i_cons(&a,2,lf[288],t14);
t16=(C_word)C_a_i_cons(&a,2,lf[16],t15);
t17=(C_word)C_a_i_cons(&a,2,t16,C_SCHEME_END_OF_LIST);
t18=(C_word)C_a_i_cons(&a,2,t9,t17);
t19=(C_word)C_a_i_cons(&a,2,lf[71],t18);
t20=(C_word)C_a_i_cons(&a,2,lf[289],t19);
t21=(C_word)C_a_i_cons(&a,2,lf[11],t20);
t22=(C_word)C_a_i_cons(&a,2,lf[284],C_SCHEME_END_OF_LIST);
t23=(C_word)C_a_i_cons(&a,2,lf[287],t22);
t24=(C_word)C_a_i_cons(&a,2,lf[285],t23);
t25=(C_word)C_a_i_cons(&a,2,lf[71],t24);
t26=(C_word)C_a_i_cons(&a,2,lf[288],t25);
t27=(C_word)C_a_i_cons(&a,2,lf[286],t26);
t28=(C_word)C_a_i_cons(&a,2,lf[289],t27);
t29=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11937,tmp=(C_word)a,a+=2,tmp);
t30=(C_word)C_a_i_cons(&a,2,t29,C_SCHEME_END_OF_LIST);
t31=(C_word)C_a_i_cons(&a,2,t28,t30);
t32=(C_word)C_a_i_cons(&a,2,t21,t31);
t33=(C_word)C_a_i_cons(&a,2,lf[290],C_SCHEME_END_OF_LIST);
t34=(C_word)C_a_i_cons(&a,2,lf[291],C_SCHEME_END_OF_LIST);
t35=(C_word)C_a_i_cons(&a,2,t34,C_SCHEME_END_OF_LIST);
t36=(C_word)C_a_i_cons(&a,2,lf[27],t35);
t37=(C_word)C_a_i_cons(&a,2,t36,C_SCHEME_END_OF_LIST);
t38=(C_word)C_a_i_cons(&a,2,lf[71],t37);
t39=(C_word)C_a_i_cons(&a,2,t33,t38);
t40=(C_word)C_a_i_cons(&a,2,lf[139],t39);
t41=(C_word)C_a_i_cons(&a,2,lf[287],C_SCHEME_END_OF_LIST);
t42=(C_word)C_a_i_cons(&a,2,lf[285],t41);
t43=(C_word)C_a_i_cons(&a,2,t40,t42);
t44=(C_word)C_a_i_cons(&a,2,lf[289],t43);
t45=(C_word)C_a_i_cons(&a,2,lf[11],t44);
t46=(C_word)C_a_i_cons(&a,2,lf[287],C_SCHEME_END_OF_LIST);
t47=(C_word)C_a_i_cons(&a,2,lf[285],t46);
t48=(C_word)C_a_i_cons(&a,2,lf[291],t47);
t49=(C_word)C_a_i_cons(&a,2,lf[71],t48);
t50=(C_word)C_a_i_cons(&a,2,lf[290],t49);
t51=(C_word)C_a_i_cons(&a,2,lf[289],t50);
t52=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11766,tmp=(C_word)a,a+=2,tmp);
t53=(C_word)C_a_i_cons(&a,2,t52,C_SCHEME_END_OF_LIST);
t54=(C_word)C_a_i_cons(&a,2,t51,t53);
t55=(C_word)C_a_i_cons(&a,2,t45,t54);
/* optimizer.scm: 627  register-simplifications */
((C_proc5)C_retrieve_symbol_proc(lf[120]))(5,*((C_word*)lf[120]+1),t2,lf[11],t32,t55);}

/* a11765 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_11766(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[9],*a=ab;
if(c!=9) C_bad_argc_2(c,9,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr9,(void*)f_11766,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
t9=(C_word)C_i_assoc(t4,C_retrieve(lf[292]));
if(C_truep(t9)){
if(C_truep((C_word)C_i_listp(t6))){
t10=(C_word)C_i_length(t6);
t11=C_retrieve(lf[293]);
if(C_truep((C_word)C_fixnum_lessp(t10,t11))){
t12=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_11788,a[2]=t6,a[3]=t1,a[4]=t5,a[5]=t8,a[6]=t7,a[7]=t3,a[8]=t9,tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 658  gensym */
((C_proc2)C_retrieve_symbol_proc(lf[83]))(2,*((C_word*)lf[83]+1),t12);}
else{
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_FALSE);}}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}}

/* k11786 in a11765 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_11788(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11788,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[8]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(C_word)C_a_i_list(&a,1,t1);
t5=((C_word*)t0)[7];
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11811,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t5,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11813,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11843,a[2]=((C_word*)t0)[2],a[3]=t7,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 675  qnode */
((C_proc3)C_retrieve_symbol_proc(lf[39]))(3,*((C_word*)lf[39]+1),t8,C_SCHEME_FALSE);}

/* k11841 in k11786 in a11765 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_11843(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 667  fold-right */
((C_proc5)C_retrieve_symbol_proc(lf[124]))(5,*((C_word*)lf[124]+1),((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* a11812 in k11786 in a11765 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_11813(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_11813,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11835,a[2]=t2,a[3]=t1,a[4]=t3,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 672  varnode */
((C_proc3)C_retrieve_symbol_proc(lf[49]))(3,*((C_word*)lf[49]+1),t4,((C_word*)t0)[2]);}

/* k11833 in a11812 in k11786 in a11765 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_11835(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11835,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11839,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 672  qnode */
((C_proc3)C_retrieve_symbol_proc(lf[39]))(3,*((C_word*)lf[39]+1),t2,((C_word*)t0)[2]);}

/* k11837 in k11833 in a11812 in k11786 in a11765 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_11839(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11839,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_record(&a,4,lf[37],lf[139],((C_word*)t0)[4],t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11831,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 673  qnode */
((C_proc3)C_retrieve_symbol_proc(lf[39]))(3,*((C_word*)lf[39]+1),t4,C_SCHEME_TRUE);}

/* k11829 in k11837 in k11833 in a11812 in k11786 in a11765 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_11831(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11831,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,((C_word*)t0)[4],t1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[37],lf[18],C_SCHEME_END_OF_LIST,t2));}

/* k11809 in k11786 in a11765 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_11811(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11811,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,t1,((C_word*)t0)[7],((C_word*)t0)[6]);
t3=(C_word)C_a_i_record(&a,4,lf[37],lf[11],((C_word*)t0)[5],t2);
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[37],lf[12],((C_word*)t0)[2],t4));}

/* a11936 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_11937(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9){
C_word tmp;
C_word t10;
C_word t11;
C_word ab[7],*a=ab;
if(c!=10) C_bad_argc_2(c,10,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr10,(void*)f_11937,10,t0,t1,t2,t3,t4,t5,t6,t7,t8,t9);}
if(C_truep(C_retrieve(lf[138]))){
t10=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11951,a[2]=t4,a[3]=t1,a[4]=t8,a[5]=t7,a[6]=t6,tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 643  varnode */
((C_proc3)C_retrieve_symbol_proc(lf[49]))(3,*((C_word*)lf[49]+1),t10,t9);}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}}

/* k11949 in a11936 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_11951(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11951,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);
t3=(C_word)C_a_i_record(&a,4,lf[37],lf[18],C_SCHEME_END_OF_LIST,t2);
t4=(C_word)C_a_i_list(&a,2,t1,t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[37],lf[16],((C_word*)t0)[2],t4));}

/* k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_5667(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5667,2,t0,t1);}
t2=C_mutate((C_word*)lf[122]+1 /* (set! reorganize-recursive-bindings ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5669,tmp=(C_word)a,a+=2,tmp));
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5995,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 770  make-vector */
((C_proc4)C_retrieve_proc(*((C_word*)lf[283]+1)))(4,*((C_word*)lf[283]+1),t3,C_fix(301),C_SCHEME_END_OF_LIST);}

/* k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_5995(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5995,2,t0,t1);}
t2=C_mutate((C_word*)lf[135]+1 /* (set! substitution-table ...) */,t1);
t3=C_mutate((C_word*)lf[136]+1 /* (set! rewrite ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5997,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate((C_word*)lf[137]+1 /* (set! simplify-named-call ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6017,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[178]+1 /* (set! transform-direct-lambdas! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7889,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[207]+1 /* (set! perform-lambda-lifting! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8984,tmp=(C_word)a,a+=2,tmp));
t7=C_set_block_item(lf[231] /* compiler-syntax-statistics */,0,C_SCHEME_END_OF_LIST);
t8=C_mutate((C_word*)lf[232]+1 /* (set! compiler-syntax-hook ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10628,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate((C_word*)lf[235]+1 /* (set! r-c-s ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10642,tmp=(C_word)a,a+=2,tmp));
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10694,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t11=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11582,tmp=(C_word)a,a+=2,tmp);
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11740,a[2]=t11,a[3]=t10,tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1804 ##sys#primitive-alias */
((C_proc3)C_retrieve_symbol_proc(lf[271]))(3,*((C_word*)lf[271]+1),t12,lf[278]);}

/* k11738 in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_11740(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11740,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[278],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
/* optimizer.scm: 1787 r-c-s */
((C_proc5)C_retrieve_symbol_proc(lf[235]))(5,*((C_word*)lf[235]+1),((C_word*)t0)[3],lf[282],((C_word*)t0)[2],t3);}

/* a11581 in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_11582(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_11582,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11586,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1790 r */
t6=t3;
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,lf[12]);}

/* k11584 in a11581 in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_11586(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11586,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11589,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 1791 r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[11]);}

/* k11587 in k11584 in a11581 in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_11589(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11589,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11592,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 1792 r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[281]);}

/* k11590 in k11587 in k11584 in a11581 in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_11592(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11592,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11595,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 1793 r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[280]);}

/* k11593 in k11590 in k11587 in k11584 in a11581 in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_11595(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11595,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_11598,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 1794 r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[279]);}

/* k11596 in k11593 in k11590 in k11587 in k11584 in a11581 in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_11598(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11598,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_11601,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 1795 r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[278]);}

/* k11599 in k11596 in k11593 in k11590 in k11587 in k11584 in a11581 in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_11601(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11601,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_11607,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
if(C_truep((C_word)C_i_memq(lf[132],C_retrieve(lf[277])))){
t3=(C_word)C_i_length(((C_word*)t0)[8]);
t4=t2;
f_11607(t4,(C_word)C_eqp(C_fix(3),t3));}
else{
t3=t2;
f_11607(t3,C_SCHEME_FALSE);}}

/* k11605 in k11599 in k11596 in k11593 in k11590 in k11587 in k11584 in a11581 in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_fcall f_11607(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word ab[78],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11607,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_caddr(((C_word*)t0)[9]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t6);
t8=(C_word)C_i_cadr(((C_word*)t0)[9]);
t9=(C_word)C_a_i_cons(&a,2,C_fix(0),C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t9);
t11=(C_word)C_a_i_cons(&a,2,lf[275],t10);
t12=(C_word)C_a_i_cons(&a,2,t11,C_SCHEME_END_OF_LIST);
t13=(C_word)C_a_i_cons(&a,2,t8,t12);
t14=(C_word)C_a_i_cons(&a,2,C_fix(1),C_SCHEME_END_OF_LIST);
t15=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t14);
t16=(C_word)C_a_i_cons(&a,2,lf[275],t15);
t17=(C_word)C_a_i_cons(&a,2,t16,C_SCHEME_END_OF_LIST);
t18=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t17);
t19=(C_word)C_a_i_cons(&a,2,lf[276],t18);
t20=(C_word)C_a_i_cons(&a,2,t19,C_SCHEME_END_OF_LIST);
t21=(C_word)C_a_i_cons(&a,2,t13,t20);
t22=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t21);
t23=(C_word)C_a_i_cons(&a,2,t22,C_SCHEME_END_OF_LIST);
t24=(C_word)C_a_i_cons(&a,2,t7,t23);
t25=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t24);
t26=(C_word)C_a_i_cons(&a,2,t25,C_SCHEME_END_OF_LIST);
t27=(C_word)C_a_i_cons(&a,2,t5,t26);
t28=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t27);
t29=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t29+1)))(2,t29,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t28));}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[9]);}}

/* k10692 in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_10694(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10694,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10697,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11533,tmp=(C_word)a,a+=2,tmp);
/* optimizer.scm: 1806 r-c-s */
((C_proc4)C_retrieve_symbol_proc(lf[235]))(4,*((C_word*)lf[235]+1),t2,lf[274],t3);}

/* a11532 in k10692 in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_11533(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_11533,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_length(t2);
t6=(C_word)C_fixnum_greaterp(t5,C_fix(1));
t7=(C_truep(t6)?(C_word)C_i_memq(lf[8],C_retrieve(lf[246])):C_SCHEME_FALSE);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11543,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1811 r */
t9=t3;
((C_proc3)C_retrieve_proc(t9))(3,t9,t8,lf[273]);}
else{
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t2);}}

/* k11541 in a11532 in k10692 in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_11543(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11543,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11550,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1812 r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[14]);}

/* k11548 in k11541 in a11532 in k10692 in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_11550(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11550,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11566,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* optimizer.scm: 1812 fold-right */
((C_proc5)C_retrieve_symbol_proc(lf[124]))(5,*((C_word*)lf[124]+1),t3,*((C_word*)lf[272]+1),((C_word*)t0)[4],t4);}

/* k11564 in k11548 in k11541 in a11532 in k10692 in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_11566(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11566,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* k10695 in k10692 in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_10697(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10697,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11531,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 1815 ##sys#primitive-alias */
((C_proc3)C_retrieve_symbol_proc(lf[271]))(3,*((C_word*)lf[271]+1),t2,lf[238]);}

/* k11529 in k10695 in k10692 in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_11531(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11531,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[238],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11527,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1816 ##sys#primitive-alias */
((C_proc3)C_retrieve_symbol_proc(lf[271]))(3,*((C_word*)lf[271]+1),t3,lf[239]);}

/* k11525 in k11529 in k10695 in k10692 in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_11527(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11527,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[239],t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11523,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1817 ##sys#primitive-alias */
((C_proc3)C_retrieve_symbol_proc(lf[271]))(3,*((C_word*)lf[271]+1),t3,lf[240]);}

/* k11521 in k11525 in k11529 in k10695 in k10692 in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_11523(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11523,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[240],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11519,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 1818 ##sys#primitive-alias */
((C_proc3)C_retrieve_symbol_proc(lf[271]))(3,*((C_word*)lf[271]+1),t3,lf[241]);}

/* k11517 in k11521 in k11525 in k11529 in k10695 in k10692 in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_11519(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11519,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[241],t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11515,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 1819 ##sys#primitive-alias */
((C_proc3)C_retrieve_symbol_proc(lf[271]))(3,*((C_word*)lf[271]+1),t3,lf[242]);}

/* k11513 in k11517 in k11521 in k11525 in k11529 in k10695 in k10692 in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_11515(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11515,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[242],t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11511,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 1820 ##sys#primitive-alias */
((C_proc3)C_retrieve_symbol_proc(lf[271]))(3,*((C_word*)lf[271]+1),t3,lf[243]);}

/* k11509 in k11513 in k11517 in k11521 in k11525 in k11529 in k10695 in k10692 in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_11511(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11511,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[243],t1);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_11507,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 1821 ##sys#primitive-alias */
((C_proc3)C_retrieve_symbol_proc(lf[271]))(3,*((C_word*)lf[271]+1),t3,lf[244]);}

/* k11505 in k11509 in k11513 in k11517 in k11521 in k11525 in k11529 in k10695 in k10692 in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_11507(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11507,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[244],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t5);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t6);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t7);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t8);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10703,a[2]=t9,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t11=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11375,tmp=(C_word)a,a+=2,tmp);
/* optimizer.scm: 1822 r-c-s */
((C_proc5)C_retrieve_symbol_proc(lf[235]))(5,*((C_word*)lf[235]+1),t10,lf[270],t11,t9);}

/* a11374 in k11505 in k11509 in k11513 in k11517 in k11521 in k11525 in k11529 in k10695 in k10692 in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_11375(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_11375,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11379,a[2]=t4,a[3]=t2,a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 1825 gensym */
((C_proc3)C_retrieve_symbol_proc(lf[83]))(3,*((C_word*)lf[83]+1),t5,lf[261]);}

/* k11377 in a11374 in k11505 in k11509 in k11513 in k11517 in k11521 in k11525 in k11529 in k10695 in k10692 in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_11379(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11379,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11382,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
t4=(C_word)C_i_memq(t3,lf[268]);
t5=(C_truep(t4)?lf[250]:lf[269]);
t6=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* optimizer.scm: 1826 compile-format-string */
((C_proc8)C_retrieve_symbol_proc(lf[245]))(8,*((C_word*)lf[245]+1),t2,t5,t1,((C_word*)t0)[3],t6,((C_word*)t0)[4],((C_word*)t0)[2]);}

/* k11380 in k11377 in a11374 in k11505 in k11509 in k11513 in k11517 in k11521 in k11525 in k11529 in k10695 in k10692 in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_11382(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11382,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11392,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 1835 r */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[12]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* k11390 in k11380 in k11377 in a11374 in k11505 in k11509 in k11513 in k11517 in k11521 in k11525 in k11529 in k10695 in k10692 in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_11392(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11392,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11436,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 1835 r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[243]);}

/* k11434 in k11390 in k11380 in k11377 in a11374 in k11505 in k11509 in k11513 in k11517 in k11521 in k11525 in k11529 in k10695 in k10692 in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_11436(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11436,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11416,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t5,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 1837 r */
t7=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,lf[244]);}

/* k11414 in k11434 in k11390 in k11380 in k11377 in a11374 in k11505 in k11509 in k11513 in k11517 in k11521 in k11525 in k11529 in k10695 in k10692 in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_11416(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11416,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t5);
t7=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t6));}

/* k10701 in k11505 in k11509 in k11513 in k11517 in k11521 in k11525 in k11529 in k10695 in k10692 in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_10703(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10703,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10706,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11348,tmp=(C_word)a,a+=2,tmp);
/* optimizer.scm: 1840 r-c-s */
((C_proc5)C_retrieve_symbol_proc(lf[235]))(5,*((C_word*)lf[235]+1),t2,lf[267],t3,((C_word*)t0)[2]);}

/* a11347 in k10701 in k11505 in k11509 in k11513 in k11517 in k11521 in k11525 in k11529 in k10695 in k10692 in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_11348(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_11348,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_length(t2);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t5,C_fix(3)))){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11358,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_i_cadr(t2);
t8=(C_word)C_i_cddr(t2);
/* optimizer.scm: 1844 compile-format-string */
((C_proc8)C_retrieve_symbol_proc(lf[245]))(8,*((C_word*)lf[245]+1),t6,lf[240],t7,t2,t8,t3,t4);}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t2);}}

/* k11356 in a11347 in k10701 in k11505 in k11509 in k11513 in k11517 in k11521 in k11525 in k11529 in k10695 in k10692 in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_11358(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?t1:((C_word*)t0)[2]));}

/* k10704 in k10701 in k11505 in k11509 in k11513 in k11517 in k11521 in k11525 in k11529 in k10695 in k10692 in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_10706(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10706,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10709,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11335,tmp=(C_word)a,a+=2,tmp);
/* optimizer.scm: 1853 r-c-s */
((C_proc5)C_retrieve_symbol_proc(lf[235]))(5,*((C_word*)lf[235]+1),t2,lf[266],t3,((C_word*)t0)[2]);}

/* a11334 in k10704 in k10701 in k11505 in k11509 in k11513 in k11517 in k11521 in k11525 in k11529 in k10695 in k10692 in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_11335(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_11335,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11339,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(t2);
/* optimizer.scm: 1856 compile-format-string */
((C_proc8)C_retrieve_symbol_proc(lf[245]))(8,*((C_word*)lf[245]+1),t5,lf[264],lf[265],t2,t6,t3,t4);}

/* k11337 in a11334 in k10704 in k10701 in k11505 in k11509 in k11513 in k11517 in k11521 in k11525 in k11529 in k10695 in k10692 in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_11339(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?t1:((C_word*)t0)[2]));}

/* k10707 in k10704 in k10701 in k11505 in k11509 in k11513 in k11517 in k11521 in k11525 in k11529 in k10695 in k10692 in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_10709(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10709,2,t0,t1);}
t2=C_mutate((C_word*)lf[245]+1 /* (set! compile-format-string ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10711,tmp=(C_word)a,a+=2,tmp));
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}

/* ##compiler#compile-format-string in k10707 in k10704 in k10701 in k11505 in k11509 in k11513 in k11517 in k11521 in k11525 in k11529 in k10695 in k10692 in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_10711(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
if(c!=8) C_bad_argc_2(c,8,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr8,(void*)f_10711,8,t0,t1,t2,t3,t4,t5,t6,t7);}
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10717,a[2]=t7,a[3]=t6,a[4]=t3,a[5]=t4,a[6]=t2,a[7]=t5,tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 1866 call/cc */
((C_proc3)C_retrieve_proc(*((C_word*)lf[263]+1)))(3,*((C_word*)lf[263]+1),t1,t8);}

/* a10716 in ##compiler#compile-format-string in k10707 in k10704 in k10701 in k11505 in k11509 in k11513 in k11517 in k11521 in k11525 in k11529 in k10695 in k10692 in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_10717(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[18],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10717,3,t0,t1,t2);}
t3=(C_word)C_i_length(((C_word*)t0)[7]);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,C_fix(1)))){
if(C_truep((C_word)C_i_memq(((C_word*)t0)[6],C_retrieve(lf[246])))){
t4=(C_word)C_i_car(((C_word*)t0)[7]);
t5=(C_word)C_i_stringp(t4);
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_10739,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t2,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t5)){
t7=t6;
f_10739(t7,t5);}
else{
t7=(C_word)C_i_car(((C_word*)t0)[7]);
if(C_truep((C_word)C_i_listp(t7))){
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11306,a[2]=((C_word*)t0)[7],a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11317,a[2]=((C_word*)t0)[7],a[3]=t8,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1872 r */
t10=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t10))(3,t10,t9,lf[27]);}
else{
t8=t6;
f_10739(t8,C_SCHEME_FALSE);}}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k11315 in a10716 in ##compiler#compile-format-string in k10707 in k10704 in k10701 in k11505 in k11509 in k11513 in k11517 in k11521 in k11525 in k11529 in k10695 in k10692 in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_11317(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11317,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11321,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1872 caar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[29]+1)))(3,*((C_word*)lf[29]+1),t2,((C_word*)t0)[2]);}

/* k11319 in k11315 in a10716 in ##compiler#compile-format-string in k10707 in k10704 in k10701 in k11505 in k11509 in k11513 in k11517 in k11521 in k11525 in k11529 in k10695 in k10692 in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_11321(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1872 c */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k11304 in a10716 in ##compiler#compile-format-string in k10707 in k10704 in k10701 in k11505 in k11509 in k11513 in k11517 in k11521 in k11525 in k11529 in k10695 in k10692 in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_11306(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11306,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11313,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 1873 cadar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[262]+1)))(3,*((C_word*)lf[262]+1),t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_10739(t2,C_SCHEME_FALSE);}}

/* k11311 in k11304 in a10716 in ##compiler#compile-format-string in k10707 in k10704 in k10701 in k11505 in k11509 in k11513 in k11517 in k11521 in k11525 in k11529 in k10695 in k10692 in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_11313(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_10739(t2,(C_word)C_i_stringp(t1));}

/* k10737 in a10716 in ##compiler#compile-format-string in k10707 in k10704 in k10701 in k11505 in k11509 in k11513 in k11517 in k11521 in k11525 in k11529 in k10695 in k10692 in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_fcall f_10739(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10739,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_10742,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[8]);
if(C_truep((C_word)C_i_stringp(t3))){
t4=t2;
f_10742(2,t4,(C_word)C_i_car(((C_word*)t0)[8]));}
else{
/* optimizer.scm: 1874 cadar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[262]+1)))(3,*((C_word*)lf[262]+1),t2,((C_word*)t0)[8]);}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k10740 in k10737 in a10716 in ##compiler#compile-format-string in k10707 in k10704 in k10701 in k11505 in k11509 in k11513 in k11517 in k11521 in k11525 in k11529 in k10695 in k10692 in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_10742(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10742,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[8]);
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10747,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t6=C_SCHEME_END_OF_LIST;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_fix(0);
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=(C_word)C_i_string_length(t1);
t11=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_10773,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t10,a[6]=t7,a[7]=t5,a[8]=t4,a[9]=t9,a[10]=t1,tmp=(C_word)a,a+=11,tmp);
/* optimizer.scm: 1888 r */
t12=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t12))(3,t12,t11,lf[238]);}

/* k10771 in k10740 in k10737 in a10716 in ##compiler#compile-format-string in k10707 in k10704 in k10701 in k11505 in k11509 in k11513 in k11517 in k11521 in k11525 in k11529 in k10695 in k10692 in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_10773(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10773,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_10776,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* optimizer.scm: 1889 r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[239]);}

/* k10774 in k10771 in k10740 in k10737 in a10716 in ##compiler#compile-format-string in k10707 in k10704 in k10701 in k11505 in k11509 in k11513 in k11517 in k11521 in k11525 in k11529 in k10695 in k10692 in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_10776(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10776,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_10779,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
/* optimizer.scm: 1890 r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[242]);}

/* k10777 in k10774 in k10771 in k10740 in k10737 in a10716 in ##compiler#compile-format-string in k10707 in k10704 in k10701 in k11505 in k11509 in k11513 in k11517 in k11521 in k11525 in k11529 in k10695 in k10692 in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_10779(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10779,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_10782,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
/* optimizer.scm: 1891 r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[261]);}

/* k10780 in k10777 in k10774 in k10771 in k10740 in k10737 in a10716 in ##compiler#compile-format-string in k10707 in k10704 in k10701 in k11505 in k11509 in k11513 in k11517 in k11521 in k11525 in k11529 in k10695 in k10692 in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_10782(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10782,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_10785,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],tmp=(C_word)a,a+=15,tmp);
/* optimizer.scm: 1892 r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[240]);}

/* k10783 in k10780 in k10777 in k10774 in k10771 in k10740 in k10737 in a10716 in ##compiler#compile-format-string in k10707 in k10704 in k10701 in k11505 in k11509 in k11513 in k11517 in k11521 in k11525 in k11529 in k10695 in k10692 in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_10785(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10785,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_10788,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],tmp=(C_word)a,a+=16,tmp);
/* optimizer.scm: 1893 r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[12]);}

/* k10786 in k10783 in k10780 in k10777 in k10774 in k10771 in k10740 in k10737 in a10716 in ##compiler#compile-format-string in k10707 in k10704 in k10701 in k11505 in k11509 in k11513 in k11517 in k11521 in k11525 in k11529 in k10695 in k10692 in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_10788(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10788,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_10791,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],tmp=(C_word)a,a+=16,tmp);
/* optimizer.scm: 1894 r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[241]);}

/* k10789 in k10786 in k10783 in k10780 in k10777 in k10774 in k10771 in k10740 in k10737 in a10716 in ##compiler#compile-format-string in k10707 in k10704 in k10701 in k11505 in k11509 in k11513 in k11517 in k11521 in k11525 in k11529 in k10695 in k10692 in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_10791(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[39],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10791,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10793,a[2]=((C_word*)t0)[14],a[3]=((C_word*)t0)[15],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10803,a[2]=((C_word*)t0)[12],a[3]=((C_word*)t0)[13],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10875,a[2]=((C_word*)t0)[11],tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10822,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|19,a[1]=(C_word)f_10885,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[8],a[6]=t3,a[7]=t4,a[8]=((C_word*)t0)[4],a[9]=t7,a[10]=t2,a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=t5,a[14]=((C_word*)t0)[11],a[15]=((C_word*)t0)[5],a[16]=((C_word*)t0)[10],a[17]=((C_word*)t0)[6],a[18]=((C_word*)t0)[7],a[19]=((C_word*)t0)[14],tmp=(C_word)a,a+=20,tmp));
t9=((C_word*)t7)[1];
f_10885(t9,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* loop in k10789 in k10786 in k10783 in k10780 in k10777 in k10774 in k10771 in k10740 in k10737 in a10716 in ##compiler#compile-format-string in k10707 in k10704 in k10701 in k11505 in k11509 in k11513 in k11517 in k11521 in k11525 in k11529 in k10695 in k10692 in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_fcall f_10885(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(16);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_10885,NULL,3,t0,t1,t2);}
t3=((C_word*)((C_word*)t0)[19])[1];
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[18]))){
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_10895,a[2]=t2,a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[14],a[5]=((C_word*)t0)[15],a[6]=t1,a[7]=((C_word*)t0)[16],a[8]=((C_word*)t0)[17],tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_i_nullp(((C_word*)((C_word*)t0)[12])[1]))){
t5=t4;
f_10895(2,t5,C_SCHEME_UNDEFINED);}
else{
/* optimizer.scm: 1916 fail */
t5=((C_word*)t0)[11];
f_10747(t5,t4,C_SCHEME_FALSE,lf[257],C_SCHEME_END_OF_LIST);}}
else{
t4=f_10793(((C_word*)t0)[10]);
t5=(C_word)C_eqp(t4,C_make_character(126));
if(C_truep(t5)){
t6=f_10793(((C_word*)t0)[10]);
t7=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_10946,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[19],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[7],a[11]=((C_word*)t0)[8],a[12]=((C_word*)t0)[16],a[13]=t1,a[14]=((C_word*)t0)[9],a[15]=t6,tmp=(C_word)a,a+=16,tmp);
/* optimizer.scm: 1924 endchunk */
t8=((C_word*)t0)[13];
f_10822(t8,t7,t2);}
else{
t6=(C_word)C_a_i_cons(&a,2,t4,t2);
/* optimizer.scm: 1947 loop */
t11=t1;
t12=t6;
t1=t11;
t2=t12;
goto loop;}}}

/* k10944 in loop in k10789 in k10786 in k10783 in k10780 in k10777 in k10774 in k10771 in k10740 in k10737 in a10716 in ##compiler#compile-format-string in k10707 in k10704 in k10701 in k11505 in k11509 in k11513 in k11517 in k11521 in k11525 in k11529 in k10695 in k10692 in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_10946(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10946,2,t0,t1);}
t2=(C_word)C_u_i_char_upcase(((C_word*)t0)[15]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10952,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[14],tmp=(C_word)a,a+=4,tmp);
switch(t2){
case C_make_character(83):
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10973,a[2]=((C_word*)t0)[10],a[3]=t3,a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[12],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 1926 next */
t5=((C_word*)t0)[9];
f_10803(t5,t4);
case C_make_character(65):
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10998,a[2]=((C_word*)t0)[10],a[3]=t3,a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[12],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 1927 next */
t5=((C_word*)t0)[9];
f_10803(t5,t4);
case C_make_character(67):
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11023,a[2]=((C_word*)t0)[10],a[3]=t3,a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[12],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 1928 next */
t5=((C_word*)t0)[9];
f_10803(t5,t4);
case C_make_character(66):
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11060,a[2]=((C_word*)t0)[10],a[3]=t3,a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 1929 next */
t5=((C_word*)t0)[9];
f_10803(t5,t4);
case C_make_character(79):
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11097,a[2]=((C_word*)t0)[10],a[3]=t3,a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 1930 next */
t5=((C_word*)t0)[9];
f_10803(t5,t4);
case C_make_character(88):
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11134,a[2]=((C_word*)t0)[10],a[3]=t3,a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 1931 next */
t5=((C_word*)t0)[9];
f_10803(t5,t4);
case C_make_character(33):
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[12],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[258],t4);
/* optimizer.scm: 1932 push */
t6=t3;
f_10952(2,t6,f_10875(C_a_i(&a,3),((C_word*)t0)[10],t5));
case C_make_character(63):
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11164,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[12],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 1934 next */
t5=((C_word*)t0)[9];
f_10803(t5,t4);
case C_make_character(126):
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[12],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,C_make_character(126),t4);
t6=(C_word)C_a_i_cons(&a,2,*((C_word*)lf[242]+1),t5);
/* optimizer.scm: 1937 push */
t7=t3;
f_10952(2,t7,f_10875(C_a_i(&a,3),((C_word*)t0)[10],t6));
default:
t4=(C_word)C_eqp(t2,C_make_character(37));
t5=(C_truep(t4)?t4:(C_word)C_eqp(t2,C_make_character(78)));
if(C_truep(t5)){
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[12],C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,C_make_character(10),t6);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t7);
/* optimizer.scm: 1938 push */
t9=t3;
f_10952(2,t9,f_10875(C_a_i(&a,3),((C_word*)t0)[10],t8));}
else{
if(C_truep((C_word)C_u_i_char_whitespacep(((C_word*)t0)[15]))){
t6=f_10793(((C_word*)t0)[4]);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11250,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t8=t3;
f_10952(2,t8,f_11250(t7,t6));}
else{
/* optimizer.scm: 1945 fail */
t6=((C_word*)t0)[2];
f_10747(t6,t3,C_SCHEME_TRUE,lf[260],(C_word)C_a_i_list(&a,1,((C_word*)t0)[15]));}}}}

/* skip in k10944 in loop in k10789 in k10786 in k10783 in k10780 in k10777 in k10774 in k10771 in k10740 in k10737 in a10716 in ##compiler#compile-format-string in k10707 in k10704 in k10701 in k11505 in k11509 in k11513 in k11517 in k11521 in k11525 in k11529 in k10695 in k10692 in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static C_word C_fcall f_11250(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
loop:
C_stack_check;
if(C_truep((C_word)C_u_i_char_whitespacep(t1))){
t2=f_10793(((C_word*)t0)[3]);
t6=t2;
t1=t6;
goto loop;}
else{
t2=(C_word)C_fixnum_decrease(((C_word*)((C_word*)t0)[2])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
return(t3);}}

/* k11162 in k10944 in loop in k10789 in k10786 in k10783 in k10780 in k10777 in k10774 in k10771 in k10740 in k10737 in a10716 in ##compiler#compile-format-string in k10707 in k10704 in k10701 in k11505 in k11509 in k11513 in k11517 in k11521 in k11525 in k11529 in k10695 in k10692 in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_11164(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11164,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11167,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 1935 next */
t3=((C_word*)t0)[2];
f_10803(t3,t2);}

/* k11165 in k11162 in k10944 in loop in k10789 in k10786 in k10783 in k10780 in k10777 in k10774 in k10771 in k10740 in k10737 in a10716 in ##compiler#compile-format-string in k10707 in k10704 in k10701 in k11505 in k11509 in k11513 in k11517 in k11521 in k11525 in k11529 in k10695 in k10692 in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_11167(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11167,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t4);
t6=(C_word)C_a_i_cons(&a,2,lf[259],t5);
/* optimizer.scm: 1936 push */
t7=((C_word*)t0)[3];
f_10952(2,t7,f_10875(C_a_i(&a,3),((C_word*)t0)[2],t6));}

/* k11132 in k10944 in loop in k10789 in k10786 in k10783 in k10780 in k10777 in k10774 in k10771 in k10740 in k10737 in a10716 in ##compiler#compile-format-string in k10707 in k10704 in k10701 in k11505 in k11509 in k11513 in k11517 in k11521 in k11525 in k11529 in k10695 in k10692 in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_11134(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11134,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_fix(16),C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,t4,t5);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t6);
/* optimizer.scm: 1931 push */
t8=((C_word*)t0)[3];
f_10952(2,t8,f_10875(C_a_i(&a,3),((C_word*)t0)[2],t7));}

/* k11095 in k10944 in loop in k10789 in k10786 in k10783 in k10780 in k10777 in k10774 in k10771 in k10740 in k10737 in a10716 in ##compiler#compile-format-string in k10707 in k10704 in k10701 in k11505 in k11509 in k11513 in k11517 in k11521 in k11525 in k11529 in k10695 in k10692 in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_11097(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11097,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_fix(8),C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,t4,t5);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t6);
/* optimizer.scm: 1930 push */
t8=((C_word*)t0)[3];
f_10952(2,t8,f_10875(C_a_i(&a,3),((C_word*)t0)[2],t7));}

/* k11058 in k10944 in loop in k10789 in k10786 in k10783 in k10780 in k10777 in k10774 in k10771 in k10740 in k10737 in a10716 in ##compiler#compile-format-string in k10707 in k10704 in k10701 in k11505 in k11509 in k11513 in k11517 in k11521 in k11525 in k11529 in k10695 in k10692 in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_11060(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11060,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_fix(2),C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,t4,t5);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t6);
/* optimizer.scm: 1929 push */
t8=((C_word*)t0)[3];
f_10952(2,t8,f_10875(C_a_i(&a,3),((C_word*)t0)[2],t7));}

/* k11021 in k10944 in loop in k10789 in k10786 in k10783 in k10780 in k10777 in k10774 in k10771 in k10740 in k10737 in a10716 in ##compiler#compile-format-string in k10707 in k10704 in k10701 in k11505 in k11509 in k11513 in k11517 in k11521 in k11525 in k11529 in k10695 in k10692 in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_11023(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11023,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t3);
/* optimizer.scm: 1928 push */
t5=((C_word*)t0)[3];
f_10952(2,t5,f_10875(C_a_i(&a,3),((C_word*)t0)[2],t4));}

/* k10996 in k10944 in loop in k10789 in k10786 in k10783 in k10780 in k10777 in k10774 in k10771 in k10740 in k10737 in a10716 in ##compiler#compile-format-string in k10707 in k10704 in k10701 in k11505 in k11509 in k11513 in k11517 in k11521 in k11525 in k11529 in k10695 in k10692 in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_10998(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10998,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t3);
/* optimizer.scm: 1927 push */
t5=((C_word*)t0)[3];
f_10952(2,t5,f_10875(C_a_i(&a,3),((C_word*)t0)[2],t4));}

/* k10971 in k10944 in loop in k10789 in k10786 in k10783 in k10780 in k10777 in k10774 in k10771 in k10740 in k10737 in a10716 in ##compiler#compile-format-string in k10707 in k10704 in k10701 in k11505 in k11509 in k11513 in k11517 in k11521 in k11525 in k11529 in k10695 in k10692 in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_10973(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10973,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t3);
/* optimizer.scm: 1926 push */
t5=((C_word*)t0)[3];
f_10952(2,t5,f_10875(C_a_i(&a,3),((C_word*)t0)[2],t4));}

/* k10950 in k10944 in loop in k10789 in k10786 in k10783 in k10780 in k10777 in k10774 in k10771 in k10740 in k10737 in a10716 in ##compiler#compile-format-string in k10707 in k10704 in k10701 in k11505 in k11509 in k11513 in k11517 in k11521 in k11525 in k11529 in k10695 in k10692 in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_10952(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1946 loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_10885(t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k10893 in loop in k10789 in k10786 in k10783 in k10780 in k10777 in k10774 in k10771 in k10740 in k10737 in a10716 in ##compiler#compile-format-string in k10707 in k10704 in k10701 in k11505 in k11509 in k11513 in k11517 in k11521 in k11525 in k11529 in k10695 in k10692 in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_10895(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10895,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10898,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 1917 endchunk */
t3=((C_word*)t0)[3];
f_10822(t3,t2,((C_word*)t0)[2]);}

/* k10896 in k10893 in loop in k10789 in k10786 in k10783 in k10780 in k10777 in k10774 in k10771 in k10740 in k10737 in a10716 in ##compiler#compile-format-string in k10707 in k10704 in k10701 in k11505 in k11509 in k11513 in k11517 in k11521 in k11525 in k11529 in k10695 in k10692 in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_10898(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10898,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10913,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10917,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 1919 reverse */
((C_proc3)C_retrieve_proc(*((C_word*)lf[114]+1)))(3,*((C_word*)lf[114]+1),t6,((C_word*)((C_word*)t0)[2])[1]);}

/* k10915 in k10896 in k10893 in loop in k10789 in k10786 in k10783 in k10780 in k10777 in k10774 in k10771 in k10740 in k10737 in a10716 in ##compiler#compile-format-string in k10707 in k10704 in k10701 in k11505 in k11509 in k11513 in k11517 in k11521 in k11525 in k11529 in k10695 in k10692 in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_10917(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[256]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k10911 in k10896 in k10893 in loop in k10789 in k10786 in k10783 in k10780 in k10777 in k10774 in k10771 in k10740 in k10737 in a10716 in ##compiler#compile-format-string in k10707 in k10704 in k10701 in k11505 in k11509 in k11513 in k11517 in k11521 in k11525 in k11529 in k10695 in k10692 in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_10913(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10913,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* endchunk in k10789 in k10786 in k10783 in k10780 in k10777 in k10774 in k10771 in k10740 in k10737 in a10716 in ##compiler#compile-format-string in k10707 in k10704 in k10701 in k11505 in k11509 in k11513 in k11517 in k11521 in k11525 in k11529 in k10695 in k10692 in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_fcall f_10822(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10822,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10836,a[2]=((C_word*)t0)[5],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_length(t2);
t5=(C_word)C_eqp(C_fix(1),t4);
if(C_truep(t5)){
t6=(C_word)C_i_car(t2);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,t6,t7);
t9=t3;
f_10836(t9,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t8));}
else{
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10865,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1910 reverse-list->string */
((C_proc3)C_retrieve_symbol_proc(lf[255]))(3,*((C_word*)lf[255]+1),t6,t2);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k10863 in endchunk in k10789 in k10786 in k10783 in k10780 in k10777 in k10774 in k10771 in k10740 in k10737 in a10716 in ##compiler#compile-format-string in k10707 in k10704 in k10701 in k11505 in k11509 in k11513 in k11517 in k11521 in k11525 in k11529 in k10695 in k10692 in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_10865(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10865,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=((C_word*)t0)[3];
f_10836(t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* k10834 in endchunk in k10789 in k10786 in k10783 in k10780 in k10777 in k10774 in k10771 in k10740 in k10737 in a10716 in ##compiler#compile-format-string in k10707 in k10704 in k10701 in k11505 in k11509 in k11513 in k11517 in k11521 in k11525 in k11529 in k10695 in k10692 in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_fcall f_10836(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10836,NULL,2,t0,t1);}
/* optimizer.scm: 1907 push */
t2=((C_word*)t0)[3];
((C_proc2)C_retrieve_proc(t2))(2,t2,f_10875(C_a_i(&a,3),((C_word*)t0)[2],t1));}

/* push in k10789 in k10786 in k10783 in k10780 in k10777 in k10774 in k10771 in k10740 in k10737 in a10716 in ##compiler#compile-format-string in k10707 in k10704 in k10701 in k11505 in k11509 in k11513 in k11517 in k11521 in k11525 in k11529 in k10695 in k10692 in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static C_word C_fcall f_10875(C_word *a,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_stack_check;
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)((C_word*)t0)[2])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
return(t3);}

/* next in k10789 in k10786 in k10783 in k10780 in k10777 in k10774 in k10771 in k10740 in k10737 in a10716 in ##compiler#compile-format-string in k10707 in k10704 in k10701 in k11505 in k11509 in k11513 in k11517 in k11521 in k11525 in k11529 in k10695 in k10692 in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_fcall f_10803(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10803,NULL,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(((C_word*)((C_word*)t0)[3])[1]))){
/* optimizer.scm: 1901 fail */
t2=((C_word*)t0)[2];
f_10747(t2,t1,C_SCHEME_TRUE,lf[254],C_SCHEME_END_OF_LIST);}
else{
t2=(C_word)C_i_car(((C_word*)((C_word*)t0)[3])[1]);
t3=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t2);}}

/* fetch in k10789 in k10786 in k10783 in k10780 in k10777 in k10774 in k10771 in k10740 in k10737 in a10716 in ##compiler#compile-format-string in k10707 in k10704 in k10701 in k11505 in k11509 in k11513 in k11517 in k11521 in k11525 in k11529 in k10695 in k10692 in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static C_word C_fcall f_10793(C_word t0){
C_word tmp;
C_word t1;
C_word t2;
C_word t3;
C_word t4;
C_stack_check;
t1=(C_word)C_i_string_ref(((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);
t2=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[2])[1],C_fix(1));
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
return(t1);}

/* fail in k10740 in k10737 in a10716 in ##compiler#compile-format-string in k10707 in k10704 in k10701 in k11505 in k11509 in k11513 in k11517 in k11521 in k11525 in k11529 in k10695 in k10692 in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_fcall f_10747(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10747,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_10751,a[2]=t4,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,a[7]=((C_word*)t0)[5],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 1877 get-line */
((C_proc3)C_retrieve_symbol_proc(lf[253]))(3,*((C_word*)lf[253]+1),t5,((C_word*)t0)[2]);}

/* k10749 in fail in k10740 in k10737 in a10716 in ##compiler#compile-format-string in k10707 in k10704 in k10701 in k11505 in k11509 in k11513 in k11517 in k11521 in k11525 in k11529 in k10695 in k10692 in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_10751(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10751,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10754,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10764,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t1)){
/* optimizer.scm: 1882 sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[250]))(4,*((C_word*)lf[250]+1),t3,lf[251],t1);}
else{
t4=t3;
f_10764(2,t4,lf[252]);}}

/* k10762 in k10749 in fail in k10740 in k10737 in a10716 in ##compiler#compile-format-string in k10707 in k10704 in k10701 in k11505 in k11509 in k11513 in k11517 in k11521 in k11525 in k11529 in k10695 in k10692 in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_10764(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1878 compiler-warning */
((C_proc9)C_retrieve_symbol_proc(lf[247]))(9,*((C_word*)lf[247]+1),((C_word*)t0)[6],lf[248],lf[249],((C_word*)t0)[5],((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k10752 in k10749 in fail in k10740 in k10737 in a10716 in ##compiler#compile-format-string in k10707 in k10704 in k10701 in k11505 in k11509 in k11513 in k11517 in k11521 in k11525 in k11529 in k10695 in k10692 in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_10754(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(((C_word*)t0)[4])){
/* optimizer.scm: 1884 return */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_SCHEME_FALSE);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* ##compiler#r-c-s in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_10642(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_10642r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_10642r(t0,t1,t2,t3,t4);}}

static void C_ccall f_10642r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10646,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_10646(2,t6,C_SCHEME_END_OF_LIST);}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_10646(2,t7,(C_word)C_i_car(t4));}
else{
/* ##sys#error */
t7=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* k10644 in ##compiler#r-c-s in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_10646(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10646,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10672,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1781 ##sys#er-transformer */
((C_proc3)C_retrieve_symbol_proc(lf[237]))(3,*((C_word*)lf[237]+1),t2,((C_word*)t0)[2]);}

/* k10670 in k10644 in ##compiler#r-c-s in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_10672(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10672,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10654,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_symbolp(((C_word*)t0)[3]);
t5=(C_truep(t4)?(C_word)C_a_i_list(&a,1,((C_word*)t0)[3]):((C_word*)t0)[3]);
/* for-each */
t6=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,((C_word*)t0)[2],t3,t5);}

/* a10653 in k10670 in k10644 in ##compiler#r-c-s in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_10654(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10654,3,t0,t1,t2);}
/* optimizer.scm: 1784 ##sys#put! */
((C_proc5)C_retrieve_symbol_proc(lf[3]))(5,*((C_word*)lf[3]+1),t1,t2,lf[236],((C_word*)t0)[2]);}

/* ##sys#compiler-syntax-hook in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_10628(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10628,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10632,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1776 alist-ref */
((C_proc6)C_retrieve_symbol_proc(lf[234]))(6,*((C_word*)lf[234]+1),t4,t2,C_retrieve(lf[231]),*((C_word*)lf[36]+1),C_fix(0));}

/* k10630 in ##sys#compiler-syntax-hook in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_10632(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10632,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10636,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_fixnum_increase(t1);
/* optimizer.scm: 1778 alist-update! */
((C_proc5)C_retrieve_symbol_proc(lf[233]))(5,*((C_word*)lf[233]+1),t2,((C_word*)t0)[2],t3,C_retrieve(lf[231]));}

/* k10634 in k10630 in ##sys#compiler-syntax-hook in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_10636(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[231]+1 /* (set! compiler-syntax-statistics ...) */,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_8984(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[44],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8984,4,t0,t1,t2,t3);}
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8987,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9087,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9284,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9383,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9627,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9846,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10047,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10296,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10383,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t15=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_10530,a[2]=t6,a[3]=t7,a[4]=t8,a[5]=t9,a[6]=t10,a[7]=t11,a[8]=t13,a[9]=t14,a[10]=t1,a[11]=t12,tmp=(C_word)a,a+=12,tmp);
/* optimizer.scm: 1746 debugging */
((C_proc4)C_retrieve_symbol_proc(lf[7]))(4,*((C_word*)lf[7]+1),t15,lf[21],lf[230]);}

/* k10528 in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_10530(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10530,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_10533,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
/* optimizer.scm: 1747 find-lifting-candidates */
t3=((C_word*)t0)[2];
f_8987(t3,t2);}

/* k10531 in k10528 in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_10533(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10533,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_10536,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* optimizer.scm: 1748 debugging */
((C_proc4)C_retrieve_symbol_proc(lf[7]))(4,*((C_word*)lf[7]+1),t2,lf[21],lf[229]);}

/* k10534 in k10531 in k10528 in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_10536(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10536,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_10539,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
/* optimizer.scm: 1749 build-call-graph */
t3=((C_word*)t0)[2];
f_9087(t3,t2,((C_word*)t0)[3]);}

/* k10537 in k10534 in k10531 in k10528 in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_10539(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10539,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_10542,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* optimizer.scm: 1750 debugging */
((C_proc4)C_retrieve_symbol_proc(lf[7]))(4,*((C_word*)lf[7]+1),t2,lf[21],lf[228]);}

/* k10540 in k10537 in k10534 in k10531 in k10528 in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_10542(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10542,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_10545,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 1751 eliminate */
t3=((C_word*)t0)[4];
f_9284(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k10543 in k10540 in k10537 in k10534 in k10531 in k10528 in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_10545(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10545,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_10548,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10622,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1752 debugging */
((C_proc4)C_retrieve_symbol_proc(lf[7]))(4,*((C_word*)lf[7]+1),t3,lf[220],lf[227]);}

/* k10620 in k10543 in k10540 in k10537 in k10534 in k10531 in k10528 in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_10622(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* optimizer.scm: 1752 pretty-print */
((C_proc3)C_retrieve_symbol_proc(lf[219]))(3,*((C_word*)lf[219]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_10548(2,t2,C_SCHEME_UNDEFINED);}}

/* k10546 in k10543 in k10540 in k10537 in k10534 in k10531 in k10528 in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_10548(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10548,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_10551,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm: 1753 debugging */
((C_proc4)C_retrieve_symbol_proc(lf[7]))(4,*((C_word*)lf[7]+1),t2,lf[21],lf[226]);}

/* k10549 in k10546 in k10543 in k10540 in k10537 in k10534 in k10531 in k10528 in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_10551(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10551,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_10554,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 1754 collect-accessibles */
t3=((C_word*)t0)[2];
f_9383(t3,t2,((C_word*)t0)[3]);}

/* k10552 in k10549 in k10546 in k10543 in k10540 in k10537 in k10534 in k10531 in k10528 in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_10554(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10554,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_10557,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10616,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1755 debugging */
((C_proc4)C_retrieve_symbol_proc(lf[7]))(4,*((C_word*)lf[7]+1),t3,lf[220],lf[225]);}

/* k10614 in k10552 in k10549 in k10546 in k10543 in k10540 in k10537 in k10534 in k10531 in k10528 in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_10616(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* optimizer.scm: 1755 pretty-print */
((C_proc3)C_retrieve_symbol_proc(lf[219]))(3,*((C_word*)lf[219]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_10557(2,t2,C_SCHEME_UNDEFINED);}}

/* k10555 in k10552 in k10549 in k10546 in k10543 in k10540 in k10537 in k10534 in k10531 in k10528 in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_10557(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10557,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_10560,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 1756 debugging */
((C_proc4)C_retrieve_symbol_proc(lf[7]))(4,*((C_word*)lf[7]+1),t2,lf[21],lf[224]);}

/* k10558 in k10555 in k10552 in k10549 in k10546 in k10543 in k10540 in k10537 in k10534 in k10531 in k10528 in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_10560(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10560,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10563,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10613,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 1757 eliminate4 */
t4=((C_word*)t0)[3];
f_9627(t4,t3,((C_word*)t0)[2]);}

/* k10611 in k10558 in k10555 in k10552 in k10549 in k10546 in k10543 in k10540 in k10537 in k10534 in k10531 in k10528 in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_10613(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10613,2,t0,t1);}
t2=(C_word)C_i_length(t1);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9593,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_9593(t6,((C_word*)t0)[2],t1,t2);}

/* loop in k10611 in k10558 in k10555 in k10552 in k10549 in k10546 in k10543 in k10540 in k10537 in k10534 in k10531 in k10528 in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_fcall f_9593(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9593,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9597,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9611,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 1551 filter */
((C_proc4)C_retrieve_symbol_proc(lf[129]))(4,*((C_word*)lf[129]+1),t4,t5,t2);}

/* a9610 in loop in k10611 in k10558 in k10555 in k10552 in k10549 in k10546 in k10543 in k10540 in k10537 in k10534 in k10531 in k10528 in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_9611(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9611,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9617,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_cddr(t2);
/* optimizer.scm: 1551 every */
((C_proc4)C_retrieve_symbol_proc(lf[43]))(4,*((C_word*)lf[43]+1),t1,t3,t4);}

/* a9616 in a9610 in loop in k10611 in k10558 in k10555 in k10552 in k10549 in k10546 in k10543 in k10540 in k10537 in k10534 in k10531 in k10528 in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_9617(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9617,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_assq(t2,((C_word*)t0)[2]));}

/* k9595 in loop in k10611 in k10558 in k10555 in k10552 in k10549 in k10546 in k10543 in k10540 in k10537 in k10534 in k10531 in k10528 in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_9597(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_i_length(t1);
t3=((C_word*)t0)[4];
t4=(C_word)C_eqp(t3,t2);
if(C_truep(t4)){
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t1);}
else{
/* optimizer.scm: 1555 loop */
t5=((C_word*)((C_word*)t0)[2])[1];
f_9593(t5,((C_word*)t0)[3],t1,t2);}}

/* k10561 in k10558 in k10555 in k10552 in k10549 in k10546 in k10543 in k10540 in k10537 in k10534 in k10531 in k10528 in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_10563(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10563,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10566,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10603,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10605,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* ##sys#make-promise */
t5=*((C_word*)lf[198]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a10604 in k10561 in k10558 in k10555 in k10552 in k10549 in k10546 in k10543 in k10540 in k10537 in k10534 in k10531 in k10528 in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_10605(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10605,2,t0,t1);}
/* optimizer.scm: 1758 unzip1 */
((C_proc3)C_retrieve_symbol_proc(lf[197]))(3,*((C_word*)lf[197]+1),t1,((C_word*)t0)[2]);}

/* k10601 in k10561 in k10558 in k10555 in k10552 in k10549 in k10546 in k10543 in k10540 in k10537 in k10534 in k10531 in k10528 in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_10603(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1758 debugging */
((C_proc5)C_retrieve_symbol_proc(lf[7]))(5,*((C_word*)lf[7]+1),((C_word*)t0)[2],lf[8],lf[223],t1);}

/* k10564 in k10561 in k10558 in k10555 in k10552 in k10549 in k10546 in k10543 in k10540 in k10537 in k10534 in k10531 in k10528 in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_10566(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10566,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10569,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 1759 debugging */
((C_proc4)C_retrieve_symbol_proc(lf[7]))(4,*((C_word*)lf[7]+1),t2,lf[21],lf[222]);}

/* k10567 in k10564 in k10561 in k10558 in k10555 in k10552 in k10549 in k10546 in k10543 in k10540 in k10537 in k10534 in k10531 in k10528 in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_10569(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10569,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10572,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 1760 compute-extra-variables */
t3=((C_word*)t0)[2];
f_9846(t3,t2,((C_word*)t0)[5]);}

/* k10570 in k10567 in k10564 in k10561 in k10558 in k10555 in k10552 in k10549 in k10546 in k10543 in k10540 in k10537 in k10534 in k10531 in k10528 in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_10572(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10572,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10575,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10596,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1761 debugging */
((C_proc4)C_retrieve_symbol_proc(lf[7]))(4,*((C_word*)lf[7]+1),t3,lf[220],lf[221]);}

/* k10594 in k10570 in k10567 in k10564 in k10561 in k10558 in k10555 in k10552 in k10549 in k10546 in k10543 in k10540 in k10537 in k10534 in k10531 in k10528 in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_10596(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* optimizer.scm: 1761 pretty-print */
((C_proc3)C_retrieve_symbol_proc(lf[219]))(3,*((C_word*)lf[219]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_10575(2,t2,C_SCHEME_UNDEFINED);}}

/* k10573 in k10570 in k10567 in k10564 in k10561 in k10558 in k10555 in k10552 in k10549 in k10546 in k10543 in k10540 in k10537 in k10534 in k10531 in k10528 in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_10575(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10575,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10578,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 1762 debugging */
((C_proc4)C_retrieve_symbol_proc(lf[7]))(4,*((C_word*)lf[7]+1),t2,lf[21],lf[218]);}

/* k10576 in k10573 in k10570 in k10567 in k10564 in k10561 in k10558 in k10555 in k10552 in k10549 in k10546 in k10543 in k10540 in k10537 in k10534 in k10531 in k10528 in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_10578(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10578,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10581,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 1763 extend-call-sites! */
t3=((C_word*)t0)[2];
f_10296(t3,t2,((C_word*)t0)[4]);}

/* k10579 in k10576 in k10573 in k10570 in k10567 in k10564 in k10561 in k10558 in k10555 in k10552 in k10549 in k10546 in k10543 in k10540 in k10537 in k10534 in k10531 in k10528 in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_10581(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10581,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10584,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 1764 debugging */
((C_proc4)C_retrieve_symbol_proc(lf[7]))(4,*((C_word*)lf[7]+1),t2,lf[21],lf[217]);}

/* k10582 in k10579 in k10576 in k10573 in k10570 in k10567 in k10564 in k10561 in k10558 in k10555 in k10552 in k10549 in k10546 in k10543 in k10540 in k10537 in k10534 in k10531 in k10528 in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_10584(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10584,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10587,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 1765 remove-local-bindings! */
t3=((C_word*)t0)[2];
f_10383(t3,t2,((C_word*)t0)[4]);}

/* k10585 in k10582 in k10579 in k10576 in k10573 in k10570 in k10567 in k10564 in k10561 in k10558 in k10555 in k10552 in k10549 in k10546 in k10543 in k10540 in k10537 in k10534 in k10531 in k10528 in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_10587(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10587,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10590,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 1766 debugging */
((C_proc4)C_retrieve_symbol_proc(lf[7]))(4,*((C_word*)lf[7]+1),t2,lf[21],lf[216]);}

/* k10588 in k10585 in k10582 in k10579 in k10576 in k10573 in k10570 in k10567 in k10564 in k10561 in k10558 in k10555 in k10552 in k10549 in k10546 in k10543 in k10540 in k10537 in k10534 in k10531 in k10528 in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_10590(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1767 reconstruct! */
t2=((C_word*)t0)[5];
f_10047(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* remove-local-bindings! in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_fcall f_10383(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10383,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10389,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_10389(3,t6,t1,((C_word*)t0)[2]);}

/* walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_10389(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10389,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(1));
t5=t2;
t6=(C_word)C_slot(t5,C_fix(2));
t7=t2;
t8=(C_word)C_slot(t7,C_fix(3));
t9=(C_word)C_eqp(t4,lf[12]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10408,a[2]=t8,a[3]=t6,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t11=t2;
t12=(C_word)C_slot(t11,C_fix(3));
/* for-each */
t13=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t13+1)))(4,t13,t10,((C_word*)((C_word*)t0)[2])[1],t12);}
else{
t10=(C_word)C_eqp(t4,lf[17]);
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10501,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t6,tmp=(C_word)a,a+=6,tmp);
t12=t2;
t13=(C_word)C_slot(t12,C_fix(3));
/* for-each */
t14=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t14+1)))(4,t14,t11,((C_word*)((C_word*)t0)[2])[1],t13);}
else{
/* for-each */
t11=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t1,((C_word*)((C_word*)t0)[2])[1],t8);}}}

/* k10499 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_10501(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10501,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_assq(t2,((C_word*)t0)[4]))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10510,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1741 node-class-set! */
((C_proc4)C_retrieve_symbol_proc(lf[184]))(4,*((C_word*)lf[184]+1),t3,((C_word*)t0)[2],lf[69]);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k10508 in k10499 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_10510(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10510,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10513,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1742 node-parameters-set! */
((C_proc4)C_retrieve_symbol_proc(lf[115]))(4,*((C_word*)lf[115]+1),t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k10511 in k10508 in k10499 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_10513(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1743 node-subexpressions-set! */
((C_proc4)C_retrieve_symbol_proc(lf[113]))(4,*((C_word*)lf[113]+1),((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k10406 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_10408(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10408,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10413,a[2]=((C_word*)t0)[5],a[3]=t7,a[4]=t5,a[5]=((C_word*)t0)[6],a[6]=t3,tmp=(C_word)a,a+=7,tmp));
t9=((C_word*)t7)[1];
f_10413(t9,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* doloop3281 in k10406 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_fcall f_10413(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10413,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
if(C_truep((C_word)C_i_nullp(((C_word*)((C_word*)t0)[6])[1]))){
t4=(C_word)C_i_car(t3);
/* optimizer.scm: 1731 copy-node! */
((C_proc4)C_retrieve_symbol_proc(lf[179]))(4,*((C_word*)lf[179]+1),t1,t4,((C_word*)t0)[5]);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10436,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10451,a[2]=((C_word*)t0)[5],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1733 reverse */
((C_proc3)C_retrieve_proc(*((C_word*)lf[114]+1)))(3,*((C_word*)lf[114]+1),t5,((C_word*)((C_word*)t0)[6])[1]);}}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10454,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_assq(t5,((C_word*)t0)[2]))){
t6=t4;
f_10454(t6,C_SCHEME_UNDEFINED);}
else{
t6=(C_word)C_i_car(t2);
t7=(C_word)C_a_i_cons(&a,2,t6,((C_word*)((C_word*)t0)[6])[1]);
t8=C_mutate(((C_word *)((C_word*)t0)[6])+1,t7);
t9=(C_word)C_i_car(t3);
t10=(C_word)C_a_i_cons(&a,2,t9,((C_word*)((C_word*)t0)[4])[1]);
t11=C_mutate(((C_word *)((C_word*)t0)[4])+1,t10);
t12=t4;
f_10454(t12,t11);}}}

/* k10452 in doloop3281 in k10406 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_fcall f_10454(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
t4=((C_word*)((C_word*)t0)[3])[1];
f_10413(t4,((C_word*)t0)[2],t2,t3);}

/* k10449 in doloop3281 in k10406 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_10451(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1733 node-parameters-set! */
((C_proc4)C_retrieve_symbol_proc(lf[115]))(4,*((C_word*)lf[115]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k10434 in doloop3281 in k10406 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_10436(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10436,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10443,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10447,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1734 reverse */
((C_proc3)C_retrieve_proc(*((C_word*)lf[114]+1)))(3,*((C_word*)lf[114]+1),t3,((C_word*)((C_word*)t0)[2])[1]);}

/* k10445 in k10434 in doloop3281 in k10406 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_10447(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1734 append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[13]+1)))(4,*((C_word*)lf[13]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k10441 in k10434 in doloop3281 in k10406 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_10443(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1734 node-subexpressions-set! */
((C_proc4)C_retrieve_symbol_proc(lf[113]))(4,*((C_word*)lf[113]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* extend-call-sites! in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_fcall f_10296(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10296,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10302,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_10302(3,t6,t1,((C_word*)t0)[2]);}

/* walk in extend-call-sites! in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_10302(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word ab[14],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10302,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(1));
t5=t2;
t6=(C_word)C_slot(t5,C_fix(2));
t7=t2;
t8=(C_word)C_slot(t7,C_fix(3));
t9=(C_word)C_eqp(t4,lf[16]);
if(C_truep(t9)){
t10=(C_word)C_i_car(t8);
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10324,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t12=(C_word)C_slot(t10,C_fix(1));
t13=(C_word)C_eqp(lf[10],t12);
if(C_truep(t13)){
t14=(C_word)C_slot(t10,C_fix(2));
t15=(C_word)C_i_car(t14);
t16=(C_word)C_i_assq(t15,((C_word*)t0)[2]);
if(C_truep(t16)){
t17=(C_word)C_i_set_car(t6,C_SCHEME_TRUE);
t18=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10354,a[2]=t2,a[3]=t11,a[4]=t10,tmp=(C_word)a,a+=5,tmp);
t19=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10358,a[2]=t18,a[3]=t8,tmp=(C_word)a,a+=4,tmp);
t20=(C_word)C_i_cdr(t16);
/* map */
t21=*((C_word*)lf[30]+1);
((C_proc4)(void*)(*((C_word*)t21+1)))(4,t21,t19,C_retrieve(lf[49]),t20);}
else{
t17=t11;
f_10324(2,t17,C_SCHEME_UNDEFINED);}}
else{
t14=t11;
f_10324(2,t14,C_SCHEME_UNDEFINED);}}
else{
/* for-each */
t10=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t1,((C_word*)((C_word*)t0)[3])[1],t8);}}

/* k10356 in walk in extend-call-sites! in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_10358(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* optimizer.scm: 1713 append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[13]+1)))(4,*((C_word*)lf[13]+1),((C_word*)t0)[2],t1,t2);}

/* k10352 in walk in extend-call-sites! in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_10354(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10354,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
/* optimizer.scm: 1711 node-subexpressions-set! */
((C_proc4)C_retrieve_symbol_proc(lf[113]))(4,*((C_word*)lf[113]+1),((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k10322 in walk in extend-call-sites! in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_10324(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=((C_word*)t0)[4];
t3=(C_word)C_slot(t2,C_fix(3));
/* for-each */
t4=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t3);}

/* reconstruct! in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_fcall f_10047(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10047,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10059,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10061,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=((C_word*)t0)[3];
t7=(C_word)C_slot(t6,C_fix(3));
t8=(C_word)C_i_car(t7);
/* optimizer.scm: 1647 fold-right */
((C_proc5)C_retrieve_symbol_proc(lf[124]))(5,*((C_word*)lf[124]+1),t4,t5,t8,t2);}

/* a10060 in reconstruct! in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_10061(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10061,4,t0,t1,t2,t3);}
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10068,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 1650 get */
((C_proc5)C_retrieve_symbol_proc(lf[26]))(5,*((C_word*)lf[26]+1),t5,((C_word*)t0)[2],t4,lf[47]);}

/* k10066 in a10060 in reconstruct! in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_10068(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10068,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10071,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 1651 hide-variable */
((C_proc3)C_retrieve_symbol_proc(lf[215]))(3,*((C_word*)lf[215]+1),t2,((C_word*)t0)[5]);}

/* k10069 in k10066 in a10060 in reconstruct! in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_10071(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10071,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(2));
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10080,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 1652 decompose-lambda-list */
((C_proc4)C_retrieve_symbol_proc(lf[62]))(4,*((C_word*)lf[62]+1),((C_word*)t0)[2],t3,t4);}

/* a10079 in k10069 in k10066 in a10060 in reconstruct! in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_10080(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_10080,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_assq(((C_word*)t0)[5],((C_word*)t0)[4]);
t6=(C_word)C_i_cdr(t5);
t7=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_10087,a[2]=t2,a[3]=t4,a[4]=t3,a[5]=t6,a[6]=t1,a[7]=((C_word*)t0)[2],a[8]=((C_word*)t0)[3],a[9]=((C_word*)t0)[5],tmp=(C_word)a,a+=10,tmp);
/* map */
t8=*((C_word*)lf[30]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,C_retrieve(lf[83]),t6);}

/* k10085 in a10079 in k10069 in k10066 in a10060 in reconstruct! in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_10087(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10087,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_10090,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* optimizer.scm: 1657 map */
((C_proc5)C_retrieve_proc(*((C_word*)lf[133]+1)))(5,*((C_word*)lf[133]+1),t2,*((C_word*)lf[134]+1),((C_word*)t0)[5],t1);}

/* k10088 in k10085 in a10079 in k10069 in k10066 in a10060 in reconstruct! in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_10090(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10090,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_10093,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(C_word)C_slot(((C_word*)t0)[9],C_fix(3));
t4=(C_word)C_i_car(t3);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10171,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10186,a[2]=t5,a[3]=t7,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_10186(3,t9,t2,t4);}

/* walk in k10088 in k10085 in a10079 in k10069 in k10066 in a10060 in reconstruct! in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_10186(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10186,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(1));
t5=t2;
t6=(C_word)C_slot(t5,C_fix(2));
t7=t2;
t8=(C_word)C_slot(t7,C_fix(3));
t9=(C_word)C_eqp(t4,lf[12]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10205,a[2]=t8,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10212,a[2]=t2,a[3]=t10,tmp=(C_word)a,a+=4,tmp);
/* map */
t12=*((C_word*)lf[30]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t11,((C_word*)t0)[2],t6);}
else{
t10=(C_word)C_eqp(t4,lf[10]);
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10229,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t12=(C_word)C_i_car(t6);
/* optimizer.scm: 1686 rename */
t13=((C_word*)t0)[2];
f_10171(3,t13,t11,t12);}
else{
t11=(C_word)C_eqp(t4,lf[17]);
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10242,a[2]=t8,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t13=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10253,a[2]=t2,a[3]=t12,tmp=(C_word)a,a+=4,tmp);
t14=(C_word)C_i_car(t6);
/* optimizer.scm: 1688 rename */
t15=((C_word*)t0)[2];
f_10171(3,t15,t13,t14);}
else{
t12=(C_word)C_eqp(t4,lf[14]);
if(C_truep(t12)){
t13=(C_word)C_i_car(t6);
t14=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10272,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t8,a[5]=t6,tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 1691 decompose-lambda-list */
((C_proc4)C_retrieve_symbol_proc(lf[62]))(4,*((C_word*)lf[62]+1),t1,t13,t14);}
else{
/* for-each */
t13=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t13+1)))(4,t13,t1,((C_word*)((C_word*)t0)[3])[1],t8);}}}}}

/* a10271 in walk in k10088 in k10085 in a10079 in k10069 in k10066 in a10060 in reconstruct! in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_10272(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_10272,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10287,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10291,a[2]=t4,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* map */
t7=*((C_word*)lf[30]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,((C_word*)t0)[2],t2);}

/* k10289 in a10271 in walk in k10088 in k10085 in a10079 in k10069 in k10066 in a10060 in reconstruct! in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_10291(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1694 build-lambda-list */
((C_proc5)C_retrieve_symbol_proc(lf[58]))(5,*((C_word*)lf[58]+1),((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k10285 in a10271 in walk in k10088 in k10085 in a10079 in k10069 in k10066 in a10060 in reconstruct! in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_10287(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_set_car(((C_word*)t0)[5],t1);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* optimizer.scm: 1695 walk */
t4=((C_word*)((C_word*)t0)[3])[1];
f_10186(3,t4,((C_word*)t0)[2],t3);}

/* k10251 in walk in k10088 in k10085 in a10079 in k10069 in k10066 in a10060 in reconstruct! in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_10253(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10253,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* optimizer.scm: 1688 node-parameters-set! */
((C_proc4)C_retrieve_symbol_proc(lf[115]))(4,*((C_word*)lf[115]+1),((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k10240 in walk in k10088 in k10085 in a10079 in k10069 in k10066 in a10060 in reconstruct! in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_10242(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}

/* k10227 in walk in k10088 in k10085 in a10079 in k10069 in k10066 in a10060 in reconstruct! in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_10229(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10229,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* optimizer.scm: 1686 node-parameters-set! */
((C_proc4)C_retrieve_symbol_proc(lf[115]))(4,*((C_word*)lf[115]+1),((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k10210 in walk in k10088 in k10085 in a10079 in k10069 in k10066 in a10060 in reconstruct! in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_10212(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1683 node-parameters-set! */
((C_proc4)C_retrieve_symbol_proc(lf[115]))(4,*((C_word*)lf[115]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k10203 in walk in k10088 in k10085 in a10079 in k10069 in k10066 in a10060 in reconstruct! in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_10205(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}

/* rename in k10088 in k10085 in a10079 in k10069 in k10066 in a10060 in reconstruct! in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_10171(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10171,3,t0,t1,t2);}
t3=(C_word)C_i_assq(t2,((C_word*)t0)[2]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?(C_word)C_i_cdr(t3):t2));}

/* k10091 in k10088 in k10085 in a10079 in k10069 in k10066 in a10060 in reconstruct! in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_10093(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10093,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_10142,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
/* optimizer.scm: 1660 gensym */
((C_proc3)C_retrieve_symbol_proc(lf[83]))(3,*((C_word*)lf[83]+1),t2,lf[84]);}

/* k10140 in k10091 in k10088 in k10085 in a10079 in k10069 in k10066 in a10060 in reconstruct! in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_10142(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10142,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(C_word)C_a_i_list(&a,1,((C_word*)t0)[10]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10126,a[2]=t2,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=t3,a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10130,a[2]=((C_word*)t0)[4],a[3]=t4,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 1666 append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[13]+1)))(4,*((C_word*)lf[13]+1),t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k10128 in k10140 in k10091 in k10088 in k10085 in a10079 in k10069 in k10066 in a10060 in reconstruct! in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_10130(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_length(((C_word*)t0)[5]);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],t2);
/* optimizer.scm: 1666 build-lambda-list */
((C_proc5)C_retrieve_symbol_proc(lf[58]))(5,*((C_word*)lf[58]+1),((C_word*)t0)[3],t1,t3,((C_word*)t0)[2]);}

/* k10124 in k10140 in k10091 in k10088 in k10085 in a10079 in k10069 in k10066 in a10060 in reconstruct! in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_10126(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10126,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(C_word)C_slot(((C_word*)t0)[6],C_fix(3));
t4=(C_word)C_a_i_record(&a,4,lf[37],lf[14],t2,t3);
t5=(C_word)C_a_i_list(&a,1,t4);
t6=(C_word)C_a_i_record(&a,4,lf[37],lf[17],((C_word*)t0)[5],t5);
t7=(C_word)C_a_i_list(&a,2,t6,((C_word*)t0)[4]);
t8=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_record(&a,4,lf[37],lf[12],((C_word*)t0)[2],t7));}

/* k10057 in reconstruct! in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_10059(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10059,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* optimizer.scm: 1644 node-subexpressions-set! */
((C_proc4)C_retrieve_symbol_proc(lf[113]))(4,*((C_word*)lf[113]+1),((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* compute-extra-variables in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_fcall f_9846(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9846,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9911,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10033,tmp=(C_word)a,a+=2,tmp);
/* map */
t5=*((C_word*)lf[30]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,t2);}

/* a10032 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_10033(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10033,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cadr(t2);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,t3,t4));}

/* k9909 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_9911(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9911,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9913,a[2]=t5,a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=t3,tmp=(C_word)a,a+=6,tmp));
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9988,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* for-each */
t8=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,((C_word*)t5)[1],((C_word*)t0)[4]);}

/* k9986 in k9909 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_9988(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9988,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9993,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* map */
t3=*((C_word*)lf[30]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a9992 in k9986 in k9909 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_9993(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9993,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10031,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 1633 get */
((C_proc5)C_retrieve_symbol_proc(lf[26]))(5,*((C_word*)lf[26]+1),t4,((C_word*)t0)[2],t3,lf[47]);}

/* k10029 in a9992 in k9986 in k9909 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_10031(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10031,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9853,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9855,a[2]=t6,a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_9855(3,t8,t4,t1);}

/* walk in k10029 in a9992 in k9986 in k9909 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_9855(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9855,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(1));
t5=t2;
t6=(C_word)C_slot(t5,C_fix(2));
t7=t2;
t8=(C_word)C_slot(t7,C_fix(3));
t9=(C_word)C_eqp(t4,lf[12]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9875,a[2]=t8,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 1609 append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[13]+1)))(4,*((C_word*)lf[13]+1),t10,t6,((C_word*)((C_word*)t0)[3])[1]);}
else{
t10=(C_word)C_eqp(t4,lf[14]);
if(C_truep(t10)){
t11=(C_word)C_i_car(t6);
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9893,a[2]=((C_word*)t0)[2],a[3]=t8,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1612 decompose-lambda-list */
((C_proc4)C_retrieve_symbol_proc(lf[62]))(4,*((C_word*)lf[62]+1),t1,t11,t12);}
else{
/* for-each */
t11=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t1,((C_word*)((C_word*)t0)[2])[1],t8);}}}

/* a9892 in walk in k10029 in a9992 in k9986 in k9909 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_9893(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9893,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9898,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 1615 append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[13]+1)))(4,*((C_word*)lf[13]+1),t5,t2,((C_word*)((C_word*)t0)[4])[1]);}

/* k9896 in a9892 in walk in k10029 in a9992 in k9986 in k9909 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_9898(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* optimizer.scm: 1616 walk */
t4=((C_word*)((C_word*)t0)[3])[1];
f_9855(3,t4,((C_word*)t0)[2],t3);}

/* k9873 in walk in k10029 in a9992 in k9986 in k9909 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_9875(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
/* for-each */
t3=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}

/* k9851 in k10029 in a9992 in k9986 in k9909 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_9853(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9853,2,t0,t1);}
t2=((C_word*)((C_word*)t0)[6])[1];
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10007,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10009,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10023,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* optimizer.scm: 1639 delete-duplicates */
((C_proc4)C_retrieve_symbol_proc(lf[210]))(4,*((C_word*)lf[210]+1),t5,t6,*((C_word*)lf[36]+1));}

/* k10021 in k9851 in k10029 in a9992 in k9986 in k9909 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_10023(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1635 remove */
((C_proc4)C_retrieve_symbol_proc(lf[169]))(4,*((C_word*)lf[169]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a10008 in k9851 in k10029 in a9992 in k9986 in k9909 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_10009(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10009,3,t0,t1,t2);}
t3=(C_word)C_i_assq(t2,((C_word*)t0)[3]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?t3:(C_word)C_i_memq(t2,((C_word*)t0)[2])));}

/* k10005 in k9851 in k10029 in a9992 in k9986 in k9909 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_10007(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10007,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* walk in k9909 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_9913(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9913,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9979,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],a[7]=t3,a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9981,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 1624 count */
((C_proc4)C_retrieve_symbol_proc(lf[214]))(4,*((C_word*)lf[214]+1),t4,t5,((C_word*)((C_word*)t0)[5])[1]);}

/* a9980 in walk in k9909 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_9981(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9981,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_eqp(((C_word*)t0)[2],t2));}

/* k9977 in walk in k9909 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_9979(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9979,2,t0,t1);}
if(C_truep((C_word)C_fixnum_greaterp(t1,C_fix(1)))){
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],((C_word*)((C_word*)t0)[6])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t4=(C_word)C_i_cddr(((C_word*)t0)[5]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9933,a[2]=t4,a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9967,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t7=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,t4);}}

/* a9966 in k9977 in walk in k9909 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_9967(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9967,3,t0,t1,t2);}
t3=(C_word)C_i_assq(t2,((C_word*)t0)[3]);
/* optimizer.scm: 1627 walk */
t4=((C_word*)((C_word*)t0)[2])[1];
f_9913(3,t4,t1,t3);}

/* k9931 in k9977 in walk in k9909 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_9933(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9933,2,t0,t1);}
t2=(C_word)C_i_assq(((C_word*)t0)[5],((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9943,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cdr(t2);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9951,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9955,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9957,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* map */
t8=*((C_word*)lf[30]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,t7,((C_word*)t0)[2]);}

/* a9956 in k9931 in k9977 in walk in k9909 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_9957(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9957,3,t0,t1,t2);}
t3=(C_word)C_i_assq(t2,((C_word*)t0)[2]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_cdr(t3));}

/* k9953 in k9931 in k9977 in walk in k9909 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_9955(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1629 concatenate */
((C_proc3)C_retrieve_symbol_proc(lf[213]))(3,*((C_word*)lf[213]+1),((C_word*)t0)[2],t1);}

/* k9949 in k9931 in k9977 in walk in k9909 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_9951(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1629 append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[13]+1)))(4,*((C_word*)lf[13]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k9941 in k9931 in k9977 in walk in k9909 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_9943(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_set_cdr(((C_word*)t0)[2],t1));}

/* eliminate4 in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_fcall f_9627(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9627,NULL,3,t0,t1,t2);}
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9631,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9633,a[2]=t3,a[3]=t6,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_9633(t8,t4,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* walk in eliminate4 in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_fcall f_9633(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9633,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_slot(t4,C_fix(1));
t6=t2;
t7=(C_word)C_slot(t6,C_fix(2));
t8=t2;
t9=(C_word)C_slot(t8,C_fix(3));
t10=(C_word)C_eqp(t5,lf[10]);
t11=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9652,a[2]=((C_word*)t0)[2],a[3]=t9,a[4]=t3,a[5]=t7,a[6]=((C_word*)t0)[3],a[7]=t5,a[8]=t1,tmp=(C_word)a,a+=9,tmp);
if(C_truep(t10)){
t12=t11;
f_9652(t12,t10);}
else{
t12=(C_word)C_eqp(t5,lf[27]);
if(C_truep(t12)){
t13=t11;
f_9652(t13,t12);}
else{
t13=(C_word)C_eqp(t5,lf[69]);
if(C_truep(t13)){
t14=t11;
f_9652(t14,t13);}
else{
t14=(C_word)C_eqp(t5,lf[211]);
t15=t11;
f_9652(t15,(C_truep(t14)?t14:(C_word)C_eqp(t5,lf[159])));}}}}

/* k9650 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_fcall f_9652(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9652,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[7],lf[12]);
if(C_truep(t2)){
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9663,a[2]=t4,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_9663(t6,((C_word*)t0)[8],((C_word*)t0)[5],((C_word*)t0)[3]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[7],lf[14]);
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[5]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9714,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1574 decompose-lambda-list */
((C_proc4)C_retrieve_symbol_proc(lf[62]))(4,*((C_word*)lf[62]+1),((C_word*)t0)[8],t4,t5);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[7],lf[16]);
if(C_truep(t4)){
t5=(C_word)C_i_car(((C_word*)t0)[3]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9738,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9749,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1580 call-with-current-continuation */
((C_proc3)C_retrieve_proc(*((C_word*)lf[20]+1)))(3,*((C_word*)lf[20]+1),t6,t7);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9819,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t6=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,((C_word*)t0)[8],t5,((C_word*)t0)[3]);}}}}}

/* a9818 in k9650 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_9819(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9819,3,t0,t1,t2);}
/* optimizer.scm: 1595 walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_9633(t3,t1,t2,((C_word*)t0)[2]);}

/* a9748 in k9650 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_9749(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[11],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9749,3,t0,t1,t2);}
t3=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t4=(C_word)C_eqp(lf[10],t3);
if(C_truep(t4)){
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(C_word)C_slot(((C_word*)t0)[4],C_fix(2));
t8=(C_word)C_i_car(t7);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9765,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t10,a[5]=((C_word*)t0)[3],a[6]=t6,tmp=(C_word)a,a+=7,tmp));
t12=((C_word*)t10)[1];
f_9765(3,t12,t1,t8);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}}

/* loop in a9748 in k9650 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_9765(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[14],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9765,3,t0,t1,t2);}
if(C_truep((C_word)C_i_memq(t2,((C_word*)((C_word*)t0)[6])[1]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[6])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t3);
t5=(C_word)C_i_assq(t2,((C_word*)((C_word*)t0)[5])[1]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9785,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9795,a[2]=t5,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=t6,tmp=(C_word)a,a+=6,tmp);
t8=(C_word)C_i_cadr(t5);
/* optimizer.scm: 1589 lset<= */
((C_proc5)C_retrieve_symbol_proc(lf[127]))(5,*((C_word*)lf[127]+1),t7,*((C_word*)lf[36]+1),t8,((C_word*)t0)[2]);}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}}}

/* k9793 in loop in a9748 in k9650 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_9795(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9795,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
f_9785(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9799,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1591 delete! */
((C_proc5)C_retrieve_symbol_proc(lf[212]))(5,*((C_word*)lf[212]+1),t2,((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1],*((C_word*)lf[36]+1));}}

/* k9797 in k9793 in loop in a9748 in k9650 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_9799(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
/* optimizer.scm: 1592 return */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k9783 in loop in a9748 in k9650 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_9785(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cddr(((C_word*)t0)[4]);
/* for-each */
t3=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t2);}

/* k9736 in k9650 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_9738(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9738,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9743,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t3=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a9742 in k9736 in k9650 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_9743(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9743,3,t0,t1,t2);}
/* optimizer.scm: 1594 walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_9633(t3,t1,t2,((C_word*)t0)[2]);}

/* a9713 in k9650 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_9714(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9714,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_car(((C_word*)t0)[4]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9726,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1577 append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[13]+1)))(4,*((C_word*)lf[13]+1),t6,t2,((C_word*)t0)[2]);}

/* k9724 in a9713 in k9650 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_9726(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1577 walk */
t2=((C_word*)((C_word*)t0)[4])[1];
f_9633(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* loop in k9650 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_fcall f_9663(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9663,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(C_word)C_i_car(t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9681,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1569 append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[13]+1)))(4,*((C_word*)lf[13]+1),t5,((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9684,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(t3);
/* optimizer.scm: 1571 walk */
t6=((C_word*)((C_word*)t0)[5])[1];
f_9633(t6,t4,t5,((C_word*)t0)[3]);}}

/* k9682 in loop in k9650 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_9684(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* optimizer.scm: 1572 loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_9663(t4,((C_word*)t0)[2],t2,t3);}

/* k9679 in loop in k9650 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_9681(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1569 walk */
t2=((C_word*)((C_word*)t0)[4])[1];
f_9633(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k9629 in eliminate4 in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_9631(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* collect-accessibles in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_fcall f_9383(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9383,NULL,3,t0,t1,t2);}
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9387,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9389,a[2]=t4,a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t7,tmp=(C_word)a,a+=6,tmp));
t9=((C_word*)t7)[1];
f_9389(t9,t5,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_fcall f_9389(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9389,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_slot(t4,C_fix(1));
t6=t2;
t7=(C_word)C_slot(t6,C_fix(2));
t8=t2;
t9=(C_word)C_slot(t8,C_fix(3));
t10=(C_word)C_eqp(t5,lf[10]);
t11=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_9408,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=t9,a[7]=t3,a[8]=t7,a[9]=((C_word*)t0)[5],a[10]=t5,a[11]=t1,tmp=(C_word)a,a+=12,tmp);
if(C_truep(t10)){
t12=t11;
f_9408(t12,t10);}
else{
t12=(C_word)C_eqp(t5,lf[27]);
if(C_truep(t12)){
t13=t11;
f_9408(t13,t12);}
else{
t13=(C_word)C_eqp(t5,lf[69]);
if(C_truep(t13)){
t14=t11;
f_9408(t14,t13);}
else{
t14=(C_word)C_eqp(t5,lf[211]);
t15=t11;
f_9408(t15,(C_truep(t14)?t14:(C_word)C_eqp(t5,lf[159])));}}}}

/* k9406 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_fcall f_9408(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9408,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[11];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[10],lf[12]);
if(C_truep(t2)){
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9419,a[2]=t4,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_9419(t6,((C_word*)t0)[11],((C_word*)t0)[8],((C_word*)t0)[6]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[10],lf[14]);
if(C_truep(t3)){
t4=(C_word)C_i_assq(((C_word*)t0)[5],((C_word*)((C_word*)t0)[4])[1]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9467,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t4)){
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_assq(t6,((C_word*)t0)[3]))){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9501,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t8=(C_word)C_i_cdr(t4);
/* optimizer.scm: 1526 alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[28]))(5,*((C_word*)lf[28]+1),t7,t8,((C_word*)t0)[7],((C_word*)((C_word*)t0)[2])[1]);}
else{
t7=t5;
f_9467(t7,C_SCHEME_UNDEFINED);}}
else{
t6=t5;
f_9467(t6,C_SCHEME_UNDEFINED);}}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9510,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t5=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,((C_word*)t0)[11],t4,((C_word*)t0)[6]);}}}}

/* a9509 in k9406 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_9510(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9510,3,t0,t1,t2);}
/* optimizer.scm: 1532 walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_9389(t3,t1,t2,((C_word*)t0)[2]);}

/* k9499 in k9406 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_9501(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_9467(t3,t2);}

/* k9465 in k9406 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_fcall f_9467(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9467,NULL,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9476,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1527 decompose-lambda-list */
((C_proc4)C_retrieve_symbol_proc(lf[62]))(4,*((C_word*)lf[62]+1),((C_word*)t0)[2],t2,t3);}

/* a9475 in k9465 in k9406 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_9476(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9476,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_car(((C_word*)t0)[4]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9488,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1530 append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[13]+1)))(4,*((C_word*)lf[13]+1),t6,t2,((C_word*)t0)[2]);}

/* k9486 in a9475 in k9465 in k9406 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_9488(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1530 walk */
t2=((C_word*)((C_word*)t0)[4])[1];
f_9389(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* loop in k9406 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_fcall f_9419(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9419,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(C_word)C_i_car(t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9437,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1517 append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[13]+1)))(4,*((C_word*)lf[13]+1),t5,((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9440,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(t3);
/* optimizer.scm: 1519 walk */
t6=((C_word*)((C_word*)t0)[5])[1];
f_9389(t6,t4,t5,((C_word*)t0)[3]);}}

/* k9438 in loop in k9406 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_9440(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* optimizer.scm: 1520 loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_9419(t4,((C_word*)t0)[2],t2,t3);}

/* k9435 in loop in k9406 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_9437(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1517 walk */
t2=((C_word*)((C_word*)t0)[4])[1];
f_9389(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k9385 in collect-accessibles in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_9387(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* eliminate in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_fcall f_9284(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9284,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9290,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1487 remove */
((C_proc4)C_retrieve_symbol_proc(lf[169]))(4,*((C_word*)lf[169]+1),t1,t4,t3);}

/* a9289 in eliminate in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_9290(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9290,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9324,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_i_car(t2);
t5=((C_word*)t0)[2];
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9334,a[2]=t4,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1497 unzip1 */
((C_proc3)C_retrieve_symbol_proc(lf[197]))(3,*((C_word*)lf[197]+1),t6,t5);}

/* k9332 in a9289 in eliminate in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_9334(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9334,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9339,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_9339(t5,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* count in k9332 in a9289 in eliminate in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_fcall f_9339(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9339,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_assq(t2,((C_word*)t0)[4]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9346,a[2]=t4,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t6=(C_word)C_i_cddr(t4);
/* optimizer.scm: 1500 lset-difference */
((C_proc6)C_retrieve_symbol_proc(lf[183]))(6,*((C_word*)lf[183]+1),t5,*((C_word*)lf[36]+1),t6,t3,((C_word*)t0)[2]);}

/* k9344 in count in k9332 in a9289 in eliminate in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_9346(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9346,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9373,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[2]);
/* optimizer.scm: 1501 delete-duplicates */
((C_proc4)C_retrieve_symbol_proc(lf[210]))(4,*((C_word*)lf[210]+1),t2,t3,*((C_word*)lf[36]+1));}

/* k9371 in k9344 in count in k9332 in a9289 in eliminate in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_9373(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9373,2,t0,t1);}
t2=(C_word)C_i_length(t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9369,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 1502 append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[13]+1)))(4,*((C_word*)lf[13]+1),t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9367 in k9371 in k9344 in count in k9332 in a9289 in eliminate in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_9369(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9369,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9359,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9361,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* map */
t5=*((C_word*)lf[30]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a9360 in k9367 in k9371 in k9344 in count in k9332 in a9289 in eliminate in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_9361(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9361,3,t0,t1,t2);}
/* optimizer.scm: 1503 count */
t3=((C_word*)((C_word*)t0)[3])[1];
f_9339(t3,t1,t2,((C_word*)t0)[2]);}

/* k9357 in k9367 in k9371 in k9344 in count in k9332 in a9289 in eliminate in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_9359(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1503 fold */
((C_proc5)C_retrieve_symbol_proc(lf[125]))(5,*((C_word*)lf[125]+1),((C_word*)t0)[3],*((C_word*)lf[209]+1),((C_word*)t0)[2],t1);}

/* k9322 in a9289 in eliminate in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_9324(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9324,2,t0,t1);}
t2=(C_word)C_fixnum_greaterp(t1,C_fix(16));
if(C_truep(t2)){
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9302,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cadr(((C_word*)t0)[2]);
/* optimizer.scm: 1490 any */
((C_proc4)C_retrieve_symbol_proc(lf[32]))(4,*((C_word*)lf[32]+1),((C_word*)t0)[5],t3,t4);}}

/* a9301 in k9322 in a9289 in eliminate in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_9302(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9302,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9309,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1491 get */
((C_proc5)C_retrieve_symbol_proc(lf[26]))(5,*((C_word*)lf[26]+1),t3,((C_word*)t0)[2],t2,lf[74]);}

/* k9307 in a9301 in k9322 in a9289 in eliminate in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_9309(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_assq(((C_word*)t0)[4],((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_not(t2));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* build-call-graph in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_fcall f_9087(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9087,NULL,3,t0,t1,t2);}
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_END_OF_LIST;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9090,a[2]=((C_word*)t0)[2],a[3]=t6,a[4]=t8,a[5]=t2,a[6]=t10,tmp=(C_word)a,a+=7,tmp));
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9239,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t13=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9241,a[2]=t10,a[3]=t4,a[4]=t8,a[5]=t6,tmp=(C_word)a,a+=6,tmp);
/* for-each */
t14=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t14+1)))(4,t14,t12,t13,t2);}

/* a9240 in build-call-graph in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_9241(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[11],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9241,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=(C_word)C_slot(t4,C_fix(2));
t6=(C_word)C_i_car(t5);
t7=C_set_block_item(((C_word*)t0)[5],0,C_SCHEME_END_OF_LIST);
t8=C_set_block_item(((C_word*)t0)[4],0,C_SCHEME_END_OF_LIST);
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9256,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9266,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1476 decompose-lambda-list */
((C_proc4)C_retrieve_symbol_proc(lf[62]))(4,*((C_word*)lf[62]+1),t9,t6,t10);}

/* a9265 in a9240 in build-call-graph in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_9266(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9266,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_slot(((C_word*)t0)[3],C_fix(3));
t6=(C_word)C_i_car(t5);
/* optimizer.scm: 1479 walk */
t7=((C_word*)((C_word*)t0)[2])[1];
f_9090(t7,t1,t6,t2);}

/* k9254 in a9240 in build-call-graph in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_9256(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9256,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9260,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[4])[1],((C_word*)((C_word*)t0)[3])[1]);
/* optimizer.scm: 1480 alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[28]))(5,*((C_word*)lf[28]+1),t2,((C_word*)t0)[2],t3,((C_word*)((C_word*)t0)[6])[1]);}

/* k9258 in k9254 in a9240 in build-call-graph in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_9260(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k9237 in build-call-graph in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_9239(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* walk in build-call-graph in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_fcall f_9090(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9090,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_slot(t4,C_fix(1));
t6=t2;
t7=(C_word)C_slot(t6,C_fix(2));
t8=t2;
t9=(C_word)C_slot(t8,C_fix(3));
t10=(C_word)C_eqp(t5,lf[10]);
t11=(C_truep(t10)?t10:(C_word)C_eqp(t5,lf[17]));
if(C_truep(t11)){
t12=(C_word)C_i_car(t7);
t13=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9115,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t12,a[5]=t9,a[6]=t1,a[7]=t3,a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
t14=(C_word)C_i_memq(t12,t3);
t15=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9140,a[2]=((C_word*)t0)[3],a[3]=t12,a[4]=t13,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t14)){
t16=t15;
f_9140(2,t16,t14);}
else{
/* optimizer.scm: 1452 get */
((C_proc5)C_retrieve_symbol_proc(lf[26]))(5,*((C_word*)lf[26]+1),t15,((C_word*)t0)[2],t12,lf[101]);}}
else{
t12=(C_word)C_eqp(t5,lf[12]);
if(C_truep(t12)){
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_set_block_item(t14,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9158,a[2]=t14,a[3]=t3,a[4]=t7,a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp));
t16=((C_word*)t14)[1];
f_9158(t16,t1,t7,t9);}
else{
t13=(C_word)C_eqp(t5,lf[14]);
if(C_truep(t13)){
t14=(C_word)C_i_car(t7);
t15=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9212,a[2]=t3,a[3]=((C_word*)t0)[6],a[4]=t9,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1464 decompose-lambda-list */
((C_proc4)C_retrieve_symbol_proc(lf[62]))(4,*((C_word*)lf[62]+1),t1,t14,t15);}
else{
t14=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9229,a[2]=t3,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t15=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t1,t14,t9);}}}}

/* a9228 in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_9229(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9229,3,t0,t1,t2);}
/* optimizer.scm: 1467 walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_9090(t3,t1,t2,((C_word*)t0)[2]);}

/* a9211 in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_9212(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9212,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_car(((C_word*)t0)[4]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9224,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1466 append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[13]+1)))(4,*((C_word*)lf[13]+1),t6,t2,((C_word*)t0)[2]);}

/* k9222 in a9211 in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_9224(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1466 walk */
t2=((C_word*)((C_word*)t0)[4])[1];
f_9090(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* loop in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_fcall f_9158(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9158,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(C_word)C_i_car(t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9176,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1459 append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[13]+1)))(4,*((C_word*)lf[13]+1),t5,((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9182,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_i_car(t3);
/* optimizer.scm: 1461 walk */
t7=((C_word*)((C_word*)t0)[5])[1];
f_9090(t7,t5,t6,((C_word*)t0)[3]);}}

/* k9180 in loop in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_9182(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* optimizer.scm: 1462 loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_9158(t4,((C_word*)t0)[2],t2,t3);}

/* k9174 in loop in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_9176(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1459 walk */
t2=((C_word*)((C_word*)t0)[4])[1];
f_9090(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k9138 in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_9140(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9140,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_9115(t2,C_SCHEME_UNDEFINED);}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=((C_word*)t0)[4];
f_9115(t4,t3);}}

/* k9113 in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_fcall f_9115(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9115,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9118,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_assq(((C_word*)t0)[4],((C_word*)t0)[3]))){
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[2])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t3);
t5=t2;
f_9118(t5,t4);}
else{
t3=t2;
f_9118(t3,C_SCHEME_UNDEFINED);}}

/* k9116 in k9113 in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_fcall f_9118(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9118,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9123,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t3=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a9122 in k9116 in k9113 in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_9123(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9123,3,t0,t1,t2);}
/* optimizer.scm: 1455 walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_9090(t3,t1,t2,((C_word*)t0)[2]);}

/* find-lifting-candidates in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_fcall f_8987(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8987,NULL,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8991,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8993,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1423 ##sys#hash-table-for-each */
((C_proc4)C_retrieve_symbol_proc(lf[208]))(4,*((C_word*)lf[208]+1),t4,t5,((C_word*)t0)[2]);}

/* a8992 in find-lifting-candidates in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_8993(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8993,4,t0,t1,t2,t3);}
t4=(C_word)C_i_assq(lf[47],t3);
if(C_truep(t4)){
t5=(C_word)C_i_assq(lf[75],t3);
if(C_truep(t5)){
t6=(C_word)C_i_assq(lf[118],t3);
if(C_truep(t6)){
t7=(C_word)C_i_cdr(t5);
t8=(C_word)C_i_length(t7);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9024,a[2]=t2,a[3]=t4,a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_assq(lf[76],t3))){
t10=t9;
f_9024(t10,C_SCHEME_FALSE);}
else{
t10=(C_word)C_i_cdr(t4);
t11=(C_word)C_slot(t10,C_fix(1));
t12=(C_word)C_eqp(lf[14],t11);
if(C_truep(t12)){
if(C_truep((C_word)C_i_assq(lf[101],t3))){
t13=t9;
f_9024(t13,C_SCHEME_FALSE);}
else{
t13=(C_word)C_i_cdr(t6);
t14=(C_word)C_i_length(t13);
t15=t9;
f_9024(t15,(C_word)C_eqp(t8,t14));}}
else{
t13=t9;
f_9024(t13,C_SCHEME_FALSE);}}}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}}
else{
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_SCHEME_FALSE);}}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}

/* k9022 in a8992 in find-lifting-candidates in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_fcall f_9024(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9024,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9028,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* optimizer.scm: 1434 alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[28]))(5,*((C_word*)lf[28]+1),t2,t3,((C_word*)t0)[2],((C_word*)((C_word*)t0)[6])[1]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k9026 in k9022 in a8992 in find-lifting-candidates in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_9028(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9028,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[6])+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9032,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* optimizer.scm: 1435 alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[28]))(5,*((C_word*)lf[28]+1),t3,((C_word*)t0)[2],t4,((C_word*)((C_word*)t0)[5])[1]);}

/* k9030 in k9026 in k9022 in a8992 in find-lifting-candidates in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_9032(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k8989 in find-lifting-candidates in ##compiler#perform-lambda-lifting! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_8991(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* ##compiler#transform-direct-lambdas! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_7889(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[35],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7889,4,t0,t1,t2,t3);}
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_END_OF_LIST;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_END_OF_LIST;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_fix(0);
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8473,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t13=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8054,a[2]=t7,a[3]=t9,a[4]=t3,a[5]=t11,tmp=(C_word)a,a+=6,tmp);
t14=C_SCHEME_UNDEFINED;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_set_block_item(t15,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7892,a[2]=t3,a[3]=t13,a[4]=t15,a[5]=t11,a[6]=t9,a[7]=t7,a[8]=t12,tmp=(C_word)a,a+=9,tmp));
t17=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8979,a[2]=t2,a[3]=t15,a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 1402 debugging */
((C_proc4)C_retrieve_symbol_proc(lf[7]))(4,*((C_word*)lf[7]+1),t17,lf[21],lf[206]);}

/* k8977 in ##compiler#transform-direct-lambdas! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_8979(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8979,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8982,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1403 walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_7892(t3,t2,C_SCHEME_FALSE,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k8980 in k8977 in ##compiler#transform-direct-lambdas! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_8982(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* walk in ##compiler#transform-direct-lambdas! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_fcall f_7892(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word *a;
loop:
a=C_alloc(22);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_7892,NULL,5,t0,t1,t2,t3,t4);}
t5=t3;
t6=(C_word)C_slot(t5,C_fix(2));
t7=t3;
t8=(C_word)C_slot(t7,C_fix(3));
t9=t3;
t10=(C_word)C_slot(t9,C_fix(1));
t11=(C_word)C_eqp(t10,lf[55]);
if(C_truep(t11)){
t12=(C_word)C_i_caddr(t6);
t13=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_7917,a[2]=((C_word*)t0)[4],a[3]=t8,a[4]=((C_word*)t0)[5],a[5]=t4,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t2,a[9]=t3,a[10]=t1,a[11]=((C_word*)t0)[8],tmp=(C_word)a,a+=12,tmp);
if(C_truep(t2)){
if(C_truep((C_word)C_i_cadr(t6))){
t14=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8002,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=t8,a[7]=t3,a[8]=t12,a[9]=t13,tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm: 1194 get */
((C_proc5)C_retrieve_symbol_proc(lf[26]))(5,*((C_word*)lf[26]+1),t14,((C_word*)t0)[2],t2,lf[76]);}
else{
t14=t13;
f_7917(2,t14,C_SCHEME_FALSE);}}
else{
t14=t13;
f_7917(2,t14,C_SCHEME_FALSE);}}
else{
t12=(C_word)C_eqp(t10,lf[17]);
if(C_truep(t12)){
t13=(C_word)C_i_car(t6);
t14=(C_word)C_i_car(t8);
/* optimizer.scm: 1204 walk */
t24=t1;
t25=t13;
t26=t14;
t27=C_SCHEME_FALSE;
t1=t24;
t2=t25;
t3=t26;
t4=t27;
goto loop;}
else{
t13=(C_word)C_eqp(t10,lf[12]);
if(C_truep(t13)){
t14=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8028,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t8,tmp=(C_word)a,a+=5,tmp);
t15=(C_word)C_i_car(t6);
t16=(C_word)C_i_car(t8);
/* optimizer.scm: 1206 walk */
t24=t14;
t25=t15;
t26=t16;
t27=t3;
t1=t24;
t2=t25;
t3=t26;
t4=t27;
goto loop;}
else{
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8048,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* for-each */
t15=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t1,t14,t8);}}}}

/* a8047 in walk in ##compiler#transform-direct-lambdas! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_8048(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8048,3,t0,t1,t2);}
/* optimizer.scm: 1208 walk */
t3=((C_word*)((C_word*)t0)[2])[1];
f_7892(t3,t1,C_SCHEME_FALSE,t2,C_SCHEME_FALSE);}

/* k8026 in walk in ##compiler#transform-direct-lambdas! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_8028(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* optimizer.scm: 1207 walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_7892(t3,((C_word*)t0)[2],C_SCHEME_FALSE,t2,C_SCHEME_FALSE);}

/* k8000 in walk in ##compiler#transform-direct-lambdas! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_8002(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8002,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[9];
f_7917(2,t2,C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_i_listp(((C_word*)t0)[8]))){
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7948,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm: 1196 get */
((C_proc5)C_retrieve_symbol_proc(lf[26]))(5,*((C_word*)lf[26]+1),t2,((C_word*)t0)[2],((C_word*)t0)[5],lf[47]);}
else{
t2=((C_word*)t0)[9];
f_7917(2,t2,C_SCHEME_FALSE);}}}

/* k7946 in k8000 in walk in ##compiler#transform-direct-lambdas! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_7948(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7948,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7954,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* optimizer.scm: 1197 get */
((C_proc5)C_retrieve_symbol_proc(lf[26]))(5,*((C_word*)lf[26]+1),t2,((C_word*)t0)[2],((C_word*)t0)[6],lf[75]);}
else{
t2=((C_word*)t0)[4];
f_7917(2,t2,C_SCHEME_FALSE);}}

/* k7952 in k7946 in k8000 in walk in ##compiler#transform-direct-lambdas! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_7954(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7954,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7960,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t1,a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
/* optimizer.scm: 1198 get */
((C_proc5)C_retrieve_symbol_proc(lf[26]))(5,*((C_word*)lf[26]+1),t2,((C_word*)t0)[2],((C_word*)t0)[6],lf[118]);}
else{
t2=((C_word*)t0)[4];
f_7917(2,t2,C_SCHEME_FALSE);}}

/* k7958 in k7952 in k7946 in k8000 in walk in ##compiler#transform-direct-lambdas! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_7960(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7960,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_eqp(((C_word*)t0)[10],((C_word*)t0)[9]);
if(C_truep(t2)){
t3=(C_word)C_i_length(((C_word*)t0)[8]);
t4=(C_word)C_i_length(t1);
t5=(C_word)C_eqp(t3,t4);
if(C_truep(t5)){
t6=(C_word)C_i_car(((C_word*)t0)[7]);
t7=(C_word)C_i_car(((C_word*)t0)[6]);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[6]);
/* optimizer.scm: 1201 scan */
t9=((C_word*)t0)[4];
f_8054(t9,((C_word*)t0)[3],t6,t7,((C_word*)t0)[5],((C_word*)t0)[2],t8);}
else{
t6=((C_word*)t0)[3];
f_7917(2,t6,C_SCHEME_FALSE);}}
else{
t3=((C_word*)t0)[3];
f_7917(2,t3,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[3];
f_7917(2,t2,C_SCHEME_FALSE);}}

/* k7915 in walk in ##compiler#transform-direct-lambdas! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_7917(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
/* optimizer.scm: 1202 transform */
t2=((C_word*)t0)[11];
f_8473(t2,((C_word*)t0)[10],((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)((C_word*)t0)[7])[1],((C_word*)((C_word*)t0)[6])[1],((C_word*)t0)[5],((C_word*)((C_word*)t0)[4])[1]);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[3]);
/* optimizer.scm: 1203 walk */
t3=((C_word*)((C_word*)t0)[2])[1];
f_7892(t3,((C_word*)t0)[10],C_SCHEME_FALSE,t2,C_SCHEME_FALSE);}}

/* scan in ##compiler#transform-direct-lambdas! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_fcall f_8054(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8054,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=C_SCHEME_END_OF_LIST;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_FALSE;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_8057,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t4,a[5]=((C_word*)t0)[3],a[6]=t5,a[7]=t12,a[8]=t8,a[9]=((C_word*)t0)[4],a[10]=((C_word*)t0)[5],a[11]=t10,a[12]=t6,tmp=(C_word)a,a+=13,tmp));
t14=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_END_OF_LIST);
t15=C_set_block_item(((C_word*)t0)[3],0,C_SCHEME_END_OF_LIST);
t16=C_set_block_item(((C_word*)t0)[5],0,C_fix(0));
t17=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8464,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t8,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 1287 rec */
t18=((C_word*)t12)[1];
f_8057(t18,t17,t2,C_SCHEME_FALSE,C_SCHEME_FALSE,t6);}

/* k8462 in scan in ##compiler#transform-direct-lambdas! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_8464(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8464,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8471,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1288 delete */
((C_proc5)C_retrieve_symbol_proc(lf[205]))(5,*((C_word*)lf[205]+1),t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],*((C_word*)lf[36]+1));}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k8469 in k8462 in scan in ##compiler#transform-direct-lambdas! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_8471(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1288 lset= */
((C_proc5)C_retrieve_symbol_proc(lf[204]))(5,*((C_word*)lf[204]+1),((C_word*)t0)[3],*((C_word*)lf[36]+1),((C_word*)((C_word*)t0)[2])[1],t1);}

/* rec in scan in ##compiler#transform-direct-lambdas! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_fcall f_8057(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word *a;
loop:
a=C_alloc(13);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_8057,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=t2;
t7=(C_word)C_slot(t6,C_fix(2));
t8=t2;
t9=(C_word)C_slot(t8,C_fix(3));
t10=t2;
t11=(C_word)C_slot(t10,C_fix(1));
t12=(C_word)C_eqp(t11,lf[10]);
if(C_truep(t12)){
t13=(C_word)C_i_car(t7);
t14=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8106,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[12],a[5]=t13,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 1219 get */
((C_proc5)C_retrieve_symbol_proc(lf[26]))(5,*((C_word*)lf[26]+1),t14,((C_word*)t0)[9],t13,lf[200]);}
else{
t13=(C_word)C_eqp(t11,lf[55]);
if(C_truep(t13)){
if(C_truep(t3)){
t14=(C_word)C_i_caddr(t7);
t15=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8124,a[2]=t5,a[3]=((C_word*)t0)[7],a[4]=t9,a[5]=((C_word*)t0)[8],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 1227 decompose-lambda-list */
((C_proc4)C_retrieve_symbol_proc(lf[62]))(4,*((C_word*)lf[62]+1),t1,t14,t15);}
else{
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,C_SCHEME_FALSE);}}
else{
t14=(C_word)C_eqp(t11,lf[88]);
if(C_truep(t14)){
t15=((C_word*)((C_word*)t0)[11])[1];
if(C_truep(t15)){
t16=t1;
((C_proc2)(void*)(*((C_word*)t16+1)))(2,t16,C_SCHEME_FALSE);}
else{
t16=(C_word)C_i_cadr(t7);
t17=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[10])[1],t16);
t18=C_mutate(((C_word *)((C_word*)t0)[10])+1,t17);
t19=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8161,a[2]=t5,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1236 every */
((C_proc4)C_retrieve_symbol_proc(lf[43]))(4,*((C_word*)lf[43]+1),t1,t19,t9);}}
else{
t15=(C_word)C_eqp(t11,lf[192]);
if(C_truep(t15)){
if(C_truep(t4)){
if(C_truep(((C_word*)t0)[6])){
t16=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8195,a[2]=t4,a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t17=(C_word)C_i_car(t9);
/* optimizer.scm: 1239 scan-used-variables */
((C_proc4)C_retrieve_symbol_proc(lf[131]))(4,*((C_word*)lf[131]+1),t16,t17,t5);}
else{
t16=t1;
((C_proc2)(void*)(*((C_word*)t16+1)))(2,t16,C_SCHEME_FALSE);}}
else{
t16=t1;
((C_proc2)(void*)(*((C_word*)t16+1)))(2,t16,C_SCHEME_FALSE);}}
else{
t16=(C_word)C_eqp(t11,lf[201]);
if(C_truep(t16)){
t17=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8211,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],a[4]=t9,a[5]=t1,a[6]=t5,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t18=(C_word)C_i_cadr(t7);
/* optimizer.scm: 1244 estimate-foreign-result-size */
((C_proc3)C_retrieve_symbol_proc(lf[202]))(3,*((C_word*)lf[202]+1),t17,t18);}
else{
t17=(C_word)C_eqp(t11,lf[203]);
if(C_truep(t17)){
t18=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8252,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],a[4]=t9,a[5]=t1,a[6]=t5,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t19=(C_word)C_i_car(t7);
/* optimizer.scm: 1252 estimate-foreign-result-size */
((C_proc3)C_retrieve_symbol_proc(lf[202]))(3,*((C_word*)lf[202]+1),t18,t19);}
else{
t18=(C_word)C_eqp(t11,lf[16]);
if(C_truep(t18)){
t19=(C_word)C_i_car(t9);
t20=(C_word)C_slot(t19,C_fix(1));
t21=(C_word)C_eqp(lf[10],t20);
if(C_truep(t21)){
t22=(C_word)C_slot(t19,C_fix(2));
t23=(C_word)C_i_car(t22);
t24=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8305,a[2]=t1,a[3]=t9,a[4]=t5,a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t25=(C_word)C_eqp(t23,((C_word*)t0)[4]);
if(C_truep(t25)){
t26=(C_word)C_eqp(((C_word*)((C_word*)t0)[10])[1],C_fix(0));
if(C_truep(t26)){
t27=(C_word)C_i_cadr(t9);
t28=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8333,a[2]=t24,a[3]=((C_word*)t0)[11],tmp=(C_word)a,a+=4,tmp);
t29=(C_word)C_slot(t27,C_fix(1));
t30=(C_word)C_eqp(lf[10],t29);
if(C_truep(t30)){
t31=(C_word)C_slot(t27,C_fix(2));
t32=(C_word)C_i_car(t31);
t33=(C_word)C_a_i_cons(&a,2,t32,((C_word*)((C_word*)t0)[3])[1]);
t34=C_mutate(((C_word *)((C_word*)t0)[3])+1,t33);
t35=t28;
f_8333(t35,t34);}
else{
t31=t28;
f_8333(t31,C_SCHEME_UNDEFINED);}}
else{
t27=t24;
f_8305(t27,C_SCHEME_FALSE);}}
else{
t26=t24;
f_8305(t26,(C_word)C_eqp(t23,((C_word*)t0)[2]));}}
else{
t22=t1;
((C_proc2)(void*)(*((C_word*)t22+1)))(2,t22,C_SCHEME_FALSE);}}
else{
t19=(C_word)C_eqp(t11,lf[180]);
if(C_truep(t19)){
t20=(C_word)C_i_cadddr(t7);
t21=(C_word)C_eqp(t20,C_fix(0));
if(C_truep(t21)){
t22=t1;
((C_proc2)(void*)(*((C_word*)t22+1)))(2,t22,t21);}
else{
t22=((C_word*)((C_word*)t0)[11])[1];
if(C_truep(t22)){
t23=t1;
((C_proc2)(void*)(*((C_word*)t23+1)))(2,t23,C_SCHEME_FALSE);}
else{
t23=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[10])[1],t20);
t24=C_mutate(((C_word *)((C_word*)t0)[10])+1,t23);
t25=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8394,a[2]=t5,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1278 every */
((C_proc4)C_retrieve_symbol_proc(lf[43]))(4,*((C_word*)lf[43]+1),t1,t25,t9);}}}
else{
t20=(C_word)C_eqp(t11,lf[17]);
if(C_truep(t20)){
t21=(C_word)C_i_car(t9);
t22=(C_word)C_i_car(t7);
/* optimizer.scm: 1279 rec */
t66=t1;
t67=t21;
t68=t22;
t69=C_SCHEME_FALSE;
t70=t5;
t1=t66;
t2=t67;
t3=t68;
t4=t69;
t5=t70;
goto loop;}
else{
t21=(C_word)C_eqp(t11,lf[12]);
if(C_truep(t21)){
t22=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8427,a[2]=t5,a[3]=t7,a[4]=t1,a[5]=((C_word*)t0)[7],a[6]=t9,tmp=(C_word)a,a+=7,tmp);
t23=(C_word)C_i_car(t9);
t24=(C_word)C_i_car(t7);
/* optimizer.scm: 1281 rec */
t66=t22;
t67=t23;
t68=t24;
t69=t2;
t70=t5;
t1=t66;
t2=t67;
t3=t68;
t4=t69;
t5=t70;
goto loop;}
else{
t22=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8451,a[2]=t5,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1283 every */
((C_proc4)C_retrieve_symbol_proc(lf[43]))(4,*((C_word*)lf[43]+1),t1,t22,t9);}}}}}}}}}}}

/* a8450 in rec in scan in ##compiler#transform-direct-lambdas! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_8451(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8451,3,t0,t1,t2);}
/* optimizer.scm: 1283 rec */
t3=((C_word*)((C_word*)t0)[3])[1];
f_8057(t3,t1,t2,C_SCHEME_FALSE,C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* k8425 in rec in scan in ##compiler#transform-direct-lambdas! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_8427(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8427,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8438,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1282 append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[13]+1)))(4,*((C_word*)lf[13]+1),t3,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k8436 in k8425 in rec in scan in ##compiler#transform-direct-lambdas! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_8438(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1282 rec */
t2=((C_word*)((C_word*)t0)[4])[1];
f_8057(t2,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE,C_SCHEME_FALSE,t1);}

/* a8393 in rec in scan in ##compiler#transform-direct-lambdas! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_8394(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8394,3,t0,t1,t2);}
/* optimizer.scm: 1278 rec */
t3=((C_word*)((C_word*)t0)[3])[1];
f_8057(t3,t1,t2,C_SCHEME_FALSE,C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* k8331 in rec in scan in ##compiler#transform-direct-lambdas! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_fcall f_8333(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_set_block_item(((C_word*)t0)[3],0,C_SCHEME_TRUE);
t3=((C_word*)t0)[2];
f_8305(t3,C_SCHEME_TRUE);}

/* k8303 in rec in scan in ##compiler#transform-direct-lambdas! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_fcall f_8305(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8305,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8310,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* optimizer.scm: 1271 every */
((C_proc4)C_retrieve_symbol_proc(lf[43]))(4,*((C_word*)lf[43]+1),((C_word*)t0)[2],t2,t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a8309 in k8303 in rec in scan in ##compiler#transform-direct-lambdas! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_8310(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8310,3,t0,t1,t2);}
/* optimizer.scm: 1271 rec */
t3=((C_word*)((C_word*)t0)[3])[1];
f_8057(t3,t1,t2,C_SCHEME_FALSE,C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* k8250 in rec in scan in ##compiler#transform-direct-lambdas! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_8252(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8252,2,t0,t1);}
t2=(C_word)C_eqp(t1,C_fix(0));
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8258,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t4=t3;
f_8258(t4,t2);}
else{
t4=((C_word*)((C_word*)t0)[3])[1];
if(C_truep(t4)){
t5=t3;
f_8258(t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[2])[1],t1);
t6=C_mutate(((C_word *)((C_word*)t0)[2])+1,t5);
t7=t3;
f_8258(t7,C_SCHEME_TRUE);}}}

/* k8256 in k8250 in rec in scan in ##compiler#transform-direct-lambdas! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_fcall f_8258(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8258,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8263,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1258 every */
((C_proc4)C_retrieve_symbol_proc(lf[43]))(4,*((C_word*)lf[43]+1),((C_word*)t0)[3],t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a8262 in k8256 in k8250 in rec in scan in ##compiler#transform-direct-lambdas! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_8263(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8263,3,t0,t1,t2);}
/* optimizer.scm: 1258 rec */
t3=((C_word*)((C_word*)t0)[3])[1];
f_8057(t3,t1,t2,C_SCHEME_FALSE,C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* k8209 in rec in scan in ##compiler#transform-direct-lambdas! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_8211(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8211,2,t0,t1);}
t2=(C_word)C_eqp(t1,C_fix(0));
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8217,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t4=t3;
f_8217(t4,t2);}
else{
t4=((C_word*)((C_word*)t0)[3])[1];
if(C_truep(t4)){
t5=t3;
f_8217(t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[2])[1],t1);
t6=C_mutate(((C_word *)((C_word*)t0)[2])+1,t5);
t7=t3;
f_8217(t7,C_SCHEME_TRUE);}}}

/* k8215 in k8209 in rec in scan in ##compiler#transform-direct-lambdas! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_fcall f_8217(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8217,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8222,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1250 every */
((C_proc4)C_retrieve_symbol_proc(lf[43]))(4,*((C_word*)lf[43]+1),((C_word*)t0)[3],t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a8221 in k8215 in k8209 in rec in scan in ##compiler#transform-direct-lambdas! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_8222(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8222,3,t0,t1,t2);}
/* optimizer.scm: 1250 rec */
t3=((C_word*)((C_word*)t0)[3])[1];
f_8057(t3,t1,t2,C_SCHEME_FALSE,C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* k8193 in rec in scan in ##compiler#transform-direct-lambdas! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_8195(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8195,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8191,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1241 alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[28]))(5,*((C_word*)lf[28]+1),t2,((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)((C_word*)t0)[5])[1]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k8189 in k8193 in rec in scan in ##compiler#transform-direct-lambdas! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_8191(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_TRUE);}

/* a8160 in rec in scan in ##compiler#transform-direct-lambdas! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_8161(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8161,3,t0,t1,t2);}
/* optimizer.scm: 1236 rec */
t3=((C_word*)((C_word*)t0)[3])[1];
f_8057(t3,t1,t2,C_SCHEME_FALSE,C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* a8123 in rec in scan in ##compiler#transform-direct-lambdas! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_8124(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8124,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],((C_word*)((C_word*)t0)[5])[1]);
t6=C_mutate(((C_word *)((C_word*)t0)[5])+1,t5);
t7=(C_word)C_i_car(((C_word*)t0)[4]);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8140,a[2]=t7,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1231 append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[13]+1)))(4,*((C_word*)lf[13]+1),t8,t2,((C_word*)t0)[2]);}

/* k8138 in a8123 in rec in scan in ##compiler#transform-direct-lambdas! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_8140(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1231 rec */
t2=((C_word*)((C_word*)t0)[4])[1];
f_8057(t2,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE,C_SCHEME_FALSE,t1);}

/* k8104 in rec in scan in ##compiler#transform-direct-lambdas! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_8106(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
t2=(C_word)C_i_not(t1);
if(C_truep(t2)){
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(C_word)C_i_memq(((C_word*)t0)[5],((C_word*)t0)[4]);
t4=(C_word)C_i_not(t3);
if(C_truep(t4)){
t5=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=((C_word*)((C_word*)t0)[3])[1];
if(C_truep(t5)){
t6=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}
else{
t6=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[2])[1],C_fix(2));
t7=C_mutate(((C_word *)((C_word*)t0)[2])+1,t6);
t8=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_TRUE);}}}}

/* transform in ##compiler#transform-direct-lambdas! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_fcall f_8473(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8473,NULL,8,t0,t1,t2,t3,t4,t5,t6,t7);}
t8=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8477,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t3,a[5]=t7,a[6]=t1,a[7]=t5,a[8]=t6,a[9]=t2,a[10]=((C_word*)t0)[3],tmp=(C_word)a,a+=11,tmp);
if(C_truep((C_word)C_i_pairp(t5))){
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8967,a[2]=t7,a[3]=t3,a[4]=t8,tmp=(C_word)a,a+=5,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8969,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* ##sys#make-promise */
t11=*((C_word*)lf[198]+1);
((C_proc3)(void*)(*((C_word*)t11+1)))(3,t11,t9,t10);}
else{
/* optimizer.scm: 1293 debugging */
((C_proc6)C_retrieve_symbol_proc(lf[7]))(6,*((C_word*)lf[7]+1),t8,lf[8],lf[199],t3,t7);}}

/* a8968 in transform in ##compiler#transform-direct-lambdas! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_8969(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8969,2,t0,t1);}
/* optimizer.scm: 1292 unzip1 */
((C_proc3)C_retrieve_symbol_proc(lf[197]))(3,*((C_word*)lf[197]+1),t1,((C_word*)t0)[2]);}

/* k8965 in transform in ##compiler#transform-direct-lambdas! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_8967(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1292 debugging */
((C_proc7)C_retrieve_symbol_proc(lf[7]))(7,*((C_word*)lf[7]+1),((C_word*)t0)[4],lf[8],lf[196],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k8475 in transform in ##compiler#transform-direct-lambdas! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_8477(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8477,2,t0,t1);}
t2=C_set_block_item(((C_word*)t0)[10],0,C_SCHEME_TRUE);
t3=((C_word*)t0)[9];
t4=(C_word)C_slot(t3,C_fix(2));
t5=(C_word)C_i_caddr(t4);
t6=(C_word)C_i_length(t5);
t7=C_SCHEME_END_OF_LIST;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_8487,a[2]=((C_word*)t0)[3],a[3]=t8,a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[4],a[6]=t6,a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=t4,tmp=(C_word)a,a+=12,tmp);
/* optimizer.scm: 1298 get */
((C_proc5)C_retrieve_symbol_proc(lf[26]))(5,*((C_word*)lf[26]+1),t9,((C_word*)t0)[2],((C_word*)t0)[4],lf[118]);}

/* k8485 in k8475 in transform in ##compiler#transform-direct-lambdas! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_8487(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8487,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_8493,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=t1,a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],a[12]=((C_word*)t0)[10],a[13]=((C_word*)t0)[11],tmp=(C_word)a,a+=14,tmp);
if(C_truep((C_word)C_i_listp(((C_word*)t0)[11]))){
t5=(C_word)C_i_length(((C_word*)t0)[11]);
t6=(C_word)C_eqp(t5,C_fix(4));
if(C_truep(t6)){
t7=(C_word)C_i_caddr(((C_word*)t0)[11]);
t8=t4;
f_8493(t8,(C_word)C_i_listp(t7));}
else{
t7=t4;
f_8493(t7,C_SCHEME_FALSE);}}
else{
t5=t4;
f_8493(t5,C_SCHEME_FALSE);}}

/* k8491 in k8485 in k8475 in transform in ##compiler#transform-direct-lambdas! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_fcall f_8493(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8493,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[13]);
t3=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_8499,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t2,a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],tmp=(C_word)a,a+=15,tmp);
/* optimizer.scm: 1302 caaddr */
((C_proc3)C_retrieve_proc(*((C_word*)lf[194]+1)))(3,*((C_word*)lf[194]+1),t3,((C_word*)t0)[13]);}
else{
/* optimizer.scm: 1400 bomb */
((C_proc4)C_retrieve_symbol_proc(lf[176]))(4,*((C_word*)lf[176]+1),((C_word*)t0)[10],lf[195],((C_word*)t0)[13]);}}

/* k8497 in k8491 in k8485 in k8475 in transform in ##compiler#transform-direct-lambdas! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_8499(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8499,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_8502,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],tmp=(C_word)a,a+=16,tmp);
/* optimizer.scm: 1303 cdaddr */
((C_proc3)C_retrieve_proc(*((C_word*)lf[193]+1)))(3,*((C_word*)lf[193]+1),t2,((C_word*)t0)[14]);}

/* k8500 in k8497 in k8491 in k8485 in k8475 in transform in ##compiler#transform-direct-lambdas! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_8502(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8502,2,t0,t1);}
t2=(C_word)C_i_cddr(((C_word*)t0)[15]);
t3=(C_word)C_i_set_car(t2,t1);
t4=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_8508,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],tmp=(C_word)a,a+=15,tmp);
/* optimizer.scm: 1307 node-class-set! */
((C_proc4)C_retrieve_symbol_proc(lf[184]))(4,*((C_word*)lf[184]+1),t4,((C_word*)t0)[5],lf[192]);}

/* k8506 in k8500 in k8497 in k8491 in k8485 in k8475 in transform in ##compiler#transform-direct-lambdas! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_8508(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8508,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8511,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[12],a[9]=((C_word*)t0)[13],a[10]=((C_word*)t0)[14],tmp=(C_word)a,a+=11,tmp);
t3=((C_word*)t0)[5];
t4=(C_word)C_slot(t3,C_fix(3));
t5=(C_word)C_i_car(t4);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8684,a[2]=((C_word*)t0)[2],a[3]=t7,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp));
t9=((C_word*)t7)[1];
f_8684(3,t9,t2,t5);}

/* rec in k8506 in k8500 in k8497 in k8491 in k8485 in k8475 in transform in ##compiler#transform-direct-lambdas! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_8684(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word ab[13],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8684,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(2));
t5=t2;
t6=(C_word)C_slot(t5,C_fix(3));
t7=t2;
t8=(C_word)C_slot(t7,C_fix(1));
t9=(C_word)C_eqp(t8,lf[16]);
if(C_truep(t9)){
t10=(C_word)C_i_car(t6);
t11=(C_word)C_i_cadr(t6);
t12=(C_word)C_slot(t10,C_fix(2));
t13=(C_word)C_slot(t11,C_fix(2));
t14=(C_word)C_slot(t10,C_fix(1));
t15=(C_word)C_eqp(lf[10],t14);
if(C_truep(t15)){
t16=(C_word)C_i_car(t12);
t17=(C_word)C_eqp(((C_word*)t0)[9],t16);
if(C_truep(t17)){
t18=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_8728,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t2,a[8]=t1,a[9]=t6,a[10]=((C_word*)t0)[7],a[11]=t13,a[12]=((C_word*)t0)[8],tmp=(C_word)a,a+=13,tmp);
/* optimizer.scm: 1321 alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[28]))(5,*((C_word*)lf[28]+1),t18,C_SCHEME_FALSE,t2,((C_word*)((C_word*)t0)[8])[1]);}
else{
t18=(C_word)C_i_car(t12);
t19=(C_word)C_eqp(((C_word*)t0)[7],t18);
if(C_truep(t19)){
t20=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8859,a[2]=t2,a[3]=t1,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1346 node-class-set! */
((C_proc4)C_retrieve_symbol_proc(lf[184]))(4,*((C_word*)lf[184]+1),t20,t2,lf[190]);}
else{
/* optimizer.scm: 1349 bomb */
((C_proc3)C_retrieve_symbol_proc(lf[176]))(3,*((C_word*)lf[176]+1),t1,lf[191]);}}}
else{
t16=t1;
((C_proc2)(void*)(*((C_word*)t16+1)))(2,t16,C_SCHEME_UNDEFINED);}}
else{
t10=(C_word)C_eqp(t8,lf[12]);
if(C_truep(t10)){
t11=(C_word)C_i_car(t4);
t12=(C_word)C_i_car(t6);
if(C_truep((C_word)C_i_memq(t11,((C_word*)t0)[2]))){
t13=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8906,a[2]=t6,a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 1354 alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[28]))(5,*((C_word*)lf[28]+1),t13,t11,t12,((C_word*)((C_word*)t0)[4])[1]);}
else{
/* for-each */
t13=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t13+1)))(4,t13,t1,((C_word*)((C_word*)t0)[3])[1],t6);}}
else{
/* for-each */
t11=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t1,((C_word*)((C_word*)t0)[3])[1],t6);}}}

/* k8904 in rec in k8506 in k8500 in k8497 in k8491 in k8485 in k8475 in transform in ##compiler#transform-direct-lambdas! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_8906(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8906,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[6])+1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8909,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_cadr(((C_word*)t0)[2]);
/* optimizer.scm: 1355 copy-node! */
((C_proc4)C_retrieve_symbol_proc(lf[179]))(4,*((C_word*)lf[179]+1),t3,t4,((C_word*)t0)[3]);}

/* k8907 in k8904 in rec in k8506 in k8500 in k8497 in k8491 in k8485 in k8475 in transform in ##compiler#transform-direct-lambdas! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_8909(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1356 rec */
t2=((C_word*)((C_word*)t0)[4])[1];
f_8684(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k8857 in rec in k8506 in k8500 in k8497 in k8491 in k8485 in k8475 in transform in ##compiler#transform-direct-lambdas! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_8859(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8859,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8862,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1347 node-parameters-set! */
((C_proc4)C_retrieve_symbol_proc(lf[115]))(4,*((C_word*)lf[115]+1),t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k8860 in k8857 in rec in k8506 in k8500 in k8497 in k8491 in k8485 in k8475 in transform in ##compiler#transform-direct-lambdas! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_8862(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* optimizer.scm: 1348 node-subexpressions-set! */
((C_proc4)C_retrieve_symbol_proc(lf[113]))(4,*((C_word*)lf[113]+1),((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k8726 in rec in k8506 in k8500 in k8497 in k8491 in k8485 in k8475 in transform in ##compiler#transform-direct-lambdas! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_8728(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8728,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[12])+1,t1);
t3=(C_word)C_i_car(((C_word*)t0)[11]);
t4=(C_word)C_eqp(((C_word*)t0)[10],t3);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8737,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_i_cdr(((C_word*)t0)[9]);
t7=(C_word)C_i_length(t6);
t8=(C_word)C_eqp(((C_word*)t0)[5],t7);
if(C_truep(t8)){
t9=t5;
f_8737(2,t9,C_SCHEME_UNDEFINED);}
else{
/* optimizer.scm: 1324 quit */
((C_proc4)C_retrieve_symbol_proc(lf[181]))(4,*((C_word*)lf[181]+1),t5,lf[186],((C_word*)t0)[4]);}}
else{
t5=(C_word)C_i_car(((C_word*)t0)[11]);
t6=(C_word)C_i_assq(t5,((C_word*)((C_word*)t0)[3])[1]);
if(C_truep(t6)){
t7=(C_word)C_i_cdr(t6);
t8=(C_word)C_slot(t7,C_fix(3));
t9=(C_word)C_i_car(t8);
t10=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8783,a[2]=t7,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[6],a[6]=t9,a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[2],tmp=(C_word)a,a+=9,tmp);
t11=(C_word)C_i_cdr(((C_word*)t0)[9]);
t12=(C_word)C_i_length(t11);
t13=(C_word)C_eqp(((C_word*)t0)[5],t12);
if(C_truep(t13)){
t14=t10;
f_8783(2,t14,C_SCHEME_UNDEFINED);}
else{
/* optimizer.scm: 1335 quit */
((C_proc4)C_retrieve_symbol_proc(lf[181]))(4,*((C_word*)lf[181]+1),t10,lf[188],((C_word*)t0)[4]);}}
else{
/* optimizer.scm: 1344 bomb */
((C_proc4)C_retrieve_symbol_proc(lf[176]))(4,*((C_word*)lf[176]+1),((C_word*)t0)[8],lf[189],((C_word*)t0)[11]);}}}

/* k8781 in k8726 in rec in k8506 in k8500 in k8497 in k8491 in k8485 in k8475 in transform in ##compiler#transform-direct-lambdas! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_8783(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8783,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8786,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 1338 node-class-set! */
((C_proc4)C_retrieve_symbol_proc(lf[184]))(4,*((C_word*)lf[184]+1),t2,((C_word*)t0)[3],lf[12]);}

/* k8784 in k8781 in k8726 in rec in k8506 in k8500 in k8497 in k8491 in k8485 in k8475 in transform in ##compiler#transform-direct-lambdas! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_8786(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8786,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8789,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8813,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_slot(((C_word*)t0)[2],C_fix(2));
t5=(C_word)C_i_caddr(t4);
/* optimizer.scm: 1339 take */
((C_proc4)C_retrieve_symbol_proc(lf[187]))(4,*((C_word*)lf[187]+1),t3,t5,C_fix(1));}

/* k8811 in k8784 in k8781 in k8726 in rec in k8506 in k8500 in k8497 in k8491 in k8485 in k8475 in transform in ##compiler#transform-direct-lambdas! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_8813(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1339 node-parameters-set! */
((C_proc4)C_retrieve_symbol_proc(lf[115]))(4,*((C_word*)lf[115]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8787 in k8784 in k8781 in k8726 in rec in k8506 in k8500 in k8497 in k8491 in k8485 in k8475 in transform in ##compiler#transform-direct-lambdas! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_8789(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8789,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8792,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_a_i_list(&a,2,C_SCHEME_FALSE,((C_word*)t0)[4]);
t4=(C_word)C_i_cddr(((C_word*)t0)[3]);
t5=(C_word)C_a_i_record(&a,4,lf[37],lf[185],t3,t4);
t6=(C_word)C_a_i_list(&a,2,t5,((C_word*)t0)[5]);
/* optimizer.scm: 1340 node-subexpressions-set! */
((C_proc4)C_retrieve_symbol_proc(lf[113]))(4,*((C_word*)lf[113]+1),t2,((C_word*)t0)[2],t6);}

/* k8790 in k8787 in k8784 in k8781 in k8726 in rec in k8506 in k8500 in k8497 in k8491 in k8485 in k8475 in transform in ##compiler#transform-direct-lambdas! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_8792(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1343 rec */
t2=((C_word*)((C_word*)t0)[4])[1];
f_8684(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k8735 in k8726 in rec in k8506 in k8500 in k8497 in k8491 in k8485 in k8475 in transform in ##compiler#transform-direct-lambdas! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_8737(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8737,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8740,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 1327 node-class-set! */
((C_proc4)C_retrieve_symbol_proc(lf[184]))(4,*((C_word*)lf[184]+1),t2,((C_word*)t0)[3],lf[185]);}

/* k8738 in k8735 in k8726 in rec in k8506 in k8500 in k8497 in k8491 in k8485 in k8475 in transform in ##compiler#transform-direct-lambdas! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_8740(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8740,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8743,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_a_i_list(&a,2,C_SCHEME_TRUE,((C_word*)t0)[2]);
/* optimizer.scm: 1328 node-parameters-set! */
((C_proc4)C_retrieve_symbol_proc(lf[115]))(4,*((C_word*)lf[115]+1),t2,((C_word*)t0)[3],t3);}

/* k8741 in k8738 in k8735 in k8726 in rec in k8506 in k8500 in k8497 in k8491 in k8485 in k8475 in transform in ##compiler#transform-direct-lambdas! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_8743(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cddr(((C_word*)t0)[4]);
/* optimizer.scm: 1329 node-subexpressions-set! */
((C_proc4)C_retrieve_symbol_proc(lf[113]))(4,*((C_word*)lf[113]+1),((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k8509 in k8506 in k8500 in k8497 in k8491 in k8485 in k8475 in transform in ##compiler#transform-direct-lambdas! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_8511(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8511,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8514,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8607,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8664,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8666,tmp=(C_word)a,a+=2,tmp);
/* optimizer.scm: 1377 lset-difference */
((C_proc5)C_retrieve_symbol_proc(lf[183]))(5,*((C_word*)lf[183]+1),t4,t5,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* a8665 in k8509 in k8506 in k8500 in k8497 in k8491 in k8485 in k8475 in transform in ##compiler#transform-direct-lambdas! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_8666(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8666,4,t0,t1,t2,t3);}
t4=(C_word)C_i_cdr(t2);
t5=(C_word)C_i_cdr(t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_eqp(t4,t5));}

/* k8662 in k8509 in k8506 in k8500 in k8497 in k8491 in k8485 in k8475 in transform in ##compiler#transform-direct-lambdas! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_8664(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a8606 in k8509 in k8506 in k8500 in k8497 in k8491 in k8485 in k8475 in transform in ##compiler#transform-direct-lambdas! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_8607(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8607,3,t0,t1,t2);}
t3=(C_word)C_i_cdr(t2);
t4=(C_word)C_slot(t3,C_fix(3));
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8617,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t4,tmp=(C_word)a,a+=7,tmp);
t6=(C_word)C_i_cdr(t4);
t7=(C_word)C_i_length(t6);
t8=(C_word)C_eqp(((C_word*)t0)[3],t7);
if(C_truep(t8)){
t9=t5;
f_8617(2,t9,C_SCHEME_UNDEFINED);}
else{
/* optimizer.scm: 1367 quit */
((C_proc4)C_retrieve_symbol_proc(lf[181]))(4,*((C_word*)lf[181]+1),t5,lf[182],((C_word*)t0)[2]);}}

/* k8615 in a8606 in k8509 in k8506 in k8500 in k8497 in k8491 in k8485 in k8475 in transform in ##compiler#transform-direct-lambdas! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_8617(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8617,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[6]);
t3=(C_word)C_a_i_list(&a,4,C_SCHEME_TRUE,C_SCHEME_FALSE,((C_word*)t0)[5],((C_word*)t0)[4]);
t4=(C_word)C_i_car(((C_word*)t0)[6]);
t5=(C_word)C_i_cddr(((C_word*)t0)[6]);
t6=(C_word)C_a_i_cons(&a,2,t4,t5);
t7=(C_word)C_a_i_record(&a,4,lf[37],lf[180],t3,t6);
t8=(C_word)C_a_i_list(&a,2,t2,t7);
/* optimizer.scm: 1370 node-subexpressions-set! */
((C_proc4)C_retrieve_symbol_proc(lf[113]))(4,*((C_word*)lf[113]+1),((C_word*)t0)[3],((C_word*)t0)[2],t8);}

/* k8512 in k8509 in k8506 in k8500 in k8497 in k8491 in k8485 in k8475 in transform in ##compiler#transform-direct-lambdas! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_8514(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8514,2,t0,t1);}
t2=(C_truep(((C_word*)t0)[4])?(C_word)C_i_pairp(((C_word*)t0)[3]):C_SCHEME_FALSE);
if(C_truep(t2)){
t3=(C_word)C_a_i_record(&a,4,lf[37],C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8526,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 1382 copy-node! */
((C_proc4)C_retrieve_symbol_proc(lf[179]))(4,*((C_word*)lf[179]+1),t4,((C_word*)t0)[4],t3);}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k8524 in k8512 in k8509 in k8506 in k8500 in k8497 in k8491 in k8485 in k8475 in transform in ##compiler#transform-direct-lambdas! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_8526(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8526,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8529,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8565,tmp=(C_word)a,a+=2,tmp);
/* optimizer.scm: 1384 fold-right */
((C_proc5)C_retrieve_symbol_proc(lf[124]))(5,*((C_word*)lf[124]+1),t2,t3,((C_word*)t0)[2],((C_word*)t0)[4]);}

/* a8564 in k8524 in k8512 in k8509 in k8506 in k8500 in k8497 in k8491 in k8485 in k8475 in transform in ##compiler#transform-direct-lambdas! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_8565(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[19],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8565,4,t0,t1,t2,t3);}
t4=(C_word)C_i_car(t2);
t5=(C_word)C_a_i_list(&a,1,t4);
t6=(C_word)C_i_cdr(t2);
t7=(C_word)C_slot(t6,C_fix(3));
t8=(C_word)C_i_car(t7);
t9=(C_word)C_slot(t8,C_fix(1));
t10=(C_word)C_slot(t8,C_fix(2));
t11=(C_word)C_slot(t8,C_fix(3));
t12=(C_word)C_a_i_record(&a,4,lf[37],t9,t10,t11);
t13=(C_word)C_a_i_list(&a,2,t12,t3);
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,(C_word)C_a_i_record(&a,4,lf[37],lf[12],t5,t13));}

/* k8527 in k8524 in k8512 in k8509 in k8506 in k8500 in k8497 in k8491 in k8485 in k8475 in transform in ##compiler#transform-direct-lambdas! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_8529(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8529,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8532,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1393 copy-node! */
((C_proc4)C_retrieve_symbol_proc(lf[179]))(4,*((C_word*)lf[179]+1),t2,t1,((C_word*)t0)[2]);}

/* k8530 in k8527 in k8524 in k8512 in k8509 in k8506 in k8500 in k8497 in k8491 in k8485 in k8475 in transform in ##compiler#transform-direct-lambdas! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_8532(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8532,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8537,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t3=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a8536 in k8530 in k8527 in k8524 in k8512 in k8509 in k8506 in k8500 in k8497 in k8491 in k8485 in k8475 in transform in ##compiler#transform-direct-lambdas! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_8537(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8537,3,t0,t1,t2);}
t3=(C_word)C_i_cdr(t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8544,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8563,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1397 gensym */
((C_proc2)C_retrieve_symbol_proc(lf[83]))(2,*((C_word*)lf[83]+1),t5);}

/* k8561 in a8536 in k8530 in k8527 in k8524 in k8512 in k8509 in k8506 in k8500 in k8497 in k8491 in k8485 in k8475 in transform in ##compiler#transform-direct-lambdas! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_8563(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8563,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* optimizer.scm: 1397 node-parameters-set! */
((C_proc4)C_retrieve_symbol_proc(lf[115]))(4,*((C_word*)lf[115]+1),((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k8542 in a8536 in k8530 in k8527 in k8524 in k8512 in k8509 in k8506 in k8500 in k8497 in k8491 in k8485 in k8475 in transform in ##compiler#transform-direct-lambdas! in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_8544(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8544,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(3));
t3=(C_word)C_a_i_record(&a,4,lf[37],lf[69],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_set_car(t2,t3));}

/* ##compiler#simplify-named-call in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_6017(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word ab[8],*a=ab;
if(c!=9) C_bad_argc_2(c,9,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr9,(void*)f_6017,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
switch(t6){
case C_fix(1):
t9=t4;
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6074,a[2]=t5,a[3]=t8,a[4]=t7,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[45]))(4,*((C_word*)lf[45]+1),t10,t9,lf[46]);
case C_fix(2):
if(C_truep(C_retrieve(lf[138]))){
t9=(C_word)C_i_length(t8);
t10=(C_word)C_i_car(t7);
t11=(C_word)C_eqp(t9,t10);
if(C_truep(t11)){
t12=t4;
t13=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6182,a[2]=t2,a[3]=t1,a[4]=t5,a[5]=t8,a[6]=t7,tmp=(C_word)a,a+=7,tmp);
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[45]))(4,*((C_word*)lf[45]+1),t13,t12,lf[46]);}
else{
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_FALSE);}}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(3):
if(C_truep(C_retrieve(lf[138]))){
if(C_truep((C_word)C_i_nullp(t8))){
t9=t4;
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6280,a[2]=t7,a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[45]))(4,*((C_word*)lf[45]+1),t10,t9,lf[46]);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(4):
if(C_truep(C_retrieve(lf[138]))){
if(C_truep(C_retrieve(lf[142]))){
t9=(C_word)C_i_length(t8);
t10=(C_word)C_eqp(C_fix(2),t9);
if(C_truep(t10)){
t11=t4;
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6318,a[2]=t1,a[3]=t5,a[4]=t8,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[45]))(4,*((C_word*)lf[45]+1),t12,t11,lf[46]);}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_FALSE);}}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(5):
if(C_truep(C_retrieve(lf[138]))){
t9=t4;
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6374,a[2]=t1,a[3]=t5,a[4]=t7,a[5]=t8,tmp=(C_word)a,a+=6,tmp);
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[45]))(4,*((C_word*)lf[45]+1),t10,t9,lf[46]);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(6):
t9=(C_word)C_i_caddr(t7);
t10=(C_truep(t9)?t9:C_retrieve(lf[142]));
if(C_truep(t10)){
if(C_truep(C_retrieve(lf[138]))){
t11=(C_word)C_i_length(t8);
t12=(C_word)C_eqp(C_fix(1),t11);
if(C_truep(t12)){
t13=t4;
t14=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6461,a[2]=t1,a[3]=t5,a[4]=t8,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[45]))(4,*((C_word*)lf[45]+1),t14,t13,lf[46]);}
else{
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,C_SCHEME_FALSE);}}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_FALSE);}}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_FALSE);}
case C_fix(7):
t9=(C_word)C_i_cadddr(t7);
t10=(C_truep(t9)?t9:C_retrieve(lf[142]));
if(C_truep(t10)){
if(C_truep(C_retrieve(lf[138]))){
t11=(C_word)C_i_length(t8);
t12=(C_word)C_i_car(t7);
t13=(C_word)C_eqp(t11,t12);
if(C_truep(t13)){
t14=t4;
t15=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6526,a[2]=t8,a[3]=t1,a[4]=t5,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[45]))(4,*((C_word*)lf[45]+1),t15,t14,lf[46]);}
else{
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,C_SCHEME_FALSE);}}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_FALSE);}}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_FALSE);}
case C_fix(8):
if(C_truep(C_retrieve(lf[138]))){
t9=t4;
t10=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6581,a[2]=t8,a[3]=t5,a[4]=t2,a[5]=t1,a[6]=t7,tmp=(C_word)a,a+=7,tmp);
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[45]))(4,*((C_word*)lf[45]+1),t10,t9,lf[46]);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(9):
if(C_truep(C_retrieve(lf[138]))){
t9=t4;
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6602,a[2]=t7,a[3]=t1,a[4]=t5,a[5]=t8,tmp=(C_word)a,a+=6,tmp);
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[45]))(4,*((C_word*)lf[45]+1),t10,t9,lf[46]);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(10):
if(C_truep(C_retrieve(lf[138]))){
t9=(C_word)C_i_cadddr(t7);
t10=(C_truep(t9)?t9:C_retrieve(lf[142]));
if(C_truep(t10)){
t11=t4;
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6746,a[2]=t1,a[3]=t5,a[4]=t7,a[5]=t8,tmp=(C_word)a,a+=6,tmp);
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[45]))(4,*((C_word*)lf[45]+1),t12,t11,lf[46]);}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_FALSE);}}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(11):
if(C_truep(C_retrieve(lf[138]))){
t9=(C_word)C_i_caddr(t7);
t10=(C_truep(t9)?t9:C_retrieve(lf[142]));
if(C_truep(t10)){
t11=t4;
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6833,a[2]=t8,a[3]=t5,a[4]=t1,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[45]))(4,*((C_word*)lf[45]+1),t12,t11,lf[46]);}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_FALSE);}}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(12):
if(C_truep(C_retrieve(lf[138]))){
t9=t4;
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6892,a[2]=t1,a[3]=t5,a[4]=t8,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[45]))(4,*((C_word*)lf[45]+1),t10,t9,lf[46]);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(13):
if(C_truep(C_retrieve(lf[138]))){
t9=t4;
t10=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6962,a[2]=t3,a[3]=t8,a[4]=t5,a[5]=t1,a[6]=t7,tmp=(C_word)a,a+=7,tmp);
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[45]))(4,*((C_word*)lf[45]+1),t10,t9,lf[46]);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(14):
if(C_truep(C_retrieve(lf[138]))){
t9=(C_word)C_i_cadr(t7);
t10=(C_word)C_i_length(t8);
t11=(C_word)C_eqp(t9,t10);
if(C_truep(t11)){
t12=t4;
t13=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7021,a[2]=t1,a[3]=t5,a[4]=t8,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[45]))(4,*((C_word*)lf[45]+1),t13,t12,lf[46]);}
else{
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_FALSE);}}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(15):
if(C_truep(C_retrieve(lf[138]))){
t9=(C_word)C_i_length(t8);
t10=(C_word)C_eqp(C_fix(1),t9);
if(C_truep(t10)){
t11=C_retrieve(lf[142]);
t12=(C_truep(t11)?t11:(C_word)C_i_cadddr(t7));
if(C_truep(t12)){
t13=t4;
t14=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7098,a[2]=t8,a[3]=t5,a[4]=t1,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[45]))(4,*((C_word*)lf[45]+1),t14,t13,lf[46]);}
else{
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,C_SCHEME_FALSE);}}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_FALSE);}}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(16):
t9=(C_word)C_i_car(t7);
t10=(C_word)C_i_length(t8);
t11=(C_word)C_i_cadddr(t7);
if(C_truep(C_retrieve(lf[138]))){
t12=(C_word)C_i_not(t9);
t13=(C_truep(t12)?t12:(C_word)C_eqp(t10,t9));
if(C_truep(t13)){
t14=t4;
t15=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7185,a[2]=t10,a[3]=t11,a[4]=t1,a[5]=t5,a[6]=t8,a[7]=t7,tmp=(C_word)a,a+=8,tmp);
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[45]))(4,*((C_word*)lf[45]+1),t15,t14,lf[46]);}
else{
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,C_SCHEME_FALSE);}}
else{
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_FALSE);}
case C_fix(17):
if(C_truep(C_retrieve(lf[138]))){
t9=(C_word)C_i_length(t8);
t10=(C_word)C_i_car(t7);
t11=(C_word)C_eqp(t9,t10);
if(C_truep(t11)){
t12=t4;
t13=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7258,a[2]=t1,a[3]=t5,a[4]=t8,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[45]))(4,*((C_word*)lf[45]+1),t13,t12,lf[46]);}
else{
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_FALSE);}}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(18):
if(C_truep(C_retrieve(lf[138]))){
if(C_truep((C_word)C_i_nullp(t8))){
t9=t4;
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7320,a[2]=t7,a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[45]))(4,*((C_word*)lf[45]+1),t10,t9,lf[46]);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(19):
if(C_truep(C_retrieve(lf[138]))){
t9=t4;
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7349,a[2]=t8,a[3]=t1,a[4]=t5,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[45]))(4,*((C_word*)lf[45]+1),t10,t9,lf[46]);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(20):
t9=(C_word)C_i_length(t8);
t10=(C_word)C_i_cadddr(t7);
t11=(C_truep(t10)?t10:C_retrieve(lf[142]));
if(C_truep(t11)){
if(C_truep(C_retrieve(lf[138]))){
t12=(C_word)C_i_car(t7);
t13=(C_word)C_eqp(t9,t12);
if(C_truep(t13)){
t14=t4;
t15=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7491,a[2]=t8,a[3]=t9,a[4]=t1,a[5]=t5,a[6]=t7,tmp=(C_word)a,a+=7,tmp);
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[45]))(4,*((C_word*)lf[45]+1),t15,t14,lf[46]);}
else{
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,C_SCHEME_FALSE);}}
else{
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_FALSE);}}
else{
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_FALSE);}
case C_fix(21):
if(C_truep(C_retrieve(lf[138]))){
t9=t4;
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7558,a[2]=t8,a[3]=t1,a[4]=t5,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[45]))(4,*((C_word*)lf[45]+1),t10,t9,lf[46]);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(22):
t9=(C_word)C_i_car(t7);
t10=(C_word)C_i_length(t8);
t11=(C_word)C_i_cadddr(t7);
if(C_truep(C_retrieve(lf[138]))){
t12=(C_word)C_eqp(t10,t9);
if(C_truep(t12)){
t13=t4;
t14=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7706,a[2]=t11,a[3]=t8,a[4]=t1,a[5]=t5,a[6]=t7,tmp=(C_word)a,a+=7,tmp);
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[45]))(4,*((C_word*)lf[45]+1),t14,t13,lf[46]);}
else{
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,C_SCHEME_FALSE);}}
else{
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_FALSE);}
case C_fix(23):
if(C_truep(C_retrieve(lf[138]))){
t9=t4;
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7763,a[2]=t5,a[3]=t1,a[4]=t8,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[45]))(4,*((C_word*)lf[45]+1),t10,t9,lf[46]);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
default:
/* optimizer.scm: 1169 bomb */
((C_proc3)C_retrieve_symbol_proc(lf[176]))(3,*((C_word*)lf[176]+1),t1,lf[177]);}}

/* k7761 in ##compiler#simplify-named-call in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_7763(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7763,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_i_length(((C_word*)t0)[4]);
t4=(C_word)C_i_car(((C_word*)t0)[5]);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,t4))){
t5=(C_word)C_i_cadr(((C_word*)t0)[5]);
t6=(C_word)C_a_i_list(&a,2,C_SCHEME_TRUE,t5);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7778,a[2]=t6,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7785,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[2],a[6]=t7,tmp=(C_word)a,a+=7,tmp);
t9=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* optimizer.scm: 1155 varnode */
((C_proc3)C_retrieve_symbol_proc(lf[49]))(3,*((C_word*)lf[49]+1),t8,t9);}
else{
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k7783 in k7761 in ##compiler#simplify-named-call in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_7785(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7785,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7789,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7791,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7797,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t2,t3,t4);}

/* a7796 in k7783 in k7761 in ##compiler#simplify-named-call in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_7797(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7797,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7805,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_cddr(((C_word*)t0)[2]);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7811,a[2]=t7,tmp=(C_word)a,a+=3,tmp));
t9=((C_word*)t7)[1];
f_7811(t9,t4,t3,t5);}

/* loop in a7796 in k7783 in k7761 in ##compiler#simplify-named-call in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_fcall f_7811(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
a=C_alloc(9);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_7811,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7831,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_car(t3);
if(C_truep((C_word)C_i_symbolp(t5))){
/* optimizer.scm: 779  varnode */
((C_proc3)C_retrieve_symbol_proc(lf[49]))(3,*((C_word*)lf[49]+1),t4,t5);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6042,a[2]=t4,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(t5))){
t7=(C_word)C_i_car(t5);
t8=t6;
f_6042(t8,(C_word)C_eqp(lf[27],t7));}
else{
t7=t6;
f_6042(t7,C_SCHEME_FALSE);}}}}
else{
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7860,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(t2);
t7=(C_word)C_i_cdr(t3);
/* optimizer.scm: 1167 loop */
t13=t5;
t14=t6;
t15=t7;
t1=t13;
t2=t14;
t3=t15;
goto loop;}}}

/* k7858 in loop in a7796 in k7783 in k7761 in ##compiler#simplify-named-call in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_7860(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7860,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k6040 in loop in a7796 in k7783 in k7761 in ##compiler#simplify-named-call in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_fcall f_6042(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[3]);
/* optimizer.scm: 780  qnode */
((C_proc3)C_retrieve_symbol_proc(lf[39]))(3,*((C_word*)lf[39]+1),((C_word*)t0)[2],t2);}
else{
/* optimizer.scm: 781  qnode */
((C_proc3)C_retrieve_symbol_proc(lf[39]))(3,*((C_word*)lf[39]+1),((C_word*)t0)[2],((C_word*)t0)[3]);}}

/* k7829 in loop in a7796 in k7783 in k7761 in ##compiler#simplify-named-call in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_7831(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7831,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7835,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* optimizer.scm: 1165 loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_7811(t4,t2,C_SCHEME_END_OF_LIST,t3);}

/* k7833 in k7829 in loop in a7796 in k7783 in k7761 in ##compiler#simplify-named-call in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_7835(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7835,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k7803 in a7796 in k7783 in k7761 in ##compiler#simplify-named-call in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_7805(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1158 append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[13]+1)))(4,*((C_word*)lf[13]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a7790 in k7783 in k7761 in ##compiler#simplify-named-call in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_7791(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7791,2,t0,t1);}
/* optimizer.scm: 1157 split-at */
((C_proc4)C_retrieve_symbol_proc(lf[86]))(4,*((C_word*)lf[86]+1),t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k7787 in k7783 in k7761 in ##compiler#simplify-named-call in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_7789(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1154 cons* */
((C_proc5)C_retrieve_symbol_proc(lf[157]))(5,*((C_word*)lf[157]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7776 in k7761 in ##compiler#simplify-named-call in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_7778(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7778,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[37],lf[16],((C_word*)t0)[2],t1));}

/* k7704 in ##compiler#simplify-named-call in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_7706(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7706,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_caddr(((C_word*)t0)[6]);
t3=(C_truep(t2)?t2:C_retrieve(lf[142]));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7725,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_eqp(C_retrieve(lf[147]),lf[152]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7738,a[2]=t4,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1136 fifth */
((C_proc3)C_retrieve_symbol_proc(lf[174]))(3,*((C_word*)lf[174]+1),t6,((C_word*)t0)[6]);}
else{
t6=(C_word)C_i_cadr(((C_word*)t0)[6]);
t7=(C_word)C_a_i_list(&a,2,t6,((C_word*)t0)[2]);
t8=((C_word*)t0)[3];
t9=t4;
f_7725(t9,(C_word)C_a_i_record(&a,4,lf[37],lf[88],t7,t8));}}
else{
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k7736 in k7704 in ##compiler#simplify-named-call in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_7738(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7738,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[3];
t4=((C_word*)t0)[2];
f_7725(t4,(C_word)C_a_i_record(&a,4,lf[37],lf[139],t2,t3));}

/* k7723 in k7704 in ##compiler#simplify-named-call in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_fcall f_7725(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7725,NULL,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[37],lf[16],lf[175],t2));}

/* k7556 in ##compiler#simplify-named-call in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_7558(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7558,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7564,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 1096 fifth */
((C_proc3)C_retrieve_symbol_proc(lf[174]))(3,*((C_word*)lf[174]+1),t3,((C_word*)t0)[5]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k7562 in k7556 in ##compiler#simplify-named-call in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_7564(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7564,2,t0,t1);}
t2=(C_word)C_i_cadddr(((C_word*)t0)[6]);
t3=(C_truep(C_retrieve(lf[142]))?(C_word)C_i_caddr(((C_word*)t0)[6]):(C_word)C_i_cadr(((C_word*)t0)[6]));
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7573,a[2]=t1,a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7648,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 1100 remove */
((C_proc4)C_retrieve_symbol_proc(lf[169]))(4,*((C_word*)lf[169]+1),t4,t5,((C_word*)t0)[2]);}

/* a7647 in k7562 in k7556 in ##compiler#simplify-named-call in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_7648(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7648,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(1));
t5=(C_word)C_eqp(lf[27],t4);
if(C_truep(t5)){
t6=t2;
t7=(C_word)C_slot(t6,C_fix(2));
t8=(C_word)C_i_car(t7);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_eqp(((C_word*)t0)[2],t8));}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}

/* k7571 in k7562 in k7556 in ##compiler#simplify-named-call in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_7573(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7573,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7589,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1105 qnode */
((C_proc3)C_retrieve_symbol_proc(lf[39]))(3,*((C_word*)lf[39]+1),t2,((C_word*)t0)[5]);}
else{
t2=(C_word)C_i_cdr(t1);
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_i_car(t1);
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[7],t3);
t5=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[37],lf[16],lf[172],t4));}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7615,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7617,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1113 fold-inner */
((C_proc4)C_retrieve_symbol_proc(lf[168]))(4,*((C_word*)lf[168]+1),t3,t4,t1);}}}

/* a7616 in k7571 in k7562 in k7556 in ##compiler#simplify-named-call in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_7617(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[17],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7617,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(C_retrieve(lf[147]),lf[152]);
if(C_truep(t4)){
t5=(C_word)C_a_i_list(&a,1,((C_word*)t0)[4]);
t6=(C_word)C_a_i_list(&a,2,t2,t3);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_record(&a,4,lf[37],lf[139],t5,t6));}
else{
t5=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]);
t6=(C_word)C_a_i_list(&a,2,t2,t3);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_record(&a,4,lf[37],lf[88],t5,t6));}}

/* k7613 in k7571 in k7562 in k7556 in ##compiler#simplify-named-call in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_7615(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7615,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[37],lf[16],lf[173],t2));}

/* k7587 in k7571 in k7562 in k7556 in ##compiler#simplify-named-call in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_7589(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7589,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[37],lf[16],lf[171],t2));}

/* k7489 in ##compiler#simplify-named-call in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_7491(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7491,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[6]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7504,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7509,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7519,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t4,t5,t6);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a7518 in k7489 in ##compiler#simplify-named-call in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_7519(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7519,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7531,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_caddr(((C_word*)t0)[2]);
/* optimizer.scm: 1084 qnode */
((C_proc3)C_retrieve_symbol_proc(lf[39]))(3,*((C_word*)lf[39]+1),t4,t5);}

/* k7529 in a7518 in k7489 in ##compiler#simplify-named-call in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_7531(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7531,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* optimizer.scm: 1083 append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[13]+1)))(5,*((C_word*)lf[13]+1),((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a7508 in k7489 in ##compiler#simplify-named-call in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_7509(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7509,2,t0,t1);}
t2=(C_word)C_fixnum_decrease(((C_word*)t0)[3]);
/* optimizer.scm: 1082 split-at */
((C_proc4)C_retrieve_symbol_proc(lf[86]))(4,*((C_word*)lf[86]+1),t1,((C_word*)t0)[2],t2);}

/* k7502 in k7489 in ##compiler#simplify-named-call in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_7504(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7504,2,t0,t1);}
t2=(C_word)C_a_i_record(&a,4,lf[37],lf[139],((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_record(&a,4,lf[37],lf[16],lf[170],t3));}

/* k7347 in ##compiler#simplify-named-call in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_7349(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7349,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_truep(C_retrieve(lf[142]))?(C_word)C_i_caddr(((C_word*)t0)[5]):(C_word)C_i_cadr(((C_word*)t0)[5]));
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7358,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7430,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 1051 remove */
((C_proc4)C_retrieve_symbol_proc(lf[169]))(4,*((C_word*)lf[169]+1),t4,t5,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a7429 in k7347 in ##compiler#simplify-named-call in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_7430(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7430,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(1));
t5=(C_word)C_eqp(lf[27],t4);
if(C_truep(t5)){
t6=t2;
t7=(C_word)C_slot(t6,C_fix(2));
t8=(C_word)C_i_car(t7);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_eqp(((C_word*)t0)[2],t8));}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}

/* k7356 in k7347 in ##compiler#simplify-named-call in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_7358(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7358,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7374,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1056 qnode */
((C_proc3)C_retrieve_symbol_proc(lf[39]))(3,*((C_word*)lf[39]+1),t2,((C_word*)t0)[4]);}
else{
t2=(C_word)C_i_cdr(t1);
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_i_car(t1);
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[6],t3);
t5=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[37],lf[16],lf[166],t4));}
else{
t3=(C_word)C_i_cadddr(((C_word*)t0)[3]);
t4=(C_truep(t3)?t3:(C_word)C_eqp(C_retrieve(lf[147]),lf[152]));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7409,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7411,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 1064 fold-inner */
((C_proc4)C_retrieve_symbol_proc(lf[168]))(4,*((C_word*)lf[168]+1),t5,t6,t1);}
else{
t5=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}}}

/* a7410 in k7356 in k7347 in ##compiler#simplify-named-call in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_7411(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7411,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
t5=(C_word)C_a_i_list(&a,2,t2,t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_record(&a,4,lf[37],lf[139],t4,t5));}

/* k7407 in k7356 in k7347 in ##compiler#simplify-named-call in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_7409(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7409,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[37],lf[16],lf[167],t2));}

/* k7372 in k7356 in k7347 in ##compiler#simplify-named-call in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_7374(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7374,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[37],lf[16],lf[165],t2));}

/* k7318 in ##compiler#simplify-named-call in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_7320(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7320,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7330,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[2]);
/* optimizer.scm: 1038 qnode */
((C_proc3)C_retrieve_symbol_proc(lf[39]))(3,*((C_word*)lf[39]+1),t2,t3);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k7328 in k7318 in ##compiler#simplify-named-call in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_7330(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7330,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[37],lf[16],lf[164],t2));}

/* k7256 in ##compiler#simplify-named-call in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_7258(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7258,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7278,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_retrieve(lf[142]))){
t3=(C_word)C_i_cddr(((C_word*)t0)[5]);
t4=t2;
f_7278(t4,(C_word)C_i_pairp(t3));}
else{
t3=t2;
f_7278(t3,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k7276 in k7256 in ##compiler#simplify-named-call in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_fcall f_7278(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7278,NULL,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_i_caddr(((C_word*)t0)[5]):(C_word)C_i_cadr(((C_word*)t0)[5]));
t3=(C_word)C_a_i_list(&a,1,t2);
t4=((C_word*)t0)[4];
t5=(C_word)C_a_i_record(&a,4,lf[37],lf[139],t3,t4);
t6=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t5);
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_record(&a,4,lf[37],lf[16],lf[163],t6));}

/* k7183 in ##compiler#simplify-named-call in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_7185(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7185,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_caddr(((C_word*)t0)[7]);
t3=(C_truep(t2)?t2:C_retrieve(lf[142]));
if(C_truep(t3)){
t4=(C_word)C_i_cadr(((C_word*)t0)[7]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7215,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_eqp(C_SCHEME_TRUE,((C_word*)t0)[3]);
if(C_truep(t6)){
t7=t5;
f_7215(t7,(C_word)C_fixnum_increase(((C_word*)t0)[2]));}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
t7=(C_word)C_i_car(((C_word*)t0)[3]);
t8=t5;
f_7215(t8,(C_word)C_fixnum_times(((C_word*)t0)[2],t7));}
else{
t7=t5;
f_7215(t7,((C_word*)t0)[3]);}}}
else{
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k7213 in k7183 in ##compiler#simplify-named-call in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_fcall f_7215(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7215,NULL,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[5],t1);
t3=((C_word*)t0)[4];
t4=(C_word)C_a_i_record(&a,4,lf[37],lf[88],t2,t3);
t5=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t4);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_record(&a,4,lf[37],lf[16],lf[162],t5));}

/* k7096 in ##compiler#simplify-named-call in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_7098(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7098,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_eqp(C_retrieve(lf[147]),t2);
if(C_truep(t3)){
t4=(C_word)C_i_caddr(((C_word*)t0)[5]);
t5=(C_word)C_a_i_list(&a,2,C_SCHEME_TRUE,t4);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7110,a[2]=t5,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7117,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t6,tmp=(C_word)a,a+=5,tmp);
t8=(C_word)C_i_caddr(((C_word*)t0)[5]);
/* optimizer.scm: 989  varnode */
((C_proc3)C_retrieve_symbol_proc(lf[49]))(3,*((C_word*)lf[49]+1),t7,t8);}
else{
t4=(C_word)C_i_cadr(((C_word*)t0)[5]);
t5=(C_word)C_eqp(C_retrieve(lf[147]),t4);
if(C_truep(t5)){
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]);
t7=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_record(&a,4,lf[37],lf[16],lf[161],t6));}
else{
t6=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k7115 in k7096 in ##compiler#simplify-named-call in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_7117(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 989  cons* */
((C_proc5)C_retrieve_symbol_proc(lf[157]))(5,*((C_word*)lf[157]+1),((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k7108 in k7096 in ##compiler#simplify-named-call in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_7110(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7110,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[37],lf[16],((C_word*)t0)[2],t1));}

/* k7019 in ##compiler#simplify-named-call in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_7021(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7021,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_eqp(C_retrieve(lf[147]),t2);
if(C_truep(t3)){
t4=(C_word)C_i_cadddr(((C_word*)t0)[5]);
t5=(C_truep(t4)?t4:C_retrieve(lf[142]));
if(C_truep(t5)){
t6=(C_truep(C_retrieve(lf[142]))?(C_word)C_i_cadddr(((C_word*)t0)[5]):(C_word)C_i_caddr(((C_word*)t0)[5]));
t7=(C_word)C_a_i_list(&a,1,t6);
t8=((C_word*)t0)[4];
t9=(C_word)C_a_i_record(&a,4,lf[37],lf[139],t7,t8);
t10=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t9);
t11=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_word)C_a_i_record(&a,4,lf[37],lf[16],lf[160],t10));}
else{
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}
else{
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k6960 in ##compiler#simplify-named-call in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_6962(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6962,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[6]);
t3=(C_truep(t2)?t2:C_retrieve(lf[142]));
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[6]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6977,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t6=(C_word)C_i_cdr(((C_word*)t0)[2]);
t7=t5;
f_6977(t7,(C_word)C_a_i_cons(&a,2,C_SCHEME_TRUE,t6));}
else{
t6=t5;
f_6977(t6,((C_word*)t0)[2]);}}
else{
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k6975 in k6960 in ##compiler#simplify-named-call in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_fcall f_6977(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6977,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6980,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],C_SCHEME_TRUE);
t4=(C_word)C_a_i_record(&a,4,lf[37],lf[159],t3,C_SCHEME_END_OF_LIST);
/* optimizer.scm: 962  cons* */
((C_proc5)C_retrieve_symbol_proc(lf[157]))(5,*((C_word*)lf[157]+1),t2,t4,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k6978 in k6975 in k6960 in ##compiler#simplify-named-call in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_6980(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6980,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[37],lf[16],((C_word*)t0)[2],t1));}

/* k6890 in ##compiler#simplify-named-call in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_6892(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6892,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(C_truep(t2)?t2:C_retrieve(lf[142]));
if(C_truep(t3)){
t4=(C_word)C_i_length(((C_word*)t0)[4]);
t5=(C_word)C_i_caddr(((C_word*)t0)[5]);
if(C_truep((C_word)C_fixnum_less_or_equal_p(t4,t5))){
t6=(C_word)C_eqp(t4,C_fix(1));
if(C_truep(t6)){
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)t0)[4]);
t8=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_record(&a,4,lf[37],lf[16],lf[158],t7));}
else{
t7=(C_word)C_i_car(((C_word*)t0)[5]);
t8=(C_word)C_a_i_list(&a,2,C_SCHEME_TRUE,t7);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6928,a[2]=t8,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6935,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=t9,tmp=(C_word)a,a+=5,tmp);
t11=(C_word)C_i_car(((C_word*)t0)[5]);
/* optimizer.scm: 952  varnode */
((C_proc3)C_retrieve_symbol_proc(lf[49]))(3,*((C_word*)lf[49]+1),t10,t11);}}
else{
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}
else{
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k6933 in k6890 in ##compiler#simplify-named-call in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_6935(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 952  cons* */
((C_proc5)C_retrieve_symbol_proc(lf[157]))(5,*((C_word*)lf[157]+1),((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k6926 in k6890 in ##compiler#simplify-named-call in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_6928(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6928,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[37],lf[16],((C_word*)t0)[2],t1));}

/* k6831 in ##compiler#simplify-named-call in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_6833(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6833,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_i_not(t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6845,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t3)){
t5=t4;
f_6845(t5,t3);}
else{
t5=(C_word)C_i_length(((C_word*)t0)[2]);
t6=(C_word)C_i_car(((C_word*)t0)[5]);
t7=t4;
f_6845(t7,(C_word)C_eqp(t5,t6));}}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k6843 in k6831 in ##compiler#simplify-named-call in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_fcall f_6845(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6845,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(C_word)C_a_i_list(&a,2,C_SCHEME_TRUE,t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6851,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6858,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* optimizer.scm: 937  varnode */
((C_proc3)C_retrieve_symbol_proc(lf[49]))(3,*((C_word*)lf[49]+1),t5,t6);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k6856 in k6843 in k6831 in ##compiler#simplify-named-call in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_6858(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 937  cons* */
((C_proc5)C_retrieve_symbol_proc(lf[157]))(5,*((C_word*)lf[157]+1),((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k6849 in k6843 in k6831 in ##compiler#simplify-named-call in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_6851(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6851,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[37],lf[16],((C_word*)t0)[2],t1));}

/* k6744 in ##compiler#simplify-named-call in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_6746(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6746,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_length(((C_word*)t0)[5]);
if(C_truep((C_word)C_and((C_word)C_fixnum_lessp(C_fix(0),t2),(C_word)C_fixnum_lessp(t2,C_fix(3))))){
t3=(C_word)C_i_car(((C_word*)t0)[4]);
t4=(C_word)C_a_i_list(&a,2,C_SCHEME_FALSE,t3);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6768,a[2]=((C_word*)t0)[4],a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t6=(C_word)C_i_car(((C_word*)t0)[4]);
/* optimizer.scm: 919  varnode */
((C_proc3)C_retrieve_symbol_proc(lf[49]))(3,*((C_word*)lf[49]+1),t5,t6);}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k6766 in k6744 in ##compiler#simplify-named-call in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_6768(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6768,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6776,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t2,a[7]=((C_word*)t0)[5],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t4=(C_word)C_i_cadr(((C_word*)t0)[2]);
/* optimizer.scm: 922  qnode */
((C_proc3)C_retrieve_symbol_proc(lf[39]))(3,*((C_word*)lf[39]+1),t3,t4);}

/* k6774 in k6766 in k6744 in ##compiler#simplify-named-call in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_6776(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6776,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6780,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_nullp(t3))){
t4=(C_word)C_i_caddr(((C_word*)t0)[2]);
/* optimizer.scm: 924  varnode */
((C_proc3)C_retrieve_symbol_proc(lf[49]))(3,*((C_word*)lf[49]+1),t2,t4);}
else{
t4=t2;
f_6780(2,t4,(C_word)C_i_cadr(((C_word*)t0)[3]));}}

/* k6778 in k6774 in k6766 in k6744 in ##compiler#simplify-named-call in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_6780(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6780,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,5,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[37],lf[16],((C_word*)t0)[2],t2));}

/* k6600 in ##compiler#simplify-named-call in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_6602(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6602,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_length(((C_word*)t0)[5]);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(2)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6618,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 890  qnode */
((C_proc3)C_retrieve_symbol_proc(lf[39]))(3,*((C_word*)lf[39]+1),t3,C_SCHEME_TRUE);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6624,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_retrieve(lf[142]))){
t4=(C_word)C_eqp(C_retrieve(lf[147]),lf[156]);
t5=t3;
f_6624(t5,(C_word)C_i_not(t4));}
else{
t4=t3;
f_6624(t4,C_SCHEME_FALSE);}}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k6622 in k6600 in ##compiler#simplify-named-call in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_fcall f_6624(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6624,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6627,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t1)){
t3=t2;
f_6627(t3,t1);}
else{
t3=(C_word)C_eqp(C_retrieve(lf[147]),lf[152]);
t4=(C_truep(t3)?(C_word)C_i_caddr(((C_word*)t0)[5]):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=t2;
f_6627(t5,t4);}
else{
t5=(C_word)C_eqp(C_retrieve(lf[147]),lf[155]);
t6=t2;
f_6627(t6,(C_truep(t5)?(C_word)C_i_cadddr(((C_word*)t0)[5]):C_SCHEME_FALSE));}}}

/* k6625 in k6622 in k6600 in ##compiler#simplify-named-call in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_fcall f_6627(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6627,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6630,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6686,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[30]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a6685 in k6625 in k6622 in k6600 in ##compiler#simplify-named-call in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_6686(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6686,3,t0,t1,t2);}
/* optimizer.scm: 894  gensym */
((C_proc2)C_retrieve_symbol_proc(lf[83]))(2,*((C_word*)lf[83]+1),t1);}

/* k6628 in k6625 in k6622 in k6600 in ##compiler#simplify-named-call in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_6630(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6630,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6633,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* map */
t3=*((C_word*)lf[30]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_retrieve(lf[49]),t1);}

/* k6631 in k6628 in k6625 in k6622 in k6600 in ##compiler#simplify-named-call in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_6633(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6633,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6638,tmp=(C_word)a,a+=2,tmp);
t3=(C_word)C_eqp(C_retrieve(lf[147]),lf[152]);
t4=(C_truep(t3)?(C_word)C_i_car(((C_word*)t0)[6]):(C_word)C_i_cadr(((C_word*)t0)[6]));
t5=(C_word)C_a_i_list(&a,1,t4);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6662,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6664,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 906  fold-boolean */
((C_proc4)C_retrieve_symbol_proc(lf[154]))(4,*((C_word*)lf[154]+1),t6,t7,t1);}

/* a6663 in k6631 in k6628 in k6625 in k6622 in k6600 in ##compiler#simplify-named-call in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_6664(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6664,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_list(&a,2,t2,t3);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[37],lf[139],((C_word*)t0)[2],t4));}

/* k6660 in k6631 in k6628 in k6625 in k6622 in k6600 in ##compiler#simplify-named-call in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_6662(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6662,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[6],t1);
t3=(C_word)C_a_i_record(&a,4,lf[37],lf[16],lf[153],t2);
/* optimizer.scm: 896  fold-right */
((C_proc6)C_retrieve_symbol_proc(lf[124]))(6,*((C_word*)lf[124]+1),((C_word*)t0)[5],((C_word*)t0)[4],t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a6637 in k6631 in k6628 in k6625 in k6622 in k6600 in ##compiler#simplify-named-call in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_6638(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6638,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_a_i_list(&a,1,t3);
t6=(C_word)C_a_i_list(&a,2,t2,t4);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_record(&a,4,lf[37],lf[12],t5,t6));}

/* k6616 in k6600 in ##compiler#simplify-named-call in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_6618(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6618,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[37],lf[16],lf[151],t2));}

/* k6579 in ##compiler#simplify-named-call in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_6581(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=t2;
((C_proc6)C_retrieve_proc(t3))(6,t3,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[6],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k6524 in ##compiler#simplify-named-call in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_6526(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6526,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6539,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6550,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_caddr(((C_word*)t0)[5]);
/* optimizer.scm: 876  qnode */
((C_proc3)C_retrieve_symbol_proc(lf[39]))(3,*((C_word*)lf[39]+1),t5,t6);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k6548 in k6524 in ##compiler#simplify-named-call in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_6550(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6550,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* optimizer.scm: 875  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[13]+1)))(4,*((C_word*)lf[13]+1),((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k6537 in k6524 in ##compiler#simplify-named-call in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_6539(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6539,2,t0,t1);}
t2=(C_word)C_a_i_record(&a,4,lf[37],lf[139],((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_record(&a,4,lf[37],lf[16],lf[150],t3));}

/* k6459 in ##compiler#simplify-named-call in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_6461(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6461,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(C_word)C_i_cadr(((C_word*)t0)[5]);
t5=(C_word)C_a_i_list(&a,1,t4);
t6=((C_word*)t0)[4];
t7=(C_word)C_a_i_record(&a,4,lf[37],lf[139],t5,t6);
t8=(C_word)C_a_i_list(&a,1,t7);
t9=(C_word)C_a_i_record(&a,4,lf[37],lf[139],t3,t8);
t10=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t9);
t11=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_word)C_a_i_record(&a,4,lf[37],lf[16],lf[149],t10));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k6372 in ##compiler#simplify-named-call in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_6374(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6374,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_length(((C_word*)t0)[5]);
t3=(C_word)C_eqp(C_fix(1),t2);
if(C_truep(t3)){
t4=(C_word)C_i_caddr(((C_word*)t0)[4]);
t5=(C_word)C_i_not(t4);
t6=(C_truep(t5)?t5:(C_word)C_eqp(t4,C_retrieve(lf[147])));
if(C_truep(t6)){
t7=(C_word)C_i_car(((C_word*)t0)[4]);
t8=(C_word)C_a_i_list(&a,1,t7);
t9=(C_word)C_i_car(((C_word*)t0)[5]);
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6416,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t8,a[5]=t9,tmp=(C_word)a,a+=6,tmp);
t11=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* optimizer.scm: 852  qnode */
((C_proc3)C_retrieve_symbol_proc(lf[39]))(3,*((C_word*)lf[39]+1),t10,t11);}
else{
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_SCHEME_FALSE);}}
else{
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k6414 in k6372 in ##compiler#simplify-named-call in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_6416(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6416,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_record(&a,4,lf[37],lf[139],((C_word*)t0)[4],t2);
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[37],lf[16],lf[148],t4));}

/* k6316 in ##compiler#simplify-named-call in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_6318(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6318,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_a_i_list(&a,2,C_SCHEME_FALSE,t2);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6331,a[2]=((C_word*)t0)[5],a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[5]);
/* optimizer.scm: 834  varnode */
((C_proc3)C_retrieve_symbol_proc(lf[49]))(3,*((C_word*)lf[49]+1),t4,t5);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k6329 in k6316 in ##compiler#simplify-named-call in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_6331(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6331,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6339,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t4=(C_word)C_i_cadr(((C_word*)t0)[2]);
/* optimizer.scm: 837  qnode */
((C_proc3)C_retrieve_symbol_proc(lf[39]))(3,*((C_word*)lf[39]+1),t3,t4);}

/* k6337 in k6329 in k6316 in ##compiler#simplify-named-call in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_6339(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6339,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[7]);
t3=(C_word)C_a_i_list(&a,5,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],t1,t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_record(&a,4,lf[37],lf[16],((C_word*)t0)[2],t3));}

/* k6278 in ##compiler#simplify-named-call in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_6280(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6280,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6290,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[2]);
/* optimizer.scm: 825  varnode */
((C_proc3)C_retrieve_symbol_proc(lf[49]))(3,*((C_word*)lf[49]+1),t2,t3);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k6288 in k6278 in ##compiler#simplify-named-call in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_6290(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6290,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[37],lf[16],lf[146],t2));}

/* k6180 in ##compiler#simplify-named-call in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_6182(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6182,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_caddr(((C_word*)t0)[6]);
t3=(C_truep(t2)?t2:C_retrieve(lf[142]));
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[5]);
t5=(C_word)C_i_cadddr(((C_word*)t0)[6]);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6207,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6210,a[2]=((C_word*)t0)[6],a[3]=t6,a[4]=((C_word*)t0)[5],a[5]=t5,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t5)){
t8=(C_word)C_slot(t4,C_fix(1));
t9=(C_word)C_eqp(lf[10],t8);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6239,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
t11=(C_word)C_slot(t4,C_fix(2));
t12=(C_word)C_i_car(t11);
/* optimizer.scm: 816  get */
((C_proc5)C_retrieve_symbol_proc(lf[26]))(5,*((C_word*)lf[26]+1),t10,((C_word*)t0)[2],t12,lf[145]);}
else{
t10=t7;
f_6210(t10,C_SCHEME_FALSE);}}
else{
t8=t7;
f_6210(t8,C_SCHEME_FALSE);}}
else{
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k6237 in k6180 in ##compiler#simplify-named-call in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_6239(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_6210(t2,(C_word)C_eqp(lf[144],t1));}

/* k6208 in k6180 in ##compiler#simplify-named-call in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_fcall f_6210(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6210,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[5]);
t3=((C_word*)t0)[4];
t4=((C_word*)t0)[3];
f_6207(t4,(C_word)C_a_i_record(&a,4,lf[37],lf[139],t2,t3));}
else{
t2=(C_word)C_i_cadr(((C_word*)t0)[2]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=((C_word*)t0)[4];
t5=((C_word*)t0)[3];
f_6207(t5,(C_word)C_a_i_record(&a,4,lf[37],lf[139],t3,t4));}}

/* k6205 in k6180 in ##compiler#simplify-named-call in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_fcall f_6207(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6207,NULL,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[37],lf[16],lf[143],t2));}

/* k6072 in ##compiler#simplify-named-call in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_6074(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6074,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6077,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_length(((C_word*)t0)[3]);
t4=(C_word)C_i_car(((C_word*)t0)[4]);
t5=(C_word)C_eqp(t3,t4);
if(C_truep(t5)){
t6=(C_word)C_i_car(((C_word*)t0)[3]);
t7=(C_word)C_i_cadr(((C_word*)t0)[3]);
t8=(C_word)C_slot(t6,C_fix(1));
t9=(C_word)C_eqp(lf[10],t8);
if(C_truep(t9)){
t10=(C_word)C_slot(t7,C_fix(1));
t11=(C_word)C_eqp(lf[10],t10);
if(C_truep(t11)){
t12=(C_word)C_slot(t6,C_fix(2));
t13=(C_word)C_slot(t7,C_fix(2));
if(C_truep((C_word)C_i_equalp(t12,t13))){
t14=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6137,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 795  qnode */
((C_proc3)C_retrieve_symbol_proc(lf[39]))(3,*((C_word*)lf[39]+1),t14,C_SCHEME_TRUE);}
else{
t14=t2;
f_6077(t14,C_SCHEME_FALSE);}}
else{
t12=t2;
f_6077(t12,C_SCHEME_FALSE);}}
else{
t10=t2;
f_6077(t10,C_SCHEME_FALSE);}}
else{
t6=t2;
f_6077(t6,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k6135 in k6072 in ##compiler#simplify-named-call in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_6137(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6137,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
f_6077(t3,(C_word)C_a_i_record(&a,4,lf[37],lf[16],lf[141],t2));}

/* k6075 in k6072 in ##compiler#simplify-named-call in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_fcall f_6077(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6077,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
if(C_truep(C_retrieve(lf[138]))){
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=((C_word*)t0)[3];
t5=(C_word)C_a_i_record(&a,4,lf[37],lf[139],t3,t4);
t6=(C_word)C_a_i_list(&a,2,((C_word*)t0)[2],t5);
t7=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_record(&a,4,lf[37],lf[16],lf[140],t6));}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}}

/* ##compiler#rewrite in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_5997(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_5997r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5997r(t0,t1,t2,t3);}}

static void C_ccall f_5997r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6001,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 773  ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[33]))(4,*((C_word*)lf[33]+1),t4,C_retrieve(lf[135]),t2);}

/* k5999 in ##compiler#rewrite in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_6001(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6001,2,t0,t1);}
t2=(C_truep(t1)?t1:C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6011,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
/* optimizer.scm: 774  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[13]+1)))(4,*((C_word*)lf[13]+1),t3,t2,t4);}

/* k6009 in k5999 in ##compiler#rewrite in k5993 in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_6011(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 774  ##sys#hash-table-set! */
((C_proc5)C_retrieve_symbol_proc(lf[121]))(5,*((C_word*)lf[121]+1),((C_word*)t0)[3],C_retrieve(lf[135]),((C_word*)t0)[2],t1);}

/* ##compiler#reorganize-recursive-bindings in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_5669(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5669,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5673,a[2]=t3,a[3]=t2,a[4]=t4,a[5]=t1,a[6]=t6,tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 685  map */
((C_proc5)C_retrieve_proc(*((C_word*)lf[133]+1)))(5,*((C_word*)lf[133]+1),t7,*((C_word*)lf[134]+1),t2,t3);}

/* k5671 in ##compiler#reorganize-recursive-bindings in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_5673(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5673,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5675,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5720,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5982,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 696  for-each */
((C_proc5)C_retrieve_proc(*((C_word*)lf[132]+1)))(5,*((C_word*)lf[132]+1),t3,t4,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5981 in k5671 in ##compiler#reorganize-recursive-bindings in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_5982(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5982,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5987,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5991,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 697  scan-used-variables */
((C_proc4)C_retrieve_symbol_proc(lf[131]))(4,*((C_word*)lf[131]+1),t5,t3,((C_word*)t0)[2]);}

/* k5989 in a5981 in k5671 in ##compiler#reorganize-recursive-bindings in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_5991(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 697  alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[28]))(5,*((C_word*)lf[28]+1),((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)((C_word*)t0)[2])[1]);}

/* k5985 in a5981 in k5671 in ##compiler#reorganize-recursive-bindings in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_5987(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k5718 in k5671 in ##compiler#reorganize-recursive-bindings in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_5720(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5720,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5723,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t3,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5924,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
/* for-each */
t8=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,t7,((C_word*)t0)[2]);}

/* a5923 in k5718 in k5671 in ##compiler#reorganize-recursive-bindings in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_5924(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5924,3,t0,t1,t2);}
if(C_truep((C_word)C_i_memq(t2,((C_word*)((C_word*)t0)[5])[1]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5934,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5956,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 706  filter */
((C_proc4)C_retrieve_symbol_proc(lf[129]))(4,*((C_word*)lf[129]+1),t3,t4,((C_word*)t0)[2]);}}

/* a5955 in a5923 in k5718 in k5671 in ##compiler#reorganize-recursive-bindings in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_5956(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5956,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,((C_word*)t0)[3]);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5969,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 707  find-path */
t5=((C_word*)t0)[2];
f_5675(t5,t4,((C_word*)t0)[3],t2);}}

/* k5967 in a5955 in a5923 in k5718 in k5671 in ##compiler#reorganize-recursive-bindings in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_5969(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* optimizer.scm: 707  find-path */
t2=((C_word*)t0)[5];
f_5675(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k5932 in a5923 in k5718 in k5671 in ##compiler#reorganize-recursive-bindings in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_5934(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5934,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5938,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5950,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 709  gensym */
((C_proc2)C_retrieve_symbol_proc(lf[83]))(2,*((C_word*)lf[83]+1),t3);}

/* k5948 in k5932 in a5923 in k5718 in k5671 in ##compiler#reorganize-recursive-bindings in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_5950(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5950,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[4]);
/* optimizer.scm: 709  alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[28]))(5,*((C_word*)lf[28]+1),((C_word*)t0)[3],t1,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* k5936 in k5932 in a5923 in k5718 in k5671 in ##compiler#reorganize-recursive-bindings in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_5938(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5938,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[6])+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5942,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_a_i_list(&a,1,((C_word*)t0)[3]);
/* optimizer.scm: 710  append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[13]+1)))(5,*((C_word*)lf[13]+1),t3,t4,((C_word*)t0)[2],((C_word*)((C_word*)t0)[5])[1]);}

/* k5940 in k5936 in k5932 in a5923 in k5718 in k5671 in ##compiler#reorganize-recursive-bindings in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_5942(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k5721 in k5718 in k5671 in ##compiler#reorganize-recursive-bindings in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_5723(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5723,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5726,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5865,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[7],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* for-each */
t6=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,((C_word*)((C_word*)t0)[7])[1]);}

/* a5864 in k5721 in k5718 in k5671 in ##compiler#reorganize-recursive-bindings in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_5865(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5865,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5872,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5908,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(t2);
/* optimizer.scm: 719  append-map */
((C_proc4)C_retrieve_symbol_proc(lf[130]))(4,*((C_word*)lf[130]+1),t4,t5,t6);}

/* a5907 in a5864 in k5721 in k5718 in k5671 in ##compiler#reorganize-recursive-bindings in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_5908(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5908,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5914,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 720  filter */
((C_proc4)C_retrieve_symbol_proc(lf[129]))(4,*((C_word*)lf[129]+1),t1,t3,((C_word*)t0)[2]);}

/* a5913 in a5907 in a5864 in k5721 in k5718 in k5671 in ##compiler#reorganize-recursive-bindings in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_5914(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5914,3,t0,t1,t2);}
/* optimizer.scm: 720  find-path */
t3=((C_word*)t0)[3];
f_5675(t3,t1,((C_word*)t0)[2],t2);}

/* k5870 in a5864 in k5721 in k5718 in k5671 in ##compiler#reorganize-recursive-bindings in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_5872(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5872,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5876,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5880,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5882,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 725  filter-map */
((C_proc4)C_retrieve_symbol_proc(lf[128]))(4,*((C_word*)lf[128]+1),t3,t4,((C_word*)((C_word*)t0)[2])[1]);}

/* a5881 in k5870 in a5864 in k5721 in k5718 in k5671 in ##compiler#reorganize-recursive-bindings in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_5882(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5882,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,((C_word*)t0)[3]);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5895,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_cdr(t2);
/* optimizer.scm: 726  lset<= */
((C_proc5)C_retrieve_symbol_proc(lf[127]))(5,*((C_word*)lf[127]+1),t4,*((C_word*)lf[36]+1),t5,((C_word*)t0)[2]);}}

/* k5893 in a5881 in k5870 in a5864 in k5721 in k5718 in k5671 in ##compiler#reorganize-recursive-bindings in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_5895(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?(C_word)C_i_car(((C_word*)t0)[2]):C_SCHEME_FALSE));}

/* k5878 in k5870 in a5864 in k5721 in k5718 in k5671 in ##compiler#reorganize-recursive-bindings in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_5880(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 723  alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[28]))(5,*((C_word*)lf[28]+1),((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)((C_word*)t0)[2])[1]);}

/* k5874 in k5870 in a5864 in k5721 in k5718 in k5671 in ##compiler#reorganize-recursive-bindings in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_5876(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k5724 in k5721 in k5718 in k5671 in ##compiler#reorganize-recursive-bindings in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_5726(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5726,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5729,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 732  topological-sort */
((C_proc4)C_retrieve_symbol_proc(lf[126]))(4,*((C_word*)lf[126]+1),t2,((C_word*)((C_word*)t0)[2])[1],*((C_word*)lf[36]+1));}

/* k5727 in k5724 in k5721 in k5718 in k5671 in ##compiler#reorganize-recursive-bindings in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_5729(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5729,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5732,a[2]=((C_word*)t0)[6],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5749,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 737  fold */
((C_proc5)C_retrieve_symbol_proc(lf[125]))(5,*((C_word*)lf[125]+1),t4,t5,((C_word*)t0)[2],t1);}

/* a5748 in k5727 in k5724 in k5721 in k5718 in k5671 in ##compiler#reorganize-recursive-bindings in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_5749(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5749,4,t0,t1,t2,t3);}
t4=(C_word)C_i_assq(t2,((C_word*)((C_word*)t0)[5])[1]);
t5=(C_word)C_i_cdr(t4);
t6=(C_word)C_i_car(t5);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5762,a[2]=t5,a[3]=t1,a[4]=t3,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t6,tmp=(C_word)a,a+=8,tmp);
t8=(C_word)C_i_cdr(t5);
if(C_truep((C_word)C_i_nullp(t8))){
t9=(C_word)C_i_assq(t6,((C_word*)((C_word*)t0)[2])[1]);
t10=(C_word)C_i_cdr(t9);
t11=(C_word)C_i_memq(t6,t10);
t12=t7;
f_5762(t12,(C_word)C_i_not(t11));}
else{
t9=t7;
f_5762(t9,C_SCHEME_FALSE);}}

/* k5760 in a5748 in k5727 in k5724 in k5721 in k5718 in k5671 in ##compiler#reorganize-recursive-bindings in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_fcall f_5762(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5762,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],((C_word*)((C_word*)t0)[6])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t4=(C_word)C_i_assq(((C_word*)t0)[7],((C_word*)t0)[5]);
t5=(C_word)C_i_cdr(t4);
t6=(C_word)C_a_i_list(&a,2,t5,((C_word*)t0)[4]);
t7=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_record(&a,4,lf[37],lf[12],((C_word*)t0)[2],t6));}
else{
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5785,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5803,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5805,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 751  fold-right */
((C_proc5)C_retrieve_symbol_proc(lf[124]))(5,*((C_word*)lf[124]+1),t3,t4,((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* a5804 in k5760 in a5748 in k5727 in k5724 in k5721 in k5718 in k5671 in ##compiler#reorganize-recursive-bindings in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_5805(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5805,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5837,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 754  gensym */
((C_proc2)C_retrieve_symbol_proc(lf[83]))(2,*((C_word*)lf[83]+1),t4);}

/* k5835 in a5804 in k5760 in a5748 in k5727 in k5724 in k5721 in k5718 in k5671 in ##compiler#reorganize-recursive-bindings in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_5837(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5837,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(C_word)C_a_i_list(&a,1,((C_word*)t0)[5]);
t4=(C_word)C_i_assq(((C_word*)t0)[5],((C_word*)t0)[4]);
t5=(C_word)C_i_cdr(t4);
t6=(C_word)C_a_i_list(&a,1,t5);
t7=(C_word)C_a_i_record(&a,4,lf[37],lf[17],t3,t6);
t8=(C_word)C_a_i_list(&a,2,t7,((C_word*)t0)[3]);
t9=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_a_i_record(&a,4,lf[37],lf[12],t2,t8));}

/* k5801 in k5760 in a5748 in k5727 in k5724 in k5721 in k5718 in k5671 in ##compiler#reorganize-recursive-bindings in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_5803(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 746  fold-right */
((C_proc5)C_retrieve_symbol_proc(lf[124]))(5,*((C_word*)lf[124]+1),((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* a5784 in k5760 in a5748 in k5727 in k5724 in k5721 in k5718 in k5671 in ##compiler#reorganize-recursive-bindings in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_5785(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[19],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5785,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_list(&a,1,t2);
t5=(C_word)C_a_i_record(&a,4,lf[37],lf[69],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_list(&a,2,t5,t3);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_record(&a,4,lf[37],lf[12],t4,t6));}

/* k5730 in k5727 in k5724 in k5721 in k5718 in k5671 in ##compiler#reorganize-recursive-bindings in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_5732(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5732,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(((C_word*)((C_word*)t0)[3])[1]))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5741,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 763  debugging */
((C_proc5)C_retrieve_symbol_proc(lf[7]))(5,*((C_word*)lf[7]+1),t2,lf[8],lf[123],((C_word*)((C_word*)t0)[3])[1]);}
else{
/* optimizer.scm: 765  values */
C_values(4,0,((C_word*)t0)[2],t1,C_SCHEME_FALSE);}}

/* k5739 in k5730 in k5727 in k5724 in k5721 in k5718 in k5671 in ##compiler#reorganize-recursive-bindings in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_5741(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 764  values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_TRUE);}

/* find-path in k5671 in ##compiler#reorganize-recursive-bindings in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_fcall f_5675(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5675,NULL,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5681,a[2]=t5,a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_5681(t7,t1,t2,C_SCHEME_END_OF_LIST);}

/* find in find-path in k5671 in ##compiler#reorganize-recursive-bindings in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_fcall f_5681(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5681,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_memq(t2,t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(C_word)C_i_assq(t2,((C_word*)((C_word*)t0)[4])[1]);
t5=(C_word)C_i_cdr(t4);
t6=(C_word)C_i_memq(((C_word*)t0)[3],t5);
if(C_truep(t6)){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t7=(C_word)C_a_i_cons(&a,2,t2,t3);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5705,a[2]=t7,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 693  any */
((C_proc4)C_retrieve_symbol_proc(lf[32]))(4,*((C_word*)lf[32]+1),t1,t8,t5);}}}

/* a5704 in find in find-path in k5671 in ##compiler#reorganize-recursive-bindings in k5665 in k5662 in k5659 in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_5705(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5705,3,t0,t1,t2);}
/* optimizer.scm: 693  find */
t3=((C_word*)((C_word*)t0)[3])[1];
f_5681(t3,t1,t2,((C_word*)t0)[2]);}

/* register-simplifications in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_5654(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3r,(void*)f_5654r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5654r(t0,t1,t2,t3);}}

static void C_ccall f_5654r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
/* optimizer.scm: 464  ##sys#hash-table-set! */
((C_proc5)C_retrieve_symbol_proc(lf[121]))(5,*((C_word*)lf[121]+1),t1,C_retrieve(lf[23]),t2,t3);}

/* ##compiler#perform-pre-optimization! in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_5413(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[17],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5413,4,t0,t1,t2,t3);}
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_fix(0);
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5416,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5420,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t10=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5427,a[2]=t9,a[3]=t8,a[4]=t7,a[5]=t5,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 416  debugging */
((C_proc4)C_retrieve_symbol_proc(lf[7]))(4,*((C_word*)lf[7]+1),t10,lf[21],lf[119]);}

/* k5425 in ##compiler#perform-pre-optimization! in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_5427(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5427,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5430,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5442,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[45]))(4,*((C_word*)lf[45]+1),t3,lf[117],lf[46]);}

/* k5440 in k5425 in ##compiler#perform-pre-optimization! in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_5442(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5442,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5447,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5649,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 455  test */
t4=((C_word*)t0)[3];
f_5420(t4,t3,lf[117],lf[118]);}
else{
t2=((C_word*)t0)[2];
f_5430(2,t2,C_SCHEME_UNDEFINED);}}

/* k5647 in k5440 in k5425 in ##compiler#perform-pre-optimization! in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_5649(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?t1:C_SCHEME_END_OF_LIST);
/* for-each */
t3=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* a5446 in k5440 in k5425 in ##compiler#perform-pre-optimization! in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_5447(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[14],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5447,3,t0,t1,t2);}
t3=(C_word)C_i_cdr(t2);
t4=(C_word)C_slot(t3,C_fix(3));
t5=(C_word)C_i_cadr(t4);
t6=(C_word)C_slot(t5,C_fix(2));
t7=(C_word)C_i_car(t6);
t8=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5460,a[2]=t7,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t4,a[6]=((C_word*)t0)[3],a[7]=t1,a[8]=((C_word*)t0)[4],tmp=(C_word)a,a+=9,tmp);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5638,a[2]=t7,a[3]=((C_word*)t0)[2],a[4]=t8,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 425  test */
t10=((C_word*)t0)[2];
f_5420(t10,t9,t7,lf[76]);}

/* k5636 in a5446 in k5440 in k5425 in ##compiler#perform-pre-optimization! in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_5638(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_5460(2,t2,C_SCHEME_FALSE);}
else{
/* optimizer.scm: 425  test */
t2=((C_word*)t0)[3];
f_5420(t2,((C_word*)t0)[4],((C_word*)t0)[2],lf[47]);}}

/* k5458 in a5446 in k5440 in k5425 in ##compiler#perform-pre-optimization! in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_5460(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5460,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5463,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 426  test */
t3=((C_word*)t0)[3];
f_5420(t3,t2,((C_word*)t0)[2],lf[75]);}

/* k5461 in k5458 in a5446 in k5440 in k5425 in ##compiler#perform-pre-optimization! in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_5463(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5463,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5469,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)t0)[8])){
if(C_truep(t1)){
t3=(C_word)C_i_length(t1);
t4=(C_word)C_eqp(C_fix(1),t3);
if(C_truep(t4)){
t5=(C_word)C_i_length(((C_word*)t0)[4]);
t6=(C_word)C_eqp(C_fix(3),t5);
if(C_truep(t6)){
t7=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
t8=t2;
f_5469(t8,(C_word)C_eqp(lf[55],t7));}
else{
t7=t2;
f_5469(t7,C_SCHEME_FALSE);}}
else{
t5=t2;
f_5469(t5,C_SCHEME_FALSE);}}
else{
t3=t2;
f_5469(t3,C_SCHEME_FALSE);}}
else{
t3=t2;
f_5469(t3,C_SCHEME_FALSE);}}

/* k5467 in k5461 in k5458 in a5446 in k5440 in k5425 in ##compiler#perform-pre-optimization! in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_fcall f_5469(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5469,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[8],C_fix(2));
t3=(C_word)C_i_caddr(t2);
t4=(C_word)C_slot(((C_word*)t0)[8],C_fix(3));
t5=(C_word)C_i_car(t4);
t6=(C_word)C_slot(t5,C_fix(3));
t7=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5484,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t6,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=t5,a[10]=t3,tmp=(C_word)a,a+=11,tmp);
if(C_truep((C_word)C_i_listp(t3))){
t8=(C_word)C_i_cdr(t3);
t9=t7;
f_5484(t9,(C_word)C_i_nullp(t8));}
else{
t8=t7;
f_5484(t8,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k5482 in k5467 in k5461 in k5458 in a5446 in k5440 in k5425 in ##compiler#perform-pre-optimization! in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_fcall f_5484(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5484,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[10]);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5490,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm: 437  test */
t4=((C_word*)t0)[2];
f_5420(t4,t3,t2,lf[75]);}
else{
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k5488 in k5482 in k5467 in k5461 in k5458 in a5446 in k5440 in k5425 in ##compiler#perform-pre-optimization! in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_5490(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5490,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5496,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
if(C_truep(t1)){
t3=(C_word)C_i_length(t1);
t4=(C_word)C_eqp(C_fix(1),t3);
if(C_truep(t4)){
t5=(C_word)C_slot(((C_word*)t0)[9],C_fix(1));
t6=t2;
f_5496(t6,(C_word)C_eqp(lf[11],t5));}
else{
t5=t2;
f_5496(t5,C_SCHEME_FALSE);}}
else{
t3=t2;
f_5496(t3,C_SCHEME_FALSE);}}

/* k5494 in k5488 in k5482 in k5467 in k5461 in k5458 in a5446 in k5440 in k5425 in ##compiler#perform-pre-optimization! in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_fcall f_5496(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5496,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[9],C_fix(3));
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5505,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t5=(C_word)C_slot(t3,C_fix(1));
t6=(C_word)C_eqp(lf[10],t5);
if(C_truep(t6)){
t7=(C_word)C_slot(t3,C_fix(2));
t8=(C_word)C_i_car(t7);
t9=t4;
f_5505(t9,(C_word)C_eqp(((C_word*)t0)[2],t8));}
else{
t7=t4;
f_5505(t7,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k5503 in k5494 in k5488 in k5482 in k5467 in k5461 in k5458 in a5446 in k5440 in k5425 in ##compiler#perform-pre-optimization! in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_fcall f_5505(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5505,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[8])[1],C_fix(1));
t3=C_mutate(((C_word *)((C_word*)t0)[8])+1,t2);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5512,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 449  node-parameters-set! */
((C_proc4)C_retrieve_symbol_proc(lf[115]))(4,*((C_word*)lf[115]+1),t4,((C_word*)t0)[2],lf[116]);}
else{
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k5510 in k5503 in k5494 in k5488 in k5482 in k5467 in k5461 in k5458 in a5446 in k5440 in k5425 in ##compiler#perform-pre-optimization! in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_5512(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5512,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5515,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* optimizer.scm: 450  node-subexpressions-set! */
((C_proc4)C_retrieve_symbol_proc(lf[113]))(4,*((C_word*)lf[113]+1),t2,((C_word*)t0)[2],t3);}

/* k5513 in k5510 in k5503 in k5494 in k5488 in k5482 in k5467 in k5461 in k5458 in a5446 in k5440 in k5425 in ##compiler#perform-pre-optimization! in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_5515(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5515,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5518,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5533,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* optimizer.scm: 453  reverse */
((C_proc3)C_retrieve_proc(*((C_word*)lf[114]+1)))(3,*((C_word*)lf[114]+1),t4,t5);}

/* k5531 in k5513 in k5510 in k5503 in k5494 in k5488 in k5482 in k5467 in k5461 in k5458 in a5446 in k5440 in k5425 in ##compiler#perform-pre-optimization! in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_5533(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5533,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
/* optimizer.scm: 451  node-subexpressions-set! */
((C_proc4)C_retrieve_symbol_proc(lf[113]))(4,*((C_word*)lf[113]+1),((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k5516 in k5513 in k5510 in k5503 in k5494 in k5488 in k5482 in k5467 in k5461 in k5458 in a5446 in k5440 in k5425 in ##compiler#perform-pre-optimization! in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_5518(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 454  touch */
t2=((C_word*)t0)[3];
((C_proc2)C_retrieve_proc(t2))(2,t2,f_5416(((C_word*)t0)[2]));}

/* k5428 in k5425 in ##compiler#perform-pre-optimization! in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_5430(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5430,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5433,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)((C_word*)t0)[2])[1];
if(C_truep((C_word)C_fixnum_greaterp(t3,C_fix(0)))){
/* optimizer.scm: 457  debugging */
((C_proc5)C_retrieve_symbol_proc(lf[7]))(5,*((C_word*)lf[7]+1),t2,lf[8],lf[112],((C_word*)((C_word*)t0)[2])[1]);}
else{
t4=t2;
f_5433(2,t4,C_SCHEME_UNDEFINED);}}

/* k5431 in k5428 in k5425 in ##compiler#perform-pre-optimization! in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_5433(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* test in ##compiler#perform-pre-optimization! in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_fcall f_5420(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5420,NULL,4,t0,t1,t2,t3);}
/* optimizer.scm: 414  get */
((C_proc5)C_retrieve_symbol_proc(lf[26]))(5,*((C_word*)lf[26]+1),t1,((C_word*)t0)[2],t2,t3);}

/* touch in ##compiler#perform-pre-optimization! in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static C_word C_fcall f_5416(C_word t0){
C_word tmp;
C_word t1;
C_word t2;
C_stack_check;
t1=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_TRUE);
return(C_SCHEME_TRUE);}

/* ##compiler#perform-high-level-optimizations in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_3931(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word ab[66],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3931,4,t0,t1,t2,t3);}
t4=C_fix(0);
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_fix(0);
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_fix(0);
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_SCHEME_END_OF_LIST;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_SCHEME_END_OF_LIST;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_SCHEME_FALSE;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3934,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t17=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3940,tmp=(C_word)a,a+=2,tmp);
t18=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3960,a[2]=t15,tmp=(C_word)a,a+=3,tmp);
t19=C_SCHEME_UNDEFINED;
t20=(*a=C_VECTOR_TYPE|1,a[1]=t19,tmp=(C_word)a,a+=2,tmp);
t21=C_set_block_item(t20,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3964,a[2]=t3,a[3]=t20,a[4]=t18,a[5]=t13,tmp=(C_word)a,a+=6,tmp));
t22=C_SCHEME_UNDEFINED;
t23=(*a=C_VECTOR_TYPE|1,a[1]=t22,tmp=(C_word)a,a+=2,tmp);
t24=C_SCHEME_UNDEFINED;
t25=(*a=C_VECTOR_TYPE|1,a[1]=t24,tmp=(C_word)a,a+=2,tmp);
t26=C_SCHEME_UNDEFINED;
t27=(*a=C_VECTOR_TYPE|1,a[1]=t26,tmp=(C_word)a,a+=2,tmp);
t28=C_set_block_item(t23,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4056,a[2]=t25,a[3]=t17,a[4]=t23,a[5]=t18,a[6]=t7,a[7]=t20,a[8]=t15,tmp=(C_word)a,a+=9,tmp));
t29=C_set_block_item(t25,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4270,a[2]=t11,a[3]=t3,a[4]=t27,a[5]=t23,a[6]=t5,a[7]=t9,a[8]=t16,a[9]=t18,tmp=(C_word)a,a+=10,tmp));
t30=C_set_block_item(t27,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5298,a[2]=t23,tmp=(C_word)a,a+=3,tmp));
t31=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5317,a[2]=t23,a[3]=t13,a[4]=t9,a[5]=t5,a[6]=t7,a[7]=t15,a[8]=t2,a[9]=t1,tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm: 382  perform-pre-optimization! */
((C_proc4)C_retrieve_symbol_proc(lf[111]))(4,*((C_word*)lf[111]+1),t31,t2,t3);}

/* k5315 in ##compiler#perform-high-level-optimizations in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_5317(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5317,2,t0,t1);}
if(C_truep(t1)){
/* optimizer.scm: 383  values */
C_values(4,0,((C_word*)t0)[9],((C_word*)t0)[8],C_SCHEME_TRUE);}
else{
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5323,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm: 385  debugging */
((C_proc4)C_retrieve_symbol_proc(lf[7]))(4,*((C_word*)lf[7]+1),t2,lf[21],lf[110]);}}

/* k5321 in k5315 in ##compiler#perform-high-level-optimizations in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_5323(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5323,2,t0,t1);}
t2=C_set_block_item(lf[24] /* simplified-ops */,0,C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5327,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 387  walk */
t4=((C_word*)((C_word*)t0)[3])[1];
f_4056(3,t4,t3,((C_word*)t0)[2]);}

/* k5325 in k5321 in k5315 in ##compiler#perform-high-level-optimizations in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_5327(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5327,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5330,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)((C_word*)t0)[2])[1]))){
/* optimizer.scm: 388  debugging */
((C_proc5)C_retrieve_symbol_proc(lf[7]))(5,*((C_word*)lf[7]+1),t2,lf[8],lf[109],((C_word*)((C_word*)t0)[2])[1]);}
else{
t3=t2;
f_5330(2,t3,C_SCHEME_UNDEFINED);}}

/* k5328 in k5325 in k5321 in k5315 in ##compiler#perform-high-level-optimizations in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_5330(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5330,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5333,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5366,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(C_retrieve(lf[24])))){
/* optimizer.scm: 389  debugging */
((C_proc4)C_retrieve_symbol_proc(lf[7]))(4,*((C_word*)lf[7]+1),t3,lf[8],lf[108]);}
else{
t4=t3;
f_5366(2,t4,C_SCHEME_FALSE);}}

/* k5364 in k5328 in k5325 in k5321 in k5315 in ##compiler#perform-high-level-optimizations in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_5366(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5366,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5371,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t3=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t2,C_retrieve(lf[24]));}
else{
t2=((C_word*)t0)[2];
f_5333(2,t2,C_SCHEME_UNDEFINED);}}

/* a5370 in k5364 in k5328 in k5325 in k5321 in k5315 in ##compiler#perform-high-level-optimizations in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_5371(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5371,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5375,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_car(t2);
/* optimizer.scm: 392  print* */
((C_proc4)C_retrieve_proc(*((C_word*)lf[107]+1)))(4,*((C_word*)lf[107]+1),t3,C_make_character(9),t4);}

/* k5373 in a5370 in k5364 in k5328 in k5325 in k5321 in k5315 in ##compiler#perform-high-level-optimizations in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_5375(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_fixnum_greaterp(t2,C_fix(1)))){
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* optimizer.scm: 394  print */
((C_proc4)C_retrieve_proc(*((C_word*)lf[105]+1)))(4,*((C_word*)lf[105]+1),((C_word*)t0)[2],C_make_character(9),t3);}
else{
/* optimizer.scm: 395  newline */
((C_proc2)C_retrieve_proc(*((C_word*)lf[106]+1)))(2,*((C_word*)lf[106]+1),((C_word*)t0)[2]);}}

/* k5331 in k5328 in k5325 in k5321 in k5315 in ##compiler#perform-high-level-optimizations in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_5333(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5333,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5336,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=((C_word*)((C_word*)t0)[2])[1];
if(C_truep((C_word)C_fixnum_greaterp(t3,C_fix(0)))){
/* optimizer.scm: 397  debugging */
((C_proc5)C_retrieve_symbol_proc(lf[7]))(5,*((C_word*)lf[7]+1),t2,lf[8],lf[104],((C_word*)((C_word*)t0)[2])[1]);}
else{
t4=t2;
f_5336(2,t4,C_SCHEME_UNDEFINED);}}

/* k5334 in k5331 in k5328 in k5325 in k5321 in k5315 in ##compiler#perform-high-level-optimizations in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_5336(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5336,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5339,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=((C_word*)((C_word*)t0)[2])[1];
if(C_truep((C_word)C_fixnum_greaterp(t3,C_fix(0)))){
/* optimizer.scm: 398  debugging */
((C_proc5)C_retrieve_symbol_proc(lf[7]))(5,*((C_word*)lf[7]+1),t2,lf[8],lf[103],((C_word*)((C_word*)t0)[2])[1]);}
else{
t4=t2;
f_5339(2,t4,C_SCHEME_UNDEFINED);}}

/* k5337 in k5334 in k5331 in k5328 in k5325 in k5321 in k5315 in ##compiler#perform-high-level-optimizations in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_5339(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5339,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5342,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)((C_word*)t0)[2])[1];
if(C_truep((C_word)C_fixnum_greaterp(t3,C_fix(0)))){
/* optimizer.scm: 399  debugging */
((C_proc5)C_retrieve_symbol_proc(lf[7]))(5,*((C_word*)lf[7]+1),t2,lf[8],lf[102],((C_word*)((C_word*)t0)[2])[1]);}
else{
t4=t2;
f_5342(2,t4,C_SCHEME_UNDEFINED);}}

/* k5340 in k5337 in k5334 in k5331 in k5328 in k5325 in k5321 in k5315 in ##compiler#perform-high-level-optimizations in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_5342(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 400  values */
C_values(4,0,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* walk-generic in ##compiler#perform-high-level-optimizations in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_fcall f_5298(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5298,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5302,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* map */
t7=*((C_word*)lf[30]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,((C_word*)((C_word*)t0)[2])[1],t5);}

/* k5300 in walk-generic in ##compiler#perform-high-level-optimizations in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_5302(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5302,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5308,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 378  every */
((C_proc5)C_retrieve_symbol_proc(lf[43]))(5,*((C_word*)lf[43]+1),t2,*((C_word*)lf[36]+1),((C_word*)t0)[2],t1);}

/* k5306 in k5300 in walk-generic in ##compiler#perform-high-level-optimizations in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_5308(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5308,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[5]);}
else{
t2=((C_word*)t0)[4];
t3=((C_word*)t0)[3];
t4=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_record(&a,4,lf[37],t2,t3,((C_word*)t0)[2]));}}

/* walk1 in ##compiler#perform-high-level-optimizations in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_fcall f_4270(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4270,NULL,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(3));
t5=t2;
t6=(C_word)C_slot(t5,C_fix(2));
t7=t2;
t8=(C_word)C_slot(t7,C_fix(1));
t9=(C_word)C_eqp(t8,lf[10]);
if(C_truep(t9)){
t10=(C_word)C_i_car(t6);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4295,a[2]=((C_word*)t0)[7],a[3]=t6,a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=t12,tmp=(C_word)a,a+=7,tmp));
t14=((C_word*)t12)[1];
f_4295(t14,t1,t10);}
else{
t10=(C_word)C_eqp(t8,lf[12]);
if(C_truep(t10)){
t11=(C_word)C_i_car(t6);
t12=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4370,a[2]=t11,a[3]=((C_word*)t0)[8],a[4]=t6,a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=t4,a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm: 202  test */
t13=((C_word*)t0)[8];
f_3934(t13,t12,t11,lf[54]);}
else{
t11=(C_word)C_eqp(t8,lf[55]);
if(C_truep(t11)){
t12=(C_word)C_i_caddr(t6);
t13=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4421,a[2]=t8,a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=t12,a[6]=t1,a[7]=((C_word*)t0)[5],a[8]=t4,a[9]=t6,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[8],tmp=(C_word)a,a+=12,tmp);
t14=(C_word)C_i_car(t6);
/* optimizer.scm: 211  test */
t15=((C_word*)t0)[8];
f_3934(t15,t13,t14,lf[64]);}
else{
t12=(C_word)C_eqp(t8,lf[16]);
if(C_truep(t12)){
t13=(C_word)C_i_car(t4);
t14=(C_word)C_slot(t13,C_fix(1));
t15=(C_word)C_eqp(t14,lf[10]);
if(C_truep(t15)){
t16=(C_word)C_slot(t13,C_fix(2));
t17=(C_word)C_i_car(t16);
t18=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_4597,a[2]=((C_word*)t0)[2],a[3]=t13,a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[3],a[6]=t6,a[7]=t8,a[8]=t2,a[9]=((C_word*)t0)[4],a[10]=t17,a[11]=t1,a[12]=((C_word*)t0)[5],a[13]=((C_word*)t0)[9],a[14]=t4,tmp=(C_word)a,a+=15,tmp);
t19=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5164,a[2]=t17,a[3]=((C_word*)t0)[8],a[4]=t18,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 249  test */
t20=((C_word*)t0)[8];
f_3934(t20,t19,t17,lf[76]);}
else{
t16=(C_word)C_eqp(t14,lf[55]);
if(C_truep(t16)){
if(C_truep((C_word)C_i_car(t6))){
/* optimizer.scm: 356  walk-generic */
t17=((C_word*)((C_word*)t0)[4])[1];
f_5298(t17,t1,t2,t8,t6,t4);}
else{
t17=(C_word)C_i_cdr(t6);
t18=(C_word)C_a_i_cons(&a,2,C_SCHEME_TRUE,t17);
t19=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5189,a[2]=t18,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* map */
t20=*((C_word*)lf[30]+1);
((C_proc4)(void*)(*((C_word*)t20+1)))(4,t20,t19,((C_word*)((C_word*)t0)[5])[1],t4);}}
else{
/* optimizer.scm: 358  walk-generic */
t17=((C_word*)((C_word*)t0)[4])[1];
f_5298(t17,t1,t2,t8,t6,t4);}}}
else{
t13=(C_word)C_eqp(t8,lf[17]);
if(C_truep(t13)){
t14=(C_word)C_i_car(t6);
t15=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5214,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=t4,a[6]=t6,a[7]=t14,a[8]=t1,a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm: 362  test */
t16=((C_word*)t0)[8];
f_3934(t16,t15,t14,lf[53]);}
else{
/* optimizer.scm: 374  walk-generic */
t14=((C_word*)((C_word*)t0)[4])[1];
f_5298(t14,t1,t2,t8,t6,t4);}}}}}}

/* k5212 in walk1 in ##compiler#perform-high-level-optimizations in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_5214(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5214,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5217,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
if(C_truep(t1)){
t3=t2;
f_5217(2,t3,t1);}
else{
/* optimizer.scm: 362  test */
t3=((C_word*)t0)[2];
f_3934(t3,t2,((C_word*)t0)[7],lf[51]);}}

/* k5215 in k5212 in walk1 in ##compiler#perform-high-level-optimizations in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_5217(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5217,2,t0,t1);}
if(C_truep(t1)){
t2=f_3960(((C_word*)t0)[9]);
t3=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[37],lf[69],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST));}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5229,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5290,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 365  test */
t4=((C_word*)t0)[2];
f_3934(t4,t3,((C_word*)t0)[7],lf[101]);}}

/* k5288 in k5215 in k5212 in walk1 in ##compiler#perform-high-level-optimizations in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_5290(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5290,2,t0,t1);}
t2=(C_word)C_i_not(t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5258,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t2)){
t4=t3;
f_5258(t4,t2);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5286,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 366  variable-visible? */
((C_proc3)C_retrieve_symbol_proc(lf[100]))(3,*((C_word*)lf[100]+1),t4,((C_word*)t0)[2]);}}

/* k5284 in k5288 in k5215 in k5212 in walk1 in ##compiler#perform-high-level-optimizations in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_5286(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_5258(t2,(C_word)C_i_not(t1));}

/* k5256 in k5288 in k5215 in k5212 in walk1 in ##compiler#perform-high-level-optimizations in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_fcall f_5258(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5258,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5279,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 367  test */
t3=((C_word*)t0)[3];
f_3934(t3,t2,((C_word*)t0)[2],lf[75]);}
else{
t2=((C_word*)t0)[6];
f_5229(t2,C_SCHEME_FALSE);}}

/* k5277 in k5256 in k5288 in k5215 in k5212 in walk1 in ##compiler#perform-high-level-optimizations in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_5279(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5279,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_5229(t2,C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5271,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
/* optimizer.scm: 368  expression-has-side-effects? */
((C_proc4)C_retrieve_symbol_proc(lf[73]))(4,*((C_word*)lf[73]+1),t2,t3,((C_word*)t0)[2]);}}

/* k5269 in k5277 in k5256 in k5288 in k5215 in k5212 in walk1 in ##compiler#perform-high-level-optimizations in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_5271(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_5229(t2,(C_word)C_i_not(t1));}

/* k5227 in k5215 in k5212 in walk1 in ##compiler#perform-high-level-optimizations in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_fcall f_5229(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5229,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=f_3960(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5235,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 370  debugging */
((C_proc5)C_retrieve_symbol_proc(lf[7]))(5,*((C_word*)lf[7]+1),t3,lf[8],lf[99],((C_word*)t0)[5]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5248,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
/* optimizer.scm: 372  walk */
t4=((C_word*)((C_word*)t0)[2])[1];
f_4056(3,t4,t2,t3);}}

/* k5246 in k5227 in k5215 in k5212 in walk1 in ##compiler#perform-high-level-optimizations in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_5248(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5248,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[37],lf[17],((C_word*)t0)[2],t2));}

/* k5233 in k5227 in k5215 in k5212 in walk1 in ##compiler#perform-high-level-optimizations in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_5235(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5235,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[37],lf[69],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST));}

/* k5187 in walk1 in ##compiler#perform-high-level-optimizations in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_5189(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5189,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[37],lf[16],((C_word*)t0)[2],t1));}

/* k5162 in walk1 in ##compiler#perform-high-level-optimizations in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_5164(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5164,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_4597(2,t2,C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5154,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 250  test */
t3=((C_word*)t0)[3];
f_3934(t3,t2,((C_word*)t0)[2],lf[47]);}}

/* k5152 in k5162 in walk1 in ##compiler#perform-high-level-optimizations in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_5154(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_4597(2,t2,t1);}
else{
/* optimizer.scm: 251  test */
t2=((C_word*)t0)[3];
f_3934(t2,((C_word*)t0)[4],((C_word*)t0)[2],lf[98]);}}

/* k4595 in walk1 in ##compiler#perform-high-level-optimizations in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_4597(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4597,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[14]);
t3=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_4606,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[14],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=t2,a[13]=((C_word*)t0)[11],a[14]=((C_word*)t0)[12],a[15]=((C_word*)t0)[13],a[16]=t1,tmp=(C_word)a,a+=17,tmp);
/* optimizer.scm: 253  test */
t4=((C_word*)t0)[4];
f_3934(t4,t3,((C_word*)t0)[10],lf[53]);}

/* k4604 in k4595 in walk1 in ##compiler#perform-high-level-optimizations in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_4606(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4606,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[16],C_fix(2));
t3=(C_word)C_i_caddr(t2);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4615,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[12],a[4]=t3,a[5]=((C_word*)t0)[16],a[6]=((C_word*)t0)[13],a[7]=((C_word*)t0)[14],a[8]=((C_word*)t0)[15],tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 256  check-signature */
((C_proc5)C_retrieve_symbol_proc(lf[67]))(5,*((C_word*)lf[67]+1),t4,((C_word*)t0)[11],((C_word*)t0)[12],t3);}
else{
if(C_truep((C_word)C_i_memq(((C_word*)t0)[11],C_retrieve(lf[68])))){
t2=(C_word)C_i_car(((C_word*)t0)[12]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4648,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[13],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_eqp(lf[10],t4);
if(C_truep(t5)){
t6=(C_word)C_slot(t2,C_fix(2));
t7=(C_word)C_i_car(t6);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4669,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[11],a[6]=t2,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4773,a[2]=t7,a[3]=((C_word*)t0)[4],a[4]=t8,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 264  test */
t10=((C_word*)t0)[4];
f_3934(t10,t9,t7,lf[76]);}
else{
t8=t3;
f_4648(t8,C_SCHEME_FALSE);}}
else{
t6=t3;
f_4648(t6,C_SCHEME_FALSE);}}
else{
t4=t3;
f_4648(t4,C_SCHEME_FALSE);}}
else{
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_4787,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
if(C_truep(((C_word*)t0)[16])){
t3=(C_word)C_slot(((C_word*)t0)[16],C_fix(1));
t4=t2;
f_4787(t4,(C_word)C_eqp(lf[55],t3));}
else{
t3=t2;
f_4787(t3,C_SCHEME_FALSE);}}}}

/* k4785 in k4604 in k4595 in walk1 in ##compiler#perform-high-level-optimizations in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_fcall f_4787(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4787,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[16],C_fix(2));
t3=(C_word)C_i_caddr(t2);
t4=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_4798,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=t3,a[14]=((C_word*)t0)[16],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=t2,tmp=(C_word)a,a+=18,tmp);
/* optimizer.scm: 280  decompose-lambda-list */
((C_proc4)C_retrieve_symbol_proc(lf[62]))(4,*((C_word*)lf[62]+1),((C_word*)t0)[2],t3,t4);}
else{
/* optimizer.scm: 353  walk-generic */
t2=((C_word*)((C_word*)t0)[11])[1];
f_5298(t2,((C_word*)t0)[2],((C_word*)t0)[10],((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7]);}}

/* a4797 in k4785 in k4604 in k4595 in walk1 in ##compiler#perform-high-level-optimizations in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_4798(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[28],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4798,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_car(((C_word*)t0)[17]);
t6=(*a=C_CLOSURE_TYPE|21,a[1]=(C_word)f_4808,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=t3,a[13]=t5,a[14]=((C_word*)t0)[17],a[15]=((C_word*)t0)[11],a[16]=((C_word*)t0)[12],a[17]=((C_word*)t0)[13],a[18]=((C_word*)t0)[14],a[19]=t1,a[20]=((C_word*)t0)[15],a[21]=((C_word*)t0)[16],tmp=(C_word)a,a+=22,tmp);
if(C_truep(C_retrieve(lf[91]))){
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5110,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[17],a[5]=t6,tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 285  test */
t8=((C_word*)t0)[3];
f_3934(t8,t7,t5,lf[97]);}
else{
t7=t6;
f_4808(t7,C_SCHEME_FALSE);}}

/* k5108 in a4797 in k4785 in k4604 in k4595 in walk1 in ##compiler#perform-high-level-optimizations in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_5110(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5110,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5116,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 286  test */
t3=((C_word*)t0)[2];
f_3934(t3,t2,((C_word*)t0)[3],lf[96]);}
else{
t2=((C_word*)t0)[5];
f_4808(t2,C_SCHEME_FALSE);}}

/* k5114 in k5108 in a4797 in k4785 in k4604 in k4595 in walk1 in ##compiler#perform-high-level-optimizations in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_5116(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5116,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5119,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[45]))(4,*((C_word*)lf[45]+1),t2,((C_word*)t0)[2],lf[95]);}
else{
t2=((C_word*)t0)[4];
f_4808(t2,C_SCHEME_FALSE);}}

/* k5117 in k5114 in k5108 in a4797 in k4785 in k4604 in k4595 in walk1 in ##compiler#perform-high-level-optimizations in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_5119(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_word)C_eqp(t1,lf[92]);
if(C_truep(t2)){
t3=((C_word*)t0)[3];
f_4808(t3,C_SCHEME_TRUE);}
else{
t3=(C_word)C_eqp(t1,lf[93]);
if(C_truep(t3)){
t4=((C_word*)t0)[3];
f_4808(t4,C_SCHEME_FALSE);}
else{
t4=(C_word)C_i_cadddr(((C_word*)t0)[2]);
t5=C_retrieve(lf[94]);
t6=((C_word*)t0)[3];
f_4808(t6,(C_word)C_fixnum_lessp(t4,t5));}}}

/* k4806 in a4797 in k4785 in k4604 in k4595 in walk1 in ##compiler#perform-high-level-optimizations in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_fcall f_4808(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4808,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4811,a[2]=((C_word*)t0)[15],a[3]=((C_word*)t0)[16],a[4]=((C_word*)t0)[17],a[5]=((C_word*)t0)[18],a[6]=((C_word*)t0)[19],a[7]=((C_word*)t0)[20],a[8]=((C_word*)t0)[21],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4846,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[15],a[4]=t2,a[5]=((C_word*)t0)[14],tmp=(C_word)a,a+=6,tmp);
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[45]))(4,*((C_word*)lf[45]+1),t3,((C_word*)t0)[15],lf[81]);}
else{
t2=(*a=C_CLOSURE_TYPE|19,a[1]=(C_word)f_4855,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[17],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[15],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[20],a[10]=((C_word*)t0)[6],a[11]=((C_word*)t0)[21],a[12]=((C_word*)t0)[7],a[13]=((C_word*)t0)[8],a[14]=((C_word*)t0)[9],a[15]=((C_word*)t0)[10],a[16]=((C_word*)t0)[19],a[17]=((C_word*)t0)[11],a[18]=((C_word*)t0)[12],a[19]=((C_word*)t0)[16],tmp=(C_word)a,a+=20,tmp);
/* optimizer.scm: 302  test */
t3=((C_word*)t0)[4];
f_3934(t3,t2,((C_word*)t0)[13],lf[64]);}}

/* k4853 in k4806 in a4797 in k4785 in k4604 in k4595 in walk1 in ##compiler#perform-high-level-optimizations in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_4855(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4855,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_length(((C_word*)t0)[19]);
t3=((C_word*)t0)[18];
if(C_truep((C_word)C_fixnum_lessp(t2,t3))){
/* optimizer.scm: 304  walk-generic */
t4=((C_word*)((C_word*)t0)[17])[1];
f_5298(t4,((C_word*)t0)[16],((C_word*)t0)[15],((C_word*)t0)[14],((C_word*)t0)[13],((C_word*)t0)[12]);}
else{
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4869,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=t5,a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[13],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp));
t7=((C_word*)t5)[1];
f_4869(t7,((C_word*)t0)[16],((C_word*)t0)[5],((C_word*)t0)[18],((C_word*)t0)[19],C_SCHEME_END_OF_LIST);}}
else{
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_5014,a[2]=((C_word*)t0)[15],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[12],a[9]=((C_word*)t0)[13],a[10]=((C_word*)t0)[14],a[11]=((C_word*)t0)[16],a[12]=((C_word*)t0)[17],a[13]=((C_word*)t0)[19],tmp=(C_word)a,a+=14,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5097,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[15],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 328  test */
t4=((C_word*)t0)[6];
f_3934(t4,t3,((C_word*)t0)[2],lf[60]);}}

/* k5095 in k4853 in k4806 in a4797 in k4785 in k4604 in k4595 in walk1 in ##compiler#perform-high-level-optimizations in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_5097(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_memq(((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]);
t3=((C_word*)t0)[2];
f_5014(t3,(C_word)C_i_not(t2));}
else{
t2=((C_word*)t0)[2];
f_5014(t2,C_SCHEME_FALSE);}}

/* k5012 in k4853 in k4806 in a4797 in k4785 in k4604 in k4595 in walk1 in ##compiler#perform-high-level-optimizations in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_fcall f_5014(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5014,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5017,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],tmp=(C_word)a,a+=12,tmp);
/* optimizer.scm: 330  llist-length */
((C_proc3)C_retrieve_symbol_proc(lf[90]))(3,*((C_word*)lf[90]+1),t2,((C_word*)t0)[3]);}
else{
/* optimizer.scm: 352  walk-generic */
t2=((C_word*)((C_word*)t0)[12])[1];
f_5298(t2,((C_word*)t0)[11],((C_word*)t0)[2],((C_word*)t0)[10],((C_word*)t0)[9],((C_word*)t0)[8]);}}

/* k5015 in k5012 in k4853 in k4806 in a4797 in k4785 in k4604 in k4595 in walk1 in ##compiler#perform-high-level-optimizations in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_5017(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5017,2,t0,t1);}
t2=(C_word)C_i_length(((C_word*)t0)[11]);
t3=t1;
if(C_truep((C_word)C_fixnum_lessp(t2,t3))){
/* optimizer.scm: 332  walk-generic */
t4=((C_word*)((C_word*)t0)[10])[1];
f_5298(t4,((C_word*)t0)[9],t1,((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6]);}
else{
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5029,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=t1,a[8]=((C_word*)t0)[11],tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 334  debugging */
((C_proc6)C_retrieve_symbol_proc(lf[7]))(6,*((C_word*)lf[7]+1),t4,lf[8],lf[89],((C_word*)t0)[2],t1);}}

/* k5027 in k5015 in k5012 in k4853 in k4806 in a4797 in k4785 in k4604 in k4595 in walk1 in ##compiler#perform-high-level-optimizations in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_5029(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5029,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5034,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5040,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a5039 in k5027 in k5015 in k5012 in k4853 in k4806 in a4797 in k4785 in k4604 in k4595 in walk1 in ##compiler#perform-high-level-optimizations in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_5040(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[25],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5040,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5044,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5059,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5067,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* optimizer.scm: 345  qnode */
((C_proc3)C_retrieve_symbol_proc(lf[39]))(3,*((C_word*)lf[39]+1),t6,C_SCHEME_END_OF_LIST);}
else{
t7=(C_word)C_i_length(t3);
t8=(C_word)C_fixnum_times(C_fix(3),t7);
t9=(C_word)C_a_i_list(&a,2,lf[87],t8);
t10=t6;
f_5067(2,t10,(C_word)C_a_i_record(&a,4,lf[37],lf[88],t9,t3));}}

/* k5065 in a5039 in k5027 in k5015 in k5012 in k4853 in k4806 in a4797 in k4785 in k4604 in k4595 in walk1 in ##compiler#perform-high-level-optimizations in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_5067(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5067,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* optimizer.scm: 341  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[13]+1)))(4,*((C_word*)lf[13]+1),((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k5057 in a5039 in k5027 in k5015 in k5012 in k4853 in k4806 in a4797 in k4785 in k4604 in k4595 in walk1 in ##compiler#perform-high-level-optimizations in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_5059(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5059,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
/* map */
t3=*((C_word*)lf[30]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t2);}

/* k5042 in a5039 in k5027 in k5015 in k5012 in k4853 in k4806 in a4797 in k4785 in k4604 in k4595 in walk1 in ##compiler#perform-high-level-optimizations in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_5044(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5044,2,t0,t1);}
t2=(C_word)C_a_i_record(&a,4,lf[37],lf[16],((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[3])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t2);}

/* a5033 in k5027 in k5015 in k5012 in k4853 in k4806 in a4797 in k4785 in k4604 in k4595 in walk1 in ##compiler#perform-high-level-optimizations in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_5034(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5034,2,t0,t1);}
/* optimizer.scm: 335  split-at */
((C_proc4)C_retrieve_symbol_proc(lf[86]))(4,*((C_word*)lf[86]+1),t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop in k4853 in k4806 in a4797 in k4785 in k4604 in k4595 in walk1 in ##compiler#perform-high-level-optimizations in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_fcall f_4869(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4869,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(C_word)C_i_nullp(t2);
t7=(C_truep(t6)?t6:(C_word)C_eqp(t3,C_fix(0)));
if(C_truep(t7)){
t8=f_3960(((C_word*)t0)[9]);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4885,a[2]=((C_word*)t0)[8],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4896,a[2]=((C_word*)t0)[6],a[3]=t9,a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 311  append-reverse */
((C_proc4)C_retrieve_symbol_proc(lf[82]))(4,*((C_word*)lf[82]+1),t10,t5,t4);}
else{
t8=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4902,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],a[5]=t5,a[6]=((C_word*)t0)[5],a[7]=t4,a[8]=t3,a[9]=t2,a[10]=t1,a[11]=((C_word*)t0)[9],tmp=(C_word)a,a+=12,tmp);
t9=(C_word)C_i_car(t2);
/* optimizer.scm: 312  test */
t10=((C_word*)t0)[2];
f_3934(t10,t8,t9,lf[56]);}}

/* k4900 in loop in k4853 in k4806 in a4797 in k4785 in k4604 in k4595 in walk1 in ##compiler#perform-high-level-optimizations in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_4902(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4902,2,t0,t1);}
if(C_truep(t1)){
t2=f_3960(((C_word*)t0)[11]);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4908,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[9]);
/* optimizer.scm: 314  debugging */
((C_proc6)C_retrieve_symbol_proc(lf[7]))(6,*((C_word*)lf[7]+1),t3,lf[8],lf[85],t4,((C_word*)t0)[2]);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[9]);
t3=(C_word)C_fixnum_decrease(((C_word*)t0)[8]);
t4=(C_word)C_i_cdr(((C_word*)t0)[7]);
t5=(C_word)C_i_car(((C_word*)t0)[7]);
t6=(C_word)C_a_i_cons(&a,2,t5,((C_word*)t0)[5]);
/* optimizer.scm: 324  loop */
t7=((C_word*)((C_word*)t0)[6])[1];
f_4869(t7,((C_word*)t0)[10],t2,t3,t4,t6);}}

/* k4906 in k4900 in loop in k4853 in k4806 in a4797 in k4785 in k4604 in k4595 in walk1 in ##compiler#perform-high-level-optimizations in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_4908(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4908,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4914,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[6]);
/* optimizer.scm: 317  expression-has-side-effects? */
((C_proc4)C_retrieve_symbol_proc(lf[73]))(4,*((C_word*)lf[73]+1),t2,t3,((C_word*)t0)[2]);}

/* k4912 in k4906 in k4900 in loop in k4853 in k4806 in a4797 in k4785 in k4604 in k4595 in walk1 in ##compiler#perform-high-level-optimizations in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_4914(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4914,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4951,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 320  gensym */
((C_proc3)C_retrieve_symbol_proc(lf[83]))(3,*((C_word*)lf[83]+1),t2,lf[84]);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
t3=(C_word)C_fixnum_decrease(((C_word*)t0)[6]);
t4=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* optimizer.scm: 323  loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_4869(t5,((C_word*)t0)[8],t2,t3,t4,((C_word*)t0)[3]);}}

/* k4949 in k4912 in k4906 in k4900 in loop in k4853 in k4806 in a4797 in k4785 in k4604 in k4595 in walk1 in ##compiler#perform-high-level-optimizations in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_4951(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4951,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4927,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t2,a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[5]);
/* optimizer.scm: 321  walk */
t5=((C_word*)((C_word*)t0)[2])[1];
f_4056(3,t5,t3,t4);}

/* k4925 in k4949 in k4912 in k4906 in k4900 in loop in k4853 in k4806 in a4797 in k4785 in k4604 in k4595 in walk1 in ##compiler#perform-high-level-optimizations in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_4927(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4927,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4931,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[6]);
t4=(C_word)C_fixnum_decrease(((C_word*)t0)[5]);
t5=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* optimizer.scm: 322  loop */
t6=((C_word*)((C_word*)t0)[3])[1];
f_4869(t6,t2,t3,t4,t5,((C_word*)t0)[2]);}

/* k4929 in k4925 in k4949 in k4912 in k4906 in k4900 in loop in k4853 in k4806 in a4797 in k4785 in k4604 in k4595 in walk1 in ##compiler#perform-high-level-optimizations in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_4931(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4931,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[37],lf[12],((C_word*)t0)[2],t2));}

/* k4894 in loop in k4853 in k4806 in a4797 in k4785 in k4604 in k4595 in walk1 in ##compiler#perform-high-level-optimizations in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_4896(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4896,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
/* map */
t3=*((C_word*)lf[30]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t2);}

/* k4883 in loop in k4853 in k4806 in a4797 in k4785 in k4604 in k4595 in walk1 in ##compiler#perform-high-level-optimizations in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_4885(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4885,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[37],lf[16],((C_word*)t0)[2],t1));}

/* k4844 in k4806 in a4797 in k4785 in k4604 in k4595 in walk1 in ##compiler#perform-high-level-optimizations in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_4846(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_i_structurep(t1,lf[37]);
t3=(C_truep(t2)?lf[78]:lf[79]);
t4=(C_word)C_i_cadddr(((C_word*)t0)[5]);
/* optimizer.scm: 292  debugging */
((C_proc7)C_retrieve_symbol_proc(lf[7]))(7,*((C_word*)lf[7]+1),((C_word*)t0)[4],lf[80],t3,((C_word*)t0)[3],((C_word*)t0)[2],t4);}

/* k4809 in k4806 in a4797 in k4785 in k4604 in k4595 in walk1 in ##compiler#perform-high-level-optimizations in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_4811(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4811,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4814,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 298  check-signature */
((C_proc5)C_retrieve_symbol_proc(lf[67]))(5,*((C_word*)lf[67]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4]);}

/* k4812 in k4809 in k4806 in a4797 in k4785 in k4604 in k4595 in walk1 in ##compiler#perform-high-level-optimizations in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_4814(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4814,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4817,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 299  debugging */
((C_proc5)C_retrieve_symbol_proc(lf[7]))(5,*((C_word*)lf[7]+1),t2,lf[8],lf[77],((C_word*)t0)[2]);}

/* k4815 in k4812 in k4809 in k4806 in a4797 in k4785 in k4604 in k4595 in walk1 in ##compiler#perform-high-level-optimizations in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_4817(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4817,2,t0,t1);}
t2=f_3960(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4827,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_slot(((C_word*)t0)[4],C_fix(3));
t5=(C_word)C_i_car(t4);
/* optimizer.scm: 301  inline-lambda-bindings */
((C_proc6)C_retrieve_symbol_proc(lf[65]))(6,*((C_word*)lf[65]+1),t3,((C_word*)t0)[3],((C_word*)t0)[2],t5,C_SCHEME_TRUE);}

/* k4825 in k4815 in k4812 in k4809 in k4806 in a4797 in k4785 in k4604 in k4595 in walk1 in ##compiler#perform-high-level-optimizations in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_4827(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 301  walk */
t2=((C_word*)((C_word*)t0)[3])[1];
f_4056(3,t2,((C_word*)t0)[2],t1);}

/* k4771 in k4604 in k4595 in walk1 in ##compiler#perform-high-level-optimizations in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_4773(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_4669(2,t2,C_SCHEME_FALSE);}
else{
/* optimizer.scm: 264  test */
t2=((C_word*)t0)[3];
f_3934(t2,((C_word*)t0)[4],((C_word*)t0)[2],lf[47]);}}

/* k4667 in k4604 in k4595 in walk1 in ##compiler#perform-high-level-optimizations in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_4669(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4669,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(t1,C_fix(1));
t3=(C_word)C_eqp(lf[55],t2);
if(C_truep(t3)){
t4=(C_word)C_slot(t1,C_fix(2));
t5=(C_word)C_i_caddr(t4);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4690,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t7=(C_word)C_i_car(t5);
/* optimizer.scm: 267  test */
t8=((C_word*)t0)[2];
f_3934(t8,t6,t7,lf[56]);}
else{
t6=((C_word*)t0)[7];
f_4648(t6,C_SCHEME_FALSE);}}
else{
t4=((C_word*)t0)[7];
f_4648(t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[7];
f_4648(t2,C_SCHEME_FALSE);}}

/* k4688 in k4667 in k4604 in k4595 in walk1 in ##compiler#perform-high-level-optimizations in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_4690(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4690,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4693,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t1)){
t3=t2;
f_4693(t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4747,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[3]);
/* optimizer.scm: 268  test */
t5=((C_word*)t0)[2];
f_3934(t5,t3,t4,lf[75]);}}

/* k4745 in k4688 in k4667 in k4604 in k4595 in walk1 in ##compiler#perform-high-level-optimizations in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_4747(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4747,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_4693(t2,C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4739,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
/* optimizer.scm: 269  test */
t4=((C_word*)t0)[2];
f_3934(t4,t2,t3,lf[74]);}}

/* k4737 in k4745 in k4688 in k4667 in k4604 in k4595 in walk1 in ##compiler#perform-high-level-optimizations in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_4739(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_4693(t2,(C_word)C_i_not(t1));}

/* k4691 in k4688 in k4667 in k4604 in k4595 in walk1 in ##compiler#perform-high-level-optimizations in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_fcall f_4693(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4693,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4716,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4718,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* optimizer.scm: 270  any */
((C_proc4)C_retrieve_symbol_proc(lf[32]))(4,*((C_word*)lf[32]+1),t2,t3,t4);}
else{
t2=((C_word*)t0)[6];
f_4648(t2,C_SCHEME_FALSE);}}

/* a4717 in k4691 in k4688 in k4667 in k4604 in k4595 in walk1 in ##compiler#perform-high-level-optimizations in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_4718(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4718,3,t0,t1,t2);}
/* ##compiler#expression-has-side-effects? */
((C_proc4)C_retrieve_symbol_proc(lf[73]))(4,*((C_word*)lf[73]+1),t1,t2,((C_word*)t0)[2]);}

/* k4714 in k4691 in k4688 in k4667 in k4604 in k4595 in walk1 in ##compiler#perform-high-level-optimizations in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_4716(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4716,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_4648(t2,C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4702,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 271  debugging */
((C_proc5)C_retrieve_symbol_proc(lf[7]))(5,*((C_word*)lf[7]+1),t2,lf[71],lf[72],((C_word*)t0)[2]);}}

/* k4700 in k4714 in k4691 in k4688 in k4667 in k4604 in k4595 in walk1 in ##compiler#perform-high-level-optimizations in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_4702(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4702,2,t0,t1);}
t2=(C_word)C_a_i_record(&a,4,lf[37],lf[69],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
f_4648(t4,(C_word)C_a_i_record(&a,4,lf[37],lf[16],lf[70],t3));}

/* k4646 in k4604 in k4595 in walk1 in ##compiler#perform-high-level-optimizations in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_fcall f_4648(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
/* optimizer.scm: 275  walk-generic */
t2=((C_word*)((C_word*)t0)[6])[1];
f_5298(t2,((C_word*)t0)[7],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k4613 in k4604 in k4595 in walk1 in ##compiler#perform-high-level-optimizations in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_4615(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4615,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4618,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 257  debugging */
((C_proc5)C_retrieve_symbol_proc(lf[7]))(5,*((C_word*)lf[7]+1),t2,lf[8],lf[66],((C_word*)t0)[2]);}

/* k4616 in k4613 in k4604 in k4595 in walk1 in ##compiler#perform-high-level-optimizations in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_4618(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4618,2,t0,t1);}
t2=f_3960(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4628,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_slot(((C_word*)t0)[4],C_fix(3));
t5=(C_word)C_i_car(t4);
/* optimizer.scm: 259  inline-lambda-bindings */
((C_proc6)C_retrieve_symbol_proc(lf[65]))(6,*((C_word*)lf[65]+1),t3,((C_word*)t0)[3],((C_word*)t0)[2],t5,C_SCHEME_FALSE);}

/* k4626 in k4616 in k4613 in k4604 in k4595 in walk1 in ##compiler#perform-high-level-optimizations in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_4628(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 259  walk */
t2=((C_word*)((C_word*)t0)[3])[1];
f_4056(3,t2,((C_word*)t0)[2],t1);}

/* k4419 in walk1 in ##compiler#perform-high-level-optimizations in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_4421(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4421,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4426,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[11],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 212  decompose-lambda-list */
((C_proc4)C_retrieve_symbol_proc(lf[62]))(4,*((C_word*)lf[62]+1),((C_word*)t0)[6],((C_word*)t0)[5],t2);}
else{
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4513,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[9]);
/* optimizer.scm: 227  test */
t4=((C_word*)t0)[11];
f_3934(t4,t2,t3,lf[60]);}}

/* k4511 in k4419 in walk1 in ##compiler#perform-high-level-optimizations in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_4513(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4513,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4518,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 228  decompose-lambda-list */
((C_proc4)C_retrieve_symbol_proc(lf[62]))(4,*((C_word*)lf[62]+1),((C_word*)t0)[6],((C_word*)t0)[5],t2);}
else{
/* optimizer.scm: 240  walk-generic */
t2=((C_word*)((C_word*)t0)[4])[1];
f_5298(t2,((C_word*)t0)[6],((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[9],((C_word*)t0)[8]);}}

/* a4517 in k4511 in k4419 in walk1 in ##compiler#perform-high-level-optimizations in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_4518(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4518,5,t0,t1,t2,t3,t4);}
t5=f_3960(((C_word*)t0)[5]);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4525,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=t1,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 232  debugging */
((C_proc5)C_retrieve_symbol_proc(lf[7]))(5,*((C_word*)lf[7]+1),t6,lf[8],lf[63],t4);}

/* k4523 in a4517 in k4511 in k4419 in walk1 in ##compiler#perform-high-level-optimizations in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_4525(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4525,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[7]);
t3=(C_word)C_i_cadr(((C_word*)t0)[7]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4554,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t3,a[6]=t2,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t5=(C_word)C_fixnum_increase(((C_word*)t0)[3]);
/* optimizer.scm: 237  build-lambda-list */
((C_proc5)C_retrieve_symbol_proc(lf[58]))(5,*((C_word*)lf[58]+1),t4,((C_word*)t0)[2],t5,C_SCHEME_FALSE);}

/* k4552 in k4523 in a4517 in k4511 in k4419 in walk1 in ##compiler#perform-high-level-optimizations in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_4554(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4554,2,t0,t1);}
t2=(C_word)C_i_cadddr(((C_word*)t0)[7]);
t3=(C_word)C_a_i_list(&a,4,((C_word*)t0)[6],((C_word*)t0)[5],t1,t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4538,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[3]);
/* optimizer.scm: 239  walk */
t6=((C_word*)((C_word*)t0)[2])[1];
f_4056(3,t6,t4,t5);}

/* k4536 in k4552 in k4523 in a4517 in k4511 in k4419 in walk1 in ##compiler#perform-high-level-optimizations in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_4538(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4538,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[37],lf[55],((C_word*)t0)[2],t2));}

/* a4425 in k4419 in walk1 in ##compiler#perform-high-level-optimizations in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_4426(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4426,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4432,a[2]=t2,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4444,a[2]=((C_word*)t0)[6],a[3]=t4,a[4]=t3,a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t5,t6);}

/* a4443 in a4425 in k4419 in walk1 in ##compiler#perform-high-level-optimizations in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_4444(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4444,4,t0,t1,t2,t3);}
t4=f_3960(((C_word*)t0)[8]);
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4451,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t1,a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm: 217  debugging */
((C_proc5)C_retrieve_symbol_proc(lf[7]))(5,*((C_word*)lf[7]+1),t5,lf[8],lf[61],t2);}

/* k4449 in a4443 in a4425 in k4419 in walk1 in ##compiler#perform-high-level-optimizations in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_4451(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4451,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[9]);
t3=(C_word)C_i_cadr(((C_word*)t0)[9]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4480,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=t3,a[6]=t2,a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4487,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[3])){
t6=(C_word)C_i_car(((C_word*)t0)[9]);
/* optimizer.scm: 221  test */
t7=((C_word*)t0)[2];
f_3934(t7,t5,t6,lf[60]);}
else{
t6=t5;
f_4487(2,t6,C_SCHEME_FALSE);}}

/* k4485 in k4449 in a4443 in a4425 in k4419 in walk1 in ##compiler#perform-high-level-optimizations in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_4487(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4487,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4490,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 222  debugging */
((C_proc5)C_retrieve_symbol_proc(lf[7]))(5,*((C_word*)lf[7]+1),t2,lf[8],lf[59],((C_word*)t0)[2]);}
else{
/* optimizer.scm: 224  build-lambda-list */
((C_proc5)C_retrieve_symbol_proc(lf[58]))(5,*((C_word*)lf[58]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[5],((C_word*)t0)[2]);}}

/* k4488 in k4485 in k4449 in a4443 in a4425 in k4419 in walk1 in ##compiler#perform-high-level-optimizations in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_4490(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_increase(((C_word*)t0)[4]);
/* optimizer.scm: 223  build-lambda-list */
((C_proc5)C_retrieve_symbol_proc(lf[58]))(5,*((C_word*)lf[58]+1),((C_word*)t0)[3],((C_word*)t0)[2],t2,C_SCHEME_FALSE);}

/* k4478 in k4449 in a4443 in a4425 in k4419 in walk1 in ##compiler#perform-high-level-optimizations in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_4480(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4480,2,t0,t1);}
t2=(C_word)C_i_cadddr(((C_word*)t0)[7]);
t3=(C_word)C_a_i_list(&a,4,((C_word*)t0)[6],((C_word*)t0)[5],t1,t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4464,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[3]);
/* optimizer.scm: 226  walk */
t6=((C_word*)((C_word*)t0)[2])[1];
f_4056(3,t6,t4,t5);}

/* k4462 in k4478 in k4449 in a4443 in a4425 in k4419 in walk1 in ##compiler#perform-high-level-optimizations in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_4464(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4464,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[37],lf[55],((C_word*)t0)[2],t2));}

/* a4431 in a4425 in k4419 in walk1 in ##compiler#perform-high-level-optimizations in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_4432(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4432,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4438,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 215  partition */
((C_proc4)C_retrieve_symbol_proc(lf[57]))(4,*((C_word*)lf[57]+1),t1,t2,((C_word*)t0)[2]);}

/* a4437 in a4431 in a4425 in k4419 in walk1 in ##compiler#perform-high-level-optimizations in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_4438(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4438,3,t0,t1,t2);}
/* optimizer.scm: 215  test */
t3=((C_word*)t0)[2];
f_3934(t3,t1,t2,lf[56]);}

/* k4368 in walk1 in ##compiler#perform-high-level-optimizations in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_4370(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4370,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4373,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t1)){
t3=t2;
f_4373(t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4399,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 203  test */
t4=((C_word*)t0)[3];
f_3934(t4,t3,((C_word*)t0)[2],lf[53]);}}

/* k4397 in k4368 in walk1 in ##compiler#perform-high-level-optimizations in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_4399(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4399,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4406,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 203  test */
t3=((C_word*)t0)[3];
f_3934(t3,t2,((C_word*)t0)[2],lf[52]);}
else{
t2=((C_word*)t0)[4];
f_4373(t2,C_SCHEME_FALSE);}}

/* k4404 in k4397 in k4368 in walk1 in ##compiler#perform-high-level-optimizations in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_4406(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_4373(t2,(C_word)C_i_not(t1));}

/* k4371 in k4368 in walk1 in ##compiler#perform-high-level-optimizations in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_fcall f_4373(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4373,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=f_3960(((C_word*)t0)[7]);
t3=(C_word)C_fixnum_increase(((C_word*)((C_word*)t0)[6])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t3);
t5=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* optimizer.scm: 206  walk */
t6=((C_word*)((C_word*)t0)[4])[1];
f_4056(3,t6,((C_word*)t0)[3],t5);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4390,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* map */
t3=*((C_word*)lf[30]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[5]);}}

/* k4388 in k4371 in k4368 in walk1 in ##compiler#perform-high-level-optimizations in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_4390(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4390,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[37],lf[12],((C_word*)t0)[2],t1));}

/* replace in walk1 in ##compiler#perform-high-level-optimizations in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_fcall f_4295(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4295,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4299,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t1,a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 187  test */
t4=((C_word*)t0)[4];
f_3934(t4,t3,t2,lf[51]);}

/* k4297 in replace in walk1 in ##compiler#perform-high-level-optimizations in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_4299(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4299,2,t0,t1);}
if(C_truep(t1)){
/* replace329 */
t2=((C_word*)((C_word*)t0)[8])[1];
f_4295(t2,((C_word*)t0)[7],t1);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4311,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 188  test */
t3=((C_word*)t0)[5];
f_3934(t3,t2,((C_word*)t0)[4],lf[50]);}}

/* k4309 in k4297 in replace in walk1 in ##compiler#perform-high-level-optimizations in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_4311(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4311,2,t0,t1);}
if(C_truep(t1)){
t2=f_3960(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4317,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 190  debugging */
((C_proc5)C_retrieve_symbol_proc(lf[7]))(5,*((C_word*)lf[7]+1),t3,lf[8],lf[48],((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4334,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
t4=(C_word)C_eqp(((C_word*)t0)[4],t3);
if(C_truep(t4)){
t5=t2;
f_4334(t5,C_SCHEME_UNDEFINED);}
else{
t5=f_3960(((C_word*)t0)[7]);
t6=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[2])[1],C_fix(1));
t7=C_mutate(((C_word *)((C_word*)t0)[2])+1,t6);
t8=t2;
f_4334(t8,t7);}}}

/* k4332 in k4309 in k4297 in replace in walk1 in ##compiler#perform-high-level-optimizations in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_fcall f_4334(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 197  varnode */
((C_proc3)C_retrieve_symbol_proc(lf[49]))(3,*((C_word*)lf[49]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4315 in k4309 in k4297 in replace in walk1 in ##compiler#perform-high-level-optimizations in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_4317(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4317,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4328,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 191  test */
t3=((C_word*)t0)[3];
f_3934(t3,t2,((C_word*)t0)[2],lf[47]);}

/* k4326 in k4315 in k4309 in k4297 in replace in walk1 in ##compiler#perform-high-level-optimizations in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_4328(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_slot(t1,C_fix(2));
t3=(C_word)C_i_car(t2);
/* optimizer.scm: 191  qnode */
((C_proc3)C_retrieve_symbol_proc(lf[39]))(3,*((C_word*)lf[39]+1),((C_word*)t0)[2],t3);}

/* walk in ##compiler#perform-high-level-optimizations in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_4056(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4056,3,t0,t1,t2);}
if(C_truep((C_word)C_i_memq(t2,C_retrieve(lf[34])))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=((C_word*)((C_word*)t0)[8])[1];
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4070,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[8],a[4]=t3,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t1,a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm: 141  walk1 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_4270(t5,t4,t2);}}

/* k4068 in walk in ##compiler#perform-high-level-optimizations in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_4070(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4070,2,t0,t1);}
t2=(C_word)C_slot(t1,C_fix(3));
t3=(C_word)C_slot(t1,C_fix(1));
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4079,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_eqp(t3,lf[11]);
if(C_truep(t5)){
t6=(C_word)C_i_car(t2);
t7=(C_word)C_slot(t6,C_fix(1));
t8=(C_word)C_eqp(lf[27],t7);
if(C_truep(t8)){
t9=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[7])[1],C_fix(1));
t10=C_mutate(((C_word *)((C_word*)t0)[7])+1,t9);
t11=f_3960(((C_word*)t0)[6]);
t12=(C_word)C_i_car(t2);
t13=(C_word)C_slot(t12,C_fix(2));
t14=(C_word)C_i_car(t13);
t15=(C_truep(t14)?(C_word)C_i_cadr(t2):(C_word)C_i_caddr(t2));
/* optimizer.scm: 149  walk */
t16=((C_word*)((C_word*)t0)[5])[1];
f_4056(3,t16,t4,t15);}
else{
t9=t4;
f_4079(2,t9,t1);}}
else{
t6=(C_word)C_eqp(t3,lf[16]);
if(C_truep(t6)){
t7=(C_word)C_i_car(t2);
t8=(C_word)C_slot(t7,C_fix(1));
t9=(C_word)C_eqp(lf[10],t8);
if(C_truep(t9)){
t10=(C_word)C_i_car(t2);
t11=(C_word)C_slot(t10,C_fix(2));
t12=(C_word)C_i_car(t11);
t13=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4140,a[2]=t2,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,a[7]=t4,a[8]=t12,tmp=(C_word)a,a+=9,tmp);
t14=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4241,a[2]=t12,a[3]=((C_word*)t0)[2],a[4]=t13,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[45]))(4,*((C_word*)lf[45]+1),t14,t12,lf[46]);}
else{
t10=t4;
f_4079(2,t10,t1);}}
else{
t7=t4;
f_4079(2,t7,t1);}}}

/* k4239 in k4068 in walk in ##compiler#perform-high-level-optimizations in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_4241(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4241,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4247,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 158  foldable? */
((C_proc3)C_retrieve_symbol_proc(lf[44]))(3,*((C_word*)lf[44]+1),t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
f_4140(2,t2,C_SCHEME_FALSE);}}

/* k4245 in k4239 in k4068 in walk in ##compiler#perform-high-level-optimizations in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_4247(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cddr(((C_word*)t0)[4]);
/* optimizer.scm: 159  every */
((C_proc4)C_retrieve_symbol_proc(lf[43]))(4,*((C_word*)lf[43]+1),((C_word*)t0)[3],((C_word*)t0)[2],t2);}
else{
t2=((C_word*)t0)[3];
f_4140(2,t2,C_SCHEME_FALSE);}}

/* k4138 in k4068 in walk in ##compiler#perform-high-level-optimizations in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_4140(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4140,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4220,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4222,tmp=(C_word)a,a+=2,tmp);
t4=(C_word)C_i_cddr(((C_word*)t0)[2]);
/* map */
t5=*((C_word*)lf[30]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,t3,t4);}
else{
t2=((C_word*)t0)[7];
f_4079(2,t2,((C_word*)t0)[6]);}}

/* a4221 in k4138 in k4068 in walk in ##compiler#perform-high-level-optimizations in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_4222(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4222,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(2));
t4=(C_word)C_i_car(t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[27],t5));}

/* k4218 in k4138 in k4068 in walk in ##compiler#perform-high-level-optimizations in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_4220(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4220,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4149,a[2]=((C_word*)t0)[7],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4151,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* call-with-current-continuation */
((C_proc3)C_retrieve_proc(*((C_word*)lf[20]+1)))(3,*((C_word*)lf[20]+1),t3,t4);}

/* a4150 in k4218 in k4138 in k4068 in walk in ##compiler#perform-high-level-optimizations in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_4151(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4151,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4157,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4174,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* with-exception-handler */
((C_proc4)C_retrieve_symbol_proc(lf[42]))(4,*((C_word*)lf[42]+1),t1,t3,t4);}

/* a4173 in a4150 in k4218 in k4138 in k4068 in walk in ##compiler#perform-high-level-optimizations in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_4174(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4174,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4180,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4206,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a4205 in a4173 in a4150 in k4218 in k4138 in k4068 in walk in ##compiler#perform-high-level-optimizations in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_4206(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_4206r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4206r(t0,t1,t2);}}

static void C_ccall f_4206r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4212,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* k278284 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a4211 in a4205 in a4173 in a4150 in k4218 in k4138 in k4068 in walk in ##compiler#perform-high-level-optimizations in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_4212(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4212,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a4179 in a4173 in a4150 in k4218 in k4138 in k4068 in walk in ##compiler#perform-high-level-optimizations in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_4180(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4180,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4184,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 167  eval */
((C_proc3)C_retrieve_symbol_proc(lf[41]))(3,*((C_word*)lf[41]+1),t2,((C_word*)t0)[2]);}

/* k4182 in a4179 in a4173 in a4150 in k4218 in k4138 in k4068 in walk in ##compiler#perform-high-level-optimizations in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_4184(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4184,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4187,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 168  debugging */
((C_proc5)C_retrieve_symbol_proc(lf[7]))(5,*((C_word*)lf[7]+1),t2,lf[8],lf[40],((C_word*)t0)[2]);}

/* k4185 in k4182 in a4179 in a4173 in a4150 in k4218 in k4138 in k4068 in walk in ##compiler#perform-high-level-optimizations in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_4187(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4187,2,t0,t1);}
t2=f_3960(((C_word*)t0)[5]);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4204,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 173  qnode */
((C_proc3)C_retrieve_symbol_proc(lf[39]))(3,*((C_word*)lf[39]+1),t4,((C_word*)t0)[2]);}

/* k4202 in k4185 in k4182 in a4179 in a4173 in a4150 in k4218 in k4138 in k4068 in walk in ##compiler#perform-high-level-optimizations in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_4204(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4204,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[37],lf[16],lf[38],t2));}

/* a4156 in a4150 in k4218 in k4138 in k4068 in walk in ##compiler#perform-high-level-optimizations in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_4157(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4157,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4163,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* k278284 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a4162 in a4156 in a4150 in k4218 in k4138 in k4068 in walk in ##compiler#perform-high-level-optimizations in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_4163(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4163,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4167,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=t2;
f_4167(t3,C_SCHEME_UNDEFINED);}
else{
t3=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_FALSE);
t4=t2;
f_4167(t4,t3);}}

/* k4165 in a4162 in a4156 in a4150 in k4218 in k4138 in k4068 in walk in ##compiler#perform-high-level-optimizations in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_fcall f_4167(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4167,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4171,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 165  lset-adjoin */
((C_proc5)C_retrieve_symbol_proc(lf[35]))(5,*((C_word*)lf[35]+1),t2,*((C_word*)lf[36]+1),C_retrieve(lf[34]),((C_word*)t0)[2]);}

/* k4169 in k4165 in a4162 in a4156 in a4150 in k4218 in k4138 in k4068 in walk in ##compiler#perform-high-level-optimizations in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_4171(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[34]+1 /* (set! broken-constant-nodes ...) */,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[2]);}

/* k4147 in k4218 in k4138 in k4068 in walk in ##compiler#perform-high-level-optimizations in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_4149(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k4077 in k4068 in walk in ##compiler#perform-high-level-optimizations in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_4079(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 139  simplify */
t2=((C_word*)((C_word*)t0)[3])[1];
f_3964(t2,((C_word*)t0)[2],t1);}

/* simplify in ##compiler#perform-high-level-optimizations in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_fcall f_3964(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3964,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3968,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t4=t2;
t5=(C_word)C_slot(t4,C_fix(1));
/* optimizer.scm: 120  ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[33]))(4,*((C_word*)lf[33]+1),t3,C_retrieve(lf[23]),t5);}

/* k3966 in simplify in ##compiler#perform-high-level-optimizations in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_3968(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3968,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3971,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3979,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 121  any */
((C_proc4)C_retrieve_symbol_proc(lf[32]))(4,*((C_word*)lf[32]+1),t2,t3,t1);}
else{
t3=t2;
f_3971(2,t3,C_SCHEME_FALSE);}}

/* a3978 in k3966 in simplify in ##compiler#perform-high-level-optimizations in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_3979(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3979,3,t0,t1,t2);}
t3=(C_word)C_i_cadr(t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3989,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
t5=(C_word)C_i_car(t2);
/* optimizer.scm: 123  match-node */
((C_proc5)C_retrieve_symbol_proc(lf[31]))(5,*((C_word*)lf[31]+1),t4,((C_word*)t0)[2],t5,t3);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k3987 in a3978 in k3966 in simplify in ##compiler#perform-high-level-optimizations in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_3989(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3989,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3995,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_caddr(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4036,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4038,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* map */
t6=*((C_word*)lf[30]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a4037 in k3987 in a3978 in k3966 in simplify in ##compiler#perform-high-level-optimizations in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_4038(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4038,3,t0,t1,t2);}
t3=(C_word)C_i_assq(t2,((C_word*)t0)[2]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_cdr(t3));}

/* k4034 in k3987 in a3978 in k3966 in simplify in ##compiler#perform-high-level-optimizations in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_4036(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(5,0,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3993 in k3987 in a3978 in k3966 in simplify in ##compiler#perform-high-level-optimizations in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_3995(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3995,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4001,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 126  caar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[29]+1)))(3,*((C_word*)lf[29]+1),t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k3999 in k3993 in k3987 in a3978 in k3966 in simplify in ##compiler#perform-high-level-optimizations in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_4001(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4001,2,t0,t1);}
t2=(C_word)C_i_assq(t1,((C_word*)((C_word*)t0)[6])[1]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4007,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t4=(C_word)C_i_cdr(t2);
t5=(C_word)C_fixnum_increase(t4);
t6=t3;
f_4007(t6,(C_word)C_i_set_cdr(t2,t5));}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4028,a[2]=t3,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 130  alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[28]))(5,*((C_word*)lf[28]+1),t4,t1,C_fix(1),((C_word*)((C_word*)t0)[6])[1]);}}

/* k4026 in k3999 in k3993 in k3987 in a3978 in k3966 in simplify in ##compiler#perform-high-level-optimizations in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_4028(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_4007(t3,t2);}

/* k4005 in k3999 in k3993 in k3987 in a3978 in k3966 in simplify in ##compiler#perform-high-level-optimizations in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_fcall f_4007(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=f_3960(((C_word*)t0)[5]);
/* optimizer.scm: 132  simplify */
t3=((C_word*)((C_word*)t0)[4])[1];
f_3964(t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3969 in k3966 in simplify in ##compiler#perform-high-level-optimizations in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_3971(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?t1:((C_word*)t0)[2]));}

/* touch in ##compiler#perform-high-level-optimizations in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static C_word C_fcall f_3960(C_word t0){
C_word tmp;
C_word t1;
C_word t2;
C_stack_check;
t1=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_TRUE);
return(t1);}

/* constant-node? in ##compiler#perform-high-level-optimizations in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_3940(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3940,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(1));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_eqp(lf[27],t3));}

/* test in ##compiler#perform-high-level-optimizations in k3926 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_fcall f_3934(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3934,NULL,4,t0,t1,t2,t3);}
/* optimizer.scm: 114  get */
((C_proc5)C_retrieve_symbol_proc(lf[26]))(5,*((C_word*)lf[26]+1),t1,((C_word*)t0)[2],t2,t3);}

/* ##compiler#scan-toplevel-assignments in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_3693(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[15],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3693,3,t0,t1,t2);}
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3696,a[2]=t4,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3714,a[2]=t2,a[3]=t6,a[4]=t4,a[5]=t1,a[6]=t7,tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 46   debugging */
((C_proc4)C_retrieve_symbol_proc(lf[7]))(4,*((C_word*)lf[7]+1),t8,lf[21],lf[22]);}

/* k3712 in ##compiler#scan-toplevel-assignments in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_3714(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3714,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3717,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3758,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 47   call-with-current-continuation */
((C_proc3)C_retrieve_proc(*((C_word*)lf[20]+1)))(3,*((C_word*)lf[20]+1),t2,t3);}

/* a3757 in k3712 in ##compiler#scan-toplevel-assignments in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_3758(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[15],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3758,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3761,a[2]=t6,tmp=(C_word)a,a+=3,tmp));
t8=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3773,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=t6,a[5]=t2,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp));
/* optimizer.scm: 82   scan */
t9=((C_word*)t6)[1];
f_3773(t9,t1,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* scan in a3757 in k3712 in ##compiler#scan-toplevel-assignments in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_fcall f_3773(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3773,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_slot(t4,C_fix(2));
t6=t2;
t7=(C_word)C_slot(t6,C_fix(3));
t8=t2;
t9=(C_word)C_slot(t8,C_fix(1));
t10=(C_word)C_eqp(t9,lf[10]);
if(C_truep(t10)){
t11=(C_word)C_i_car(t5);
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3798,a[2]=t1,a[3]=((C_word*)t0)[7],a[4]=t11,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_memq(t11,t3))){
t13=t12;
f_3798(t13,C_SCHEME_FALSE);}
else{
t13=(C_word)C_i_memq(t11,((C_word*)((C_word*)t0)[6])[1]);
t14=t12;
f_3798(t14,(C_word)C_i_not(t13));}}
else{
t11=(C_word)C_eqp(t9,lf[11]);
t12=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3825,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t5,a[5]=t9,a[6]=t3,a[7]=((C_word*)t0)[4],a[8]=t7,a[9]=t1,a[10]=((C_word*)t0)[5],tmp=(C_word)a,a+=11,tmp);
if(C_truep(t11)){
t13=t12;
f_3825(t13,t11);}
else{
t13=(C_word)C_eqp(t9,lf[18]);
t14=t12;
f_3825(t14,(C_truep(t13)?t13:(C_word)C_eqp(t9,lf[19])));}}}

/* k3823 in scan in a3757 in k3712 in ##compiler#scan-toplevel-assignments in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_fcall f_3825(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3825,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3828,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[8]);
/* optimizer.scm: 64   scan */
t4=((C_word*)((C_word*)t0)[7])[1];
f_3773(t4,t2,t3,((C_word*)t0)[6]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[12]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3844,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[8]);
/* optimizer.scm: 68   scan */
t5=((C_word*)((C_word*)t0)[7])[1];
f_3773(t5,t3,t4,((C_word*)t0)[6]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[5],lf[14]);
t4=(C_truep(t3)?t3:(C_word)C_eqp(((C_word*)t0)[5],lf[15]));
if(C_truep(t4)){
t5=((C_word*)t0)[9];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],lf[16]);
if(C_truep(t5)){
/* optimizer.scm: 73   return */
t6=((C_word*)t0)[10];
((C_proc3)C_retrieve_proc(t6))(3,t6,((C_word*)t0)[9],C_SCHEME_FALSE);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[5],lf[17]);
if(C_truep(t6)){
t7=(C_word)C_i_car(((C_word*)t0)[4]);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3889,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_memq(t7,((C_word*)t0)[6]))){
t9=t8;
f_3889(2,t9,C_SCHEME_UNDEFINED);}
else{
/* optimizer.scm: 77   mark */
t9=((C_word*)t0)[3];
f_3696(3,t9,t8,t7);}}
else{
/* optimizer.scm: 80   scan-each */
t7=((C_word*)((C_word*)t0)[2])[1];
f_3761(t7,((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[6]);}}}}}}

/* k3887 in k3823 in scan in a3757 in k3712 in ##compiler#scan-toplevel-assignments in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_3889(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(((C_word*)t0)[5]);
/* optimizer.scm: 78   scan */
t3=((C_word*)((C_word*)t0)[4])[1];
f_3773(t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k3842 in k3823 in scan in a3757 in k3712 in ##compiler#scan-toplevel-assignments in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_3844(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3844,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3855,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 69   append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[13]+1)))(4,*((C_word*)lf[13]+1),t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3853 in k3842 in k3823 in scan in a3757 in k3712 in ##compiler#scan-toplevel-assignments in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_3855(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 69   scan */
t2=((C_word*)((C_word*)t0)[4])[1];
f_3773(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3826 in k3823 in scan in a3757 in k3712 in ##compiler#scan-toplevel-assignments in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_3828(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 65   return */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k3796 in scan in a3757 in k3712 in ##compiler#scan-toplevel-assignments in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_fcall f_3798(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3798,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* scan-each in a3757 in k3712 in ##compiler#scan-toplevel-assignments in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_fcall f_3761(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3761,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3767,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t5=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t4,t2);}

/* a3766 in scan-each in a3757 in k3712 in ##compiler#scan-toplevel-assignments in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_3767(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3767,3,t0,t1,t2);}
/* optimizer.scm: 51   scan */
t3=((C_word*)((C_word*)t0)[3])[1];
f_3773(t3,t1,t2,((C_word*)t0)[2]);}

/* k3715 in k3712 in ##compiler#scan-toplevel-assignments in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_3717(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3717,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3720,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 83   debugging */
((C_proc5)C_retrieve_symbol_proc(lf[7]))(5,*((C_word*)lf[7]+1),t2,lf[8],lf[9],((C_word*)((C_word*)t0)[2])[1]);}

/* k3718 in k3715 in k3712 in ##compiler#scan-toplevel-assignments in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_3720(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3720,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3725,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* for-each */
t3=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)((C_word*)t0)[2])[1]);}

/* a3724 in k3718 in k3715 in k3712 in ##compiler#scan-toplevel-assignments in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_3725(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3725,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3730,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,lf[5]);}

/* f_3730 in a3724 in k3718 in k3715 in k3712 in ##compiler#scan-toplevel-assignments in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_3730(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_3730r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3730r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3730r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3734,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_3734(2,t6,C_SCHEME_TRUE);}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_3734(2,t7,(C_word)C_i_car(t4));}
else{
/* ##sys#error */
t7=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* k3732 */
static void C_ccall f_3734(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#put! */
((C_proc5)C_retrieve_symbol_proc(lf[3]))(5,*((C_word*)lf[3]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* mark in ##compiler#scan-toplevel-assignments in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 */
static void C_ccall f_3696(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3696,3,t0,t1,t2);}
if(C_truep((C_word)C_i_memq(t2,((C_word*)((C_word*)t0)[3])[1]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[2])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t3);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[667] = {
{"toplevel:optimizer_scm",(void*)C_optimizer_toplevel},
{"f_3676:optimizer_scm",(void*)f_3676},
{"f_3679:optimizer_scm",(void*)f_3679},
{"f_3682:optimizer_scm",(void*)f_3682},
{"f_3685:optimizer_scm",(void*)f_3685},
{"f_3688:optimizer_scm",(void*)f_3688},
{"f_3691:optimizer_scm",(void*)f_3691},
{"f_3928:optimizer_scm",(void*)f_3928},
{"f_13049:optimizer_scm",(void*)f_13049},
{"f_13057:optimizer_scm",(void*)f_13057},
{"f_13062:optimizer_scm",(void*)f_13062},
{"f_13107:optimizer_scm",(void*)f_13107},
{"f_13111:optimizer_scm",(void*)f_13111},
{"f_13072:optimizer_scm",(void*)f_13072},
{"f_13096:optimizer_scm",(void*)f_13096},
{"f_13081:optimizer_scm",(void*)f_13081},
{"f_5661:optimizer_scm",(void*)f_5661},
{"f_12088:optimizer_scm",(void*)f_12088},
{"f_12122:optimizer_scm",(void*)f_12122},
{"f_12224:optimizer_scm",(void*)f_12224},
{"f_12234:optimizer_scm",(void*)f_12234},
{"f_12298:optimizer_scm",(void*)f_12298},
{"f_12327:optimizer_scm",(void*)f_12327},
{"f_12450:optimizer_scm",(void*)f_12450},
{"f_12343:optimizer_scm",(void*)f_12343},
{"f_12390:optimizer_scm",(void*)f_12390},
{"f_12380:optimizer_scm",(void*)f_12380},
{"f_12388:optimizer_scm",(void*)f_12388},
{"f_12520:optimizer_scm",(void*)f_12520},
{"f_12533:optimizer_scm",(void*)f_12533},
{"f_12568:optimizer_scm",(void*)f_12568},
{"f_12552:optimizer_scm",(void*)f_12552},
{"f_12556:optimizer_scm",(void*)f_12556},
{"f_12545:optimizer_scm",(void*)f_12545},
{"f_12734:optimizer_scm",(void*)f_12734},
{"f_12747:optimizer_scm",(void*)f_12747},
{"f_12753:optimizer_scm",(void*)f_12753},
{"f_12799:optimizer_scm",(void*)f_12799},
{"f_12791:optimizer_scm",(void*)f_12791},
{"f_12775:optimizer_scm",(void*)f_12775},
{"f_12779:optimizer_scm",(void*)f_12779},
{"f_12783:optimizer_scm",(void*)f_12783},
{"f_5664:optimizer_scm",(void*)f_5664},
{"f_11766:optimizer_scm",(void*)f_11766},
{"f_11788:optimizer_scm",(void*)f_11788},
{"f_11843:optimizer_scm",(void*)f_11843},
{"f_11813:optimizer_scm",(void*)f_11813},
{"f_11835:optimizer_scm",(void*)f_11835},
{"f_11839:optimizer_scm",(void*)f_11839},
{"f_11831:optimizer_scm",(void*)f_11831},
{"f_11811:optimizer_scm",(void*)f_11811},
{"f_11937:optimizer_scm",(void*)f_11937},
{"f_11951:optimizer_scm",(void*)f_11951},
{"f_5667:optimizer_scm",(void*)f_5667},
{"f_5995:optimizer_scm",(void*)f_5995},
{"f_11740:optimizer_scm",(void*)f_11740},
{"f_11582:optimizer_scm",(void*)f_11582},
{"f_11586:optimizer_scm",(void*)f_11586},
{"f_11589:optimizer_scm",(void*)f_11589},
{"f_11592:optimizer_scm",(void*)f_11592},
{"f_11595:optimizer_scm",(void*)f_11595},
{"f_11598:optimizer_scm",(void*)f_11598},
{"f_11601:optimizer_scm",(void*)f_11601},
{"f_11607:optimizer_scm",(void*)f_11607},
{"f_10694:optimizer_scm",(void*)f_10694},
{"f_11533:optimizer_scm",(void*)f_11533},
{"f_11543:optimizer_scm",(void*)f_11543},
{"f_11550:optimizer_scm",(void*)f_11550},
{"f_11566:optimizer_scm",(void*)f_11566},
{"f_10697:optimizer_scm",(void*)f_10697},
{"f_11531:optimizer_scm",(void*)f_11531},
{"f_11527:optimizer_scm",(void*)f_11527},
{"f_11523:optimizer_scm",(void*)f_11523},
{"f_11519:optimizer_scm",(void*)f_11519},
{"f_11515:optimizer_scm",(void*)f_11515},
{"f_11511:optimizer_scm",(void*)f_11511},
{"f_11507:optimizer_scm",(void*)f_11507},
{"f_11375:optimizer_scm",(void*)f_11375},
{"f_11379:optimizer_scm",(void*)f_11379},
{"f_11382:optimizer_scm",(void*)f_11382},
{"f_11392:optimizer_scm",(void*)f_11392},
{"f_11436:optimizer_scm",(void*)f_11436},
{"f_11416:optimizer_scm",(void*)f_11416},
{"f_10703:optimizer_scm",(void*)f_10703},
{"f_11348:optimizer_scm",(void*)f_11348},
{"f_11358:optimizer_scm",(void*)f_11358},
{"f_10706:optimizer_scm",(void*)f_10706},
{"f_11335:optimizer_scm",(void*)f_11335},
{"f_11339:optimizer_scm",(void*)f_11339},
{"f_10709:optimizer_scm",(void*)f_10709},
{"f_10711:optimizer_scm",(void*)f_10711},
{"f_10717:optimizer_scm",(void*)f_10717},
{"f_11317:optimizer_scm",(void*)f_11317},
{"f_11321:optimizer_scm",(void*)f_11321},
{"f_11306:optimizer_scm",(void*)f_11306},
{"f_11313:optimizer_scm",(void*)f_11313},
{"f_10739:optimizer_scm",(void*)f_10739},
{"f_10742:optimizer_scm",(void*)f_10742},
{"f_10773:optimizer_scm",(void*)f_10773},
{"f_10776:optimizer_scm",(void*)f_10776},
{"f_10779:optimizer_scm",(void*)f_10779},
{"f_10782:optimizer_scm",(void*)f_10782},
{"f_10785:optimizer_scm",(void*)f_10785},
{"f_10788:optimizer_scm",(void*)f_10788},
{"f_10791:optimizer_scm",(void*)f_10791},
{"f_10885:optimizer_scm",(void*)f_10885},
{"f_10946:optimizer_scm",(void*)f_10946},
{"f_11250:optimizer_scm",(void*)f_11250},
{"f_11164:optimizer_scm",(void*)f_11164},
{"f_11167:optimizer_scm",(void*)f_11167},
{"f_11134:optimizer_scm",(void*)f_11134},
{"f_11097:optimizer_scm",(void*)f_11097},
{"f_11060:optimizer_scm",(void*)f_11060},
{"f_11023:optimizer_scm",(void*)f_11023},
{"f_10998:optimizer_scm",(void*)f_10998},
{"f_10973:optimizer_scm",(void*)f_10973},
{"f_10952:optimizer_scm",(void*)f_10952},
{"f_10895:optimizer_scm",(void*)f_10895},
{"f_10898:optimizer_scm",(void*)f_10898},
{"f_10917:optimizer_scm",(void*)f_10917},
{"f_10913:optimizer_scm",(void*)f_10913},
{"f_10822:optimizer_scm",(void*)f_10822},
{"f_10865:optimizer_scm",(void*)f_10865},
{"f_10836:optimizer_scm",(void*)f_10836},
{"f_10875:optimizer_scm",(void*)f_10875},
{"f_10803:optimizer_scm",(void*)f_10803},
{"f_10793:optimizer_scm",(void*)f_10793},
{"f_10747:optimizer_scm",(void*)f_10747},
{"f_10751:optimizer_scm",(void*)f_10751},
{"f_10764:optimizer_scm",(void*)f_10764},
{"f_10754:optimizer_scm",(void*)f_10754},
{"f_10642:optimizer_scm",(void*)f_10642},
{"f_10646:optimizer_scm",(void*)f_10646},
{"f_10672:optimizer_scm",(void*)f_10672},
{"f_10654:optimizer_scm",(void*)f_10654},
{"f_10628:optimizer_scm",(void*)f_10628},
{"f_10632:optimizer_scm",(void*)f_10632},
{"f_10636:optimizer_scm",(void*)f_10636},
{"f_8984:optimizer_scm",(void*)f_8984},
{"f_10530:optimizer_scm",(void*)f_10530},
{"f_10533:optimizer_scm",(void*)f_10533},
{"f_10536:optimizer_scm",(void*)f_10536},
{"f_10539:optimizer_scm",(void*)f_10539},
{"f_10542:optimizer_scm",(void*)f_10542},
{"f_10545:optimizer_scm",(void*)f_10545},
{"f_10622:optimizer_scm",(void*)f_10622},
{"f_10548:optimizer_scm",(void*)f_10548},
{"f_10551:optimizer_scm",(void*)f_10551},
{"f_10554:optimizer_scm",(void*)f_10554},
{"f_10616:optimizer_scm",(void*)f_10616},
{"f_10557:optimizer_scm",(void*)f_10557},
{"f_10560:optimizer_scm",(void*)f_10560},
{"f_10613:optimizer_scm",(void*)f_10613},
{"f_9593:optimizer_scm",(void*)f_9593},
{"f_9611:optimizer_scm",(void*)f_9611},
{"f_9617:optimizer_scm",(void*)f_9617},
{"f_9597:optimizer_scm",(void*)f_9597},
{"f_10563:optimizer_scm",(void*)f_10563},
{"f_10605:optimizer_scm",(void*)f_10605},
{"f_10603:optimizer_scm",(void*)f_10603},
{"f_10566:optimizer_scm",(void*)f_10566},
{"f_10569:optimizer_scm",(void*)f_10569},
{"f_10572:optimizer_scm",(void*)f_10572},
{"f_10596:optimizer_scm",(void*)f_10596},
{"f_10575:optimizer_scm",(void*)f_10575},
{"f_10578:optimizer_scm",(void*)f_10578},
{"f_10581:optimizer_scm",(void*)f_10581},
{"f_10584:optimizer_scm",(void*)f_10584},
{"f_10587:optimizer_scm",(void*)f_10587},
{"f_10590:optimizer_scm",(void*)f_10590},
{"f_10383:optimizer_scm",(void*)f_10383},
{"f_10389:optimizer_scm",(void*)f_10389},
{"f_10501:optimizer_scm",(void*)f_10501},
{"f_10510:optimizer_scm",(void*)f_10510},
{"f_10513:optimizer_scm",(void*)f_10513},
{"f_10408:optimizer_scm",(void*)f_10408},
{"f_10413:optimizer_scm",(void*)f_10413},
{"f_10454:optimizer_scm",(void*)f_10454},
{"f_10451:optimizer_scm",(void*)f_10451},
{"f_10436:optimizer_scm",(void*)f_10436},
{"f_10447:optimizer_scm",(void*)f_10447},
{"f_10443:optimizer_scm",(void*)f_10443},
{"f_10296:optimizer_scm",(void*)f_10296},
{"f_10302:optimizer_scm",(void*)f_10302},
{"f_10358:optimizer_scm",(void*)f_10358},
{"f_10354:optimizer_scm",(void*)f_10354},
{"f_10324:optimizer_scm",(void*)f_10324},
{"f_10047:optimizer_scm",(void*)f_10047},
{"f_10061:optimizer_scm",(void*)f_10061},
{"f_10068:optimizer_scm",(void*)f_10068},
{"f_10071:optimizer_scm",(void*)f_10071},
{"f_10080:optimizer_scm",(void*)f_10080},
{"f_10087:optimizer_scm",(void*)f_10087},
{"f_10090:optimizer_scm",(void*)f_10090},
{"f_10186:optimizer_scm",(void*)f_10186},
{"f_10272:optimizer_scm",(void*)f_10272},
{"f_10291:optimizer_scm",(void*)f_10291},
{"f_10287:optimizer_scm",(void*)f_10287},
{"f_10253:optimizer_scm",(void*)f_10253},
{"f_10242:optimizer_scm",(void*)f_10242},
{"f_10229:optimizer_scm",(void*)f_10229},
{"f_10212:optimizer_scm",(void*)f_10212},
{"f_10205:optimizer_scm",(void*)f_10205},
{"f_10171:optimizer_scm",(void*)f_10171},
{"f_10093:optimizer_scm",(void*)f_10093},
{"f_10142:optimizer_scm",(void*)f_10142},
{"f_10130:optimizer_scm",(void*)f_10130},
{"f_10126:optimizer_scm",(void*)f_10126},
{"f_10059:optimizer_scm",(void*)f_10059},
{"f_9846:optimizer_scm",(void*)f_9846},
{"f_10033:optimizer_scm",(void*)f_10033},
{"f_9911:optimizer_scm",(void*)f_9911},
{"f_9988:optimizer_scm",(void*)f_9988},
{"f_9993:optimizer_scm",(void*)f_9993},
{"f_10031:optimizer_scm",(void*)f_10031},
{"f_9855:optimizer_scm",(void*)f_9855},
{"f_9893:optimizer_scm",(void*)f_9893},
{"f_9898:optimizer_scm",(void*)f_9898},
{"f_9875:optimizer_scm",(void*)f_9875},
{"f_9853:optimizer_scm",(void*)f_9853},
{"f_10023:optimizer_scm",(void*)f_10023},
{"f_10009:optimizer_scm",(void*)f_10009},
{"f_10007:optimizer_scm",(void*)f_10007},
{"f_9913:optimizer_scm",(void*)f_9913},
{"f_9981:optimizer_scm",(void*)f_9981},
{"f_9979:optimizer_scm",(void*)f_9979},
{"f_9967:optimizer_scm",(void*)f_9967},
{"f_9933:optimizer_scm",(void*)f_9933},
{"f_9957:optimizer_scm",(void*)f_9957},
{"f_9955:optimizer_scm",(void*)f_9955},
{"f_9951:optimizer_scm",(void*)f_9951},
{"f_9943:optimizer_scm",(void*)f_9943},
{"f_9627:optimizer_scm",(void*)f_9627},
{"f_9633:optimizer_scm",(void*)f_9633},
{"f_9652:optimizer_scm",(void*)f_9652},
{"f_9819:optimizer_scm",(void*)f_9819},
{"f_9749:optimizer_scm",(void*)f_9749},
{"f_9765:optimizer_scm",(void*)f_9765},
{"f_9795:optimizer_scm",(void*)f_9795},
{"f_9799:optimizer_scm",(void*)f_9799},
{"f_9785:optimizer_scm",(void*)f_9785},
{"f_9738:optimizer_scm",(void*)f_9738},
{"f_9743:optimizer_scm",(void*)f_9743},
{"f_9714:optimizer_scm",(void*)f_9714},
{"f_9726:optimizer_scm",(void*)f_9726},
{"f_9663:optimizer_scm",(void*)f_9663},
{"f_9684:optimizer_scm",(void*)f_9684},
{"f_9681:optimizer_scm",(void*)f_9681},
{"f_9631:optimizer_scm",(void*)f_9631},
{"f_9383:optimizer_scm",(void*)f_9383},
{"f_9389:optimizer_scm",(void*)f_9389},
{"f_9408:optimizer_scm",(void*)f_9408},
{"f_9510:optimizer_scm",(void*)f_9510},
{"f_9501:optimizer_scm",(void*)f_9501},
{"f_9467:optimizer_scm",(void*)f_9467},
{"f_9476:optimizer_scm",(void*)f_9476},
{"f_9488:optimizer_scm",(void*)f_9488},
{"f_9419:optimizer_scm",(void*)f_9419},
{"f_9440:optimizer_scm",(void*)f_9440},
{"f_9437:optimizer_scm",(void*)f_9437},
{"f_9387:optimizer_scm",(void*)f_9387},
{"f_9284:optimizer_scm",(void*)f_9284},
{"f_9290:optimizer_scm",(void*)f_9290},
{"f_9334:optimizer_scm",(void*)f_9334},
{"f_9339:optimizer_scm",(void*)f_9339},
{"f_9346:optimizer_scm",(void*)f_9346},
{"f_9373:optimizer_scm",(void*)f_9373},
{"f_9369:optimizer_scm",(void*)f_9369},
{"f_9361:optimizer_scm",(void*)f_9361},
{"f_9359:optimizer_scm",(void*)f_9359},
{"f_9324:optimizer_scm",(void*)f_9324},
{"f_9302:optimizer_scm",(void*)f_9302},
{"f_9309:optimizer_scm",(void*)f_9309},
{"f_9087:optimizer_scm",(void*)f_9087},
{"f_9241:optimizer_scm",(void*)f_9241},
{"f_9266:optimizer_scm",(void*)f_9266},
{"f_9256:optimizer_scm",(void*)f_9256},
{"f_9260:optimizer_scm",(void*)f_9260},
{"f_9239:optimizer_scm",(void*)f_9239},
{"f_9090:optimizer_scm",(void*)f_9090},
{"f_9229:optimizer_scm",(void*)f_9229},
{"f_9212:optimizer_scm",(void*)f_9212},
{"f_9224:optimizer_scm",(void*)f_9224},
{"f_9158:optimizer_scm",(void*)f_9158},
{"f_9182:optimizer_scm",(void*)f_9182},
{"f_9176:optimizer_scm",(void*)f_9176},
{"f_9140:optimizer_scm",(void*)f_9140},
{"f_9115:optimizer_scm",(void*)f_9115},
{"f_9118:optimizer_scm",(void*)f_9118},
{"f_9123:optimizer_scm",(void*)f_9123},
{"f_8987:optimizer_scm",(void*)f_8987},
{"f_8993:optimizer_scm",(void*)f_8993},
{"f_9024:optimizer_scm",(void*)f_9024},
{"f_9028:optimizer_scm",(void*)f_9028},
{"f_9032:optimizer_scm",(void*)f_9032},
{"f_8991:optimizer_scm",(void*)f_8991},
{"f_7889:optimizer_scm",(void*)f_7889},
{"f_8979:optimizer_scm",(void*)f_8979},
{"f_8982:optimizer_scm",(void*)f_8982},
{"f_7892:optimizer_scm",(void*)f_7892},
{"f_8048:optimizer_scm",(void*)f_8048},
{"f_8028:optimizer_scm",(void*)f_8028},
{"f_8002:optimizer_scm",(void*)f_8002},
{"f_7948:optimizer_scm",(void*)f_7948},
{"f_7954:optimizer_scm",(void*)f_7954},
{"f_7960:optimizer_scm",(void*)f_7960},
{"f_7917:optimizer_scm",(void*)f_7917},
{"f_8054:optimizer_scm",(void*)f_8054},
{"f_8464:optimizer_scm",(void*)f_8464},
{"f_8471:optimizer_scm",(void*)f_8471},
{"f_8057:optimizer_scm",(void*)f_8057},
{"f_8451:optimizer_scm",(void*)f_8451},
{"f_8427:optimizer_scm",(void*)f_8427},
{"f_8438:optimizer_scm",(void*)f_8438},
{"f_8394:optimizer_scm",(void*)f_8394},
{"f_8333:optimizer_scm",(void*)f_8333},
{"f_8305:optimizer_scm",(void*)f_8305},
{"f_8310:optimizer_scm",(void*)f_8310},
{"f_8252:optimizer_scm",(void*)f_8252},
{"f_8258:optimizer_scm",(void*)f_8258},
{"f_8263:optimizer_scm",(void*)f_8263},
{"f_8211:optimizer_scm",(void*)f_8211},
{"f_8217:optimizer_scm",(void*)f_8217},
{"f_8222:optimizer_scm",(void*)f_8222},
{"f_8195:optimizer_scm",(void*)f_8195},
{"f_8191:optimizer_scm",(void*)f_8191},
{"f_8161:optimizer_scm",(void*)f_8161},
{"f_8124:optimizer_scm",(void*)f_8124},
{"f_8140:optimizer_scm",(void*)f_8140},
{"f_8106:optimizer_scm",(void*)f_8106},
{"f_8473:optimizer_scm",(void*)f_8473},
{"f_8969:optimizer_scm",(void*)f_8969},
{"f_8967:optimizer_scm",(void*)f_8967},
{"f_8477:optimizer_scm",(void*)f_8477},
{"f_8487:optimizer_scm",(void*)f_8487},
{"f_8493:optimizer_scm",(void*)f_8493},
{"f_8499:optimizer_scm",(void*)f_8499},
{"f_8502:optimizer_scm",(void*)f_8502},
{"f_8508:optimizer_scm",(void*)f_8508},
{"f_8684:optimizer_scm",(void*)f_8684},
{"f_8906:optimizer_scm",(void*)f_8906},
{"f_8909:optimizer_scm",(void*)f_8909},
{"f_8859:optimizer_scm",(void*)f_8859},
{"f_8862:optimizer_scm",(void*)f_8862},
{"f_8728:optimizer_scm",(void*)f_8728},
{"f_8783:optimizer_scm",(void*)f_8783},
{"f_8786:optimizer_scm",(void*)f_8786},
{"f_8813:optimizer_scm",(void*)f_8813},
{"f_8789:optimizer_scm",(void*)f_8789},
{"f_8792:optimizer_scm",(void*)f_8792},
{"f_8737:optimizer_scm",(void*)f_8737},
{"f_8740:optimizer_scm",(void*)f_8740},
{"f_8743:optimizer_scm",(void*)f_8743},
{"f_8511:optimizer_scm",(void*)f_8511},
{"f_8666:optimizer_scm",(void*)f_8666},
{"f_8664:optimizer_scm",(void*)f_8664},
{"f_8607:optimizer_scm",(void*)f_8607},
{"f_8617:optimizer_scm",(void*)f_8617},
{"f_8514:optimizer_scm",(void*)f_8514},
{"f_8526:optimizer_scm",(void*)f_8526},
{"f_8565:optimizer_scm",(void*)f_8565},
{"f_8529:optimizer_scm",(void*)f_8529},
{"f_8532:optimizer_scm",(void*)f_8532},
{"f_8537:optimizer_scm",(void*)f_8537},
{"f_8563:optimizer_scm",(void*)f_8563},
{"f_8544:optimizer_scm",(void*)f_8544},
{"f_6017:optimizer_scm",(void*)f_6017},
{"f_7763:optimizer_scm",(void*)f_7763},
{"f_7785:optimizer_scm",(void*)f_7785},
{"f_7797:optimizer_scm",(void*)f_7797},
{"f_7811:optimizer_scm",(void*)f_7811},
{"f_7860:optimizer_scm",(void*)f_7860},
{"f_6042:optimizer_scm",(void*)f_6042},
{"f_7831:optimizer_scm",(void*)f_7831},
{"f_7835:optimizer_scm",(void*)f_7835},
{"f_7805:optimizer_scm",(void*)f_7805},
{"f_7791:optimizer_scm",(void*)f_7791},
{"f_7789:optimizer_scm",(void*)f_7789},
{"f_7778:optimizer_scm",(void*)f_7778},
{"f_7706:optimizer_scm",(void*)f_7706},
{"f_7738:optimizer_scm",(void*)f_7738},
{"f_7725:optimizer_scm",(void*)f_7725},
{"f_7558:optimizer_scm",(void*)f_7558},
{"f_7564:optimizer_scm",(void*)f_7564},
{"f_7648:optimizer_scm",(void*)f_7648},
{"f_7573:optimizer_scm",(void*)f_7573},
{"f_7617:optimizer_scm",(void*)f_7617},
{"f_7615:optimizer_scm",(void*)f_7615},
{"f_7589:optimizer_scm",(void*)f_7589},
{"f_7491:optimizer_scm",(void*)f_7491},
{"f_7519:optimizer_scm",(void*)f_7519},
{"f_7531:optimizer_scm",(void*)f_7531},
{"f_7509:optimizer_scm",(void*)f_7509},
{"f_7504:optimizer_scm",(void*)f_7504},
{"f_7349:optimizer_scm",(void*)f_7349},
{"f_7430:optimizer_scm",(void*)f_7430},
{"f_7358:optimizer_scm",(void*)f_7358},
{"f_7411:optimizer_scm",(void*)f_7411},
{"f_7409:optimizer_scm",(void*)f_7409},
{"f_7374:optimizer_scm",(void*)f_7374},
{"f_7320:optimizer_scm",(void*)f_7320},
{"f_7330:optimizer_scm",(void*)f_7330},
{"f_7258:optimizer_scm",(void*)f_7258},
{"f_7278:optimizer_scm",(void*)f_7278},
{"f_7185:optimizer_scm",(void*)f_7185},
{"f_7215:optimizer_scm",(void*)f_7215},
{"f_7098:optimizer_scm",(void*)f_7098},
{"f_7117:optimizer_scm",(void*)f_7117},
{"f_7110:optimizer_scm",(void*)f_7110},
{"f_7021:optimizer_scm",(void*)f_7021},
{"f_6962:optimizer_scm",(void*)f_6962},
{"f_6977:optimizer_scm",(void*)f_6977},
{"f_6980:optimizer_scm",(void*)f_6980},
{"f_6892:optimizer_scm",(void*)f_6892},
{"f_6935:optimizer_scm",(void*)f_6935},
{"f_6928:optimizer_scm",(void*)f_6928},
{"f_6833:optimizer_scm",(void*)f_6833},
{"f_6845:optimizer_scm",(void*)f_6845},
{"f_6858:optimizer_scm",(void*)f_6858},
{"f_6851:optimizer_scm",(void*)f_6851},
{"f_6746:optimizer_scm",(void*)f_6746},
{"f_6768:optimizer_scm",(void*)f_6768},
{"f_6776:optimizer_scm",(void*)f_6776},
{"f_6780:optimizer_scm",(void*)f_6780},
{"f_6602:optimizer_scm",(void*)f_6602},
{"f_6624:optimizer_scm",(void*)f_6624},
{"f_6627:optimizer_scm",(void*)f_6627},
{"f_6686:optimizer_scm",(void*)f_6686},
{"f_6630:optimizer_scm",(void*)f_6630},
{"f_6633:optimizer_scm",(void*)f_6633},
{"f_6664:optimizer_scm",(void*)f_6664},
{"f_6662:optimizer_scm",(void*)f_6662},
{"f_6638:optimizer_scm",(void*)f_6638},
{"f_6618:optimizer_scm",(void*)f_6618},
{"f_6581:optimizer_scm",(void*)f_6581},
{"f_6526:optimizer_scm",(void*)f_6526},
{"f_6550:optimizer_scm",(void*)f_6550},
{"f_6539:optimizer_scm",(void*)f_6539},
{"f_6461:optimizer_scm",(void*)f_6461},
{"f_6374:optimizer_scm",(void*)f_6374},
{"f_6416:optimizer_scm",(void*)f_6416},
{"f_6318:optimizer_scm",(void*)f_6318},
{"f_6331:optimizer_scm",(void*)f_6331},
{"f_6339:optimizer_scm",(void*)f_6339},
{"f_6280:optimizer_scm",(void*)f_6280},
{"f_6290:optimizer_scm",(void*)f_6290},
{"f_6182:optimizer_scm",(void*)f_6182},
{"f_6239:optimizer_scm",(void*)f_6239},
{"f_6210:optimizer_scm",(void*)f_6210},
{"f_6207:optimizer_scm",(void*)f_6207},
{"f_6074:optimizer_scm",(void*)f_6074},
{"f_6137:optimizer_scm",(void*)f_6137},
{"f_6077:optimizer_scm",(void*)f_6077},
{"f_5997:optimizer_scm",(void*)f_5997},
{"f_6001:optimizer_scm",(void*)f_6001},
{"f_6011:optimizer_scm",(void*)f_6011},
{"f_5669:optimizer_scm",(void*)f_5669},
{"f_5673:optimizer_scm",(void*)f_5673},
{"f_5982:optimizer_scm",(void*)f_5982},
{"f_5991:optimizer_scm",(void*)f_5991},
{"f_5987:optimizer_scm",(void*)f_5987},
{"f_5720:optimizer_scm",(void*)f_5720},
{"f_5924:optimizer_scm",(void*)f_5924},
{"f_5956:optimizer_scm",(void*)f_5956},
{"f_5969:optimizer_scm",(void*)f_5969},
{"f_5934:optimizer_scm",(void*)f_5934},
{"f_5950:optimizer_scm",(void*)f_5950},
{"f_5938:optimizer_scm",(void*)f_5938},
{"f_5942:optimizer_scm",(void*)f_5942},
{"f_5723:optimizer_scm",(void*)f_5723},
{"f_5865:optimizer_scm",(void*)f_5865},
{"f_5908:optimizer_scm",(void*)f_5908},
{"f_5914:optimizer_scm",(void*)f_5914},
{"f_5872:optimizer_scm",(void*)f_5872},
{"f_5882:optimizer_scm",(void*)f_5882},
{"f_5895:optimizer_scm",(void*)f_5895},
{"f_5880:optimizer_scm",(void*)f_5880},
{"f_5876:optimizer_scm",(void*)f_5876},
{"f_5726:optimizer_scm",(void*)f_5726},
{"f_5729:optimizer_scm",(void*)f_5729},
{"f_5749:optimizer_scm",(void*)f_5749},
{"f_5762:optimizer_scm",(void*)f_5762},
{"f_5805:optimizer_scm",(void*)f_5805},
{"f_5837:optimizer_scm",(void*)f_5837},
{"f_5803:optimizer_scm",(void*)f_5803},
{"f_5785:optimizer_scm",(void*)f_5785},
{"f_5732:optimizer_scm",(void*)f_5732},
{"f_5741:optimizer_scm",(void*)f_5741},
{"f_5675:optimizer_scm",(void*)f_5675},
{"f_5681:optimizer_scm",(void*)f_5681},
{"f_5705:optimizer_scm",(void*)f_5705},
{"f_5654:optimizer_scm",(void*)f_5654},
{"f_5413:optimizer_scm",(void*)f_5413},
{"f_5427:optimizer_scm",(void*)f_5427},
{"f_5442:optimizer_scm",(void*)f_5442},
{"f_5649:optimizer_scm",(void*)f_5649},
{"f_5447:optimizer_scm",(void*)f_5447},
{"f_5638:optimizer_scm",(void*)f_5638},
{"f_5460:optimizer_scm",(void*)f_5460},
{"f_5463:optimizer_scm",(void*)f_5463},
{"f_5469:optimizer_scm",(void*)f_5469},
{"f_5484:optimizer_scm",(void*)f_5484},
{"f_5490:optimizer_scm",(void*)f_5490},
{"f_5496:optimizer_scm",(void*)f_5496},
{"f_5505:optimizer_scm",(void*)f_5505},
{"f_5512:optimizer_scm",(void*)f_5512},
{"f_5515:optimizer_scm",(void*)f_5515},
{"f_5533:optimizer_scm",(void*)f_5533},
{"f_5518:optimizer_scm",(void*)f_5518},
{"f_5430:optimizer_scm",(void*)f_5430},
{"f_5433:optimizer_scm",(void*)f_5433},
{"f_5420:optimizer_scm",(void*)f_5420},
{"f_5416:optimizer_scm",(void*)f_5416},
{"f_3931:optimizer_scm",(void*)f_3931},
{"f_5317:optimizer_scm",(void*)f_5317},
{"f_5323:optimizer_scm",(void*)f_5323},
{"f_5327:optimizer_scm",(void*)f_5327},
{"f_5330:optimizer_scm",(void*)f_5330},
{"f_5366:optimizer_scm",(void*)f_5366},
{"f_5371:optimizer_scm",(void*)f_5371},
{"f_5375:optimizer_scm",(void*)f_5375},
{"f_5333:optimizer_scm",(void*)f_5333},
{"f_5336:optimizer_scm",(void*)f_5336},
{"f_5339:optimizer_scm",(void*)f_5339},
{"f_5342:optimizer_scm",(void*)f_5342},
{"f_5298:optimizer_scm",(void*)f_5298},
{"f_5302:optimizer_scm",(void*)f_5302},
{"f_5308:optimizer_scm",(void*)f_5308},
{"f_4270:optimizer_scm",(void*)f_4270},
{"f_5214:optimizer_scm",(void*)f_5214},
{"f_5217:optimizer_scm",(void*)f_5217},
{"f_5290:optimizer_scm",(void*)f_5290},
{"f_5286:optimizer_scm",(void*)f_5286},
{"f_5258:optimizer_scm",(void*)f_5258},
{"f_5279:optimizer_scm",(void*)f_5279},
{"f_5271:optimizer_scm",(void*)f_5271},
{"f_5229:optimizer_scm",(void*)f_5229},
{"f_5248:optimizer_scm",(void*)f_5248},
{"f_5235:optimizer_scm",(void*)f_5235},
{"f_5189:optimizer_scm",(void*)f_5189},
{"f_5164:optimizer_scm",(void*)f_5164},
{"f_5154:optimizer_scm",(void*)f_5154},
{"f_4597:optimizer_scm",(void*)f_4597},
{"f_4606:optimizer_scm",(void*)f_4606},
{"f_4787:optimizer_scm",(void*)f_4787},
{"f_4798:optimizer_scm",(void*)f_4798},
{"f_5110:optimizer_scm",(void*)f_5110},
{"f_5116:optimizer_scm",(void*)f_5116},
{"f_5119:optimizer_scm",(void*)f_5119},
{"f_4808:optimizer_scm",(void*)f_4808},
{"f_4855:optimizer_scm",(void*)f_4855},
{"f_5097:optimizer_scm",(void*)f_5097},
{"f_5014:optimizer_scm",(void*)f_5014},
{"f_5017:optimizer_scm",(void*)f_5017},
{"f_5029:optimizer_scm",(void*)f_5029},
{"f_5040:optimizer_scm",(void*)f_5040},
{"f_5067:optimizer_scm",(void*)f_5067},
{"f_5059:optimizer_scm",(void*)f_5059},
{"f_5044:optimizer_scm",(void*)f_5044},
{"f_5034:optimizer_scm",(void*)f_5034},
{"f_4869:optimizer_scm",(void*)f_4869},
{"f_4902:optimizer_scm",(void*)f_4902},
{"f_4908:optimizer_scm",(void*)f_4908},
{"f_4914:optimizer_scm",(void*)f_4914},
{"f_4951:optimizer_scm",(void*)f_4951},
{"f_4927:optimizer_scm",(void*)f_4927},
{"f_4931:optimizer_scm",(void*)f_4931},
{"f_4896:optimizer_scm",(void*)f_4896},
{"f_4885:optimizer_scm",(void*)f_4885},
{"f_4846:optimizer_scm",(void*)f_4846},
{"f_4811:optimizer_scm",(void*)f_4811},
{"f_4814:optimizer_scm",(void*)f_4814},
{"f_4817:optimizer_scm",(void*)f_4817},
{"f_4827:optimizer_scm",(void*)f_4827},
{"f_4773:optimizer_scm",(void*)f_4773},
{"f_4669:optimizer_scm",(void*)f_4669},
{"f_4690:optimizer_scm",(void*)f_4690},
{"f_4747:optimizer_scm",(void*)f_4747},
{"f_4739:optimizer_scm",(void*)f_4739},
{"f_4693:optimizer_scm",(void*)f_4693},
{"f_4718:optimizer_scm",(void*)f_4718},
{"f_4716:optimizer_scm",(void*)f_4716},
{"f_4702:optimizer_scm",(void*)f_4702},
{"f_4648:optimizer_scm",(void*)f_4648},
{"f_4615:optimizer_scm",(void*)f_4615},
{"f_4618:optimizer_scm",(void*)f_4618},
{"f_4628:optimizer_scm",(void*)f_4628},
{"f_4421:optimizer_scm",(void*)f_4421},
{"f_4513:optimizer_scm",(void*)f_4513},
{"f_4518:optimizer_scm",(void*)f_4518},
{"f_4525:optimizer_scm",(void*)f_4525},
{"f_4554:optimizer_scm",(void*)f_4554},
{"f_4538:optimizer_scm",(void*)f_4538},
{"f_4426:optimizer_scm",(void*)f_4426},
{"f_4444:optimizer_scm",(void*)f_4444},
{"f_4451:optimizer_scm",(void*)f_4451},
{"f_4487:optimizer_scm",(void*)f_4487},
{"f_4490:optimizer_scm",(void*)f_4490},
{"f_4480:optimizer_scm",(void*)f_4480},
{"f_4464:optimizer_scm",(void*)f_4464},
{"f_4432:optimizer_scm",(void*)f_4432},
{"f_4438:optimizer_scm",(void*)f_4438},
{"f_4370:optimizer_scm",(void*)f_4370},
{"f_4399:optimizer_scm",(void*)f_4399},
{"f_4406:optimizer_scm",(void*)f_4406},
{"f_4373:optimizer_scm",(void*)f_4373},
{"f_4390:optimizer_scm",(void*)f_4390},
{"f_4295:optimizer_scm",(void*)f_4295},
{"f_4299:optimizer_scm",(void*)f_4299},
{"f_4311:optimizer_scm",(void*)f_4311},
{"f_4334:optimizer_scm",(void*)f_4334},
{"f_4317:optimizer_scm",(void*)f_4317},
{"f_4328:optimizer_scm",(void*)f_4328},
{"f_4056:optimizer_scm",(void*)f_4056},
{"f_4070:optimizer_scm",(void*)f_4070},
{"f_4241:optimizer_scm",(void*)f_4241},
{"f_4247:optimizer_scm",(void*)f_4247},
{"f_4140:optimizer_scm",(void*)f_4140},
{"f_4222:optimizer_scm",(void*)f_4222},
{"f_4220:optimizer_scm",(void*)f_4220},
{"f_4151:optimizer_scm",(void*)f_4151},
{"f_4174:optimizer_scm",(void*)f_4174},
{"f_4206:optimizer_scm",(void*)f_4206},
{"f_4212:optimizer_scm",(void*)f_4212},
{"f_4180:optimizer_scm",(void*)f_4180},
{"f_4184:optimizer_scm",(void*)f_4184},
{"f_4187:optimizer_scm",(void*)f_4187},
{"f_4204:optimizer_scm",(void*)f_4204},
{"f_4157:optimizer_scm",(void*)f_4157},
{"f_4163:optimizer_scm",(void*)f_4163},
{"f_4167:optimizer_scm",(void*)f_4167},
{"f_4171:optimizer_scm",(void*)f_4171},
{"f_4149:optimizer_scm",(void*)f_4149},
{"f_4079:optimizer_scm",(void*)f_4079},
{"f_3964:optimizer_scm",(void*)f_3964},
{"f_3968:optimizer_scm",(void*)f_3968},
{"f_3979:optimizer_scm",(void*)f_3979},
{"f_3989:optimizer_scm",(void*)f_3989},
{"f_4038:optimizer_scm",(void*)f_4038},
{"f_4036:optimizer_scm",(void*)f_4036},
{"f_3995:optimizer_scm",(void*)f_3995},
{"f_4001:optimizer_scm",(void*)f_4001},
{"f_4028:optimizer_scm",(void*)f_4028},
{"f_4007:optimizer_scm",(void*)f_4007},
{"f_3971:optimizer_scm",(void*)f_3971},
{"f_3960:optimizer_scm",(void*)f_3960},
{"f_3940:optimizer_scm",(void*)f_3940},
{"f_3934:optimizer_scm",(void*)f_3934},
{"f_3693:optimizer_scm",(void*)f_3693},
{"f_3714:optimizer_scm",(void*)f_3714},
{"f_3758:optimizer_scm",(void*)f_3758},
{"f_3773:optimizer_scm",(void*)f_3773},
{"f_3825:optimizer_scm",(void*)f_3825},
{"f_3889:optimizer_scm",(void*)f_3889},
{"f_3844:optimizer_scm",(void*)f_3844},
{"f_3855:optimizer_scm",(void*)f_3855},
{"f_3828:optimizer_scm",(void*)f_3828},
{"f_3798:optimizer_scm",(void*)f_3798},
{"f_3761:optimizer_scm",(void*)f_3761},
{"f_3767:optimizer_scm",(void*)f_3767},
{"f_3717:optimizer_scm",(void*)f_3717},
{"f_3720:optimizer_scm",(void*)f_3720},
{"f_3725:optimizer_scm",(void*)f_3725},
{"f_3730:optimizer_scm",(void*)f_3730},
{"f_3734:optimizer_scm",(void*)f_3734},
{"f_3696:optimizer_scm",(void*)f_3696},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
